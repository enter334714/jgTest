GameGlobal.wx = ks;
wx.onMessage = function() {}
wx.getOpenDataContext = function() {}
