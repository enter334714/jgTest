var _ = wx.y$;
import _dlmqpn from '../bbbk/bbbsdk.js';window[_[40818]] = { 'wxVersion': window[_[565]][_[54735]] }, window[_[54736]] = ![], window['p$ED'] = 0x1, window[_[54737]] = 0x1, window['p$CDE'] = !![], window[_[54738]] = !![], window['p$ABCDE'] = '', window[_[54739]] = ![], window['p$DE'] = { 'base_cdn': _[54740], 'cdn': _[54740] }, p$DE[_[54741]] = {}, p$DE[_[40856]] = '0', p$DE[_[5407]] = window[_[40818]][_[54742]], p$DE[_[24461]] = '', p$DE['os'] = '1', p$DE[_[54743]] = _[54744], p$DE[_[54745]] = _[54746], p$DE[_[54747]] = _[54748], p$DE[_[54749]] = _[54750], p$DE[_[54751]] = _[54752], p$DE[_[16951]] = '1', p$DE[_[41344]] = '', p$DE[_[41346]] = '', p$DE[_[54753]] = 0x0, p$DE[_[54754]] = {}, p$DE[_[54755]] = parseInt(p$DE[_[16951]]), p$DE[_[16960]] = p$DE[_[16951]], p$DE[_[41338]] = {}, p$DE['p$BD'] = _[54756], p$DE[_[54757]] = ![], p$DE[_[17165]] = _[54758], p$DE[_[41282]] = Date[_[83]](), p$DE[_[4572]] = _[54759], p$DE[_[753]] = '_a', p$DE[_[41515]] = '', p$DE[_[54760]] = 0x1, p$DE[_[101]] = 0x7c1, p$DE[_[54742]] = window[_[40818]][_[54742]], p$DE[_[775]] = ![], p$DE[_[1130]] = ![], p$DE[_[15196]] = ![], p$DE[_[40858]] = ![], window['p$CED'] = 0x5, window['p$CE'] = ![], window['p$EC'] = ![], window['p$DCE'] = ![], window[_[54761]] = ![], window[_[54762]] = ![], window['p$DEC'] = ![], window['p$CD'] = ![], window['p$DC'] = ![], window['p$ECD'] = ![], window[_[54763]] = null, window[_[659]] = function (nomjlk) {
  console[_[490]](_[659], nomjlk), wx[_[4916]]({}), wx[_[54764]]({ 'title': _[6478], 'content': nomjlk, 'success'(bcdge) {
      if (bcdge[_[54765]]) console[_[490]](_[54766]);else bcdge[_[561]] && console[_[490]](_[54767]);
    } });
}, window['p$BCDE'] = function (omlnk) {
  console[_[490]](_[54768], omlnk), p$BDEC(), wx[_[54764]]({ 'title': _[6478], 'content': omlnk, 'confirmText': _[54769], 'cancelText': _[28308], 'success'(onljmk) {
      if (onljmk[_[54765]]) window['p$DB']();else onljmk[_[561]] && (console[_[490]](_[54770]), wx[_[40854]]({}));
    } });
}, window[_[54771]] = function (fhij) {
  console[_[490]](_[54771], fhij), wx[_[54764]]({ 'title': _[6478], 'content': fhij, 'confirmText': _[41495], 'showCancel': ![], 'complete'(inmjlk) {
      console[_[490]](_[54770]), wx[_[40854]]({});
    } });
}, window['p$BCED'] = ![], window['p$BDCE'] = function (ijgehf) {
  window['p$BCED'] = !![], wx[_[4915]](ijgehf);
}, window['p$BDEC'] = function () {
  window['p$BCED'] && (window['p$BCED'] = ![], wx[_[4916]]({}));
}, window['p$BECD'] = function (mhil) {
  window[_[54772]][_[148]]['p$BECD'](mhil);
}, window[_[16967]] = function (nljmok, klimhj) {
  _dlmqpn[_[16967]](nljmok, function (qtrsvu) {
    qtrsvu && qtrsvu[_[11]] ? qtrsvu[_[11]][_[1327]] == 0x1 ? klimhj(!![]) : (klimhj(![]), console[_[78]](_[54773] + qtrsvu[_[11]][_[54774]])) : console[_[490]](_[16967], qtrsvu);
  });
}, window['p$BEDC'] = function (porm) {
  console[_[490]](_[54775], porm);
}, window['p$BDE'] = function (ihgd) {}, window['p$BED'] = function (fgjihe, qpnom, y$10z) {}, window['p$BE'] = function (iklghj) {
  console[_[490]](_[54776], iklghj), window[_[54772]][_[148]][_[54777]](), window[_[54772]][_[148]][_[54778]](), window[_[54772]][_[148]][_[54779]](), window[_[54780]]();
}, window['p$EB'] = function (w_xzy$) {
  window[_[54781]](0xe, _[54782] + w_xzy$), window['p$BCDE'](_[54783]);var jmlnki = { 'id': window['p$DE'][_[54784]], 'role': window['p$DE'][_[4705]], 'level': window['p$DE'][_[54785]], 'account': window['p$DE'][_[41342]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4570]], 'pkgName': window['p$DE'][_[41344]], 'gamever': window[_[565]][_[54735]], 'serverid': window['p$DE'][_[41338]] ? window['p$DE'][_[41338]][_[15431]] : 0x0, 'systemInfo': window[_[54786]], 'error': _[54787], 'stack': w_xzy$ ? w_xzy$ : _[54783] },
      trsqpu = JSON[_[4556]](jmlnki);console[_[125]](_[54788] + trsqpu), window['p$BD'](trsqpu);
}, window[_[54781]] = function (ligk, egdbf) {
  sendApi(p$DE[_[54747]], _[54789], { 'game_pkg': p$DE[_[41344]], 'partner_id': p$DE[_[16951]], 'server_id': p$DE[_[41338]] && p$DE[_[41338]][_[15431]] > 0x0 ? p$DE[_[41338]][_[15431]] : 0x0, 'uid': p$DE[_[41342]] > 0x0 ? p$DE[_[41342]] : 0x0, 'type': ligk, 'info': egdbf });
}, window['p$DBE'] = function (knplm) {
  var vwsrut = JSON[_[533]](knplm);vwsrut[_[54790]] = window[_[565]][_[54735]], vwsrut[_[54791]] = window['p$DE'][_[41338]] ? window['p$DE'][_[41338]][_[15431]] : 0x0, vwsrut[_[54786]] = window[_[54786]];var y10z$_ = JSON[_[4556]](vwsrut);console[_[125]](_[54792] + y10z$_), window['p$BD'](y10z$_);
}, window['p$DEB'] = function (hjgki, mhij) {
  var rpsqo = { 'id': window['p$DE'][_[54784]], 'role': window['p$DE'][_[4705]], 'level': window['p$DE'][_[54785]], 'account': window['p$DE'][_[41342]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4570]], 'pkgName': window['p$DE'][_[41344]], 'gamever': window[_[565]][_[54735]], 'serverid': window['p$DE'][_[41338]] ? window['p$DE'][_[41338]][_[15431]] : 0x0, 'systemInfo': window[_[54786]], 'error': hjgki, 'stack': mhij },
      efg = JSON[_[4556]](rpsqo);console[_[96]](_[54793] + efg), window['p$BD'](efg);
}, window['p$BD'] = function (moqnr) {
  if (window['p$DE'][_[54794]] == _[54795]) return;var y1_z = p$DE['p$BD'] + _[54796] + p$DE[_[41342]];wx[_[485]]({ 'url': y1_z, 'method': _[54617], 'data': moqnr, 'header': { 'content-type': _[54797], 'cache-control': _[54798] }, 'success': function (z1y0_) {
      DEBUG && console[_[490]](_[54799], y1_z, moqnr, z1y0_);
    }, 'fail': function (zxwy) {
      DEBUG && console[_[490]](_[54799], y1_z, moqnr, zxwy);
    }, 'complete': function () {} });
}, window[_[54800]] = function () {
  function z01y_() {
    return ((0x1 + Math[_[119]]()) * 0x10000 | 0x0)[_[274]](0x10)[_[505]](0x1);
  }return z01y_() + z01y_() + '-' + z01y_() + '-' + z01y_() + '-' + z01y_() + '+' + z01y_() + z01y_() + z01y_();
}, window['p$DB'] = function () {
  console[_[490]](_[54801]);var vrsw = _dlmqpn[_[51529]]();p$DE[_[16960]] = vrsw[_[54802]], p$DE[_[54755]] = vrsw[_[54802]], p$DE[_[16951]] = vrsw[_[54802]], p$DE[_[41344]] = vrsw[_[54803]];var plomq = { 'game_ver': p$DE[_[5407]] };p$DE[_[41346]] = this[_[54800]](), p$BDCE({ 'title': _[54804] }), _dlmqpn[_[371]](plomq, this['p$EBD'][_[74]](this));
}, window['p$EBD'] = function (wvuxy) {
  var ghcfde = wvuxy[_[54805]];sdkInitRes = wvuxy, console[_[490]](_[54806] + ghcfde + _[54807] + (ghcfde == 0x1) + _[54808] + wvuxy[_[54735]] + _[54809] + window[_[40818]][_[54742]]);if (!wvuxy[_[54735]] || window['p$ACEBD'](window[_[40818]][_[54742]], wvuxy[_[54735]]) < 0x0) console[_[490]](_[54810]), p$DE[_[54745]] = _[54811], p$DE[_[54747]] = _[54812], p$DE[_[54749]] = _[54813], p$DE[_[4570]] = _[54814], p$DE[_[40855]] = _[54815], p$DE[_[4573]] = wvuxy[_[4573]] || _[54816], p$DE[_[775]] = ![];else window['p$ACEBD'](window[_[40818]][_[54742]], wvuxy[_[54735]]) == 0x0 ? (console[_[490]](_[54817]), p$DE[_[54745]] = _[54746], p$DE[_[54747]] = _[54748], p$DE[_[54749]] = _[54750], p$DE[_[4570]] = _[54740], p$DE[_[40855]] = _[54815], p$DE[_[4573]] = _[54816], p$DE[_[775]] = !![]) : (console[_[490]](_[54818]), p$DE[_[54745]] = _[54746], p$DE[_[54747]] = _[54748], p$DE[_[54749]] = _[54750], p$DE[_[4570]] = _[54740], p$DE[_[40855]] = _[54815], p$DE[_[4573]] = _[54816], p$DE[_[775]] = ![]);p$DE[_[54753]] = config[_[47593]] ? config[_[47593]] : 0x0, this['p$CDBE'](), this['p$CDEB'](), window[_[54819]] = 0x5, p$BDCE({ 'title': _[54820] }), _dlmqpn[_[54637]](this['p$EDB'][_[74]](this));
}, window[_[54819]] = 0x5, window['p$EDB'] = function (egfhi, iklhj) {
  if (egfhi == 0x0 && iklhj && iklhj[_[54283]]) {
    p$DE[_[54821]] = iklhj[_[54283]], p$DE[_[41513]] = iklhj[_[41513]], p$DE[_[41507]] = iklhj[_[41507]], p$DE[_[41514]] = iklhj[_[41514]], p$DE[_[41506]] = iklhj[_[41506]];var urps = this;p$BDCE({ 'title': _[54822] }), sendApi(p$DE[_[54745]], _[54823], { 'platform': p$DE[_[54743]], 'partner_id': p$DE[_[16951]], 'token': iklhj[_[54283]], 'game_pkg': p$DE[_[41344]], 'deviceId': p$DE[_[41346]], 'scene': _[54824] + p$DE[_[54753]] }, this['p$CBDE'][_[74]](this), p$CED, p$EB);
  } else iklhj && iklhj[_[41632]] && window[_[54819]] > 0x0 && (iklhj[_[41632]][_[115]](_[54825]) != -0x1 || iklhj[_[41632]][_[115]](_[54826]) != -0x1 || iklhj[_[41632]][_[115]](_[54827]) != -0x1 || iklhj[_[41632]][_[115]](_[54828]) != -0x1 || iklhj[_[41632]][_[115]](_[54829]) != -0x1 || iklhj[_[41632]][_[115]](_[54830]) != -0x1) ? (window[_[54819]]--, _dlmqpn[_[54637]](this['p$EDB'][_[74]](this))) : (window[_[54781]](0x1, _[54831] + egfhi + _[54832] + (iklhj ? iklhj[_[41632]] : '')), window['p$DEB'](_[54833], JSON[_[4556]]({ 'status': egfhi, 'data': iklhj })), window['p$BCDE'](_[54834] + (iklhj && iklhj[_[41632]] ? '，' + iklhj[_[41632]] : '')));
}, window['p$CBDE'] = function (adbe) {
  if (!adbe) {
    window[_[54781]](0x2, _[54835]), window['p$DEB'](_[54836], _[54837]), window['p$BCDE'](_[54838]);return;
  }if (adbe[_[1327]] != _[12814]) {
    window[_[54781]](0x2, _[54839] + adbe[_[1327]]), window['p$DEB'](_[54836], JSON[_[4556]](adbe)), window['p$BCDE'](_[54840] + adbe[_[1327]]);return;
  }if (adbe[_[54841]] == 0x1) {
    window['p$BCDE'](_[54842]);return;
  }p$DE[_[16949]] = String(adbe[_[41342]]), p$DE[_[41342]] = String(adbe[_[41342]]), p$DE[_[41280]] = String(adbe[_[41280]]), p$DE[_[16960]] = String(adbe[_[41280]]), p$DE[_[41345]] = String(adbe[_[41345]]), p$DE[_[54843]] = String(adbe[_[15401]]), p$DE[_[54844]] = String(adbe[_[906]]), p$DE[_[15401]] = '';var y0$z_x = this;p$BDCE({ 'title': _[54845] });var qustrp = localStorage[_[488]](_[54846] + p$DE[_[41344]] + p$DE[_[41342]]);if (qustrp && qustrp != '') {
    var trupsq = Number(qustrp);y0$z_x[_[54847]](trupsq);
  } else y0$z_x[_[54848]]();
}, window[_[54848]] = function () {
  var tqvsur = this;sendApi(p$DE[_[54745]], _[54849], { 'partner_id': p$DE[_[16951]], 'uid': p$DE[_[41342]], 'version': p$DE[_[5407]], 'game_pkg': p$DE[_[41344]], 'device': p$DE[_[41346]] }, tqvsur['p$CBED'][_[74]](tqvsur), p$CED, p$EB);
}, window['p$CBED'] = function (gikhlj) {
  if (!gikhlj) {
    window[_[54781]](0x3, _[54850]), window['p$BCDE'](_[54850]);return;
  }if (gikhlj[_[1327]] != _[12814]) {
    window[_[54781]](0x3, _[54851] + gikhlj[_[1327]]), window['p$BCDE'](_[54851] + gikhlj[_[1327]]);return;
  }if (!gikhlj[_[11]] || gikhlj[_[11]][_[13]] == 0x0) {
    window[_[54781]](0x3, _[54852]), window['p$BCDE'](_[54853]);return;
  }this[_[54854]](gikhlj);
}, window[_[54847]] = function (imlknj) {
  var uxvwts = this;sendApi(p$DE[_[54745]], _[54855], { 'server_id': imlknj, 'time': Date[_[83]]() / 0x3e8 }, uxvwts[_[54856]][_[74]](uxvwts), p$CED, p$EB);
}, window[_[54856]] = function (opmrnq) {
  if (!opmrnq) {
    window[_[54781]](0x4, _[54857]), this[_[54848]]();return;
  }if (opmrnq[_[1327]] != _[12814]) {
    window[_[54781]](0x4, _[54858] + opmrnq[_[1327]]), this[_[54848]]();return;
  }if (!opmrnq[_[11]] || opmrnq[_[11]][_[13]] == 0x0) {
    window[_[54781]](0x4, _[54859]), this[_[54848]]();return;
  }this[_[54854]](opmrnq);
}, window[_[54854]] = function ($_z0yx) {
  p$DE[_[671]] = $_z0yx[_[54860]] != undefined ? $_z0yx[_[54860]] : 0x0, p$DE[_[41338]] = { 'server_id': String($_z0yx[_[11]][0x0][_[15431]]), 'server_name': String($_z0yx[_[11]][0x0][_[41343]]), 'entry_ip': $_z0yx[_[11]][0x0][_[41368]], 'entry_port': parseInt($_z0yx[_[11]][0x0][_[41369]]), 'status': p$DCB($_z0yx[_[11]][0x0]), 'start_time': $_z0yx[_[11]][0x0][_[54861]], 'maintain_time': $_z0yx[_[11]][0x0][_[54862]] ? $_z0yx[_[11]][0x0][_[54862]] : '', 'is_recommend': $_z0yx[_[11]][0x0][_[54863]], 'cdn': p$DE[_[4570]] }, this[_[54864]]();
}, window[_[54864]] = function () {
  window['p$DC'] = !![], window['p$EDCB']();
}, window['p$EDCB'] = function () {
  if (window['p$DC'] && window['p$EC']) {
    var xyz$0 = p$DE[_[54865]] != undefined ? p$DE[_[54865]] : 0x0,
        _0214 = p$DE[_[41506]] == undefined ? 0x0 : p$DE[_[41506]],
        $zy10 = xyz$0 == 0x1 && _0214 == 0x1 || xyz$0 == 0x2 && _0214 != 0x1 || xyz$0 == 0x3;console[_[78]](_[54866] + p$DE[_[671]] + _[54867] + $zy10 + _[54868] + p$DE[_[41506]] + _[54869] + p$DE[_[54865]]);if (!$zy10 && p$DE[_[671]] == 0x1) {
      var ihklmj = p$DE[_[41338]][_[106]];if (ihklmj === -0x1 || ihklmj === 0x0) {
        window[_[54781]](0xf, _[54870] + p$DE[_[41338]]['id'] + _[54871] + p$DE[_[41338]][_[106]]), window['p$BCDE'](ihklmj === -0x1 ? _[54872] : _[54873]);return;
      }p$EBCD(0x0, p$DE[_[41338]][_[15431]]), window[_[54772]][_[148]][_[54874]](p$DE[_[671]]);
    } else wx[_[54875]](window[_[54876]]), window[_[54772]][_[148]][_[54877]]({ 'show': sdkInitRes[_[54878]], 'skinUrl': sdkInitRes[_[54879]], 'content': sdkInitRes[_[54880]], 'x': sdkInitRes[_[54881]], 'y': sdkInitRes[_[54882]] }), p$BDEC();window[_[54883]](), window['p$ECDB'](), window['p$EDBC']();
  }
}, window['p$CDBE'] = function () {
  sendApi(p$DE[_[54745]], _[54884], { 'game_pkg': p$DE[_[41344]], 'version_name': p$DE[_[4573]] }, this[_[54885]][_[74]](this), p$CED, p$EB);
}, window[_[54885]] = function (ceadb) {
  if (!ceadb) {
    window[_[54781]](0x5, _[54886]), window['p$BCDE'](_[54886]);return;
  }if (ceadb[_[1327]] != _[12814]) {
    window[_[54781]](0x5, _[54887] + ceadb[_[1327]]), window['p$BCDE'](_[54887] + ceadb[_[1327]]);return;
  }if (!ceadb[_[11]] || !ceadb[_[11]][_[5407]]) {
    window[_[54781]](0x5, _[54888] + (ceadb[_[11]] && ceadb[_[11]][_[5407]])), window['p$BCDE'](_[54888] + (ceadb[_[11]] && ceadb[_[11]][_[5407]]));return;
  }ceadb[_[11]][_[54889]] && ceadb[_[11]][_[54889]][_[13]] > 0xa && (p$DE[_[54890]] = ceadb[_[11]][_[54889]], p$DE[_[4570]] = ceadb[_[11]][_[54889]]), ceadb[_[11]][_[5407]] && (p$DE[_[101]] = ceadb[_[11]][_[5407]]), console[_[78]](_[41509] + p$DE[_[101]] + _[54891] + p$DE[_[4573]]), window['p$DEC'] = !![], window['p$ECDB'](), window['p$EDBC']();
}, window[_[54892]], window['p$CDEB'] = function () {
  sendApi(p$DE[_[54745]], _[54893], { 'game_pkg': p$DE[_[41344]] }, this['p$CEBD'][_[74]](this), p$CED, p$EB);
}, window['p$CEBD'] = function (mqonlp) {
  if (mqonlp && mqonlp[_[1327]] === _[12814] && mqonlp[_[11]]) {
    window[_[54892]] = mqonlp[_[11]];for (var yzx$w_ in mqonlp[_[11]]) {
      p$DE[yzx$w_] = mqonlp[_[11]][yzx$w_];
    }
  } else window[_[54781]](0xb, _[54894]), console[_[78]](_[54895] + mqonlp[_[1327]]);window['p$CD'] = !![], window['p$EDCB']();
}, window[_[54896]] = function ($w_x, ljmnk, rpust, rvsqut, gheifd, acebfd, ehfdig, rstqup, efhgi, rutvws) {
  gheifd = String(gheifd);var zw$vy = ehfdig,
      lkhm = rstqup;p$DE[_[54741]][gheifd] = { 'productid': gheifd, 'productname': zw$vy, 'productdesc': lkhm, 'roleid': $w_x, 'rolename': ljmnk, 'rolelevel': rpust, 'price': acebfd, 'callback': efhgi }, sendApi(p$DE[_[54749]], _[54897], { 'game_pkg': p$DE[_[41344]], 'server_id': p$DE[_[41338]][_[15431]], 'server_name': p$DE[_[41338]][_[41343]], 'level': rpust, 'uid': p$DE[_[41342]], 'role_id': $w_x, 'role_name': ljmnk, 'product_id': gheifd, 'product_name': zw$vy, 'product_desc': lkhm, 'money': acebfd, 'partner_id': p$DE[_[16951]] }, toPayCallBack, p$CED, p$EB);
}, window[_[54898]] = function (chgfde) {
  if (chgfde && (chgfde[_[54899]] === 0xc8 || chgfde[_[1327]] == _[12814])) {
    var hfjkgi = p$DE[_[54741]][String(chgfde[_[54900]])];if (hfjkgi[_[337]]) hfjkgi[_[337]](chgfde[_[54900]], chgfde[_[54901]], -0x1);_dlmqpn[_[54673]]({ 'cpbill': chgfde[_[54901]], 'productid': chgfde[_[54900]], 'productname': hfjkgi[_[54902]], 'productdesc': hfjkgi[_[54903]], 'serverid': p$DE[_[41338]][_[15431]], 'servername': p$DE[_[41338]][_[41343]], 'roleid': hfjkgi[_[16955]], 'rolename': hfjkgi[_[16956]], 'rolelevel': hfjkgi[_[54904]], 'price': hfjkgi[_[44587]], 'extension': JSON[_[4556]]({ 'cp_order_id': chgfde[_[54901]] }) }, function (vtur, mljin) {
      hfjkgi[_[337]] && vtur == 0x0 && hfjkgi[_[337]](chgfde[_[54900]], chgfde[_[54901]], vtur);console[_[78]](JSON[_[4556]]({ 'type': _[54905], 'status': vtur, 'data': chgfde, 'role_name': hfjkgi[_[16956]] }));if (vtur === 0x0) {} else {
        if (vtur === 0x1) {} else {
          if (vtur === 0x2) {}
        }
      }
    });
  } else {
    var hiefd = chgfde ? _[54906] + chgfde[_[54899]] + _[54907] + chgfde[_[1327]] + _[54908] + chgfde[_[78]] : _[54909];window[_[54781]](0xd, _[54910] + hiefd), alert(hiefd);
  }
}, window['p$CEDB'] = function () {}, window['p$BCE'] = function (efgbd, suwvr, jhif, cbefd, jmlink) {
  _dlmqpn[_[54721]](p$DE[_[41338]][_[15431]], p$DE[_[41338]][_[41343]] || p$DE[_[41338]][_[15431]], efgbd, suwvr, jhif), sendApi(p$DE[_[54745]], _[54911], { 'game_pkg': p$DE[_[41344]], 'server_id': p$DE[_[41338]][_[15431]], 'role_id': efgbd, 'uid': p$DE[_[41342]], 'role_name': suwvr, 'role_type': cbefd, 'level': jhif });
}, window['p$BEC'] = function (hgkilj, sruptq, gchfe, _0zyx, uxwvyz, jkhfi, plomnk, onlqm, efcg, qotrps) {
  p$DE[_[54784]] = hgkilj, p$DE[_[4705]] = sruptq, p$DE[_[54785]] = gchfe, _dlmqpn[_[54722]](p$DE[_[41338]][_[15431]], p$DE[_[41338]][_[41343]] || p$DE[_[41338]][_[15431]], hgkilj, sruptq, gchfe), sendApi(p$DE[_[54745]], _[54912], { 'game_pkg': p$DE[_[41344]], 'server_id': p$DE[_[41338]][_[15431]], 'role_id': hgkilj, 'uid': p$DE[_[41342]], 'role_name': sruptq, 'role_type': _0zyx, 'level': gchfe, 'evolution': uxwvyz });
}, window['p$CBE'] = function (jnmok, khljig, vuzy, vwyxz$, $yx_0, surq, xytvw, fedhcg, vwzyu, _3$201) {
  p$DE[_[54784]] = jnmok, p$DE[_[4705]] = khljig, p$DE[_[54785]] = vuzy, _dlmqpn[_[54723]](p$DE[_[41338]][_[15431]], p$DE[_[41338]][_[41343]] || p$DE[_[41338]][_[15431]], jnmok, khljig, vuzy), sendApi(p$DE[_[54745]], _[54912], { 'game_pkg': p$DE[_[41344]], 'server_id': p$DE[_[41338]][_[15431]], 'role_id': jnmok, 'uid': p$DE[_[41342]], 'role_name': khljig, 'role_type': vwyxz$, 'level': vuzy, 'evolution': $yx_0 });
}, window['p$CEB'] = function ($y0z) {}, window['p$BC'] = function (knlo, jhilgk) {
  _dlmqpn[_[54651]](_[54651], { 'activity_id': jhilgk }, function ($310_2) {
    knlo && knlo($310_2);
  });
}, window[_[38059]] = function () {
  _dlmqpn[_[38059]]();
}, window[_[54913]] = function (npomkl) {
  _dlmqpn[_[37832]](npomkl);
}, window[_[54914]] = function (urtsvw, gljhk, ijkhgl, bcdafe, mkjinl, ihkjlm, lnmik, y$10_) {
  y$10_ = y$10_ || p$DE[_[41338]][_[15431]], sendApi(p$DE[_[54745]], _[54915], { 'phone': urtsvw, 'role_id': gljhk, 'uid': p$DE[_[41342]], 'game_pkg': p$DE[_[41344]], 'partner_id': p$DE[_[16951]], 'server_id': y$10_ }, lnmik, 0x2, null, function () {
    return !![];
  });
}, wx[_[54916]] = null, wx[_[54917]] = null, window[_[14486]] = function (z01$_) {
  wx[_[54917]] = z01$_, wx[_[54917]] && wx[_[54916]] && (console[_[78]](_[54918] + wx[_[54916]][_[831]]), wx[_[54917]](wx[_[54916]]), wx[_[54916]] = null);
}, wx[_[54919]] = null, window[_[14488]] = function (jkolm) {
  wx[_[54919]] = jkolm;
}, window['p$ECB'] = function (vsurtq, z_x$y0, srnoq, wrtv) {
  window[_[22]](_[54920], { 'game_pkg': window['p$DE'][_[41344]], 'role_id': z_x$y0, 'server_id': srnoq }, wrtv);
}, window['p$DBCE'] = function (prqtsu, jkhfig, jihgk) {
  function yxz$wv(nsrq) {
    var fdae = [],
        vzwu = [],
        $0zxy = jihgk || window[_[565]][_[54921]];for (var ebfgcd in $0zxy) {
      var kgl = Number(ebfgcd);(!prqtsu || !prqtsu[_[13]] || prqtsu[_[115]](kgl) != -0x1) && (vzwu[_[29]]($0zxy[ebfgcd]), fdae[_[29]]([kgl, 0x3]));
    }window['p$ACEBD'](window[_[54922]], _[54923]) >= 0x0 ? (console[_[490]](_[54924]), _dlmqpn[_[54718]](vzwu, function (svqrut) {
      console[_[490]](_[54925]), console[_[490]](svqrut);if (svqrut && svqrut[_[41632]] == _[54926]) for (var uvxzy in $0zxy) {
        if (svqrut[$0zxy[uvxzy]] == _[54927]) {
          var hkilgj = Number(uvxzy);for (var jknli = 0x0; jknli < fdae[_[13]]; jknli++) {
            if (fdae[jknli][0x0] == hkilgj) {
              fdae[jknli][0x1] = 0x1;break;
            }
          }
        }
      }window['p$ACEBD'](window[_[54922]], _[54928]) >= 0x0 ? wx[_[54929]]({ 'withSubscriptions': !![], 'success': function ($0z_) {
          var _$wyzx = $0z_[_[54930]][_[54931]];if (_$wyzx) {
            console[_[490]](_[54932]), console[_[490]](_$wyzx);for (var $_20z1 in $0zxy) {
              if (_$wyzx[$0zxy[$_20z1]] == _[54927]) {
                var $yzx_0 = Number($_20z1);for (var yt = 0x0; yt < fdae[_[13]]; yt++) {
                  if (fdae[yt][0x0] == $yzx_0) {
                    fdae[yt][0x1] = 0x2;break;
                  }
                }
              }
            }console[_[490]](fdae), jkhfig && jkhfig(fdae);
          } else console[_[490]](_[54933]), console[_[490]]($0z_), console[_[490]](fdae), jkhfig && jkhfig(fdae);
        }, 'fail': function () {
          console[_[490]](_[54934]), console[_[490]](fdae), jkhfig && jkhfig(fdae);
        } }) : (console[_[490]](_[54935] + window[_[54922]]), console[_[490]](fdae), jkhfig && jkhfig(fdae));
    })) : (console[_[490]](_[54936] + window[_[54922]]), console[_[490]](fdae), jkhfig && jkhfig(fdae)), wx[_[54937]](yxz$wv);
  }wx[_[54875]](yxz$wv);
}, window['p$DBEC'] = { 'isSuccess': ![], 'level': _[47606], 'isCharging': ![] }, window['p$DCBE'] = function (efgbc) {}, window[_[15997]] = function (kmoj) {
  wx[_[15997]]({ 'success': function (_xwy$) {
      kmoj && kmoj(!![], _xwy$);
    }, 'fail': function (dfhecg) {
      kmoj && kmoj(![], dfhecg);
    } });
}, window[_[15999]] = function (suwvtr) {
  if (suwvtr) wx[_[15999]](suwvtr);
}, window[_[40849]] = function (hfkgji) {
  wx[_[40849]](hfkgji);
}, window[_[22]] = function ($0_yxz, trspqo, qmlpno, bfdca, ijklmn, qporn, spor, jilgkh) {
  if (bfdca == undefined) bfdca = 0x1;wx[_[485]]({ 'url': $0_yxz, 'method': spor || _[41150], 'responseType': _[4464], 'data': trspqo, 'header': { 'content-type': jilgkh || _[54797] }, 'success': function (qtro) {
      DEBUG && console[_[490]](_[54938], $0_yxz, info, qtro);if (qtro && qtro[_[41728]] == 0xc8) {
        var rsqpn = qtro[_[11]];!qporn || qporn(rsqpn) ? qmlpno && qmlpno(rsqpn) : window[_[54939]]($0_yxz, trspqo, qmlpno, bfdca, ijklmn, qporn, qtro);
      } else window[_[54939]]($0_yxz, trspqo, qmlpno, bfdca, ijklmn, qporn, qtro);
    }, 'fail': function ($0_z12) {
      DEBUG && console[_[490]](_[54940], $0_yxz, info, $0_z12), window[_[54939]]($0_yxz, trspqo, qmlpno, bfdca, ijklmn, qporn, $0_z12);
    }, 'complete': function () {} });
}, window[_[54939]] = function (qmrop, urpsqt, vxtuwy, efhgd, kmlh, vuxzyw, ojmnlk) {
  efhgd - 0x1 > 0x0 ? setTimeout(function () {
    window[_[22]](qmrop, urpsqt, vxtuwy, efhgd - 0x1, kmlh, vuxzyw);
  }, 0x3e8) : kmlh && kmlh(JSON[_[4556]]({ 'url': qmrop, 'response': ojmnlk }));
}, window[_[54941]] = function (kjhfig, ljmnik, ilkjnm, jklih, tsrqpo, qomln, vytwux) {
  !ilkjnm && (ilkjnm = {});var tpqus = Math[_[118]](Date[_[83]]() / 0x3e8);ilkjnm[_[906]] = tpqus, ilkjnm[_[54942]] = ljmnik;var njlki = Object[_[265]](ilkjnm)[_[1134]](),
      vtqsur = '',
      $230 = '';for (var wvrstu = 0x0; wvrstu < njlki[_[13]]; wvrstu++) {
    vtqsur = vtqsur + (wvrstu == 0x0 ? '' : '&') + njlki[wvrstu] + ilkjnm[njlki[wvrstu]], $230 = $230 + (wvrstu == 0x0 ? '' : '&') + njlki[wvrstu] + '=' + encodeURIComponent(ilkjnm[njlki[wvrstu]]);
  }vtqsur = vtqsur + p$DE[_[54751]];var y0$_zx = _[54943] + md5(vtqsur);send(kjhfig + '?' + $230 + ($230 == '' ? '' : '&') + y0$_zx, null, jklih, tsrqpo, qomln, vytwux || function (jimnlk) {
    return jimnlk[_[1327]] == _[12814];
  }, null, _[54618]);
}, window['p$DCEB'] = function (yuwvzx, sqrpo) {
  var wzxv$y = 0x0;p$DE[_[41338]] && (wzxv$y = p$DE[_[41338]][_[15431]]), sendApi(p$DE[_[54747]], _[54944], { 'partnerId': p$DE[_[16951]], 'gamePkg': p$DE[_[41344]], 'logTime': Math[_[118]](Date[_[83]]() / 0x3e8), 'platformUid': p$DE[_[41345]], 'type': yuwvzx, 'serverId': wzxv$y }, null, 0x2, null, function () {
    return !![];
  });
}, window['p$DEBC'] = function (otpr) {
  sendApi(p$DE[_[54745]], _[54945], { 'partner_id': p$DE[_[16951]], 'uid': p$DE[_[41342]], 'version': p$DE[_[5407]], 'game_pkg': p$DE[_[41344]], 'device': p$DE[_[41346]] }, p$DECB, p$CED, p$EB);
}, window['p$DECB'] = function (ikjmnl) {
  if (ikjmnl && ikjmnl[_[1327]] === _[12814] && ikjmnl[_[11]]) {
    ikjmnl[_[11]][_[5598]]({ 'id': -0x2, 'name': _[54946] }), ikjmnl[_[11]][_[5598]]({ 'id': -0x1, 'name': _[54947] }), p$DE[_[54948]] = ikjmnl[_[11]];if (window[_[17234]]) window[_[17234]][_[54949]]();
  } else {
    p$DE[_[54950]] = ![];var zxyw = ikjmnl ? ikjmnl[_[1327]] : '';window[_[54781]](0x7, _[54951] + zxyw), window['p$BCDE'](_[54952] + zxyw);
  }
}, window['p$BCD'] = function (nlkjmo) {
  sendApi(p$DE[_[54745]], _[54953], { 'partner_id': p$DE[_[16951]], 'uid': p$DE[_[41342]], 'version': p$DE[_[5407]], 'game_pkg': p$DE[_[41344]], 'device': p$DE[_[41346]] }, p$BDC, p$CED, p$EB);
}, window['p$BDC'] = function (hgiej) {
  p$DE[_[54954]] = ![];if (hgiej && hgiej[_[1327]] === _[12814] && hgiej[_[11]]) {
    for (var yx0_z$ = 0x0; yx0_z$ < hgiej[_[11]][_[13]]; yx0_z$++) {
      hgiej[_[11]][yx0_z$][_[106]] = p$DCB(hgiej[_[11]][yx0_z$]);
    }p$DE[_[54754]][-0x1] = window[_[54955]](hgiej[_[11]]), window[_[17234]][_[54956]](-0x1);
  } else {
    var _$z0y1 = hgiej ? hgiej[_[1327]] : '';window[_[54781]](0x8, _[54957] + _$z0y1), window['p$BCDE'](_[54958] + _$z0y1);
  }
}, window[_[54959]] = function (lgjh) {
  sendApi(p$DE[_[54745]], _[54953], { 'partner_id': p$DE[_[16951]], 'uid': p$DE[_[41342]], 'version': p$DE[_[5407]], 'game_pkg': p$DE[_[41344]], 'device': p$DE[_[41346]] }, lgjh, p$CED, p$EB);
}, window['p$CBD'] = function (mnroq, gjkih) {
  sendApi(p$DE[_[54745]], _[54960], { 'partner_id': p$DE[_[16951]], 'uid': p$DE[_[41342]], 'version': p$DE[_[5407]], 'game_pkg': p$DE[_[41344]], 'device': p$DE[_[41346]], 'server_group_id': gjkih }, p$CDB, p$CED, p$EB);
}, window['p$CDB'] = function (bgfed) {
  p$DE[_[54954]] = ![];if (bgfed && bgfed[_[1327]] === _[12814] && bgfed[_[11]] && bgfed[_[11]][_[11]]) {
    var xvwyz$ = bgfed[_[11]][_[54961]],
        zw_$ = [];for (var _0zyx$ = 0x0; _0zyx$ < bgfed[_[11]][_[11]][_[13]]; _0zyx$++) {
      bgfed[_[11]][_[11]][_0zyx$][_[106]] = p$DCB(bgfed[_[11]][_[11]][_0zyx$]), (zw_$[_[13]] == 0x0 || bgfed[_[11]][_[11]][_0zyx$][_[106]] != 0x0) && (zw_$[zw_$[_[13]]] = bgfed[_[11]][_[11]][_0zyx$]);
    }p$DE[_[54754]][xvwyz$] = window[_[54955]](zw_$), window[_[17234]][_[54956]](xvwyz$);
  } else {
    var ploqnm = bgfed ? bgfed[_[1327]] : '';window[_[54781]](0x9, _[54962] + ploqnm), window['p$BCDE'](_[54963] + ploqnm);
  }
}, window['p$ACED'] = function ($zxywv) {
  sendApi(p$DE[_[54745]], _[54964], { 'partner_id': p$DE[_[16951]], 'uid': p$DE[_[41342]], 'version': p$DE[_[5407]], 'game_pkg': p$DE[_[41344]], 'device': p$DE[_[41346]] }, reqServerRecommendCallBack, p$CED, p$EB);
}, window[_[54965]] = function (imlkhj) {
  p$DE[_[54954]] = ![];if (imlkhj && imlkhj[_[1327]] === _[12814] && imlkhj[_[11]]) {
    for (var gcfhe = 0x0; gcfhe < imlkhj[_[11]][_[13]]; gcfhe++) {
      imlkhj[_[11]][gcfhe][_[106]] = p$DCB(imlkhj[_[11]][gcfhe]);
    }p$DE[_[54754]][-0x2] = window[_[54955]](imlkhj[_[11]]), window[_[17234]][_[54956]](-0x2);
  } else {
    var fdcgbe = imlkhj ? imlkhj[_[1327]] : '';window[_[54781]](0xa, _[54966] + fdcgbe), alert(_[54967] + fdcgbe);
  }
}, window[_[54955]] = function (hefgdc) {
  return hefgdc;
}, window['p$DBC'] = function ($xzvw, gfbcde) {
  $xzvw = $xzvw || p$DE[_[41338]][_[15431]], sendApi(p$DE[_[54745]], _[54968], { 'type': '4', 'game_pkg': p$DE[_[41344]], 'server_id': $xzvw }, gfbcde);
}, window[_[54969]] = function (jnkmi, uvtsqr, utpsr, txsvwu) {
  utpsr = utpsr || p$DE[_[41338]][_[15431]], sendApi(p$DE[_[54745]], _[54970], { 'type': jnkmi, 'game_pkg': uvtsqr, 'server_id': utpsr }, txsvwu);
}, window[_[54971]] = function (wzvyux, tvsuwr) {
  sendApi(p$DE[_[54745]], _[54972], { 'game_pkg': wzvyux }, tvsuwr);
}, window['p$DCB'] = function (zw$xyv) {
  if (zw$xyv) {
    if (zw$xyv[_[106]] == 0x1) {
      if (zw$xyv[_[54973]] == 0x3) return 0x3;else return zw$xyv[_[54973]] == 0x1 ? 0x2 : 0x1;
    } else return zw$xyv[_[106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['p$EBCD'] = function (tsvux, hefij) {
  p$DE[_[54974]] = { 'step': tsvux, 'server_id': hefij };var hdeig = this;p$BDCE({ 'title': _[54975] }), sendApi(p$DE[_[54745]], _[54976], { 'partner_id': p$DE[_[16951]], 'uid': p$DE[_[41342]], 'game_pkg': p$DE[_[41344]], 'server_id': hefij, 'platform': p$DE[_[41280]], 'platform_uid': p$DE[_[41345]], 'check_login_time': p$DE[_[54844]], 'check_login_sign': p$DE[_[54843]], 'version_name': p$DE[_[4573]] }, p$EBDC, p$CED, p$EB, function (oqsnr) {
    return oqsnr[_[1327]] == _[12814] || oqsnr[_[78]] == _[54977] || oqsnr[_[78]] == _[54978];
  });
}, window['p$EBDC'] = function (cgbd) {
  var vuyxwt = this;if (cgbd && cgbd[_[1327]] === _[12814] && cgbd[_[11]]) {
    var nomrp = p$DE[_[41338]];nomrp[_[54979]] = p$DE[_[54755]], nomrp[_[15401]] = String(cgbd[_[11]][_[54980]]), nomrp[_[41282]] = parseInt(cgbd[_[11]][_[906]]);if (cgbd[_[11]][_[41281]]) nomrp[_[41281]] = parseInt(cgbd[_[11]][_[41281]]);else nomrp[_[41281]] = parseInt(cgbd[_[11]][_[15431]]);nomrp[_[54981]] = 0x0, nomrp[_[4570]] = p$DE[_[54890]], nomrp[_[54982]] = cgbd[_[11]][_[54983]], nomrp[_[54984]] = cgbd[_[11]][_[54984]];if (cgbd[_[11]][_[41288]]) nomrp[_[41288]] = parseInt(cgbd[_[11]][_[41288]]);console[_[490]](_[54985] + JSON[_[4556]](nomrp[_[54984]])), p$DE[_[671]] == 0x1 && nomrp[_[54984]] && nomrp[_[54984]][_[54986]] == 0x1 && (p$DE[_[54987]] = 0x1, window[_[54772]][_[148]]['p$AED']()), p$ECBD();
  } else {
    if (p$DE[_[54974]][_[4487]] >= 0x3) {
      var ebcgf = cgbd ? cgbd[_[1327]] : '';window[_[54781]](0xc, _[54988] + ebcgf), p$EB(JSON[_[4556]](cgbd)), window['p$BCDE'](_[54989] + ebcgf);
    } else sendApi(p$DE[_[54745]], _[54823], { 'platform': p$DE[_[54743]], 'partner_id': p$DE[_[16951]], 'token': p$DE[_[54821]], 'game_pkg': p$DE[_[41344]], 'deviceId': p$DE[_[41346]], 'scene': _[54824] + p$DE[_[54753]] }, function (hglkj) {
      if (!hglkj || hglkj[_[1327]] != _[12814]) {
        window['p$BCDE'](_[54840] + hglkj && hglkj[_[1327]]);return;
      }p$DE[_[54843]] = String(hglkj[_[15401]]), p$DE[_[54844]] = String(hglkj[_[906]]), setTimeout(function () {
        p$EBCD(p$DE[_[54974]][_[4487]] + 0x1, p$DE[_[54974]][_[15431]]);
      }, 0x5dc);
    }, p$CED, p$EB, function (xutvy) {
      return xutvy[_[1327]] == _[12814] || xutvy[_[1327]] == _[41811];
    });
  }
}, window['p$ECBD'] = function () {
  ServerLoading[_[148]][_[54874]](p$DE[_[671]]), window['p$CE'] = !![], window['p$EDBC']();
}, window['p$ECDB'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[54761]] && window[_[54762]] && window['p$DEC'] && window['p$DC']) {
    if (window[_[54178]] && !window[_[54178]][_[148]]) {
      console[_[490]](_[54990] + window[_[54178]][_[148]]);var lihjm = wx[_[54991]](),
          pqosrt = lihjm[_[831]] ? lihjm[_[831]] : 0x0,
          moqrpn = { 'cdn': window['p$DE'][_[4570]], 'spareCdn': window['p$DE'][_[40855]], 'newRegister': window['p$DE'][_[671]], 'wxPC': window['p$DE'][_[40858]], 'wxIOS': window['p$DE'][_[1130]], 'wxAndroid': window['p$DE'][_[15196]], 'wxParam': { 'limitLoad': window['p$DE']['p$ABCED'], 'benchmarkLevel': window['p$DE']['p$ABDCE'], 'wxFrom': window[_[565]][_[47593]] == _[54992] ? 0x1 : 0x0, 'wxSDKVersion': window[_[54922]] }, 'configType': window['p$DE'][_[4572]], 'exposeType': window['p$DE'][_[753]], 'scene': pqosrt, 'video_type': window['p$DE'][_[41507]], 'ad_flag': window['p$DE'][_[41506]] };if (window[_[54892]]) for (var qsv in window[_[54892]]) {
        if (!moqrpn[qsv]) moqrpn[qsv] = window[_[54892]][qsv];
      }new window[_[54178]](moqrpn, window['p$DE'][_[101]], window['p$ABCDE']);
    }
  }
}, window['p$EDBC'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[54761]] && window[_[54762]] && window['p$DEC'] && window['p$DC'] && window['p$CE'] && window['p$CD']) {
    p$BDEC();if (!p$ECD) {
      p$ECD = !![];if (!window[_[54178]][_[148]]) window['p$ECDB']();var uqrtps = 0x0,
          $xzwy_ = wx[_[54993]]();$xzwy_ && (window['p$DE'][_[54994]] && (uqrtps = $xzwy_[_[325]]), console[_[78]](_[54995] + $xzwy_[_[325]] + _[54996] + $xzwy_[_[1348]] + _[54997] + $xzwy_[_[1350]] + _[54998] + $xzwy_[_[1349]] + _[54999] + $xzwy_[_[179]] + _[55000] + $xzwy_[_[180]]));var zywv$x = {};for (const vtsqru in p$DE[_[41338]]) {
        zywv$x[vtsqru] = p$DE[_[41338]][vtsqru];
      }var kmnijl = { 'channel': window['p$DE'][_[16960]], 'account': window['p$DE'][_[41342]], 'userId': window['p$DE'][_[16949]], 'cdn': window['p$DE'][_[4570]], 'data': window['p$DE'][_[11]], 'package': window['p$DE'][_[40856]], 'newRegister': window['p$DE'][_[671]], 'pkgName': window['p$DE'][_[41344]], 'partnerId': window['p$DE'][_[16951]], 'platform_uid': window['p$DE'][_[41345]], 'deviceId': window['p$DE'][_[41346]], 'selectedServer': zywv$x, 'configType': window['p$DE'][_[4572]], 'exposeType': window['p$DE'][_[753]], 'debugUsers': window['p$DE'][_[17165]], 'wxMenuTop': uqrtps, 'wxShield': window['p$DE'][_[775]], 'encryptParam': window['p$DE'][_[41515]], 'wx_channel': window['p$DE'][_[41513]], 'zsy_tp_state': window['p$DE'][_[41514]] };if (window[_[54892]]) for (var uzxy in window[_[54892]]) {
        kmnijl[uzxy] = window[_[54892]][uzxy];
      }window[_[54178]][_[148]]['p$EDA'](kmnijl);if (p$DE[_[41338]] && p$DE[_[41338]][_[15431]]) localStorage[_[493]](_[54846] + p$DE[_[41344]] + p$DE[_[41342]], p$DE[_[41338]][_[15431]]);
    }
  } else console[_[78]](_[55001] + window['p$EC'] + _[55002] + window['p$DCE'] + _[55003] + window[_[54761]] + _[55004] + window[_[54762]] + _[55005] + window['p$DEC'] + _[55006] + window['p$DC'] + _[55007] + window['p$CE'] + _[55008] + window['p$CD']);
}, window[_[54876]] = function () {}, window[_[55009]] = function (_0xzy$) {
  if (!window[_[16725]]) {
    console[_[125]](_[55010]);return;
  }var _12z0 = _0xzy$[_[348]];_12z0 == 0x1 ? window[_[16725]][_[65]](0x2327, _0xzy$) : window[_[16725]][_[81]](0x2327);
}, window[_[54883]] = function () {
  if (!window['p$DC'] || !window['p$CD']) return;var rqvsu = p$DE[_[671]] == 0x1,
      vwtuxy = p$DE[_[775]],
      hefig = p$DE[_[41168]] && p$DE[_[41168]] > 0x0;if (vwtuxy || rqvsu && hefig) {
    var _yx$ = p$DE[_[41169]],
        x0y = _yx$ && _yx$[_[13]] == 0x9;x0y && (window[_[45782]] = _yx$);var inlmjk = p$DE[_[41170]],
        fdh = inlmjk && inlmjk[_[15]]('#')[_[13]] == 0x4;fdh && (window[_[45783]] = inlmjk);
  }
}, window[_[54780]] = function () {
  window[_[45782]] = null, window[_[45783]] = null;
}, window[_[55011]] = function (pnmko) {
  _dlmqpn[_[55011]](pnmko);
};