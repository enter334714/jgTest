var _ = wx.y$;
var sdk_conf = {
    game_id: _[54730],
    game_pkg: _[54731],
    partner_label: _[54732],
    partner_id: _[54733],
    game_ver: _[54734],
    is_auth: false //授权登录
};

module.exports = sdk_conf;