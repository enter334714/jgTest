var _ = wx.y$;
console[_[78]](_[55243]), window[_[55244]], wx[_[55245]](function (w$_yz) {
  if (w$_yz) {
    if (w$_yz[_[4574]]) {
      var npmolq = window[_[565]][_[54735]][_[4275]](new RegExp(/\./, 'g'), '_'),
          nqmopr = w$_yz[_[4574]],
          wtruvs = nqmopr[_[16825]](/(bbbbbbbbb\/main.js:)[0-9]{1,60}(:)/g);if (wtruvs) for (var txwus = 0x0; txwus < wtruvs[_[13]]; txwus++) {
        if (wtruvs[txwus] && wtruvs[txwus][_[13]] > 0x0) {
          var ihjkf = parseInt(wtruvs[txwus][_[4275]](_[55246], '')[_[4275]](':', ''));nqmopr = nqmopr[_[4275]](wtruvs[txwus], wtruvs[txwus][_[4275]](':' + ihjkf + ':', ':' + (ihjkf - 0x2) + ':'));
        }
      }nqmopr = nqmopr[_[4275]](new RegExp(_[55247], 'g'), _[55248] + npmolq + _[41459]), nqmopr = nqmopr[_[4275]](new RegExp(_[55249], 'g'), _[55248] + npmolq + _[41459]), w$_yz[_[4574]] = nqmopr;
    }var cefgdb = { 'id': window['p$DE'][_[54784]], 'role': window['p$DE'][_[4705]], 'level': window['p$DE'][_[54785]], 'user': window['p$DE'][_[41342]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4570]], 'pkgName': window['p$DE'][_[41344]], 'gamever': window[_[565]][_[54735]], 'serverid': window['p$DE'][_[41338]] ? window['p$DE'][_[41338]][_[15431]] : 0x0, 'systemInfo': window[_[54786]], 'error': _[55250], 'stack': w$_yz ? w$_yz[_[4574]] : '' },
        mlhjki = JSON[_[4556]](cefgdb);console[_[125]](_[55251] + mlhjki), (!window[_[55244]] || window[_[55244]] != cefgdb[_[125]]) && (window[_[55244]] = cefgdb[_[125]], window['p$BD'](cefgdb));
  }
});import 'bbbmd5min.js';import 'bbbzlibs.js';window[_[55252]] = require(_[55253]);import 'bbbindex.js';import 'bbblibsmin.js';import 'bbbwxmini.js';import 'bbbinitmin.js';import 'recorder.js';import 'ServiceButton.js';console[_[78]](_[55254]), console[_[78]](_[55255]), p$BDCE({ 'title': _[55256] });var _d_y$xz0 = { 'p$ABEDC': !![] };new window[_[54772]](_d_y$xz0), window[_[54772]][_[148]]['p$ACDEB']();if (window['p$ABDEC']) clearInterval(window['p$ABDEC']);window['p$ABDEC'] = null, window['p$ACEBD'] = function (ihklmj, _01) {
  if (!ihklmj || !_01) return 0x0;ihklmj = ihklmj[_[15]]('.'), _01 = _01[_[15]]('.');const tuyvxw = Math[_[908]](ihklmj[_[13]], _01[_[13]]);while (ihklmj[_[13]] < tuyvxw) {
    ihklmj[_[29]]('0');
  }while (_01[_[13]] < tuyvxw) {
    _01[_[29]]('0');
  }for (var z_y$x = 0x0; z_y$x < tuyvxw; z_y$x++) {
    const kniljm = parseInt(ihklmj[z_y$x]),
          nqlm = parseInt(_01[z_y$x]);if (kniljm > nqlm) return 0x1;else {
      if (kniljm < nqlm) return -0x1;
    }
  }return 0x0;
}, window[_[54922]] = wx[_[55257]]()[_[54922]], console[_[490]](_[55258] + window[_[54922]]);var _dqnrs = wx[_[55259]]();_dqnrs[_[55260]](function (gije) {
  console[_[490]](_[55261] + gije[_[55262]]);
}), _dqnrs[_[55263]](function () {
  wx[_[54764]]({ 'title': _[55264], 'content': _[55265], 'showCancel': ![], 'success': function (stuwrv) {
      _dqnrs[_[55266]]();
    } });
}), _dqnrs[_[55267]](function () {
  console[_[490]](_[55268]);
}), window['p$ACEDB'] = function () {
  console[_[490]](_[55269]);var jfkg = wx[_[55270]]({ 'name': _[55271], 'success': function (prto) {
      console[_[490]](_[55272]), console[_[490]](prto), prto && prto[_[41632]] == _[55273] ? (window['p$EC'] = !![], window['p$ECDB'](), window['p$EDBC']()) : setTimeout(function () {
        window['p$ACEDB']();
      }, 0x1f4);
    }, 'fail': function (cbefgd) {
      console[_[490]](_[55274]), console[_[490]](cbefgd), setTimeout(function () {
        window['p$ACEDB']();
      }, 0x1f4);
    } });jfkg && jfkg[_[55275]](pomn => {});
}, window['p$ADBEC'] = function () {
  console[_[490]](_[55276]);var decba = wx[_[55270]]({ 'name': _[55277], 'success': function (bceafd) {
      console[_[490]](_[55278]), console[_[490]](bceafd), bceafd && bceafd[_[41632]] == _[55273] ? (window['p$DCE'] = !![], window['p$ECDB'](), window['p$EDBC']()) : setTimeout(function () {
        window['p$ADBEC']();
      }, 0x1f4);
    }, 'fail': function (lomjnk) {
      console[_[490]](_[55279]), console[_[490]](lomjnk), setTimeout(function () {
        window['p$ADBEC']();
      }, 0x1f4);
    } });decba && decba[_[55275]](rvw => {});
};window['p$ACEBD'](window[_[54922]], _[55280]) >= 0x0 ? (console[_[490]](_[55281] + window[_[54922]] + _[55282]), window['p$DB'](), window['p$ACEDB'](), window['p$ADBEC']()) : (window['p$DEB'](_[55283], window[_[54922]]), wx[_[54764]]({ 'title': _[6478], 'content': _[55284] }));window[_[54786]] = '', wx[_[55285]]({ 'success'(jgfe) {
    window[_[54786]] = _[55286] + jgfe[_[55287]] + _[55288] + jgfe[_[55289]] + _[55290] + jgfe[_[5407]] + _[55291] + jgfe[_[483]] + _[55292] + jgfe[_[41280]] + _[55293] + jgfe[_[54922]] + _[55294] + jgfe[_[12167]], console[_[490]](window[_[54786]]), console[_[490]](_[55295] + jgfe[_[47482]] + _[55296] + jgfe[_[55297]] + _[55298] + jgfe[_[55299]] + _[55300] + jgfe[_[55301]] + _[55302] + jgfe[_[55303]] + _[55304] + jgfe[_[55305]] + _[55306] + (jgfe[_[55307]] ? jgfe[_[55307]][_[325]] + ',' + jgfe[_[55307]][_[1348]] + ',' + jgfe[_[55307]][_[1350]] + ',' + jgfe[_[55307]][_[1349]] : ''));var olmqp = jgfe[_[483]] ? jgfe[_[483]][_[17322]]() : '',
        vw$xy = jgfe[_[55289]] ? jgfe[_[55289]][_[17322]]()[_[4275]]('\x20', '') : '';window['p$DE'][_[1130]] = olmqp[_[115]](_[55308]) != -0x1, window['p$DE'][_[15196]] = olmqp[_[115]](_[54679]) != -0x1, window['p$DE'][_[54994]] = olmqp[_[115]](_[55308]) != -0x1 || olmqp[_[115]](_[54679]) != -0x1, window['p$DE'][_[40858]] = olmqp[_[115]](_[55309]) != -0x1 || olmqp[_[115]](_[24461]) != -0x1, window['p$DE'][_[54794]] = jgfe[_[41280]] ? jgfe[_[41280]][_[17322]]() : '', window['p$DE']['p$ABCED'] = ![], window['p$DE']['p$ABDCE'] = 0x2;if (olmqp[_[115]](_[54679]) != -0x1) {
      if (jgfe[_[12167]] >= 0x18) window['p$DE']['p$ABDCE'] = 0x3;else window['p$DE']['p$ABDCE'] = 0x2;
    } else {
      if (olmqp[_[115]](_[55308]) != -0x1) {
        if (jgfe[_[12167]] && jgfe[_[12167]] >= 0x14) window['p$DE']['p$ABDCE'] = 0x3;else {
          if (vw$xy[_[115]](_[55310]) != -0x1 || vw$xy[_[115]](_[55311]) != -0x1 || vw$xy[_[115]](_[55312]) != -0x1 || vw$xy[_[115]](_[55313]) != -0x1 || vw$xy[_[115]](_[55314]) != -0x1) window['p$DE']['p$ABDCE'] = 0x2;else window['p$DE']['p$ABDCE'] = 0x3;
        }
      } else window['p$DE']['p$ABDCE'] = 0x2;
    }console[_[490]](_[55315] + window['p$DE']['p$ABCED'] + _[55316] + window['p$DE']['p$ABDCE']);
  } }), wx[_[15997]]({ 'success': function (fhdgc) {
    console[_[490]](_[55317] + fhdgc[_[19164]]);
  } }), wx[_[55318]]({ 'keepScreenOn': !![] }), wx[_[15999]](function ($_zyx0) {
  console[_[490]](_[55317] + $_zyx0[_[19164]] + _[55319] + $_zyx0[_[55320]]);
}), wx[_[14486]](function (gjhfki) {
  wx[_[54916]] = gjhfki, wx[_[54917]] && wx[_[54916]] && (console[_[78]](_[54918] + wx[_[54916]][_[831]]), wx[_[54917]](wx[_[54916]]), wx[_[54916]] = null);
}), wx[_[24750]](function () {
  console[_[78]](_[55321]), wx[_[54919]] && wx[_[54919]]();
}), window[_[55322]] = 0x0, window['p$ADCEB'] = 0x0, window[_[55323]] = null, wx[_[55324]](function () {
  window['p$ADCEB']++;var monprq = Date[_[83]]();(window[_[55322]] == 0x0 || monprq - window[_[55322]] > 0x1d4c0) && (console[_[96]](_[55325]), wx[_[16620]]());if (window['p$ADCEB'] >= 0x2) {
    window['p$ADCEB'] = 0x0, console[_[125]](_[55326]), wx[_[55327]]('0', 0x1);if (window['p$DE'] && window['p$DE'][_[1130]]) window['p$DEB'](_[55328], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});