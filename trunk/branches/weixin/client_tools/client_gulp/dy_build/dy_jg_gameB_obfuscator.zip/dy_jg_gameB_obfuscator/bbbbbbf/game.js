var _ = wx.y$;
require('bbbbBuff.js'), window[_[54297]][_[44493]][_[54182]] = null, window['client_pb'] = require('bbbcleintpb.js'), window[_[41518]] = window[_[54297]][_[41379]][_[41380]](client_pb);