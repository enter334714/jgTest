﻿var sdk_conf = {
    game_id: '256',
    game_pkg: 'tjqy_tjqyyhqydyxyx_AKN',
    partner_label: 'douyinxyx',
    partner_id: '502',
    game_ver: '2.0.15',
    is_auth: false, //授权登录
};

module.exports = sdk_conf;