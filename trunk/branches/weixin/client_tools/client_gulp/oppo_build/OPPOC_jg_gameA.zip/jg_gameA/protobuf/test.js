
(function(a,b,c,d,e){
	// var __un=Laya.un,__uns=Laya.uns,__static=Laya.static,__class=Laya.class,__getset=Laya.getset,__newvec=Laya.__newvec;

	// var Browser=laya.utils.Browser,Config=Laya.Config,Event=laya.events.Event,EventDispatcher=laya.events.EventDispatcher;
	// var HTMLImage=laya.resource.HTMLImage,Handler=laya.utils.Handler,Input=laya.display.Input,Loader=laya.net.Loader;
	// var LocalStorage=laya.net.LocalStorage,Matrix=laya.maths.Matrix,Render=laya.renders.Render,RunDriver=laya.utils.RunDriver;
	// var SoundChannel=laya.media.SoundChannel,SoundManager=laya.media.SoundManager,URL=laya.net.URL,Utils=laya.utils.Utils;
    console.log("testgame 12345678:",a,b,c,d,e)


})([1,2,3,4,5]);


console.log("testgame 012:")
// if (typeof define === 'function' && define.amd){
// 	define('laya.core', ['require', "exports"], function(require, exports) {
//         'use strict';
//         Object.defineProperty(exports, '__esModule', { value: true });
//         for (var i in Laya) {
// 			var o = Laya[i];
//             o && o.__isclass && (exports[i] = o);
//         }
//     });
// }