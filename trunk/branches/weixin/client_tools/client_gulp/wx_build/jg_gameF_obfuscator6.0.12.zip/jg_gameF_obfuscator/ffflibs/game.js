var k = wx.$f;
require(k[86913]);