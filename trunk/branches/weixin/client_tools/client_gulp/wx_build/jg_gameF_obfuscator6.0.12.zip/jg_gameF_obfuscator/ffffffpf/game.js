var k = wx.$f;
require('ffffBuff.js'), window[k[86245]][k[86235]][k[86127]] = null, window['client_pb'] = require('fffcleintpb.js'), window[k[83138]] = window[k[86245]][k[83040]][k[83041]](client_pb);