var k = wx.$f;
import fb1ugv9 from '../ffffsdk/fffsdk.js';window[k[86527]] = { 'wxVersion': window[k[60530]][k[86428]] }, window[k[86528]] = ![], window['F$6L'] = 0x1, window[k[86529]] = 0x1, window['F$8L6'] = !![], window[k[86530]] = !![], window['F$I086L'] = '', window['F$L6'] = { 'base_cdn': k[86531], 'cdn': k[86531] }, F$L6[k[86532]] = {}, F$L6[k[82706]] = '0', F$L6[k[64231]] = window[k[86527]][k[86533]], F$L6[k[86500]] = '', F$L6['os'] = '1', F$L6[k[86534]] = k[86535], F$L6[k[86536]] = k[86537], F$L6[k[86538]] = k[86539], F$L6[k[86540]] = k[86541], F$L6[k[86542]] = k[86543], F$L6[k[81783]] = '1', F$L6[k[83012]] = '', F$L6[k[83014]] = '', F$L6[k[86544]] = 0x0, F$L6[k[86545]] = {}, F$L6[k[86546]] = parseInt(F$L6[k[81783]]), F$L6[k[83010]] = F$L6[k[81783]], F$L6[k[83006]] = {}, F$L6['F$0L'] = k[86547], F$L6[k[86548]] = ![], F$L6[k[70838]] = k[86549], F$L6[k[82984]] = Date[k[60082]](), F$L6[k[70455]] = k[86550], F$L6[k[60679]] = '_a', F$L6[k[86551]] = 0x2, F$L6[k[60100]] = 0x7c1, F$L6[k[86533]] = window[k[86527]][k[86533]], F$L6[k[60704]] = ![], F$L6[k[60486]] = ![], F$L6[k[70128]] = ![], F$L6[k[82708]] = ![], window['F$86L'] = 0x5, window['F$86'] = ![], window['F$68'] = ![], window['F$L86'] = ![], window[k[86552]] = ![], window[k[86553]] = ![], window['F$L68'] = ![], window['F$8L'] = ![], window['F$L8'] = ![], window['F$68L'] = ![], window[k[63725]] = function (sdc6) {
  console[k[60457]](k[63725], sdc6), wx[k[64485]]({}), wx[k[86451]]({ 'title': k[65793], 'content': sdc6, 'success'(odjswc) {
      if (odjswc[k[86318]]) console[k[60457]](k[86554]);else odjswc[k[60526]] && console[k[60457]](k[86301]);
    } });
}, window['F$08L6'] = function (jxns) {
  console[k[60457]](k[86555], jxns), F$0L68(), wx[k[86451]]({ 'title': k[65793], 'content': jxns, 'confirmText': k[86556], 'cancelText': k[76840], 'success'(owsjc) {
      if (owsjc[k[86318]]) window['F$L0']();else owsjc[k[60526]] && (console[k[60457]](k[86557]), wx[k[83155]]({}));
    } });
}, window['F$6IL'] = function (zr783$) {
  console[k[60457]](k[86558], zr783$), wx[k[86451]]({ 'title': k[65793], 'content': zr783$, 'confirmText': k[83130], 'showCancel': ![], 'complete'(r7$e) {
      console[k[60457]](k[86557]), wx[k[83155]]({});
    } });
}, window['F$086L'] = ![], window['F$0L86'] = function (g91ubv) {
  window['F$086L'] = !![], wx[k[64484]](g91ubv);
}, window['F$0L68'] = function () {
  window['F$086L'] && (window['F$086L'] = ![], wx[k[64485]]({}));
}, window['F$068L'] = function (c_624o) {
  window[k[86443]][k[60144]]['F$068L'](c_624o);
}, window[k[70756]] = function (thfmq, bv) {
  fb1ugv9[k[70756]](thfmq, function (fqmth0) {
    fqmth0 && fqmth0[k[60011]] ? fqmth0[k[60011]][k[63662]] == 0x1 ? bv(!![]) : (bv(![]), console[k[60077]](k[86559] + fqmth0[k[60011]][k[86560]])) : console[k[60457]](k[70756], fqmth0);
  });
}, window['F$06L8'] = function (iu9v) {
  console[k[60457]](k[86561], iu9v);
}, window['F$0L6'] = function (ug9) {}, window['F$06L'] = function (vbifum, uivmb1, jcwd) {}, window['F$06'] = function (r8enxz) {
  console[k[60457]](k[86562], r8enxz), window[k[86443]][k[60144]][k[86563]](), window[k[86443]][k[60144]][k[86564]](), window[k[86443]][k[60144]][k[86565]]();
}, window['F$60'] = function ($a7yr3) {
  window['F$08L6'](k[86566]);var x7erz8 = { 'id': window['F$L6'][k[86433]], 'role': window['F$L6'][k[64161]], 'level': window['F$L6'][k[86434]], 'account': window['F$L6'][k[83011]], 'version': window['F$L6'][k[60100]], 'cdn': window['F$L6'][k[64053]], 'pkgName': window['F$L6'][k[83012]], 'gamever': window[k[60530]][k[86428]], 'serverid': window['F$L6'][k[83006]] ? window['F$L6'][k[83006]][k[70285]] : 0x0, 'systemInfo': window[k[86435]], 'error': k[86567], 'stack': $a7yr3 ? $a7yr3 : k[86566] },
      $z3r78 = JSON[k[64039]](x7erz8);console[k[60124]](k[86568] + $z3r78), window['F$0L']($z3r78);
}, window['F$L06'] = function (vgu1) {
  var k_5q4 = JSON[k[60502]](vgu1);k_5q4[k[86569]] = window[k[60530]][k[86428]], k_5q4[k[86570]] = window['F$L6'][k[83006]] ? window['F$L6'][k[83006]][k[70285]] : 0x0, k_5q4[k[86435]] = window[k[86435]];var y3a$r = JSON[k[64039]](k_5q4);console[k[60124]](k[86571] + y3a$r), window['F$0L'](y3a$r);
}, window['F$L60'] = function (djwso, cnjdsw) {
  var swdjo = { 'id': window['F$L6'][k[86433]], 'role': window['F$L6'][k[64161]], 'level': window['F$L6'][k[86434]], 'account': window['F$L6'][k[83011]], 'version': window['F$L6'][k[60100]], 'cdn': window['F$L6'][k[64053]], 'pkgName': window['F$L6'][k[83012]], 'gamever': window[k[60530]][k[86428]], 'serverid': window['F$L6'][k[83006]] ? window['F$L6'][k[83006]][k[70285]] : 0x0, 'systemInfo': window[k[86435]], 'error': djwso, 'stack': cnjdsw },
      jcdo62 = JSON[k[64039]](swdjo);console[k[60095]](k[86572] + jcdo62), window['F$0L'](jcdo62);
}, window['F$0L'] = function (q5htf0) {
  if (window['F$L6'][k[86501]] == k[86573]) return;var a7yp3$ = F$L6['F$0L'] + k[86574] + F$L6[k[83011]];wx[k[60452]]({ 'url': a7yp3$, 'method': k[86280], 'data': q5htf0, 'header': { 'content-type': k[86575], 'cache-control': k[86576] }, 'success': function (pay3$) {
      DEBUG && console[k[60457]](k[86577], a7yp3$, q5htf0, pay3$);
    }, 'fail': function (kh_q) {
      DEBUG && console[k[60457]](k[86577], a7yp3$, q5htf0, kh_q);
    }, 'complete': function () {} });
}, window[k[86578]] = function () {
  function hfmqt0() {
    return ((0x1 + Math[k[60118]]()) * 0x10000 | 0x0)[k[60265]](0x10)[k[60474]](0x1);
  }return hfmqt0() + hfmqt0() + '-' + hfmqt0() + '-' + hfmqt0() + '-' + hfmqt0() + '+' + hfmqt0() + hfmqt0() + hfmqt0();
}, window['F$L0'] = function () {
  console[k[60457]](k[86579]);var wze8nx = fb1ugv9[k[86580]]();F$L6[k[83010]] = wze8nx[k[86581]], F$L6[k[86546]] = wze8nx[k[86581]], F$L6[k[81783]] = wze8nx[k[86581]], F$L6[k[83012]] = wze8nx[k[86582]];var f0hmti = { 'game_ver': F$L6[k[64231]] };F$L6[k[83014]] = this[k[86578]](), F$0L86({ 'title': k[86583] }), fb1ugv9[k[60356]](f0hmti, this['F$60L'][k[60073]](this));
};var wx_develop = ![];window['F$60L'] = function (rzn8ex) {
  var zex7r = rzn8ex[k[86584]];wx_develop = zex7r == 0x1, console[k[60457]](k[86585] + zex7r + k[86586] + (zex7r == 0x1) + k[86587] + rzn8ex[k[86428]] + k[86588] + window[k[86527]][k[86533]]);if (!rzn8ex[k[86428]] || window['F$I86L0'](window[k[86527]][k[86533]], rzn8ex[k[86428]]) < 0x0) console[k[60457]](k[86589]), F$L6[k[86536]] = k[86590], F$L6[k[86538]] = k[86591], F$L6[k[86540]] = k[86592], F$L6[k[64053]] = k[86593], F$L6[k[82705]] = k[86594], F$L6[k[86595]] = k[86596], F$L6[k[60704]] = ![];else window['F$I86L0'](window[k[86527]][k[86533]], rzn8ex[k[86428]]) == 0x0 ? (console[k[60457]](k[86597]), F$L6[k[86536]] = k[86537], F$L6[k[86538]] = k[86539], F$L6[k[86540]] = k[86541], F$L6[k[64053]] = k[86598], F$L6[k[82705]] = k[86594], F$L6[k[86595]] = k[86599], F$L6[k[60704]] = !![]) : (console[k[60457]](k[86600]), F$L6[k[86536]] = k[86537], F$L6[k[86538]] = k[86539], F$L6[k[86540]] = k[86541], F$L6[k[64053]] = k[86598], F$L6[k[82705]] = k[86594], F$L6[k[86595]] = k[86599], F$L6[k[60704]] = ![]);F$L6[k[86544]] = config[k[86140]] ? config[k[86140]] : 0x0, this['F$8L06'](), this['F$8L60'](), window[k[86601]] = 0x5, F$0L86({ 'title': k[86602] }), fb1ugv9[k[86343]](this['F$6L0'][k[60073]](this));
}, window[k[86601]] = 0x5, window['F$6L0'] = function (vi9bu1, x8r7ez) {
  if (vi9bu1 == 0x0 && x8r7ez && x8r7ez[k[86229]]) {
    F$L6[k[86603]] = x8r7ez[k[86229]];var r$3a7 = this;F$0L86({ 'title': k[86604] }), sendApi(F$L6[k[86536]], k[86605], { 'platform': F$L6[k[86534]], 'partner_id': F$L6[k[81783]], 'token': x8r7ez[k[86229]], 'game_pkg': F$L6[k[83012]], 'deviceId': F$L6[k[83014]], 'scene': k[86606] + F$L6[k[86544]] }, this['F$80L6'][k[60073]](this), F$86L, F$60);
  } else x8r7ez && x8r7ez[k[83178]] && window[k[86601]] > 0x0 && (x8r7ez[k[83178]][k[60114]](k[86607]) != -0x1 || x8r7ez[k[83178]][k[60114]](k[86608]) != -0x1 || x8r7ez[k[83178]][k[60114]](k[86609]) != -0x1 || x8r7ez[k[83178]][k[60114]](k[86610]) != -0x1 || x8r7ez[k[83178]][k[60114]](k[86611]) != -0x1 || x8r7ez[k[83178]][k[60114]](k[86612]) != -0x1) ? (window[k[86601]]--, fb1ugv9[k[86343]](this['F$6L0'][k[60073]](this))) : (window['F$L60'](k[86613], JSON[k[64039]]({ 'status': vi9bu1, 'data': x8r7ez })), window['F$08L6'](k[86614] + (x8r7ez && x8r7ez[k[83178]] ? '，' + x8r7ez[k[83178]] : '')));
}, window['F$80L6'] = function (t05hqk) {
  if (!t05hqk) {
    window['F$08L6'](k[86615]);return;
  }if (t05hqk[k[63662]] != k[68940]) {
    window['F$08L6'](k[86616] + t05hqk[k[63662]]);return;
  }F$L6[k[81782]] = String(t05hqk[k[83011]]), F$L6[k[83011]] = String(t05hqk[k[83011]]), F$L6[k[82982]] = String(t05hqk[k[82982]]), F$L6[k[83010]] = String(t05hqk[k[82982]]), F$L6[k[83013]] = String(t05hqk[k[83013]]), F$L6[k[86617]] = String(t05hqk[k[70271]]), F$L6[k[86618]] = String(t05hqk[k[60811]]), F$L6[k[70271]] = '';var hmtibf = this;F$0L86({ 'title': k[86619] }), sendApi(F$L6[k[86536]], k[86620], { 'partner_id': F$L6[k[81783]], 'uid': F$L6[k[83011]], 'version': F$L6[k[64231]], 'game_pkg': F$L6[k[83012]], 'device': F$L6[k[83014]] }, hmtibf['F$806L'][k[60073]](hmtibf), F$86L, F$60);
}, window['F$806L'] = function (iuv19b) {
  if (!iuv19b) {
    window['F$08L6'](k[86621]);return;
  }if (iuv19b[k[63662]] != k[68940]) {
    window['F$08L6'](k[86622] + iuv19b[k[63662]]);return;
  }if (!iuv19b[k[60011]] || iuv19b[k[60011]][k[60013]] == 0x0) {
    window['F$08L6'](k[86623]);return;
  }F$L6[k[60599]] = iuv19b[k[86624]], F$L6[k[83006]] = { 'server_id': String(iuv19b[k[60011]][0x0][k[70285]]), 'server_name': String(iuv19b[k[60011]][0x0][k[86625]]), 'entry_ip': iuv19b[k[60011]][0x0][k[83034]], 'entry_port': parseInt(iuv19b[k[60011]][0x0][k[83035]]), 'status': F$608L(iuv19b[k[60011]][0x0]), 'start_time': iuv19b[k[60011]][0x0][k[86626]], 'cdn': F$L6[k[64053]] }, this['F$I08L6']();
}, window['F$I08L6'] = function () {
  if (F$L6[k[60599]] == 0x1) {
    var hifmbt = F$L6[k[83006]][k[60105]];if (hifmbt === -0x1 || hifmbt === 0x0) {
      window['F$08L6'](hifmbt === -0x1 ? k[86627] : k[86628]);return;
    }F$60L8(0x0, F$L6[k[83006]][k[70285]]), window[k[86443]][k[60144]][k[86629]](F$L6[k[60599]]);
  } else window[k[86443]][k[60144]][k[86630]](), F$0L68();window['F$L8'] = !![], window['F$6L08'](), window['F$6L80']();
}, window['F$8L06'] = function () {
  var i1u9b = this;sendApi(F$L6[k[86536]], k[86631], { 'game_pkg': F$L6[k[83012]], 'version_name': F$L6[k[86595]] }, function (nrz8) {
    if (!nrz8) {
      window['F$08L6'](k[86632]);return;
    }if (nrz8[k[63662]] != k[68940]) {
      window['F$08L6'](k[86633] + nrz8[k[63662]]);return;
    }if (!nrz8[k[60011]] || !nrz8[k[60011]][k[64231]]) {
      window['F$08L6'](k[86634] + (nrz8[k[60011]] && nrz8[k[60011]][k[64231]]));return;
    }nrz8[k[60011]][k[86635]] && nrz8[k[60011]][k[86635]][k[60013]] > 0xa && (F$L6[k[86636]] = nrz8[k[60011]][k[86635]], F$L6[k[64053]] = nrz8[k[60011]][k[86635]]), nrz8[k[60011]][k[64231]] && (F$L6[k[60100]] = nrz8[k[60011]][k[64231]]), console[k[60077]](k[83134] + F$L6[k[60100]] + k[86637] + F$L6[k[86595]]), window['F$L68'] = !![], window['F$6L08'](), window['F$6L80']();
  });
}, window[k[86638]], window['F$8L60'] = function () {
  sendApi(F$L6[k[86536]], k[86639], { 'game_pkg': F$L6[k[83012]] }, F$860L);
}, window['F$860L'] = function (oc64_) {
  if (oc64_[k[63662]] === k[68940] && oc64_[k[60011]]) {
    window[k[86638]] = oc64_[k[60011]];for (var ndwc in oc64_[k[60011]]) {
      F$L6[ndwc] = oc64_[k[60011]][ndwc];
    }
  } else console[k[60077]](k[86640] + oc64_[k[63662]]);window['F$8L'] = !![], window['F$6L80']();
}, window[k[86641]] = function (a3p7$y, xew, yr$837, jc6dso, t0qf5, enx8zw, tfibvm, fibmht, uv9bg1) {
  t0qf5 = String(t0qf5);var co26j4 = tfibvm,
      if0tmh = fibmht;F$L6[k[86532]][t0qf5] = { 'productid': t0qf5, 'productname': co26j4, 'productdesc': if0tmh, 'roleid': a3p7$y, 'rolename': xew, 'rolelevel': yr$837, 'price': enx8zw, 'callback': uv9bg1 }, sendApi(F$L6[k[86540]], k[86642], { 'game_pkg': F$L6[k[83012]], 'server_id': F$L6[k[83006]][k[70285]], 'server_name': F$L6[k[83006]][k[86625]], 'level': yr$837, 'uid': F$L6[k[83011]], 'role_id': a3p7$y, 'role_name': xew, 'product_id': t0qf5, 'product_name': co26j4, 'product_desc': if0tmh, 'money': enx8zw, 'partner_id': F$L6[k[81783]] }, toPayCallBack, F$86L, F$60);
}, window[k[86643]] = function (tvimf) {
  if (tvimf) {
    if (tvimf[k[86644]] === 0xc8 || tvimf[k[63662]] == k[68940]) {
      var hqtk = F$L6[k[86532]][String(tvimf[k[86645]])];if (hqtk[k[60325]]) hqtk[k[60325]](tvimf[k[86645]], tvimf[k[86646]], -0x1);fb1ugv9[k[86384]]({ 'cpbill': tvimf[k[86646]], 'productid': tvimf[k[86645]], 'productname': hqtk[k[86647]], 'productdesc': hqtk[k[86648]], 'serverid': F$L6[k[83006]][k[70285]], 'servername': F$L6[k[83006]][k[86625]], 'roleid': hqtk[k[86649]], 'rolename': hqtk[k[86650]], 'rolelevel': hqtk[k[86651]], 'price': hqtk[k[84474]], 'extension': JSON[k[64039]]({ 'cp_order_id': tvimf[k[86646]] }) }, function (mbivu1, pa7$3y) {
        hqtk[k[60325]] && mbivu1 == 0x0 && hqtk[k[60325]](tvimf[k[86645]], tvimf[k[86646]], mbivu1);console[k[60077]](JSON[k[64039]]({ 'type': k[86652], 'status': mbivu1, 'data': tvimf, 'role_name': hqtk[k[86650]] }));if (mbivu1 === 0x0) {} else {
          if (mbivu1 === 0x1) {} else {
            if (mbivu1 === 0x2) {}
          }
        }
      });
    } else alert(tvimf[k[60077]]);
  }
}, window['F$86L0'] = function () {}, window['F$086'] = function (rnx8ze, _42kq5, pa3y7$, mfqht0, r8$73y) {
  fb1ugv9[k[86417]](F$L6[k[83006]][k[70285]], F$L6[k[83006]][k[86625]] || F$L6[k[83006]][k[70285]], rnx8ze, _42kq5, pa3y7$), sendApi(F$L6[k[86536]], k[86653], { 'game_pkg': F$L6[k[83012]], 'server_id': F$L6[k[83006]][k[70285]], 'role_id': rnx8ze, 'uid': F$L6[k[83011]], 'role_name': _42kq5, 'role_type': mfqht0, 'level': pa3y7$ });
}, window['F$068'] = function (muvi1b, hifmt, $z78re, dwsxn, r8ze7$, fht05, j26o, ih0fm, iubv9, z87e$r) {
  F$L6[k[86433]] = muvi1b, F$L6[k[64161]] = hifmt, F$L6[k[86434]] = $z78re, fb1ugv9[k[86418]](F$L6[k[83006]][k[70285]], F$L6[k[83006]][k[86625]] || F$L6[k[83006]][k[70285]], muvi1b, hifmt, $z78re), sendApi(F$L6[k[86536]], k[86654], { 'game_pkg': F$L6[k[83012]], 'server_id': F$L6[k[83006]][k[70285]], 'role_id': muvi1b, 'uid': F$L6[k[83011]], 'role_name': hifmt, 'role_type': dwsxn, 'level': $z78re, 'evolution': r8ze7$ });
}, window['F$806'] = function (ze78r, k0q4_, h5, yra37$, swnxed, dco6s, thq5, bvufi, tfh0, jdscwn) {
  F$L6[k[86433]] = ze78r, F$L6[k[64161]] = k0q4_, F$L6[k[86434]] = h5, fb1ugv9[k[86419]](F$L6[k[83006]][k[70285]], F$L6[k[83006]][k[86625]] || F$L6[k[83006]][k[70285]], ze78r, k0q4_, h5), sendApi(F$L6[k[86536]], k[86654], { 'game_pkg': F$L6[k[83012]], 'server_id': F$L6[k[83006]][k[70285]], 'role_id': ze78r, 'uid': F$L6[k[83011]], 'role_name': k0q4_, 'role_type': yra37$, 'level': h5, 'evolution': swnxed });
}, window['F$860'] = function (cdjo2) {}, window['F$08'] = function (_0k5hq) {
  fb1ugv9[k[86363]](k[86363], function (bmiv1u) {
    _0k5hq && _0k5hq(bmiv1u);
  });
}, window[k[82691]] = function () {
  fb1ugv9[k[82691]]();
}, window[k[86655]] = function () {
  fb1ugv9[k[81683]]();
}, window['F$80'] = function (a$37yr) {
  window['F$680'] = a$37yr, window['F$680'] && window['F$608'] && (console[k[60077]](k[86521] + window['F$608'][k[60739]]), window['F$680'](window['F$608']), window['F$608'] = null);
}, window['F$L086'] = function (dswne, v9bi, timbv, nzw) {
  window[k[60022]](k[86656], { 'game_pkg': window['F$L6'][k[83012]], 'role_id': v9bi, 'server_id': timbv }, nzw);
}, window['F$L068'] = function (bvimt, zexnr) {
  function cojsw(r$z387) {
    var xwsez = [],
        viufm = [],
        miub1 = window[k[60530]][k[86657]];for (var csdnj in miub1) {
      var y$837r = Number(csdnj);(!bvimt || !bvimt[k[60013]] || bvimt[k[60114]](y$837r) != -0x1) && (viufm[k[60029]](miub1[csdnj]), xwsez[k[60029]]([y$837r, 0x3]));
    }window['F$I86L0'](window[k[86444]], k[86658]) >= 0x0 ? (console[k[60457]](k[86659]), fb1ugv9[k[86660]] && fb1ugv9[k[86660]](viufm, function (sxdnwj) {
      console[k[60457]](k[86661]), console[k[60457]](sxdnwj);if (sxdnwj && sxdnwj[k[83178]] == k[86662]) for (var t0fmhq in miub1) {
        if (sxdnwj[miub1[t0fmhq]] == k[86317]) {
          var mvfbit = Number(t0fmhq);for (var cod6js = 0x0; cod6js < xwsez[k[60013]]; cod6js++) {
            if (xwsez[cod6js][0x0] == mvfbit) {
              xwsez[cod6js][0x1] = 0x1;break;
            }
          }
        }
      }window['F$I86L0'](window[k[86444]], k[86663]) >= 0x0 ? wx[k[86664]]({ 'withSubscriptions': !![], 'success': function (mif0) {
          var g9u1vb = mif0[k[86665]][k[86666]];if (g9u1vb) {
            console[k[60457]](k[86667]), console[k[60457]](g9u1vb);for (var tkqh in miub1) {
              if (g9u1vb[miub1[tkqh]] == k[86317]) {
                var ifmuvb = Number(tkqh);for (var enxsw = 0x0; enxsw < xwsez[k[60013]]; enxsw++) {
                  if (xwsez[enxsw][0x0] == ifmuvb) {
                    xwsez[enxsw][0x1] = 0x2;break;
                  }
                }
              }
            }console[k[60457]](xwsez), zexnr && zexnr(xwsez);
          } else console[k[60457]](k[86668]), console[k[60457]](mif0), console[k[60457]](xwsez), zexnr && zexnr(xwsez);
        }, 'fail': function () {
          console[k[60457]](k[86669]), console[k[60457]](xwsez), zexnr && zexnr(xwsez);
        } }) : (console[k[60457]](k[86670] + window[k[86444]]), console[k[60457]](xwsez), zexnr && zexnr(xwsez));
    })) : (console[k[60457]](k[86671] + window[k[86444]]), console[k[60457]](xwsez), zexnr && zexnr(xwsez)), wx[k[86672]](cojsw);
  }wx[k[86673]](cojsw);
}, window['F$L806'] = { 'isSuccess': ![], 'level': k[86674], 'isCharging': ![] }, window['F$L860'] = function (od6jcs) {
  wx[k[86509]]({ 'success': function (cnwsj) {
      var ibfum = window['F$L806'];ibfum[k[86675]] = !![], ibfum[k[64137]] = Number(cnwsj[k[64137]])['toFixed'](0x0), ibfum[k[86512]] = cnwsj[k[86512]], od6jcs && od6jcs(ibfum[k[86675]], ibfum[k[64137]], ibfum[k[86512]]);
    }, 'fail': function (xnze8) {
      console[k[60457]](k[86676], xnze8[k[83178]]);var rz$7e8 = window['F$L806'];od6jcs && od6jcs(rz$7e8[k[86675]], rz$7e8[k[64137]], rz$7e8[k[86512]]);
    } });
}, window[k[60022]] = function (znxer, _2k56, $ya73r, p$3ya, d2o, dc2jo6, wn8xez, fim0h) {
  p$3ya == undefined && (p$3ya = 0x1);var _o624c = new XMLHttpRequest();_o624c[k[83219]] = function () {
    if (_o624c[k[60061]] == 0x4) {
      if (_o624c[k[60105]] == 0xc8 || _o624c[k[60105]] == 0x12d) {
        var er8xzn = _o624c[k[83220]];er8xzn = JSON[k[60502]](_o624c[k[83220]]);if (!dc2jo6 || dc2jo6(er8xzn, _o624c, znxer)) {
          $ya73r && $ya73r(er8xzn);return;
        } else console[k[60077]](znxer), console[k[60124]](er8xzn);
      }p$3ya - 0x1 > 0x0 ? setTimeout(function () {
        send(znxer, _2k56, $ya73r, p$3ya - 0x1, d2o, dc2jo6);
      }, 0x3e8) : d2o && d2o(JSON[k[64039]]({ 'url': znxer, 'status': _o624c[k[60105]], 'response': _o624c[k[83220]], 'responseType': _o624c[k[83224]] }));
    }
  }, _o624c[k[60064]](wn8xez || k[82906], znxer), _o624c[k[83224]] = k[63965], _o624c[k[86677]](k[86678], fim0h || k[86575]), _o624c[k[60022]](_2k56);
}, window[k[86679]] = function (tqfh, xwz8, r$y38, wdxens, _4k0q, k26_o, qtm0hf) {
  !r$y38 && (r$y38 = {});var kqh0_ = Math[k[60117]](Date[k[60082]]() / 0x3e8);r$y38[k[60811]] = kqh0_, r$y38[k[82825]] = xwz8;var o62k = Object[k[60257]](r$y38)[k[60999]](),
      a$3p7 = '',
      tfm0ih = '';for (var t5qhk = 0x0; t5qhk < o62k[k[60013]]; t5qhk++) {
    a$3p7 = a$3p7 + (t5qhk == 0x0 ? '' : '&') + o62k[t5qhk] + r$y38[o62k[t5qhk]], tfm0ih = tfm0ih + (t5qhk == 0x0 ? '' : '&') + o62k[t5qhk] + '=' + encodeURIComponent(r$y38[o62k[t5qhk]]);
  }a$3p7 = a$3p7 + F$L6[k[86542]];var vbiufm = k[86680] + md5(a$3p7);send(tqfh + '?' + tfm0ih + (tfm0ih == '' ? '' : '&') + vbiufm, null, wdxens, _4k0q, k26_o, qtm0hf || function (dco62) {
    return dco62[k[63662]] == k[68940];
  }, null, k[86348]);
}, window['F$L608'] = function (_52, h0mft) {
  var bimhtf = 0x0;F$L6[k[83006]] && (bimhtf = F$L6[k[83006]][k[70285]]), sendApi(F$L6[k[86538]], k[86681], { 'partnerId': F$L6[k[81783]], 'gamePkg': F$L6[k[83012]], 'logTime': Math[k[60117]](Date[k[60082]]() / 0x3e8), 'platformUid': F$L6[k[83013]], 'type': _52, 'serverId': bimhtf }, null, 0x2, null, function () {
    return !![];
  });
}, window['F$L680'] = function (u91bvi) {
  sendApi(F$L6[k[86536]], k[86682], { 'partner_id': F$L6[k[81783]], 'uid': F$L6[k[83011]], 'version': F$L6[k[64231]], 'game_pkg': F$L6[k[83012]], 'device': F$L6[k[83014]] }, F$08L, F$86L, F$60);
}, window['F$08L'] = function (nexr8z) {
  if (nexr8z[k[63662]] === k[68940] && nexr8z[k[60011]]) {
    nexr8z[k[60011]][k[65011]]({ 'id': -0x2, 'name': k[86683] }), nexr8z[k[60011]][k[65011]]({ 'id': -0x1, 'name': k[86684] }), F$L6[k[86685]] = nexr8z[k[60011]];if (window[k[70886]]) window[k[70886]][k[86686]]();
  } else F$L6[k[86687]] = ![], window['F$08L6'](k[86688] + nexr8z[k[63662]]);
}, window['F$0L8'] = function (c26oj4) {
  sendApi(F$L6[k[86536]], k[86689], { 'partner_id': F$L6[k[81783]], 'uid': F$L6[k[83011]], 'version': F$L6[k[64231]], 'game_pkg': F$L6[k[83012]], 'device': F$L6[k[83014]] }, F$80L, F$86L, F$60);
}, window['F$80L'] = function (btimh) {
  F$L6[k[86690]] = ![];if (btimh[k[63662]] === k[68940] && btimh[k[60011]]) {
    for (var qt05hf = 0x0; qt05hf < btimh[k[60011]][k[60013]]; qt05hf++) {
      btimh[k[60011]][qt05hf][k[60105]] = F$608L(btimh[k[60011]][qt05hf]);
    }F$L6[k[86545]][-0x1] = window[k[86691]](btimh[k[60011]]), window[k[70886]][k[86692]](-0x1);
  } else window['F$08L6'](k[86693] + btimh[k[63662]]);
}, window[k[86694]] = function (p7y3a) {
  sendApi(F$L6[k[86536]], k[86689], { 'partner_id': F$L6[k[81783]], 'uid': F$L6[k[83011]], 'version': F$L6[k[64231]], 'game_pkg': F$L6[k[83012]], 'device': F$L6[k[83014]] }, p7y3a, F$86L, F$60);
}, window['F$8L0'] = function (codsw, $3r87y) {
  sendApi(F$L6[k[86536]], k[86695], { 'partner_id': F$L6[k[81783]], 'uid': F$L6[k[83011]], 'version': F$L6[k[64231]], 'game_pkg': F$L6[k[83012]], 'device': F$L6[k[83014]], 'server_group_id': $3r87y }, F$L08, F$86L, F$60);
}, window['F$L08'] = function (_k5624) {
  F$L6[k[86690]] = ![];if (_k5624[k[63662]] === k[68940] && _k5624[k[60011]] && _k5624[k[60011]][k[60011]]) {
    var wz8e = _k5624[k[60011]][k[86696]],
        xnsezw = [];for (var xjwsd = 0x0; xjwsd < _k5624[k[60011]][k[60011]][k[60013]]; xjwsd++) {
      _k5624[k[60011]][k[60011]][xjwsd][k[60105]] = F$608L(_k5624[k[60011]][k[60011]][xjwsd]), (xnsezw[k[60013]] == 0x0 || _k5624[k[60011]][k[60011]][xjwsd][k[60105]] != 0x0) && (xnsezw[xnsezw[k[60013]]] = _k5624[k[60011]][k[60011]][xjwsd]);
    }F$L6[k[86545]][wz8e] = window[k[86691]](xnsezw), window[k[70886]][k[86692]](wz8e);
  } else window['F$08L6'](k[86697] + _k5624[k[63662]]);
}, window['F$IL86'] = function (vbmift) {
  sendApi(F$L6[k[86536]], k[86698], { 'partner_id': F$L6[k[81783]], 'uid': F$L6[k[83011]], 'version': F$L6[k[64231]], 'game_pkg': F$L6[k[83012]], 'device': F$L6[k[83014]] }, reqServerRecommendCallBack, F$86L, F$60);
}, window[k[86699]] = function (bmvu) {
  F$L6[k[86690]] = ![];if (bmvu[k[63662]] === k[68940] && bmvu[k[60011]]) {
    for (var k_5q04 = 0x0; k_5q04 < bmvu[k[60011]][k[60013]]; k_5q04++) {
      bmvu[k[60011]][k_5q04][k[60105]] = F$608L(bmvu[k[60011]][k_5q04]);
    }F$L6[k[86545]][-0x2] = window[k[86691]](bmvu[k[60011]]), window[k[70886]][k[86692]](-0x2);
  } else alert(k[86700] + bmvu[k[63662]]);
}, window[k[86691]] = function (vfib) {
  if (!vfib && vfib[k[60013]] <= 0x0) return vfib;for (let jcsdn = 0x0; jcsdn < vfib[k[60013]]; jcsdn++) {
    vfib[jcsdn][k[86701]] && vfib[jcsdn][k[86701]] == 0x1 && (vfib[jcsdn][k[86625]] += k[86702]);
  }return vfib;
}, window['F$L80'] = function (oc_2, ndwsj) {
  oc_2 = oc_2 || F$L6[k[83006]][k[70285]], sendApi(F$L6[k[86536]], k[86703], { 'type': '4', 'game_pkg': F$L6[k[83012]], 'server_id': oc_2 }, ndwsj);
}, window[k[86704]] = function (_2k5q, th0kq, himb, i91u) {
  himb = himb || F$L6[k[83006]][k[70285]], sendApi(F$L6[k[86536]], k[86705], { 'type': _2k5q, 'game_pkg': th0kq, 'server_id': himb }, i91u);
}, window['F$608L'] = function (k50hq_) {
  if (k50hq_) {
    if (k50hq_[k[60105]] == 0x1) {
      if (k50hq_[k[86706]] == 0x1) return 0x2;else return 0x1;
    } else return k50hq_[k[60105]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['F$60L8'] = function (b1muvi, fbimht) {
  F$L6[k[86707]] = { 'step': b1muvi, 'server_id': fbimht };var c6o2jd = this;F$0L86({ 'title': k[86708] }), sendApi(F$L6[k[86536]], k[86709], { 'partner_id': F$L6[k[81783]], 'uid': F$L6[k[83011]], 'game_pkg': F$L6[k[83012]], 'server_id': fbimht, 'platform': F$L6[k[82982]], 'platform_uid': F$L6[k[83013]], 'check_login_time': F$L6[k[86618]], 'check_login_sign': F$L6[k[86617]], 'version_name': F$L6[k[86595]] }, F$680L, F$86L, F$60, function (m0tf) {
    return m0tf[k[63662]] == k[68940] || m0tf[k[60077]] == k[86710] || m0tf[k[60077]] == k[86711];
  });
}, window['F$680L'] = function (wnsc) {
  var dc2j6o = this;if (wnsc[k[63662]] === k[68940] && wnsc[k[60011]]) {
    var b1u9vi = F$L6[k[83006]];b1u9vi[k[86712]] = F$L6[k[86546]], b1u9vi[k[70271]] = String(wnsc[k[60011]][k[86713]]), b1u9vi[k[82984]] = parseInt(wnsc[k[60011]][k[60811]]);if (wnsc[k[60011]][k[82983]]) b1u9vi[k[82983]] = parseInt(wnsc[k[60011]][k[82983]]);else b1u9vi[k[82983]] = parseInt(wnsc[k[60011]][k[70285]]);b1u9vi[k[86714]] = 0x0, b1u9vi[k[64053]] = F$L6[k[86636]], b1u9vi[k[86715]] = wnsc[k[60011]][k[86716]], b1u9vi[k[86717]] = wnsc[k[60011]][k[86717]], console[k[60457]](k[86718] + JSON[k[64039]](b1u9vi[k[86717]])), F$L6[k[60599]] == 0x1 && b1u9vi[k[86717]] && b1u9vi[k[86717]][k[86719]] == 0x1 && (F$L6[k[86720]] = 0x1, window[k[86443]][k[60144]]['F$I6']()), F$68L0();
  } else sendApi(F$L6[k[86536]], k[86605], { 'platform': F$L6[k[86534]], 'partner_id': F$L6[k[81783]], 'token': F$L6[k[86603]], 'game_pkg': F$L6[k[83012]], 'deviceId': F$L6[k[83014]], 'scene': k[86606] + F$L6[k[86544]] }, function (v1g9ub) {
    if (v1g9ub[k[63662]] == k[83276]) {
      window['F$08L6'](k[86616] + v1g9ub[k[63662]]);return;
    }F$L6[k[86617]] = String(v1g9ub[k[70271]]), F$L6[k[86618]] = String(v1g9ub[k[60811]]), setTimeout(function () {
      F$60L8(F$L6[k[86707]][k[66453]], F$L6[k[86707]][k[70285]]);
    }, 0x5dc);
  }, F$86L, F$60, function (ug9vb) {
    return ug9vb[k[63662]] == k[68940] || ug9vb[k[63662]] == k[83276];
  });
}, window['F$68L0'] = function () {
  ServerLoading[k[60144]][k[86629]](F$L6[k[60599]]), window['F$86'] = !![], window['F$6L80']();
}, window['F$6L08'] = function () {
  if (window['F$68'] && window['F$L86'] && window[k[86552]] && window[k[86553]] && window['F$L68'] && window['F$L8']) {
    if (!window[k[85885]][k[60144]]) {
      console[k[60457]](k[86721] + window[k[85885]][k[60144]]);var ncjsw = wx[k[86722]](),
          o42k6 = ncjsw[k[60739]] ? ncjsw[k[60739]] : 0x0,
          p3y$a7 = { 'cdn': window['F$L6'][k[64053]], 'spareCdn': window['F$L6'][k[82705]], 'newRegister': window['F$L6'][k[60599]], 'wxPC': window['F$L6'][k[82708]], 'wxIOS': window['F$L6'][k[60486]], 'wxAndroid': window['F$L6'][k[70128]], 'wxParam': { 'limitLoad': window['F$L6']['F$I0L86'], 'benchmarkLevel': window['F$L6']['F$I0L68'], 'wxFrom': window[k[60530]][k[86140]] == k[86723] ? 0x1 : 0x0, 'wxSDKVersion': window[k[86444]] }, 'configType': window['F$L6'][k[70455]], 'exposeType': window['F$L6'][k[60679]], 'scene': o42k6 };new window[k[85885]](p3y$a7, window['F$L6'][k[60100]], window['F$I086L']);
    }
  }
}, window['F$6L80'] = function () {
  if (window['F$68'] && window['F$L86'] && window[k[86552]] && window[k[86553]] && window['F$L68'] && window['F$L8'] && window['F$86'] && window['F$8L']) {
    F$0L68();if (!F$68L) {
      F$68L = !![];if (!window[k[85885]][k[60144]]) window['F$6L08']();var $7yr3 = 0x0,
          k40_q = wx[k[86724]]();k40_q && (window['F$L6'][k[86498]] && ($7yr3 = k40_q[k[60313]]), console[k[60077]](k[86725] + k40_q[k[60313]] + k[86726] + k40_q[k[61124]] + k[86727] + k40_q[k[61126]] + k[86728] + k40_q[k[61125]] + k[86729] + k40_q[k[60172]] + k[86730] + k40_q[k[60173]]));var jdsxw = {};for (const jdo26 in F$L6[k[83006]]) {
        jdsxw[jdo26] = F$L6[k[83006]][jdo26];
      }var h0iftm = { 'channel': window['F$L6'][k[83010]], 'account': window['F$L6'][k[83011]], 'userId': window['F$L6'][k[81782]], 'cdn': window['F$L6'][k[64053]], 'data': window['F$L6'][k[60011]], 'package': window['F$L6'][k[82706]], 'newRegister': window['F$L6'][k[60599]], 'pkgName': window['F$L6'][k[83012]], 'partnerId': window['F$L6'][k[81783]], 'platform_uid': window['F$L6'][k[83013]], 'deviceId': window['F$L6'][k[83014]], 'selectedServer': jdsxw, 'configType': window['F$L6'][k[70455]], 'exposeType': window['F$L6'][k[60679]], 'debugUsers': window['F$L6'][k[70838]], 'wxMenuTop': $7yr3, 'wxShield': window['F$L6'][k[60704]] };if (window[k[86638]]) for (var co24_6 in window[k[86638]]) {
        h0iftm[co24_6] = window[k[86638]][co24_6];
      }window[k[85885]][k[60144]]['F$8I6L'](h0iftm), setTimeout(() => {
        !wx_develop && new minitool();
      }, 0x2710);
    }
  } else console[k[60077]](k[86731] + window['F$68'] + k[86732] + window['F$L86'] + k[86733] + window[k[86552]] + k[86734] + window[k[86553]] + k[86735] + window['F$L68'] + k[86736] + window['F$L8'] + k[86737] + window['F$86'] + k[86738] + window['F$8L']);
};