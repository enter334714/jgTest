var s1 = wx.l$;
import _xx24g from '../ij76a/ip.js';
window[s1[565]] = { 'wxVersion': window[s1[425]][s1[566]] }, window[s1[567]] = ![], window[s1[568]] = 0x1, window[s1[569]] = 0x1, window[s1[570]] = !![], window[s1[571]] = !![], window[s1[572]] = '', window[s1[573]] = !![], window[s1[160]] = {
    'base_cdn': s1[574],
    'cdn': s1[574]
}, _sYI[s1[575]] = {}, _sYI[s1[576]] = '0', _sYI[s1[577]] = window[s1[565]][s1[224]], _sYI[s1[578]] = '', _sYI['os'] = '1', _sYI[s1[579]] = s1[580], _sYI[s1[581]] = s1[582], _sYI[s1[583]] = s1[584], _sYI[s1[585]] = s1[586], _sYI[s1[587]] = s1[588], _sYI[s1[589]] = '1', _sYI[s1[304]] = '', _sYI[s1[590]] = '', _sYI[s1[591]] = 0x0, _sYI[s1[342]] = {}, _sYI[s1[592]] = parseInt(_sYI[s1[589]]), _sYI[s1[593]] = _sYI[s1[589]], _sYI[s1[161]] = {}, _sYI[s1[594]] = s1[595], _sYI[s1[596]] = ![], _sYI[s1[597]] = s1[598], _sYI[s1[599]] = Date[s1[154]](), _sYI[s1[600]] = s1[601], _sYI[s1[602]] = '_a', _sYI[s1[603]] = '', _sYI[s1[207]] = 0x2, _sYI[s1[222]] = 0x7c1, _sYI[s1[224]] = window[s1[565]][s1[224]], _sYI[s1[309]] = ![], _sYI[s1[604]] = ![], _sYI[s1[605]] = ![], _sYI[s1[606]] = ![], window[s1[607]] = 0x5, window[s1[608]] = ![], window[s1[609]] = ![], window[s1[610]] = ![], window[s1[465]] = ![], window[s1[479]] = ![], window[s1[611]] = ![], window[s1[612]] = ![], window[s1[613]] = ![], window[s1[614]] = ![], window[s1[469]] = null, window[s1[615]] = function ($wdt) {
    console[s1[311]](s1[615], $wdt), wx[s1[616]]({}), wx[s1[617]]({
        'title': s1[618],
        'content': $wdt,
        'success'(wvbt$) {
            if (wvbt$[s1[619]]) console[s1[311]](s1[620]);else wvbt$[s1[621]] && console[s1[311]](s1[622]);
        }
    });
}, window[s1[623]] = function (au7oz) {
    console[s1[311]](s1[624], au7oz), _sNYIW(), wx[s1[617]]({
        'title': s1[618],
        'content': au7oz,
        'confirmText': s1[625],
        'cancelText': s1[626],
        'success'(rq_cak) {
            if (rq_cak[s1[619]]) window[s1[627]]();else rq_cak[s1[621]] && (console[s1[311]](s1[628]), wx[s1[629]]({}));
        }
    });
}, window[s1[630]] = function (_kqrnc) {
    console[s1[311]](s1[630], _kqrnc), wx[s1[617]]({
        'title': s1[618],
        'content': _kqrnc,
        'confirmText': s1[631],
        'showCancel': ![],
        'complete'(wvtj$9) {
            console[s1[311]](s1[628]), wx[s1[629]]({});
        }
    });
}, window[s1[632]] = ![], window[s1[633]] = function (gxy4) {
    window[s1[632]] = !![], wx[s1[634]](gxy4);
}, window[s1[635]] = function () {
    window[s1[632]] && (window[s1[632]] = ![], wx[s1[616]]({}));
}, window[s1[459]] = function (hgi24) {
    window[s1[564]][s1[155]][s1[459]](hgi24);
}, window[s1[636]] = function (rknc9_, fe5ls6) {
    _xx24g[s1[636]](rknc9_, function (g43h1) {
        g43h1 && g43h1[s1[349]] ? g43h1[s1[349]][s1[348]] == 0x1 ? fe5ls6(!![]) : (fe5ls6(![]), console[s1[637]](s1[638] + g43h1[s1[349]][s1[639]])) : console[s1[311]](s1[636], g43h1);
    });
}, window[s1[640]] = function (f5ls6e, ef56sl) {
    console[s1[637]](s1[641] + JSON[s1[497]](f5ls6e)), f5ls6e[s1[642]] = JSON[s1[497]](f5ls6e[s1[642]]);
    var zlpf7s = function (e6yxgi) {
        if (!e6yxgi) e6yxgi = {
            'state': 0x1,
            'display': 0x1,
            'msg': s1[643]
        };
        if (!e6yxgi[s1[639]]) e6yxgi[s1[639]] = s1[643];
        console[s1[637]](s1[644] + JSON[s1[497]](e6yxgi)), ef56sl && ef56sl(e6yxgi);
    },
        lzp7uf = function (t$0vbw) {
        var _nck9j = {
            'state': 0x0,
            'display': 0x0,
            'msg': s1[645]
        };
        console[s1[637]](s1[646] + t$0vbw), ef56sl && ef56sl(_nck9j);
    };
    sendApi(_sYI[s1[581]], s1[647], f5ls6e, zlpf7s, 0x1, lzp7uf, function () {
        return !![];
    });
}, window[s1[648]] = function (i2yx4) {
    console[s1[311]](s1[649], i2yx4);
}, window[s1[213]] = function (yi6ex) {}, window[s1[218]] = function (j9vcn, _nqr, qauomr) {}, window[s1[650]] = function (ex5s6) {
    console[s1[311]](s1[651], ex5s6), window[s1[564]][s1[155]][s1[211]](), window[s1[564]][s1[155]][s1[212]](), window[s1[564]][s1[155]][s1[228]](), window[s1[652]]();
}, window[s1[653]] = function (v0$tw) {
    window[s1[654]](0xe, s1[655] + v0$tw), window[s1[623]](s1[656]);
    var yg2xi = {
        'id': window[s1[160]][s1[657]],
        'role': window[s1[160]][s1[658]],
        'level': window[s1[160]][s1[659]],
        'account': window[s1[160]][s1[660]],
        'version': window[s1[160]][s1[222]],
        'cdn': window[s1[160]][s1[335]],
        'pkgName': window[s1[160]][s1[304]],
        'gamever': window[s1[425]][s1[566]],
        'serverid': window[s1[160]][s1[161]] ? window[s1[160]][s1[161]][s1[162]] : 0x0,
        'systemInfo': window[s1[661]],
        'error': s1[662],
        'stack': v0$tw ? v0$tw : s1[656]
    },
        w9nv$ = JSON[s1[497]](yg2xi);
    console[s1[428]](s1[663] + w9nv$), window[s1[594]](w9nv$);
}, window[s1[654]] = function (_rqma, sef6x) {
    sendApi(_sYI[s1[583]], s1[664], {
        'game_pkg': _sYI[s1[304]],
        'partner_id': _sYI[s1[589]],
        'server_id': _sYI[s1[161]] && _sYI[s1[161]][s1[162]] > 0x0 ? _sYI[s1[161]][s1[162]] : 0x0,
        'uid': _sYI[s1[660]] > 0x0 ? _sYI[s1[660]] : 0x0,
        'type': _rqma,
        'info': sef6x
    });
}, window[s1[665]] = function (racqo) {
    var k9ncjv = JSON[s1[666]](racqo);
    k9ncjv[s1[667]] = window[s1[425]][s1[566]], k9ncjv[s1[668]] = window[s1[160]][s1[161]] ? window[s1[160]][s1[161]][s1[162]] : 0x0, k9ncjv[s1[661]] = window[s1[661]];
    var fzs7l = JSON[s1[497]](k9ncjv);
    console[s1[428]](s1[669] + fzs7l), window[s1[594]](fzs7l);
}, window[s1[670]] = function (mrq, qcnr_) {
    var btw$v0 = {
        'id': window[s1[160]][s1[657]],
        'role': window[s1[160]][s1[658]],
        'level': window[s1[160]][s1[659]],
        'account': window[s1[160]][s1[660]],
        'version': window[s1[160]][s1[222]],
        'cdn': window[s1[160]][s1[335]],
        'pkgName': window[s1[160]][s1[304]],
        'gamever': window[s1[425]][s1[566]],
        'serverid': window[s1[160]][s1[161]] ? window[s1[160]][s1[161]][s1[162]] : 0x0,
        'systemInfo': window[s1[661]],
        'error': mrq,
        'stack': qcnr_
    },
        vwtb$ = JSON[s1[497]](btw$v0);
    console[s1[515]](s1[671] + vwtb$), window[s1[594]](vwtb$);
}, window[s1[594]] = function (aomur) {
    if (window[s1[160]][s1[672]] == s1[673]) return;
    var zm7upl = _sYI[s1[594]] + s1[674] + _sYI[s1[660]];
    wx[s1[675]]({
        'url': zm7upl,
        'method': s1[676],
        'data': aomur,
        'header': {
            'content-type': s1[677],
            'cache-control': s1[678]
        },
        'success': function (le6sf) {
            DEBUG && console[s1[311]](s1[679], zm7upl, aomur, le6sf);
        },
        'fail': function (_kj9) {
            DEBUG && console[s1[311]](s1[679], zm7upl, aomur, _kj9);
        },
        'complete': function () {}
    });
}, window[s1[680]] = function () {
    function w9vkj() {
        return ((0x1 + Math[s1[215]]()) * 0x10000 | 0x0)[s1[681]](0x10)[s1[473]](0x1);
    }
    return w9vkj() + w9vkj() + '-' + w9vkj() + '-' + w9vkj() + '-' + w9vkj() + '+' + w9vkj() + w9vkj() + w9vkj();
}, window[s1[627]] = function () {
    console[s1[311]](s1[682]);
    var _orqma = _xx24g[s1[683]]();
    _sYI[s1[593]] = _orqma[s1[684]], _sYI[s1[592]] = _orqma[s1[684]], _sYI[s1[589]] = _orqma[s1[684]], _sYI[s1[304]] = _orqma[s1[426]];
    var sye56 = { 'game_ver': _sYI[s1[577]] };
    _sYI[s1[590]] = this[s1[680]](), _sNYWI({ 'title': s1[685] }), _xx24g[s1[394]](sye56, this[s1[686]][s1[220]](this));
}, window[s1[686]] = function (hg1423) {
    var amquor = hg1423[s1[470]];
    sdkInitRes = hg1423, console[s1[311]](s1[687] + amquor + s1[688] + (amquor == 0x1) + s1[689] + hg1423[s1[566]] + s1[690] + window[s1[565]][s1[224]]);
    if (!hg1423[s1[566]] || window[s1[691]](window[s1[565]][s1[224]], hg1423[s1[566]]) < 0x0) console[s1[311]](s1[692]), _sYI[s1[581]] = s1[693], _sYI[s1[583]] = s1[694], _sYI[s1[585]] = s1[695], _sYI[s1[335]] = s1[696], _sYI[s1[697]] = s1[698], _sYI[s1[699]] = hg1423[s1[699]], _sYI[s1[309]] = ![];else window[s1[691]](window[s1[565]][s1[224]], hg1423[s1[566]]) == 0x0 ? (console[s1[311]](s1[700]), _sYI[s1[581]] = s1[582], _sYI[s1[583]] = s1[584], _sYI[s1[585]] = s1[586], _sYI[s1[335]] = s1[701], _sYI[s1[697]] = s1[698], _sYI[s1[699]] = s1[702], _sYI[s1[309]] = !![]) : (console[s1[311]](s1[703]), _sYI[s1[581]] = s1[582], _sYI[s1[583]] = s1[584], _sYI[s1[585]] = s1[586], _sYI[s1[335]] = s1[701], _sYI[s1[697]] = s1[698], _sYI[s1[699]] = s1[702], _sYI[s1[309]] = ![]);
    _sYI[s1[591]] = config[s1[642]] ? config[s1[642]] : 0x0, this[s1[704]](), this[s1[705]](), window[s1[706]] = 0x5, _sNYWI({ 'title': s1[707] }), _xx24g[s1[708]](this[s1[709]][s1[220]](this));
}, window[s1[706]] = 0x5, window[s1[709]] = function (cj_k, pzul) {
    if (cj_k == 0x0 && pzul && pzul[s1[710]]) {
        _sYI[s1[711]] = pzul[s1[710]], _sYI[s1[712]] = pzul[s1[712]], _sYI[s1[713]] = pzul[s1[713]], _sYI[s1[714]] = pzul[s1[714]], _sYI[s1[308]] = pzul[s1[308]];
        var rqc_nk = this;
        _sNYWI({ 'title': s1[715] }), sendApi(_sYI[s1[581]], s1[716], {
            'platform': _sYI[s1[579]],
            'partner_id': _sYI[s1[589]],
            'token': pzul[s1[710]],
            'game_pkg': _sYI[s1[304]],
            'deviceId': _sYI[s1[590]],
            'scene': s1[717] + _sYI[s1[591]]
        }, this[s1[718]][s1[220]](this), _sWIY, _sIN);
    } else pzul && pzul[s1[719]] && window[s1[706]] > 0x0 && (pzul[s1[719]][s1[517]](s1[720]) != -0x1 || pzul[s1[719]][s1[517]](s1[721]) != -0x1 || pzul[s1[719]][s1[517]](s1[722]) != -0x1 || pzul[s1[719]][s1[517]](s1[723]) != -0x1 || pzul[s1[719]][s1[517]](s1[724]) != -0x1 || pzul[s1[719]][s1[517]](s1[725]) != -0x1) ? (window[s1[706]]--, _xx24g[s1[708]](this[s1[709]][s1[220]](this))) : (window[s1[654]](0x1, s1[726] + cj_k + s1[727] + (pzul ? pzul[s1[719]] : '')), window[s1[670]](s1[728], JSON[s1[497]]({
        'status': cj_k,
        'data': pzul
    })), window[s1[623]](s1[729] + (pzul && pzul[s1[719]] ? '，' + pzul[s1[719]] : '')));
}, window[s1[718]] = function (_r9ck) {
    if (!_r9ck) {
        window[s1[654]](0x2, s1[730]), window[s1[670]](s1[731], s1[732]), window[s1[623]](s1[733]);
        return;
    }
    if (_r9ck[s1[348]] != s1[347]) {
        window[s1[654]](0x2, s1[734] + _r9ck[s1[348]]), window[s1[670]](s1[731], JSON[s1[497]](_r9ck)), window[s1[623]](s1[735] + _r9ck[s1[348]]);
        return;
    }
    if (_r9ck[s1[736]] == 0x1) {
        window[s1[623]](s1[737]);
        return;
    }
    _sYI[s1[738]] = String(_r9ck[s1[660]]), _sYI[s1[660]] = String(_r9ck[s1[660]]), _sYI[s1[739]] = String(_r9ck[s1[739]]), _sYI[s1[593]] = String(_r9ck[s1[739]]), _sYI[s1[740]] = String(_r9ck[s1[740]]), _sYI[s1[741]] = String(_r9ck[s1[742]]), _sYI[s1[743]] = String(_r9ck[s1[744]]), _sYI[s1[742]] = '';
    var $0bd8t = this;
    _sNYWI({ 'title': s1[745] });
    var _9rcnk = localStorage[s1[346]](s1[746] + _sYI[s1[304]] + _sYI[s1[660]]);
    if (_9rcnk && _9rcnk != '') {
        var jck9nv = Number(_9rcnk);
        $0bd8t[s1[747]](jck9nv);
    } else $0bd8t[s1[748]]();
}, window[s1[748]] = function () {
    var ck9_nr = this;
    sendApi(_sYI[s1[581]], s1[749], {
        'partner_id': _sYI[s1[589]],
        'uid': _sYI[s1[660]],
        'version': _sYI[s1[577]],
        'game_pkg': _sYI[s1[304]],
        'device': _sYI[s1[590]]
    }, ck9_nr[s1[750]][s1[220]](ck9_nr), _sWIY, _sIN);
}, window[s1[750]] = function (nkjc) {
    if (!nkjc) {
        window[s1[654]](0x3, s1[751]), window[s1[623]](s1[751]);
        return;
    }
    if (nkjc[s1[348]] != s1[347]) {
        window[s1[654]](0x3, s1[752] + nkjc[s1[348]]), window[s1[623]](s1[752] + nkjc[s1[348]]);
        return;
    }
    if (!nkjc[s1[349]] || nkjc[s1[349]][s1[192]] == 0x0) {
        window[s1[654]](0x3, s1[753]), window[s1[623]](s1[754]);
        return;
    }
    this[s1[755]](nkjc);
}, window[s1[747]] = function ($8dt0) {
    var plz5f = this;
    sendApi(_sYI[s1[581]], s1[756], {
        'server_id': $8dt0,
        'time': Date[s1[154]]() / 0x3e8
    }, plz5f[s1[757]][s1[220]](plz5f), _sWIY, _sIN);
}, window[s1[757]] = function (twdb) {
    if (!twdb) {
        window[s1[654]](0x4, s1[758]), this[s1[748]]();
        return;
    }
    if (twdb[s1[348]] != s1[347]) {
        window[s1[654]](0x4, s1[759] + twdb[s1[348]]), this[s1[748]]();
        return;
    }
    if (!twdb[s1[349]] || twdb[s1[349]][s1[192]] == 0x0) {
        window[s1[654]](0x4, s1[760]), this[s1[748]]();
        return;
    }
    this[s1[755]](twdb);
}, window[s1[755]] = function (uplz7m) {
    _sYI[s1[486]] = uplz7m[s1[761]] != undefined ? uplz7m[s1[761]] : 0x0, _sYI[s1[161]] = {
        'server_id': String(uplz7m[s1[349]][0x0][s1[162]]),
        'server_name': String(uplz7m[s1[349]][0x0][s1[334]]),
        'entry_ip': uplz7m[s1[349]][0x0][s1[762]],
        'entry_port': parseInt(uplz7m[s1[349]][0x0][s1[763]]),
        'status': _sYWN(uplz7m[s1[349]][0x0]),
        'start_time': uplz7m[s1[349]][0x0][s1[764]],
        'maintain_time': uplz7m[s1[349]][0x0][s1[251]] ? uplz7m[s1[349]][0x0][s1[251]] : '',
        'is_recommend': uplz7m[s1[349]][0x0][s1[246]],
        'cdn': _sYI[s1[335]]
    }, this[s1[765]](), window[s1[564]] && window[s1[564]][s1[155]][s1[766]] && window[s1[564]][s1[155]][s1[766]](sdkInitRes[s1[767]], sdkInitRes[s1[768]], sdkInitRes[s1[769]], sdkInitRes[s1[770]], sdkInitRes[s1[771]]);
}, window[s1[765]] = function () {
    window[s1[613]] = !![], window[s1[772]]();
}, window[s1[772]] = function () {
    if (window[s1[613]] && window[s1[612]]) {
        var fex56 = _sYI[s1[307]] != undefined ? _sYI[s1[307]] : 0x0,
            kn9wv = _sYI[s1[308]] == undefined ? 0x0 : _sYI[s1[308]],
            o7uaq = fex56 == 0x1 && kn9wv == 0x1 || fex56 == 0x2 && kn9wv != 0x1 || fex56 == 0x3;
        console[s1[637]](s1[773] + _sYI[s1[486]] + s1[774] + o7uaq + s1[775] + _sYI[s1[308]] + s1[776] + _sYI[s1[307]]);
        if (!o7uaq && _sYI[s1[486]] == 0x1) {
            var mopuz = _sYI[s1[161]][s1[247]];
            if (mopuz === -0x1 || mopuz === 0x0) {
                window[s1[654]](0xf, s1[777] + _sYI[s1[161]]['id'] + s1[778] + _sYI[s1[161]][s1[247]]), window[s1[623]](mopuz === -0x1 ? s1[779] : s1[780]);
                return;
            }
            _sINWY(0x0, _sYI[s1[161]][s1[162]]), window[s1[564]][s1[155]][s1[480]](_sYI[s1[486]]);
        } else window[s1[564]][s1[155]][s1[475]]({
            'show': sdkInitRes[s1[767]],
            'skinUrl': sdkInitRes[s1[768]],
            'content': sdkInitRes[s1[769]],
            'x': sdkInitRes[s1[770]],
            'y': sdkInitRes[s1[771]]
        }), _sNYIW();
        window[s1[781]](), window[s1[466]](), window[s1[467]]();
    }
}, window[s1[704]] = function () {
    sendApi(_sYI[s1[581]], s1[782], {
        'game_pkg': _sYI[s1[304]],
        'version_name': _sYI[s1[699]]
    }, this[s1[783]][s1[220]](this), _sWIY, _sIN);
}, window[s1[783]] = function (lp5f6) {
    if (!lp5f6) {
        window[s1[654]](0x5, s1[784]), window[s1[623]](s1[784]);
        return;
    }
    if (lp5f6[s1[348]] != s1[347]) {
        window[s1[654]](0x5, s1[785] + lp5f6[s1[348]]), window[s1[623]](s1[785] + lp5f6[s1[348]]);
        return;
    }
    if (!lp5f6[s1[349]] || !lp5f6[s1[349]][s1[577]]) {
        window[s1[654]](0x5, s1[786] + (lp5f6[s1[349]] && lp5f6[s1[349]][s1[577]])), window[s1[623]](s1[786] + (lp5f6[s1[349]] && lp5f6[s1[349]][s1[577]]));
        return;
    }
    lp5f6[s1[349]][s1[787]] && lp5f6[s1[349]][s1[787]][s1[192]] > 0xa && (_sYI[s1[788]] = lp5f6[s1[349]][s1[787]], _sYI[s1[335]] = lp5f6[s1[349]][s1[787]]), lp5f6[s1[349]][s1[577]] && (_sYI[s1[222]] = lp5f6[s1[349]][s1[577]]), console[s1[637]](s1[789] + _sYI[s1[222]] + s1[790] + _sYI[s1[699]]), window[s1[611]] = !![], window[s1[466]](), window[s1[467]]();
}, window[s1[791]], window[s1[705]] = function () {
    sendApi(_sYI[s1[581]], s1[792], { 'game_pkg': _sYI[s1[304]] }, this[s1[793]][s1[220]](this), _sWIY, _sIN);
}, window[s1[793]] = function (b0tdw) {
    if (b0tdw && b0tdw[s1[348]] === s1[347] && b0tdw[s1[349]]) {
        window[s1[791]] = b0tdw[s1[349]];
        for (var hg12i4 in b0tdw[s1[349]]) {
            _sYI[hg12i4] = b0tdw[s1[349]][hg12i4];
        }
    } else window[s1[654]](0xb, s1[794]), console[s1[637]](s1[795] + b0tdw[s1[348]]);
    window[s1[612]] = !![], window[s1[772]]();
}, window[s1[781]] = function () {
    if (!window[s1[613]] || !window[s1[612]]) return;
    var c9nkj_ = _sYI[s1[486]] == 0x1,
        eygx4i = _sYI[s1[309]],
        qr_ = _sYI[s1[796]] && _sYI[s1[796]] > 0x0;
    if (eygx4i || c9nkj_ && qr_) {
        var exygi4 = _sYI[s1[797]],
            jvw0$t = exygi4 && exygi4[s1[192]] == 0x9;
        jvw0$t && (window[s1[798]] = exygi4);
        var _kcr = _sYI[s1[799]],
            gyx6 = _kcr && _kcr[s1[436]]('#')[s1[192]] == 0x4;
        gyx6 && (window[s1[433]] = _kcr);
    }
}, window[s1[652]] = function () {
    window[s1[798]] = null, window[s1[433]] = null;
}, window[s1[800]] = function (ufpz7l, g1hi, kjn9wv, d8b$0, lszf7p, bwt$0, wkvn, xs56fe, jw$, ro_mqa) {
    lszf7p = String(lszf7p);
    var zmpuo = wkvn,
        jwv$9n = xs56fe;
    _sYI[s1[575]][lszf7p] = {
        'productid': lszf7p,
        'productname': zmpuo,
        'productdesc': jwv$9n,
        'roleid': ufpz7l,
        'rolename': g1hi,
        'rolelevel': kjn9wv,
        'price': bwt$0,
        'callback': jw$
    }, sendApi(_sYI[s1[585]], s1[801], {
        'game_pkg': _sYI[s1[304]],
        'server_id': _sYI[s1[161]][s1[162]],
        'server_name': _sYI[s1[161]][s1[334]],
        'level': kjn9wv,
        'uid': _sYI[s1[660]],
        'role_id': ufpz7l,
        'role_name': g1hi,
        'product_id': lszf7p,
        'product_name': zmpuo,
        'product_desc': jwv$9n,
        'money': bwt$0,
        'partner_id': _sYI[s1[589]]
    }, toPayCallBack, _sWIY, _sIN);
}, window[s1[802]] = function (qr_kc) {
    if (qr_kc && (qr_kc[s1[803]] === 0xc8 || qr_kc[s1[348]] == s1[347])) {
        var lpsf5 = _sYI[s1[575]][String(qr_kc[s1[804]])];
        if (lpsf5[s1[805]]) lpsf5[s1[805]](qr_kc[s1[804]], qr_kc[s1[806]], -0x1);
        _xx24g[s1[807]]({
            'cpbill': qr_kc[s1[806]],
            'productid': qr_kc[s1[804]],
            'productname': lpsf5[s1[808]],
            'productdesc': lpsf5[s1[809]],
            'serverid': _sYI[s1[161]][s1[162]],
            'servername': _sYI[s1[161]][s1[334]],
            'roleid': lpsf5[s1[810]],
            'rolename': lpsf5[s1[811]],
            'rolelevel': lpsf5[s1[812]],
            'price': lpsf5[s1[813]],
            'extension': JSON[s1[497]]({ 'cp_order_id': qr_kc[s1[806]] })
        }, function ($nv9, kr_n9c) {
            lpsf5[s1[805]] && $nv9 == 0x0 && lpsf5[s1[805]](qr_kc[s1[804]], qr_kc[s1[806]], $nv9);
            console[s1[637]](JSON[s1[497]]({
                'type': s1[814],
                'status': $nv9,
                'data': qr_kc,
                'role_name': lpsf5[s1[811]]
            }));
            if ($nv9 === 0x0) {} else {
                if ($nv9 === 0x1) {} else {
                    if ($nv9 === 0x2) {}
                }
            }
        });
    } else {
        var $wnvj9 = qr_kc ? s1[815] + qr_kc[s1[803]] + s1[816] + qr_kc[s1[348]] + s1[817] + qr_kc[s1[637]] : s1[818];
        window[s1[654]](0xd, s1[819] + $wnvj9), alert($wnvj9);
    }
}, window[s1[820]] = function () {}, window[s1[821]] = function (rc_q, h21ig4, j9vk, _cakq, rqkcn_) {
    _xx24g[s1[822]](_sYI[s1[161]][s1[162]], _sYI[s1[161]][s1[334]] || _sYI[s1[161]][s1[162]], rc_q, h21ig4, j9vk), sendApi(_sYI[s1[581]], s1[823], {
        'game_pkg': _sYI[s1[304]],
        'server_id': _sYI[s1[161]][s1[162]],
        'role_id': rc_q,
        'uid': _sYI[s1[660]],
        'role_name': h21ig4,
        'role_type': _cakq,
        'level': j9vk
    });
}, window[s1[824]] = function (qomar_, rcqkn_, s5ef6, ex5i, vjkc9, f7lpu, _nc9r, $j0twv, x56fs, o_cra) {
    _sYI[s1[657]] = qomar_, _sYI[s1[658]] = rcqkn_, _sYI[s1[659]] = s5ef6, _xx24g[s1[825]](_sYI[s1[161]][s1[162]], _sYI[s1[161]][s1[334]] || _sYI[s1[161]][s1[162]], qomar_, rcqkn_, s5ef6), sendApi(_sYI[s1[581]], s1[826], {
        'game_pkg': _sYI[s1[304]],
        'server_id': _sYI[s1[161]][s1[162]],
        'role_id': qomar_,
        'uid': _sYI[s1[660]],
        'role_name': rcqkn_,
        'role_type': ex5i,
        'level': s5ef6,
        'evolution': vjkc9
    });
}, window[s1[827]] = function (vbt0$, zplfu7, pf5l, jvk9c, sl65ef, xi6ye, au7oq, mqroau, s6lp, vwt9j$) {
    _sYI[s1[657]] = vbt0$, _sYI[s1[658]] = zplfu7, _sYI[s1[659]] = pf5l, _xx24g[s1[828]](_sYI[s1[161]][s1[162]], _sYI[s1[161]][s1[334]] || _sYI[s1[161]][s1[162]], vbt0$, zplfu7, pf5l), sendApi(_sYI[s1[581]], s1[826], {
        'game_pkg': _sYI[s1[304]],
        'server_id': _sYI[s1[161]][s1[162]],
        'role_id': vbt0$,
        'uid': _sYI[s1[660]],
        'role_name': zplfu7,
        'role_type': jvk9c,
        'level': pf5l,
        'evolution': sl65ef
    });
}, window[s1[829]] = function (xse5y) {}, window[s1[830]] = function (v9kjn, k9c_) {
    _xx24g[s1[831]](s1[831], { 'activity_id': k9c_ }, function (g6iye) {
        v9kjn && v9kjn(g6iye);
    });
}, window[s1[832]] = function () {
    _xx24g[s1[832]]();
}, window[s1[833]] = function () {
    _xx24g[s1[834]]();
}, window[s1[835]] = function ($vt9jw, lfe5, t$vw0j, zomup7, pum, n_k9, es5l6f, v0tw) {
    v0tw = v0tw || _sYI[s1[161]][s1[162]], sendApi(_sYI[s1[581]], s1[836], {
        'phone': $vt9jw,
        'role_id': lfe5,
        'uid': _sYI[s1[660]],
        'game_pkg': _sYI[s1[304]],
        'partner_id': _sYI[s1[589]],
        'server_id': v0tw
    }, es5l6f, 0x2, null, function () {
        return !![];
    });
}, window[s1[837]] = function (rn9_k) {
    window[s1[838]] = rn9_k, window[s1[838]] && window[s1[839]] && (console[s1[637]](s1[840] + window[s1[839]][s1[841]]), window[s1[838]](window[s1[839]]), window[s1[839]] = null);
}, window[s1[842]] = function ($db0t, plf7uz, syxe5, ls7pz) {
    window[s1[843]](s1[844], {
        'game_pkg': window[s1[160]][s1[304]],
        'role_id': plf7uz,
        'server_id': syxe5
    }, ls7pz);
}, window[s1[845]] = function (puzm, n9w$j, h143) {
    function i124gh(qckr_n) {
        var g4h21 = [],
            j0v = [],
            fel6s5 = h143 || window[s1[425]][s1[846]];
        for (var rkqac_ in fel6s5) {
            var ozu7pm = Number(rkqac_);
            (!puzm || !puzm[s1[192]] || puzm[s1[517]](ozu7pm) != -0x1) && (j0v[s1[353]](fel6s5[rkqac_]), g4h21[s1[353]]([ozu7pm, 0x3]));
        }
        window[s1[691]](window[s1[847]], s1[848]) >= 0x0 ? (console[s1[311]](s1[849]), _xx24g[s1[850]] && _xx24g[s1[850]](j0v, function (g123h4) {
            console[s1[311]](s1[851]), console[s1[311]](g123h4);
            if (g123h4 && g123h4[s1[719]] == s1[852]) for (var _ckr9n in fel6s5) {
                if (g123h4[fel6s5[_ckr9n]] == s1[853]) {
                    var g142i = Number(_ckr9n);
                    for (var a_rcqk = 0x0; a_rcqk < g4h21[s1[192]]; a_rcqk++) {
                        if (g4h21[a_rcqk][0x0] == g142i) {
                            g4h21[a_rcqk][0x1] = 0x1;
                            break;
                        }
                    }
                }
            }
            window[s1[691]](window[s1[847]], s1[854]) >= 0x0 ? wx[s1[855]]({
                'withSubscriptions': !![],
                'success': function (psf5z) {
                    var knvw9 = psf5z[s1[856]][s1[857]];
                    if (knvw9) {
                        console[s1[311]](s1[858]), console[s1[311]](knvw9);
                        for (var x6y5s in fel6s5) {
                            if (knvw9[fel6s5[x6y5s]] == s1[853]) {
                                var qraumo = Number(x6y5s);
                                for (var wt9j$v = 0x0; wt9j$v < g4h21[s1[192]]; wt9j$v++) {
                                    if (g4h21[wt9j$v][0x0] == qraumo) {
                                        g4h21[wt9j$v][0x1] = 0x2;
                                        break;
                                    }
                                }
                            }
                        }
                        console[s1[311]](g4h21), n9w$j && n9w$j(g4h21);
                    } else console[s1[311]](s1[859]), console[s1[311]](psf5z), console[s1[311]](g4h21), n9w$j && n9w$j(g4h21);
                },
                'fail': function () {
                    console[s1[311]](s1[860]), console[s1[311]](g4h21), n9w$j && n9w$j(g4h21);
                }
            }) : (console[s1[311]](s1[861] + window[s1[847]]), console[s1[311]](g4h21), n9w$j && n9w$j(g4h21));
        })) : (console[s1[311]](s1[862] + window[s1[847]]), console[s1[311]](g4h21), n9w$j && n9w$j(g4h21)), wx[s1[863]](i124gh);
    }
    wx[s1[864]](i124gh);
}, window[s1[865]] = {
    'isSuccess': ![],
    'level': s1[866],
    'isCharging': ![]
}, window[s1[867]] = function (ckraq) {
    wx[s1[868]]({
        'success': function (lzmp7) {
            var eiy4gx = window[s1[865]];
            eiy4gx[s1[869]] = !![], eiy4gx[s1[870]] = Number(lzmp7[s1[870]])[s1[871]](0x0), eiy4gx[s1[872]] = lzmp7[s1[872]], ckraq && ckraq(eiy4gx[s1[869]], eiy4gx[s1[870]], eiy4gx[s1[872]]);
        },
        'fail': function (b0tw$d) {
            console[s1[311]](s1[873], b0tw$d[s1[719]]);
            var _9cnr = window[s1[865]];
            ckraq && ckraq(_9cnr[s1[869]], _9cnr[s1[870]], _9cnr[s1[872]]);
        }
    });
}, window[s1[874]] = function (o7qau) {
    wx[s1[874]]({
        'success': function (yxe5i6) {
            o7qau && o7qau(!![], yxe5i6);
        },
        'fail': function (n9$wv) {
            o7qau && o7qau(![], n9$wv);
        }
    });
}, window[s1[875]] = function (yxige4) {
    if (yxige4) wx[s1[875]](yxige4);
}, window[s1[876]] = function (ei6gyx) {
    wx[s1[876]](ei6gyx);
}, window[s1[843]] = function (krnc, bt$wv, ey65x, mqou, lse, es6lf5, btv$0, j_kc) {
    if (mqou == undefined) mqou = 0x1;
    wx[s1[675]]({
        'url': krnc,
        'method': btv$0 || s1[877],
        'responseType': s1[217],
        'data': bt$wv,
        'header': { 'content-type': j_kc || s1[677] },
        'success': function (coqr) {
            DEBUG && console[s1[311]](s1[878], krnc, info, coqr);
            if (coqr && coqr[s1[879]] == 0xc8) {
                var v9wj = coqr[s1[349]];
                !es6lf5 || es6lf5(v9wj) ? ey65x && ey65x(v9wj) : window[s1[880]](krnc, bt$wv, ey65x, mqou, lse, es6lf5, coqr);
            } else window[s1[880]](krnc, bt$wv, ey65x, mqou, lse, es6lf5, coqr);
        },
        'fail': function (e6s5) {
            DEBUG && console[s1[311]](s1[881], krnc, info, e6s5), window[s1[880]](krnc, bt$wv, ey65x, mqou, lse, es6lf5, e6s5);
        },
        'complete': function () {}
    });
}, window[s1[880]] = function (rk_qc, cknrq, cao_, $nvwj9, fl6s5p, p5fs6l, e5fls6) {
    $nvwj9 - 0x1 > 0x0 ? setTimeout(function () {
        window[s1[843]](rk_qc, cknrq, cao_, $nvwj9 - 0x1, fl6s5p, p5fs6l);
    }, 0x3e8) : fl6s5p && fl6s5p(JSON[s1[497]]({
        'url': rk_qc,
        'response': e5fls6
    }));
}, window[s1[882]] = function (xgyi42, k9nwj, q_crk, u7mzoa, n9_krc, rnkqc, szf5) {
    !q_crk && (q_crk = {});
    var cnr_9k = Math[s1[427]](Date[s1[154]]() / 0x3e8);
    q_crk[s1[744]] = cnr_9k, q_crk[s1[883]] = k9nwj;
    var rqo_m = Object[s1[884]](q_crk)[s1[354]](),
        yi65e = '',
        ih21g = '';
    for (var hi21g = 0x0; hi21g < rqo_m[s1[192]]; hi21g++) {
        yi65e = yi65e + (hi21g == 0x0 ? '' : '&') + rqo_m[hi21g] + q_crk[rqo_m[hi21g]], ih21g = ih21g + (hi21g == 0x0 ? '' : '&') + rqo_m[hi21g] + '=' + encodeURIComponent(q_crk[rqo_m[hi21g]]);
    }
    yi65e = yi65e + _sYI[s1[587]];
    var oc_qar = s1[885] + md5(yi65e);
    send(xgyi42 + '?' + ih21g + (ih21g == '' ? '' : '&') + oc_qar, null, u7mzoa, n9_krc, rnkqc, szf5 || function (g6xi) {
        return g6xi[s1[348]] == s1[347];
    }, null, s1[886]);
}, window[s1[887]] = function (sf5l, fe65l) {
    var ump7 = 0x0;
    _sYI[s1[161]] && (ump7 = _sYI[s1[161]][s1[162]]), sendApi(_sYI[s1[583]], s1[888], {
        'partnerId': _sYI[s1[589]],
        'gamePkg': _sYI[s1[304]],
        'logTime': Math[s1[427]](Date[s1[154]]() / 0x3e8),
        'platformUid': _sYI[s1[740]],
        'type': sf5l,
        'serverId': ump7
    }, null, 0x2, null, function () {
        return !![];
    });
}, window[s1[889]] = function (xyes6) {
    sendApi(_sYI[s1[581]], s1[890], {
        'partner_id': _sYI[s1[589]],
        'uid': _sYI[s1[660]],
        'version': _sYI[s1[577]],
        'game_pkg': _sYI[s1[304]],
        'device': _sYI[s1[590]]
    }, _sYIWN, _sWIY, _sIN);
}, window[s1[891]] = function (romuaq) {
    if (romuaq && romuaq[s1[348]] === s1[347] && romuaq[s1[349]]) {
        romuaq[s1[349]][s1[892]]({
            'id': -0x2,
            'name': s1[893]
        }), romuaq[s1[349]][s1[892]]({
            'id': -0x1,
            'name': s1[894]
        }), _sYI[s1[303]] = romuaq[s1[349]];
        if (window[s1[293]]) window[s1[293]][s1[336]]();
    } else {
        _sYI[s1[314]] = ![];
        var giyex4 = romuaq ? romuaq[s1[348]] : '';
        window[s1[654]](0x7, s1[895] + giyex4), window[s1[623]](s1[896] + giyex4);
    }
}, window[s1[897]] = function (oauq7m) {
    sendApi(_sYI[s1[581]], s1[898], {
        'partner_id': _sYI[s1[589]],
        'uid': _sYI[s1[660]],
        'version': _sYI[s1[577]],
        'game_pkg': _sYI[s1[304]],
        'device': _sYI[s1[590]]
    }, _sNYW, _sWIY, _sIN);
}, window[s1[899]] = function (ei) {
    _sYI[s1[344]] = ![];
    if (ei && ei[s1[348]] === s1[347] && ei[s1[349]]) {
        for (var kn9j_c = 0x0; kn9j_c < ei[s1[349]][s1[192]]; kn9j_c++) {
            ei[s1[349]][kn9j_c][s1[247]] = _sYWN(ei[s1[349]][kn9j_c]);
        }
        _sYI[s1[342]][-0x1] = window[s1[900]](ei[s1[349]]), window[s1[293]][s1[343]](-0x1);
    } else {
        var e5sfl6 = ei ? ei[s1[348]] : '';
        window[s1[654]](0x8, s1[901] + e5sfl6), window[s1[623]](s1[902] + e5sfl6);
    }
}, window[s1[903]] = function (r_maoq) {
    sendApi(_sYI[s1[581]], s1[898], {
        'partner_id': _sYI[s1[589]],
        'uid': _sYI[s1[660]],
        'version': _sYI[s1[577]],
        'game_pkg': _sYI[s1[304]],
        'device': _sYI[s1[590]]
    }, r_maoq, _sWIY, _sIN);
}, window[s1[904]] = function (o_aqmr, fex) {
    sendApi(_sYI[s1[581]], s1[905], {
        'partner_id': _sYI[s1[589]],
        'uid': _sYI[s1[660]],
        'version': _sYI[s1[577]],
        'game_pkg': _sYI[s1[304]],
        'device': _sYI[s1[590]],
        'server_group_id': fex
    }, _sWYN, _sWIY, _sIN);
}, window[s1[906]] = function (pzfl7u) {
    _sYI[s1[344]] = ![];
    if (pzfl7u && pzfl7u[s1[348]] === s1[347] && pzfl7u[s1[349]] && pzfl7u[s1[349]][s1[349]]) {
        var q_omra = pzfl7u[s1[349]][s1[907]],
            fxs6 = [];
        for (var g6xyi = 0x0; g6xyi < pzfl7u[s1[349]][s1[349]][s1[192]]; g6xyi++) {
            pzfl7u[s1[349]][s1[349]][g6xyi][s1[247]] = _sYWN(pzfl7u[s1[349]][s1[349]][g6xyi]), (fxs6[s1[192]] == 0x0 || pzfl7u[s1[349]][s1[349]][g6xyi][s1[247]] != 0x0) && (fxs6[fxs6[s1[192]]] = pzfl7u[s1[349]][s1[349]][g6xyi]);
        }
        _sYI[s1[342]][q_omra] = window[s1[900]](fxs6), window[s1[293]][s1[343]](q_omra);
    } else {
        var kqnr_ = pzfl7u ? pzfl7u[s1[348]] : '';
        window[s1[654]](0x9, s1[908] + kqnr_), window[s1[623]](s1[909] + kqnr_);
    }
}, window[s1[910]] = function (_orqca) {
    sendApi(_sYI[s1[581]], s1[911], {
        'partner_id': _sYI[s1[589]],
        'uid': _sYI[s1[660]],
        'version': _sYI[s1[577]],
        'game_pkg': _sYI[s1[304]],
        'device': _sYI[s1[590]]
    }, reqServerRecommendCallBack, _sWIY, _sIN);
}, window[s1[912]] = function (omu7qa) {
    _sYI[s1[344]] = ![];
    if (omu7qa && omu7qa[s1[348]] === s1[347] && omu7qa[s1[349]]) {
        for (var j9tw$ = 0x0; j9tw$ < omu7qa[s1[349]][s1[192]]; j9tw$++) {
            omu7qa[s1[349]][j9tw$][s1[247]] = _sYWN(omu7qa[s1[349]][j9tw$]);
        }
        _sYI[s1[342]][-0x2] = window[s1[900]](omu7qa[s1[349]]), window[s1[293]][s1[343]](-0x2);
    } else {
        var t0$wvj = omu7qa ? omu7qa[s1[348]] : '';
        window[s1[654]](0xa, s1[913] + t0$wvj), alert(s1[914] + t0$wvj);
    }
}, window[s1[900]] = function (ihy24) {
    return ihy24;
}, window[s1[915]] = function (kcjn9_, pls7) {
    kcjn9_ = kcjn9_ || _sYI[s1[161]][s1[162]], sendApi(_sYI[s1[581]], s1[916], {
        'type': '4',
        'game_pkg': _sYI[s1[304]],
        'server_id': kcjn9_
    }, pls7);
}, window[s1[917]] = function (zlpf7u, tvw$b0, cqk_n, akqc_) {
    cqk_n = cqk_n || _sYI[s1[161]][s1[162]], sendApi(_sYI[s1[581]], s1[918], {
        'type': zlpf7u,
        'game_pkg': tvw$b0,
        'server_id': cqk_n
    }, akqc_);
}, window[s1[919]] = function (zlpsf7, _roaq) {
    sendApi(_sYI[s1[581]], s1[920], { 'game_pkg': zlpsf7 }, _roaq);
}, window[s1[921]] = function (le56sf) {
    if (le56sf) {
        if (le56sf[s1[247]] == 0x1) {
            if (le56sf[s1[922]] == 0x3) return 0x3;else return le56sf[s1[922]] == 0x1 ? 0x2 : 0x1;
        } else return le56sf[s1[247]] == 0x0 ? 0x0 : -0x1;
    }
    return -0x1;
}, window[s1[923]] = function (eyig4x, fx6s5e) {
    _sYI[s1[924]] = {
        'step': eyig4x,
        'server_id': fx6s5e
    };
    var auzom = this;
    _sNYWI({ 'title': s1[925] }), sendApi(_sYI[s1[581]], s1[926], {
        'partner_id': _sYI[s1[589]],
        'uid': _sYI[s1[660]],
        'game_pkg': _sYI[s1[304]],
        'server_id': fx6s5e,
        'platform': _sYI[s1[739]],
        'platform_uid': _sYI[s1[740]],
        'check_login_time': _sYI[s1[743]],
        'check_login_sign': _sYI[s1[741]],
        'version_name': _sYI[s1[699]]
    }, _sINYW, _sWIY, _sIN, function (ulmzp) {
        return ulmzp[s1[348]] == s1[347] || ulmzp[s1[637]] == s1[927] || ulmzp[s1[637]] == s1[928];
    });
}, window[s1[929]] = function (a_rmo) {
    var gyxi24 = this;
    if (a_rmo && a_rmo[s1[348]] === s1[347] && a_rmo[s1[349]]) {
        var aqmuro = _sYI[s1[161]];
        aqmuro[s1[930]] = _sYI[s1[592]], aqmuro[s1[742]] = String(a_rmo[s1[349]][s1[931]]), aqmuro[s1[599]] = parseInt(a_rmo[s1[349]][s1[744]]);
        if (a_rmo[s1[349]][s1[932]]) aqmuro[s1[932]] = parseInt(a_rmo[s1[349]][s1[932]]);else aqmuro[s1[932]] = parseInt(a_rmo[s1[349]][s1[162]]);
        aqmuro[s1[933]] = 0x0, aqmuro[s1[335]] = _sYI[s1[788]], aqmuro[s1[934]] = a_rmo[s1[349]][s1[935]], aqmuro[s1[936]] = a_rmo[s1[349]][s1[936]];
        if (a_rmo[s1[349]][s1[937]]) aqmuro[s1[937]] = parseInt(a_rmo[s1[349]][s1[937]]);
        console[s1[311]](s1[938] + JSON[s1[497]](aqmuro[s1[936]])), _sYI[s1[486]] == 0x1 && aqmuro[s1[936]] && aqmuro[s1[936]][s1[939]] == 0x1 && (_sYI[s1[225]] = 0x1, window[s1[564]][s1[155]][s1[484]]()), _sIWNY();
    } else {
        if (_sYI[s1[924]][s1[940]] >= 0x3) {
            var z7upl = a_rmo ? a_rmo[s1[348]] : '';
            window[s1[654]](0xc, s1[941] + z7upl), _sIN(JSON[s1[497]](a_rmo)), window[s1[623]](s1[942] + z7upl);
        } else sendApi(_sYI[s1[581]], s1[716], {
            'platform': _sYI[s1[579]],
            'partner_id': _sYI[s1[589]],
            'token': _sYI[s1[711]],
            'game_pkg': _sYI[s1[304]],
            'deviceId': _sYI[s1[590]],
            'scene': s1[717] + _sYI[s1[591]]
        }, function (nj$wv) {
            if (!nj$wv || nj$wv[s1[348]] != s1[347]) {
                window[s1[623]](s1[735] + nj$wv && nj$wv[s1[348]]);
                return;
            }
            _sYI[s1[741]] = String(nj$wv[s1[742]]), _sYI[s1[743]] = String(nj$wv[s1[744]]), setTimeout(function () {
                _sINWY(_sYI[s1[924]][s1[940]] + 0x1, _sYI[s1[924]][s1[162]]);
            }, 0x5dc);
        }, _sWIY, _sIN, function (ix4yge) {
            return ix4yge[s1[348]] == s1[347] || ix4yge[s1[348]] == s1[943];
        });
    }
}, window[s1[944]] = function () {
    ServerLoading[s1[155]][s1[480]](_sYI[s1[486]]), window[s1[608]] = !![], window[s1[467]]();
}, window[s1[466]] = function () {
    if (window[s1[609]] && window[s1[610]] && window[s1[465]] && window[s1[479]] && window[s1[611]] && window[s1[613]]) {
        if (!window[s1[945]][s1[155]]) {
            console[s1[311]](s1[946] + window[s1[945]][s1[155]]);
            var zlfs5 = wx[s1[947]](),
                g4ih12 = zlfs5[s1[841]] ? zlfs5[s1[841]] : 0x0,
                ro_a = {
                'cdn': window[s1[160]][s1[335]],
                'spareCdn': window[s1[160]][s1[697]],
                'newRegister': window[s1[160]][s1[486]],
                'wxPC': window[s1[160]][s1[606]],
                'wxIOS': window[s1[160]][s1[604]],
                'wxAndroid': window[s1[160]][s1[605]],
                'wxParam': {
                    'limitLoad': window[s1[160]][s1[948]],
                    'benchmarkLevel': window[s1[160]][s1[949]],
                    'wxFrom': window[s1[425]][s1[642]] == s1[950] ? 0x1 : 0x0,
                    'wxSDKVersion': window[s1[847]],
                    'qudao': s1[951]
                },
                'configType': window[s1[160]][s1[600]],
                'exposeType': window[s1[160]][s1[602]],
                'scene': g4ih12,
                'video_type': window[s1[160]][s1[713]],
                'ad_flag': window[s1[160]][s1[308]]
            };
            if (window[s1[791]]) for (var xeiyg6 in window[s1[791]]) {
                if (!ro_a[xeiyg6]) ro_a[xeiyg6] = window[s1[791]][xeiyg6];
            }
            new window[s1[945]](ro_a, window[s1[160]][s1[222]], window[s1[572]]);
        }
    }
}, window[s1[467]] = function () {
    if (window[s1[609]] && window[s1[610]] && window[s1[465]] && window[s1[479]] && window[s1[611]] && window[s1[613]] && window[s1[608]] && window[s1[612]]) {
        _sNYIW();
        if (!_sIWY) {
            _sIWY = !![];
            if (!window[s1[945]][s1[155]]) window[s1[466]]();
            var y4xige = 0x0,
                d0t8$ = wx[s1[952]]();
            d0t8$ && (window[s1[160]][s1[953]] && (y4xige = d0t8$[s1[106]]), console[s1[637]](s1[954] + d0t8$[s1[106]] + s1[955] + d0t8$[s1[236]] + s1[956] + d0t8$[s1[366]] + s1[957] + d0t8$[s1[69]] + s1[958] + d0t8$[s1[184]] + s1[959] + d0t8$[s1[186]]));
            var pz5fsl = {};
            for (const muaq7 in _sYI[s1[161]]) {
                pz5fsl[muaq7] = _sYI[s1[161]][muaq7];
            }
            var yi2gh = {
                'channel': window[s1[160]][s1[593]],
                'account': window[s1[160]][s1[660]],
                'userId': window[s1[160]][s1[738]],
                'cdn': window[s1[160]][s1[335]],
                'data': window[s1[160]][s1[349]],
                'package': window[s1[160]][s1[576]],
                'newRegister': window[s1[160]][s1[486]],
                'pkgName': window[s1[160]][s1[304]],
                'partnerId': window[s1[160]][s1[589]],
                'platform_uid': window[s1[160]][s1[740]],
                'deviceId': window[s1[160]][s1[590]],
                'selectedServer': pz5fsl,
                'configType': window[s1[160]][s1[600]],
                'exposeType': window[s1[160]][s1[602]],
                'debugUsers': window[s1[160]][s1[597]],
                'wxMenuTop': y4xige,
                'wxShield': window[s1[160]][s1[309]],
                'encryptParam': window[s1[160]][s1[603]],
                'wx_channel': window[s1[160]][s1[712]],
                'zsy_tp_state': window[s1[160]][s1[714]]
            };
            if (window[s1[791]]) for (var geiy in window[s1[791]]) {
                yi2gh[geiy] = window[s1[791]][geiy];
            }
            window[s1[945]][s1[155]][s1[960]](yi2gh);
            if (_sYI[s1[161]] && _sYI[s1[161]][s1[162]]) localStorage[s1[315]](s1[746] + _sYI[s1[304]] + _sYI[s1[660]], _sYI[s1[161]][s1[162]]);
        }
    } else console[s1[637]](s1[961] + window[s1[609]] + s1[962] + window[s1[610]] + s1[963] + window[s1[465]] + s1[964] + window[s1[479]] + s1[965] + window[s1[611]] + s1[966] + window[s1[613]] + s1[967] + window[s1[608]] + s1[968] + window[s1[612]]);
};