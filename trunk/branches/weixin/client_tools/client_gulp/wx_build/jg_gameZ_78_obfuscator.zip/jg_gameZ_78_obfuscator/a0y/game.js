var s1 = wx.l$;
require(s1[0]);