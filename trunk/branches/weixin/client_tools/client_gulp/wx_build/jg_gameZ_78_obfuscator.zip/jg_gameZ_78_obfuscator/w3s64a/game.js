var s1 = wx.l$;
require('./xmc2w.js'), window[s1[37761]][s1[31325]][s1[37762]] = null, window['client_pb'] = require('./op.js'), window[s1[29327]] = window[s1[37761]][s1[29230]][s1[29231]](client_pb);