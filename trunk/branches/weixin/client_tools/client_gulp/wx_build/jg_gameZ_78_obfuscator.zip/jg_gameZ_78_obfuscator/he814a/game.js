var s1 = wx.l$;
import 'Z_78main.js';