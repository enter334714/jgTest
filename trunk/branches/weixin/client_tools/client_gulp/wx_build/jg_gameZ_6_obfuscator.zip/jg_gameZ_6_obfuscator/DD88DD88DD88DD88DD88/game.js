var G = wx.$E;
import 'DD882MDD88IDD882.js';