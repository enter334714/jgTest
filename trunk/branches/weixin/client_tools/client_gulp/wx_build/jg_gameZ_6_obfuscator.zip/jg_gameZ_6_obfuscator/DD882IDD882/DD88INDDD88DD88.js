var G = wx.$E;
import Eckmb$ from '../DD88DD88basdDD88/DD885sdkDD88.js';window[G[580648]] = { 'wxVersion': window[G[580095]][G[580096]] }, window[G[580649]] = ![], window['E1_R'] = 0x1, window[G[580650]] = 0x1, window['E16R_'] = !![], window[G[580651]] = !![], window['E1CD6R_'] = '', window['E1R_'] = { 'base_cdn': G[580652], 'cdn': G[580652] }, E1R_[G[580653]] = {}, E1R_[G[580654]] = '0', E1R_[G[580167]] = window[G[580648]][G[580430]], E1R_[G[580201]] = '', E1R_['os'] = '1', E1R_[G[580655]] = G[580656], E1R_[G[580657]] = G[580658], E1R_[G[580659]] = G[580660], E1R_[G[580661]] = G[580662], E1R_[G[580663]] = G[580664], E1R_[G[580665]] = '1', E1R_[G[580483]] = '', E1R_[G[580666]] = '', E1R_[G[580667]] = 0x0, E1R_[G[580522]] = {}, E1R_[G[580668]] = parseInt(E1R_[G[580665]]), E1R_[G[580669]] = E1R_[G[580665]], E1R_[G[580111]] = {}, E1R_['E1DR'] = G[580670], E1R_[G[580671]] = ![], E1R_[G[580672]] = G[580673], E1R_[G[580674]] = Date[G[580371]](), E1R_[G[580675]] = G[580676], E1R_[G[580677]] = '_a', E1R_[G[580416]] = 0x2, E1R_[G[580109]] = 0x7c1, E1R_[G[580430]] = window[G[580648]][G[580430]], E1R_[G[580678]] = ![], E1R_[G[580194]] = ![], E1R_[G[580197]] = ![], E1R_[G[580199]] = ![], window['E16_R'] = 0x5, window['E16_'] = ![], window['E1_6'] = ![], window['E1R6_'] = ![], window[G[580598]] = ![], window[G[580601]] = ![], window['E1R_6'] = ![], window['E16R'] = ![], window['E1R6'] = ![], window['E1_6R'] = ![], window[G[580679]] = function (di) {
  console[G[580129]](G[580679], di), wx[G[580680]]({}), wx[G[580136]]({ 'title': G[580159], 'content': di, 'success'(cb4m7) {
      if (cb4m7[G[580681]]) console[G[580129]](G[580682]);else cb4m7[G[580683]] && console[G[580129]](G[580684]);
    } });
}, window['E1D6R_'] = function (awv8r) {
  console[G[580129]](G[580685], awv8r), E1DR_6(), wx[G[580136]]({ 'title': G[580159], 'content': awv8r, 'confirmText': G[580686], 'cancelText': G[580687], 'success'(fw87m) {
      if (fw87m[G[580681]]) window['E1RD']();else fw87m[G[580683]] && (console[G[580129]](G[580688]), wx[G[580689]]({}));
    } });
}, window[G[580690]] = function (b7m4c) {
  console[G[580129]](G[580690], b7m4c), wx[G[580136]]({ 'title': G[580159], 'content': b7m4c, 'confirmText': G[580691], 'showCancel': ![], 'complete'(h9agqu) {
      console[G[580129]](G[580688]), wx[G[580689]]({});
    } });
}, window['E1D6_R'] = ![], window['E1DR6_'] = function (mk$bc) {
  window['E1D6_R'] = !![], wx[G[580692]](mk$bc);
}, window['E1DR_6'] = function () {
  window['E1D6_R'] && (window['E1D6_R'] = ![], wx[G[580680]]({}));
}, window['E1D_6R'] = function (s2_0t3) {
  window[G[580122]][G[580123]]['E1D_6R'](s2_0t3);
}, window[G[580085]] = function (rqvua, huypg9) {
  Eckmb$[G[580085]](rqvua, function (m$k4c) {
    m$k4c && m$k4c[G[580532]] ? m$k4c[G[580532]][G[580531]] == 0x1 ? huypg9(!![]) : (huypg9(![]), console[G[580090]](G[580693] + m$k4c[G[580532]][G[580694]])) : console[G[580129]](G[580085], m$k4c);
  });
}, window['E1D_R6'] = function (pau) {
  console[G[580129]](G[580695], pau);
}, window['E1DR_'] = function (a9ghup) {}, window['E1D_R'] = function (wurv, wruvqa, hyg9n) {}, window['E1D_'] = function (sd1it_) {
  console[G[580129]](G[580696], sd1it_), window[G[580122]][G[580123]][G[580420]](), window[G[580122]][G[580123]][G[580421]](), window[G[580122]][G[580123]][G[580434]]();
}, window['E1_D'] = function (auq) {
  window['E1D6R_'](G[580697]);var k5d6 = { 'id': window['E1R_'][G[580105]], 'role': window['E1R_'][G[580106]], 'level': window['E1R_'][G[580107]], 'account': window['E1R_'][G[580108]], 'version': window['E1R_'][G[580109]], 'cdn': window['E1R_'][G[580110]], 'pkgName': window['E1R_'][G[580483]], 'gamever': window[G[580095]][G[580096]], 'serverid': window['E1R_'][G[580111]] ? window['E1R_'][G[580111]][G[580068]] : 0x0, 'systemInfo': window[G[580112]], 'error': G[580698], 'stack': auq ? auq : G[580697] },
      tj = JSON[G[580114]](k5d6);console[G[580115]](G[580699] + tj), window['E1DR'](tj);
}, window['E1RD_'] = function (qrwv8f) {
  var gh9pu = JSON[G[580700]](qrwv8f);gh9pu[G[580701]] = window[G[580095]][G[580096]], gh9pu[G[580702]] = window['E1R_'][G[580111]] ? window['E1R_'][G[580111]][G[580068]] : 0x0, gh9pu[G[580112]] = window[G[580112]];var qfw8rv = JSON[G[580114]](gh9pu);console[G[580115]](G[580703] + qfw8rv), window['E1DR'](qfw8rv);
}, window['E1R_D'] = function (b$k6, aq9hu) {
  var xnlgpy = { 'id': window['E1R_'][G[580105]], 'role': window['E1R_'][G[580106]], 'level': window['E1R_'][G[580107]], 'account': window['E1R_'][G[580108]], 'version': window['E1R_'][G[580109]], 'cdn': window['E1R_'][G[580110]], 'pkgName': window['E1R_'][G[580483]], 'gamever': window[G[580095]][G[580096]], 'serverid': window['E1R_'][G[580111]] ? window['E1R_'][G[580111]][G[580068]] : 0x0, 'systemInfo': window[G[580112]], 'error': b$k6, 'stack': aq9hu },
      b$4mck = JSON[G[580114]](xnlgpy);console[G[580635]](G[580704] + b$4mck), window['E1DR'](b$4mck);
}, window['E1DR'] = function (mc4kb$) {
  if (window['E1R_'][G[580202]] == G[580705]) return;var qvfwr8 = E1R_['E1DR'] + G[580706] + E1R_[G[580108]];wx[G[580707]]({ 'url': qvfwr8, 'method': G[580028], 'data': mc4kb$, 'header': { 'content-type': G[580708], 'cache-control': G[580709] }, 'success': function (awvruq) {
      DEBUG && console[G[580129]](G[580710], qvfwr8, mc4kb$, awvruq);
    }, 'fail': function (kc64$5) {
      DEBUG && console[G[580129]](G[580710], qvfwr8, mc4kb$, kc64$5);
    }, 'complete': function () {} });
}, window[G[580711]] = function () {
  function uq9vra() {
    return ((0x1 + Math[G[580423]]()) * 0x10000 | 0x0)[G[580712]](0x10)[G[580713]](0x1);
  }return uq9vra() + uq9vra() + '-' + uq9vra() + '-' + uq9vra() + '-' + uq9vra() + '+' + uq9vra() + uq9vra() + uq9vra();
}, window['E1RD'] = function () {
  console[G[580129]](G[580714]);var quhag = Eckmb$[G[580715]]();E1R_[G[580669]] = quhag[G[580716]], E1R_[G[580668]] = quhag[G[580716]], E1R_[G[580665]] = quhag[G[580716]], E1R_[G[580483]] = quhag[G[580717]];var dsti_1 = { 'game_ver': E1R_[G[580167]] };E1R_[G[580666]] = this[G[580711]](), E1DR6_({ 'title': G[580718] }), Eckmb$[G[580080]](dsti_1, this['E1_DR'][G[580427]](this));
}, window['E1_DR'] = function (jd_it1) {
  var hr9uq = jd_it1[G[580719]];console[G[580129]](G[580720] + hr9uq + G[580721] + (hr9uq == 0x1) + G[580722] + jd_it1[G[580096]] + G[580723] + window[G[580648]][G[580430]]);if (!jd_it1[G[580096]] || window['E1C6_DR'](window[G[580648]][G[580430]], jd_it1[G[580096]]) < 0x0) console[G[580129]](G[580724]), E1R_[G[580657]] = G[580725], E1R_[G[580659]] = G[580726], E1R_[G[580661]] = G[580727], E1R_[G[580110]] = G[580728], E1R_[G[580729]] = G[580730], E1R_[G[580731]] = 'ty', E1R_[G[580678]] = ![];else window['E1C6_DR'](window[G[580648]][G[580430]], jd_it1[G[580096]]) == 0x0 ? (console[G[580129]](G[580732]), E1R_[G[580657]] = G[580658], E1R_[G[580659]] = G[580660], E1R_[G[580661]] = G[580662], E1R_[G[580110]] = G[580733], E1R_[G[580729]] = G[580730], E1R_[G[580731]] = G[580734], E1R_[G[580678]] = !![]) : (console[G[580129]](G[580735]), E1R_[G[580657]] = G[580658], E1R_[G[580659]] = G[580660], E1R_[G[580661]] = G[580662], E1R_[G[580110]] = G[580733], E1R_[G[580729]] = G[580730], E1R_[G[580731]] = G[580734], E1R_[G[580678]] = ![]);E1R_[G[580667]] = config[G[580736]] ? config[G[580736]] : 0x0, this['E16RD_'](), this['E16R_D'](), window[G[580737]] = 0x5, E1DR6_({ 'title': G[580738] }), Eckmb$[G[580012]](this['E1_RD'][G[580427]](this));
}, window[G[580737]] = 0x5, window['E1_RD'] = function (m4$, kjd56i) {
  if (m4$ == 0x0 && kjd56i && kjd56i[G[580739]]) {
    E1R_[G[580740]] = kjd56i[G[580739]];var $46 = this;E1DR6_({ 'title': G[580741] }), sendApi(E1R_[G[580657]], G[580742], { 'platform': E1R_[G[580655]], 'partner_id': E1R_[G[580665]], 'token': kjd56i[G[580739]], 'game_pkg': E1R_[G[580483]], 'deviceId': E1R_[G[580666]], 'scene': G[580743] + E1R_[G[580667]] }, this['E16DR_'][G[580427]](this), E16_R, E1_D);
  } else kjd56i && kjd56i[G[580146]] && window[G[580737]] > 0x0 && (kjd56i[G[580146]][G[580195]](G[580744]) != -0x1 || kjd56i[G[580146]][G[580195]](G[580745]) != -0x1 || kjd56i[G[580146]][G[580195]](G[580746]) != -0x1 || kjd56i[G[580146]][G[580195]](G[580747]) != -0x1 || kjd56i[G[580146]][G[580195]](G[580748]) != -0x1 || kjd56i[G[580146]][G[580195]](G[580749]) != -0x1) ? (window[G[580737]]--, Eckmb$[G[580012]](this['E1_RD'][G[580427]](this))) : (window['E1R_D'](G[580750], JSON[G[580114]]({ 'status': m4$, 'data': kjd56i })), window['E1D6R_'](G[580751] + (kjd56i && kjd56i[G[580146]] ? '，' + kjd56i[G[580146]] : '')));
}, window['E16DR_'] = function (m8fvw7) {
  if (!m8fvw7) {
    window['E1R_D'](G[580752], G[580753]), window['E1D6R_'](G[580754]);return;
  }if (m8fvw7[G[580531]] != G[580530]) {
    window['E1R_D'](G[580752], JSON[G[580114]](m8fvw7)), window['E1D6R_'](G[580755] + m8fvw7[G[580531]]);return;
  }E1R_[G[580021]] = String(m8fvw7[G[580108]]), E1R_[G[580108]] = String(m8fvw7[G[580108]]), E1R_[G[580171]] = String(m8fvw7[G[580171]]), E1R_[G[580669]] = String(m8fvw7[G[580171]]), E1R_[G[580756]] = String(m8fvw7[G[580756]]), E1R_[G[580757]] = String(m8fvw7[G[580020]]), E1R_[G[580758]] = String(m8fvw7[G[580759]]), E1R_[G[580020]] = '';var fwr78v = this;E1DR6_({ 'title': G[580760] }), sendApi(E1R_[G[580657]], G[580761], { 'partner_id': E1R_[G[580665]], 'uid': E1R_[G[580108]], 'version': E1R_[G[580167]], 'game_pkg': E1R_[G[580483]], 'device': E1R_[G[580666]] }, fwr78v['E16D_R'][G[580427]](fwr78v), E16_R, E1_D);
}, window['E16D_R'] = function (m$bc47) {
  if (!m$bc47) {
    window['E1D6R_'](G[580762]);return;
  }if (m$bc47[G[580531]] != G[580530]) {
    window['E1D6R_'](G[580763] + m$bc47[G[580531]]);return;
  }if (!m$bc47[G[580532]] || m$bc47[G[580532]][G[580099]] == 0x0) {
    window['E1D6R_'](G[580764]);return;
  }E1R_[G[580607]] = m$bc47[G[580765]], E1R_[G[580111]] = { 'server_id': String(m$bc47[G[580532]][0x0][G[580068]]), 'server_name': String(m$bc47[G[580532]][0x0][G[580510]]), 'entry_ip': m$bc47[G[580532]][0x0][G[580766]], 'entry_port': parseInt(m$bc47[G[580532]][0x0][G[580767]]), 'status': E1R6D(m$bc47[G[580532]][0x0]), 'start_time': m$bc47[G[580532]][0x0][G[580768]], 'cdn': E1R_[G[580110]] }, this['E1_R6D']();
}, window['E1_R6D'] = function () {
  if (E1R_[G[580607]] == 0x1) {
    var i5_1jd = E1R_[G[580111]][G[580509]];if (i5_1jd === -0x1 || i5_1jd === 0x0) {
      window['E1D6R_'](i5_1jd === -0x1 ? G[580769] : G[580770]);return;
    }E1_D6R(0x0, E1R_[G[580111]][G[580068]]), window[G[580122]][G[580123]][G[580602]](E1R_[G[580607]]);
  } else window[G[580122]][G[580123]][G[580599]](), E1DR_6();window['E1R6'] = !![], window['E1_6RD'](), window['E1_RD6']();
}, window['E16RD_'] = function () {
  sendApi(E1R_[G[580657]], G[580771], { 'game_pkg': E1R_[G[580483]], 'version_name': E1R_[G[580731]] }, this[G[580772]][G[580427]](this), E16_R, E1_D);
}, window[G[580772]] = function (cb$mk) {
  if (!cb$mk) {
    window['E1D6R_'](G[580773]);return;
  }if (cb$mk[G[580531]] != G[580530]) {
    window['E1D6R_'](G[580774] + cb$mk[G[580531]]);return;
  }if (!cb$mk[G[580532]] || !cb$mk[G[580532]][G[580167]]) {
    window['E1D6R_'](G[580775] + (cb$mk[G[580532]] && cb$mk[G[580532]][G[580167]]));return;
  }cb$mk[G[580532]][G[580776]] && cb$mk[G[580532]][G[580776]][G[580099]] > 0xa && (E1R_[G[580777]] = cb$mk[G[580532]][G[580776]], E1R_[G[580110]] = cb$mk[G[580532]][G[580776]]), cb$mk[G[580532]][G[580167]] && (E1R_[G[580109]] = cb$mk[G[580532]][G[580167]]), console[G[580090]](G[580778] + E1R_[G[580109]] + G[580779] + E1R_[G[580731]]), window['E1R_6'] = !![], window['E1_6RD'](), window['E1_RD6']();
}, window[G[580780]], window['E16R_D'] = function () {
  sendApi(E1R_[G[580657]], G[580781], { 'game_pkg': E1R_[G[580483]] }, this['E16_DR'][G[580427]](this), E16_R, E1_D);
}, window['E16_DR'] = function (puh9yg) {
  if (puh9yg[G[580531]] === G[580530] && puh9yg[G[580532]]) {
    window[G[580780]] = puh9yg[G[580532]];for (var hygpn in puh9yg[G[580532]]) {
      E1R_[hygpn] = puh9yg[G[580532]][hygpn];
    }
  } else console[G[580090]](G[580782] + puh9yg[G[580531]]);window['E16R'] = !![], window['E1_RD6']();
}, window[G[580783]] = function (y9hpug, t21_si, xplygn, hgua, $mb74c, pahu9g, b7cf, uhr9, puh9a) {
  $mb74c = String($mb74c);var wm8fv = b7cf,
      $64cbk = uhr9;E1R_[G[580653]][$mb74c] = { 'productid': $mb74c, 'productname': wm8fv, 'productdesc': $64cbk, 'roleid': y9hpug, 'rolename': t21_si, 'rolelevel': xplygn, 'price': pahu9g, 'callback': puh9a }, sendApi(E1R_[G[580661]], G[580784], { 'game_pkg': E1R_[G[580483]], 'server_id': E1R_[G[580111]][G[580068]], 'server_name': E1R_[G[580111]][G[580510]], 'level': xplygn, 'uid': E1R_[G[580108]], 'role_id': y9hpug, 'role_name': t21_si, 'product_id': $mb74c, 'product_name': wm8fv, 'product_desc': $64cbk, 'money': pahu9g, 'partner_id': E1R_[G[580665]] }, toPayCallBack, E16_R, E1_D);
}, window[G[580785]] = function (mkcb4) {
  if (mkcb4) {
    if (mkcb4[G[580786]] === 0xc8 || mkcb4[G[580531]] == G[580530]) {
      var m$c7b = E1R_[G[580653]][String(mkcb4[G[580787]])];if (m$c7b[G[580788]]) m$c7b[G[580788]](mkcb4[G[580787]], mkcb4[G[580789]], -0x1);Eckmb$[G[580058]]({ 'cpbill': mkcb4[G[580789]], 'productid': mkcb4[G[580787]], 'productname': m$c7b[G[580790]], 'productdesc': m$c7b[G[580791]], 'serverid': E1R_[G[580111]][G[580068]], 'servername': E1R_[G[580111]][G[580510]], 'roleid': m$c7b[G[580792]], 'rolename': m$c7b[G[580793]], 'rolelevel': m$c7b[G[580794]], 'price': m$c7b[G[580795]], 'extension': JSON[G[580114]]({ 'cp_order_id': mkcb4[G[580789]] }) }, function (pxolny, rvwua) {
        m$c7b[G[580788]] && pxolny == 0x0 && m$c7b[G[580788]](mkcb4[G[580787]], mkcb4[G[580789]], pxolny);console[G[580090]](JSON[G[580114]]({ 'type': G[580796], 'status': pxolny, 'data': mkcb4, 'role_name': m$c7b[G[580793]] }));if (pxolny === 0x0) {} else {
          if (pxolny === 0x1) {} else {
            if (pxolny === 0x2) {}
          }
        }
      });
    } else alert(mkcb4[G[580090]]);
  }
}, window['E16_RD'] = function () {}, window['E1D6_'] = function (auhq9g, j5ck, i2t1, ugahp, gah9p) {
  Eckmb$[G[580082]](E1R_[G[580111]][G[580068]], E1R_[G[580111]][G[580510]] || E1R_[G[580111]][G[580068]], auhq9g, j5ck, i2t1), sendApi(E1R_[G[580657]], G[580797], { 'game_pkg': E1R_[G[580483]], 'server_id': E1R_[G[580111]][G[580068]], 'role_id': auhq9g, 'uid': E1R_[G[580108]], 'role_name': j5ck, 'role_type': ugahp, 'level': i2t1 });
}, window['E1D_6'] = function (jdk$, k$c4bm, pnyh9g, bwm8f7, $6b4ck, nglxy, sitd1, q9gauh, hq9uar, ypxonl) {
  E1R_[G[580105]] = jdk$, E1R_[G[580106]] = k$c4bm, E1R_[G[580107]] = pnyh9g, Eckmb$[G[580083]](E1R_[G[580111]][G[580068]], E1R_[G[580111]][G[580510]] || E1R_[G[580111]][G[580068]], jdk$, k$c4bm, pnyh9g), sendApi(E1R_[G[580657]], G[580798], { 'game_pkg': E1R_[G[580483]], 'server_id': E1R_[G[580111]][G[580068]], 'role_id': jdk$, 'uid': E1R_[G[580108]], 'role_name': k$c4bm, 'role_type': bwm8f7, 'level': pnyh9g, 'evolution': $6b4ck });
}, window['E16D_'] = function (cb46$k, pnghly, m7b4fc, m$4bc, qravu, d156j, $k6dj, mb4$ck, _12ist, j_51) {
  E1R_[G[580105]] = cb46$k, E1R_[G[580106]] = pnghly, E1R_[G[580107]] = m7b4fc, Eckmb$[G[580084]](E1R_[G[580111]][G[580068]], E1R_[G[580111]][G[580510]] || E1R_[G[580111]][G[580068]], cb46$k, pnghly, m7b4fc), sendApi(E1R_[G[580657]], G[580798], { 'game_pkg': E1R_[G[580483]], 'server_id': E1R_[G[580111]][G[580068]], 'role_id': cb46$k, 'uid': E1R_[G[580108]], 'role_name': pnghly, 'role_type': m$4bc, 'level': m7b4fc, 'evolution': qravu });
}, window['E16_D'] = function (yxlng) {}, window['E1D6'] = function (_ts2i) {
  Eckmb$[G[580039]](G[580039], function (xpnloy) {
    _ts2i && _ts2i(xpnloy);
  });
}, window[G[580081]] = function () {
  Eckmb$[G[580081]]();
}, window[G[580799]] = function () {
  Eckmb$[G[580088]]();
}, window[G[580800]] = function (wm7v, it_d, t_1jdi, ylpgn, $56jkd, _t13, vrwqua, vfr7) {
  vfr7 = vfr7 || E1R_[G[580111]][G[580068]], sendApi(E1R_[G[580657]], G[580801], { 'phone': wm7v, 'role_id': it_d, 'uid': E1R_[G[580108]], 'game_pkg': E1R_[G[580483]], 'partner_id': E1R_[G[580665]], 'server_id': vfr7 }, vrwqua);
}, window[G[580222]] = function (kcj65) {
  window['E1_D6'] = kcj65, window['E1_D6'] && window['E16D'] && (console[G[580090]](G[580223] + window['E16D'][G[580224]]), window['E1_D6'](window['E16D']), window['E16D'] = null);
}, window['E1_6D'] = function (vwq8ra, y9hnpg, bfm4, v8wr7) {
  window[G[580802]](G[580803], { 'game_pkg': window['E1R_'][G[580483]], 'role_id': y9hnpg, 'server_id': bfm4 }, v8wr7);
}, window['E1RD6_'] = function (ki65, _t02) {
  function avr8(cm$7b4) {
    var gp9hua = [],
        $4cbm = [],
        mc$4k = window[G[580095]][G[580804]];for (var lpxng in mc$4k) {
      var ijd6k = Number(lpxng);(!ki65 || !ki65[G[580099]] || ki65[G[580195]](ijd6k) != -0x1) && ($4cbm[G[580126]](mc$4k[lpxng]), gp9hua[G[580126]]([ijd6k, 0x3]));
    }window['E1C6_DR'](window[G[580127]], G[580805]) >= 0x0 ? (console[G[580129]](G[580806]), Eckmb$[G[580807]] && Eckmb$[G[580807]]($4cbm, function (pguy9) {
      console[G[580129]](G[580808]), console[G[580129]](pguy9);if (pguy9 && pguy9[G[580146]] == G[580809]) for (var s1tid_ in mc$4k) {
        if (pguy9[mc$4k[s1tid_]] == G[580810]) {
          var ypgln = Number(s1tid_);for (var oxypln = 0x0; oxypln < gp9hua[G[580099]]; oxypln++) {
            if (gp9hua[oxypln][0x0] == ypgln) {
              gp9hua[oxypln][0x1] = 0x1;break;
            }
          }
        }
      }window['E1C6_DR'](window[G[580127]], G[580811]) >= 0x0 ? wx[G[580812]]({ 'withSubscriptions': !![], 'success': function (xno) {
          var kc4 = xno[G[580813]][G[580814]];if (kc4) {
            console[G[580129]](G[580815]), console[G[580129]](kc4);for (var _sit2 in mc$4k) {
              if (kc4[mc$4k[_sit2]] == G[580810]) {
                var v8qwf = Number(_sit2);for (var d5j1i = 0x0; d5j1i < gp9hua[G[580099]]; d5j1i++) {
                  if (gp9hua[d5j1i][0x0] == v8qwf) {
                    gp9hua[d5j1i][0x1] = 0x2;break;
                  }
                }
              }
            }console[G[580129]](gp9hua), _t02 && _t02(gp9hua);
          } else console[G[580129]](G[580816]), console[G[580129]](xno), console[G[580129]](gp9hua), _t02 && _t02(gp9hua);
        }, 'fail': function () {
          console[G[580129]](G[580817]), console[G[580129]](gp9hua), _t02 && _t02(gp9hua);
        } }) : (console[G[580129]](G[580818] + window[G[580127]]), console[G[580129]](gp9hua), _t02 && _t02(gp9hua));
    })) : (console[G[580129]](G[580819] + window[G[580127]]), console[G[580129]](gp9hua), _t02 && _t02(gp9hua)), wx[G[580820]](avr8);
  }wx[G[580821]](avr8);
}, window['E1RD_6'] = { 'isSuccess': ![], 'level': G[580822], 'isCharging': ![] }, window['E1R6D_'] = function (lxgnyp) {
  wx[G[580210]]({ 'success': function (arvq9) {
      var lpynx = window['E1RD_6'];lpynx[G[580823]] = !![], lpynx[G[580212]] = Number(arvq9[G[580212]])[G[580824]](0x0), lpynx[G[580214]] = arvq9[G[580214]], lxgnyp && lxgnyp(lpynx[G[580823]], lpynx[G[580212]], lpynx[G[580214]]);
    }, 'fail': function (bm7c4) {
      console[G[580129]](G[580825], bm7c4[G[580146]]);var _3s1t2 = window['E1RD_6'];lxgnyp && lxgnyp(_3s1t2[G[580823]], _3s1t2[G[580212]], _3s1t2[G[580214]]);
    } });
}, window[G[580802]] = function (a8wvq, c$j6, ghqua9, nhgply, bck$4m, _31t2s, yuh, _di1ts) {
  if (nhgply == undefined) nhgply = 0x1;wx[G[580707]]({ 'url': a8wvq, 'method': yuh || G[580826], 'responseType': G[580425], 'data': c$j6, 'header': { 'content-type': _di1ts || G[580708] }, 'success': function (mbf4) {
      DEBUG && console[G[580129]](G[580827], a8wvq, info, mbf4);if (mbf4 && mbf4[G[580016]] == 0xc8) {
        var nyhp9g = mbf4[G[580532]];!_31t2s || _31t2s(nyhp9g) ? ghqua9 && ghqua9(nyhp9g) : window[G[580828]](a8wvq, c$j6, ghqua9, nhgply, bck$4m, _31t2s, mbf4);
      } else window[G[580828]](a8wvq, c$j6, ghqua9, nhgply, bck$4m, _31t2s, mbf4);
    }, 'fail': function (uag9p) {
      DEBUG && console[G[580129]](G[580829], a8wvq, info, uag9p), window[G[580828]](a8wvq, c$j6, ghqua9, nhgply, bck$4m, _31t2s, uag9p);
    }, 'complete': function () {} });
}, window[G[580828]] = function (t02_s3, m7fc4b, t_231s, rahuq, rfvq, jk6c5$, gyp9hu) {
  rahuq - 0x1 > 0x0 ? setTimeout(function () {
    window[G[580802]](t02_s3, m7fc4b, t_231s, rahuq - 0x1, rfvq, jk6c5$);
  }, 0x3e8) : rfvq && rfvq(JSON[G[580114]]({ 'url': t02_s3, 'response': gyp9hu }));
}, window[G[580830]] = function (uarqh, _51id, quv, rauvq, rwvfq8, lnhypg, nlxgyp) {
  !quv && (quv = {});var $dj56 = Math[G[580619]](Date[G[580371]]() / 0x3e8);quv[G[580759]] = $dj56, quv[G[580831]] = _51id;var lnopxy = Object[G[580832]](quv)[G[580536]](),
      avqu = '',
      uphg9 = '';for (var qw8vr = 0x0; qw8vr < lnopxy[G[580099]]; qw8vr++) {
    avqu = avqu + (qw8vr == 0x0 ? '' : '&') + lnopxy[qw8vr] + quv[lnopxy[qw8vr]], uphg9 = uphg9 + (qw8vr == 0x0 ? '' : '&') + lnopxy[qw8vr] + '=' + encodeURIComponent(quv[lnopxy[qw8vr]]);
  }avqu = avqu + E1R_[G[580663]];var j6i5k = G[580833] + md5(avqu);send(uarqh + '?' + uphg9 + (uphg9 == '' ? '' : '&') + j6i5k, null, rauvq, rwvfq8, lnhypg, nlxgyp || function (jd5_) {
    return jd5_[G[580531]] == G[580530];
  }, null, G[580030]);
}, window['E1R6_D'] = function (f8b7m4, vqr8aw) {
  var yhpngl = 0x0;E1R_[G[580111]] && (yhpngl = E1R_[G[580111]][G[580068]]), sendApi(E1R_[G[580659]], G[580834], { 'partnerId': E1R_[G[580665]], 'gamePkg': E1R_[G[580483]], 'logTime': Math[G[580619]](Date[G[580371]]() / 0x3e8), 'platformUid': E1R_[G[580756]], 'type': f8b7m4, 'serverId': yhpngl }, null, 0x2, null, function () {
    return !![];
  });
}, window['E1R_D6'] = function (ah9ruq) {
  sendApi(E1R_[G[580657]], G[580835], { 'partner_id': E1R_[G[580665]], 'uid': E1R_[G[580108]], 'version': E1R_[G[580167]], 'game_pkg': E1R_[G[580483]], 'device': E1R_[G[580666]] }, E1R_6D, E16_R, E1_D);
}, window['E1R_6D'] = function (m7wvf) {
  if (m7wvf[G[580531]] === G[580530] && m7wvf[G[580532]]) {
    m7wvf[G[580532]][G[580836]]({ 'id': -0x2, 'name': G[580837] }), m7wvf[G[580532]][G[580836]]({ 'id': -0x1, 'name': G[580838] }), E1R_[G[580482]] = m7wvf[G[580532]];if (window[G[580474]]) window[G[580474]][G[580516]]();
  } else E1R_[G[580493]] = ![], window['E1D6R_'](G[580839] + m7wvf[G[580531]]);
}, window['E1D6R'] = function (j61i5d) {
  sendApi(E1R_[G[580657]], G[580840], { 'partner_id': E1R_[G[580665]], 'uid': E1R_[G[580108]], 'version': E1R_[G[580167]], 'game_pkg': E1R_[G[580483]], 'device': E1R_[G[580666]] }, E1DR6, E16_R, E1_D);
}, window['E1DR6'] = function (w7b8fm) {
  E1R_[G[580524]] = ![];if (w7b8fm[G[580531]] === G[580530] && w7b8fm[G[580532]]) {
    for (var ki6jd = 0x0; ki6jd < w7b8fm[G[580532]][G[580099]]; ki6jd++) {
      w7b8fm[G[580532]][ki6jd][G[580509]] = E1R6D(w7b8fm[G[580532]][ki6jd]);
    }E1R_[G[580522]][-0x1] = window[G[580841]](w7b8fm[G[580532]]), window[G[580474]][G[580523]](-0x1);
  } else window['E1D6R_'](G[580842] + w7b8fm[G[580531]]);
}, window[G[580843]] = function (olp) {
  sendApi(E1R_[G[580657]], G[580840], { 'partner_id': E1R_[G[580665]], 'uid': E1R_[G[580108]], 'version': E1R_[G[580167]], 'game_pkg': E1R_[G[580483]], 'device': E1R_[G[580666]] }, olp, E16_R, E1_D);
}, window['E16DR'] = function (_ts1i2, ji1d5_) {
  sendApi(E1R_[G[580657]], G[580844], { 'partner_id': E1R_[G[580665]], 'uid': E1R_[G[580108]], 'version': E1R_[G[580167]], 'game_pkg': E1R_[G[580483]], 'device': E1R_[G[580666]], 'server_group_id': ji1d5_ }, E16RD, E16_R, E1_D);
}, window['E16RD'] = function ($5jd6k) {
  E1R_[G[580524]] = ![];if ($5jd6k[G[580531]] === G[580530] && $5jd6k[G[580532]] && $5jd6k[G[580532]][G[580532]]) {
    var _t1ids = $5jd6k[G[580532]][G[580845]],
        t_j1id = [];for (var gah9uq = 0x0; gah9uq < $5jd6k[G[580532]][G[580532]][G[580099]]; gah9uq++) {
      $5jd6k[G[580532]][G[580532]][gah9uq][G[580509]] = E1R6D($5jd6k[G[580532]][G[580532]][gah9uq]), (t_j1id[G[580099]] == 0x0 || $5jd6k[G[580532]][G[580532]][gah9uq][G[580509]] != 0x0) && (t_j1id[t_j1id[G[580099]]] = $5jd6k[G[580532]][G[580532]][gah9uq]);
    }E1R_[G[580522]][_t1ids] = window[G[580841]](t_j1id), window[G[580474]][G[580523]](_t1ids);
  } else window['E1D6R_'](G[580846] + $5jd6k[G[580531]]);
}, window['E1C6_R'] = function (raqvw8) {
  sendApi(E1R_[G[580657]], G[580847], { 'partner_id': E1R_[G[580665]], 'uid': E1R_[G[580108]], 'version': E1R_[G[580167]], 'game_pkg': E1R_[G[580483]], 'device': E1R_[G[580666]] }, reqServerRecommendCallBack, E16_R, E1_D);
}, window[G[580848]] = function (rq8wva) {
  E1R_[G[580524]] = ![];if (rq8wva[G[580531]] === G[580530] && rq8wva[G[580532]]) {
    for (var m4bc$ = 0x0; m4bc$ < rq8wva[G[580532]][G[580099]]; m4bc$++) {
      rq8wva[G[580532]][m4bc$][G[580509]] = E1R6D(rq8wva[G[580532]][m4bc$]);
    }E1R_[G[580522]][-0x2] = window[G[580841]](rq8wva[G[580532]]), window[G[580474]][G[580523]](-0x2);
  } else alert(G[580849] + rq8wva[G[580531]]);
}, window[G[580841]] = function (opnx) {
  if (!opnx && opnx[G[580099]] <= 0x0) return opnx;for (let nxgylp = 0x0; nxgylp < opnx[G[580099]]; nxgylp++) {
    opnx[nxgylp][G[580850]] && opnx[nxgylp][G[580850]] == 0x1 && (opnx[nxgylp][G[580510]] += G[580851]);
  }return opnx;
}, window['E1RD6'] = function ($4kcm, vf8r) {
  $4kcm = $4kcm || E1R_[G[580111]][G[580068]], sendApi(E1R_[G[580657]], G[580852], { 'type': '4', 'game_pkg': E1R_[G[580483]], 'server_id': $4kcm }, vf8r);
}, window[G[580853]] = function (t_d1ij, di1_j, _tid1, k$jd56) {
  _tid1 = _tid1 || E1R_[G[580111]][G[580068]], sendApi(E1R_[G[580657]], G[580854], { 'type': t_d1ij, 'game_pkg': di1_j, 'server_id': _tid1 }, k$jd56);
}, window['E1R6D'] = function (_ist21) {
  if (_ist21) {
    if (_ist21[G[580509]] == 0x1) {
      if (_ist21[G[580855]] == 0x1) return 0x2;else return 0x1;
    } else return _ist21[G[580509]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['E1_D6R'] = function (pylhng, c$k4) {
  E1R_[G[580856]] = { 'step': pylhng, 'server_id': c$k4 };var ijtd = this;E1DR6_({ 'title': G[580857] }), sendApi(E1R_[G[580657]], G[580858], { 'partner_id': E1R_[G[580665]], 'uid': E1R_[G[580108]], 'game_pkg': E1R_[G[580483]], 'server_id': c$k4, 'platform': E1R_[G[580171]], 'platform_uid': E1R_[G[580756]], 'check_login_time': E1R_[G[580758]], 'check_login_sign': E1R_[G[580757]], 'version_name': E1R_[G[580731]] }, E1_DR6, E16_R, E1_D, function (b4$c6k) {
    return b4$c6k[G[580531]] == G[580530] || b4$c6k[G[580090]] == G[580859] || b4$c6k[G[580090]] == G[580860];
  });
}, window['E1_DR6'] = function (s320t_) {
  var vrqa9 = this;if (s320t_[G[580531]] === G[580530] && s320t_[G[580532]]) {
    var d1_ts = E1R_[G[580111]];d1_ts[G[580861]] = E1R_[G[580668]], d1_ts[G[580020]] = String(s320t_[G[580532]][G[580862]]), d1_ts[G[580674]] = parseInt(s320t_[G[580532]][G[580759]]);if (s320t_[G[580532]][G[580863]]) d1_ts[G[580863]] = parseInt(s320t_[G[580532]][G[580863]]);else d1_ts[G[580863]] = parseInt(s320t_[G[580532]][G[580068]]);d1_ts[G[580864]] = 0x0, d1_ts[G[580110]] = E1R_[G[580777]], d1_ts[G[580865]] = s320t_[G[580532]][G[580866]], d1_ts[G[580867]] = s320t_[G[580532]][G[580867]], console[G[580129]](G[580868] + JSON[G[580114]](d1_ts[G[580867]])), E1R_[G[580607]] == 0x1 && d1_ts[G[580867]] && d1_ts[G[580867]][G[580869]] == 0x1 && (E1R_[G[580431]] = 0x1, window[G[580122]][G[580123]]['E1C_R']()), E1_6DR();
  } else E1R_[G[580856]][G[580870]] >= 0x3 ? (E1_D(JSON[G[580114]](s320t_)), window['E1D6R_'](G[580871] + s320t_[G[580531]])) : sendApi(E1R_[G[580657]], G[580742], { 'platform': E1R_[G[580655]], 'partner_id': E1R_[G[580665]], 'token': E1R_[G[580740]], 'game_pkg': E1R_[G[580483]], 'deviceId': E1R_[G[580666]], 'scene': G[580743] + E1R_[G[580667]] }, function (vqr9ua) {
    if (!vqr9ua || vqr9ua[G[580531]] != G[580530]) {
      window['E1D6R_'](G[580755] + vqr9ua && vqr9ua[G[580531]]);return;
    }E1R_[G[580757]] = String(vqr9ua[G[580020]]), E1R_[G[580758]] = String(vqr9ua[G[580759]]), setTimeout(function () {
      E1_D6R(E1R_[G[580856]][G[580870]] + 0x1, E1R_[G[580856]][G[580068]]);
    }, 0x5dc);
  }, E16_R, E1_D, function (cm) {
    return cm[G[580531]] == G[580530] || cm[G[580531]] == G[580872];
  });
}, window['E1_6DR'] = function () {
  ServerLoading[G[580123]][G[580602]](E1R_[G[580607]]), window['E16_'] = !![], window['E1_RD6']();
}, window['E1_6RD'] = function () {
  if (window['E1_6'] && window['E1R6_'] && window[G[580598]] && window[G[580601]] && window['E1R_6'] && window['E1R6']) {
    if (!window[G[580873]][G[580123]]) {
      console[G[580129]](G[580874] + window[G[580873]][G[580123]]);var vr7w = wx[G[580875]](),
          vq8 = vr7w[G[580224]] ? vr7w[G[580224]] : 0x0,
          jd$56k = { 'cdn': window['E1R_'][G[580110]], 'spareCdn': window['E1R_'][G[580729]], 'newRegister': window['E1R_'][G[580607]], 'wxPC': window['E1R_'][G[580199]], 'wxIOS': window['E1R_'][G[580194]], 'wxAndroid': window['E1R_'][G[580197]], 'wxParam': { 'limitLoad': window['E1R_']['E1CD6_R'], 'benchmarkLevel': window['E1R_']['E1CDR6_'], 'wxFrom': window[G[580095]][G[580736]] == G[580876] ? 0x1 : 0x0, 'wxSDKVersion': window[G[580127]] }, 'configType': window['E1R_'][G[580675]], 'exposeType': window['E1R_'][G[580677]], 'scene': vq8 };new window[G[580873]](jd$56k, window['E1R_'][G[580109]], window['E1CD6R_']);
    }
  }
}, window['E1_RD6'] = function () {
  if (window['E1_6'] && window['E1R6_'] && window[G[580598]] && window[G[580601]] && window['E1R_6'] && window['E1R6'] && window['E16_'] && window['E16R']) {
    E1DR_6();if (!E1_6R) {
      E1_6R = !![];if (!window[G[580873]][G[580123]]) window['E1_6RD']();var fmb48 = 0x0,
          _istd1 = wx[G[580877]]();_istd1 && (window['E1R_'][G[580198]] && (fmb48 = _istd1[G[580189]]), console[G[580090]](G[580878] + _istd1[G[580189]] + G[580879] + _istd1[G[580190]] + G[580880] + _istd1[G[580191]] + G[580881] + _istd1[G[580192]] + G[580882] + _istd1[G[580394]] + G[580883] + _istd1[G[580396]]));var q9aru = {};for (const jid5k in E1R_[G[580111]]) {
        q9aru[jid5k] = E1R_[G[580111]][jid5k];
      }var f4m7 = { 'channel': window['E1R_'][G[580669]], 'account': window['E1R_'][G[580108]], 'userId': window['E1R_'][G[580021]], 'serverId': q9aru[G[580068]], 'cdn': window['E1R_'][G[580110]], 'data': window['E1R_'][G[580532]], 'package': window['E1R_'][G[580654]], 'newRegister': window['E1R_'][G[580607]], 'pkgName': window['E1R_'][G[580483]], 'partnerId': window['E1R_'][G[580665]], 'platform_uid': window['E1R_'][G[580756]], 'deviceId': window['E1R_'][G[580666]], 'selectedServer': q9aru, 'configType': window['E1R_'][G[580675]], 'exposeType': window['E1R_'][G[580677]], 'debugUsers': window['E1R_'][G[580672]], 'wxMenuTop': fmb48, 'wxShield': window['E1R_'][G[580678]] };if (window[G[580780]]) for (var di_1st in window[G[580780]]) {
        f4m7[di_1st] = window[G[580780]][di_1st];
      }window[G[580873]][G[580123]]['E1_RC'](f4m7);
    }
  } else console[G[580090]](G[580884] + window['E1_6'] + G[580885] + window['E1R6_'] + G[580886] + window[G[580598]] + G[580887] + window[G[580601]] + G[580888] + window['E1R_6'] + G[580889] + window['E1R6'] + G[580890] + window['E16_'] + G[580891] + window['E16R']);
};