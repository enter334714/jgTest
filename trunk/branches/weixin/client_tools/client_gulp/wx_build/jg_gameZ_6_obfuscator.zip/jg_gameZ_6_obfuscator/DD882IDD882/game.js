var G = wx.$E;
require(G[580892]);