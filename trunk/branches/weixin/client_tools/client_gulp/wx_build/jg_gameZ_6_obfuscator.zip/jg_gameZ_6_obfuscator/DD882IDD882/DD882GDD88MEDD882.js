var G = wx.$E;
console[G[580090]](G[580091]), window[G[580092]], wx[G[580093]](function (i6j15) {
  if (i6j15) {
    if (i6j15[G[580094]]) {
      var $m4bkc = window[G[580095]][G[580096]][G[580097]](new RegExp(/\./, 'g'), '_'),
          xylpo = i6j15[G[580094]],
          _2s0t = xylpo[G[580098]](/(DD88DD88DD88DD88DD88\/DD882GDD88MEDD882.js:)[0-9]{1,60}(:)/g);if (_2s0t) for (var ck46$ = 0x0; ck46$ < _2s0t[G[580099]]; ck46$++) {
        if (_2s0t[ck46$] && _2s0t[ck46$][G[580099]] > 0x0) {
          var _3st02 = parseInt(_2s0t[ck46$][G[580097]](G[580100], '')[G[580097]](':', ''));xylpo = xylpo[G[580097]](_2s0t[ck46$], _2s0t[ck46$][G[580097]](':' + _3st02 + ':', ':' + (_3st02 - 0x2) + ':'));
        }
      }xylpo = xylpo[G[580097]](new RegExp(G[580101], 'g'), G[580102] + $m4bkc + G[580103]), xylpo = xylpo[G[580097]](new RegExp(G[580104], 'g'), G[580102] + $m4bkc + G[580103]), i6j15[G[580094]] = xylpo;
    }var wfv7m8 = { 'id': window['E1R_'][G[580105]], 'role': window['E1R_'][G[580106]], 'level': window['E1R_'][G[580107]], 'user': window['E1R_'][G[580108]], 'version': window['E1R_'][G[580109]], 'gamever': window[G[580095]][G[580096]], 'cdn': window['E1R_'][G[580110]], 'serverid': window['E1R_'][G[580111]] ? window['E1R_'][G[580111]][G[580068]] : 0x0, 'systemInfo': window[G[580112]], 'error': G[580113], 'stack': i6j15 ? i6j15[G[580094]] : '' },
        jt_i1 = JSON[G[580114]](wfv7m8);console[G[580115]](G[580116] + jt_i1), (!window[G[580092]] || window[G[580092]] != wfv7m8[G[580115]]) && (window[G[580092]] = wfv7m8[G[580115]], window['E1DR'](wfv7m8));
  }
});import 'DD88DD88bfDD88DD88.js';import 'DD88DD8811DD88DD88.js';window[G[580117]] = require(G[580118]);import 'DD88INDDD88DD88.js';import 'DD88DD88IDD881DD88DD88.js';import 'DD88DD88MtadDD88DD88.js';import 'DD88DD88INIDD88aDD88.js';console[G[580090]](G[580119]), console[G[580090]](G[580120]), E1DR6_({ 'title': G[580121] });var Ewfr = { 'E1CD_R6': !![] };new window[G[580122]](Ewfr), window[G[580122]][G[580123]]['E1C6R_D']();if (window['E1CDR_6']) clearInterval(window['E1CDR_6']);window['E1CDR_6'] = null, window['E1C6_DR'] = function (uvwqra, haguq) {
  if (!uvwqra || !haguq) return 0x0;uvwqra = uvwqra[G[580124]]('.'), haguq = haguq[G[580124]]('.');const gnyph9 = Math[G[580125]](uvwqra[G[580099]], haguq[G[580099]]);while (uvwqra[G[580099]] < gnyph9) {
    uvwqra[G[580126]]('0');
  }while (haguq[G[580099]] < gnyph9) {
    haguq[G[580126]]('0');
  }for (var b4f7c = 0x0; b4f7c < gnyph9; b4f7c++) {
    const f8w7m = parseInt(uvwqra[b4f7c]),
          t_1jd = parseInt(haguq[b4f7c]);if (f8w7m > t_1jd) return 0x1;else {
      if (f8w7m < t_1jd) return -0x1;
    }
  }return 0x0;
}, window[G[580127]] = wx[G[580128]]()[G[580127]], console[G[580129]](G[580130] + window[G[580127]]);var Ei5j1_ = wx[G[580131]]();Ei5j1_[G[580132]](function ($jck) {
  console[G[580129]](G[580133] + $jck[G[580134]]);
}), Ei5j1_[G[580135]](function () {
  wx[G[580136]]({ 'title': G[580137], 'content': G[580138], 'showCancel': ![], 'success': function (t_dis) {
      Ei5j1_[G[580139]]();
    } });
}), Ei5j1_[G[580140]](function () {
  console[G[580129]](G[580141]);
}), window['E1C6_RD'] = function () {
  console[G[580129]](G[580142]);var n9hpgy = wx[G[580143]]({ 'name': G[580144], 'success': function (t032sz) {
      console[G[580129]](G[580145]), console[G[580129]](t032sz), t032sz && t032sz[G[580146]] == G[580147] ? (window['E1_6'] = !![], window['E1_6RD'](), window['E1_RD6']()) : setTimeout(function () {
        window['E1C6_RD']();
      }, 0x1f4);
    }, 'fail': function (hrau9) {
      console[G[580129]](G[580148]), console[G[580129]](hrau9), setTimeout(function () {
        window['E1C6_RD']();
      }, 0x1f4);
    } });n9hpgy && n9hpgy[G[580149]](_it1j => {});
}, window['E1CRD_6'] = function () {
  console[G[580129]](G[580150]);var mbcf = wx[G[580143]]({ 'name': G[580151], 'success': function (kj6d$5) {
      console[G[580129]](G[580152]), console[G[580129]](kj6d$5), kj6d$5 && kj6d$5[G[580146]] == G[580147] ? (window['E1R6_'] = !![], window['E1_6RD'](), window['E1_RD6']()) : setTimeout(function () {
        window['E1CRD_6']();
      }, 0x1f4);
    }, 'fail': function (lpgyx) {
      console[G[580129]](G[580153]), console[G[580129]](lpgyx), setTimeout(function () {
        window['E1CRD_6']();
      }, 0x1f4);
    } });mbcf && mbcf[G[580149]](w8r7 => {});
}, window[G[580154]] = function () {
  window['E1C6_DR'](window[G[580127]], G[580155]) >= 0x0 ? (console[G[580129]](G[580156] + window[G[580127]] + G[580157]), window['E1RD'](), window['E1C6_RD'](), window['E1CRD_6']()) : (window['E1R_D'](G[580158], window[G[580127]]), wx[G[580136]]({ 'title': G[580159], 'content': G[580160] }));
}, window[G[580112]] = '', wx[G[580161]]({ 'success'(xlygp) {
    window[G[580112]] = G[580162] + xlygp[G[580163]] + G[580164] + xlygp[G[580165]] + G[580166] + xlygp[G[580167]] + G[580168] + xlygp[G[580169]] + G[580170] + xlygp[G[580171]] + G[580172] + xlygp[G[580127]] + G[580173] + xlygp[G[580174]], console[G[580129]](window[G[580112]]), console[G[580129]](G[580175] + xlygp[G[580176]] + G[580177] + xlygp[G[580178]] + G[580179] + xlygp[G[580180]] + G[580181] + xlygp[G[580182]] + G[580183] + xlygp[G[580184]] + G[580185] + xlygp[G[580186]] + G[580187] + (xlygp[G[580188]] ? xlygp[G[580188]][G[580189]] + ',' + xlygp[G[580188]][G[580190]] + ',' + xlygp[G[580188]][G[580191]] + ',' + xlygp[G[580188]][G[580192]] : ''));var pghynl = xlygp[G[580169]] ? xlygp[G[580169]][G[580193]]() : '',
        b8wm7f = xlygp[G[580165]] ? xlygp[G[580165]][G[580193]]()[G[580097]]('\x20', '') : '';window['E1R_'][G[580194]] = pghynl[G[580195]](G[580196]) != -0x1, window['E1R_'][G[580197]] = pghynl[G[580195]](G[580076]) != -0x1, window['E1R_'][G[580198]] = pghynl[G[580195]](G[580196]) != -0x1 || pghynl[G[580195]](G[580076]) != -0x1, window['E1R_'][G[580199]] = pghynl[G[580195]](G[580200]) != -0x1 || pghynl[G[580195]](G[580201]) != -0x1, window['E1R_'][G[580202]] = xlygp[G[580171]] ? xlygp[G[580171]][G[580193]]() : '', window['E1R_']['E1CD6_R'] = ![], window['E1R_']['E1CDR6_'] = 0x2;if (pghynl[G[580195]](G[580076]) != -0x1) {
      if (xlygp[G[580174]] >= 0x18) window['E1R_']['E1CDR6_'] = 0x3;else window['E1R_']['E1CDR6_'] = 0x2;
    } else {
      if (pghynl[G[580195]](G[580196]) != -0x1) {
        if (xlygp[G[580174]] && xlygp[G[580174]] >= 0x14) window['E1R_']['E1CDR6_'] = 0x3;else {
          if (b8wm7f[G[580195]](G[580203]) != -0x1 || b8wm7f[G[580195]](G[580204]) != -0x1 || b8wm7f[G[580195]](G[580205]) != -0x1 || b8wm7f[G[580195]](G[580206]) != -0x1 || b8wm7f[G[580195]](G[580207]) != -0x1) window['E1R_']['E1CDR6_'] = 0x2;else window['E1R_']['E1CDR6_'] = 0x3;
        }
      } else window['E1R_']['E1CDR6_'] = 0x2;
    }console[G[580129]](G[580208] + window['E1R_']['E1CD6_R'] + G[580209] + window['E1R_']['E1CDR6_']);
  } }), wx[G[580210]]({ 'success': function (i6dj5k) {
    console[G[580129]](G[580211] + i6dj5k[G[580212]] + G[580213] + i6dj5k[G[580214]]);
  } }), wx[G[580215]]({ 'success': function (phyng) {
    console[G[580129]](G[580216] + phyng[G[580217]]);
  } }), wx[G[580218]]({ 'keepScreenOn': !![] }), wx[G[580219]](function (pxlnyo) {
  console[G[580129]](G[580216] + pxlnyo[G[580217]] + G[580220] + pxlnyo[G[580221]]);
}), wx[G[580222]](function (oylnp) {
  window['E16D'] = oylnp, window['E1_D6'] && window['E16D'] && (console[G[580090]](G[580223] + window['E16D'][G[580224]]), window['E1_D6'](window['E16D']), window['E16D'] = null);
}), window['E1CR6_D'] = 0x0, window[G[580225]] = null, wx[G[580226]](function () {
  window['E1CR6_D']++, wx[G[580227]]();if (window['E1CR6_D'] >= 0x2) {
    window['E1CR6_D'] = 0x0, console[G[580115]](G[580228]), wx[G[580229]]('0', 0x1);if (window['E1R_'] && window['E1R_'][G[580194]]) window['E1R_D'](G[580230], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});