var g = wx.u$;
require(g[0]);