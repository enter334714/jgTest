var g = wx.u$;
import 'ttMAItttt.js';