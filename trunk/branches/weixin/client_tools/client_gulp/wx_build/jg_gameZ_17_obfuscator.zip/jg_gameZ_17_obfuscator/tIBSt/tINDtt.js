var g = wx.u$;
import _ddqf6t from '../ttkttt/t6ktgt.js';window[g[167]] = { 'wxVersion': window[g[6]][g[7]] }, window[g[168]] = ![], window[g[169]] = 0x1, window[g[170]] = 0x1, window[g[171]] = !![], window[g[172]] = !![], window[g[173]] = '', window[g[174]] = ![], window[g[16]] = { 'base_cdn': g[175], 'cdn': g[175] }, p4H[g[176]] = {}, p4H[g[177]] = '0', p4H[g[93]] = window[g[167]][g[178]], p4H[g[128]] = '', p4H['os'] = '1', p4H[g[179]] = g[180], p4H[g[181]] = g[182], p4H[g[183]] = g[184], p4H[g[185]] = g[186], p4H[g[187]] = g[188], p4H[g[189]] = '1', p4H[g[23]] = '', p4H[g[190]] = '', p4H[g[191]] = 0x0, p4H[g[192]] = {}, p4H[g[193]] = parseInt(p4H[g[189]]), p4H[g[194]] = p4H[g[189]], p4H[g[24]] = {}, p4H[g[31]] = g[195], p4H[g[196]] = ![], p4H[g[197]] = g[198], p4H[g[199]] = Date[g[160]](), p4H[g[200]] = g[201], p4H[g[202]] = '_a', p4H[g[203]] = 0x2, p4H[g[21]] = 0x7c1, p4H[g[178]] = window[g[167]][g[178]], p4H[g[204]] = ![], p4H[g[120]] = ![], p4H[g[123]] = ![], p4H[g[126]] = ![], window[g[205]] = 0x5, window[g[206]] = ![], window[g[67]] = ![], window[g[76]] = ![], window[g[207]] = ![], window[g[208]] = ![], window[g[209]] = ![], window[g[210]] = ![], window[g[211]] = ![], window[g[212]] = ![], window[g[213]] = null, window[g[214]] = function ($9bz7l) {
  console[g[47]](g[214], $9bz7l), wx[g[215]]({}), wx[g[54]]({ 'title': g[85], 'content': $9bz7l, 'success'($7l9b) {
      if ($7l9b[g[216]]) console[g[47]](g[217]);else $7l9b[g[218]] && console[g[47]](g[219]);
    } });
}, window[g[220]] = function (lo7bz) {
  console[g[47]](g[221], lo7bz), p14HS(), wx[g[54]]({ 'title': g[85], 'content': lo7bz, 'confirmText': g[222], 'cancelText': g[223], 'success'(f6t1) {
      if (f6t1[g[216]]) window[g[82]]();else f6t1[g[218]] && (console[g[47]](g[224]), wx[g[225]]({}));
    } });
}, window[g[226]] = function (mcpxo) {
  console[g[47]](g[226], mcpxo), wx[g[54]]({ 'title': g[85], 'content': mcpxo, 'confirmText': g[227], 'showCancel': ![], 'complete'(opx4m) {
      console[g[47]](g[224]), wx[g[225]]({});
    } });
}, window[g[228]] = ![], window[g[229]] = function (pmc4xo) {
  window[g[228]] = !![], wx[g[230]](pmc4xo);
}, window[g[231]] = function () {
  window[g[228]] && (window[g[228]] = ![], wx[g[215]]({}));
}, window[g[232]] = function (knw_yj) {
  window[g[37]][g[38]][g[232]](knw_yj);
}, window[g[233]] = function (bv729$, _w8sh) {
  _ddqf6t[g[233]](bv729$, function (jgknyi) {
    jgknyi && jgknyi[g[234]] ? jgknyi[g[234]][g[235]] == 0x1 ? _w8sh(!![]) : (_w8sh(![]), console[g[1]](g[236] + jgknyi[g[234]][g[237]])) : console[g[47]](g[233], jgknyi);
  });
}, window[g[238]] = function (mozpc) {
  console[g[47]](g[239], mozpc);
}, window[g[240]] = function (vq952) {}, window[g[241]] = function (qd2u5, shw8e, o7$zml) {}, window[g[242]] = function (_jkwn) {
  console[g[47]](g[243], _jkwn), window[g[37]][g[38]][g[244]](), window[g[37]][g[38]][g[245]](), window[g[37]][g[38]][g[246]]();
}, window[g[247]] = function (ozm7l) {
  window[g[248]](0xe, g[249] + ozm7l), window[g[220]](g[250]);var xyigj = { 'id': window[g[16]][g[17]], 'role': window[g[16]][g[18]], 'level': window[g[16]][g[19]], 'account': window[g[16]][g[20]], 'version': window[g[16]][g[21]], 'cdn': window[g[16]][g[22]], 'pkgName': window[g[16]][g[23]], 'gamever': window[g[6]][g[7]], 'serverid': window[g[16]][g[24]] ? window[g[16]][g[24]][g[25]] : 0x0, 'systemInfo': window[g[26]], 'error': g[251], 'stack': ozm7l ? ozm7l : g[250] },
      v2u$b9 = JSON[g[28]](xyigj);console[g[29]](g[252] + v2u$b9), window[g[31]](v2u$b9);
}, window[g[248]] = function (gkyn, pm4xoc) {
  sendApi(p4H[g[183]], g[253], { 'game_pkg': p4H[g[23]], 'partner_id': p4H[g[189]], 'server_id': p4H[g[24]] && p4H[g[24]][g[25]] > 0x0 ? p4H[g[24]][g[25]] : 0x0, 'uid': p4H[g[20]] > 0x0 ? p4H[g[20]] : 0x0, 'type': gkyn, 'info': pm4xoc });
}, window[g[254]] = function (a8es) {
  var h8was = JSON[g[255]](a8es);h8was[g[256]] = window[g[6]][g[7]], h8was[g[257]] = window[g[16]][g[24]] ? window[g[16]][g[24]][g[25]] : 0x0, h8was[g[26]] = window[g[26]];var l7ozb = JSON[g[28]](h8was);console[g[29]](g[258] + l7ozb), window[g[31]](l7ozb);
}, window[g[83]] = function (cpg4ix, cpzom) {
  var obzl$ = { 'id': window[g[16]][g[17]], 'role': window[g[16]][g[18]], 'level': window[g[16]][g[19]], 'account': window[g[16]][g[20]], 'version': window[g[16]][g[21]], 'cdn': window[g[16]][g[22]], 'pkgName': window[g[16]][g[23]], 'gamever': window[g[6]][g[7]], 'serverid': window[g[16]][g[24]] ? window[g[16]][g[24]][g[25]] : 0x0, 'systemInfo': window[g[26]], 'error': cpg4ix, 'stack': cpzom },
      zcxp = JSON[g[28]](obzl$);console[g[161]](g[259] + zcxp), window[g[31]](zcxp);
}, window[g[31]] = function (_jng) {
  if (window[g[16]][g[129]] == g[260]) return;var d5fvqu = p4H[g[31]] + g[261] + p4H[g[20]];wx[g[262]]({ 'url': d5fvqu, 'method': g[263], 'data': _jng, 'header': { 'content-type': g[264], 'cache-control': g[265] }, 'success': function (xmocpz) {
      DEBUG && console[g[47]](g[266], d5fvqu, _jng, xmocpz);
    }, 'fail': function (xpoc4) {
      DEBUG && console[g[47]](g[266], d5fvqu, _jng, xpoc4);
    }, 'complete': function () {} });
}, window[g[267]] = function () {
  function xjy4() {
    return ((0x1 + Math[g[268]]()) * 0x10000 | 0x0)[g[269]](0x10)[g[270]](0x1);
  }return xjy4() + xjy4() + '-' + xjy4() + '-' + xjy4() + '-' + xjy4() + '+' + xjy4() + xjy4() + xjy4();
}, window[g[82]] = function () {
  console[g[47]](g[271]);var g4cixp = _ddqf6t[g[272]]();p4H[g[194]] = g4cixp[g[273]], p4H[g[193]] = g4cixp[g[273]], p4H[g[189]] = g4cixp[g[273]], p4H[g[23]] = g4cixp[g[274]];var uqvd25 = { 'game_ver': p4H[g[93]] };p4H[g[190]] = this[g[267]](), p14SH({ 'title': g[275] }), _ddqf6t[g[276]](uqvd25, this[g[277]][g[278]](this));
}, window[g[277]] = function (tdr6fq) {
  var zocml = tdr6fq[g[279]];sdkInitRes = tdr6fq, console[g[47]](g[280] + zocml + g[281] + (zocml == 0x1) + g[282] + tdr6fq[g[7]] + g[283] + window[g[167]][g[178]]);if (!tdr6fq[g[7]] || window[g[41]](window[g[167]][g[178]], tdr6fq[g[7]]) < 0x0) console[g[47]](g[284]), p4H[g[181]] = g[285], p4H[g[183]] = g[286], p4H[g[185]] = g[287], p4H[g[22]] = g[288], p4H[g[289]] = g[290], p4H[g[291]] = 'sq', p4H[g[204]] = ![];else window[g[41]](window[g[167]][g[178]], tdr6fq[g[7]]) == 0x0 ? (console[g[47]](g[292]), p4H[g[181]] = g[182], p4H[g[183]] = g[184], p4H[g[185]] = g[186], p4H[g[22]] = g[293], p4H[g[289]] = g[290], p4H[g[291]] = g[294], p4H[g[204]] = !![]) : (console[g[47]](g[295]), p4H[g[181]] = g[182], p4H[g[183]] = g[184], p4H[g[185]] = g[186], p4H[g[22]] = g[293], p4H[g[289]] = g[290], p4H[g[291]] = g[294], p4H[g[204]] = ![]);p4H[g[191]] = config[g[296]] ? config[g[296]] : 0x0, this[g[297]](), this[g[298]](), window[g[299]] = 0x5, p14SH({ 'title': g[300] }), _ddqf6t[g[301]](this[g[302]][g[278]](this));
}, window[g[299]] = 0x5, window[g[302]] = function (q6trd, fr6q5) {
  if (q6trd == 0x0 && fr6q5 && fr6q5[g[303]]) {
    p4H[g[304]] = fr6q5[g[303]];var uvd2q = this;p14SH({ 'title': g[305] }), sendApi(p4H[g[181]], g[306], { 'platform': p4H[g[179]], 'partner_id': p4H[g[189]], 'token': fr6q5[g[303]], 'game_pkg': p4H[g[23]], 'deviceId': p4H[g[190]], 'scene': g[307] + p4H[g[191]] }, this[g[308]][g[278]](this), pSH4, pH1);
  } else fr6q5 && fr6q5[g[65]] && window[g[299]] > 0x0 && (fr6q5[g[65]][g[121]](g[309]) != -0x1 || fr6q5[g[65]][g[121]](g[310]) != -0x1 || fr6q5[g[65]][g[121]](g[311]) != -0x1 || fr6q5[g[65]][g[121]](g[312]) != -0x1 || fr6q5[g[65]][g[121]](g[313]) != -0x1 || fr6q5[g[65]][g[121]](g[314]) != -0x1) ? (window[g[299]]--, _ddqf6t[g[301]](this[g[302]][g[278]](this))) : (window[g[248]](0x1, g[315] + q6trd + g[316] + (fr6q5 ? fr6q5[g[65]] : '')), window[g[83]](g[317], JSON[g[28]]({ 'status': q6trd, 'data': fr6q5 })), window[g[220]](g[318] + (fr6q5 && fr6q5[g[65]] ? '，' + fr6q5[g[65]] : '')));
}, window[g[308]] = function (yjgk_n) {
  if (!yjgk_n) {
    window[g[248]](0x2, g[319]), window[g[83]](g[320], g[321]), window[g[220]](g[322]);return;
  }if (yjgk_n[g[235]] != g[323]) {
    window[g[248]](0x2, g[324] + yjgk_n[g[235]]), window[g[83]](g[320], JSON[g[28]](yjgk_n)), window[g[220]](g[325] + yjgk_n[g[235]]);return;
  }p4H[g[326]] = String(yjgk_n[g[20]]), p4H[g[20]] = String(yjgk_n[g[20]]), p4H[g[97]] = String(yjgk_n[g[97]]), p4H[g[194]] = String(yjgk_n[g[97]]), p4H[g[327]] = String(yjgk_n[g[327]]), p4H[g[328]] = String(yjgk_n[g[329]]), p4H[g[330]] = String(yjgk_n[g[331]]), p4H[g[329]] = '';var d52qv = this;p14SH({ 'title': g[332] });var xgcp4 = localStorage[g[333]](g[334] + p4H[g[23]] + p4H[g[20]]);if (xgcp4 && xgcp4 != '') {
    var frtdq6 = Number(xgcp4);d52qv[g[335]](frtdq6);
  } else d52qv[g[336]]();
}, window[g[336]] = function () {
  var dtqr6 = this;sendApi(p4H[g[181]], g[337], { 'partner_id': p4H[g[189]], 'uid': p4H[g[20]], 'version': p4H[g[93]], 'game_pkg': p4H[g[23]], 'device': p4H[g[190]] }, dtqr6[g[338]][g[278]](dtqr6), pSH4, pH1);
}, window[g[338]] = function (q56u) {
  if (!q56u) {
    window[g[248]](0x3, g[339]), window[g[220]](g[339]);return;
  }if (q56u[g[235]] != g[323]) {
    window[g[248]](0x3, g[340] + q56u[g[235]]), window[g[220]](g[340] + q56u[g[235]]);return;
  }if (!q56u[g[234]] || q56u[g[234]][g[10]] == 0x0) {
    window[g[248]](0x3, g[341]), window[g[220]](g[342]);return;
  }this[g[343]](q56u);
}, window[g[335]] = function (xig4) {
  var wkj_e = this;sendApi(p4H[g[181]], g[344], { 'server_id': xig4, 'time': Date[g[160]]() / 0x3e8 }, wkj_e[g[345]][g[278]](wkj_e), pSH4, pH1);
}, window[g[345]] = function (gy4xji) {
  if (!gy4xji) {
    window[g[248]](0x4, g[346]), this[g[336]]();return;
  }if (gy4xji[g[235]] != g[323]) {
    window[g[248]](0x4, g[347] + gy4xji[g[235]]), this[g[336]]();return;
  }if (!gy4xji[g[234]] || gy4xji[g[234]][g[10]] == 0x0) {
    window[g[248]](0x4, g[348]), this[g[336]]();return;
  }this[g[343]](gy4xji), window[g[37]] && window[g[37]][g[38]][g[349]] && window[g[37]][g[38]][g[349]](sdkInitRes[g[350]], sdkInitRes[g[351]], sdkInitRes[g[352]], sdkInitRes[g[353]], sdkInitRes[g[354]]);
}, window[g[343]] = function (rd5f6q) {
  p4H[g[355]] = rd5f6q[g[356]] != undefined ? rd5f6q[g[356]] : 0x0, p4H[g[24]] = { 'server_id': String(rd5f6q[g[234]][0x0][g[25]]), 'server_name': String(rd5f6q[g[234]][0x0][g[357]]), 'entry_ip': rd5f6q[g[234]][0x0][g[358]], 'entry_port': parseInt(rd5f6q[g[234]][0x0][g[359]]), 'status': p4S1(rd5f6q[g[234]][0x0]), 'start_time': rd5f6q[g[234]][0x0][g[360]], 'cdn': p4H[g[22]] }, this[g[361]]();
}, window[g[361]] = function () {
  if (p4H[g[355]] == 0x1) {
    var nkygj_ = p4H[g[24]][g[362]];if (nkygj_ === -0x1 || nkygj_ === 0x0) {
      window[g[248]](0xf, g[363] + p4H[g[24]]['id'] + g[364] + p4H[g[24]][g[362]]), window[g[220]](nkygj_ === -0x1 ? g[365] : g[366]);return;
    }pH1S4(0x0, p4H[g[24]][g[25]]), window[g[37]][g[38]][g[367]](p4H[g[355]]);
  } else window[g[37]][g[38]][g[368]](), p14HS();window[g[211]] = !![], window[g[68]](), window[g[69]]();
}, window[g[297]] = function () {
  sendApi(p4H[g[181]], g[369], { 'game_pkg': p4H[g[23]], 'version_name': p4H[g[291]] }, this[g[370]][g[278]](this), pSH4, pH1);
}, window[g[370]] = function (yi4gp) {
  if (!yi4gp) {
    window[g[248]](0x5, g[371]), window[g[220]](g[371]);return;
  }if (yi4gp[g[235]] != g[323]) {
    window[g[248]](0x5, g[372] + yi4gp[g[235]]), window[g[220]](g[372] + yi4gp[g[235]]);return;
  }if (!yi4gp[g[234]] || !yi4gp[g[234]][g[93]]) {
    window[g[248]](0x5, g[373] + (yi4gp[g[234]] && yi4gp[g[234]][g[93]])), window[g[220]](g[373] + (yi4gp[g[234]] && yi4gp[g[234]][g[93]]));return;
  }yi4gp[g[234]][g[374]] && yi4gp[g[234]][g[374]][g[10]] > 0xa && (p4H[g[375]] = yi4gp[g[234]][g[374]], p4H[g[22]] = yi4gp[g[234]][g[374]]), yi4gp[g[234]][g[93]] && (p4H[g[21]] = yi4gp[g[234]][g[93]]), console[g[1]](g[376] + p4H[g[21]] + g[377] + p4H[g[291]]), window[g[209]] = !![], window[g[68]](), window[g[69]]();
}, window[g[378]], window[g[298]] = function () {
  sendApi(p4H[g[181]], g[379], { 'game_pkg': p4H[g[23]] }, this[g[380]][g[278]](this), pSH4, pH1);
}, window[g[380]] = function (r16ft3) {
  if (r16ft3 && r16ft3[g[235]] === g[323] && r16ft3[g[234]]) {
    window[g[378]] = r16ft3[g[234]];for (var ynig4j in r16ft3[g[234]]) {
      p4H[ynig4j] = r16ft3[g[234]][ynig4j];
    }
  } else window[g[248]](0xb, g[381]), console[g[1]](g[382] + r16ft3[g[235]]);window[g[210]] = !![], window[g[69]]();
}, window[g[383]] = function (qfrd56, lz7om, z$b7l9, ixgpc, ip4c, zo7mc, picm4x, xpci, xipc, ipgxy) {
  ip4c = String(ip4c);var tdqf = picm4x,
      t6qrfd = xpci;p4H[g[176]][ip4c] = { 'productid': ip4c, 'productname': tdqf, 'productdesc': t6qrfd, 'roleid': qfrd56, 'rolename': lz7om, 'rolelevel': z$b7l9, 'price': zo7mc, 'callback': xipc }, sendApi(p4H[g[185]], g[384], { 'game_pkg': p4H[g[23]], 'server_id': p4H[g[24]][g[25]], 'server_name': p4H[g[24]][g[357]], 'level': z$b7l9, 'uid': p4H[g[20]], 'role_id': qfrd56, 'role_name': lz7om, 'product_id': ip4c, 'product_name': tdqf, 'product_desc': t6qrfd, 'money': zo7mc, 'partner_id': p4H[g[189]] }, toPayCallBack, pSH4, pH1);
}, window[g[385]] = function (xci4p) {
  if (xci4p && (xci4p[g[386]] === 0xc8 || xci4p[g[235]] == g[323])) {
    var ijny = p4H[g[176]][String(xci4p[g[387]])];if (ijny[g[388]]) ijny[g[388]](xci4p[g[387]], xci4p[g[389]], -0x1);_ddqf6t[g[390]]({ 'cpbill': xci4p[g[389]], 'productid': xci4p[g[387]], 'productname': ijny[g[391]], 'productdesc': ijny[g[392]], 'serverid': p4H[g[24]][g[25]], 'servername': p4H[g[24]][g[357]], 'roleid': ijny[g[393]], 'rolename': ijny[g[394]], 'rolelevel': ijny[g[395]], 'price': ijny[g[396]], 'extension': JSON[g[28]]({ 'cp_order_id': xci4p[g[389]] }) }, function (pxmzc, lz97$) {
      ijny[g[388]] && pxmzc == 0x0 && ijny[g[388]](xci4p[g[387]], xci4p[g[389]], pxmzc);console[g[1]](JSON[g[28]]({ 'type': g[397], 'status': pxmzc, 'data': xci4p, 'role_name': ijny[g[394]] }));if (pxmzc === 0x0) {} else {
        if (pxmzc === 0x1) {} else {
          if (pxmzc === 0x2) {}
        }
      }
    });
  } else {
    var ypi4g = xci4p ? g[398] + xci4p[g[386]] + g[399] + xci4p[g[235]] + g[400] + xci4p[g[1]] : g[401];window[g[248]](0xd, g[402] + ypi4g), alert(ypi4g);
  }
}, window[g[403]] = function () {}, window[g[404]] = function (cx, $7ozm, igpyx, ynji4g, mclo) {
  _ddqf6t[g[405]](p4H[g[24]][g[25]], p4H[g[24]][g[357]] || p4H[g[24]][g[25]], cx, $7ozm, igpyx), sendApi(p4H[g[181]], g[406], { 'game_pkg': p4H[g[23]], 'server_id': p4H[g[24]][g[25]], 'role_id': cx, 'uid': p4H[g[20]], 'role_name': $7ozm, 'role_type': ynji4g, 'level': igpyx });
}, window[g[407]] = function (dv5qu2, vd5, ol$b7, td6f3, rtf6dq, e_8kw, cmpoz, r163ft, xgij4, xcg4pi) {
  p4H[g[17]] = dv5qu2, p4H[g[18]] = vd5, p4H[g[19]] = ol$b7, _ddqf6t[g[408]](p4H[g[24]][g[25]], p4H[g[24]][g[357]] || p4H[g[24]][g[25]], dv5qu2, vd5, ol$b7), sendApi(p4H[g[181]], g[409], { 'game_pkg': p4H[g[23]], 'server_id': p4H[g[24]][g[25]], 'role_id': dv5qu2, 'uid': p4H[g[20]], 'role_name': vd5, 'role_type': td6f3, 'level': ol$b7, 'evolution': rtf6dq });
}, window[g[410]] = function (lcmz7, olzm, cmpx, fr3t61, ci4mxp, q9u2v5, b97$lz, q5vufd, h_se8w, rftdq6) {
  p4H[g[17]] = lcmz7, p4H[g[18]] = olzm, p4H[g[19]] = cmpx, _ddqf6t[g[411]](p4H[g[24]][g[25]], p4H[g[24]][g[357]] || p4H[g[24]][g[25]], lcmz7, olzm, cmpx), sendApi(p4H[g[181]], g[409], { 'game_pkg': p4H[g[23]], 'server_id': p4H[g[24]][g[25]], 'role_id': lcmz7, 'uid': p4H[g[20]], 'role_name': olzm, 'role_type': fr3t61, 'level': cmpx, 'evolution': ci4mxp });
}, window[g[412]] = function (q592uv) {}, window[g[413]] = function (b$2u9v) {
  _ddqf6t[g[414]](g[414], function (rtfqd) {
    b$2u9v && b$2u9v(rtfqd);
  });
}, window[g[415]] = function () {
  _ddqf6t[g[415]]();
}, window[g[416]] = function () {
  _ddqf6t[g[417]]();
}, window[g[418]] = function (p4igy, $v7b2, dr65, kjwen, qv592u, qvduf, jikygn, $9z) {
  $9z = $9z || p4H[g[24]][g[25]], sendApi(p4H[g[181]], g[419], { 'phone': p4igy, 'role_id': $v7b2, 'uid': p4H[g[20]], 'game_pkg': p4H[g[23]], 'partner_id': p4H[g[189]], 'server_id': $9z }, jikygn, 0x2, null, function () {
    return !![];
  });
}, window[g[151]] = function (ni4gj) {
  window[g[153]] = ni4gj, window[g[153]] && window[g[152]] && (console[g[1]](g[154] + window[g[152]][g[155]]), window[g[153]](window[g[152]]), window[g[152]] = null);
}, window[g[420]] = function (uvf5qd, opmx4, kgiyj, j4giny) {
  window[g[421]](g[422], { 'game_pkg': window[g[16]][g[23]], 'role_id': opmx4, 'server_id': kgiyj }, j4giny);
}, window[g[423]] = function (vq2u95, $297vb, zmlo7c) {
  function $ub92(dv5ufq) {
    var qud6f5 = [],
        lo7zm = [],
        k_jyn = zmlo7c || window[g[6]][g[424]];for (var l$bz in k_jyn) {
      var pgy4i = Number(l$bz);(!vq2u95 || !vq2u95[g[10]] || vq2u95[g[121]](pgy4i) != -0x1) && (lo7zm[g[44]](k_jyn[l$bz]), qud6f5[g[44]]([pgy4i, 0x3]));
    }window[g[41]](window[g[45]], g[425]) >= 0x0 ? (console[g[47]](g[426]), _ddqf6t[g[427]] && _ddqf6t[g[427]](lo7zm, function (swhe) {
      console[g[47]](g[428]), console[g[47]](swhe);if (swhe && swhe[g[65]] == g[429]) for (var xopz in k_jyn) {
        if (swhe[k_jyn[xopz]] == g[430]) {
          var nejk_w = Number(xopz);for (var ne_j = 0x0; ne_j < qud6f5[g[10]]; ne_j++) {
            if (qud6f5[ne_j][0x0] == nejk_w) {
              qud6f5[ne_j][0x1] = 0x1;break;
            }
          }
        }
      }window[g[41]](window[g[45]], g[431]) >= 0x0 ? wx[g[432]]({ 'withSubscriptions': !![], 'success': function (vud2) {
          var qfud65 = vud2[g[433]][g[434]];if (qfud65) {
            console[g[47]](g[435]), console[g[47]](qfud65);for (var qtrd6f in k_jyn) {
              if (qfud65[k_jyn[qtrd6f]] == g[430]) {
                var qd5rf6 = Number(qtrd6f);for (var knwjy = 0x0; knwjy < qud6f5[g[10]]; knwjy++) {
                  if (qud6f5[knwjy][0x0] == qd5rf6) {
                    qud6f5[knwjy][0x1] = 0x2;break;
                  }
                }
              }
            }console[g[47]](qud6f5), $297vb && $297vb(qud6f5);
          } else console[g[47]](g[436]), console[g[47]](vud2), console[g[47]](qud6f5), $297vb && $297vb(qud6f5);
        }, 'fail': function () {
          console[g[47]](g[437]), console[g[47]](qud6f5), $297vb && $297vb(qud6f5);
        } }) : (console[g[47]](g[438] + window[g[45]]), console[g[47]](qud6f5), $297vb && $297vb(qud6f5));
    })) : (console[g[47]](g[439] + window[g[45]]), console[g[47]](qud6f5), $297vb && $297vb(qud6f5)), wx[g[440]]($ub92);
  }wx[g[441]]($ub92);
}, window[g[442]] = { 'isSuccess': ![], 'level': g[443], 'isCharging': ![] }, window[g[444]] = function (kg_n) {
  wx[g[139]]({ 'success': function (rf36dt) {
      var b2u5v9 = window[g[442]];b2u5v9[g[445]] = !![], b2u5v9[g[141]] = Number(rf36dt[g[141]])[g[446]](0x0), b2u5v9[g[143]] = rf36dt[g[143]], kg_n && kg_n(b2u5v9[g[445]], b2u5v9[g[141]], b2u5v9[g[143]]);
    }, 'fail': function (xgpyi) {
      console[g[47]](g[447], xgpyi[g[65]]);var qtrdf = window[g[442]];kg_n && kg_n(qtrdf[g[445]], qtrdf[g[141]], qtrdf[g[143]]);
    } });
}, window[g[144]] = function (gnjk_y) {
  wx[g[144]]({ 'success': function (e8sah) {
      gnjk_y && gnjk_y(!![], e8sah);
    }, 'fail': function (udf6q5) {
      gnjk_y && gnjk_y(![], udf6q5);
    } });
}, window[g[148]] = function (px) {
  if (px) wx[g[148]](px);
}, window[g[448]] = function (g_k) {
  wx[g[448]](g_k);
}, window[g[421]] = function (pxcmoz, dq65uf, p4mco, wesah8, bu$29v, m$l7zo, qd5ufv, molz7$) {
  if (wesah8 == undefined) wesah8 = 0x1;wx[g[262]]({ 'url': pxcmoz, 'method': qd5ufv || g[449], 'responseType': g[450], 'data': dq65uf, 'header': { 'content-type': molz7$ || g[264] }, 'success': function (jgnyik) {
      DEBUG && console[g[47]](g[451], pxcmoz, info, jgnyik);if (jgnyik && jgnyik[g[452]] == 0xc8) {
        var jnykg = jgnyik[g[234]];!m$l7zo || m$l7zo(jnykg) ? p4mco && p4mco(jnykg) : window[g[453]](pxcmoz, dq65uf, p4mco, wesah8, bu$29v, m$l7zo, jgnyik);
      } else window[g[453]](pxcmoz, dq65uf, p4mco, wesah8, bu$29v, m$l7zo, jgnyik);
    }, 'fail': function (u529vb) {
      DEBUG && console[g[47]](g[454], pxcmoz, info, u529vb), window[g[453]](pxcmoz, dq65uf, p4mco, wesah8, bu$29v, m$l7zo, u529vb);
    }, 'complete': function () {} });
}, window[g[453]] = function (y4jgx, k_jwny, uvqd5f, yjgin, bz7$9l, wseah8, h8sawe) {
  yjgin - 0x1 > 0x0 ? setTimeout(function () {
    window[g[421]](y4jgx, k_jwny, uvqd5f, yjgin - 0x1, bz7$9l, wseah8);
  }, 0x3e8) : bz7$9l && bz7$9l(JSON[g[28]]({ 'url': y4jgx, 'response': h8sawe }));
}, window[g[455]] = function (zclpmo, nyijk, x4pgci, mopxcz, $9l27b, f3dr, s8h0ae) {
  !x4pgci && (x4pgci = {});var eawhs = Math[g[456]](Date[g[160]]() / 0x3e8);x4pgci[g[331]] = eawhs, x4pgci[g[457]] = nyijk;var _8weh = Object[g[458]](x4pgci)[g[459]](),
      hsaw = '',
      uv9b52 = '';for (var l2$9b7 = 0x0; l2$9b7 < _8weh[g[10]]; l2$9b7++) {
    hsaw = hsaw + (l2$9b7 == 0x0 ? '' : '&') + _8weh[l2$9b7] + x4pgci[_8weh[l2$9b7]], uv9b52 = uv9b52 + (l2$9b7 == 0x0 ? '' : '&') + _8weh[l2$9b7] + '=' + encodeURIComponent(x4pgci[_8weh[l2$9b7]]);
  }hsaw = hsaw + p4H[g[187]];var j_gkny = g[460] + md5(hsaw);send(zclpmo + '?' + uv9b52 + (uv9b52 == '' ? '' : '&') + j_gkny, null, mopxcz, $9l27b, f3dr, s8h0ae || function (v2b9$u) {
    return v2b9$u[g[235]] == g[323];
  }, null, g[461]);
}, window[g[462]] = function (k_nw8e, mplcz) {
  var yjng4 = 0x0;p4H[g[24]] && (yjng4 = p4H[g[24]][g[25]]), sendApi(p4H[g[183]], g[463], { 'partnerId': p4H[g[189]], 'gamePkg': p4H[g[23]], 'logTime': Math[g[456]](Date[g[160]]() / 0x3e8), 'platformUid': p4H[g[327]], 'type': k_nw8e, 'serverId': yjng4 }, null, 0x2, null, function () {
    return !![];
  });
}, window[g[464]] = function (_hke8w) {
  sendApi(p4H[g[181]], g[465], { 'partner_id': p4H[g[189]], 'uid': p4H[g[20]], 'version': p4H[g[93]], 'game_pkg': p4H[g[23]], 'device': p4H[g[190]] }, p4HS1, pSH4, pH1);
}, window[g[466]] = function (ocp4mx) {
  if (ocp4mx && ocp4mx[g[235]] === g[323] && ocp4mx[g[234]]) {
    ocp4mx[g[234]][g[467]]({ 'id': -0x2, 'name': g[468] }), ocp4mx[g[234]][g[467]]({ 'id': -0x1, 'name': g[469] }), p4H[g[470]] = ocp4mx[g[234]];if (window[g[471]]) window[g[471]][g[472]]();
  } else {
    p4H[g[473]] = ![];var nk_e = ocp4mx ? ocp4mx[g[235]] : '';window[g[248]](0x7, g[474] + nk_e), window[g[220]](g[475] + nk_e);
  }
}, window[g[476]] = function (r63tf1) {
  sendApi(p4H[g[181]], g[477], { 'partner_id': p4H[g[189]], 'uid': p4H[g[20]], 'version': p4H[g[93]], 'game_pkg': p4H[g[23]], 'device': p4H[g[190]] }, p14S, pSH4, pH1);
}, window[g[478]] = function (ewkh8) {
  p4H[g[479]] = ![];if (ewkh8 && ewkh8[g[235]] === g[323] && ewkh8[g[234]]) {
    for (var dq5fr = 0x0; dq5fr < ewkh8[g[234]][g[10]]; dq5fr++) {
      ewkh8[g[234]][dq5fr][g[362]] = p4S1(ewkh8[g[234]][dq5fr]);
    }p4H[g[192]][-0x1] = window[g[480]](ewkh8[g[234]]), window[g[471]][g[481]](-0x1);
  } else {
    var mczpol = ewkh8 ? ewkh8[g[235]] : '';window[g[248]](0x8, g[482] + mczpol), window[g[220]](g[483] + mczpol);
  }
}, window[g[484]] = function (czpm) {
  sendApi(p4H[g[181]], g[477], { 'partner_id': p4H[g[189]], 'uid': p4H[g[20]], 'version': p4H[g[93]], 'game_pkg': p4H[g[23]], 'device': p4H[g[190]] }, czpm, pSH4, pH1);
}, window[g[485]] = function (dfu6q5, mlz$7o) {
  sendApi(p4H[g[181]], g[486], { 'partner_id': p4H[g[189]], 'uid': p4H[g[20]], 'version': p4H[g[93]], 'game_pkg': p4H[g[23]], 'device': p4H[g[190]], 'server_group_id': mlz$7o }, pS41, pSH4, pH1);
}, window[g[487]] = function (vq2du5) {
  p4H[g[479]] = ![];if (vq2du5 && vq2du5[g[235]] === g[323] && vq2du5[g[234]] && vq2du5[g[234]][g[234]]) {
    var ygijn4 = vq2du5[g[234]][g[488]],
        ijgnky = [];for (var xiy = 0x0; xiy < vq2du5[g[234]][g[234]][g[10]]; xiy++) {
      vq2du5[g[234]][g[234]][xiy][g[362]] = p4S1(vq2du5[g[234]][g[234]][xiy]), (ijgnky[g[10]] == 0x0 || vq2du5[g[234]][g[234]][xiy][g[362]] != 0x0) && (ijgnky[ijgnky[g[10]]] = vq2du5[g[234]][g[234]][xiy]);
    }p4H[g[192]][ygijn4] = window[g[480]](ijgnky), window[g[471]][g[481]](ygijn4);
  } else {
    var j_ken = vq2du5 ? vq2du5[g[235]] : '';window[g[248]](0x9, g[489] + j_ken), window[g[220]](g[490] + j_ken);
  }
}, window[g[491]] = function (xcmzo) {
  sendApi(p4H[g[181]], g[492], { 'partner_id': p4H[g[189]], 'uid': p4H[g[20]], 'version': p4H[g[93]], 'game_pkg': p4H[g[23]], 'device': p4H[g[190]] }, reqServerRecommendCallBack, pSH4, pH1);
}, window[g[493]] = function (l72$9) {
  p4H[g[479]] = ![];if (l72$9 && l72$9[g[235]] === g[323] && l72$9[g[234]]) {
    for (var cpxg = 0x0; cpxg < l72$9[g[234]][g[10]]; cpxg++) {
      l72$9[g[234]][cpxg][g[362]] = p4S1(l72$9[g[234]][cpxg]);
    }p4H[g[192]][-0x2] = window[g[480]](l72$9[g[234]]), window[g[471]][g[481]](-0x2);
  } else {
    var bu9v2 = l72$9 ? l72$9[g[235]] : '';window[g[248]](0xa, g[494] + bu9v2), alert(g[495] + bu9v2);
  }
}, window[g[480]] = function (fd6t) {
  return fd6t;
}, window[g[496]] = function (nij4g, k_eh) {
  nij4g = nij4g || p4H[g[24]][g[25]], sendApi(p4H[g[181]], g[497], { 'type': '4', 'game_pkg': p4H[g[23]], 'server_id': nij4g }, k_eh);
}, window[g[498]] = function (wnk8_e, cpmx4, hs_, fd6rq5) {
  hs_ = hs_ || p4H[g[24]][g[25]], sendApi(p4H[g[181]], g[499], { 'type': wnk8_e, 'game_pkg': cpmx4, 'server_id': hs_ }, fd6rq5);
}, window[g[500]] = function (kwe_nj, q6dfr) {
  sendApi(p4H[g[181]], g[501], { 'game_pkg': kwe_nj }, q6dfr);
}, window[g[502]] = function (ahwse) {
  if (ahwse) {
    if (ahwse[g[362]] == 0x1) {
      if (ahwse[g[503]] == 0x1) return 0x2;else return 0x1;
    } else return ahwse[g[362]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window[g[504]] = function (jwekn, ewk_nj) {
  p4H[g[505]] = { 'step': jwekn, 'server_id': ewk_nj };var igx4j = this;p14SH({ 'title': g[506] }), sendApi(p4H[g[181]], g[507], { 'partner_id': p4H[g[189]], 'uid': p4H[g[20]], 'game_pkg': p4H[g[23]], 'server_id': ewk_nj, 'platform': p4H[g[97]], 'platform_uid': p4H[g[327]], 'check_login_time': p4H[g[330]], 'check_login_sign': p4H[g[328]], 'version_name': p4H[g[291]] }, pH14S, pSH4, pH1, function (lz7m$) {
    return lz7m$[g[235]] == g[323] || lz7m$[g[1]] == g[508] || lz7m$[g[1]] == g[509];
  });
}, window[g[510]] = function (l9$z) {
  var j_wekn = this;if (l9$z && l9$z[g[235]] === g[323] && l9$z[g[234]]) {
    var dqf5u6 = p4H[g[24]];dqf5u6[g[511]] = p4H[g[193]], dqf5u6[g[329]] = String(l9$z[g[234]][g[512]]), dqf5u6[g[199]] = parseInt(l9$z[g[234]][g[331]]);if (l9$z[g[234]][g[513]]) dqf5u6[g[513]] = parseInt(l9$z[g[234]][g[513]]);else dqf5u6[g[513]] = parseInt(l9$z[g[234]][g[25]]);dqf5u6[g[514]] = 0x0, dqf5u6[g[22]] = p4H[g[375]], dqf5u6[g[515]] = l9$z[g[234]][g[516]], dqf5u6[g[517]] = l9$z[g[234]][g[517]];if (l9$z[g[234]][g[518]]) dqf5u6[g[518]] = parseInt(l9$z[g[234]][g[518]]);console[g[47]](g[519] + JSON[g[28]](dqf5u6[g[517]])), p4H[g[355]] == 0x1 && dqf5u6[g[517]] && dqf5u6[g[517]][g[520]] == 0x1 && (p4H[g[521]] = 0x1, window[g[37]][g[38]][g[522]]()), pHS14();
  } else {
    if (p4H[g[505]][g[523]] >= 0x3) {
      var u95v2b = l9$z ? l9$z[g[235]] : '';window[g[248]](0xc, g[524] + u95v2b), pH1(JSON[g[28]](l9$z)), window[g[220]](g[525] + u95v2b);
    } else sendApi(p4H[g[181]], g[306], { 'platform': p4H[g[179]], 'partner_id': p4H[g[189]], 'token': p4H[g[304]], 'game_pkg': p4H[g[23]], 'deviceId': p4H[g[190]], 'scene': g[307] + p4H[g[191]] }, function (xcopzm) {
      if (!xcopzm || xcopzm[g[235]] != g[323]) {
        window[g[220]](g[325] + xcopzm && xcopzm[g[235]]);return;
      }p4H[g[328]] = String(xcopzm[g[329]]), p4H[g[330]] = String(xcopzm[g[331]]), setTimeout(function () {
        pH1S4(p4H[g[505]][g[523]] + 0x1, p4H[g[505]][g[25]]);
      }, 0x5dc);
    }, pSH4, pH1, function (l$9) {
      return l$9[g[235]] == g[323] || l$9[g[235]] == g[526];
    });
  }
}, window[g[527]] = function () {
  ServerLoading[g[38]][g[367]](p4H[g[355]]), window[g[206]] = !![], window[g[69]]();
}, window[g[68]] = function () {
  if (window[g[67]] && window[g[76]] && window[g[207]] && window[g[208]] && window[g[209]] && window[g[211]]) {
    if (!window[g[528]][g[38]]) {
      console[g[47]](g[529] + window[g[528]][g[38]]);var ny_w = wx[g[530]](),
          gnkiy = ny_w[g[155]] ? ny_w[g[155]] : 0x0,
          v2q5ud = { 'cdn': window[g[16]][g[22]], 'spareCdn': window[g[16]][g[289]], 'newRegister': window[g[16]][g[355]], 'wxPC': window[g[16]][g[126]], 'wxIOS': window[g[16]][g[120]], 'wxAndroid': window[g[16]][g[123]], 'wxParam': { 'limitLoad': window[g[16]][g[130]], 'benchmarkLevel': window[g[16]][g[131]], 'wxFrom': window[g[6]][g[296]] == g[531] ? 0x1 : 0x0, 'wxSDKVersion': window[g[45]] }, 'configType': window[g[16]][g[200]], 'exposeType': window[g[16]][g[202]], 'scene': gnkiy };new window[g[528]](v2q5ud, window[g[16]][g[21]], window[g[173]]);
    }
  }
}, window[g[69]] = function () {
  if (window[g[67]] && window[g[76]] && window[g[207]] && window[g[208]] && window[g[209]] && window[g[211]] && window[g[206]] && window[g[210]]) {
    p14HS();if (!pHS4) {
      pHS4 = !![];if (!window[g[528]][g[38]]) window[g[68]]();var qtrfd = 0x0,
          xcm4o = wx[g[532]]();xcm4o && (window[g[16]][g[125]] && (qtrfd = xcm4o[g[115]]), console[g[1]](g[533] + xcm4o[g[115]] + g[534] + xcm4o[g[116]] + g[535] + xcm4o[g[117]] + g[536] + xcm4o[g[118]] + g[537] + xcm4o[g[538]] + g[539] + xcm4o[g[540]]));var xg4ic = {};for (const v5qfu in p4H[g[24]]) {
        xg4ic[v5qfu] = p4H[g[24]][v5qfu];
      }var cmpxo = { 'channel': window[g[16]][g[194]], 'account': window[g[16]][g[20]], 'userId': window[g[16]][g[326]], 'cdn': window[g[16]][g[22]], 'data': window[g[16]][g[234]], 'package': window[g[16]][g[177]], 'newRegister': window[g[16]][g[355]], 'pkgName': window[g[16]][g[23]], 'partnerId': window[g[16]][g[189]], 'platform_uid': window[g[16]][g[327]], 'deviceId': window[g[16]][g[190]], 'selectedServer': xg4ic, 'configType': window[g[16]][g[200]], 'exposeType': window[g[16]][g[202]], 'debugUsers': window[g[16]][g[197]], 'wxMenuTop': qtrfd, 'wxShield': window[g[16]][g[204]] };if (window[g[378]]) for (var hs08a in window[g[378]]) {
        cmpxo[hs08a] = window[g[378]][hs08a];
      }window[g[528]][g[38]][g[541]](cmpxo);if (p4H[g[24]] && p4H[g[24]][g[25]]) localStorage[g[542]](g[334] + p4H[g[23]] + p4H[g[20]], p4H[g[24]][g[25]]);
    }
  } else console[g[1]](g[543] + window[g[67]] + g[544] + window[g[76]] + g[545] + window[g[207]] + g[546] + window[g[208]] + g[547] + window[g[209]] + g[548] + window[g[211]] + g[549] + window[g[206]] + g[550] + window[g[210]]);
};