var g = wx.u$;
require('tBFtt.js'), window[g[972]][g[973]][g[974]] = null, window['client_pb'] = require('tCLIENTtt.js'), window[g[975]] = window[g[972]][g[976]][g[977]](client_pb);