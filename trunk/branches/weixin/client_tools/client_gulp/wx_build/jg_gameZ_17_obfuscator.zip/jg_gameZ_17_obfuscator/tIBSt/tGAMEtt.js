var g = wx.u$;
console[g[1]](g[2]), window[g[3]], wx[g[4]](function (gc4x) {
  if (gc4x) {
    if (gc4x[g[5]]) {
      var zlmo$ = window[g[6]][g[7]][g[8]](new RegExp(/\./, 'g'), '_'),
          j_gy = gc4x[g[5]],
          u5vdq2 = j_gy[g[9]](/(ttttttt\/tGAMEtt.js:)[0-9]{1,60}(:)/g);if (u5vdq2) for (var p4cgxi = 0x0; p4cgxi < u5vdq2[g[10]]; p4cgxi++) {
        if (u5vdq2[p4cgxi] && u5vdq2[p4cgxi][g[10]] > 0x0) {
          var kew8n = parseInt(u5vdq2[p4cgxi][g[8]](g[11], '')[g[8]](':', ''));j_gy = j_gy[g[8]](u5vdq2[p4cgxi], u5vdq2[p4cgxi][g[8]](':' + kew8n + ':', ':' + (kew8n - 0x2) + ':'));
        }
      }j_gy = j_gy[g[8]](new RegExp(g[12], 'g'), g[13] + zlmo$ + g[14]), j_gy = j_gy[g[8]](new RegExp(g[15], 'g'), g[13] + zlmo$ + g[14]), gc4x[g[5]] = j_gy;
    }var e8_h = { 'id': window[g[16]][g[17]], 'role': window[g[16]][g[18]], 'level': window[g[16]][g[19]], 'user': window[g[16]][g[20]], 'version': window[g[16]][g[21]], 'cdn': window[g[16]][g[22]], 'pkgName': window[g[16]][g[23]], 'gamever': window[g[6]][g[7]], 'serverid': window[g[16]][g[24]] ? window[g[16]][g[24]][g[25]] : 0x0, 'systemInfo': window[g[26]], 'error': g[27], 'stack': gc4x ? gc4x[g[5]] : '' },
        rf5qd = JSON[g[28]](e8_h);console[g[29]](g[30] + rf5qd), (!window[g[3]] || window[g[3]] != e8_h[g[29]]) && (window[g[3]] = e8_h[g[29]], window[g[31]](e8_h));
  }
});import 'ttfttt.js';import 'tt112tt.js';window[g[32]] = require(g[33]);import 'tINDtt.js';import 'ttLIB23tt.js';import 'tWXMtadtt.js';import 'ttINItt.js';console[g[1]](g[34]), console[g[1]](g[35]), p14SH({ 'title': g[36] });var _dd2uv5q = { 'pT1H4S': !![] };new window[g[37]](_dd2uv5q), window[g[37]][g[38]][g[39]]();if (window[g[40]]) clearInterval(window[g[40]]);window[g[40]] = null, window[g[41]] = function (mozlp, mz7o$) {
  if (!mozlp || !mz7o$) return 0x0;mozlp = mozlp[g[42]]('.'), mz7o$ = mz7o$[g[42]]('.');const vdquf5 = Math[g[43]](mozlp[g[10]], mz7o$[g[10]]);while (mozlp[g[10]] < vdquf5) {
    mozlp[g[44]]('0');
  }while (mz7o$[g[10]] < vdquf5) {
    mz7o$[g[44]]('0');
  }for (var e8ha0s = 0x0; e8ha0s < vdquf5; e8ha0s++) {
    const $2v97b = parseInt(mozlp[e8ha0s]),
          zl7mco = parseInt(mz7o$[e8ha0s]);if ($2v97b > zl7mco) return 0x1;else {
      if ($2v97b < zl7mco) return -0x1;
    }
  }return 0x0;
}, window[g[45]] = wx[g[46]]()[g[45]], console[g[47]](g[48] + window[g[45]]);var _dheaw = wx[g[49]]();_dheaw[g[50]](function (qv5u9) {
  console[g[47]](g[51] + qv5u9[g[52]]);
}), _dheaw[g[53]](function () {
  wx[g[54]]({ 'title': g[55], 'content': g[56], 'showCancel': ![], 'success': function (qdtf) {
      _dheaw[g[57]]();
    } });
}), _dheaw[g[58]](function () {
  console[g[47]](g[59]);
}), window[g[60]] = function () {
  console[g[47]](g[61]);var b9v72$ = wx[g[62]]({ 'name': g[63], 'success': function (mc4i) {
      console[g[47]](g[64]), console[g[47]](mc4i), mc4i && mc4i[g[65]] == g[66] ? (window[g[67]] = !![], window[g[68]](), window[g[69]]()) : setTimeout(function () {
        window[g[60]]();
      }, 0x1f4);
    }, 'fail': function (pmxzo) {
      console[g[47]](g[70]), console[g[47]](pmxzo), setTimeout(function () {
        window[g[60]]();
      }, 0x1f4);
    } });b9v72$ && b9v72$[g[71]](_swhe8 => {});
}, window[g[72]] = function () {
  console[g[47]](g[73]);var jn4i = wx[g[62]]({ 'name': g[74], 'success': function (igjn) {
      console[g[47]](g[75]), console[g[47]](igjn), igjn && igjn[g[65]] == g[66] ? (window[g[76]] = !![], window[g[68]](), window[g[69]]()) : setTimeout(function () {
        window[g[72]]();
      }, 0x1f4);
    }, 'fail': function (r5q6fd) {
      console[g[47]](g[77]), console[g[47]](r5q6fd), setTimeout(function () {
        window[g[72]]();
      }, 0x1f4);
    } });jn4i && jn4i[g[71]](mlzcop => {});
}, window[g[78]] = function () {
  window[g[41]](window[g[45]], g[79]) >= 0x0 ? (console[g[47]](g[80] + window[g[45]] + g[81]), window[g[82]](), window[g[60]](), window[g[72]]()) : (window[g[83]](g[84], window[g[45]]), wx[g[54]]({ 'title': g[85], 'content': g[86] }));
}, window[g[26]] = '', wx[g[87]]({ 'success'(zxopcm) {
    window[g[26]] = g[88] + zxopcm[g[89]] + g[90] + zxopcm[g[91]] + g[92] + zxopcm[g[93]] + g[94] + zxopcm[g[95]] + g[96] + zxopcm[g[97]] + g[98] + zxopcm[g[45]] + g[99] + zxopcm[g[100]], console[g[47]](window[g[26]]), console[g[47]](g[101] + zxopcm[g[102]] + g[103] + zxopcm[g[104]] + g[105] + zxopcm[g[106]] + g[107] + zxopcm[g[108]] + g[109] + zxopcm[g[110]] + g[111] + zxopcm[g[112]] + g[113] + (zxopcm[g[114]] ? zxopcm[g[114]][g[115]] + ',' + zxopcm[g[114]][g[116]] + ',' + zxopcm[g[114]][g[117]] + ',' + zxopcm[g[114]][g[118]] : ''));var bv92$u = zxopcm[g[95]] ? zxopcm[g[95]][g[119]]() : '',
        qud52 = zxopcm[g[91]] ? zxopcm[g[91]][g[119]]()[g[8]]('\x20', '') : '';window[g[16]][g[120]] = bv92$u[g[121]](g[122]) != -0x1, window[g[16]][g[123]] = bv92$u[g[121]](g[124]) != -0x1, window[g[16]][g[125]] = bv92$u[g[121]](g[122]) != -0x1 || bv92$u[g[121]](g[124]) != -0x1, window[g[16]][g[126]] = bv92$u[g[121]](g[127]) != -0x1 || bv92$u[g[121]](g[128]) != -0x1, window[g[16]][g[129]] = zxopcm[g[97]] ? zxopcm[g[97]][g[119]]() : '', window[g[16]][g[130]] = ![], window[g[16]][g[131]] = 0x2;if (bv92$u[g[121]](g[124]) != -0x1) {
      if (zxopcm[g[100]] >= 0x18) window[g[16]][g[131]] = 0x3;else window[g[16]][g[131]] = 0x2;
    } else {
      if (bv92$u[g[121]](g[122]) != -0x1) {
        if (zxopcm[g[100]] && zxopcm[g[100]] >= 0x14) window[g[16]][g[131]] = 0x3;else {
          if (qud52[g[121]](g[132]) != -0x1 || qud52[g[121]](g[133]) != -0x1 || qud52[g[121]](g[134]) != -0x1 || qud52[g[121]](g[135]) != -0x1 || qud52[g[121]](g[136]) != -0x1) window[g[16]][g[131]] = 0x2;else window[g[16]][g[131]] = 0x3;
        }
      } else window[g[16]][g[131]] = 0x2;
    }console[g[47]](g[137] + window[g[16]][g[130]] + g[138] + window[g[16]][g[131]]);
  } }), wx[g[139]]({ 'success': function (hkw8_) {
    console[g[47]](g[140] + hkw8_[g[141]] + g[142] + hkw8_[g[143]]);
  } }), wx[g[144]]({ 'success': function (l7z$bo) {
    console[g[47]](g[145] + l7z$bo[g[146]]);
  } }), wx[g[147]]({ 'keepScreenOn': !![] }), wx[g[148]](function (fqu65d) {
  console[g[47]](g[145] + fqu65d[g[146]] + g[149] + fqu65d[g[150]]);
}), wx[g[151]](function (vb$92) {
  window[g[152]] = vb$92, window[g[153]] && window[g[152]] && (console[g[1]](g[154] + window[g[152]][g[155]]), window[g[153]](window[g[152]]), window[g[152]] = null);
}), window[g[156]] = 0x0, window[g[157]] = 0x0, window[g[158]] = null, wx[g[159]](function () {
  window[g[157]]++;var whk8e = Date[g[160]]();(window[g[156]] == 0x0 || whk8e - window[g[156]] > 0x1d4c0) && (console[g[161]](g[162]), wx[g[163]]());if (window[g[157]] >= 0x2) {
    window[g[157]] = 0x0, console[g[29]](g[164]), wx[g[165]]('0', 0x1);if (window[g[16]] && window[g[16]][g[120]]) window[g[83]](g[166], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});