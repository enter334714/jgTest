var k = wx.$f;
import fwn8e from '../ffffsdk/fffsdk.js';window[k[87702]] = { 'wxVersion': window[k[60538]][k[87604]] }, window[k[87703]] = ![], window['F$6L'] = 0x1, window[k[87704]] = 0x1, window['F$8L6'] = !![], window[k[87705]] = !![], window['F$I08L6'] = '', window['F$L6'] = { 'base_cdn': k[87706], 'cdn': k[87706] }, F$L6[k[87707]] = {}, F$L6[k[83641]] = '0', F$L6[k[64318]] = window[k[87702]][k[87708]], F$L6[k[87676]] = '', F$L6['os'] = '1', F$L6[k[87709]] = k[87710], F$L6[k[87711]] = k[87712], F$L6[k[87713]] = k[87714], F$L6[k[87715]] = k[87716], F$L6[k[87717]] = k[87718], F$L6[k[82394]] = '1', F$L6[k[83947]] = '', F$L6[k[83949]] = '', F$L6[k[87719]] = 0x0, F$L6[k[87720]] = {}, F$L6[k[87721]] = parseInt(F$L6[k[82394]]), F$L6[k[83945]] = F$L6[k[82394]], F$L6[k[83941]] = {}, F$L6['F$0L'] = k[87722], F$L6[k[87723]] = ![], F$L6[k[71317]] = k[87724], F$L6[k[83918]] = Date[k[60082]](), F$L6[k[70946]] = k[87725], F$L6[k[60689]] = '_a', F$L6[k[87726]] = 0x2, F$L6[k[60100]] = 0x7c1, F$L6[k[87708]] = window[k[87702]][k[87708]], F$L6[k[60713]] = ![], F$L6[k[61003]] = ![], F$L6[k[70467]] = ![], F$L6[k[83643]] = ![], window['F$86L'] = 0x5, window['F$86'] = ![], window['F$68'] = ![], window['F$L86'] = ![], window[k[87727]] = ![], window[k[87728]] = ![], window['F$L68'] = ![], window['F$8L'] = ![], window['F$L8'] = ![], window['F$68L'] = ![], window[k[63806]] = function (th0fmi) {
  console[k[60466]](k[63806], th0fmi), wx[k[64571]]({}), wx[k[87627]]({ 'title': k[65824], 'content': th0fmi, 'success'(mvfibt) {
      if (mvfibt[k[87480]]) console[k[60466]](k[87729]);else mvfibt[k[60534]] && console[k[60466]](k[87457]);
    } });
}, window['F$08L6'] = function (fmith) {
  console[k[60466]](k[87730], fmith), F$0L68(), wx[k[87627]]({ 'title': k[65824], 'content': fmith, 'confirmText': k[87731], 'cancelText': k[77404], 'success'(m0thq) {
      if (m0thq[k[87480]]) window['F$L0']();else m0thq[k[60534]] && (console[k[60466]](k[87732]), wx[k[84100]]({}));
    } });
}, window[k[87733]] = function (fihbt) {
  console[k[60466]](k[87733], fihbt), wx[k[87627]]({ 'title': k[65824], 'content': fihbt, 'confirmText': k[84075], 'showCancel': ![], 'complete'(yp3a) {
      console[k[60466]](k[87732]), wx[k[84100]]({});
    } });
}, window['F$086L'] = ![], window['F$0L86'] = function (q0fmt) {
  window['F$086L'] = !![], wx[k[64570]](q0fmt);
}, window['F$0L68'] = function () {
  window['F$086L'] && (window['F$086L'] = ![], wx[k[64571]]({}));
}, window['F$068L'] = function (sowdjc) {
  window[k[87619]][k[60144]]['F$068L'](sowdjc);
}, window[k[71202]] = function (imbhtf, a7$yp) {
  fwn8e[k[71202]](imbhtf, function (qh5t0k) {
    qh5t0k && qh5t0k[k[60011]] ? qh5t0k[k[60011]][k[63741]] == 0x1 ? a7$yp(!![]) : (a7$yp(![]), console[k[60077]](k[87734] + qh5t0k[k[60011]][k[87735]])) : console[k[60466]](k[71202], qh5t0k);
  });
}, window['F$06L8'] = function (tmbh) {
  console[k[60466]](k[87736], tmbh);
}, window['F$0L6'] = function (xerz8) {}, window['F$06L'] = function (edxwsn, r378$z, btivmf) {}, window['F$06'] = function ($r87z3) {
  console[k[60466]](k[87737], $r87z3), window[k[87619]][k[60144]][k[87738]](), window[k[87619]][k[60144]][k[87739]](), window[k[87619]][k[60144]][k[87740]]();
}, window['F$60'] = function (q4_25) {
  window['F$08L6'](k[87741]);var zwens = { 'id': window['F$L6'][k[87609]], 'role': window['F$L6'][k[64248]], 'level': window['F$L6'][k[87610]], 'account': window['F$L6'][k[83946]], 'version': window['F$L6'][k[60100]], 'cdn': window['F$L6'][k[64138]], 'pkgName': window['F$L6'][k[83947]], 'gamever': window[k[60538]][k[87604]], 'serverid': window['F$L6'][k[83941]] ? window['F$L6'][k[83941]][k[70632]] : 0x0, 'systemInfo': window[k[87611]], 'error': k[87742], 'stack': q4_25 ? q4_25 : k[87741] },
      k24q5_ = JSON[k[64124]](zwens);console[k[60124]](k[87743] + k24q5_), window['F$0L'](k24q5_);
}, window['F$L06'] = function (ojcs6d) {
  var z7r$e = JSON[k[60510]](ojcs6d);z7r$e[k[87744]] = window[k[60538]][k[87604]], z7r$e[k[87745]] = window['F$L6'][k[83941]] ? window['F$L6'][k[83941]][k[70632]] : 0x0, z7r$e[k[87611]] = window[k[87611]];var fmhq0t = JSON[k[64124]](z7r$e);console[k[60124]](k[87746] + fmhq0t), window['F$0L'](fmhq0t);
}, window['F$L60'] = function (cjnws, bg1v) {
  var thqmf0 = { 'id': window['F$L6'][k[87609]], 'role': window['F$L6'][k[64248]], 'level': window['F$L6'][k[87610]], 'account': window['F$L6'][k[83946]], 'version': window['F$L6'][k[60100]], 'cdn': window['F$L6'][k[64138]], 'pkgName': window['F$L6'][k[83947]], 'gamever': window[k[60538]][k[87604]], 'serverid': window['F$L6'][k[83941]] ? window['F$L6'][k[83941]][k[70632]] : 0x0, 'systemInfo': window[k[87611]], 'error': cjnws, 'stack': bg1v },
      o2cj64 = JSON[k[64124]](thqmf0);console[k[60095]](k[87747] + o2cj64), window['F$0L'](o2cj64);
}, window['F$0L'] = function (py$73a) {
  if (window['F$L6'][k[87677]] == k[87748]) return;var swnxe = F$L6['F$0L'] + k[87749] + F$L6[k[83946]];wx[k[60461]]({ 'url': swnxe, 'method': k[87441], 'data': py$73a, 'header': { 'content-type': k[87750], 'cache-control': k[87751] }, 'success': function (y78r3) {
      DEBUG && console[k[60466]](k[87752], swnxe, py$73a, y78r3);
    }, 'fail': function (cwosd) {
      DEBUG && console[k[60466]](k[87752], swnxe, py$73a, cwosd);
    }, 'complete': function () {} });
}, window[k[87753]] = function () {
  function fbtihm() {
    return ((0x1 + Math[k[60118]]()) * 0x10000 | 0x0)[k[60265]](0x10)[k[60483]](0x1);
  }return fbtihm() + fbtihm() + '-' + fbtihm() + '-' + fbtihm() + '-' + fbtihm() + '+' + fbtihm() + fbtihm() + fbtihm();
}, window['F$L0'] = function () {
  console[k[60466]](k[87754]);var mvfubi = fwn8e[k[87755]]();F$L6[k[83945]] = mvfubi[k[87756]], F$L6[k[87721]] = mvfubi[k[87756]], F$L6[k[82394]] = mvfubi[k[87756]], F$L6[k[83947]] = mvfubi[k[87757]];var odc26 = { 'game_ver': F$L6[k[64318]] };F$L6[k[83949]] = this[k[87753]](), F$0L86({ 'title': k[87758] }), fwn8e[k[60358]](odc26, this['F$60L'][k[60073]](this));
}, window['F$60L'] = function (rxne8) {
  var nzwe = rxne8[k[87759]];console[k[60466]](k[87760] + nzwe + k[87761] + (nzwe == 0x1) + k[87762] + rxne8[k[87604]] + k[87763] + window[k[87702]][k[87708]]);if (!rxne8[k[87604]] || window['F$I860L'](window[k[87702]][k[87708]], rxne8[k[87604]]) < 0x0) console[k[60466]](k[87764]), F$L6[k[87711]] = k[87765], F$L6[k[87713]] = k[87766], F$L6[k[87715]] = k[87767], F$L6[k[64138]] = k[87768], F$L6[k[83640]] = k[87769], F$L6[k[87770]] = k[87771], F$L6[k[60713]] = ![];else window['F$I860L'](window[k[87702]][k[87708]], rxne8[k[87604]]) == 0x0 ? (console[k[60466]](k[87772]), F$L6[k[87711]] = k[87712], F$L6[k[87713]] = k[87714], F$L6[k[87715]] = k[87716], F$L6[k[64138]] = k[87773], F$L6[k[83640]] = k[87769], F$L6[k[87770]] = k[87774], F$L6[k[60713]] = !![]) : (console[k[60466]](k[87775]), F$L6[k[87711]] = k[87712], F$L6[k[87713]] = k[87714], F$L6[k[87715]] = k[87716], F$L6[k[64138]] = k[87773], F$L6[k[83640]] = k[87769], F$L6[k[87770]] = k[87774], F$L6[k[60713]] = ![]);F$L6[k[87719]] = config[k[87296]] ? config[k[87296]] : 0x0, this['F$8L06'](), this['F$8L60'](), window[k[87776]] = 0x5, F$0L86({ 'title': k[87777] }), fwn8e[k[87512]](this['F$6L0'][k[60073]](this));
}, window[k[87776]] = 0x5, window['F$6L0'] = function (bmiv, fuvimb) {
  if (bmiv == 0x0 && fuvimb && fuvimb[k[87385]]) {
    F$L6[k[87778]] = fuvimb[k[87385]];var $ay3r = this;F$0L86({ 'title': k[87779] }), sendApi(F$L6[k[87711]], k[87780], { 'platform': F$L6[k[87709]], 'partner_id': F$L6[k[82394]], 'token': fuvimb[k[87385]], 'game_pkg': F$L6[k[83947]], 'deviceId': F$L6[k[83949]], 'scene': k[87781] + F$L6[k[87719]] }, this['F$80L6'][k[60073]](this), F$86L, F$60);
  } else fuvimb && fuvimb[k[84122]] && window[k[87776]] > 0x0 && (fuvimb[k[84122]][k[60114]](k[87782]) != -0x1 || fuvimb[k[84122]][k[60114]](k[87783]) != -0x1 || fuvimb[k[84122]][k[60114]](k[87784]) != -0x1 || fuvimb[k[84122]][k[60114]](k[87785]) != -0x1 || fuvimb[k[84122]][k[60114]](k[87786]) != -0x1 || fuvimb[k[84122]][k[60114]](k[87787]) != -0x1) ? (window[k[87776]]--, fwn8e[k[87512]](this['F$6L0'][k[60073]](this))) : (window['F$L60'](k[87788], JSON[k[64124]]({ 'status': bmiv, 'data': fuvimb })), window['F$08L6'](k[87789] + (fuvimb && fuvimb[k[84122]] ? '，' + fuvimb[k[84122]] : '')));
}, window['F$80L6'] = function (d6sco) {
  if (!d6sco) {
    window['F$L60'](k[87790], k[87791]), window['F$08L6'](k[87792]);return;
  }if (d6sco[k[63741]] != k[69176]) {
    window['F$L60'](k[87790], JSON[k[64124]](d6sco)), window['F$08L6'](k[87793] + d6sco[k[63741]]);return;
  }F$L6[k[82393]] = String(d6sco[k[83946]]), F$L6[k[83946]] = String(d6sco[k[83946]]), F$L6[k[83916]] = String(d6sco[k[83916]]), F$L6[k[83945]] = String(d6sco[k[83916]]), F$L6[k[83948]] = String(d6sco[k[83948]]), F$L6[k[87794]] = String(d6sco[k[70618]]), F$L6[k[87795]] = String(d6sco[k[60820]]), F$L6[k[70618]] = '';var exrnz = this;F$0L86({ 'title': k[87796] }), sendApi(F$L6[k[87711]], k[87797], { 'partner_id': F$L6[k[82394]], 'uid': F$L6[k[83946]], 'version': F$L6[k[64318]], 'game_pkg': F$L6[k[83947]], 'device': F$L6[k[83949]] }, exrnz['F$806L'][k[60073]](exrnz), F$86L, F$60);
}, window['F$806L'] = function (k25q_) {
  if (!k25q_) {
    window['F$08L6'](k[87798]);return;
  }if (k25q_[k[63741]] != k[69176]) {
    window['F$08L6'](k[87799] + k25q_[k[63741]]);return;
  }if (!k25q_[k[60011]] || k25q_[k[60011]][k[60013]] == 0x0) {
    window['F$08L6'](k[87800]);return;
  }F$L6[k[60609]] = k25q_[k[87801]], F$L6[k[83941]] = { 'server_id': String(k25q_[k[60011]][0x0][k[70632]]), 'server_name': String(k25q_[k[60011]][0x0][k[87802]]), 'entry_ip': k25q_[k[60011]][0x0][k[83969]], 'entry_port': parseInt(k25q_[k[60011]][0x0][k[83970]]), 'status': F$L80(k25q_[k[60011]][0x0]), 'start_time': k25q_[k[60011]][0x0][k[87803]], 'cdn': F$L6[k[64138]] }, this['F$6L80']();
}, window['F$6L80'] = function () {
  if (F$L6[k[60609]] == 0x1) {
    var d6ojc = F$L6[k[83941]][k[60105]];if (d6ojc === -0x1 || d6ojc === 0x0) {
      window['F$08L6'](d6ojc === -0x1 ? k[87804] : k[87805]);return;
    }F$608L(0x0, F$L6[k[83941]][k[70632]]), window[k[87619]][k[60144]][k[87806]](F$L6[k[60609]]);
  } else window[k[87619]][k[60144]][k[87807]](), F$0L68();window['F$L8'] = !![], window['F$68L0'](), window['F$6L08']();
}, window['F$8L06'] = function () {
  sendApi(F$L6[k[87711]], k[87808], { 'game_pkg': F$L6[k[83947]], 'version_name': F$L6[k[87770]] }, this[k[87809]][k[60073]](this), F$86L, F$60);
}, window[k[87809]] = function (o2cd6j) {
  if (!o2cd6j) {
    window['F$08L6'](k[87810]);return;
  }if (o2cd6j[k[63741]] != k[69176]) {
    window['F$08L6'](k[87811] + o2cd6j[k[63741]]);return;
  }if (!o2cd6j[k[60011]] || !o2cd6j[k[60011]][k[64318]]) {
    window['F$08L6'](k[87812] + (o2cd6j[k[60011]] && o2cd6j[k[60011]][k[64318]]));return;
  }o2cd6j[k[60011]][k[87813]] && o2cd6j[k[60011]][k[87813]][k[60013]] > 0xa && (F$L6[k[87814]] = o2cd6j[k[60011]][k[87813]], F$L6[k[64138]] = o2cd6j[k[60011]][k[87813]]), o2cd6j[k[60011]][k[64318]] && (F$L6[k[60100]] = o2cd6j[k[60011]][k[64318]]), console[k[60077]](k[84079] + F$L6[k[60100]] + k[87815] + F$L6[k[87770]]), window['F$L68'] = !![], window['F$68L0'](), window['F$6L08']();
}, window[k[87816]], window['F$8L60'] = function () {
  sendApi(F$L6[k[87711]], k[87817], { 'game_pkg': F$L6[k[83947]] }, this['F$860L'][k[60073]](this), F$86L, F$60);
}, window['F$860L'] = function (dcos6) {
  if (dcos6[k[63741]] === k[69176] && dcos6[k[60011]]) {
    window[k[87816]] = dcos6[k[60011]];for (var exz87 in dcos6[k[60011]]) {
      F$L6[exz87] = dcos6[k[60011]][exz87];
    }
  } else console[k[60077]](k[87818] + dcos6[k[63741]]);window['F$8L'] = !![], window['F$6L08']();
}, window[k[87819]] = function (z87r$3, cjd6os, cjnsdw, u9gbv, uvimb1, wnzex8, ok426, wdjsnx, owjd) {
  uvimb1 = String(uvimb1);var xnwez = ok426,
      r7z8e$ = wdjsnx;F$L6[k[87707]][uvimb1] = { 'productid': uvimb1, 'productname': xnwez, 'productdesc': r7z8e$, 'roleid': z87r$3, 'rolename': cjd6os, 'rolelevel': cjnsdw, 'price': wnzex8, 'callback': owjd }, sendApi(F$L6[k[87715]], k[87820], { 'game_pkg': F$L6[k[83947]], 'server_id': F$L6[k[83941]][k[70632]], 'server_name': F$L6[k[83941]][k[87802]], 'level': cjnsdw, 'uid': F$L6[k[83946]], 'role_id': z87r$3, 'role_name': cjd6os, 'product_id': uvimb1, 'product_name': xnwez, 'product_desc': r7z8e$, 'money': wnzex8, 'partner_id': F$L6[k[82394]] }, toPayCallBack, F$86L, F$60);
}, window[k[87821]] = function (hbfitm) {
  if (hbfitm) {
    if (hbfitm[k[87822]] === 0xc8 || hbfitm[k[63741]] == k[69176]) {
      var cwsnd = F$L6[k[87707]][String(hbfitm[k[87823]])];if (cwsnd[k[60325]]) cwsnd[k[60325]](hbfitm[k[87823]], hbfitm[k[87824]], -0x1);fwn8e[k[87555]]({ 'cpbill': hbfitm[k[87824]], 'productid': hbfitm[k[87823]], 'productname': cwsnd[k[87825]], 'productdesc': cwsnd[k[87826]], 'serverid': F$L6[k[83941]][k[70632]], 'servername': F$L6[k[83941]][k[87802]], 'roleid': cwsnd[k[87827]], 'rolename': cwsnd[k[87828]], 'rolelevel': cwsnd[k[87829]], 'price': cwsnd[k[85535]], 'extension': JSON[k[64124]]({ 'cp_order_id': hbfitm[k[87824]] }) }, function (jd6osc, nwszex) {
        cwsnd[k[60325]] && jd6osc == 0x0 && cwsnd[k[60325]](hbfitm[k[87823]], hbfitm[k[87824]], jd6osc);console[k[60077]](JSON[k[64124]]({ 'type': k[87830], 'status': jd6osc, 'data': hbfitm, 'role_name': cwsnd[k[87828]] }));if (jd6osc === 0x0) {} else {
          if (jd6osc === 0x1) {} else {
            if (jd6osc === 0x2) {}
          }
        }
      });
    } else alert(hbfitm[k[60077]]);
  }
}, window['F$86L0'] = function () {}, window['F$086'] = function (k_4q05, ibmvt, oc64j2, swjnx, ewsxnz) {
  fwn8e[k[87593]](F$L6[k[83941]][k[70632]], F$L6[k[83941]][k[87802]] || F$L6[k[83941]][k[70632]], k_4q05, ibmvt, oc64j2), sendApi(F$L6[k[87711]], k[87831], { 'game_pkg': F$L6[k[83947]], 'server_id': F$L6[k[83941]][k[70632]], 'role_id': k_4q05, 'uid': F$L6[k[83946]], 'role_name': ibmvt, 'role_type': swjnx, 'level': oc64j2 });
}, window['F$068'] = function (ifmbh, z7$8er, nexzw, dxnsw, $r378y, ufibv, q0kh_5, co46j, mbhfti, wdsxne) {
  F$L6[k[87609]] = ifmbh, F$L6[k[64248]] = z7$8er, F$L6[k[87610]] = nexzw, fwn8e[k[87594]](F$L6[k[83941]][k[70632]], F$L6[k[83941]][k[87802]] || F$L6[k[83941]][k[70632]], ifmbh, z7$8er, nexzw), sendApi(F$L6[k[87711]], k[87832], { 'game_pkg': F$L6[k[83947]], 'server_id': F$L6[k[83941]][k[70632]], 'role_id': ifmbh, 'uid': F$L6[k[83946]], 'role_name': z7$8er, 'role_type': dxnsw, 'level': nexzw, 'evolution': $r378y });
}, window['F$806'] = function (mt0if, $ry783, ezsw, _46o2k, k54, doscj, ewzxns, _co4, rzx7, c64_2) {
  F$L6[k[87609]] = mt0if, F$L6[k[64248]] = $ry783, F$L6[k[87610]] = ezsw, fwn8e[k[87595]](F$L6[k[83941]][k[70632]], F$L6[k[83941]][k[87802]] || F$L6[k[83941]][k[70632]], mt0if, $ry783, ezsw), sendApi(F$L6[k[87711]], k[87832], { 'game_pkg': F$L6[k[83947]], 'server_id': F$L6[k[83941]][k[70632]], 'role_id': mt0if, 'uid': F$L6[k[83946]], 'role_name': $ry783, 'role_type': _46o2k, 'level': ezsw, 'evolution': k54 });
}, window['F$860'] = function (fuvi) {}, window['F$08'] = function (nzxsw) {
  fwn8e[k[87531]](k[87531], function (xezr78) {
    nzxsw && nzxsw(xezr78);
  });
}, window[k[83625]] = function () {
  fwn8e[k[83625]]();
}, window[k[87833]] = function () {
  fwn8e[k[82290]]();
}, window[k[70033]] = function (sndxwe) {
  window['F$608'] = sndxwe, window['F$608'] && window['F$80'] && (console[k[60077]](k[87696] + window['F$80'][k[60748]]), window['F$608'](window['F$80']), window['F$80'] = null);
}, window['F$680'] = function (k4q50, m0fhtq, iuv19, dnxsjw) {
  window[k[60022]](k[87834], { 'game_pkg': window['F$L6'][k[83947]], 'role_id': m0fhtq, 'server_id': iuv19 }, dnxsjw);
}, window['F$L086'] = function (dcj6o, vb9g) {
  function xnwdj(a73yr$) {
    var josd6 = [],
        qt5hk0 = [],
        fmu = window[k[60538]][k[87835]];for (var swjdxn in fmu) {
      var b1ug = Number(swjdxn);(!dcj6o || !dcj6o[k[60013]] || dcj6o[k[60114]](b1ug) != -0x1) && (qt5hk0[k[60029]](fmu[swjdxn]), josd6[k[60029]]([b1ug, 0x3]));
    }window['F$I860L'](window[k[87620]], k[87836]) >= 0x0 ? (console[k[60466]](k[87837]), fwn8e[k[87571]] && fwn8e[k[87571]](qt5hk0, function (wdesx) {
      console[k[60466]](k[87838]), console[k[60466]](wdesx);if (wdesx && wdesx[k[84122]] == k[87572]) for (var zwns in fmu) {
        if (wdesx[fmu[zwns]] == k[87479]) {
          var ds6oc = Number(zwns);for (var tmhf = 0x0; tmhf < josd6[k[60013]]; tmhf++) {
            if (josd6[tmhf][0x0] == ds6oc) {
              josd6[tmhf][0x1] = 0x1;break;
            }
          }
        }
      }window['F$I860L'](window[k[87620]], k[87839]) >= 0x0 ? wx[k[87840]]({ 'withSubscriptions': !![], 'success': function (ne8zxr) {
          var umbfi = ne8zxr[k[87841]][k[87842]];if (umbfi) {
            console[k[60466]](k[87843]), console[k[60466]](umbfi);for (var q5_0h in fmu) {
              if (umbfi[fmu[q5_0h]] == k[87479]) {
                var tfhmb = Number(q5_0h);for (var g19vub = 0x0; g19vub < josd6[k[60013]]; g19vub++) {
                  if (josd6[g19vub][0x0] == tfhmb) {
                    josd6[g19vub][0x1] = 0x2;break;
                  }
                }
              }
            }console[k[60466]](josd6), vb9g && vb9g(josd6);
          } else console[k[60466]](k[87844]), console[k[60466]](ne8zxr), console[k[60466]](josd6), vb9g && vb9g(josd6);
        }, 'fail': function () {
          console[k[60466]](k[87845]), console[k[60466]](josd6), vb9g && vb9g(josd6);
        } }) : (console[k[60466]](k[87846] + window[k[87620]]), console[k[60466]](josd6), vb9g && vb9g(josd6));
    })) : (console[k[60466]](k[87847] + window[k[87620]]), console[k[60466]](josd6), vb9g && vb9g(josd6)), wx[k[87848]](xnwdj);
  }wx[k[87849]](xnwdj);
}, window['F$L068'] = { 'isSuccess': ![], 'level': k[87850], 'isCharging': ![] }, window['F$L806'] = function (wndcj) {
  wx[k[87685]]({ 'success': function (owsjcd) {
      var ihbt = window['F$L068'];ihbt[k[87851]] = !![], ihbt[k[64224]] = Number(owsjcd[k[64224]])['toFixed'](0x0), ihbt[k[87688]] = owsjcd[k[87688]], wndcj && wndcj(ihbt[k[87851]], ihbt[k[64224]], ihbt[k[87688]]);
    }, 'fail': function (vitbmf) {
      console[k[60466]](k[87852], vitbmf[k[84122]]);var mviu = window['F$L068'];wndcj && wndcj(mviu[k[87851]], mviu[k[64224]], mviu[k[87688]]);
    } });
}, window[k[60022]] = function (r78z$e, ivbfm, fmhtq, dscwjn, mbfhi, zrexn, ivm1b, hfimb) {
  if (dscwjn == undefined) dscwjn = 0x1;wx[k[60461]]({ 'url': r78z$e, 'method': ivm1b || k[83839], 'responseType': k[64044], 'data': ivbfm, 'header': { 'content-type': hfimb || k[87750] }, 'success': function (_62ok) {
      DEBUG && console[k[60466]](k[87853], r78z$e, info, _62ok);if (_62ok && _62ok[k[84182]] == 0xc8) {
        var szwn = _62ok[k[60011]];!zrexn || zrexn(szwn) ? fmhtq && fmhtq(szwn) : window['sendFail'](r78z$e, ivbfm, fmhtq, dscwjn, mbfhi, zrexn, _62ok);
      } else window['sendFail'](r78z$e, ivbfm, fmhtq, dscwjn, mbfhi, zrexn, _62ok);
    }, 'fail': function (tifv) {
      DEBUG && console[k[60466]](k[87854], r78z$e, info, tifv), window['sendFail'](r78z$e, ivbfm, fmhtq, dscwjn, mbfhi, zrexn, tifv);
    }, 'complete': function () {} });
}, window['sendFail'] = function (r8zex7, xnedws, qt50h, r8y$73, ry3$a, nsexdw, bi19u) {
  r8y$73 - 0x1 > 0x0 ? setTimeout(function () {
    window[k[60022]](r8zex7, xnedws, qt50h, r8y$73 - 0x1, ry3$a, nsexdw);
  }, 0x3e8) : ry3$a && ry3$a(JSON[k[64124]]({ 'url': r8zex7, 'response': bi19u }));
}, window[k[87855]] = function (snwjdc, o6k_2, ra$y73, $7ay3, bv1ium, mftq0h, oc2d6j) {
  !ra$y73 && (ra$y73 = {});var k0tqh5 = Math[k[60117]](Date[k[60082]]() / 0x3e8);ra$y73[k[60820]] = k0tqh5, ra$y73[k[83760]] = o6k_2;var k6542_ = Object[k[60257]](ra$y73)[k[61007]](),
      tibm = '',
      ewszxn = '';for (var nxe8w = 0x0; nxe8w < k6542_[k[60013]]; nxe8w++) {
    tibm = tibm + (nxe8w == 0x0 ? '' : '&') + k6542_[nxe8w] + ra$y73[k6542_[nxe8w]], ewszxn = ewszxn + (nxe8w == 0x0 ? '' : '&') + k6542_[nxe8w] + '=' + encodeURIComponent(ra$y73[k6542_[nxe8w]]);
  }tibm = tibm + F$L6[k[87717]];var njs = k[87856] + md5(tibm);send(snwjdc + '?' + ewszxn + (ewszxn == '' ? '' : '&') + njs, null, $7ay3, bv1ium, mftq0h, oc2d6j || function (t5khq0) {
    return t5khq0[k[63741]] == k[69176];
  }, null, k[87516]);
}, window['F$L860'] = function (q05k4_, ewnsdx) {
  var o6_2 = 0x0;F$L6[k[83941]] && (o6_2 = F$L6[k[83941]][k[70632]]), sendApi(F$L6[k[87713]], k[87857], { 'partnerId': F$L6[k[82394]], 'gamePkg': F$L6[k[83947]], 'logTime': Math[k[60117]](Date[k[60082]]() / 0x3e8), 'platformUid': F$L6[k[83948]], 'type': q05k4_, 'serverId': o6_2 }, null, 0x2, null, function () {
    return !![];
  });
}, window['F$L608'] = function (buvi1m) {
  sendApi(F$L6[k[87711]], k[87858], { 'partner_id': F$L6[k[82394]], 'uid': F$L6[k[83946]], 'version': F$L6[k[64318]], 'game_pkg': F$L6[k[83947]], 'device': F$L6[k[83949]] }, F$L680, F$86L, F$60);
}, window['F$L680'] = function (ug91v) {
  if (ug91v[k[63741]] === k[69176] && ug91v[k[60011]]) {
    ug91v[k[60011]][k[65099]]({ 'id': -0x2, 'name': k[87859] }), ug91v[k[60011]][k[65099]]({ 'id': -0x1, 'name': k[87860] }), F$L6[k[87861]] = ug91v[k[60011]];if (window[k[71362]]) window[k[71362]][k[87862]]();
  } else F$L6[k[87863]] = ![], window['F$08L6'](k[87864] + ug91v[k[63741]]);
}, window['F$08L'] = function (cswjdo) {
  sendApi(F$L6[k[87711]], k[87865], { 'partner_id': F$L6[k[82394]], 'uid': F$L6[k[83946]], 'version': F$L6[k[64318]], 'game_pkg': F$L6[k[83947]], 'device': F$L6[k[83949]] }, F$0L8, F$86L, F$60);
}, window['F$0L8'] = function (dj6so) {
  F$L6[k[87866]] = ![];if (dj6so[k[63741]] === k[69176] && dj6so[k[60011]]) {
    for (var oc26d = 0x0; oc26d < dj6so[k[60011]][k[60013]]; oc26d++) {
      dj6so[k[60011]][oc26d][k[60105]] = F$L80(dj6so[k[60011]][oc26d]);
    }F$L6[k[87720]][-0x1] = window[k[87867]](dj6so[k[60011]]), window[k[71362]][k[87868]](-0x1);
  } else window['F$08L6'](k[87869] + dj6so[k[63741]]);
}, window[k[87870]] = function (mfviu) {
  sendApi(F$L6[k[87711]], k[87865], { 'partner_id': F$L6[k[82394]], 'uid': F$L6[k[83946]], 'version': F$L6[k[64318]], 'game_pkg': F$L6[k[83947]], 'device': F$L6[k[83949]] }, mfviu, F$86L, F$60);
}, window['F$80L'] = function (tbmf, c4_62o) {
  sendApi(F$L6[k[87711]], k[87871], { 'partner_id': F$L6[k[82394]], 'uid': F$L6[k[83946]], 'version': F$L6[k[64318]], 'game_pkg': F$L6[k[83947]], 'device': F$L6[k[83949]], 'server_group_id': c4_62o }, F$8L0, F$86L, F$60);
}, window['F$8L0'] = function (sdjnc) {
  F$L6[k[87866]] = ![];if (sdjnc[k[63741]] === k[69176] && sdjnc[k[60011]] && sdjnc[k[60011]][k[60011]]) {
    var _q52k = sdjnc[k[60011]][k[87872]],
        bmfvti = [];for (var vftim = 0x0; vftim < sdjnc[k[60011]][k[60011]][k[60013]]; vftim++) {
      sdjnc[k[60011]][k[60011]][vftim][k[60105]] = F$L80(sdjnc[k[60011]][k[60011]][vftim]), (bmfvti[k[60013]] == 0x0 || sdjnc[k[60011]][k[60011]][vftim][k[60105]] != 0x0) && (bmfvti[bmfvti[k[60013]]] = sdjnc[k[60011]][k[60011]][vftim]);
    }F$L6[k[87720]][_q52k] = window[k[87867]](bmfvti), window[k[71362]][k[87868]](_q52k);
  } else window['F$08L6'](k[87873] + sdjnc[k[63741]]);
}, window['F$I86L'] = function (h5k_0) {
  sendApi(F$L6[k[87711]], k[87874], { 'partner_id': F$L6[k[82394]], 'uid': F$L6[k[83946]], 'version': F$L6[k[64318]], 'game_pkg': F$L6[k[83947]], 'device': F$L6[k[83949]] }, reqServerRecommendCallBack, F$86L, F$60);
}, window[k[87875]] = function (wjxn) {
  F$L6[k[87866]] = ![];if (wjxn[k[63741]] === k[69176] && wjxn[k[60011]]) {
    for (var ko24_ = 0x0; ko24_ < wjxn[k[60011]][k[60013]]; ko24_++) {
      wjxn[k[60011]][ko24_][k[60105]] = F$L80(wjxn[k[60011]][ko24_]);
    }F$L6[k[87720]][-0x2] = window[k[87867]](wjxn[k[60011]]), window[k[71362]][k[87868]](-0x2);
  } else alert(k[87876] + wjxn[k[63741]]);
}, window[k[87867]] = function (ncjdw) {
  if (!ncjdw && ncjdw[k[60013]] <= 0x0) return ncjdw;for (let y7$pa = 0x0; y7$pa < ncjdw[k[60013]]; y7$pa++) {
    ncjdw[y7$pa][k[87877]] && ncjdw[y7$pa][k[87877]] == 0x1 && (ncjdw[y7$pa][k[87802]] += k[87878]);
  }return ncjdw;
}, window['F$L08'] = function (hit0f, dcjo2) {
  hit0f = hit0f || F$L6[k[83941]][k[70632]], sendApi(F$L6[k[87711]], k[87879], { 'type': '4', 'game_pkg': F$L6[k[83947]], 'server_id': hit0f }, dcjo2);
}, window[k[87880]] = function (k2o_, thfib, _26oc4, $p7) {
  _26oc4 = _26oc4 || F$L6[k[83941]][k[70632]], sendApi(F$L6[k[87711]], k[87881], { 'type': k2o_, 'game_pkg': thfib, 'server_id': _26oc4 }, $p7);
}, window['F$L80'] = function (h_0k5q) {
  if (h_0k5q) {
    if (h_0k5q[k[60105]] == 0x1) {
      if (h_0k5q[k[87882]] == 0x1) return 0x2;else return 0x1;
    } else return h_0k5q[k[60105]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['F$608L'] = function (_hk05q, exn8r) {
  F$L6[k[87883]] = { 'step': _hk05q, 'server_id': exn8r };var co_62 = this;F$0L86({ 'title': k[87884] }), sendApi(F$L6[k[87711]], k[87885], { 'partner_id': F$L6[k[82394]], 'uid': F$L6[k[83946]], 'game_pkg': F$L6[k[83947]], 'server_id': exn8r, 'platform': F$L6[k[83916]], 'platform_uid': F$L6[k[83948]], 'check_login_time': F$L6[k[87795]], 'check_login_sign': F$L6[k[87794]], 'version_name': F$L6[k[87770]] }, F$60L8, F$86L, F$60, function (h50tq) {
    return h50tq[k[63741]] == k[69176] || h50tq[k[60077]] == k[87886] || h50tq[k[60077]] == k[87887];
  });
}, window['F$60L8'] = function (j6c2do) {
  var sdnjcw = this;if (j6c2do[k[63741]] === k[69176] && j6c2do[k[60011]]) {
    var mhitf0 = F$L6[k[83941]];mhitf0[k[87888]] = F$L6[k[87721]], mhitf0[k[70618]] = String(j6c2do[k[60011]][k[87889]]), mhitf0[k[83918]] = parseInt(j6c2do[k[60011]][k[60820]]);if (j6c2do[k[60011]][k[83917]]) mhitf0[k[83917]] = parseInt(j6c2do[k[60011]][k[83917]]);else mhitf0[k[83917]] = parseInt(j6c2do[k[60011]][k[70632]]);mhitf0[k[87890]] = 0x0, mhitf0[k[64138]] = F$L6[k[87814]], mhitf0[k[87891]] = j6c2do[k[60011]][k[87892]], mhitf0[k[87893]] = j6c2do[k[60011]][k[87893]], console[k[60466]](k[87894] + JSON[k[64124]](mhitf0[k[87893]])), F$L6[k[60609]] == 0x1 && mhitf0[k[87893]] && mhitf0[k[87893]][k[87895]] == 0x1 && (F$L6[k[87896]] = 0x1, window[k[87619]][k[60144]]['F$I6L']()), F$680L();
  } else F$L6[k[87883]][k[66554]] >= 0x3 ? (F$60(JSON[k[64124]](j6c2do)), window['F$08L6'](k[87897] + j6c2do[k[63741]])) : sendApi(F$L6[k[87711]], k[87780], { 'platform': F$L6[k[87709]], 'partner_id': F$L6[k[82394]], 'token': F$L6[k[87778]], 'game_pkg': F$L6[k[83947]], 'deviceId': F$L6[k[83949]], 'scene': k[87781] + F$L6[k[87719]] }, function (q25_) {
    if (!q25_ || q25_[k[63741]] != k[69176]) {
      window['F$08L6'](k[87793] + q25_ && q25_[k[63741]]);return;
    }F$L6[k[87794]] = String(q25_[k[70618]]), F$L6[k[87795]] = String(q25_[k[60820]]), setTimeout(function () {
      F$608L(F$L6[k[87883]][k[66554]] + 0x1, F$L6[k[87883]][k[70632]]);
    }, 0x5dc);
  }, F$86L, F$60, function (jc6so) {
    return jc6so[k[63741]] == k[69176] || jc6so[k[63741]] == k[84243];
  });
}, window['F$680L'] = function () {
  ServerLoading[k[60144]][k[87806]](F$L6[k[60609]]), window['F$86'] = !![], window['F$6L08']();
}, window['F$68L0'] = function () {
  if (window['F$68'] && window['F$L86'] && window[k[87727]] && window[k[87728]] && window['F$L68'] && window['F$L8']) {
    if (!window[k[87025]][k[60144]]) {
      console[k[60466]](k[87898] + window[k[87025]][k[60144]]);var ugb1 = wx[k[87899]](),
          ar7$ = ugb1[k[60748]] ? ugb1[k[60748]] : 0x0,
          ezr8$7 = { 'cdn': window['F$L6'][k[64138]], 'spareCdn': window['F$L6'][k[83640]], 'newRegister': window['F$L6'][k[60609]], 'wxPC': window['F$L6'][k[83643]], 'wxIOS': window['F$L6'][k[61003]], 'wxAndroid': window['F$L6'][k[70467]], 'wxParam': { 'limitLoad': window['F$L6']['F$I086L'], 'benchmarkLevel': window['F$L6']['F$I0L86'], 'wxFrom': window[k[60538]][k[87296]] == k[87900] ? 0x1 : 0x0, 'wxSDKVersion': window[k[87620]] }, 'configType': window['F$L6'][k[70946]], 'exposeType': window['F$L6'][k[60689]], 'scene': ar7$ };new window[k[87025]](ezr8$7, window['F$L6'][k[60100]], window['F$I08L6']);
    }
  }
}, window['F$6L08'] = function () {
  if (window['F$68'] && window['F$L86'] && window[k[87727]] && window[k[87728]] && window['F$L68'] && window['F$L8'] && window['F$86'] && window['F$8L']) {
    F$0L68();if (!F$68L) {
      F$68L = !![];if (!window[k[87025]][k[60144]]) window['F$68L0']();var uv1gb9 = 0x0,
          odc6 = wx[k[87901]]();odc6 && (window['F$L6'][k[87674]] && (uv1gb9 = odc6[k[60313]]), console[k[60077]](k[87902] + odc6[k[60313]] + k[87903] + odc6[k[61133]] + k[87904] + odc6[k[61135]] + k[87905] + odc6[k[61134]] + k[87906] + odc6[k[60172]] + k[87907] + odc6[k[60173]]));var zx8ew = {};for (const y7$3r8 in F$L6[k[83941]]) {
        zx8ew[y7$3r8] = F$L6[k[83941]][y7$3r8];
      }var rxz = { 'channel': window['F$L6'][k[83945]], 'account': window['F$L6'][k[83946]], 'userId': window['F$L6'][k[82393]], 'cdn': window['F$L6'][k[64138]], 'data': window['F$L6'][k[60011]], 'package': window['F$L6'][k[83641]], 'newRegister': window['F$L6'][k[60609]], 'pkgName': window['F$L6'][k[83947]], 'partnerId': window['F$L6'][k[82394]], 'platform_uid': window['F$L6'][k[83948]], 'deviceId': window['F$L6'][k[83949]], 'selectedServer': zx8ew, 'configType': window['F$L6'][k[70946]], 'exposeType': window['F$L6'][k[60689]], 'debugUsers': window['F$L6'][k[71317]], 'wxMenuTop': uv1gb9, 'wxShield': window['F$L6'][k[60713]] };if (window[k[87816]]) for (var e8rxnz in window[k[87816]]) {
        rxz[e8rxnz] = window[k[87816]][e8rxnz];
      }window[k[87025]][k[60144]]['F$6LI'](rxz), setTimeout(() => {
        !F$L6[k[60713]] && new minitool();
      }, 0x2710);
    }
  } else console[k[60077]](k[87908] + window['F$68'] + k[87909] + window['F$L86'] + k[87910] + window[k[87727]] + k[87911] + window[k[87728]] + k[87912] + window['F$L68'] + k[87913] + window['F$L8'] + k[87914] + window['F$86'] + k[87915] + window['F$8L']);
};