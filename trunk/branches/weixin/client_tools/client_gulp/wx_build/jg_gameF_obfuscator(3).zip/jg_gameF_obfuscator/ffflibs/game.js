var k = wx.$f;
require(k[88107]);