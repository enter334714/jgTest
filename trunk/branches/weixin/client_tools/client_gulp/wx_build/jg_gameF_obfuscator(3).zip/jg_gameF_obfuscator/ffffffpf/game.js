var k = wx.$f;
require('ffffBuff.js'), window[k[87401]][k[87391]][k[87283]] = null, window['client_pb'] = require('fffcleintpb.js'), window[k[84083]] = window[k[87401]][k[83975]][k[83976]](client_pb);