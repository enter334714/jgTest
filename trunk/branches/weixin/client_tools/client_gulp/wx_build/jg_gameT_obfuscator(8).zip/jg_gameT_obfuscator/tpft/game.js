var M = wx.$T;
require('tBFtt.js'), window[M[0]][M[1]][M[2]] = null, window['client_pb'] = require('tCLIENTtt.js'), window[M[3]] = window[M[0]][M[4]][M[5]](client_pb);