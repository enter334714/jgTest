var M = wx.$T;
console[M[915]](M[916]), window[M[917]], wx[M[918]](function (sjkbar) {
  if (sjkbar) {
    if (sjkbar[M[56]]) {
      var dc9$v = window[M[919]][M[920]][M[243]](new RegExp(/\./, 'g'), '_'),
          subkj = sjkbar[M[56]],
          opefz7 = subkj[M[67]](/(ttttttt\/tGAMEtt.js:)[0-9]{1,60}(:)/g);if (opefz7) for (var yx_qm0 = 0x0; yx_qm0 < opefz7[M[31]]; yx_qm0++) {
        if (opefz7[yx_qm0] && opefz7[yx_qm0][M[31]] > 0x0) {
          var _0hxym = parseInt(opefz7[yx_qm0][M[243]](M[921], '')[M[243]](':', ''));subkj = subkj[M[243]](opefz7[yx_qm0], opefz7[yx_qm0][M[243]](':' + _0hxym + ':', ':' + (_0hxym - 0x2) + ':'));
        }
      }subkj = subkj[M[243]](new RegExp(M[922], 'g'), M[923] + dc9$v + M[924]), subkj = subkj[M[243]](new RegExp(M[925], 'g'), M[923] + dc9$v + M[924]), sjkbar[M[56]] = subkj;
    }var d7f$z = { 'id': window['t_ZK'][M[926]], 'role': window['t_ZK'][M[927]], 'level': window['t_ZK'][M[928]], 'user': window['t_ZK'][M[929]], 'version': window['t_ZK'][M[930]], 'cdn': window['t_ZK'][M[931]], 'pkgName': window['t_ZK'][M[932]], 'gamever': window[M[919]][M[920]], 'serverid': window['t_ZK'][M[933]] ? window['t_ZK'][M[933]][M[934]] : 0x0, 'systemInfo': window[M[935]], 'error': M[936], 'stack': sjkbar ? sjkbar[M[56]] : '' },
        krajsb = JSON[M[937]](d7f$z);console[M[333]](M[938] + krajsb), (!window[M[917]] || window[M[917]] != d7f$z[M[333]]) && (window[M[917]] = d7f$z[M[333]], window['t_MZ'](d7f$z));
  }
});import 'ttfttt.js';import 'tt112tt.js';window[M[939]] = require(M[940]);import 'tINDtt.js';import 'ttLIB23tt.js';import 'tWXMtadtt.js';import 'ttINItt.js';console[M[915]](M[941]), console[M[915]](M[942]), t_MZ6K({ 'title': M[943] });var t_mh5 = { 't_FMKZ6': !![] };new window[M[944]](t_mh5), window[M[944]][M[945]]['t_F6ZKM']();if (window['t_FMZK6']) clearInterval(window['t_FMZK6']);window['t_FMZK6'] = null, window['t_F6KMZ'] = function (w_6hm, brga) {
  if (!w_6hm || !brga) return 0x0;w_6hm = w_6hm[M[201]]('.'), brga = brga[M[201]]('.');const oe0yq = Math[M[301]](w_6hm[M[31]], brga[M[31]]);while (w_6hm[M[31]] < oe0yq) {
    w_6hm[M[66]]('0');
  }while (brga[M[31]] < oe0yq) {
    brga[M[66]]('0');
  }for (var g3brj = 0x0; g3brj < oe0yq; g3brj++) {
    const vd$i9c = parseInt(w_6hm[g3brj]),
          abjsku = parseInt(brga[g3brj]);if (vd$i9c > abjsku) return 0x1;else {
      if (vd$i9c < abjsku) return -0x1;
    }
  }return 0x0;
}, window[M[946]] = wx[M[947]]()[M[946]], console[M[225]](M[948] + window[M[946]]);var tdzpv$ = wx[M[949]]();tdzpv$[M[950]](function (icdv9$) {
  console[M[225]](M[951] + icdv9$[M[952]]);
}), tdzpv$[M[953]](function () {
  wx[M[954]]({ 'title': M[955], 'content': M[956], 'showCancel': ![], 'success': function (_ywm5h) {
      tdzpv$[M[957]]();
    } });
}), tdzpv$[M[958]](function () {
  console[M[225]](M[959]);
}), window['t_F6KZM'] = function () {
  console[M[225]](M[960]);var n1g38 = wx[M[961]]({ 'name': M[962], 'success': function (barksj) {
      console[M[225]](M[963]), console[M[225]](barksj), barksj && barksj[M[964]] == M[965] ? (window['t_K6'] = !![], window['t_K6ZM'](), window['t_KZM6']()) : setTimeout(function () {
        window['t_F6KZM']();
      }, 0x1f4);
    }, 'fail': function (h156w) {
      console[M[225]](M[966]), console[M[225]](h156w), setTimeout(function () {
        window['t_F6KZM']();
      }, 0x1f4);
    } });n1g38 && n1g38[M[967]](rjkabs => {});
}, window['t_FZMK6'] = function () {
  console[M[225]](M[968]);var eqzfo = wx[M[961]]({ 'name': M[969], 'success': function ($9pdv) {
      console[M[225]](M[970]), console[M[225]]($9pdv), $9pdv && $9pdv[M[964]] == M[965] ? (window['t_Z6K'] = !![], window['t_K6ZM'](), window['t_KZM6']()) : setTimeout(function () {
        window['t_FZMK6']();
      }, 0x1f4);
    }, 'fail': function (o7x0q) {
      console[M[225]](M[971]), console[M[225]](o7x0q), setTimeout(function () {
        window['t_FZMK6']();
      }, 0x1f4);
    } });eqzfo && eqzfo[M[967]](ci2v9t => {});
}, window[M[972]] = function () {
  window['t_F6KMZ'](window[M[946]], M[973]) >= 0x0 ? (console[M[225]](M[974] + window[M[946]] + M[975]), window['t_ZM'](), window['t_F6KZM'](), window['t_FZMK6']()) : (window['t_ZKM'](M[976], window[M[946]]), wx[M[954]]({ 'title': M[977], 'content': M[978] }));
}, window[M[935]] = '', wx[M[979]]({ 'success'(bagnrj) {
    window[M[935]] = M[980] + bagnrj[M[981]] + M[982] + bagnrj[M[983]] + M[984] + bagnrj[M[985]] + M[986] + bagnrj[M[987]] + M[988] + bagnrj[M[989]] + M[990] + bagnrj[M[946]] + M[991] + bagnrj[M[992]], console[M[225]](window[M[935]]), console[M[225]](M[993] + bagnrj[M[994]] + M[995] + bagnrj[M[996]] + M[997] + bagnrj[M[998]] + M[999] + bagnrj[M[1000]] + M[1001] + bagnrj[M[1002]] + M[1003] + bagnrj[M[1004]] + M[1005] + (bagnrj[M[1006]] ? bagnrj[M[1006]][M[1007]] + ',' + bagnrj[M[1006]][M[1008]] + ',' + bagnrj[M[1006]][M[1009]] + ',' + bagnrj[M[1006]][M[1010]] : ''));var i2lc4t = bagnrj[M[987]] ? bagnrj[M[987]][M[103]]() : '',
        mh_wy5 = bagnrj[M[983]] ? bagnrj[M[983]][M[103]]()[M[243]]('\x20', '') : '';window['t_ZK'][M[1011]] = i2lc4t[M[146]](M[1012]) != -0x1, window['t_ZK'][M[1013]] = i2lc4t[M[146]](M[1014]) != -0x1, window['t_ZK'][M[1015]] = i2lc4t[M[146]](M[1012]) != -0x1 || i2lc4t[M[146]](M[1014]) != -0x1, window['t_ZK'][M[1016]] = i2lc4t[M[146]](M[1017]) != -0x1 || i2lc4t[M[146]](M[1018]) != -0x1, window['t_ZK'][M[1019]] = bagnrj[M[989]] ? bagnrj[M[989]][M[103]]() : '', window['t_ZK']['t_FM6KZ'] = ![], window['t_ZK']['t_FMZ6K'] = 0x2;if (i2lc4t[M[146]](M[1014]) != -0x1) {
      if (bagnrj[M[992]] >= 0x18) window['t_ZK']['t_FMZ6K'] = 0x3;else window['t_ZK']['t_FMZ6K'] = 0x2;
    } else {
      if (i2lc4t[M[146]](M[1012]) != -0x1) {
        if (bagnrj[M[992]] && bagnrj[M[992]] >= 0x14) window['t_ZK']['t_FMZ6K'] = 0x3;else {
          if (mh_wy5[M[146]](M[1020]) != -0x1 || mh_wy5[M[146]](M[1021]) != -0x1 || mh_wy5[M[146]](M[1022]) != -0x1 || mh_wy5[M[146]](M[1023]) != -0x1 || mh_wy5[M[146]](M[1024]) != -0x1) window['t_ZK']['t_FMZ6K'] = 0x2;else window['t_ZK']['t_FMZ6K'] = 0x3;
        }
      } else window['t_ZK']['t_FMZ6K'] = 0x2;
    }console[M[225]](M[1025] + window['t_ZK']['t_FM6KZ'] + M[1026] + window['t_ZK']['t_FMZ6K']);
  } }), wx[M[1027]]({ 'success': function (o0qe7z) {
    console[M[225]](M[1028] + o0qe7z[M[1029]] + M[1030] + o0qe7z[M[1031]]);
  } }), wx[M[1032]]({ 'success': function (t9ivc2) {
    console[M[225]](M[1033] + t9ivc2[M[1034]]);
  } }), wx[M[1035]]({ 'keepScreenOn': !![] }), wx[M[1036]](function (grn3bj) {
  console[M[225]](M[1033] + grn3bj[M[1034]] + M[1037] + grn3bj[M[1038]]);
}), wx[M[1039]](function (pdz$v) {
  window['t_6M'] = pdz$v, window['t_KM6'] && window['t_6M'] && (console[M[915]](M[1040] + window['t_6M'][M[1041]]), window['t_KM6'](window['t_6M']), window['t_6M'] = null);
}), window[M[1042]] = 0x0, window['t_FZ6KM'] = 0x0, window[M[1043]] = null, wx[M[1044]](function () {
  window['t_FZ6KM']++;var p7ezof = Date[M[1045]]();(window[M[1042]] == 0x0 || p7ezof - window[M[1042]] > 0x1d4c0) && (console[M[383]](M[1046]), wx[M[1047]]());if (window['t_FZ6KM'] >= 0x2) {
    window['t_FZ6KM'] = 0x0, console[M[333]](M[1048]), wx[M[1049]]('0', 0x1);if (window['t_ZK'] && window['t_ZK'][M[1011]]) window['t_ZKM'](M[1050], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});