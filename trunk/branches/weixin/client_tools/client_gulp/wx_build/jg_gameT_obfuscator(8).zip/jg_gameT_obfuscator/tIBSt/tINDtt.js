var M = wx.$T;
import tp$f7dz from '../ttkttt/t6ktgt.js';window[M[1051]] = { 'wxVersion': window[M[919]][M[920]] }, window[M[1052]] = ![], window['t_KZ'] = 0x1, window[M[1053]] = 0x1, window['t_6ZK'] = !![], window[M[1054]] = !![], window['t_FM6ZK'] = '', window['t_ZK'] = { 'base_cdn': M[1055], 'cdn': M[1055] }, t_ZK[M[1056]] = {}, t_ZK[M[304]] = '0', t_ZK[M[985]] = window[M[1051]][M[1057]], t_ZK[M[1018]] = '', t_ZK['os'] = '1', t_ZK[M[1058]] = M[1059], t_ZK[M[1060]] = M[1061], t_ZK[M[1062]] = M[1063], t_ZK[M[1064]] = M[1065], t_ZK[M[1066]] = M[1067], t_ZK[M[1068]] = '1', t_ZK[M[932]] = '', t_ZK[M[1069]] = '', t_ZK[M[1070]] = 0x0, t_ZK[M[1071]] = {}, t_ZK[M[1072]] = parseInt(t_ZK[M[1068]]), t_ZK[M[1073]] = t_ZK[M[1068]], t_ZK[M[933]] = {}, t_ZK['t_MZ'] = M[1074], t_ZK[M[1075]] = ![], t_ZK[M[1076]] = M[1077], t_ZK[M[1078]] = Date[M[1045]](), t_ZK[M[1079]] = M[1080], t_ZK[M[1081]] = '_a', t_ZK[M[1082]] = 0x1, t_ZK[M[930]] = 0x7c1, t_ZK[M[1057]] = window[M[1051]][M[1057]], t_ZK[M[1083]] = ![], t_ZK[M[1011]] = ![], t_ZK[M[1013]] = ![], t_ZK[M[1016]] = ![], window['t_6KZ'] = 0x5, window['t_6K'] = ![], window['t_K6'] = ![], window['t_Z6K'] = ![], window[M[1084]] = ![], window[M[1085]] = ![], window['t_ZK6'] = ![], window['t_6Z'] = ![], window['t_Z6'] = ![], window['t_K6Z'] = ![], window[M[1086]] = function (bgjark) {
  console[M[225]](M[1086], bgjark), wx[M[1087]]({}), wx[M[954]]({ 'title': M[977], 'content': bgjark, 'success'(c94t2i) {
      if (c94t2i[M[1088]]) console[M[225]](M[1089]);else c94t2i[M[1090]] && console[M[225]](M[1091]);
    } });
}, window['t_M6ZK'] = function (qeof7) {
  console[M[225]](M[1092], qeof7), t_MZK6(), wx[M[954]]({ 'title': M[977], 'content': qeof7, 'confirmText': M[1093], 'cancelText': M[1094], 'success'(x_mwyh) {
      if (x_mwyh[M[1088]]) window['t_ZM']();else x_mwyh[M[1090]] && (console[M[225]](M[1095]), wx[M[1096]]({}));
    } });
}, window['t_ZF'] = function (gj3bn) {
  console[M[225]](M[1097], gj3bn), wx[M[954]]({ 'title': M[977], 'content': gj3bn, 'confirmText': M[1098], 'showCancel': ![], 'complete'(y0oexq) {
      console[M[225]](M[1095]), wx[M[1096]]({});
    } });
}, window['t_M6KZ'] = ![], window['t_MZ6K'] = function (rkjgb) {
  window['t_M6KZ'] = !![], wx[M[1099]](rkjgb);
}, window['t_MZK6'] = function () {
  window['t_M6KZ'] && (window['t_M6KZ'] = ![], wx[M[1087]]({}));
}, window['t_MK6Z'] = function (pfodz7) {
  window[M[944]][M[945]]['t_MK6Z'](pfodz7);
}, window[M[1100]] = function ($vdz, rng3bj) {
  tp$f7dz[M[1100]]($vdz, function (mhy0) {
    mhy0 && mhy0[M[335]] ? mhy0[M[335]][M[1101]] == 0x1 ? rng3bj(!![]) : (rng3bj(![]), console[M[915]](M[1102] + mhy0[M[335]][M[1103]])) : console[M[225]](M[1100], mhy0);
  });
}, window['t_MKZ6'] = function (garkj) {
  console[M[225]](M[1104], garkj);
}, window['t_MZK'] = function (o0xqy) {}, window['t_MKZ'] = function (x0eqoy, oe7fzq, z7fp) {}, window['t_MK'] = function (vp9di$) {
  console[M[225]](M[1105], vp9di$), window[M[944]][M[945]][M[1106]](), window[M[944]][M[945]][M[1107]](), window[M[944]][M[945]][M[1108]]();
}, window['t_KM'] = function (jnr3gb) {
  window['t_M6ZK'](M[1109]);var fdpv$9 = { 'id': window['t_ZK'][M[926]], 'role': window['t_ZK'][M[927]], 'level': window['t_ZK'][M[928]], 'account': window['t_ZK'][M[929]], 'version': window['t_ZK'][M[930]], 'cdn': window['t_ZK'][M[931]], 'pkgName': window['t_ZK'][M[932]], 'gamever': window[M[919]][M[920]], 'serverid': window['t_ZK'][M[933]] ? window['t_ZK'][M[933]][M[934]] : 0x0, 'systemInfo': window[M[935]], 'error': M[1110], 'stack': jnr3gb ? jnr3gb : M[1109] },
      p9$dvi = JSON[M[937]](fdpv$9);console[M[333]](M[1111] + p9$dvi), window['t_MZ'](p9$dvi);
}, window['t_ZMK'] = function (j8nrg3) {
  var xyeo0q = JSON[M[223]](j8nrg3);xyeo0q[M[1112]] = window[M[919]][M[920]], xyeo0q[M[1113]] = window['t_ZK'][M[933]] ? window['t_ZK'][M[933]][M[934]] : 0x0, xyeo0q[M[935]] = window[M[935]];var o7qe0z = JSON[M[937]](xyeo0q);console[M[333]](M[1114] + o7qe0z), window['t_MZ'](o7qe0z);
}, window['t_ZKM'] = function (askrbj, _qy0m) {
  var f7dp$z = { 'id': window['t_ZK'][M[926]], 'role': window['t_ZK'][M[927]], 'level': window['t_ZK'][M[928]], 'account': window['t_ZK'][M[929]], 'version': window['t_ZK'][M[930]], 'cdn': window['t_ZK'][M[931]], 'pkgName': window['t_ZK'][M[932]], 'gamever': window[M[919]][M[920]], 'serverid': window['t_ZK'][M[933]] ? window['t_ZK'][M[933]][M[934]] : 0x0, 'systemInfo': window[M[935]], 'error': askrbj, 'stack': _qy0m },
      _hm5w6 = JSON[M[937]](f7dp$z);console[M[383]](M[1115] + _hm5w6), window['t_MZ'](_hm5w6);
}, window['t_MZ'] = function (jg3nbr) {
  if (window['t_ZK'][M[1019]] == M[1116]) return;var h651w8 = t_ZK['t_MZ'] + M[1117] + t_ZK[M[929]];wx[M[1118]]({ 'url': h651w8, 'method': M[1119], 'data': jg3nbr, 'header': { 'content-type': M[1120], 'cache-control': M[1121] }, 'success': function (w861) {
      DEBUG && console[M[225]](M[1122], h651w8, jg3nbr, w861);
    }, 'fail': function (fvd9p) {
      DEBUG && console[M[225]](M[1122], h651w8, jg3nbr, fvd9p);
    }, 'complete': function () {} });
}, window[M[1123]] = function () {
  function _xey() {
    return ((0x1 + Math[M[1124]]()) * 0x10000 | 0x0)[M[60]](0x10)[M[234]](0x1);
  }return _xey() + _xey() + '-' + _xey() + '-' + _xey() + '-' + _xey() + '+' + _xey() + _xey() + _xey();
}, window['t_ZM'] = function () {
  console[M[225]](M[1125]);var m1h5w = tp$f7dz[M[1126]]();t_ZK[M[1073]] = m1h5w[M[1127]], t_ZK[M[1072]] = m1h5w[M[1127]], t_ZK[M[1068]] = m1h5w[M[1127]], t_ZK[M[932]] = m1h5w[M[1128]];var hymxw_ = { 'game_ver': t_ZK[M[985]] };t_ZK[M[1069]] = this[M[1123]](), t_MZ6K({ 'title': M[1129] }), tp$f7dz[M[1130]](hymxw_, this['t_KMZ'][M[17]](this));
}, window['t_KMZ'] = function (t2vi9) {
  var o0exqy = t2vi9[M[1131]];console[M[225]](M[1132] + o0exqy + M[1133] + (o0exqy == 0x1) + M[1134] + t2vi9[M[920]] + M[1135] + window[M[1051]][M[1057]]);if (!t2vi9[M[920]] || window['t_F6KMZ'](window[M[1051]][M[1057]], t2vi9[M[920]]) < 0x0) console[M[225]](M[1136]), t_ZK[M[1060]] = M[1137], t_ZK[M[1062]] = M[1138], t_ZK[M[1064]] = M[1139], t_ZK[M[931]] = M[1140], t_ZK[M[1141]] = M[1142], t_ZK[M[1143]] = M[1144], t_ZK[M[1083]] = ![];else window['t_F6KMZ'](window[M[1051]][M[1057]], t2vi9[M[920]]) == 0x0 ? (console[M[225]](M[1145]), t_ZK[M[1060]] = M[1061], t_ZK[M[1062]] = M[1063], t_ZK[M[1064]] = M[1065], t_ZK[M[931]] = M[1055], t_ZK[M[1141]] = M[1142], t_ZK[M[1143]] = M[1144], t_ZK[M[1083]] = !![]) : (console[M[225]](M[1146]), t_ZK[M[1060]] = M[1061], t_ZK[M[1062]] = M[1063], t_ZK[M[1064]] = M[1065], t_ZK[M[931]] = M[1055], t_ZK[M[1141]] = M[1142], t_ZK[M[1143]] = M[1144], t_ZK[M[1083]] = ![]);t_ZK[M[1070]] = config[M[51]] ? config[M[51]] : 0x0, this['t_6ZMK'](), this['t_6ZKM'](), window[M[1147]] = 0x5, t_MZ6K({ 'title': M[1148] }), tp$f7dz[M[1149]](this['t_KZM'][M[17]](this));
}, window[M[1147]] = 0x5, window['t_KZM'] = function (hym_5w, o7dfz) {
  if (hym_5w == 0x0 && o7dfz && o7dfz[M[285]]) {
    t_ZK[M[1150]] = o7dfz[M[285]];var p7zofd = this;t_MZ6K({ 'title': M[1151] }), sendApi(t_ZK[M[1060]], M[1152], { 'platform': t_ZK[M[1058]], 'partner_id': t_ZK[M[1068]], 'token': o7dfz[M[285]], 'game_pkg': t_ZK[M[932]], 'deviceId': t_ZK[M[1069]], 'scene': M[1153] + t_ZK[M[1070]] }, this['t_6MZK'][M[17]](this), t_6KZ, t_KM);
  } else o7dfz && o7dfz[M[964]] && window[M[1147]] > 0x0 && (o7dfz[M[964]][M[146]](M[1154]) != -0x1 || o7dfz[M[964]][M[146]](M[1155]) != -0x1 || o7dfz[M[964]][M[146]](M[1156]) != -0x1 || o7dfz[M[964]][M[146]](M[1157]) != -0x1 || o7dfz[M[964]][M[146]](M[1158]) != -0x1 || o7dfz[M[964]][M[146]](M[1159]) != -0x1) ? (window[M[1147]]--, tp$f7dz[M[1149]](this['t_KZM'][M[17]](this))) : (window['t_ZKM'](M[1160], JSON[M[937]]({ 'status': hym_5w, 'data': o7dfz })), window['t_M6ZK'](M[1161] + (o7dfz && o7dfz[M[964]] ? '，' + o7dfz[M[964]] : '')));
}, window['t_6MZK'] = function (vic9$t) {
  if (!vic9$t) {
    window['t_ZKM'](M[1162], M[1163]), window['t_M6ZK'](M[1164]);return;
  }if (vic9$t[M[1101]] != M[1165]) {
    window['t_ZKM'](M[1162], JSON[M[937]](vic9$t)), window['t_M6ZK'](M[1166] + vic9$t[M[1101]]);return;
  }t_ZK[M[1167]] = String(vic9$t[M[929]]), t_ZK[M[929]] = String(vic9$t[M[929]]), t_ZK[M[989]] = String(vic9$t[M[989]]), t_ZK[M[1073]] = String(vic9$t[M[989]]), t_ZK[M[1168]] = String(vic9$t[M[1168]]), t_ZK[M[1169]] = String(vic9$t[M[1170]]), t_ZK[M[1171]] = String(vic9$t[M[1172]]), t_ZK[M[1170]] = '';var w6 = this;t_MZ6K({ 'title': M[1173] }), sendApi(t_ZK[M[1060]], M[1174], { 'partner_id': t_ZK[M[1068]], 'uid': t_ZK[M[929]], 'version': t_ZK[M[985]], 'game_pkg': t_ZK[M[932]], 'device': t_ZK[M[1069]] }, w6['t_6MKZ'][M[17]](w6), t_6KZ, t_KM);
}, window['t_6MKZ'] = function (gr3nb) {
  if (!gr3nb) {
    window['t_M6ZK'](M[1175]);return;
  }if (gr3nb[M[1101]] != M[1165]) {
    window['t_M6ZK'](M[1176] + gr3nb[M[1101]]);return;
  }if (!gr3nb[M[335]] || gr3nb[M[335]][M[31]] == 0x0) {
    window['t_M6ZK'](M[1177]);return;
  }t_ZK[M[1178]] = gr3nb[M[1179]], t_ZK[M[933]] = { 'server_id': String(gr3nb[M[335]][0x0][M[934]]), 'server_name': String(gr3nb[M[335]][0x0][M[1180]]), 'entry_ip': gr3nb[M[335]][0x0][M[1181]], 'entry_port': parseInt(gr3nb[M[335]][0x0][M[1182]]), 'status': t_Z6M(gr3nb[M[335]][0x0]), 'start_time': gr3nb[M[335]][0x0]['start_time'], 'cdn': t_ZK[M[931]] }, this['t_KZ6M']();
}, window['t_KZ6M'] = function () {
  if (t_ZK[M[1178]] == 0x1) {
    var o7fzq = t_ZK[M[933]][M[1183]];if (o7fzq === -0x1 || o7fzq === 0x0) {
      window['t_M6ZK'](o7fzq === -0x1 ? M[1184] : M[1185]);return;
    }t_KM6Z(0x0, t_ZK[M[933]][M[934]]), window[M[944]][M[945]][M[1186]](t_ZK[M[1178]]);
  } else window[M[944]][M[945]][M[1187]](), t_MZK6();window['t_Z6'] = !![], window['t_K6ZM'](), window['t_KZM6']();
}, window['t_6ZMK'] = function () {
  sendApi(t_ZK[M[1060]], M[1188], { 'game_pkg': t_ZK[M[932]], 'version_name': t_ZK[M[1143]] }, this[M[1189]][M[17]](this), t_6KZ, t_KM);
}, window[M[1189]] = function (c9idv) {
  if (!c9idv) {
    window['t_M6ZK'](M[1190]);return;
  }if (c9idv[M[1101]] != M[1165]) {
    window['t_M6ZK'](M[1191] + c9idv[M[1101]]);return;
  }if (!c9idv[M[335]] || !c9idv[M[335]][M[985]]) {
    window['t_M6ZK'](M[1192] + (c9idv[M[335]] && c9idv[M[335]][M[985]]));return;
  }c9idv[M[335]][M[1193]] && c9idv[M[335]][M[1193]][M[31]] > 0xa && (t_ZK[M[1194]] = c9idv[M[335]][M[1193]], t_ZK[M[931]] = c9idv[M[335]][M[1193]]), c9idv[M[335]][M[985]] && (t_ZK[M[930]] = c9idv[M[335]][M[985]]), console[M[915]](M[1195] + t_ZK[M[930]] + M[1196] + t_ZK[M[1143]]), window['t_ZK6'] = !![], window['t_K6ZM'](), window['t_KZM6']();
}, window[M[1197]], window['t_6ZKM'] = function () {
  sendApi(t_ZK[M[1060]], 'Common.get_option_pkg', { 'game_pkg': t_ZK[M[932]] }, this['t_6KMZ'][M[17]](this), t_6KZ, t_KM);
}, window['t_6KMZ'] = function (m5h1w6) {
  if (m5h1w6[M[1101]] === M[1165] && m5h1w6[M[335]]) {
    window[M[1197]] = m5h1w6[M[335]];for (var $9ci in m5h1w6[M[335]]) {
      t_ZK[$9ci] = m5h1w6[M[335]][$9ci];
    }
  } else console[M[915]](M[1198] + m5h1w6[M[1101]]);window['t_6Z'] = !![], window['t_KZM6']();
}, window[M[1199]] = function (w38516, qxo70, n183rg, _yxe0, m5hw6, rsakb, hw681, ska, g136n) {
  m5hw6 = String(m5hw6);var pd7$z = hw681,
      jsbua = ska;t_ZK[M[1056]][m5hw6] = { 'productid': m5hw6, 'productname': pd7$z, 'productdesc': jsbua, 'roleid': w38516, 'rolename': qxo70, 'rolelevel': n183rg, 'price': rsakb, 'callback': g136n }, sendApi(t_ZK[M[1064]], M[1200], { 'game_pkg': t_ZK[M[932]], 'server_id': t_ZK[M[933]][M[934]], 'server_name': t_ZK[M[933]][M[1180]], 'level': n183rg, 'uid': t_ZK[M[929]], 'role_id': w38516, 'role_name': qxo70, 'product_id': m5hw6, 'product_name': pd7$z, 'product_desc': jsbua, 'money': rsakb, 'partner_id': t_ZK[M[1068]] }, toPayCallBack, t_6KZ, t_KM);
}, window[M[1201]] = function (i9tcv$) {
  if (i9tcv$) {
    if (i9tcv$[M[1202]] === 0xc8 || i9tcv$[M[1101]] == M[1165]) {
      var _6mh5 = t_ZK[M[1056]][String(i9tcv$['product_id'])];if (_6mh5[M[1203]]) _6mh5[M[1203]](i9tcv$['product_id'], i9tcv$[M[1204]], -0x1);tp$f7dz[M[1205]]({ 'cpbill': i9tcv$[M[1204]], 'productid': i9tcv$['product_id'], 'productname': _6mh5[M[1206]], 'productdesc': _6mh5[M[1207]], 'serverid': t_ZK[M[933]][M[934]], 'servername': t_ZK[M[933]][M[1180]], 'roleid': _6mh5[M[1208]], 'rolename': _6mh5[M[1209]], 'rolelevel': _6mh5[M[1210]], 'price': _6mh5[M[1211]], 'extension': JSON[M[937]]({ 'cp_order_id': i9tcv$[M[1204]] }) }, function (gajkrb, $fz) {
        _6mh5[M[1203]] && gajkrb == 0x0 && _6mh5[M[1203]](i9tcv$['product_id'], i9tcv$[M[1204]], gajkrb);console[M[915]](JSON[M[937]]({ 'type': M[1212], 'status': gajkrb, 'data': i9tcv$, 'role_name': _6mh5[M[1209]] }));if (gajkrb === 0x0) {} else {
          if (gajkrb === 0x1) {} else {
            if (gajkrb === 0x2) {}
          }
        }
      });
    } else alert(i9tcv$[M[915]]);
  }
}, window['t_6KZM'] = function () {}, window['t_M6K'] = function (akbgrj, kausb, y0_mxq, whxm_, ajkgrb) {
  tp$f7dz[M[1213]](t_ZK[M[933]][M[934]], t_ZK[M[933]][M[1180]] || t_ZK[M[933]][M[934]], akbgrj, kausb, y0_mxq), sendApi(t_ZK[M[1060]], M[1214], { 'game_pkg': t_ZK[M[932]], 'server_id': t_ZK[M[933]][M[934]], 'role_id': akbgrj, 'uid': t_ZK[M[929]], 'role_name': kausb, 'role_type': whxm_, 'level': y0_mxq });
}, window['t_MK6'] = function (g613n8, kjarb, $icv, r3jng, tci4, ofze, brkjag, z$d7p, dv9f, mywh_) {
  t_ZK[M[926]] = g613n8, t_ZK[M[927]] = kjarb, t_ZK[M[928]] = $icv, tp$f7dz[M[1215]](t_ZK[M[933]][M[934]], t_ZK[M[933]][M[1180]] || t_ZK[M[933]][M[934]], g613n8, kjarb, $icv), sendApi(t_ZK[M[1060]], M[1216], { 'game_pkg': t_ZK[M[932]], 'server_id': t_ZK[M[933]][M[934]], 'role_id': g613n8, 'uid': t_ZK[M[929]], 'role_name': kjarb, 'role_type': r3jng, 'level': $icv, 'evolution': tci4 });
}, window['t_6MK'] = function (akjub, xq07o, dfv9, myx0_, barsj, w38156, n38g1, qze70o, fzd7$, n6351) {
  t_ZK[M[926]] = akjub, t_ZK[M[927]] = xq07o, t_ZK[M[928]] = dfv9, tp$f7dz[M[1217]](t_ZK[M[933]][M[934]], t_ZK[M[933]][M[1180]] || t_ZK[M[933]][M[934]], akjub, xq07o, dfv9), sendApi(t_ZK[M[1060]], M[1216], { 'game_pkg': t_ZK[M[932]], 'server_id': t_ZK[M[933]][M[934]], 'role_id': akjub, 'uid': t_ZK[M[929]], 'role_name': xq07o, 'role_type': myx0_, 'level': dfv9, 'evolution': barsj });
}, window['t_6KM'] = function (mxhyw) {}, window['t_M6'] = function (zdof) {
  tp$f7dz[M[1218]](M[1218], function (sjabu) {
    zdof && zdof(sjabu);
  });
}, window[M[1219]] = function () {
  tp$f7dz[M[1219]]();
}, window[M[1220]] = function () {
  tp$f7dz[M[1221]]();
}, window[M[1039]] = function (dc9vi$) {
  window['t_KM6'] = dc9vi$, window['t_KM6'] && window['t_6M'] && (console[M[915]](M[1040] + window['t_6M'][M[1041]]), window['t_KM6'](window['t_6M']), window['t_6M'] = null);
}, window['t_K6M'] = function (hw_6m, zoef, xyq0m, eqox0) {
  window[M[1222]](M[1223], { 'game_pkg': window['t_ZK'][M[932]], 'role_id': zoef, 'server_id': xyq0m }, eqox0);
}, window['t_ZM6K'] = function (itv$9, r3ng18) {
  function ymq_0(_xmwh) {
    var $9dfv = [],
        eqo7z = [],
        cv9ti2 = window[M[919]][M[1224]];for (var qoze7 in cv9ti2) {
      var i924c = Number(qoze7);(!itv$9 || !itv$9[M[31]] || itv$9[M[146]](i924c) != -0x1) && (eqo7z[M[66]](cv9ti2[qoze7]), $9dfv[M[66]]([i924c, 0x3]));
    }window['t_F6KMZ'](window[M[946]], M[1225]) >= 0x0 ? (console[M[225]](M[1226]), tp$f7dz[M[1227]](eqo7z, function (h5_6m) {
      console[M[225]](M[1228]), console[M[225]](h5_6m);if (h5_6m && h5_6m[M[964]] == M[1229]) for (var fdp7o in cv9ti2) {
        if (h5_6m[cv9ti2[fdp7o]] == M[1230]) {
          var pdi9$ = Number(fdp7o);for (var jgbrka = 0x0; jgbrka < $9dfv[M[31]]; jgbrka++) {
            if ($9dfv[jgbrka][0x0] == pdi9$) {
              $9dfv[jgbrka][0x1] = 0x1;break;
            }
          }
        }
      }window['t_F6KMZ'](window[M[946]], M[1231]) >= 0x0 ? wx[M[1232]]({ 'withSubscriptions': !![], 'success': function ($9dpiv) {
          var n3grj8 = $9dpiv[M[1233]][M[1234]];if (n3grj8) {
            console[M[225]](M[1235]), console[M[225]](n3grj8);for (var n5813 in cv9ti2) {
              if (n3grj8[cv9ti2[n5813]] == M[1230]) {
                var x_0yqe = Number(n5813);for (var yxmq0_ = 0x0; yxmq0_ < $9dfv[M[31]]; yxmq0_++) {
                  if ($9dfv[yxmq0_][0x0] == x_0yqe) {
                    $9dfv[yxmq0_][0x1] = 0x2;break;
                  }
                }
              }
            }console[M[225]]($9dfv), r3ng18 && r3ng18($9dfv);
          } else console[M[225]](M[1236]), console[M[225]]($9dpiv), console[M[225]]($9dfv), r3ng18 && r3ng18($9dfv);
        }, 'fail': function () {
          console[M[225]](M[1237]), console[M[225]]($9dfv), r3ng18 && r3ng18($9dfv);
        } }) : (console[M[225]](M[1238] + window[M[946]]), console[M[225]]($9dfv), r3ng18 && r3ng18($9dfv));
    })) : (console[M[225]](M[1239] + window[M[946]]), console[M[225]]($9dfv), r3ng18 && r3ng18($9dfv)), wx[M[1240]](ymq_0);
  }wx[M[1241]](ymq_0);
}, window['t_ZMK6'] = { 'isSuccess': ![], 'level': M[1242], 'isCharging': ![] }, window['t_Z6MK'] = function (mh5wy) {
  wx[M[1027]]({ 'success': function (akbsjr) {
      var tc4l = window['t_ZMK6'];tc4l[M[1243]] = !![], tc4l[M[1029]] = Number(akbsjr[M[1029]])[M[1244]](0x0), tc4l[M[1031]] = akbsjr[M[1031]], mh5wy && mh5wy(tc4l[M[1243]], tc4l[M[1029]], tc4l[M[1031]]);
    }, 'fail': function (anrbgj) {
      console[M[225]](M[1245], anrbgj[M[964]]);var _0xey = window['t_ZMK6'];mh5wy && mh5wy(_0xey[M[1243]], _0xey[M[1029]], _0xey[M[1031]]);
    } });
}, window[M[1222]] = function (my_, opdf7, h_yw5m, w_5ym, cti9, kgrbja, rskabj, oepz) {
  if (w_5ym == undefined) w_5ym = 0x1;wx[M[1118]]({ 'url': my_, 'method': rskabj || M[1246], 'responseType': M[1247], 'data': opdf7, 'header': { 'content-type': oepz || M[1120] }, 'success': function (gnrj83) {
      DEBUG && console[M[225]](M[1248], my_, info, gnrj83);if (gnrj83 && gnrj83[M[1249]] == 0xc8) {
        var qoe07x = gnrj83[M[335]];!kgrbja || kgrbja(qoe07x) ? h_yw5m && h_yw5m(qoe07x) : window[M[1250]](my_, opdf7, h_yw5m, w_5ym, cti9, kgrbja, gnrj83);
      } else window[M[1250]](my_, opdf7, h_yw5m, w_5ym, cti9, kgrbja, gnrj83);
    }, 'fail': function (m61wh) {
      DEBUG && console[M[225]](M[1251], my_, info, m61wh), window[M[1250]](my_, opdf7, h_yw5m, w_5ym, cti9, kgrbja, m61wh);
    }, 'complete': function () {} });
}, window[M[1250]] = function (rnj83, zo7pd, qxm_y0, j8r3g, rgjnba, exy_0, bjgak) {
  j8r3g - 0x1 > 0x0 ? setTimeout(function () {
    window[M[1222]](rnj83, zo7pd, qxm_y0, j8r3g - 0x1, rgjnba, exy_0);
  }, 0x3e8) : rgjnba && rgjnba(JSON[M[937]]({ 'url': rnj83, 'response': bjgak }));
}, window[M[1252]] = function (h58w1, aujksb, _5wh6, ticv$, rn3bj, y_qmx0, akjbr) {
  !_5wh6 && (_5wh6 = {});var fe7zq = Math[M[71]](Date[M[1045]]() / 0x3e8);_5wh6[M[1172]] = fe7zq, _5wh6[M[1253]] = aujksb;var $c9iv = Object[M[30]](_5wh6)[M[382]](),
      pzo = '',
      pfoz7 = '';for (var hm516 = 0x0; hm516 < $c9iv[M[31]]; hm516++) {
    pzo = pzo + (hm516 == 0x0 ? '' : '&') + $c9iv[hm516] + _5wh6[$c9iv[hm516]], pfoz7 = pfoz7 + (hm516 == 0x0 ? '' : '&') + $c9iv[hm516] + '=' + encodeURIComponent(_5wh6[$c9iv[hm516]]);
  }pzo = pzo + t_ZK[M[1066]];var qe0xy = M[1254] + md5(pzo);send(h58w1 + '?' + pfoz7 + (pfoz7 == '' ? '' : '&') + qe0xy, null, ticv$, rn3bj, y_qmx0, akjbr || function (xwh_y) {
    return xwh_y[M[1101]] == M[1165];
  }, null, M[1255]);
}, window['t_Z6KM'] = function (di9vc$, _yxmq) {
  var r1ng83 = 0x0;t_ZK[M[933]] && (r1ng83 = t_ZK[M[933]][M[934]]), sendApi(t_ZK[M[1062]], M[1256], { 'partnerId': t_ZK[M[1068]], 'gamePkg': t_ZK[M[932]], 'logTime': Math[M[71]](Date[M[1045]]() / 0x3e8), 'platformUid': t_ZK[M[1168]], 'type': di9vc$, 'serverId': r1ng83 }, null, 0x2, null, function () {
    return !![];
  });
}, window['t_ZKM6'] = function (civ2t) {
  sendApi(t_ZK[M[1060]], M[1257], { 'partner_id': t_ZK[M[1068]], 'uid': t_ZK[M[929]], 'version': t_ZK[M[985]], 'game_pkg': t_ZK[M[932]], 'device': t_ZK[M[1069]] }, t_ZK6M, t_6KZ, t_KM);
}, window['t_ZK6M'] = function (x_0qe) {
  if (x_0qe[M[1101]] === M[1165] && x_0qe[M[335]]) {
    x_0qe[M[335]][M[174]]({ 'id': -0x2, 'name': M[1258] }), x_0qe[M[335]][M[174]]({ 'id': -0x1, 'name': M[1259] }), t_ZK[M[1260]] = x_0qe[M[335]];if (window[M[1261]]) window[M[1261]][M[1262]]();
  } else t_ZK[M[1263]] = ![], window['t_M6ZK'](M[1264] + x_0qe[M[1101]]);
}, window['t_M6Z'] = function (gnj3br) {
  sendApi(t_ZK[M[1060]], M[1265], { 'partner_id': t_ZK[M[1068]], 'uid': t_ZK[M[929]], 'version': t_ZK[M[985]], 'game_pkg': t_ZK[M[932]], 'device': t_ZK[M[1069]] }, t_MZ6, t_6KZ, t_KM);
}, window['t_MZ6'] = function (f$pv) {
  t_ZK[M[1266]] = ![];if (f$pv[M[1101]] === M[1165] && f$pv[M[335]]) {
    for (var dof7z = 0x0; dof7z < f$pv[M[335]][M[31]]; dof7z++) {
      f$pv[M[335]][dof7z][M[1183]] = t_Z6M(f$pv[M[335]][dof7z]);
    }t_ZK[M[1071]][-0x1] = window[M[1267]](f$pv[M[335]]), window[M[1261]][M[1268]](-0x1);
  } else window['t_M6ZK'](M[1269] + f$pv[M[1101]]);
}, window[M[1270]] = function (x07oq) {
  sendApi(t_ZK[M[1060]], M[1265], { 'partner_id': t_ZK[M[1068]], 'uid': t_ZK[M[929]], 'version': t_ZK[M[985]], 'game_pkg': t_ZK[M[932]], 'device': t_ZK[M[1069]] }, x07oq, t_6KZ, t_KM);
}, window['t_6MZ'] = function (rgj8, m16h5) {
  sendApi(t_ZK[M[1060]], M[1271], { 'partner_id': t_ZK[M[1068]], 'uid': t_ZK[M[929]], 'version': t_ZK[M[985]], 'game_pkg': t_ZK[M[932]], 'device': t_ZK[M[1069]], 'server_group_id': m16h5 }, t_6ZM, t_6KZ, t_KM);
}, window['t_6ZM'] = function ($ti9v) {
  t_ZK[M[1266]] = ![];if ($ti9v[M[1101]] === M[1165] && $ti9v[M[335]] && $ti9v[M[335]][M[335]]) {
    var n5831 = $ti9v[M[335]][M[1272]],
        pzoe = [];for (var jbas = 0x0; jbas < $ti9v[M[335]][M[335]][M[31]]; jbas++) {
      $ti9v[M[335]][M[335]][jbas][M[1183]] = t_Z6M($ti9v[M[335]][M[335]][jbas]), (pzoe[M[31]] == 0x0 || $ti9v[M[335]][M[335]][jbas][M[1183]] != 0x0) && (pzoe[pzoe[M[31]]] = $ti9v[M[335]][M[335]][jbas]);
    }t_ZK[M[1071]][n5831] = window[M[1267]](pzoe), window[M[1261]][M[1268]](n5831);
  } else window['t_M6ZK'](M[1273] + $ti9v[M[1101]]);
}, window['t_F6KZ'] = function (x70qoe) {
  sendApi(t_ZK[M[1060]], M[1274], { 'partner_id': t_ZK[M[1068]], 'uid': t_ZK[M[929]], 'version': t_ZK[M[985]], 'game_pkg': t_ZK[M[932]], 'device': t_ZK[M[1069]] }, reqServerRecommendCallBack, t_6KZ, t_KM);
}, window[M[1275]] = function (gkjabr) {
  t_ZK[M[1266]] = ![];if (gkjabr[M[1101]] === M[1165] && gkjabr[M[335]]) {
    for (var yxhm0 = 0x0; yxhm0 < gkjabr[M[335]][M[31]]; yxhm0++) {
      gkjabr[M[335]][yxhm0][M[1183]] = t_Z6M(gkjabr[M[335]][yxhm0]);
    }t_ZK[M[1071]][-0x2] = window[M[1267]](gkjabr[M[335]]), window[M[1261]][M[1268]](-0x2);
  } else alert(M[1276] + gkjabr[M[1101]]);
}, window[M[1267]] = function (vid9c) {
  if (!vid9c && vid9c[M[31]] <= 0x0) return vid9c;for (let cl2t = 0x0; cl2t < vid9c[M[31]]; cl2t++) {
    vid9c[cl2t][M[1277]] && vid9c[cl2t][M[1277]] == 0x1 && (vid9c[cl2t][M[1180]] += M[1278]);
  }return vid9c;
}, window['t_ZM6'] = function (z7qof, arsjb) {
  z7qof = z7qof || t_ZK[M[933]][M[934]], sendApi(t_ZK[M[1060]], 'Common.get_anno', { 'type': '4', 'game_pkg': t_ZK[M[932]], 'server_id': z7qof }, arsjb);
}, window[M[1279]] = function (w_ym5, eyx_, pdi$v, gbkjra) {
  pdi$v = pdi$v || t_ZK[M[933]][M[934]], sendApi(t_ZK[M[1060]], 'Common.get_new_anno', { 'type': w_ym5, 'game_pkg': eyx_, 'server_id': pdi$v }, gbkjra);
}, window['t_Z6M'] = function (jarbgn) {
  if (jarbgn) {
    if (jarbgn[M[1183]] == 0x1) {
      if (jarbgn[M[1280]] == 0x1) return 0x2;else return 0x1;
    } else return jarbgn[M[1183]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['t_KM6Z'] = function (oq0ey, o7q0z) {
  t_ZK['last_check_ban'] = { 'step': oq0ey, 'server_id': o7q0z };var bkgar = this;t_MZ6K({ 'title': M[1281] }), sendApi(t_ZK[M[1060]], M[1282], { 'partner_id': t_ZK[M[1068]], 'uid': t_ZK[M[929]], 'game_pkg': t_ZK[M[932]], 'server_id': o7q0z, 'platform': t_ZK[M[989]], 'platform_uid': t_ZK[M[1168]], 'check_login_time': t_ZK[M[1171]], 'check_login_sign': t_ZK[M[1169]], 'version_name': t_ZK[M[1143]] }, t_KMZ6, t_6KZ, t_KM, function (i$c9v) {
    return i$c9v[M[1101]] == M[1165] || i$c9v[M[915]] == M[1283] || i$c9v[M[915]] == M[1284];
  });
}, window['t_KMZ6'] = function (j3brn) {
  var wmy5h = this;if (j3brn[M[1101]] === M[1165] && j3brn[M[335]]) {
    var it9c = t_ZK[M[933]];it9c[M[1285]] = t_ZK[M[1072]], it9c[M[1170]] = String(j3brn[M[335]][M[1286]]), it9c[M[1078]] = parseInt(j3brn[M[335]][M[1172]]);if (j3brn[M[335]][M[1287]]) it9c[M[1287]] = parseInt(j3brn[M[335]][M[1287]]);else it9c[M[1287]] = parseInt(j3brn[M[335]][M[934]]);it9c[M[1288]] = 0x0, it9c[M[931]] = t_ZK[M[1194]], it9c[M[1289]] = j3brn[M[335]][M[1290]], it9c[M[1291]] = j3brn[M[335]][M[1291]], console[M[225]](M[1292] + JSON[M[937]](it9c[M[1291]])), t_ZK[M[1178]] == 0x1 && it9c[M[1291]] && it9c[M[1291]][M[1293]] == 0x1 && (t_ZK[M[1294]] = 0x1, window[M[944]][M[945]]['t_FKZ']()), t_K6MZ();
  } else t_ZK['last_check_ban'][M[1295]] >= 0x3 ? (t_KM(JSON[M[937]](j3brn)), window['t_M6ZK'](M[1296] + j3brn[M[1101]])) : sendApi(t_ZK[M[1060]], M[1152], { 'platform': t_ZK[M[1058]], 'partner_id': t_ZK[M[1068]], 'token': t_ZK[M[1150]], 'game_pkg': t_ZK[M[932]], 'deviceId': t_ZK[M[1069]], 'scene': M[1153] + t_ZK[M[1070]] }, function (yx0q_e) {
    if (!yx0q_e || yx0q_e[M[1101]] != M[1165]) {
      window['t_M6ZK'](M[1166] + yx0q_e && yx0q_e[M[1101]]);return;
    }t_ZK[M[1169]] = String(yx0q_e[M[1170]]), t_ZK[M[1171]] = String(yx0q_e[M[1172]]), setTimeout(function () {
      t_KM6Z(t_ZK['last_check_ban'][M[1295]] + 0x1, t_ZK['last_check_ban'][M[934]]);
    }, 0x5dc);
  }, t_6KZ, t_KM, function (m6h_5w) {
    return m6h_5w[M[1101]] == M[1165] || m6h_5w[M[1101]] == M[1297];
  });
}, window['t_K6MZ'] = function () {
  ServerLoading[M[945]][M[1186]](t_ZK[M[1178]]), window['t_6K'] = !![], window['t_KZM6']();
}, window['t_K6ZM'] = function () {
  if (window['t_K6'] && window['t_Z6K'] && window[M[1084]] && window[M[1085]] && window['t_ZK6'] && window['t_Z6']) {
    if (!window[M[1298]][M[945]]) {
      console[M[225]](M[1299] + window[M[1298]][M[945]]);var r3n8 = wx[M[1300]](),
          dzpv = r3n8[M[1041]] ? r3n8[M[1041]] : 0x0,
          t29cvi = { 'cdn': window['t_ZK'][M[931]], 'spareCdn': window['t_ZK'][M[1141]], 'newRegister': window['t_ZK'][M[1178]], 'wxPC': window['t_ZK'][M[1016]], 'wxIOS': window['t_ZK'][M[1011]], 'wxAndroid': window['t_ZK'][M[1013]], 'wxParam': { 'limitLoad': window['t_ZK']['t_FM6KZ'], 'benchmarkLevel': window['t_ZK']['t_FMZ6K'], 'wxFrom': window[M[919]][M[51]] == M[1301] ? 0x1 : 0x0, 'wxSDKVersion': window[M[946]] }, 'configType': window['t_ZK'][M[1079]], 'exposeType': window['t_ZK'][M[1081]], 'scene': dzpv };new window[M[1298]](t29cvi, window['t_ZK'][M[930]], window['t_FM6ZK']);
    }
  }
}, window['t_KZM6'] = function () {
  if (window['t_K6'] && window['t_Z6K'] && window[M[1084]] && window[M[1085]] && window['t_ZK6'] && window['t_Z6'] && window['t_6K'] && window['t_6Z']) {
    t_MZK6();if (!t_K6Z) {
      t_K6Z = !![];if (!window[M[1298]][M[945]]) window['t_K6ZM']();var zfpd$v = 0x0,
          jb3rgn = wx[M[1302]]();jb3rgn && (window['t_ZK'][M[1015]] && (zfpd$v = jb3rgn[M[1007]]), console[M[915]](M[1303] + jb3rgn[M[1007]] + M[1304] + jb3rgn[M[1008]] + M[1305] + jb3rgn[M[1009]] + M[1306] + jb3rgn[M[1010]] + M[1307] + jb3rgn[M[1308]] + M[1309] + jb3rgn[M[1310]]));var hw651m = {};for (const kbagj in t_ZK[M[933]]) {
        hw651m[kbagj] = t_ZK[M[933]][kbagj];
      }var ti4cl = { 'channel': window['t_ZK'][M[1073]], 'account': window['t_ZK'][M[929]], 'userId': window['t_ZK'][M[1167]], 'cdn': window['t_ZK'][M[931]], 'data': window['t_ZK'][M[335]], 'package': window['t_ZK'][M[304]], 'newRegister': window['t_ZK'][M[1178]], 'pkgName': window['t_ZK'][M[932]], 'partnerId': window['t_ZK'][M[1068]], 'platform_uid': window['t_ZK'][M[1168]], 'deviceId': window['t_ZK'][M[1069]], 'selectedServer': hw651m, 'configType': window['t_ZK'][M[1079]], 'exposeType': window['t_ZK'][M[1081]], 'debugUsers': window['t_ZK'][M[1076]], 'wxMenuTop': zfpd$v, 'wxShield': window['t_ZK'][M[1083]] };if (window[M[1197]]) for (var f9$dpv in window[M[1197]]) {
        ti4cl[f9$dpv] = window[M[1197]][f9$dpv];
      }window[M[1298]][M[945]]['t_6FZK'](ti4cl);
    }
  } else console[M[915]](M[1311] + window['t_K6'] + M[1312] + window['t_Z6K'] + M[1313] + window[M[1084]] + M[1314] + window[M[1085]] + M[1315] + window['t_ZK6'] + M[1316] + window['t_Z6'] + M[1317] + window['t_6K'] + M[1318] + window['t_6Z']);
};