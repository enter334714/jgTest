var Q = wx.$I;
import i_oydg from '../iiiiSDK/iiiSDDK.js';window[Q[149262]] = { 'wxVersion': window[Q[120557]][Q[149160]] }, window[Q[149263]] = ![], window['$iRG'] = 0x1, window[Q[149264]] = 0x1, window['$iDGR'] = !![], window[Q[149265]] = !![], window['$iEXDGR'] = '', window['$iGR'] = { 'base_cdn': Q[149266], 'cdn': Q[149266] }, $iGR[Q[149267]] = {}, $iGR[Q[145050]] = '0', $iGR[Q[124741]] = window[Q[149262]][Q[149268]], $iGR[Q[149234]] = '', $iGR['os'] = '1', $iGR[Q[149269]] = Q[149270], $iGR[Q[149271]] = Q[149272], $iGR[Q[149273]] = Q[149274], $iGR[Q[149275]] = Q[149276], $iGR[Q[149277]] = Q[149278], $iGR[Q[143750]] = '1', $iGR[Q[145345]] = '', $iGR[Q[145347]] = '', $iGR[Q[149279]] = 0x0, $iGR[Q[149280]] = {}, $iGR[Q[149281]] = parseInt($iGR[Q[143750]]), $iGR[Q[145343]] = $iGR[Q[143750]], $iGR[Q[145339]] = {}, $iGR['$iXG'] = Q[149282], $iGR[Q[149283]] = ![], $iGR[Q[132295]] = Q[149284], $iGR[Q[145318]] = Date[Q[120083]](), $iGR[Q[131897]] = Q[149285], $iGR[Q[120714]] = '_a', $iGR[Q[149286]] = 0x2, $iGR[Q[120101]] = 0x7c1, $iGR[Q[149268]] = window[Q[149262]][Q[149268]], $iGR[Q[120738]] = ![], $iGR[Q[121074]] = ![], $iGR[Q[131373]] = ![], $iGR[Q[145052]] = ![], window['$iDRG'] = 0x5, window['$iDR'] = ![], window['$iRD'] = ![], window['$iGDR'] = ![], window[Q[149287]] = ![], window[Q[149288]] = ![], window['$iGRD'] = ![], window['$iDG'] = ![], window['$iGD'] = ![], window['$iRDG'] = ![], window[Q[124209]] = function (bus7ek) {
  console[Q[120482]](Q[124209], bus7ek), wx[Q[125021]]({}), wx[Q[149184]]({ 'title': Q[126395], 'content': bus7ek, 'success'(ek2uqs) {
      if (ek2uqs[Q[149289]]) console[Q[120482]](Q[149290]);else ek2uqs[Q[120553]] && console[Q[120482]](Q[149291]);
    } });
}, window['$iXDGR'] = function (ilz0r$) {
  console[Q[120482]](Q[149292], ilz0r$), $iXGRD(), wx[Q[149184]]({ 'title': Q[126395], 'content': ilz0r$, 'confirmText': Q[149293], 'cancelText': Q[138582], 'success'(keq2us) {
      if (keq2us[Q[149289]]) window['$iGX']();else keq2us[Q[120553]] && (console[Q[120482]](Q[149294]), wx[Q[145045]]({}));
    } });
}, window[Q[149295]] = function (p1f8) {
  console[Q[120482]](Q[149295], p1f8), wx[Q[149184]]({ 'title': Q[126395], 'content': p1f8, 'confirmText': Q[145475], 'showCancel': ![], 'complete'(rimt9v) {
      console[Q[120482]](Q[149294]), wx[Q[145045]]({});
    } });
}, window['$iXDRG'] = ![], window['$iXGDR'] = function (u2ke) {
  window['$iXDRG'] = !![], wx[Q[125020]](u2ke);
}, window['$iXGRD'] = function () {
  window['$iXDRG'] && (window['$iXDRG'] = ![], wx[Q[125021]]({}));
}, window['$iXRDG'] = function (lzi$r0) {
  window[Q[149175]][Q[120148]]['$iXRDG'](lzi$r0);
}, window[Q[132173]] = function (j67ab, q5w4) {
  i_oydg[Q[132173]](j67ab, function (li0r$) {
    li0r$ && li0r$[Q[120011]] ? li0r$[Q[120011]][Q[124142]] == 0x1 ? q5w4(!![]) : (q5w4(![]), console[Q[120078]](Q[149296] + li0r$[Q[120011]][Q[149297]])) : console[Q[120482]](Q[132173], li0r$);
  });
}, window['$iXRGD'] = function (euksb) {
  console[Q[120482]](Q[149298], euksb);
}, window['$iXGR'] = function (ydzgo0) {}, window['$iXRG'] = function (eksqbu, iltr$z, k2nq5) {}, window['$iXR'] = function (itr$9v) {
  console[Q[120482]](Q[149299], itr$9v), window[Q[149175]][Q[120148]][Q[149300]](), window[Q[149175]][Q[120148]][Q[149301]](), window[Q[149175]][Q[120148]][Q[149302]]();
}, window['$iRX'] = function (pa_j8) {
  window['$iXDGR'](Q[149303]);var bqeuks = { 'id': window['$iGR'][Q[149165]], 'role': window['$iGR'][Q[124670]], 'level': window['$iGR'][Q[149166]], 'account': window['$iGR'][Q[145344]], 'version': window['$iGR'][Q[120101]], 'cdn': window['$iGR'][Q[124547]], 'pkgName': window['$iGR'][Q[145345]], 'gamever': window[Q[120557]][Q[149160]], 'serverid': window['$iGR'][Q[145339]] ? window['$iGR'][Q[145339]][Q[131551]] : 0x0, 'systemInfo': window[Q[149167]], 'error': Q[149304], 'stack': pa_j8 ? pa_j8 : Q[149303] },
      ja_fp = JSON[Q[124533]](bqeuks);console[Q[120125]](Q[149305] + ja_fp), window['$iXG'](ja_fp);
}, window['$iGXR'] = function (ks2qe) {
  var wk5n2 = JSON[Q[120527]](ks2qe);wk5n2[Q[149306]] = window[Q[120557]][Q[149160]], wk5n2[Q[149307]] = window['$iGR'][Q[145339]] ? window['$iGR'][Q[145339]][Q[131551]] : 0x0, wk5n2[Q[149167]] = window[Q[149167]];var b673es = JSON[Q[124533]](wk5n2);console[Q[120125]](Q[149308] + b673es), window['$iXG'](b673es);
}, window['$iGRX'] = function (fcvp1m, $vrt9) {
  var mv9c1 = { 'id': window['$iGR'][Q[149165]], 'role': window['$iGR'][Q[124670]], 'level': window['$iGR'][Q[149166]], 'account': window['$iGR'][Q[145344]], 'version': window['$iGR'][Q[120101]], 'cdn': window['$iGR'][Q[124547]], 'pkgName': window['$iGR'][Q[145345]], 'gamever': window[Q[120557]][Q[149160]], 'serverid': window['$iGR'][Q[145339]] ? window['$iGR'][Q[145339]][Q[131551]] : 0x0, 'systemInfo': window[Q[149167]], 'error': fcvp1m, 'stack': $vrt9 },
      cmp_1f = JSON[Q[124533]](mv9c1);console[Q[120096]](Q[149309] + cmp_1f), window['$iXG'](cmp_1f);
}, window['$iXG'] = function (v9mc1) {
  if (window['$iGR'][Q[149235]] == Q[149017]) return;var vm91pc = $iGR['$iXG'] + Q[149310] + $iGR[Q[145344]];wx[Q[120477]]({ 'url': vm91pc, 'method': Q[149023], 'data': v9mc1, 'header': { 'content-type': Q[149311], 'cache-control': Q[149312] }, 'success': function (qn52ku) {
      DEBUG && console[Q[120482]](Q[149313], vm91pc, v9mc1, qn52ku);
    }, 'fail': function (s37eb6) {
      DEBUG && console[Q[120482]](Q[149313], vm91pc, v9mc1, s37eb6);
    }, 'complete': function () {} });
}, window[Q[149314]] = function () {
  function t$riz() {
    return ((0x1 + Math[Q[120119]]()) * 0x10000 | 0x0)[Q[120275]](0x10)[Q[120500]](0x1);
  }return t$riz() + t$riz() + '-' + t$riz() + '-' + t$riz() + '-' + t$riz() + '+' + t$riz() + t$riz() + t$riz();
}, window['$iGX'] = function () {
  console[Q[120482]](Q[149315]);var q245wn = i_oydg[Q[149316]]();$iGR[Q[145343]] = q245wn[Q[149317]], $iGR[Q[149281]] = q245wn[Q[149317]], $iGR[Q[143750]] = q245wn[Q[149317]], $iGR[Q[145345]] = q245wn[Q[149318]];var _36j = { 'game_ver': $iGR[Q[124741]] };$iGR[Q[145347]] = this[Q[149314]](), $iXGDR({ 'title': Q[149319] }), i_oydg[Q[120368]](_36j, this['$iRXG'][Q[120074]](this));
}, window['$iRXG'] = function (kq2w5n) {
  var irtlz$ = kq2w5n[Q[149320]];console[Q[120482]](Q[149321] + irtlz$ + Q[149322] + (irtlz$ == 0x1) + Q[149323] + kq2w5n[Q[149160]] + Q[149324] + window[Q[149262]][Q[149268]]);if (!kq2w5n[Q[149160]] || window['$iEDRXG'](window[Q[149262]][Q[149268]], kq2w5n[Q[149160]]) < 0x0) console[Q[120482]](Q[149325]), $iGR[Q[149271]] = Q[149326], $iGR[Q[149273]] = Q[149327], $iGR[Q[149275]] = Q[149328], $iGR[Q[124547]] = Q[149329], $iGR[Q[145049]] = Q[149330], $iGR[Q[149331]] = 'wd', $iGR[Q[120738]] = ![];else window['$iEDRXG'](window[Q[149262]][Q[149268]], kq2w5n[Q[149160]]) == 0x0 ? (console[Q[120482]](Q[149332]), $iGR[Q[149271]] = Q[149272], $iGR[Q[149273]] = Q[149274], $iGR[Q[149275]] = Q[149276], $iGR[Q[124547]] = Q[149333], $iGR[Q[145049]] = Q[149330], $iGR[Q[149331]] = Q[149334], $iGR[Q[120738]] = !![]) : (console[Q[120482]](Q[149335]), $iGR[Q[149271]] = Q[149272], $iGR[Q[149273]] = Q[149274], $iGR[Q[149275]] = Q[149276], $iGR[Q[124547]] = Q[149333], $iGR[Q[145049]] = Q[149330], $iGR[Q[149331]] = Q[149334], $iGR[Q[120738]] = ![]);$iGR[Q[149279]] = config[Q[148630]] ? config[Q[148630]] : 0x0, this['$iDGXR'](), this['$iDGRX'](), window[Q[149336]] = 0x5, $iXGDR({ 'title': Q[149337] }), i_oydg[Q[149094]](this['$iRGX'][Q[120074]](this));
}, window[Q[149336]] = 0x5, window['$iRGX'] = function (it$l9, oz$g0l) {
  if (it$l9 == 0x0 && oz$g0l && oz$g0l[Q[148723]]) {
    $iGR[Q[149338]] = oz$g0l[Q[148723]];var t1mr9 = this;$iXGDR({ 'title': Q[149339] }), sendApi($iGR[Q[149271]], Q[149340], { 'platform': $iGR[Q[149269]], 'partner_id': $iGR[Q[143750]], 'token': oz$g0l[Q[148723]], 'game_pkg': $iGR[Q[145345]], 'deviceId': $iGR[Q[145347]], 'scene': Q[149341] + $iGR[Q[149279]] }, this['$iDXGR'][Q[120074]](this), $iDRG, $iRX);
  } else oz$g0l && oz$g0l[Q[145528]] && window[Q[149336]] > 0x0 && (oz$g0l[Q[145528]][Q[120115]](Q[149342]) != -0x1 || oz$g0l[Q[145528]][Q[120115]](Q[149343]) != -0x1 || oz$g0l[Q[145528]][Q[120115]](Q[149344]) != -0x1 || oz$g0l[Q[145528]][Q[120115]](Q[149345]) != -0x1 || oz$g0l[Q[145528]][Q[120115]](Q[149346]) != -0x1 || oz$g0l[Q[145528]][Q[120115]](Q[149347]) != -0x1) ? (window[Q[149336]]--, i_oydg[Q[149094]](this['$iRGX'][Q[120074]](this))) : (window['$iGRX'](Q[149348], JSON[Q[124533]]({ 'status': it$l9, 'data': oz$g0l })), window['$iXDGR'](Q[149349] + (oz$g0l && oz$g0l[Q[145528]] ? '，' + oz$g0l[Q[145528]] : '')));
}, window['$iDXGR'] = function (_pf81) {
  if (!_pf81) {
    window['$iGRX'](Q[149350], Q[149351]), window['$iXDGR'](Q[149352]);return;
  }if (_pf81[Q[124142]] != Q[129961]) {
    window['$iGRX'](Q[149350], JSON[Q[124533]](_pf81)), window['$iXDGR'](Q[149353] + _pf81[Q[124142]]);return;
  }$iGR[Q[143749]] = String(_pf81[Q[145344]]), $iGR[Q[145344]] = String(_pf81[Q[145344]]), $iGR[Q[145316]] = String(_pf81[Q[145316]]), $iGR[Q[145343]] = String(_pf81[Q[145316]]), $iGR[Q[145346]] = String(_pf81[Q[145346]]), $iGR[Q[149354]] = String(_pf81[Q[131534]]), $iGR[Q[149355]] = String(_pf81[Q[120851]]), $iGR[Q[131534]] = '';var a3eb6 = this;$iXGDR({ 'title': Q[149356] }), sendApi($iGR[Q[149271]], Q[149357], { 'partner_id': $iGR[Q[143750]], 'uid': $iGR[Q[145344]], 'version': $iGR[Q[124741]], 'game_pkg': $iGR[Q[145345]], 'device': $iGR[Q[145347]] }, a3eb6['$iDXRG'][Q[120074]](a3eb6), $iDRG, $iRX);
}, window['$iDXRG'] = function (i$r9l) {
  if (!i$r9l) {
    window['$iXDGR'](Q[149358]);return;
  }if (i$r9l[Q[124142]] != Q[129961]) {
    window['$iXDGR'](Q[149359] + i$r9l[Q[124142]]);return;
  }if (!i$r9l[Q[120011]] || i$r9l[Q[120011]][Q[120013]] == 0x0) {
    window['$iXDGR'](Q[149360]);return;
  }$iGR[Q[120630]] = i$r9l[Q[149361]], $iGR[Q[145339]] = { 'server_id': String(i$r9l[Q[120011]][0x0][Q[131551]]), 'server_name': String(i$r9l[Q[120011]][0x0][Q[149362]]), 'entry_ip': i$r9l[Q[120011]][0x0][Q[145367]], 'entry_port': parseInt(i$r9l[Q[120011]][0x0][Q[145368]]), 'status': $iGDX(i$r9l[Q[120011]][0x0]), 'start_time': i$r9l[Q[120011]][0x0][Q[149363]], 'cdn': $iGR[Q[124547]] }, this['$iRGDX']();
}, window['$iRGDX'] = function () {
  if ($iGR[Q[120630]] == 0x1) {
    var e7ba3 = $iGR[Q[145339]][Q[120106]];if (e7ba3 === -0x1 || e7ba3 === 0x0) {
      window['$iXDGR'](e7ba3 === -0x1 ? Q[149364] : Q[149365]);return;
    }$iRXDG(0x0, $iGR[Q[145339]][Q[131551]]), window[Q[149175]][Q[120148]][Q[149366]]($iGR[Q[120630]]);
  } else window[Q[149175]][Q[120148]][Q[149367]](), $iXGRD();window['$iGD'] = !![], window['$iRDGX'](), window['$iRGXD']();
}, window['$iDGXR'] = function () {
  sendApi($iGR[Q[149271]], Q[149368], { 'game_pkg': $iGR[Q[145345]], 'version_name': $iGR[Q[149331]] }, this[Q[149369]][Q[120074]](this), $iDRG, $iRX);
}, window[Q[149369]] = function (xnwh45) {
  if (!xnwh45) {
    window['$iXDGR'](Q[149370]);return;
  }if (xnwh45[Q[124142]] != Q[129961]) {
    window['$iXDGR'](Q[149371] + xnwh45[Q[124142]]);return;
  }if (!xnwh45[Q[120011]] || !xnwh45[Q[120011]][Q[124741]]) {
    window['$iXDGR'](Q[149372] + (xnwh45[Q[120011]] && xnwh45[Q[120011]][Q[124741]]));return;
  }xnwh45[Q[120011]][Q[149373]] && xnwh45[Q[120011]][Q[149373]][Q[120013]] > 0xa && ($iGR[Q[149374]] = xnwh45[Q[120011]][Q[149373]], $iGR[Q[124547]] = xnwh45[Q[120011]][Q[149373]]), xnwh45[Q[120011]][Q[124741]] && ($iGR[Q[120101]] = xnwh45[Q[120011]][Q[124741]]), console[Q[120078]](Q[145481] + $iGR[Q[120101]] + Q[149375] + $iGR[Q[149331]]), window['$iGRD'] = !![], window['$iRDGX'](), window['$iRGXD']();
}, window[Q[149376]], window['$iDGRX'] = function () {
  sendApi($iGR[Q[149271]], Q[149377], { 'game_pkg': $iGR[Q[145345]] }, this['$iDRXG'][Q[120074]](this), $iDRG, $iRX);
}, window['$iDRXG'] = function (mir9) {
  if (mir9[Q[124142]] === Q[129961] && mir9[Q[120011]]) {
    window[Q[149376]] = mir9[Q[120011]];for (var zig$l0 in mir9[Q[120011]]) {
      $iGR[zig$l0] = mir9[Q[120011]][zig$l0];
    }
  } else console[Q[120078]](Q[149378] + mir9[Q[124142]]);window['$iDG'] = !![], window['$iRGXD']();
}, window[Q[149379]] = function ($zg0il, ekbqus, imvrt9, fap_8, z0yolg, i$rlzt, rv9m, $gl0i, irvm9) {
  z0yolg = String(z0yolg);var fpc_j8 = rv9m,
      dgo0z = $gl0i;$iGR[Q[149267]][z0yolg] = { 'productid': z0yolg, 'productname': fpc_j8, 'productdesc': dgo0z, 'roleid': $zg0il, 'rolename': ekbqus, 'rolelevel': imvrt9, 'price': i$rlzt, 'callback': irvm9 }, sendApi($iGR[Q[149275]], Q[149380], { 'game_pkg': $iGR[Q[145345]], 'server_id': $iGR[Q[145339]][Q[131551]], 'server_name': $iGR[Q[145339]][Q[149362]], 'level': imvrt9, 'uid': $iGR[Q[145344]], 'role_id': $zg0il, 'role_name': ekbqus, 'product_id': z0yolg, 'product_name': fpc_j8, 'product_desc': dgo0z, 'money': i$rlzt, 'partner_id': $iGR[Q[143750]] }, toPayCallBack, $iDRG, $iRX);
}, window[Q[149381]] = function (vm) {
  if (vm) {
    if (vm[Q[149382]] === 0xc8 || vm[Q[124142]] == Q[129961]) {
      var q5u2kn = $iGR[Q[149267]][String(vm[Q[149383]])];if (q5u2kn[Q[120335]]) q5u2kn[Q[120335]](vm[Q[149383]], vm[Q[149384]], -0x1);i_oydg[Q[149132]]({ 'cpbill': vm[Q[149384]], 'productid': vm[Q[149383]], 'productname': q5u2kn[Q[149385]], 'productdesc': q5u2kn[Q[149386]], 'serverid': $iGR[Q[145339]][Q[131551]], 'servername': $iGR[Q[145339]][Q[149362]], 'roleid': q5u2kn[Q[149387]], 'rolename': q5u2kn[Q[149388]], 'rolelevel': q5u2kn[Q[149389]], 'price': q5u2kn[Q[147045]], 'extension': JSON[Q[124533]]({ 'cp_order_id': vm[Q[149384]] }) }, function (lgzi0$, wn25kq) {
        q5u2kn[Q[120335]] && lgzi0$ == 0x0 && q5u2kn[Q[120335]](vm[Q[149383]], vm[Q[149384]], lgzi0$);console[Q[120078]](JSON[Q[124533]]({ 'type': Q[149390], 'status': lgzi0$, 'data': vm, 'role_name': q5u2kn[Q[149388]] }));if (lgzi0$ === 0x0) {} else {
          if (lgzi0$ === 0x1) {} else {
            if (lgzi0$ === 0x2) {}
          }
        }
      });
    } else alert(vm[Q[120078]]);
  }
}, window['$iDRGX'] = function () {}, window['$iXDR'] = function (itlz$r, _38aj6, vmr91, bj6a, j836a7) {
  i_oydg[Q[149150]]($iGR[Q[145339]][Q[131551]], $iGR[Q[145339]][Q[149362]] || $iGR[Q[145339]][Q[131551]], itlz$r, _38aj6, vmr91), sendApi($iGR[Q[149271]], Q[149391], { 'game_pkg': $iGR[Q[145345]], 'server_id': $iGR[Q[145339]][Q[131551]], 'role_id': itlz$r, 'uid': $iGR[Q[145344]], 'role_name': _38aj6, 'role_type': bj6a, 'level': vmr91 });
}, window['$iXRD'] = function (nq42w, c_8pf, pc8_j, h5n, e6s7, $lrit, fj8_pc, il9t$, eskq2, igl0) {
  $iGR[Q[149165]] = nq42w, $iGR[Q[124670]] = c_8pf, $iGR[Q[149166]] = pc8_j, i_oydg[Q[149151]]($iGR[Q[145339]][Q[131551]], $iGR[Q[145339]][Q[149362]] || $iGR[Q[145339]][Q[131551]], nq42w, c_8pf, pc8_j), sendApi($iGR[Q[149271]], Q[149392], { 'game_pkg': $iGR[Q[145345]], 'server_id': $iGR[Q[145339]][Q[131551]], 'role_id': nq42w, 'uid': $iGR[Q[145344]], 'role_name': c_8pf, 'role_type': h5n, 'level': pc8_j, 'evolution': e6s7 });
}, window['$iDXR'] = function (yoz0d, goz0yl, u5qnk, aj63b, use2, h4n25w, s2uqe, af8j_6, bse763, ivmtr) {
  $iGR[Q[149165]] = yoz0d, $iGR[Q[124670]] = goz0yl, $iGR[Q[149166]] = u5qnk, i_oydg[Q[149152]]($iGR[Q[145339]][Q[131551]], $iGR[Q[145339]][Q[149362]] || $iGR[Q[145339]][Q[131551]], yoz0d, goz0yl, u5qnk), sendApi($iGR[Q[149271]], Q[149392], { 'game_pkg': $iGR[Q[145345]], 'server_id': $iGR[Q[145339]][Q[131551]], 'role_id': yoz0d, 'uid': $iGR[Q[145344]], 'role_name': goz0yl, 'role_type': aj63b, 'level': u5qnk, 'evolution': use2 });
}, window['$iDRX'] = function (fc1vmp) {}, window['$iXD'] = function (bsuqe) {
  i_oydg[Q[149112]](Q[149112], function (c1f8p) {
    bsuqe && bsuqe(c1f8p);
  });
}, window[Q[145029]] = function () {
  i_oydg[Q[145029]]();
}, window[Q[149393]] = function () {
  i_oydg[Q[143642]]();
}, window[Q[149394]] = function (ri$tz, seu3b7, pf1m_, e6ba, l0giz$, z$l0og, n5hw2, pmvfc) {
  pmvfc = pmvfc || $iGR[Q[145339]][Q[131551]], sendApi($iGR[Q[149271]], Q[149395], { 'phone': ri$tz, 'role_id': seu3b7, 'uid': $iGR[Q[145344]], 'game_pkg': $iGR[Q[145345]], 'partner_id': $iGR[Q[143750]], 'server_id': pmvfc }, n5hw2);
}, window[Q[130883]] = function (m91rvt) {
  window['$iRXD'] = m91rvt, window['$iRXD'] && window['$iDX'] && (console[Q[120078]](Q[149254] + window['$iDX'][Q[120776]]), window['$iRXD'](window['$iDX']), window['$iDX'] = null);
}, window['$iRDX'] = function (r1m9v, n25kwq, bu3e, fp_a) {
  window[Q[120022]](Q[149396], { 'game_pkg': window['$iGR'][Q[145345]], 'role_id': n25kwq, 'server_id': bu3e }, fp_a);
}, window['$iGXDR'] = function (z$litr, bse73) {
  function a8_(goly) {
    var sqbuke = [],
        t$9irv = [],
        cpj8 = window[Q[120557]][Q[149397]];for (var _f1p8 in cpj8) {
      var uksb7e = Number(_f1p8);(!z$litr || !z$litr[Q[120013]] || z$litr[Q[120115]](uksb7e) != -0x1) && (t$9irv[Q[120029]](cpj8[_f1p8]), sqbuke[Q[120029]]([uksb7e, 0x3]));
    }window['$iEDRXG'](window[Q[149176]], Q[149398]) >= 0x0 ? (console[Q[120482]](Q[149399]), i_oydg[Q[149400]] && i_oydg[Q[149400]](t$9irv, function (cjp8f_) {
      console[Q[120482]](Q[149401]), console[Q[120482]](cjp8f_);if (cjp8f_ && cjp8f_[Q[145528]] == Q[149402]) for (var wh4n2 in cpj8) {
        if (cjp8f_[cpj8[wh4n2]] == Q[149403]) {
          var u2nq = Number(wh4n2);for (var z0ri$l = 0x0; z0ri$l < sqbuke[Q[120013]]; z0ri$l++) {
            if (sqbuke[z0ri$l][0x0] == u2nq) {
              sqbuke[z0ri$l][0x1] = 0x1;break;
            }
          }
        }
      }window['$iEDRXG'](window[Q[149176]], Q[149404]) >= 0x0 ? wx[Q[149405]]({ 'withSubscriptions': !![], 'success': function (v1t9cm) {
          var pvcfm = v1t9cm[Q[149406]][Q[149407]];if (pvcfm) {
            console[Q[120482]](Q[149408]), console[Q[120482]](pvcfm);for (var $ir in cpj8) {
              if (pvcfm[cpj8[$ir]] == Q[149403]) {
                var pf1c_ = Number($ir);for (var kub = 0x0; kub < sqbuke[Q[120013]]; kub++) {
                  if (sqbuke[kub][0x0] == pf1c_) {
                    sqbuke[kub][0x1] = 0x2;break;
                  }
                }
              }
            }console[Q[120482]](sqbuke), bse73 && bse73(sqbuke);
          } else console[Q[120482]](Q[149409]), console[Q[120482]](v1t9cm), console[Q[120482]](sqbuke), bse73 && bse73(sqbuke);
        }, 'fail': function () {
          console[Q[120482]](Q[149410]), console[Q[120482]](sqbuke), bse73 && bse73(sqbuke);
        } }) : (console[Q[120482]](Q[149411] + window[Q[149176]]), console[Q[120482]](sqbuke), bse73 && bse73(sqbuke));
    })) : (console[Q[120482]](Q[149412] + window[Q[149176]]), console[Q[120482]](sqbuke), bse73 && bse73(sqbuke)), wx[Q[149413]](a8_);
  }wx[Q[149414]](a8_);
}, window['$iGXRD'] = { 'isSuccess': ![], 'level': Q[149415], 'isCharging': ![] }, window['$iGDXR'] = function (abj367) {
  wx[Q[149243]]({ 'success': function (rtv9m1) {
      var r$zlit = window['$iGXRD'];r$zlit[Q[149416]] = !![], r$zlit[Q[124646]] = Number(rtv9m1[Q[124646]])[Q[124257]](0x0), r$zlit[Q[149246]] = rtv9m1[Q[149246]], abj367 && abj367(r$zlit[Q[149416]], r$zlit[Q[124646]], r$zlit[Q[149246]]);
    }, 'fail': function (t9i$lr) {
      console[Q[120482]](Q[149417], t9i$lr[Q[145528]]);var qun52k = window['$iGXRD'];abj367 && abj367(qun52k[Q[149416]], qun52k[Q[124646]], qun52k[Q[149246]]);
    } });
}, window[Q[120022]] = function ($gl0iz, p9vcm1, ol0$zg, a736b, fja8, qkwn25, n452h, mv9t1) {
  if (a736b == undefined) a736b = 0x1;wx[Q[120477]]({ 'url': $gl0iz, 'method': n452h || Q[145235], 'responseType': Q[124454], 'data': p9vcm1, 'header': { 'content-type': mv9t1 || Q[149311] }, 'success': function (pmvc1f) {
      DEBUG && console[Q[120482]](Q[149418], $gl0iz, info, pmvc1f);if (pmvc1f && pmvc1f[Q[145599]] == 0xc8) {
        var $i9rv = pmvc1f[Q[120011]];!qkwn25 || qkwn25($i9rv) ? ol0$zg && ol0$zg($i9rv) : window[Q[149419]]($gl0iz, p9vcm1, ol0$zg, a736b, fja8, qkwn25, pmvc1f);
      } else window[Q[149419]]($gl0iz, p9vcm1, ol0$zg, a736b, fja8, qkwn25, pmvc1f);
    }, 'fail': function (knuq2) {
      DEBUG && console[Q[120482]](Q[149420], $gl0iz, info, knuq2), window[Q[149419]]($gl0iz, p9vcm1, ol0$zg, a736b, fja8, qkwn25, knuq2);
    }, 'complete': function () {} });
}, window[Q[149419]] = function (i0gzl$, nkqw2, tmir9, cf1mvp, ztrl$i, fpm1c, n42hw) {
  cf1mvp - 0x1 > 0x0 ? setTimeout(function () {
    window[Q[120022]](i0gzl$, nkqw2, tmir9, cf1mvp - 0x1, ztrl$i, fpm1c);
  }, 0x3e8) : ztrl$i && ztrl$i(JSON[Q[124533]]({ 'url': i0gzl$, 'response': n42hw }));
}, window[Q[149421]] = function (m1vt9c, t9$vi, r1m9t, nh45w, b3a7e6, kqubs, ri9m) {
  !r1m9t && (r1m9t = {});var zyog0l = Math[Q[120118]](Date[Q[120083]]() / 0x3e8);r1m9t[Q[120851]] = zyog0l, r1m9t[Q[149422]] = t9$vi;var l$ig = Object[Q[120267]](r1m9t)[Q[121078]](),
      c9v1tm = '',
      g0$ozl = '';for (var i9rvmt = 0x0; i9rvmt < l$ig[Q[120013]]; i9rvmt++) {
    c9v1tm = c9v1tm + (i9rvmt == 0x0 ? '' : '&') + l$ig[i9rvmt] + r1m9t[l$ig[i9rvmt]], g0$ozl = g0$ozl + (i9rvmt == 0x0 ? '' : '&') + l$ig[i9rvmt] + '=' + encodeURIComponent(r1m9t[l$ig[i9rvmt]]);
  }c9v1tm = c9v1tm + $iGR[Q[149277]];var sqe2uk = Q[149423] + md5(c9v1tm);send(m1vt9c + '?' + g0$ozl + (g0$ozl == '' ? '' : '&') + sqe2uk, null, nh45w, b3a7e6, kqubs, ri9m || function (j8af) {
    return j8af[Q[124142]] == Q[129961];
  }, null, Q[149024]);
}, window['$iGDRX'] = function (i$0lzr, mv9tc) {
  var mp91cv = 0x0;$iGR[Q[145339]] && (mp91cv = $iGR[Q[145339]][Q[131551]]), sendApi($iGR[Q[149273]], Q[149424], { 'partnerId': $iGR[Q[143750]], 'gamePkg': $iGR[Q[145345]], 'logTime': Math[Q[120118]](Date[Q[120083]]() / 0x3e8), 'platformUid': $iGR[Q[145346]], 'type': i$0lzr, 'serverId': mp91cv }, null, 0x2, null, function () {
    return !![];
  });
}, window['$iGRXD'] = function (z$0lgo) {
  sendApi($iGR[Q[149271]], Q[149425], { 'partner_id': $iGR[Q[143750]], 'uid': $iGR[Q[145344]], 'version': $iGR[Q[124741]], 'game_pkg': $iGR[Q[145345]], 'device': $iGR[Q[145347]] }, $iGRDX, $iDRG, $iRX);
}, window['$iGRDX'] = function (mtv9c1) {
  if (mtv9c1[Q[124142]] === Q[129961] && mtv9c1[Q[120011]]) {
    mtv9c1[Q[120011]][Q[125624]]({ 'id': -0x2, 'name': Q[149426] }), mtv9c1[Q[120011]][Q[125624]]({ 'id': -0x1, 'name': Q[149427] }), $iGR[Q[149428]] = mtv9c1[Q[120011]];if (window[Q[132345]]) window[Q[132345]][Q[149429]]();
  } else $iGR[Q[149430]] = ![], window['$iXDGR'](Q[149431] + mtv9c1[Q[124142]]);
}, window['$iXDG'] = function (ja376) {
  sendApi($iGR[Q[149271]], Q[149432], { 'partner_id': $iGR[Q[143750]], 'uid': $iGR[Q[145344]], 'version': $iGR[Q[124741]], 'game_pkg': $iGR[Q[145345]], 'device': $iGR[Q[145347]] }, $iXGD, $iDRG, $iRX);
}, window['$iXGD'] = function (ozlg$0) {
  $iGR[Q[149433]] = ![];if (ozlg$0[Q[124142]] === Q[129961] && ozlg$0[Q[120011]]) {
    for (var g0zd = 0x0; g0zd < ozlg$0[Q[120011]][Q[120013]]; g0zd++) {
      ozlg$0[Q[120011]][g0zd][Q[120106]] = $iGDX(ozlg$0[Q[120011]][g0zd]);
    }$iGR[Q[149280]][-0x1] = window[Q[149434]](ozlg$0[Q[120011]]), window[Q[132345]][Q[149435]](-0x1);
  } else window['$iXDGR'](Q[149436] + ozlg$0[Q[124142]]);
}, window[Q[149437]] = function (qkeu) {
  sendApi($iGR[Q[149271]], Q[149432], { 'partner_id': $iGR[Q[143750]], 'uid': $iGR[Q[145344]], 'version': $iGR[Q[124741]], 'game_pkg': $iGR[Q[145345]], 'device': $iGR[Q[145347]] }, qkeu, $iDRG, $iRX);
}, window['$iDXG'] = function (l0$gzo, g$lzi0) {
  sendApi($iGR[Q[149271]], Q[149438], { 'partner_id': $iGR[Q[143750]], 'uid': $iGR[Q[145344]], 'version': $iGR[Q[124741]], 'game_pkg': $iGR[Q[145345]], 'device': $iGR[Q[145347]], 'server_group_id': g$lzi0 }, $iDGX, $iDRG, $iRX);
}, window['$iDGX'] = function (t9$v) {
  $iGR[Q[149433]] = ![];if (t9$v[Q[124142]] === Q[129961] && t9$v[Q[120011]] && t9$v[Q[120011]][Q[120011]]) {
    var _8pcjf = t9$v[Q[120011]][Q[149439]],
        bkq = [];for (var $ilt9 = 0x0; $ilt9 < t9$v[Q[120011]][Q[120011]][Q[120013]]; $ilt9++) {
      t9$v[Q[120011]][Q[120011]][$ilt9][Q[120106]] = $iGDX(t9$v[Q[120011]][Q[120011]][$ilt9]), (bkq[Q[120013]] == 0x0 || t9$v[Q[120011]][Q[120011]][$ilt9][Q[120106]] != 0x0) && (bkq[bkq[Q[120013]]] = t9$v[Q[120011]][Q[120011]][$ilt9]);
    }$iGR[Q[149280]][_8pcjf] = window[Q[149434]](bkq), window[Q[132345]][Q[149435]](_8pcjf);
  } else window['$iXDGR'](Q[149440] + t9$v[Q[124142]]);
}, window['$iEDRG'] = function (knu2) {
  sendApi($iGR[Q[149271]], Q[149441], { 'partner_id': $iGR[Q[143750]], 'uid': $iGR[Q[145344]], 'version': $iGR[Q[124741]], 'game_pkg': $iGR[Q[145345]], 'device': $iGR[Q[145347]] }, reqServerRecommendCallBack, $iDRG, $iRX);
}, window[Q[149442]] = function (keus) {
  $iGR[Q[149433]] = ![];if (keus[Q[124142]] === Q[129961] && keus[Q[120011]]) {
    for (var p9vc1m = 0x0; p9vc1m < keus[Q[120011]][Q[120013]]; p9vc1m++) {
      keus[Q[120011]][p9vc1m][Q[120106]] = $iGDX(keus[Q[120011]][p9vc1m]);
    }$iGR[Q[149280]][-0x2] = window[Q[149434]](keus[Q[120011]]), window[Q[132345]][Q[149435]](-0x2);
  } else alert(Q[149443] + keus[Q[124142]]);
}, window[Q[149434]] = function (ae7b) {
  if (!ae7b && ae7b[Q[120013]] <= 0x0) return ae7b;for (let b7se63 = 0x0; b7se63 < ae7b[Q[120013]]; b7se63++) {
    ae7b[b7se63][Q[149444]] && ae7b[b7se63][Q[149444]] == 0x1 && (ae7b[b7se63][Q[149362]] += Q[149445]);
  }return ae7b;
}, window['$iGXD'] = function (eb7ks, v9tm1c) {
  eb7ks = eb7ks || $iGR[Q[145339]][Q[131551]], sendApi($iGR[Q[149271]], Q[149446], { 'type': '4', 'game_pkg': $iGR[Q[145345]], 'server_id': eb7ks }, v9tm1c);
}, window[Q[149447]] = function (use7b3, kbsueq, v$rit9, rtvm9) {
  v$rit9 = v$rit9 || $iGR[Q[145339]][Q[131551]], sendApi($iGR[Q[149271]], Q[149448], { 'type': use7b3, 'game_pkg': kbsueq, 'server_id': v$rit9 }, rtvm9);
}, window['$iGDX'] = function (w52hn4) {
  if (w52hn4) {
    if (w52hn4[Q[120106]] == 0x1) {
      if (w52hn4[Q[149449]] == 0x1) return 0x2;else return 0x1;
    } else return w52hn4[Q[120106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$iRXDG'] = function (uqkesb, c1_pf8) {
  $iGR[Q[149450]] = { 'step': uqkesb, 'server_id': c1_pf8 };var zydog = this;$iXGDR({ 'title': Q[149451] }), sendApi($iGR[Q[149271]], Q[149452], { 'partner_id': $iGR[Q[143750]], 'uid': $iGR[Q[145344]], 'game_pkg': $iGR[Q[145345]], 'server_id': c1_pf8, 'platform': $iGR[Q[145316]], 'platform_uid': $iGR[Q[145346]], 'check_login_time': $iGR[Q[149355]], 'check_login_sign': $iGR[Q[149354]], 'version_name': $iGR[Q[149331]] }, $iRXGD, $iDRG, $iRX, function (_8af) {
    return _8af[Q[124142]] == Q[129961] || _8af[Q[120078]] == Q[149453] || _8af[Q[120078]] == Q[149454];
  });
}, window['$iRXGD'] = function (_ajf8) {
  var yd0ozg = this;if (_ajf8[Q[124142]] === Q[129961] && _ajf8[Q[120011]]) {
    var nw54h = $iGR[Q[145339]];nw54h[Q[149455]] = $iGR[Q[149281]], nw54h[Q[131534]] = String(_ajf8[Q[120011]][Q[149456]]), nw54h[Q[145318]] = parseInt(_ajf8[Q[120011]][Q[120851]]);if (_ajf8[Q[120011]][Q[145317]]) nw54h[Q[145317]] = parseInt(_ajf8[Q[120011]][Q[145317]]);else nw54h[Q[145317]] = parseInt(_ajf8[Q[120011]][Q[131551]]);nw54h[Q[149457]] = 0x0, nw54h[Q[124547]] = $iGR[Q[149374]], nw54h[Q[149458]] = _ajf8[Q[120011]][Q[149459]], nw54h[Q[149460]] = _ajf8[Q[120011]][Q[149460]], console[Q[120482]](Q[149461] + JSON[Q[124533]](nw54h[Q[149460]])), $iGR[Q[120630]] == 0x1 && nw54h[Q[149460]] && nw54h[Q[149460]][Q[149462]] == 0x1 && ($iGR[Q[149463]] = 0x1, window[Q[149175]][Q[120148]]['$iERG']()), $iRDXG();
  } else $iGR[Q[149450]][Q[127165]] >= 0x3 ? ($iRX(JSON[Q[124533]](_ajf8)), window['$iXDGR'](Q[149464] + _ajf8[Q[124142]])) : sendApi($iGR[Q[149271]], Q[149340], { 'platform': $iGR[Q[149269]], 'partner_id': $iGR[Q[143750]], 'token': $iGR[Q[149338]], 'game_pkg': $iGR[Q[145345]], 'deviceId': $iGR[Q[145347]], 'scene': Q[149341] + $iGR[Q[149279]] }, function ($gz0o) {
    if (!$gz0o || $gz0o[Q[124142]] != Q[129961]) {
      window['$iXDGR'](Q[149353] + $gz0o && $gz0o[Q[124142]]);return;
    }$iGR[Q[149354]] = String($gz0o[Q[131534]]), $iGR[Q[149355]] = String($gz0o[Q[120851]]), setTimeout(function () {
      $iRXDG($iGR[Q[149450]][Q[127165]] + 0x1, $iGR[Q[149450]][Q[131551]]);
    }, 0x5dc);
  }, $iDRG, $iRX, function (z0gl$o) {
    return z0gl$o[Q[124142]] == Q[129961] || z0gl$o[Q[124142]] == Q[145678];
  });
}, window['$iRDXG'] = function () {
  ServerLoading[Q[120148]][Q[149366]]($iGR[Q[120630]]), window['$iDR'] = !![], window['$iRGXD']();
}, window['$iRDGX'] = function () {
  if (window['$iRD'] && window['$iGDR'] && window[Q[149287]] && window[Q[149288]] && window['$iGRD'] && window['$iGD']) {
    if (!window[Q[148609]][Q[120148]]) {
      console[Q[120482]](Q[149465] + window[Q[148609]][Q[120148]]);var qu5k2 = wx[Q[149466]](),
          $tvi = qu5k2[Q[120776]] ? qu5k2[Q[120776]] : 0x0,
          t9lr$ = { 'cdn': window['$iGR'][Q[124547]], 'spareCdn': window['$iGR'][Q[145049]], 'newRegister': window['$iGR'][Q[120630]], 'wxPC': window['$iGR'][Q[145052]], 'wxIOS': window['$iGR'][Q[121074]], 'wxAndroid': window['$iGR'][Q[131373]], 'wxParam': { 'limitLoad': window['$iGR']['$iEXDRG'], 'benchmarkLevel': window['$iGR']['$iEXGDR'], 'wxFrom': window[Q[120557]][Q[148630]] == Q[149467] ? 0x1 : 0x0, 'wxSDKVersion': window[Q[149176]] }, 'configType': window['$iGR'][Q[131897]], 'exposeType': window['$iGR'][Q[120714]], 'scene': $tvi };new window[Q[148609]](t9lr$, window['$iGR'][Q[120101]], window['$iEXDGR']);
    }
  }
}, window['$iRGXD'] = function () {
  if (window['$iRD'] && window['$iGDR'] && window[Q[149287]] && window[Q[149288]] && window['$iGRD'] && window['$iGD'] && window['$iDR'] && window['$iDG']) {
    $iXGRD();if (!$iRDG) {
      $iRDG = !![];if (!window[Q[148609]][Q[120148]]) window['$iRDGX']();var m9triv = 0x0,
          zg0ody = wx[Q[149468]]();zg0ody && (window['$iGR'][Q[149232]] && (m9triv = zg0ody[Q[120323]]), console[Q[120078]](Q[149469] + zg0ody[Q[120323]] + Q[149470] + zg0ody[Q[121216]] + Q[149471] + zg0ody[Q[121218]] + Q[149472] + zg0ody[Q[121217]] + Q[149473] + zg0ody[Q[120176]] + Q[149474] + zg0ody[Q[120177]]));var ivr9 = {};for (const usqe in $iGR[Q[145339]]) {
        ivr9[usqe] = $iGR[Q[145339]][usqe];
      }var z0ig = { 'channel': window['$iGR'][Q[145343]], 'account': window['$iGR'][Q[145344]], 'userId': window['$iGR'][Q[143749]], 'cdn': window['$iGR'][Q[124547]], 'data': window['$iGR'][Q[120011]], 'package': window['$iGR'][Q[145050]], 'newRegister': window['$iGR'][Q[120630]], 'pkgName': window['$iGR'][Q[145345]], 'partnerId': window['$iGR'][Q[143750]], 'platform_uid': window['$iGR'][Q[145346]], 'deviceId': window['$iGR'][Q[145347]], 'selectedServer': ivr9, 'configType': window['$iGR'][Q[131897]], 'exposeType': window['$iGR'][Q[120714]], 'debugUsers': window['$iGR'][Q[132295]], 'wxMenuTop': m9triv, 'wxShield': window['$iGR'][Q[120738]] };if (window[Q[149376]]) for (var vpfc1 in window[Q[149376]]) {
        z0ig[vpfc1] = window[Q[149376]][vpfc1];
      }window[Q[148609]][Q[120148]]['$iRGE'](z0ig);
    }
  } else console[Q[120078]](Q[149475] + window['$iRD'] + Q[149476] + window['$iGDR'] + Q[149477] + window[Q[149287]] + Q[149478] + window[Q[149288]] + Q[149479] + window['$iGRD'] + Q[149480] + window['$iGD'] + Q[149481] + window['$iDR'] + Q[149482] + window['$iDG']);
};