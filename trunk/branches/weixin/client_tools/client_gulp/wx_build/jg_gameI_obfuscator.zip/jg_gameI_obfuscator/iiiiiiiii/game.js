var Q = wx.$I;
import 'iiiMAIN.js';