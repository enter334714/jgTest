var Q = wx.$I;
console[Q[120078]](Q[149157]), window[Q[149158]], wx[Q[149159]](function (kubs7) {
  if (kubs7) {
    if (kubs7[Q[124549]]) {
      var j38_a = window[Q[120557]][Q[149160]][Q[124728]](new RegExp(/\./, 'g'), '_'),
          j6_a8 = kubs7[Q[124549]],
          fc1_pm = j6_a8[Q[132097]](/(iiiiiiiii\/iiiiGAME.js:)[0-9]{1,60}(:)/g);if (fc1_pm) for (var iz0lg$ = 0x0; iz0lg$ < fc1_pm[Q[120013]]; iz0lg$++) {
        if (fc1_pm[iz0lg$] && fc1_pm[iz0lg$][Q[120013]] > 0x0) {
          var f18p = parseInt(fc1_pm[iz0lg$][Q[124728]](Q[149161], '')[Q[124728]](':', ''));j6_a8 = j6_a8[Q[124728]](fc1_pm[iz0lg$], fc1_pm[iz0lg$][Q[124728]](':' + f18p + ':', ':' + (f18p - 0x2) + ':'));
        }
      }j6_a8 = j6_a8[Q[124728]](new RegExp(Q[149162], 'g'), Q[149163] + j38_a + Q[145444]), j6_a8 = j6_a8[Q[124728]](new RegExp(Q[149164], 'g'), Q[149163] + j38_a + Q[145444]), kubs7[Q[124549]] = j6_a8;
    }var suqn2k = { 'id': window['$iGR'][Q[149165]], 'role': window['$iGR'][Q[124670]], 'level': window['$iGR'][Q[149166]], 'user': window['$iGR'][Q[145344]], 'version': window['$iGR'][Q[120101]], 'cdn': window['$iGR'][Q[124547]], 'pkgName': window['$iGR'][Q[145345]], 'gamever': window[Q[120557]][Q[149160]], 'serverid': window['$iGR'][Q[145339]] ? window['$iGR'][Q[145339]][Q[131551]] : 0x0, 'systemInfo': window[Q[149167]], 'error': Q[149168], 'stack': kubs7 ? kubs7[Q[124549]] : '' },
        gzo$0 = JSON[Q[124533]](suqn2k);console[Q[120125]](Q[149169] + gzo$0), (!window[Q[149158]] || window[Q[149158]] != suqn2k[Q[120125]]) && (window[Q[149158]] = suqn2k[Q[120125]], window['$iXG'](suqn2k));
  }
});import 'iiiMDFIVEMIN.js';import 'iiiZLIBS.js';window[Q[149170]] = require(Q[149171]);import 'iiiINDEX.js';import 'iiiLIBSMIN.js';import 'iiiWXMINI.js';import 'iiiINITMIN.js';console[Q[120078]](Q[149172]), console[Q[120078]](Q[149173]), $iXGDR({ 'title': Q[149174] });var i_zgd0 = { '$iEXRGD': !![] };new window[Q[149175]](i_zgd0), window[Q[149175]][Q[120148]]['$iEDGRX']();if (window['$iEXGRD']) clearInterval(window['$iEXGRD']);window['$iEXGRD'] = null, window['$iEDRXG'] = function (bu7kes, sbuke) {
  if (!bu7kes || !sbuke) return 0x0;bu7kes = bu7kes[Q[120015]]('.'), sbuke = sbuke[Q[120015]]('.');const tizrl$ = Math[Q[120853]](bu7kes[Q[120013]], sbuke[Q[120013]]);while (bu7kes[Q[120013]] < tizrl$) {
    bu7kes[Q[120029]]('0');
  }while (sbuke[Q[120013]] < tizrl$) {
    sbuke[Q[120029]]('0');
  }for (var v9mtr = 0x0; v9mtr < tizrl$; v9mtr++) {
    const rltz$ = parseInt(bu7kes[v9mtr]),
          virm9t = parseInt(sbuke[v9mtr]);if (rltz$ > virm9t) return 0x1;else {
      if (rltz$ < virm9t) return -0x1;
    }
  }return 0x0;
}, window[Q[149176]] = wx[Q[149177]]()[Q[149176]], console[Q[120482]](Q[149178] + window[Q[149176]]);var i_im9rtv = wx[Q[149179]]();i_im9rtv[Q[149180]](function (kbqeu) {
  console[Q[120482]](Q[149181] + kbqeu[Q[149182]]);
}), i_im9rtv[Q[149183]](function () {
  wx[Q[149184]]({ 'title': Q[149185], 'content': Q[149186], 'showCancel': ![], 'success': function (uskeq2) {
      i_im9rtv[Q[149187]]();
    } });
}), i_im9rtv[Q[149188]](function () {
  console[Q[120482]](Q[149189]);
}), window['$iEDRGX'] = function () {
  console[Q[120482]](Q[149190]);var do0gzy = wx[Q[149191]]({ 'name': Q[149192], 'success': function (e2qsuk) {
      console[Q[120482]](Q[149193]), console[Q[120482]](e2qsuk), e2qsuk && e2qsuk[Q[145528]] == Q[149194] ? (window['$iRD'] = !![], window['$iRDGX'](), window['$iRGXD']()) : setTimeout(function () {
        window['$iEDRGX']();
      }, 0x1f4);
    }, 'fail': function (r0zil) {
      console[Q[120482]](Q[149195]), console[Q[120482]](r0zil), setTimeout(function () {
        window['$iEDRGX']();
      }, 0x1f4);
    } });do0gzy && do0gzy[Q[149196]](sub7k => {});
}, window['$iEGXRD'] = function () {
  console[Q[120482]](Q[149197]);var ebu7sk = wx[Q[149191]]({ 'name': Q[149198], 'success': function (pc8f) {
      console[Q[120482]](Q[149199]), console[Q[120482]](pc8f), pc8f && pc8f[Q[145528]] == Q[149194] ? (window['$iGDR'] = !![], window['$iRDGX'](), window['$iRGXD']()) : setTimeout(function () {
        window['$iEGXRD']();
      }, 0x1f4);
    }, 'fail': function (sqn) {
      console[Q[120482]](Q[149200]), console[Q[120482]](sqn), setTimeout(function () {
        window['$iEGXRD']();
      }, 0x1f4);
    } });ebu7sk && ebu7sk[Q[149196]](_8pjf => {});
}, window[Q[149201]] = function () {
  window['$iEDRXG'](window[Q[149176]], Q[149202]) >= 0x0 ? (console[Q[120482]](Q[149203] + window[Q[149176]] + Q[149204]), window['$iGX'](), window['$iEDRGX'](), window['$iEGXRD']()) : (window['$iGRX'](Q[149205], window[Q[149176]]), wx[Q[149184]]({ 'title': Q[126395], 'content': Q[149206] }));
}, window[Q[149167]] = '', wx[Q[149207]]({ 'success'(c1f_p) {
    window[Q[149167]] = Q[149208] + c1f_p[Q[149209]] + Q[149210] + c1f_p[Q[149211]] + Q[149212] + c1f_p[Q[124741]] + Q[149213] + c1f_p[Q[120475]] + Q[149214] + c1f_p[Q[145316]] + Q[149215] + c1f_p[Q[149176]] + Q[149216] + c1f_p[Q[129350]], console[Q[120482]](window[Q[149167]]), console[Q[120482]](Q[149217] + c1f_p[Q[149218]] + Q[149219] + c1f_p[Q[149220]] + Q[149221] + c1f_p[Q[149222]] + Q[149223] + c1f_p[Q[149224]] + Q[149225] + c1f_p[Q[149226]] + Q[149227] + c1f_p[Q[149228]] + Q[149229] + (c1f_p[Q[149230]] ? c1f_p[Q[149230]][Q[120323]] + ',' + c1f_p[Q[149230]][Q[121216]] + ',' + c1f_p[Q[149230]][Q[121218]] + ',' + c1f_p[Q[149230]][Q[121217]] : ''));var f_mcp1 = c1f_p[Q[120475]] ? c1f_p[Q[120475]][Q[132394]]() : '',
        e3bs = c1f_p[Q[149211]] ? c1f_p[Q[149211]][Q[132394]]()[Q[124728]]('\x20', '') : '';window['$iGR'][Q[121074]] = f_mcp1[Q[120115]](Q[149231]) != -0x1, window['$iGR'][Q[131373]] = f_mcp1[Q[120115]](Q[149018]) != -0x1, window['$iGR'][Q[149232]] = f_mcp1[Q[120115]](Q[149231]) != -0x1 || f_mcp1[Q[120115]](Q[149018]) != -0x1, window['$iGR'][Q[145052]] = f_mcp1[Q[120115]](Q[149233]) != -0x1 || f_mcp1[Q[120115]](Q[149234]) != -0x1, window['$iGR'][Q[149235]] = c1f_p[Q[145316]] ? c1f_p[Q[145316]][Q[132394]]() : '', window['$iGR']['$iEXDRG'] = ![], window['$iGR']['$iEXGDR'] = 0x2;if (f_mcp1[Q[120115]](Q[149018]) != -0x1) {
      if (c1f_p[Q[129350]] >= 0x18) window['$iGR']['$iEXGDR'] = 0x3;else window['$iGR']['$iEXGDR'] = 0x2;
    } else {
      if (f_mcp1[Q[120115]](Q[149231]) != -0x1) {
        if (c1f_p[Q[129350]] && c1f_p[Q[129350]] >= 0x14) window['$iGR']['$iEXGDR'] = 0x3;else {
          if (e3bs[Q[120115]](Q[149236]) != -0x1 || e3bs[Q[120115]](Q[149237]) != -0x1 || e3bs[Q[120115]](Q[149238]) != -0x1 || e3bs[Q[120115]](Q[149239]) != -0x1 || e3bs[Q[120115]](Q[149240]) != -0x1) window['$iGR']['$iEXGDR'] = 0x2;else window['$iGR']['$iEXGDR'] = 0x3;
        }
      } else window['$iGR']['$iEXGDR'] = 0x2;
    }console[Q[120482]](Q[149241] + window['$iGR']['$iEXDRG'] + Q[149242] + window['$iGR']['$iEXGDR']);
  } }), wx[Q[149243]]({ 'success': function (u5n2) {
    console[Q[120482]](Q[149244] + u5n2[Q[124646]] + Q[149245] + u5n2[Q[149246]]);
  } }), wx[Q[149247]]({ 'success': function (_1fc8) {
    console[Q[120482]](Q[149248] + _1fc8[Q[149249]]);
  } }), wx[Q[149250]]({ 'keepScreenOn': !![] }), wx[Q[149251]](function (ubse) {
  console[Q[120482]](Q[149248] + ubse[Q[149249]] + Q[149252] + ubse[Q[149253]]);
}), wx[Q[130883]](function (c91vm) {
  window['$iDX'] = c91vm, window['$iRXD'] && window['$iDX'] && (console[Q[120078]](Q[149254] + window['$iDX'][Q[120776]]), window['$iRXD'](window['$iDX']), window['$iDX'] = null);
}), window[Q[149255]] = 0x0, window['$iEGDRX'] = 0x0, window[Q[149256]] = null, wx[Q[149257]](function () {
  window['$iEGDRX']++;var nw4xh = Date[Q[120083]]();(window[Q[149255]] == 0x0 || nw4xh - window[Q[149255]] > 0x1d4c0) && (console[Q[120096]](Q[149258]), wx[Q[131950]]());if (window['$iEGDRX'] >= 0x2) {
    window['$iEGDRX'] = 0x0, console[Q[120125]](Q[149259]), wx[Q[149260]]('0', 0x1);if (window['$iGR'] && window['$iGR'][Q[121074]]) window['$iGRX'](Q[149261], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});