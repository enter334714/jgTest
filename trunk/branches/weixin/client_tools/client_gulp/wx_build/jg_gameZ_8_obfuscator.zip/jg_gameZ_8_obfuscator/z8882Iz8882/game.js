var G = wx.$G;
require(G[620000]);