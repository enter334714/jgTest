var G = wx.$G;
import 'z8882Mz888Iz8882.js';