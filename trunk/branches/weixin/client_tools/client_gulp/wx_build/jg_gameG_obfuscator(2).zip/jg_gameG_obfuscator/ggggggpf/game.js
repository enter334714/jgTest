var m = wx.$g;
require('ggggBuff.js'), window[m[27303]][m[27304]][m[27305]] = null, window['client_pb'] = require('gggcleintpb.js'), window[m[24257]] = window[m[27303]][m[24149]][m[24150]](client_pb);