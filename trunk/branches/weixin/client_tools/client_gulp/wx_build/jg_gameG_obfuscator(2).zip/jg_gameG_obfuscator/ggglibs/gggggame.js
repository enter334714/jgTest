var m = wx.$g;
console[m[72]](m[27669]), window[m[27670]], wx[m[27671]](function (e1kwvy) {
  if (e1kwvy) {
    if (e1kwvy[m[4141]]) {
      var u62jr$ = window[m[538]][m[27672]][m[4317]](new RegExp(/\./, 'g'), '_'),
          hyw1ke = e1kwvy[m[4141]],
          v1wyk = hyw1ke[m[11232]](/(gggggggg\/gggggame.js:)[0-9]{1,60}(:)/g);if (v1wyk) for (var $6mrju = 0x0; $6mrju < v1wyk[m[13]]; $6mrju++) {
        if (v1wyk[$6mrju] && v1wyk[$6mrju][m[13]] > 0x0) {
          var yekw7 = parseInt(v1wyk[$6mrju][m[4317]](m[27673], '')[m[4317]](':', ''));hyw1ke = hyw1ke[m[4317]](v1wyk[$6mrju], v1wyk[$6mrju][m[4317]](':' + yekw7 + ':', ':' + (yekw7 - 0x2) + ':'));
        }
      }hyw1ke = hyw1ke[m[4317]](new RegExp(m[27674], 'g'), m[27675] + u62jr$ + m[24216]), hyw1ke = hyw1ke[m[4317]](new RegExp(m[27676], 'g'), m[27675] + u62jr$ + m[24216]), e1kwvy[m[4141]] = hyw1ke;
    }var q7eyv = { 'id': window['G$3J'][m[27677]], 'role': window['G$3J'][m[4261]], 'level': window['G$3J'][m[27678]], 'user': window['G$3J'][m[24120]], 'version': window['G$3J'][m[95]], 'cdn': window['G$3J'][m[4140]], 'pkgName': window['G$3J'][m[24121]], 'gamever': window[m[538]][m[27672]], 'serverid': window['G$3J'][m[24115]] ? window['G$3J'][m[24115]][m[10750]] : 0x0, 'systemInfo': window[m[27679]], 'error': m[27680], 'stack': e1kwvy ? e1kwvy[m[4141]] : '' },
        ge7cq = JSON[m[4126]](q7eyv);console[m[119]](m[27681] + ge7cq), (!window[m[27670]] || window[m[27670]] != q7eyv[m[119]]) && (window[m[27670]] = q7eyv[m[119]], window['G$23'](q7eyv));
  }
});import 'gggmd5min.js';import 'gggzlibs.js';window[m[27682]] = require(m[27683]);import 'gggindex.js';import 'ggglibsmin.js';import 'gggwxmini.js';import 'ggginitmin.js';import 'XingJuBox.js';console[m[72]](m[27684]), console[m[72]](m[27685]), G$230J({ 'title': m[27686] });var gg7yqv = { 'G$V2J30': !![] };new window[m[27687]](gg7yqv), window[m[27687]][m[141]]['G$V03J2']();if (window['G$V23J0']) clearInterval(window['G$V23J0']);window['G$V23J0'] = null, window['G$V0J23'] = function (c78gqs, btfp_) {
  if (!c78gqs || !btfp_) return 0x0;c78gqs = c78gqs[m[15]]('.'), btfp_ = btfp_[m[15]]('.');const ywk1ve = Math[m[811]](c78gqs[m[13]], btfp_[m[13]]);while (c78gqs[m[13]] < ywk1ve) {
    c78gqs[m[29]]('0');
  }while (btfp_[m[13]] < ywk1ve) {
    btfp_[m[29]]('0');
  }for (var gcsvq = 0x0; gcsvq < ywk1ve; gcsvq++) {
    const ozdt34 = parseInt(c78gqs[gcsvq]),
          fto4d3 = parseInt(btfp_[gcsvq]);if (ozdt34 > fto4d3) return 0x1;else {
      if (ozdt34 < fto4d3) return -0x1;
    }
  }return 0x0;
}, window[m[27688]] = wx[m[27689]]()[m[27688]], console[m[465]](m[27690] + window[m[27688]]);var gvyew = wx[m[27691]]();gvyew[m[27692]](function (scqgv7) {
  console[m[465]](m[27693] + scqgv7[m[27694]]);
}), gvyew[m[27695]](function () {
  wx[m[27696]]({ 'title': m[27697], 'content': m[27698], 'showCancel': ![], 'success': function (vw7ke) {
      gvyew[m[27699]]();
    } });
}), gvyew[m[27700]](function () {
  console[m[465]](m[27701]);
}), window['G$V0J32'] = function () {
  console[m[465]](m[27702]);var t0f4_p = wx[m[27703]]({ 'name': m[27704], 'success': function (haibx5) {
      console[m[465]](m[27705]), console[m[465]](haibx5), haibx5 && haibx5[m[24301]] == m[27706] ? (window['G$J0'] = !![], window['G$J032'](), window['G$J320']()) : setTimeout(function () {
        window['G$V0J32']();
      }, 0x1f4);
    }, 'fail': function (yv7w) {
      console[m[465]](m[27707]), console[m[465]](yv7w), setTimeout(function () {
        window['G$V0J32']();
      }, 0x1f4);
    } });t0f4_p && t0f4_p[m[27708]](bihxa => {});
}, window['G$V32J0'] = function () {
  console[m[465]](m[27709]);var qlcs = wx[m[27703]]({ 'name': m[27710], 'success': function (vk1ew) {
      console[m[465]](m[27711]), console[m[465]](vk1ew), vk1ew && vk1ew[m[24301]] == m[27706] ? (window['G$30J'] = !![], window['G$J032'](), window['G$J320']()) : setTimeout(function () {
        window['G$V32J0']();
      }, 0x1f4);
    }, 'fail': function (kahx1) {
      console[m[465]](m[27712]), console[m[465]](kahx1), setTimeout(function () {
        window['G$V32J0']();
      }, 0x1f4);
    } });qlcs && qlcs[m[27708]](kaxhw1 => {});
}, window[m[27713]] = function () {
  window['G$V0J23'](window[m[27688]], m[27714]) >= 0x0 ? (console[m[465]](m[27715] + window[m[27688]] + m[27716]), window['G$32'](), window['G$V0J32'](), window['G$V32J0']()) : (window['G$3J2'](m[27717], window[m[27688]]), wx[m[27696]]({ 'title': m[5932], 'content': m[27718] }));
}, window[m[27679]] = '', wx[m[27719]]({ 'success'(k7yve) {
    window[m[27679]] = m[27720] + k7yve[m[27721]] + m[27722] + k7yve[m[27723]] + m[27724] + k7yve[m[4330]] + m[27725] + k7yve[m[458]] + m[27726] + k7yve[m[24090]] + m[27727] + k7yve[m[27688]] + m[27728] + k7yve[m[8735]], console[m[465]](window[m[27679]]), console[m[465]](m[27729] + k7yve[m[27730]] + m[27731] + k7yve[m[27732]] + m[27733] + k7yve[m[27734]] + m[27735] + k7yve[m[27736]] + m[27737] + k7yve[m[27738]] + m[27739] + k7yve[m[27740]] + m[27741] + (k7yve[m[27742]] ? k7yve[m[27742]][m[311]] + ',' + k7yve[m[27742]][m[1122]] + ',' + k7yve[m[27742]][m[1124]] + ',' + k7yve[m[27742]][m[1123]] : ''));var yq7vew = k7yve[m[458]] ? k7yve[m[458]][m[11507]]() : '',
        gvq7sc = k7yve[m[27723]] ? k7yve[m[27723]][m[11507]]()[m[4317]]('\x20', '') : '';window['G$3J'][m[987]] = yq7vew[m[109]](m[27743]) != -0x1, window['G$3J'][m[10579]] = yq7vew[m[109]](m[27744]) != -0x1, window['G$3J'][m[27745]] = yq7vew[m[109]](m[27743]) != -0x1 || yq7vew[m[109]](m[27744]) != -0x1, window['G$3J'][m[23825]] = yq7vew[m[109]](m[27746]) != -0x1 || yq7vew[m[109]](m[27747]) != -0x1, window['G$3J'][m[27748]] = k7yve[m[24090]] ? k7yve[m[24090]][m[11507]]() : '', window['G$3J']['G$V20J3'] = ![], window['G$3J']['G$V230J'] = 0x2;if (yq7vew[m[109]](m[27744]) != -0x1) {
      if (k7yve[m[8735]] >= 0x18) window['G$3J']['G$V230J'] = 0x3;else window['G$3J']['G$V230J'] = 0x2;
    } else {
      if (yq7vew[m[109]](m[27743]) != -0x1) {
        if (k7yve[m[8735]] && k7yve[m[8735]] >= 0x14) window['G$3J']['G$V230J'] = 0x3;else {
          if (gvq7sc[m[109]](m[27749]) != -0x1 || gvq7sc[m[109]](m[27750]) != -0x1 || gvq7sc[m[109]](m[27751]) != -0x1 || gvq7sc[m[109]](m[27752]) != -0x1 || gvq7sc[m[109]](m[27753]) != -0x1) window['G$3J']['G$V230J'] = 0x2;else window['G$3J']['G$V230J'] = 0x3;
        }
      } else window['G$3J']['G$V230J'] = 0x2;
    }console[m[465]](m[27754] + window['G$3J']['G$V20J3'] + m[27755] + window['G$3J']['G$V230J']);
  } }), wx[m[27756]]({ 'success': function (jrz$62) {
    console[m[465]](m[27757] + jrz$62[m[4237]] + m[27758] + jrz$62[m[27759]]);
  } }), wx[m[27760]]({ 'success': function (eyvkw1) {
    console[m[465]](m[27761] + eyvkw1[m[27762]]);
  } }), wx[m[27763]]({ 'keepScreenOn': !![] }), wx[m[27764]](function (xihba5) {
  console[m[465]](m[27761] + xihba5[m[27762]] + m[27765] + xihba5[m[27766]]);
}), wx[m[10136]](function (lqsc) {
  window['G$02'] = lqsc, window['G$J20'] && window['G$02'] && (console[m[72]](m[27767] + window['G$02'][m[740]]), window['G$J20'](window['G$02']), window['G$02'] = null);
}), window['memoryGCTime'] = 0x0, window['G$V30J2'] = 0x0, window[m[27768]] = null, wx[m[27769]](function () {
  window['G$V30J2']++;var xyh1k = Date[m[77]]();(window['memoryGCTime'] == 0x0 || xyh1k - window['memoryGCTime'] > 0x1d4c0) && (console[m[90]](m[27770]), wx['triggerGC']());if (window['G$V30J2'] >= 0x2) {
    window['G$V30J2'] = 0x0, console[m[119]](m[27771]), wx[m[27772]]('0', 0x1);if (window['G$3J'] && window['G$3J'][m[987]]) window['G$3J2'](m[27773], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});