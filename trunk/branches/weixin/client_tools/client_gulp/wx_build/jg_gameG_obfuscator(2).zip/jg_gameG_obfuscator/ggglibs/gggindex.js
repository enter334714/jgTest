var m = wx.$g;
import gb50ap from '../gggsdk/gggsdk.js';window[m[27774]] = { 'wxVersion': window[m[538]][m[27672]] }, window['DEBUG'] = ![], window['G$J3'] = 0x1, window[m[27775]] = 0x1, window['G$03J'] = !![], window[m[27776]] = !![], window['G$V203J'] = '', window['G$3J'] = { 'base_cdn': m[27777], 'cdn': m[27777] }, G$3J[m[27778]] = {}, G$3J[m[23823]] = '0', G$3J[m[4330]] = window[m[27774]][m[27779]], G$3J[m[27747]] = '', G$3J['os'] = '1', G$3J[m[27780]] = m[27781], G$3J[m[27782]] = m[27783], G$3J[m[27784]] = m[27785], G$3J[m[27786]] = m[27787], G$3J[m[27788]] = 'MQx0mYlUWO5XYKvgAIPKWgK1w722GKih', G$3J[m[22577]] = '1', G$3J[m[24121]] = '', G$3J[m[24123]] = '', G$3J[m[27789]] = 0x0, G$3J[m[27790]] = {}, G$3J[m[27791]] = parseInt(G$3J[m[22577]]), G$3J[m[24119]] = G$3J[m[22577]], G$3J[m[24115]] = {}, G$3J['G$23'] = m[27792], G$3J[m[27793]] = ![], G$3J[m[11419]] = m[27794], G$3J[m[24092]] = Date[m[77]](), G$3J[m[11036]] = m[27795], G$3J[m[693]] = '_a', G$3J[m[27796]] = 0x2, G$3J[m[95]] = 0x7c1, G$3J[m[27779]] = window[m[27774]][m[27779]], G$3J[m[707]] = ![], G$3J[m[987]] = ![], G$3J[m[10579]] = ![], G$3J[m[23825]] = ![], window['G$0J3'] = 0x5, window['G$0J'] = ![], window['G$J0'] = ![], window['G$30J'] = ![], window[m[27797]] = ![], window[m[27798]] = ![], window['G$3J0'] = ![], window['G$03'] = ![], window['G$30'] = ![], window['G$J03'] = ![], window[m[27799]] = {}, window[m[3808]] = function (rz26d) {
  console[m[465]](m[3808], rz26d), wx[m[4598]]({}), wx[m[27696]]({ 'title': m[5932], 'content': rz26d, 'success'(ehyw1k) {
      if (ehyw1k[m[27800]]) console[m[465]](m[27801]);else ehyw1k[m[534]] && console[m[465]](m[27802]);
    } });
}, window['G$203J'] = function (j62r$z) {
  console[m[465]](m[27803], j62r$z), G$23J0(), wx[m[27696]]({ 'title': m[5932], 'content': j62r$z, 'confirmText': m[27804], 'cancelText': m[17569], 'success'(bxhia5) {
      if (bxhia5[m[27800]]) window['G$32']();else bxhia5[m[534]] && (console[m[465]](m[27805]), wx[m[24274]]({}));
    } });
}, window['G$3V'] = function (kxaih) {
  console[m[465]](m[27806], kxaih), wx[m[27696]]({ 'title': m[5932], 'content': kxaih, 'confirmText': m[24247], 'showCancel': ![], 'complete'(gsl8q) {
      console[m[465]](m[27805]), wx[m[24274]]({});
    } });
}, window['G$20J3'] = ![], window['G$230J'] = function (f4_t03) {
  window['G$20J3'] = !![], wx[m[4597]](f4_t03);
}, window['G$23J0'] = function () {
  window['G$20J3'] && (window['G$20J3'] = ![], wx[m[4598]]({}));
}, window['G$2J03'] = function (d3z4o2) {
  window[m[27687]][m[141]]['G$2J03'](d3z4o2);
}, window[m[11303]] = function (vq7, _0tpfb) {
  gb50ap[m[11303]](vq7, function (o4dz3t) {
    o4dz3t && o4dz3t[m[11]] ? o4dz3t[m[11]][m[3743]] == 0x1 ? _0tpfb(!![]) : (_0tpfb(![]), console[m[72]](m[27807] + o4dz3t[m[11]][m[27808]])) : console[m[465]](m[11303], o4dz3t);
  });
}, window['G$2J30'] = function (ecvg) {
  console[m[465]](m[27809], ecvg);
}, window['G$23J'] = function (bxap) {}, window['G$2J3'] = function (y1wvek, yqe7w, w1hkxy) {}, window['G$2J'] = function (odz34) {
  console[m[465]]('toEnterGame', odz34), window[m[27687]][m[141]][m[27810]](), window[m[27687]][m[141]][m[27811]](), window[m[27687]][m[141]][m[27812]]();
}, window['G$J2'] = function (s89l) {
  window['G$203J'](m[27813]);var fb_5p0 = { 'id': window['G$3J'][m[27677]], 'role': window['G$3J'][m[4261]], 'level': window['G$3J'][m[27678]], 'account': window['G$3J'][m[24120]], 'version': window['G$3J'][m[95]], 'cdn': window['G$3J'][m[4140]], 'pkgName': window['G$3J'][m[24121]], 'gamever': window[m[538]][m[27672]], 'serverid': window['G$3J'][m[24115]] ? window['G$3J'][m[24115]][m[10750]] : 0x0, 'systemInfo': window[m[27679]], 'error': m[27814], 'stack': s89l ? s89l : m[27813] },
      b0aip = JSON[m[4126]](fb_5p0);console[m[119]](m[27815] + b0aip), window['G$23'](b0aip);
}, window['G$32J'] = function (ywvk) {
  var kwyxh = JSON[m[510]](ywvk);kwyxh[m[27816]] = window[m[538]][m[27672]], kwyxh[m[27817]] = window['G$3J'][m[24115]] ? window['G$3J'][m[24115]][m[10750]] : 0x0, kwyxh[m[27679]] = window[m[27679]];var rm$6uj = JSON[m[4126]](kwyxh);console[m[119]](m[27818] + rm$6uj), window['G$23'](rm$6uj);
}, window['G$3J2'] = function (p05i_, c7eq) {
  var tf_40p = { 'id': window['G$3J'][m[27677]], 'role': window['G$3J'][m[4261]], 'level': window['G$3J'][m[27678]], 'account': window['G$3J'][m[24120]], 'version': window['G$3J'][m[95]], 'cdn': window['G$3J'][m[4140]], 'pkgName': window['G$3J'][m[24121]], 'gamever': window[m[538]][m[27672]], 'serverid': window['G$3J'][m[24115]] ? window['G$3J'][m[24115]][m[10750]] : 0x0, 'systemInfo': window[m[27679]], 'error': p05i_, 'stack': c7eq },
      xh1yk = JSON[m[4126]](tf_40p);console[m[90]](m[27819] + xh1yk), window['G$23'](xh1yk);
}, window['G$23'] = function (xkahi) {
  if (window['G$3J'][m[27748]] == m[27820]) return;var f0bpt_ = G$3J['G$23'] + m[27821] + G$3J[m[24120]];wx[m[460]]({ 'url': f0bpt_, 'method': m[27822], 'data': xkahi, 'header': { 'content-type': m[27823], 'cache-control': m[27824] }, 'success': function (a5hix1) {
      DEBUG && console[m[465]](m[27825], f0bpt_, xkahi, a5hix1);
    }, 'fail': function (ix5h1) {
      DEBUG && console[m[465]](m[27825], f0bpt_, xkahi, ix5h1);
    }, 'complete': function () {} });
}, window[m[27826]] = function () {
  function _otf4() {
    return ((0x1 + Math[m[113]]()) * 0x10000 | 0x0)[m[263]](0x10)[m[483]](0x1);
  }return _otf4() + _otf4() + '-' + _otf4() + '-' + _otf4() + '-' + _otf4() + '+' + _otf4() + _otf4() + _otf4();
}, window['G$32'] = function () {
  console[m[465]](m[27827]);var sqgcv = gb50ap[m[27828]]();G$3J[m[24119]] = sqgcv[m[27829]], G$3J[m[27791]] = sqgcv[m[27829]], G$3J[m[22577]] = sqgcv[m[27829]], G$3J[m[24121]] = sqgcv[m[27830]];var v7yqg = { 'game_ver': G$3J[m[4330]] };G$3J[m[24123]] = this[m[27826]](), G$230J({ 'title': m[27831] }), gb50ap[m[357]](v7yqg, this['G$J23'][m[68]](this));
}, window['G$J23'] = function (cg7q8) {
  var i_p50b = cg7q8[m[27832]];sdk_info = cg7q8, console[m[465]](m[27833] + i_p50b + m[27834] + (i_p50b == 0x1) + m[27835] + cg7q8[m[27672]] + m[27836] + window[m[27774]][m[27779]]);if (!cg7q8[m[27672]] || window['G$V0J23'](window[m[27774]][m[27779]], cg7q8[m[27672]]) < 0x0) console[m[465]](m[27837]), G$3J[m[27782]] = m[27838], G$3J[m[27784]] = m[27839], G$3J[m[27786]] = m[27840], G$3J[m[4140]] = m[27841], G$3J[m[23822]] = m[27842], G$3J[m[27843]] = 'ws', G$3J[m[707]] = ![];else window['G$V0J23'](window[m[27774]][m[27779]], cg7q8[m[27672]]) == 0x0 ? (console[m[465]](m[27844]), G$3J[m[27782]] = m[27783], G$3J[m[27784]] = m[27785], G$3J[m[27786]] = m[27787], G$3J[m[4140]] = m[27845], G$3J[m[23822]] = m[27842], G$3J[m[27843]] = m[27846], G$3J[m[707]] = !![]) : (console[m[465]](m[27847]), G$3J[m[27782]] = m[27783], G$3J[m[27784]] = m[27785], G$3J[m[27786]] = m[27787], G$3J[m[4140]] = m[27845], G$3J[m[23822]] = m[27842], G$3J[m[27843]] = m[27846], G$3J[m[707]] = ![]);G$3J[m[27789]] = config[m[27552]] ? config[m[27552]] : 0x0, this['G$032J'](), this['G$03J2'](), window[m[27848]] = 0x5, G$230J({ 'title': m[27849] }), gb50ap[m[27850]](this['G$J32'][m[68]](this));
}, window[m[27848]] = 0x5, window['G$J32'] = function (scq7gv, f_40t) {
  if (scq7gv == 0x0 && f_40t && f_40t[m[27643]]) {
    G$3J[m[27851]] = f_40t[m[27643]], G$3J[m[27852]] = f_40t[m[27852]];var cqs7vg = this;G$230J({ 'title': m[27853] }), sendApi(G$3J[m[27782]], m[27854], { 'platform': G$3J[m[27780]], 'partner_id': G$3J[m[22577]], 'token': f_40t[m[27643]], 'game_pkg': G$3J[m[24121]], 'deviceId': G$3J[m[24123]], 'scene': m[27855] + G$3J[m[27789]] }, this['G$023J'][m[68]](this), G$0J3, G$J2);
  } else f_40t && f_40t[m[24301]] && window[m[27848]] > 0x0 && (f_40t[m[24301]][m[109]](m[27856]) != -0x1 || f_40t[m[24301]][m[109]](m[27857]) != -0x1 || f_40t[m[24301]][m[109]](m[27858]) != -0x1 || f_40t[m[24301]][m[109]](m[27859]) != -0x1 || f_40t[m[24301]][m[109]](m[27860]) != -0x1 || f_40t[m[24301]][m[109]](m[27861]) != -0x1) ? (window[m[27848]]--, gb50ap[m[27850]](this['G$J32'][m[68]](this))) : (window['G$3J2'](m[27862], JSON[m[4126]]({ 'status': scq7gv, 'data': f_40t })), window['G$203J'](m[27863] + (f_40t && f_40t[m[24301]] ? '，' + f_40t[m[24301]] : '')));
}, window['G$023J'] = function (sgvcq) {
  if (!sgvcq) {
    window['G$3J2'](m[27864], m[27865]), window['G$203J'](m[27866]);return;
  }if (sgvcq[m[3743]] != m[9283]) {
    window['G$3J2'](m[27864], JSON[m[4126]](sgvcq)), window['G$203J'](m[27867] + sgvcq[m[3743]]);return;
  }G$3J[m[22576]] = String(sgvcq[m[24120]]), G$3J[m[24120]] = String(sgvcq[m[24120]]), G$3J[m[24090]] = String(sgvcq[m[24090]]), G$3J[m[24119]] = String(sgvcq[m[24090]]), G$3J[m[24122]] = String(sgvcq[m[24122]]), G$3J[m[27868]] = String(sgvcq[m[10735]]), G$3J[m[27869]] = String(sgvcq[m[809]]), G$3J[m[10735]] = '';var qsgcl = this;G$230J({ 'title': m[27870] }), sendApi(G$3J[m[27782]], m[27871], { 'partner_id': G$3J[m[22577]], 'uid': G$3J[m[24120]], 'version': G$3J[m[4330]], 'game_pkg': G$3J[m[24121]], 'device': G$3J[m[24123]] }, qsgcl['G$02J3'][m[68]](qsgcl), G$0J3, G$J2);
}, window['G$02J3'] = function (p5_bf0) {
  if (!p5_bf0) {
    window['G$203J'](m[27872]);return;
  }if (p5_bf0[m[3743]] != m[9283]) {
    window['G$203J'](m[27873] + p5_bf0[m[3743]]);return;
  }if (!p5_bf0[m[11]] || p5_bf0[m[11]][m[13]] == 0x0) {
    window['G$203J'](m[27874]);return;
  }G$3J[m[611]] = p5_bf0[m[27875]], G$3J[m[24115]] = { 'server_id': String(p5_bf0[m[11]][0x0][m[10750]]), 'server_name': String(p5_bf0[m[11]][0x0][m[27876]]), 'entry_ip': p5_bf0[m[11]][0x0][m[24143]], 'entry_port': parseInt(p5_bf0[m[11]][0x0][m[24144]]), 'status': G$302(p5_bf0[m[11]][0x0]), 'start_time': p5_bf0[m[11]][0x0][m[27877]], 'cdn': G$3J[m[4140]] }, this['G$J302']();
}, window['G$J302'] = function () {
  if (G$3J[m[611]] == 0x1) {
    var oz2d4 = G$3J[m[24115]][m[100]];if (oz2d4 === -0x1 || oz2d4 === 0x0) {
      window['G$203J'](oz2d4 === -0x1 ? m[27878] : m[27879]);return;
    }G$J203(0x0, G$3J[m[24115]][m[10750]]), window[m[27687]][m[141]][m[27880]](G$3J[m[611]]);
  } else window[m[27687]][m[141]][m[27881]](), G$23J0();window['G$30'] = !![], window['G$J032'](), window['G$J320']();
}, window['G$032J'] = function () {
  sendApi(G$3J[m[27782]], m[27882], { 'game_pkg': G$3J[m[24121]], 'version_name': G$3J[m[27843]] }, this[m[27883]][m[68]](this), G$0J3, G$J2);
}, window[m[27883]] = function (t43doz) {
  if (!t43doz) {
    window['G$203J'](m[27884]);return;
  }if (t43doz[m[3743]] != m[9283]) {
    window['G$203J'](m[27885] + t43doz[m[3743]]);return;
  }if (!t43doz[m[11]] || !t43doz[m[11]][m[4330]]) {
    window['G$203J'](m[27886] + (t43doz[m[11]] && t43doz[m[11]][m[4330]]));return;
  }t43doz[m[11]][m[27887]] && t43doz[m[11]][m[27887]][m[13]] > 0xa && (G$3J[m[27888]] = t43doz[m[11]][m[27887]], G$3J[m[4140]] = t43doz[m[11]][m[27887]]), t43doz[m[11]][m[4330]] && (G$3J[m[95]] = t43doz[m[11]][m[4330]]), console[m[72]](m[24253] + G$3J[m[95]] + m[27889] + G$3J[m[27843]]), window['G$3J0'] = !![], window['G$J032'](), window['G$J320']();
}, window[m[27890]], window['G$03J2'] = function () {
  sendApi(G$3J[m[27782]], m[27891], { 'game_pkg': G$3J[m[24121]] }, this['G$0J23'][m[68]](this), G$0J3, G$J2);
}, window['G$0J23'] = function (qy7egv) {
  if (qy7egv[m[3743]] === m[9283] && qy7egv[m[11]]) {
    window[m[27890]] = qy7egv[m[11]];for (var pft_b in qy7egv[m[11]]) {
      G$3J[pft_b] = qy7egv[m[11]][pft_b];
    }
  } else console[m[72]](m[27892] + qy7egv[m[3743]]);window['G$03'] = !![], window['G$J320']();
}, window[m[27893]] = function (xawk, hk1wax, i5b0a, yg7q, b_t0f, bax5, xwkhy1, t_3f04, _f0pb5) {
  b_t0f = String(b_t0f);var x5aib = xwkhy1,
      v1eykw = t_3f04;G$3J[m[27778]][b_t0f] = { 'productid': b_t0f, 'productname': x5aib, 'productdesc': v1eykw, 'roleid': xawk, 'rolename': hk1wax, 'rolelevel': i5b0a, 'price': bax5, 'callback': _f0pb5 }, sendApi(G$3J[m[27786]], m[27894], { 'game_pkg': G$3J[m[24121]], 'server_id': G$3J[m[24115]][m[10750]], 'server_name': G$3J[m[24115]][m[27876]], 'level': i5b0a, 'uid': G$3J[m[24120]], 'role_id': xawk, 'role_name': hk1wax, 'product_id': b_t0f, 'product_name': x5aib, 'product_desc': v1eykw, 'money': bax5, 'partner_id': G$3J[m[22577]] }, toPayCallBack, G$0J3, G$J2);
}, window[m[27895]] = function (pib50) {
  if (pib50) {
    if (pib50[m[27896]] === 0xc8 || pib50[m[3743]] == m[9283]) {
      var scg9l8 = G$3J[m[27778]][String(pib50[m[27897]])];if (scg9l8[m[323]]) scg9l8[m[323]](pib50[m[27897]], pib50[m[27898]], -0x1);gb50ap[m[27899]]({ 'cpbill': pib50[m[27898]], 'productid': pib50[m[27897]], 'productname': scg9l8[m[27900]], 'productdesc': scg9l8[m[27901]], 'serverid': G$3J[m[24115]][m[10750]], 'servername': G$3J[m[24115]][m[27876]], 'roleid': scg9l8[m[27902]], 'rolename': scg9l8[m[27903]], 'rolelevel': scg9l8[m[27904]], 'price': scg9l8[m[25796]], 'extension': JSON[m[4126]]({ 'cp_order_id': pib50[m[27898]] }) }, function (qc7svg, jmr6u$) {
        scg9l8[m[323]] && qc7svg == 0x0 && scg9l8[m[323]](pib50[m[27897]], pib50[m[27898]], qc7svg);console[m[72]](JSON[m[4126]]({ 'type': m[27905], 'status': qc7svg, 'data': pib50, 'role_name': scg9l8[m[27903]] }));if (qc7svg === 0x0) {} else {
          if (qc7svg === 0x1) {} else {
            if (qc7svg === 0x2) {}
          }
        }
      });
    } else alert(pib50[m[72]]);
  }
}, window['G$0J32'] = function () {}, window['G$20J'] = function (c89l, f0t43_, wk1vey, p_5f, wehy1k) {
  gb50ap[m[27906]](G$3J[m[24115]][m[10750]], G$3J[m[24115]][m[27876]] || G$3J[m[24115]][m[10750]], c89l, f0t43_, wk1vey), sendApi(G$3J[m[27782]], m[27907], { 'game_pkg': G$3J[m[24121]], 'server_id': G$3J[m[24115]][m[10750]], 'role_id': c89l, 'uid': G$3J[m[24120]], 'role_name': f0t43_, 'role_type': p_5f, 'level': wk1vey });
}, window['G$2J0'] = function (yvw7eq, ia50p, ru$62j, vqec7g, t04p_, hxwky1, qcv7eg, ykv7, ahxk1w, _pb50) {
  G$3J[m[27677]] = yvw7eq, G$3J[m[4261]] = ia50p, G$3J[m[27678]] = ru$62j, gb50ap['logEnterGame'](G$3J[m[24115]][m[10750]], G$3J[m[24115]][m[27876]] || G$3J[m[24115]][m[10750]], yvw7eq, ia50p, ru$62j, hxwky1, { 'rolepower': qcv7eg }), sendApi(G$3J[m[27782]], m[27908], { 'game_pkg': G$3J[m[24121]], 'server_id': G$3J[m[24115]][m[10750]], 'role_id': yvw7eq, 'uid': G$3J[m[24120]], 'role_name': ia50p, 'role_type': vqec7g, 'level': ru$62j, 'evolution': t04p_ });
}, window['G$02J'] = function (u62r, i5xp, abp5x, ofd4t3, t034f, v7k, pf0_t4, r$26uj, iahxb5, slcg8) {
  G$3J[m[27677]] = u62r, G$3J[m[4261]] = i5xp, G$3J[m[27678]] = abp5x, gb50ap[m[27909]](G$3J[m[24115]][m[10750]], G$3J[m[24115]][m[27876]] || G$3J[m[24115]][m[10750]], u62r, i5xp, abp5x), sendApi(G$3J[m[27782]], m[27908], { 'game_pkg': G$3J[m[24121]], 'server_id': G$3J[m[24115]][m[10750]], 'role_id': u62r, 'uid': G$3J[m[24120]], 'role_name': i5xp, 'role_type': ofd4t3, 'level': abp5x, 'evolution': t034f });
}, window['G$0J2'] = function (yk1vwe) {}, window['G$20'] = function (s87cg) {
  gb50ap[m[27910]](m[27910], function (_0ft34) {
    s87cg && s87cg(_0ft34);
  });
}, window[m[23806]] = function () {
  gb50ap[m[27911]](G$3J[m[24115]][m[10750]], G$3J[m[24115]][m[27876]] || G$3J[m[24115]][m[10750]], G$3J[m[27677]], G$3J[m[4261]], G$3J[m[27678]]);
}, window['microPortGuide'] = function () {
  gb50ap[m[22479]]();
}, window[m[10136]] = function (wqye7v) {
  window['G$J20'] = wqye7v, window['G$J20'] && window['G$02'] && (console[m[72]](m[27767] + window['G$02'][m[740]]), window['G$J20'](window['G$02']), window['G$02'] = null);
}, window['G$J02'] = function (vgce7q, $rj26z, d4t3oz, zr2o6d) {
  window[m[22]](m[27912], { 'game_pkg': window['G$3J'][m[24121]], 'role_id': $rj26z, 'server_id': d4t3oz }, zr2o6d);
}, window['G$320J'] = function (g8lq, dr6zj2) {
  function _ptf0(ft3d4o) {
    var wky7ev = [],
        _fp0t4 = [],
        qeg7yv = window[m[538]][m[27913]];for (var xa5ih1 in qeg7yv) {
      var r2ozd6 = Number(xa5ih1);(!g8lq || !g8lq[m[13]] || g8lq[m[109]](r2ozd6) != -0x1) && (_fp0t4[m[29]](qeg7yv[xa5ih1]), wky7ev[m[29]]([r2ozd6, 0x3]));
    }window['G$V0J23'](window[m[27688]], m[27914]) >= 0x0 ? (console[m[465]](m[27915]), gb50ap[m[27916]] && gb50ap[m[27916]](_fp0t4, function (j6$2zr) {
      console[m[465]](m[27917]), console[m[465]](j6$2zr);if (j6$2zr && j6$2zr[m[24301]] == m[27918]) for (var jru6m in qeg7yv) {
        if (j6$2zr[qeg7yv[jru6m]] == m[27919]) {
          var hx51i = Number(jru6m);for (var o_3 = 0x0; o_3 < wky7ev[m[13]]; o_3++) {
            if (wky7ev[o_3][0x0] == hx51i) {
              wky7ev[o_3][0x1] = 0x1;break;
            }
          }
        }
      }window['G$V0J23'](window[m[27688]], m[27920]) >= 0x0 ? wx[m[27921]]({ 'withSubscriptions': !![], 'success': function (api50) {
          var gl9c8s = api50[m[27922]][m[27923]];if (gl9c8s) {
            console[m[465]](m[27924]), console[m[465]](gl9c8s);for (var ibp_5 in qeg7yv) {
              if (gl9c8s[qeg7yv[ibp_5]] == m[27919]) {
                var i5x1ha = Number(ibp_5);for (var bfpt = 0x0; bfpt < wky7ev[m[13]]; bfpt++) {
                  if (wky7ev[bfpt][0x0] == i5x1ha) {
                    wky7ev[bfpt][0x1] = 0x2;break;
                  }
                }
              }
            }console[m[465]](wky7ev), dr6zj2 && dr6zj2(wky7ev);
          } else console[m[465]](m[27925]), console[m[465]](api50), console[m[465]](wky7ev), dr6zj2 && dr6zj2(wky7ev);
        }, 'fail': function () {
          console[m[465]](m[27926]), console[m[465]](wky7ev), dr6zj2 && dr6zj2(wky7ev);
        } }) : (console[m[465]](m[27927] + window[m[27688]]), console[m[465]](wky7ev), dr6zj2 && dr6zj2(wky7ev));
    })) : (console[m[465]](m[27928] + window[m[27688]]), console[m[465]](wky7ev), dr6zj2 && dr6zj2(wky7ev)), wx[m[27929]](_ptf0);
  }wx[m[27930]](_ptf0);
}, window['G$32J0'] = { 'isSuccess': ![], 'level': m[27931], 'isCharging': ![] }, window['G$302J'] = function (tfp0_4) {
  wx[m[27756]]({ 'success': function (w1yvke) {
      var cg8q7s = window['G$32J0'];cg8q7s[m[27932]] = !![], cg8q7s[m[4237]] = Number(w1yvke[m[4237]])[m[3853]](0x0), cg8q7s[m[27759]] = w1yvke[m[27759]], tfp0_4 && tfp0_4(cg8q7s[m[27932]], cg8q7s[m[4237]], cg8q7s[m[27759]]);
    }, 'fail': function (d3to) {
      console[m[465]](m[27933], d3to[m[24301]]);var vyeq7g = window['G$32J0'];tfp0_4 && tfp0_4(vyeq7g[m[27932]], vyeq7g[m[4237]], vyeq7g[m[27759]]);
    } });
}, window[m[22]] = function (qy7, we1yk, d6jrz, xihak, m$rju, vsq7, _p0bi, fp40_t) {
  if (xihak == undefined) xihak = 0x1;wx[m[460]]({ 'url': qy7, 'method': _p0bi || 'GET', 'responseType': m[4046], 'data': we1yk, 'header': { 'content-type': fp40_t || m[27823] }, 'success': function (dzt4o3) {
      DEBUG && console[m[465]](m[27934], qy7, info, dzt4o3);if (dzt4o3 && dzt4o3[m[24367]] == 0xc8) {
        var v7gqce = dzt4o3[m[11]];!vsq7 || vsq7(v7gqce) ? d6jrz && d6jrz(v7gqce) : window[m[27935]](qy7, we1yk, d6jrz, xihak, m$rju, vsq7, dzt4o3);
      } else window[m[27935]](qy7, we1yk, d6jrz, xihak, m$rju, vsq7, dzt4o3);
    }, 'fail': function (ewk1vy) {
      DEBUG && console[m[465]](m[27936], qy7, info, ewk1vy), window[m[27935]](qy7, we1yk, d6jrz, xihak, m$rju, vsq7, ewk1vy);
    }, 'complete': function () {} });
}, window[m[27935]] = function (wvy7ek, yekv, tofd4, evqc7, hxi1a5, _p5b0f, ey1k) {
  evqc7 - 0x1 > 0x0 ? setTimeout(function () {
    window[m[22]](wvy7ek, yekv, tofd4, evqc7 - 0x1, hxi1a5, _p5b0f);
  }, 0x3e8) : hxi1a5 && hxi1a5(JSON[m[4126]]({ 'url': wvy7ek, 'response': ey1k }));
}, window[m[27937]] = function (j6z$2, fo34t, u26rj, fb0p_t, xik1a, z26dr, j6rdz) {
  !u26rj && (u26rj = {});var ywkeh1 = Math[m[112]](Date[m[77]]() / 0x3e8);u26rj[m[809]] = ywkeh1, u26rj[m[23933]] = fo34t;var ipa5 = Object[m[256]](u26rj)[m[991]](),
      s8ql = '',
      dz26or = '';for (var ev7cgq = 0x0; ev7cgq < ipa5[m[13]]; ev7cgq++) {
    s8ql = s8ql + (ev7cgq == 0x0 ? '' : '&') + ipa5[ev7cgq] + u26rj[ipa5[ev7cgq]], dz26or = dz26or + (ev7cgq == 0x0 ? '' : '&') + ipa5[ev7cgq] + '=' + encodeURIComponent(u26rj[ipa5[ev7cgq]]);
  }s8ql = s8ql + G$3J[m[27788]];var t0bf = m[27938] + md5(s8ql);send(j6z$2 + '?' + dz26or + (dz26or == '' ? '' : '&') + t0bf, null, fb0p_t, xik1a, z26dr, j6rdz || function (i1hxk) {
    return i1hxk[m[3743]] == m[9283];
  }, null, m[27939]);
}, window['G$30J2'] = function (iba5, z23do4) {
  var g7q8 = 0x0;G$3J[m[24115]] && (g7q8 = G$3J[m[24115]][m[10750]]), sendApi(G$3J[m[27784]], m[27940], { 'partnerId': G$3J[m[22577]], 'gamePkg': G$3J[m[24121]], 'logTime': Math[m[112]](Date[m[77]]() / 0x3e8), 'platformUid': G$3J[m[24122]], 'type': iba5, 'serverId': g7q8 }, null, 0x2, null, function () {
    return !![];
  });
}, window['G$3J20'] = function (k1h) {
  sendApi(G$3J[m[27782]], 'Server.getServerGroup', { 'partner_id': G$3J[m[22577]], 'uid': G$3J[m[24120]], 'version': G$3J[m[4330]], 'game_pkg': G$3J[m[24121]], 'device': G$3J[m[24123]] }, G$3J02, G$0J3, G$J2);
}, window['G$3J02'] = function (to3f4) {
  if (to3f4[m[3743]] === m[9283] && to3f4[m[11]]) {
    to3f4[m[11]][m[5183]]({ 'id': -0x2, 'name': m[27941] }), to3f4[m[11]][m[5183]]({ 'id': -0x1, 'name': m[27942] }), G$3J[m[27943]] = to3f4[m[11]];if (window[m[11462]]) window[m[11462]]['showGroupList']();
  } else G$3J['hasGroupReq'] = ![], window['G$203J']('reqServerGroupCallBack ' + to3f4[m[3743]]);
}, window['G$203'] = function (vcqsg7) {
  sendApi(G$3J[m[27782]], m[27944], { 'partner_id': G$3J[m[22577]], 'uid': G$3J[m[24120]], 'version': G$3J[m[4330]], 'game_pkg': G$3J[m[24121]], 'device': G$3J[m[24123]] }, G$230, G$0J3, G$J2);
}, window['G$230'] = function (j2u) {
  G$3J[m[27945]] = ![];if (j2u[m[3743]] === m[9283] && j2u[m[11]]) {
    for (var csvq7 = 0x0; csvq7 < j2u[m[11]][m[13]]; csvq7++) {
      j2u[m[11]][csvq7][m[100]] = G$302(j2u[m[11]][csvq7]);
    }G$3J[m[27790]][-0x1] = window[m[27946]](j2u[m[11]]), window[m[11462]][m[27947]](-0x1);
  } else window['G$203J'](m[27948] + j2u[m[3743]]);
}, window[m[27949]] = function ($uj6mr) {
  sendApi(G$3J[m[27782]], m[27944], { 'partner_id': G$3J[m[22577]], 'uid': G$3J[m[24120]], 'version': G$3J[m[4330]], 'game_pkg': G$3J[m[24121]], 'device': G$3J[m[24123]] }, $uj6mr, G$0J3, G$J2);
}, window['G$023'] = function (x1ahik, qvyg) {
  sendApi(G$3J[m[27782]], 'Server.getServerByGroup', { 'partner_id': G$3J[m[22577]], 'uid': G$3J[m[24120]], 'version': G$3J[m[4330]], 'game_pkg': G$3J[m[24121]], 'device': G$3J[m[24123]], 'server_group_id': qvyg }, G$032, G$0J3, G$J2);
}, window['G$032'] = function (xp5b) {
  G$3J[m[27945]] = ![];if (xp5b[m[3743]] === m[9283] && xp5b[m[11]] && xp5b[m[11]][m[11]]) {
    var h5ai1 = xp5b[m[11]][m[27950]],
        tdof43 = [];for (var qs8c7 = 0x0; qs8c7 < xp5b[m[11]][m[11]][m[13]]; qs8c7++) {
      xp5b[m[11]][m[11]][qs8c7][m[100]] = G$302(xp5b[m[11]][m[11]][qs8c7]), (tdof43[m[13]] == 0x0 || xp5b[m[11]][m[11]][qs8c7][m[100]] != 0x0) && (tdof43[tdof43[m[13]]] = xp5b[m[11]][m[11]][qs8c7]);
    }G$3J[m[27790]][h5ai1] = window[m[27946]](tdof43), window[m[11462]][m[27947]](h5ai1);
  } else window['G$203J'](m[27951] + xp5b[m[3743]]);
}, window['G$V0J3'] = function (g7sv) {
  sendApi(G$3J[m[27782]], m[27952], { 'partner_id': G$3J[m[22577]], 'uid': G$3J[m[24120]], 'version': G$3J[m[4330]], 'game_pkg': G$3J[m[24121]], 'device': G$3J[m[24123]] }, reqServerRecommendCallBack, G$0J3, G$J2);
}, window[m[27953]] = function (b0f_t) {
  G$3J[m[27945]] = ![];if (b0f_t[m[3743]] === m[9283] && b0f_t[m[11]]) {
    for (var y1hkew = 0x0; y1hkew < b0f_t[m[11]][m[13]]; y1hkew++) {
      b0f_t[m[11]][y1hkew][m[100]] = G$302(b0f_t[m[11]][y1hkew]);
    }G$3J[m[27790]][-0x2] = window[m[27946]](b0f_t[m[11]]), window[m[11462]][m[27947]](-0x2);
  } else alert(m[27954] + b0f_t[m[3743]]);
}, window[m[27946]] = function (haixb) {
  if (!haixb && haixb[m[13]] <= 0x0) return haixb;for (let bip0_ = 0x0; bip0_ < haixb[m[13]]; bip0_++) {
    haixb[bip0_][m[27955]] && haixb[bip0_][m[27955]] == 0x1 && (haixb[bip0_][m[27876]] += m[27956]);
  }return haixb;
}, window['G$320'] = function (f_04tp, abpxi) {
  f_04tp = f_04tp || G$3J[m[24115]][m[10750]], sendApi(G$3J[m[27782]], m[27957], { 'type': '4', 'game_pkg': G$3J[m[24121]], 'server_id': f_04tp }, abpxi);
}, window[m[27958]] = function (to3d4f, ibp5_0, qgs7c, o62z) {
  qgs7c = qgs7c || G$3J[m[24115]][m[10750]], sendApi(G$3J[m[27782]], m[27959], { 'type': to3d4f, 'game_pkg': ibp5_0, 'server_id': qgs7c }, o62z);
}, window['G$302'] = function (cveqg) {
  if (cveqg) {
    if (cveqg[m[100]] == 0x1) {
      if (cveqg[m[27960]] == 0x1) return 0x2;else return 0x1;
    } else return cveqg[m[100]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['G$J203'] = function ($6rmu, h1kaix) {
  G$3J[m[27961]] = { 'step': $6rmu, 'server_id': h1kaix };var _5pf0 = this;G$230J({ 'title': m[27962] }), sendApi(G$3J[m[27782]], m[27963], { 'partner_id': G$3J[m[22577]], 'uid': G$3J[m[24120]], 'game_pkg': G$3J[m[24121]], 'server_id': h1kaix, 'platform': G$3J[m[24090]], 'platform_uid': G$3J[m[24122]], 'check_login_time': G$3J[m[27869]], 'check_login_sign': G$3J[m[27868]], 'version_name': G$3J[m[27843]] }, G$J230, G$0J3, G$J2, function (hwkax1) {
    return hwkax1[m[3743]] == m[9283] || hwkax1[m[72]] == m[27964] || hwkax1[m[72]] == m[27965];
  });
}, window['G$J230'] = function (kev) {
  var g7ecqv = this;if (kev[m[3743]] === m[9283] && kev[m[11]]) {
    var dfot4 = G$3J[m[24115]];dfot4[m[27966]] = G$3J[m[27791]], dfot4[m[10735]] = String(kev[m[11]][m[27967]]), dfot4[m[24092]] = parseInt(kev[m[11]][m[809]]);if (kev[m[11]][m[24091]]) dfot4[m[24091]] = parseInt(kev[m[11]][m[24091]]);else dfot4[m[24091]] = parseInt(kev[m[11]][m[10750]]);dfot4[m[27968]] = 0x0, dfot4[m[4140]] = G$3J[m[27888]], dfot4[m[27969]] = kev[m[11]][m[27970]], dfot4[m[27971]] = kev[m[11]][m[27971]], console[m[465]](m[27972] + JSON[m[4126]](dfot4[m[27971]])), G$3J[m[611]] == 0x1 && dfot4[m[27971]] && dfot4[m[27971]][m[27973]] == 0x1 && (G$3J['showGetBtn'] = 0x1, window[m[27687]][m[141]]['G$VJ3']()), G$J023();
  } else G$3J[m[27961]][m[6655]] >= 0x3 ? (G$J2(JSON[m[4126]](kev)), window['G$203J'](m[27974] + kev[m[3743]])) : sendApi(G$3J[m[27782]], m[27854], { 'platform': G$3J[m[27780]], 'partner_id': G$3J[m[22577]], 'token': G$3J[m[27851]], 'game_pkg': G$3J[m[24121]], 'deviceId': G$3J[m[24123]], 'scene': m[27855] + G$3J[m[27789]] }, function (_4f3t0) {
    if (!_4f3t0 || _4f3t0[m[3743]] != m[9283]) {
      window['G$203J'](m[27867] + _4f3t0 && _4f3t0[m[3743]]);return;
    }G$3J[m[27868]] = String(_4f3t0[m[10735]]), G$3J[m[27869]] = String(_4f3t0[m[809]]), setTimeout(function () {
      G$J203(G$3J[m[27961]][m[6655]] + 0x1, G$3J[m[27961]][m[10750]]);
    }, 0x5dc);
  }, G$0J3, G$J2, function (b5a0) {
    return b5a0[m[3743]] == m[9283] || b5a0[m[3743]] == m[24445];
  });
}, window['G$J023'] = function () {
  ServerLoading[m[141]][m[27880]](G$3J[m[611]]), window['G$0J'] = !![], window['G$J320']();
}, window['G$J032'] = function () {
  if (window['G$J0'] && window['G$30J'] && window[m[27797]] && window[m[27798]] && window['G$3J0'] && window['G$30']) {
    if (!window[m[27302]][m[141]]) {
      console[m[465]](m[27975] + window[m[27302]][m[141]]);var of4td = wx[m[27976]](),
          vqecg = of4td[m[740]] ? of4td[m[740]] : 0x0,
          cgsvq = { 'cdn': window['G$3J'][m[4140]], 'spareCdn': window['G$3J'][m[23822]], 'newRegister': window['G$3J'][m[611]], 'wxPC': window['G$3J'][m[23825]], 'wxIOS': window['G$3J'][m[987]], 'wxAndroid': window['G$3J'][m[10579]], 'wxParam': { 'limitLoad': window['G$3J']['G$V20J3'], 'benchmarkLevel': window['G$3J']['G$V230J'], 'wxFrom': window[m[538]][m[27552]] == m[27977] ? 0x1 : 0x0, 'wxSDKVersion': window[m[27688]] }, 'configType': window['G$3J'][m[11036]], 'exposeType': window['G$3J'][m[693]], 'scene': vqecg };new window[m[27302]](cgsvq, window['G$3J'][m[95]], window['G$V203J']);
    }
  }
}, window['G$J320'] = function () {
  if (window['G$J0'] && window['G$30J'] && window[m[27797]] && window[m[27798]] && window['G$3J0'] && window['G$30'] && window['G$0J'] && window['G$03']) {
    G$23J0();if (!G$J03) {
      G$J03 = !![];if (!window[m[27302]][m[141]]) window['G$J032']();var w1yev = 0x0,
          _tfbp0 = wx[m[27978]]();_tfbp0 && (window['G$3J'][m[27745]] && (w1yev = _tfbp0[m[311]]), console[m[72]](m[27979] + _tfbp0[m[311]] + m[27980] + _tfbp0[m[1122]] + m[27981] + _tfbp0[m[1124]] + m[27982] + _tfbp0[m[1123]] + m[27983] + _tfbp0[m[169]] + m[27984] + _tfbp0[m[170]]));var h5baxi = {};for (const wk1hx in G$3J[m[24115]]) {
        h5baxi[wk1hx] = G$3J[m[24115]][wk1hx];
      }var lg8qc = { 'channel': window['G$3J'][m[24119]], 'account': window['G$3J'][m[24120]], 'userId': window['G$3J'][m[22576]], 'cdn': window['G$3J'][m[4140]], 'data': window['G$3J'][m[11]], 'package': window['G$3J'][m[23823]], 'newRegister': window['G$3J'][m[611]], 'pkgName': window['G$3J'][m[24121]], 'partnerId': window['G$3J'][m[22577]], 'platform_uid': window['G$3J'][m[24122]], 'deviceId': window['G$3J'][m[24123]], 'selectedServer': h5baxi, 'configType': window['G$3J'][m[11036]], 'exposeType': window['G$3J'][m[693]], 'debugUsers': window['G$3J'][m[11419]], 'wxMenuTop': w1yev, 'wxShield': window['G$3J'][m[707]] };if (window[m[27890]]) for (var o_tf34 in window[m[27890]]) {
        lg8qc[o_tf34] = window[m[27890]][o_tf34];
      }window[m[27302]][m[141]]['G$0V3J'](lg8qc), setTimeout(() => {
        new XingJuBoxMain();
      }, 0x1388);
    }
  } else console[m[72]](m[27985] + window['G$J0'] + m[27986] + window['G$30J'] + m[27987] + window[m[27797]] + m[27988] + window[m[27798]] + m[27989] + window['G$3J0'] + m[27990] + window['G$30'] + m[27991] + window['G$0J'] + m[27992] + window['G$03']);
};