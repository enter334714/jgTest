var A = wx.$N;
import n_gf7 from '../nnnkkk/nnnnSsdk.js';window[A[711]] = { 'wxVersion': window[A[160]][A[161]] }, window[A[712]] = ![], window['_n60'] = 0x1, window[A[713]] = 0x1, window['_nC06'] = !![], window[A[714]] = !![], window['_nOSC06'] = '', window['_n06'] = { 'base_cdn': A[715], 'cdn': A[715] }, _n06[A[716]] = {}, _n06[A[717]] = '0', _n06[A[233]] = window[A[711]][A[498]], _n06[A[266]] = '', _n06['os'] = '1', _n06['sdk_name'] = A[718], _n06[A[719]] = A[720], _n06[A[721]] = A[722], _n06[A[723]] = A[724], _n06[A[725]] = A[726], _n06[A[727]] = '1', _n06[A[176]] = '', _n06[A[728]] = '', _n06[A[729]] = 0x0, _n06[A[587]] = {}, _n06[A[730]] = parseInt(_n06[A[727]]), _n06[A[731]] = _n06[A[727]], _n06[A[177]] = {}, _n06['_nS0'] = A[732], _n06[A[733]] = ![], _n06[A[734]] = A[735], _n06[A[736]] = Date[A[293]](), _n06[A[737]] = A[738], _n06[A[739]] = '_a', _n06[A[484]] = 0x2, _n06[A[174]] = 0x7c1, _n06[A[498]] = window[A[711]][A[498]], _n06[A[740]] = ![], _n06[A[260]] = ![], _n06[A[263]] = ![], _n06[A[265]] = ![], window['_nC60'] = 0x5, window['_nC6'] = ![], window['_n6C'] = ![], window['_n0C6'] = ![], window[A[663]] = ![], window[A[666]] = ![], window['_n06C'] = ![], window['_nC0'] = ![], window['_n0C'] = ![], window['_n6C0'] = ![], window[A[741]] = function (l3e0o) {
  console[A[195]](A[741], l3e0o), wx[A[742]]({}), wx[A[202]]({ 'title': A[225], 'content': l3e0o, 'success'(ju0_n) {
      if (ju0_n[A[743]]) console[A[195]](A[744]);else ju0_n[A[745]] && console[A[195]](A[746]);
    } });
}, window['_nSC06'] = function (m_h8u) {
  console[A[195]](A[747], m_h8u), _nS06C(), wx[A[202]]({ 'title': A[225], 'content': m_h8u, 'confirmText': A[748], 'cancelText': A[749], 'success'(jm_un8) {
      if (jm_un8[A[743]]) window['_n0S']();else jm_un8[A[745]] && (console[A[195]](A[750]), wx[A[751]]({}));
    } });
}, window[A[752]] = function (yeo3z) {
  console[A[195]](A[752], yeo3z), wx[A[202]]({ 'title': A[225], 'content': yeo3z, 'confirmText': A[753], 'showCancel': ![], 'complete'(iskp2v) {
      console[A[195]](A[750]), wx[A[751]]({});
    } });
}, window['_nSC60'] = ![], window['_nS0C6'] = function (ozr43y) {
  window['_nSC60'] = !![], wx[A[754]](ozr43y);
}, window['_nS06C'] = function () {
  window['_nSC60'] && (window['_nSC60'] = ![], wx[A[742]]({}));
}, window['_nS6C0'] = function (lj0mn) {
  window[A[188]][A[189]]['_nS6C0'](lj0mn);
}, window[A[148]] = function (c1sgx, fd5th7) {
  n_gf7[A[148]](c1sgx, function (e3yoz) {
    e3yoz && e3yoz[A[597]] ? e3yoz[A[597]][A[596]] == 0x1 ? fd5th7(!![]) : (fd5th7(![]), console[A[155]](A[755] + e3yoz[A[597]][A[756]])) : console[A[195]](A[148], e3yoz);
  });
}, window['_nS60C'] = function (g5td7) {
  console[A[195]](A[757], g5td7);
}, window['_nS06'] = function (m_hu8n) {}, window['_nS60'] = function (mle0jn, oe0j3l, ylz3) {}, window['_nS6'] = function (vgcs) {
  console[A[195]](A[758], vgcs), window[A[188]][A[189]][A[488]](), window[A[188]][A[189]][A[489]](), window[A[188]][A[189]][A[502]]();
}, window['_n6S'] = function (oejl30) {
  window['_nSC06'](A[759]);var zyor3 = { 'id': window['_n06'][A[170]], 'role': window['_n06'][A[171]], 'level': window['_n06'][A[172]], 'account': window['_n06'][A[173]], 'version': window['_n06'][A[174]], 'cdn': window['_n06'][A[175]], 'pkgName': window['_n06'][A[176]], 'gamever': window[A[160]][A[161]], 'serverid': window['_n06'][A[177]] ? window['_n06'][A[177]][A[125]] : 0x0, 'systemInfo': window[A[178]], 'error': A[760], 'stack': oejl30 ? oejl30 : A[759] },
      yeoz43 = JSON[A[180]](zyor3);console[A[181]](A[761] + yeoz43), window['_nS0'](yeoz43);
}, window['_n0S6'] = function (ozle3y) {
  var mh8_un = JSON[A[762]](ozle3y);mh8_un[A[763]] = window[A[160]][A[161]], mh8_un[A[764]] = window['_n06'][A[177]] ? window['_n06'][A[177]][A[125]] : 0x0, mh8_un[A[178]] = window[A[178]];var skvxc = JSON[A[180]](mh8_un);console[A[181]](A[765] + skvxc), window['_nS0'](skvxc);
}, window['_n06S'] = function (q6$9w, htd5f7) {
  var ht75df = { 'id': window['_n06'][A[170]], 'role': window['_n06'][A[171]], 'level': window['_n06'][A[172]], 'account': window['_n06'][A[173]], 'version': window['_n06'][A[174]], 'cdn': window['_n06'][A[175]], 'pkgName': window['_n06'][A[176]], 'gamever': window[A[160]][A[161]], 'serverid': window['_n06'][A[177]] ? window['_n06'][A[177]][A[125]] : 0x0, 'systemInfo': window[A[178]], 'error': q6$9w, 'stack': htd5f7 },
      _f8tdh = JSON[A[180]](ht75df);console[A[294]](A[766] + _f8tdh), window['_nS0'](_f8tdh);
}, window['_nS0'] = function (u8jmn_) {
  if (window['_n06'][A[267]] == A[767]) return;var nj0_mu = _n06['_nS0'] + A[768] + _n06[A[173]];wx[A[769]]({ 'url': nj0_mu, 'method': A[4], 'data': u8jmn_, 'header': { 'content-type': A[770], 'cache-control': A[771] }, 'success': function (elzo) {
      DEBUG && console[A[195]](A[772], nj0_mu, u8jmn_, elzo);
    }, 'fail': function (q49by) {
      DEBUG && console[A[195]](A[772], nj0_mu, u8jmn_, q49by);
    }, 'complete': function () {} });
}, window[A[773]] = function () {
  function nj3le0() {
    return ((0x1 + Math[A[491]]()) * 0x10000 | 0x0)[A[774]](0x10)[A[775]](0x1);
  }return nj3le0() + nj3le0() + '-' + nj3le0() + '-' + nj3le0() + '-' + nj3le0() + '+' + nj3le0() + nj3le0() + nj3le0();
}, window['_n0S'] = function () {
  console[A[195]](A[776]);var ejn3l0 = n_gf7[A[777]]();_n06[A[731]] = ejn3l0[A[778]], _n06[A[730]] = ejn3l0[A[778]], _n06[A[727]] = ejn3l0[A[778]], _n06[A[176]] = ejn3l0[A[779]];var cgx17 = { 'game_ver': _n06[A[233]] };_n06[A[728]] = this[A[773]](), _nS0C6({ 'title': A[780] }), n_gf7[A[143]](cgx17, this['_n6S0'][A[495]](this));
}, window['_n6S0'] = function (o4z3) {
  var dfh75 = o4z3[A[781]];console[A[195]](A[782] + dfh75 + A[783] + (dfh75 == 0x1) + A[784] + o4z3[A[161]] + A[785] + window[A[711]][A[498]]);if (!o4z3[A[161]] || window['_nOC6S0'](window[A[711]][A[498]], o4z3[A[161]]) < 0x0) console[A[195]](A[786]), _n06[A[719]] = A[787], _n06[A[721]] = A[788], _n06[A[723]] = A[789], _n06[A[175]] = A[790], _n06[A[791]] = A[792], _n06['version_name'] = 'kl', _n06[A[740]] = ![];else window['_nOC6S0'](window[A[711]][A[498]], o4z3[A[161]]) == 0x0 ? (console[A[195]](A[793]), _n06[A[719]] = A[720], _n06[A[721]] = A[722], _n06[A[723]] = A[724], _n06[A[175]] = A[794], _n06[A[791]] = A[792], _n06['version_name'] = A[795], _n06[A[740]] = !![]) : (console[A[195]](A[796]), _n06[A[719]] = A[720], _n06[A[721]] = A[722], _n06[A[723]] = A[724], _n06[A[175]] = A[794], _n06[A[791]] = A[792], _n06['version_name'] = A[795], _n06[A[740]] = ![]);_n06[A[729]] = config[A[797]] ? config[A[797]] : 0x0, this['_nC0S6'](), this['_nC06S'](), window[A[798]] = 0x5, _nS0C6({ 'title': A[799] }), n_gf7[A[73]](this['_n60S'][A[495]](this));
}, window[A[798]] = 0x5, window['_n60S'] = function (tdh8_f, $wa6q) {
  if (tdh8_f == 0x0 && $wa6q && $wa6q[A[800]]) {
    _n06[A[801]] = $wa6q[A[800]];var f_d8 = this;_nS0C6({ 'title': A[802] }), sendApi(_n06[A[719]], A[803], { 'platform': _n06['sdk_name'], 'partner_id': _n06[A[727]], 'token': $wa6q[A[800]], 'game_pkg': _n06[A[176]], 'deviceId': _n06[A[728]], 'scene': A[804] + _n06[A[729]] }, this['_nCS06'][A[495]](this), _nC60, _n6S);
  } else $wa6q && $wa6q[A[212]] && window[A[798]] > 0x0 && ($wa6q[A[212]][A[261]](A[805]) != -0x1 || $wa6q[A[212]][A[261]](A[806]) != -0x1 || $wa6q[A[212]][A[261]](A[807]) != -0x1 || $wa6q[A[212]][A[261]](A[808]) != -0x1 || $wa6q[A[212]][A[261]](A[809]) != -0x1 || $wa6q[A[212]][A[261]](A[810]) != -0x1) ? (window[A[798]]--, n_gf7[A[73]](this['_n60S'][A[495]](this))) : (window['_n06S'](A[811], JSON[A[180]]({ 'status': tdh8_f, 'data': $wa6q })), window['_nSC06'](A[812] + ($wa6q && $wa6q[A[212]] ? '，' + $wa6q[A[212]] : '')));
}, window['_nCS06'] = function (pviks) {
  if (!pviks) {
    window['_n06S'](A[813], A[814]), window['_nSC06'](A[815]);return;
  }if (pviks[A[596]] != A[595]) {
    window['_n06S'](A[813], JSON[A[180]](pviks)), window['_nSC06'](A[816] + pviks[A[596]]);return;
  }_n06[A[817]] = String(pviks[A[173]]), _n06[A[173]] = String(pviks[A[173]]), _n06[A[237]] = String(pviks[A[237]]), _n06[A[731]] = String(pviks[A[237]]), _n06[A[818]] = String(pviks[A[818]]), _n06[A[819]] = String(pviks[A[19]]), _n06[A[820]] = String(pviks[A[821]]), _n06[A[19]] = '';var d5f = this;_nS0C6({ 'title': A[822] }), sendApi(_n06[A[719]], A[823], { 'partner_id': _n06[A[727]], 'uid': _n06[A[173]], 'version': _n06[A[233]], 'game_pkg': _n06[A[176]], 'device': _n06[A[728]] }, d5f['_nCS60'][A[495]](d5f), _nC60, _n6S);
}, window['_nCS60'] = function (vg1xc) {
  if (!vg1xc) {
    window['_nSC06'](A[824]);return;
  }if (vg1xc[A[596]] != A[595]) {
    window['_nSC06'](A[825] + vg1xc[A[596]]);return;
  }if (!vg1xc[A[597]] || vg1xc[A[597]][A[164]] == 0x0) {
    window['_nSC06'](A[826]);return;
  }_n06[A[672]] = vg1xc['is_new'], _n06[A[177]] = { 'server_id': String(vg1xc[A[597]][0x0][A[125]]), 'server_name': String(vg1xc[A[597]][0x0]['server_name']), 'entry_ip': vg1xc[A[597]][0x0][A[827]], 'entry_port': parseInt(vg1xc[A[597]][0x0][A[828]]), 'status': _n0CS(vg1xc[A[597]][0x0]), 'start_time': vg1xc[A[597]][0x0][A[829]], 'cdn': _n06[A[175]] }, this['_n60CS']();
}, window['_n60CS'] = function () {
  if (_n06[A[672]] == 0x1) {
    var j0_un = _n06[A[177]][A[575]];if (j0_un === -0x1 || j0_un === 0x0) {
      window['_nSC06'](j0_un === -0x1 ? A[830] : A[831]);return;
    }_n6SC0(0x0, _n06[A[177]][A[125]]), window[A[188]][A[189]][A[667]](_n06[A[672]]);
  } else window[A[188]][A[189]][A[664]](), _nS06C();window['_n0C'] = !![], window['_n6C0S'](), window['_n60SC']();
}, window['_nC0S6'] = function () {
  sendApi(_n06[A[719]], A[832], { 'game_pkg': _n06[A[176]], 'version_name': _n06['version_name'] }, this[A[833]][A[495]](this), _nC60, _n6S);
}, window[A[833]] = function (r9$wb) {
  if (!r9$wb) {
    window['_nSC06'](A[834]);return;
  }if (r9$wb[A[596]] != A[595]) {
    window['_nSC06'](A[835] + r9$wb[A[596]]);return;
  }if (!r9$wb[A[597]] || !r9$wb[A[597]][A[233]]) {
    window['_nSC06'](A[836] + (r9$wb[A[597]] && r9$wb[A[597]][A[233]]));return;
  }r9$wb[A[597]][A[837]] && r9$wb[A[597]][A[837]][A[164]] > 0xa && (_n06[A[838]] = r9$wb[A[597]][A[837]], _n06[A[175]] = r9$wb[A[597]][A[837]]), r9$wb[A[597]][A[233]] && (_n06[A[174]] = r9$wb[A[597]][A[233]]), console[A[155]](A[839] + _n06[A[174]] + ', version_name:' + _n06['version_name']), window['_n06C'] = !![], window['_n6C0S'](), window['_n60SC']();
}, window[A[840]], window['_nC06S'] = function () {
  sendApi(_n06[A[719]], A[841], { 'game_pkg': _n06[A[176]] }, this['_nC6S0'][A[495]](this), _nC60, _n6S);
}, window['_nC6S0'] = function (umh_f) {
  if (umh_f[A[596]] === A[595] && umh_f[A[597]]) {
    window[A[840]] = umh_f[A[597]];for (var bq$w6a in umh_f[A[597]]) {
      _n06[bq$w6a] = umh_f[A[597]][bq$w6a];
    }
  } else console[A[155]](A[842] + umh_f[A[596]]);window['_nC0'] = !![], window['_n60SC']();
}, window[A[843]] = function (qa6$bw, $b6wq9, lo0ej, yq4br9, mnju8, q94zy, $6abq, uf_8dh, s1vcgx) {
  mnju8 = String(mnju8);var n0ul = $6abq,
      _fd8th = uf_8dh;_n06[A[716]][mnju8] = { 'productid': mnju8, 'productname': n0ul, 'productdesc': _fd8th, 'roleid': qa6$bw, 'rolename': $b6wq9, 'rolelevel': lo0ej, 'price': q94zy, 'callback': s1vcgx }, sendApi(_n06[A[723]], A[844], { 'game_pkg': _n06[A[176]], 'server_id': _n06[A[177]][A[125]], 'server_name': _n06[A[177]]['server_name'], 'level': lo0ej, 'uid': _n06[A[173]], 'role_id': qa6$bw, 'role_name': $b6wq9, 'product_id': mnju8, 'product_name': n0ul, 'product_desc': _fd8th, 'money': q94zy, 'partner_id': _n06[A[727]] }, toPayCallBack, _nC60, _n6S);
}, window[A[845]] = function (jmu_0n) {
  if (jmu_0n) {
    if (jmu_0n[A[846]] === 0xc8 || jmu_0n[A[596]] == A[595]) {
      var gf75dt = _n06[A[716]][String(jmu_0n[A[847]])];if (gf75dt[A[848]]) gf75dt[A[848]](jmu_0n[A[847]], jmu_0n[A[849]], -0x1);n_gf7[A[112]]({ 'cpbill': jmu_0n[A[849]], 'productid': jmu_0n[A[847]], 'productname': gf75dt[A[850]], 'productdesc': gf75dt[A[851]], 'serverid': _n06[A[177]][A[125]], 'servername': _n06[A[177]]['server_name'], 'roleid': gf75dt[A[852]], 'rolename': gf75dt[A[853]], 'rolelevel': gf75dt[A[854]], 'price': gf75dt[A[855]], 'extension': JSON[A[180]]({ 'cp_order_id': jmu_0n[A[849]] }) }, function (g75dt, br9$4q) {
        gf75dt[A[848]] && g75dt == 0x0 && gf75dt[A[848]](jmu_0n[A[847]], jmu_0n[A[849]], g75dt);console[A[155]](JSON[A[180]]({ 'type': A[856], 'status': g75dt, 'data': jmu_0n, 'role_name': gf75dt[A[853]] }));if (g75dt === 0x0) {} else {
          if (g75dt === 0x1) {} else {
            if (g75dt === 0x2) {}
          }
        }
      });
    } else alert(jmu_0n[A[155]]);
  }
}, window['_nC60S'] = function () {}, window['_nSC6'] = function (rqwb$, t85dfh, h_u, q9b6w, t7gd1) {
  n_gf7[A[145]](_n06[A[177]][A[125]], _n06[A[177]]['server_name'] || _n06[A[177]][A[125]], rqwb$, t85dfh, h_u), sendApi(_n06[A[719]], A[857], { 'game_pkg': _n06[A[176]], 'server_id': _n06[A[177]][A[125]], 'role_id': rqwb$, 'uid': _n06[A[173]], 'role_name': t85dfh, 'role_type': q9b6w, 'level': h_u });
}, window['_nS6C'] = function ($q4b9, j_0m, tfh8_d, scvik, yz43o, tf_d8h, nmluj0, yl3e, eyzol3, qb96w$) {
  _n06[A[170]] = $q4b9, _n06[A[171]] = j_0m, _n06[A[172]] = tfh8_d, n_gf7[A[146]](_n06[A[177]][A[125]], _n06[A[177]]['server_name'] || _n06[A[177]][A[125]], $q4b9, j_0m, tfh8_d), sendApi(_n06[A[719]], A[858], { 'game_pkg': _n06[A[176]], 'server_id': _n06[A[177]][A[125]], 'role_id': $q4b9, 'uid': _n06[A[173]], 'role_name': j_0m, 'role_type': scvik, 'level': tfh8_d, 'evolution': yz43o });
}, window['_nCS6'] = function (v2sik, fdht_, nu0jl, xcik, z0eo3, unh_, xcsvki, k2pi, $wqab, _njmu8) {
  _n06[A[170]] = v2sik, _n06[A[171]] = fdht_, _n06[A[172]] = nu0jl, n_gf7[A[147]](_n06[A[177]][A[125]], _n06[A[177]]['server_name'] || _n06[A[177]][A[125]], v2sik, fdht_, nu0jl), sendApi(_n06[A[719]], A[858], { 'game_pkg': _n06[A[176]], 'server_id': _n06[A[177]][A[125]], 'role_id': v2sik, 'uid': _n06[A[173]], 'role_name': fdht_, 'role_type': xcik, 'level': nu0jl, 'evolution': z0eo3 });
}, window['_nC6S'] = function (x7csg1) {}, window['_nSC'] = function (mj0el) {
  n_gf7[A[93]](A[93], function (cxivsk) {
    mj0el && mj0el(cxivsk);
  });
}, window[A[144]] = function () {
  n_gf7[A[144]]();
}, window[A[859]] = function () {
  n_gf7[A[151]]();
}, window[A[860]] = function (ze4y, kx, ol3ey, fd75tg, _0m, m8fuh, xkv2s, emj) {
  emj = emj || _n06[A[177]][A[125]], sendApi(_n06[A[719]], A[861], { 'phone': ze4y, 'role_id': kx, 'uid': _n06[A[173]], 'game_pkg': _n06[A[176]], 'partner_id': _n06[A[727]], 'server_id': emj }, xkv2s);
}, window[A[287]] = function (s7g1c) {
  window['_n6SC'] = s7g1c, window['_n6SC'] && window['_nCS'] && (console[A[155]](A[288] + window['_nCS'][A[289]]), window['_n6SC'](window['_nCS']), window['_nCS'] = null);
}, window['_n6CS'] = function (brqw$9, hu_df, gt57fd, jlme0n) {
  window[A[862]](A[863], { 'game_pkg': window['_n06'][A[176]], 'role_id': hu_df, 'server_id': gt57fd }, jlme0n);
}, window['_n0SC6'] = function (tfh85d, ljmen0) {
  function l0mju(_nmhu) {
    var _mnj8u = [],
        ixkv = [],
        wq96b = window[A[160]][A[864]];for (var $qbr4 in wq96b) {
      var _hfmu8 = Number($qbr4);(!tfh85d || !tfh85d[A[164]] || tfh85d[A[261]](_hfmu8) != -0x1) && (ixkv[A[192]](wq96b[$qbr4]), _mnj8u[A[192]]([_hfmu8, 0x3]));
    }window['_nOC6S0'](window[A[193]], A[865]) >= 0x0 ? (console[A[195]](A[866]), n_gf7[A[867]] && n_gf7[A[867]](ixkv, function (xsvc1) {
      console[A[195]](A[868]), console[A[195]](xsvc1);if (xsvc1 && xsvc1[A[212]] == A[869]) for (var gf75d in wq96b) {
        if (xsvc1[wq96b[gf75d]] == A[870]) {
          var z4or3y = Number(gf75d);for (var pvks = 0x0; pvks < _mnj8u[A[164]]; pvks++) {
            if (_mnj8u[pvks][0x0] == z4or3y) {
              _mnj8u[pvks][0x1] = 0x1;break;
            }
          }
        }
      }window['_nOC6S0'](window[A[193]], A[871]) >= 0x0 ? wx[A[872]]({ 'withSubscriptions': !![], 'success': function (z9yqr4) {
          var k2pvsi = z9yqr4[A[873]][A[874]];if (k2pvsi) {
            console[A[195]](A[875]), console[A[195]](k2pvsi);for (var yo4r9 in wq96b) {
              if (k2pvsi[wq96b[yo4r9]] == A[870]) {
                var qwr9$ = Number(yo4r9);for (var f5ht7 = 0x0; f5ht7 < _mnj8u[A[164]]; f5ht7++) {
                  if (_mnj8u[f5ht7][0x0] == qwr9$) {
                    _mnj8u[f5ht7][0x1] = 0x2;break;
                  }
                }
              }
            }console[A[195]](_mnj8u), ljmen0 && ljmen0(_mnj8u);
          } else console[A[195]](A[876]), console[A[195]](z9yqr4), console[A[195]](_mnj8u), ljmen0 && ljmen0(_mnj8u);
        }, 'fail': function () {
          console[A[195]](A[877]), console[A[195]](_mnj8u), ljmen0 && ljmen0(_mnj8u);
        } }) : (console[A[195]](A[878] + window[A[193]]), console[A[195]](_mnj8u), ljmen0 && ljmen0(_mnj8u));
    })) : (console[A[195]](A[879] + window[A[193]]), console[A[195]](_mnj8u), ljmen0 && ljmen0(_mnj8u)), wx[A[880]](l0mju);
  }wx[A[881]](l0mju);
}, window['_n0S6C'] = { 'isSuccess': ![], 'level': A[882], 'isCharging': ![] }, window['_n0CS6'] = function (_8hmun) {
  wx[A[275]]({ 'success': function (a$6b) {
      var t_8 = window['_n0S6C'];t_8[A[883]] = !![], t_8[A[277]] = Number(a$6b[A[277]])[A[884]](0x0), t_8[A[279]] = a$6b[A[279]], _8hmun && _8hmun(t_8[A[883]], t_8[A[277]], t_8[A[279]]);
    }, 'fail': function (h8dtf5) {
      console[A[195]](A[885], h8dtf5[A[212]]);var z34yro = window['_n0S6C'];_8hmun && _8hmun(z34yro[A[883]], z34yro[A[277]], z34yro[A[279]]);
    } });
}, window[A[862]] = function (fdh7t, vksci, f_8hd, ylez, fh_u8d, l3ezo, qb4, isk2vp) {
  if (ylez == undefined) ylez = 0x1;wx[A[769]]({ 'url': fdh7t, 'method': qb4 || A[886], 'responseType': A[493], 'data': vksci, 'header': { 'content-type': isk2vp || A[770] }, 'success': function (f_h8t) {
      DEBUG && console[A[195]](A[887], fdh7t, info, f_h8t);if (f_h8t && f_h8t[A[888]] == 0xc8) {
        var tdg5f = f_h8t[A[597]];!l3ezo || l3ezo(tdg5f) ? f_8hd && f_8hd(tdg5f) : window[A[889]](fdh7t, vksci, f_8hd, ylez, fh_u8d, l3ezo, f_h8t);
      } else window[A[889]](fdh7t, vksci, f_8hd, ylez, fh_u8d, l3ezo, f_h8t);
    }, 'fail': function (jeln03) {
      DEBUG && console[A[195]](A[890], fdh7t, info, jeln03), window[A[889]](fdh7t, vksci, f_8hd, ylez, fh_u8d, l3ezo, jeln03);
    }, 'complete': function () {} });
}, window[A[889]] = function (gs7x1c, h_mf, wa$6b, vki2x, c5x7g, emlj0n, skivx2) {
  vki2x - 0x1 > 0x0 ? setTimeout(function () {
    window[A[862]](gs7x1c, h_mf, wa$6b, vki2x - 0x1, c5x7g, emlj0n);
  }, 0x3e8) : c5x7g && c5x7g(JSON[A[180]]({ 'url': gs7x1c, 'response': skivx2 }));
}, window[A[891]] = function ($q6wb9, o0le3, sckv1x, y43eo, gt5df, rbq$9, q9wbr) {
  !sckv1x && (sckv1x = {});var ufd_h8 = Math[A[683]](Date[A[293]]() / 0x3e8);sckv1x[A[821]] = ufd_h8, sckv1x[A[892]] = o0le3;var jo3l0e = Object[A[893]](sckv1x)[A[601]](),
      mj_8nu = '',
      ps2v = '';for (var t5gfd = 0x0; t5gfd < jo3l0e[A[164]]; t5gfd++) {
    mj_8nu = mj_8nu + (t5gfd == 0x0 ? '' : '&') + jo3l0e[t5gfd] + sckv1x[jo3l0e[t5gfd]], ps2v = ps2v + (t5gfd == 0x0 ? '' : '&') + jo3l0e[t5gfd] + '=' + encodeURIComponent(sckv1x[jo3l0e[t5gfd]]);
  }mj_8nu = mj_8nu + _n06[A[725]];var ski2v = A[894] + md5(mj_8nu);send($q6wb9 + '?' + ps2v + (ps2v == '' ? '' : '&') + ski2v, null, y43eo, gt5df, rbq$9, q9wbr || function (tfd8_h) {
    return tfd8_h[A[596]] == A[595];
  }, null, A[3]);
}, window['_n0C6S'] = function (y94zqr, dtfg5) {
  var _jnmu8 = 0x0;_n06[A[177]] && (_jnmu8 = _n06[A[177]][A[125]]), sendApi(_n06[A[721]], A[895], { 'partnerId': _n06[A[727]], 'gamePkg': _n06[A[176]], 'logTime': Math[A[683]](Date[A[293]]() / 0x3e8), 'platformUid': _n06[A[818]], 'type': y94zqr, 'serverId': _jnmu8 }, null, 0x2, null, function () {
    return !![];
  });
}, window['_n06SC'] = function (g7cx) {
  sendApi(_n06[A[719]], A[896], { 'partner_id': _n06[A[727]], 'uid': _n06[A[173]], 'version': _n06[A[233]], 'game_pkg': _n06[A[176]], 'device': _n06[A[728]] }, _n06CS, _nC60, _n6S);
}, window['_n06CS'] = function (ufh_8m) {
  if (ufh_8m[A[596]] === A[595] && ufh_8m[A[597]]) {
    ufh_8m[A[597]][A[897]]({ 'id': -0x2, 'name': A[898] }), ufh_8m[A[597]][A[897]]({ 'id': -0x1, 'name': A[899] }), _n06[A[549]] = ufh_8m[A[597]];if (window[A[541]]) window[A[541]][A[581]]();
  } else _n06[A[559]] = ![], window['_nSC06'](A[900] + ufh_8m[A[596]]);
}, window['_nSC0'] = function (t75h) {
  sendApi(_n06[A[719]], A[901], { 'partner_id': _n06[A[727]], 'uid': _n06[A[173]], 'version': _n06[A[233]], 'game_pkg': _n06[A[176]], 'device': _n06[A[728]] }, _nS0C, _nC60, _n6S);
}, window['_nS0C'] = function (vk2p) {
  _n06[A[589]] = ![];if (vk2p[A[596]] === A[595] && vk2p[A[597]]) {
    for (var b6$qaw = 0x0; b6$qaw < vk2p[A[597]][A[164]]; b6$qaw++) {
      vk2p[A[597]][b6$qaw][A[575]] = _n0CS(vk2p[A[597]][b6$qaw]);
    }_n06[A[587]][-0x1] = window[A[902]](vk2p[A[597]]), window[A[541]][A[588]](-0x1);
  } else window['_nSC06'](A[903] + vk2p[A[596]]);
}, window[A[904]] = function ($94q) {
  sendApi(_n06[A[719]], A[901], { 'partner_id': _n06[A[727]], 'uid': _n06[A[173]], 'version': _n06[A[233]], 'game_pkg': _n06[A[176]], 'device': _n06[A[728]] }, $94q, _nC60, _n6S);
}, window['_nCS0'] = function (yze3lo, h8un_m) {
  sendApi(_n06[A[719]], A[905], { 'partner_id': _n06[A[727]], 'uid': _n06[A[173]], 'version': _n06[A[233]], 'game_pkg': _n06[A[176]], 'device': _n06[A[728]], 'server_group_id': h8un_m }, _nC0S, _nC60, _n6S);
}, window['_nC0S'] = function (d5t8f) {
  _n06[A[589]] = ![];if (d5t8f[A[596]] === A[595] && d5t8f[A[597]] && d5t8f[A[597]][A[597]]) {
    var l3yz = d5t8f[A[597]][A[906]],
        c5xg7 = [];for (var j0m_n = 0x0; j0m_n < d5t8f[A[597]][A[597]][A[164]]; j0m_n++) {
      d5t8f[A[597]][A[597]][j0m_n][A[575]] = _n0CS(d5t8f[A[597]][A[597]][j0m_n]), (c5xg7[A[164]] == 0x0 || d5t8f[A[597]][A[597]][j0m_n][A[575]] != 0x0) && (c5xg7[c5xg7[A[164]]] = d5t8f[A[597]][A[597]][j0m_n]);
    }_n06[A[587]][l3yz] = window[A[902]](c5xg7), window[A[541]][A[588]](l3yz);
  } else window['_nSC06'](A[907] + d5t8f[A[596]]);
}, window['_nOC60'] = function (o3zr4) {
  sendApi(_n06[A[719]], A[908], { 'partner_id': _n06[A[727]], 'uid': _n06[A[173]], 'version': _n06[A[233]], 'game_pkg': _n06[A[176]], 'device': _n06[A[728]] }, reqServerRecommendCallBack, _nC60, _n6S);
}, window[A[909]] = function (eo03lz) {
  _n06[A[589]] = ![];if (eo03lz[A[596]] === A[595] && eo03lz[A[597]]) {
    for (var h8mfu_ = 0x0; h8mfu_ < eo03lz[A[597]][A[164]]; h8mfu_++) {
      eo03lz[A[597]][h8mfu_][A[575]] = _n0CS(eo03lz[A[597]][h8mfu_]);
    }_n06[A[587]][-0x2] = window[A[902]](eo03lz[A[597]]), window[A[541]][A[588]](-0x2);
  } else alert(A[910] + eo03lz[A[596]]);
}, window[A[902]] = function (x7c15g) {
  if (!x7c15g && x7c15g[A[164]] <= 0x0) return x7c15g;for (let umnjl0 = 0x0; umnjl0 < x7c15g[A[164]]; umnjl0++) {
    x7c15g[umnjl0][A[911]] && x7c15g[umnjl0][A[911]] == 0x1 && (x7c15g[umnjl0]['server_name'] += A[912]);
  }return x7c15g;
}, window['_n0SC'] = function (b$qrw, ljunm) {
  b$qrw = b$qrw || _n06[A[177]][A[125]], sendApi(_n06[A[719]], A[913], { 'type': '4', 'game_pkg': _n06[A[176]], 'server_id': b$qrw }, ljunm);
}, window['req_multi_server_notice'] = function (f8d_th, kv2si, svxc1k, nju0m) {
  svxc1k = svxc1k || _n06[A[177]][A[125]], sendApi(_n06[A[719]], 'Common.get_new_anno', { 'type': f8d_th, 'game_pkg': kv2si, 'server_id': svxc1k }, nju0m);
}, window['_n0CS'] = function (e0jn) {
  if (e0jn) {
    if (e0jn[A[575]] == 0x1) {
      if (e0jn[A[914]] == 0x1) return 0x2;else return 0x1;
    } else return e0jn[A[575]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_n6SC0'] = function (l3oez, x15g7c) {
  _n06[A[915]] = { 'step': l3oez, 'server_id': x15g7c };var hfu_8 = this;_nS0C6({ 'title': A[916] }), sendApi(_n06[A[719]], A[917], { 'partner_id': _n06[A[727]], 'uid': _n06[A[173]], 'game_pkg': _n06[A[176]], 'server_id': x15g7c, 'platform': _n06[A[237]], 'platform_uid': _n06[A[818]], 'check_login_time': _n06[A[820]], 'check_login_sign': _n06[A[819]], 'version_name': _n06['version_name'] }, _n6S0C, _nC60, _n6S, function (o3j) {
    return o3j[A[596]] == A[595] || o3j[A[155]] == A[918] || o3j[A[155]] == A[919];
  });
}, window['_n6S0C'] = function (g5x71) {
  var f_u8mh = this;if (g5x71[A[596]] === A[595] && g5x71[A[597]]) {
    var x1vcgs = _n06[A[177]];x1vcgs['channel_num'] = _n06[A[730]], x1vcgs[A[19]] = String(g5x71[A[597]][A[920]]), x1vcgs[A[736]] = parseInt(g5x71[A[597]][A[821]]);if (g5x71[A[597]]['server_num']) x1vcgs['server_num'] = parseInt(g5x71[A[597]]['server_num']);else x1vcgs['server_num'] = parseInt(g5x71[A[597]][A[125]]);x1vcgs[A[921]] = 0x0, x1vcgs[A[175]] = _n06[A[838]], x1vcgs[A[922]] = g5x71[A[597]][A[923]], x1vcgs[A[924]] = g5x71[A[597]][A[924]], console[A[195]](A[925] + JSON[A[180]](x1vcgs[A[924]])), _n06[A[672]] == 0x1 && x1vcgs[A[924]] && x1vcgs[A[924]][A[926]] == 0x1 && (_n06[A[499]] = 0x1, window[A[188]][A[189]]['_nO60']()), _n6CS0();
  } else _n06[A[915]][A[927]] >= 0x3 ? (_n6S(JSON[A[180]](g5x71)), window['_nSC06'](A[928] + g5x71[A[596]])) : sendApi(_n06[A[719]], A[803], { 'platform': _n06['sdk_name'], 'partner_id': _n06[A[727]], 'token': _n06[A[801]], 'game_pkg': _n06[A[176]], 'deviceId': _n06[A[728]], 'scene': A[804] + _n06[A[729]] }, function (xvksi2) {
    if (!xvksi2 || xvksi2[A[596]] != A[595]) {
      window['_nSC06'](A[816] + xvksi2 && xvksi2[A[596]]);return;
    }_n06[A[819]] = String(xvksi2[A[19]]), _n06[A[820]] = String(xvksi2[A[821]]), setTimeout(function () {
      _n6SC0(_n06[A[915]][A[927]] + 0x1, _n06[A[915]][A[125]]);
    }, 0x5dc);
  }, _nC60, _n6S, function (zyr49q) {
    return zyr49q[A[596]] == A[595] || zyr49q[A[596]] == A[929];
  });
}, window['_n6CS0'] = function () {
  ServerLoading[A[189]][A[667]](_n06[A[672]]), window['_nC6'] = !![], window['_n60SC']();
}, window['_n6C0S'] = function () {
  if (window['_n6C'] && window['_n0C6'] && window[A[663]] && window[A[666]] && window['_n06C'] && window['_n0C']) {
    if (!window[A[930]][A[189]]) {
      console[A[195]](A[931] + window[A[930]][A[189]]);var r9b4q$ = wx[A[932]](),
          m_n8hu = r9b4q$[A[289]] ? r9b4q$[A[289]] : 0x0,
          u_hdf = { 'cdn': window['_n06'][A[175]], 'spareCdn': window['_n06'][A[791]], 'newRegister': window['_n06'][A[672]], 'wxPC': window['_n06'][A[265]], 'wxIOS': window['_n06'][A[260]], 'wxAndroid': window['_n06'][A[263]], 'wxParam': { 'limitLoad': window['_n06']['_nOSC60'], 'benchmarkLevel': window['_n06']['_nOS0C6'], 'wxFrom': window[A[160]][A[797]] == A[933] ? 0x1 : 0x0, 'wxSDKVersion': window[A[193]] }, 'configType': window['_n06'][A[737]], 'exposeType': window['_n06'][A[739]], 'scene': m_n8hu };new window[A[930]](u_hdf, window['_n06'][A[174]], window['_nOSC06']);
    }
  }
}, window['_n60SC'] = function () {
  if (window['_n6C'] && window['_n0C6'] && window[A[663]] && window[A[666]] && window['_n06C'] && window['_n0C'] && window['_nC6'] && window['_nC0']) {
    _nS06C();if (!_n6C0) {
      _n6C0 = !![];if (!window[A[930]][A[189]]) window['_n6C0S']();var ryo94z = 0x0,
          rq$b4 = wx[A[934]]();rq$b4 && (window['_n06'][A[264]] && (ryo94z = rq$b4[A[255]]), console[A[155]](A[935] + rq$b4[A[255]] + A[936] + rq$b4[A[256]] + A[937] + rq$b4[A[257]] + A[938] + rq$b4[A[258]] + A[939] + rq$b4[A[462]] + A[940] + rq$b4[A[464]]));var um0jnl = {};for (const dth5f7 in _n06[A[177]]) {
        um0jnl[dth5f7] = _n06[A[177]][dth5f7];
      }var lumn = { 'channel': window['_n06'][A[731]], 'account': window['_n06'][A[173]], 'userId': window['_n06'][A[817]], 'cdn': window['_n06'][A[175]], 'data': window['_n06'][A[597]], 'package': window['_n06'][A[717]], 'newRegister': window['_n06'][A[672]], 'pkgName': window['_n06'][A[176]], 'partnerId': window['_n06'][A[727]], 'platform_uid': window['_n06'][A[818]], 'deviceId': window['_n06'][A[728]], 'selectedServer': um0jnl, 'configType': window['_n06'][A[737]], 'exposeType': window['_n06'][A[739]], 'debugUsers': window['_n06'][A[734]], 'wxMenuTop': ryo94z, 'wxShield': window['_n06'][A[740]] };if (window[A[840]]) for (var lum in window[A[840]]) {
        lumn[lum] = window[A[840]][lum];
      }window[A[930]][A[189]]['_n60O'](lumn);
    }
  } else console[A[155]](A[941] + window['_n6C'] + A[942] + window['_n0C6'] + A[943] + window[A[663]] + A[944] + window[A[666]] + A[945] + window['_n06C'] + A[946] + window['_n0C'] + A[947] + window['_nC6'] + A[948] + window['_nC0']);
};