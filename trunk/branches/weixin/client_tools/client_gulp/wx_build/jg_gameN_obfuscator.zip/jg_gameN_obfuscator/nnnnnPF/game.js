var A = wx.$N;
require('nBF.js'), window[A[29148]][A[29149]][A[29150]] = null, window['client_pb'] = require('nnnCLIENTPB.js'), window[A[26056]] = window[A[29148]][A[25968]][A[25969]](client_pb);