var A = wx.$N;
import 'nnnnMAIN.js';