var A = wx.$N;
console[A[155]](A[156]), window[A[157]], wx[A[158]](function (p2ivk) {
  if (p2ivk) {
    if (p2ivk[A[159]]) {
      var t1d = window[A[160]][A[161]][A[162]](new RegExp(/\./, 'g'), '_'),
          sk2vi = p2ivk[A[159]],
          yz94r = sk2vi[A[163]](/(nnnnnnnnn\/nnnGAME.js:)[0-9]{1,60}(:)/g);if (yz94r) for (var g517c = 0x0; g517c < yz94r[A[164]]; g517c++) {
        if (yz94r[g517c] && yz94r[g517c][A[164]] > 0x0) {
          var $9qwbr = parseInt(yz94r[g517c][A[162]](A[165], '')[A[162]](':', ''));sk2vi = sk2vi[A[162]](yz94r[g517c], yz94r[g517c][A[162]](':' + $9qwbr + ':', ':' + ($9qwbr - 0x2) + ':'));
        }
      }sk2vi = sk2vi[A[162]](new RegExp(A[166], 'g'), A[167] + t1d + A[168]), sk2vi = sk2vi[A[162]](new RegExp(A[169], 'g'), A[167] + t1d + A[168]), p2ivk[A[159]] = sk2vi;
    }var ufm_ = { 'id': window['_n06'][A[170]], 'role': window['_n06'][A[171]], 'level': window['_n06'][A[172]], 'user': window['_n06'][A[173]], 'version': window['_n06'][A[174]], 'cdn': window['_n06'][A[175]], 'pkgName': window['_n06'][A[176]], 'gamever': window[A[160]][A[161]], 'serverid': window['_n06'][A[177]] ? window['_n06'][A[177]][A[125]] : 0x0, 'systemInfo': window[A[178]], 'error': A[179], 'stack': p2ivk ? p2ivk[A[159]] : '' },
        zq4yr = JSON[A[180]](ufm_);console[A[181]](A[182] + zq4yr), (!window[A[157]] || window[A[157]] != ufm_[A[181]]) && (window[A[157]] = ufm_[A[181]], window['_nS0'](ufm_));
  }
});import 'nnnnMDadfa.js';import 'nnnasdf.js';window[A[183]] = require(A[184]);import 'nnnnnINDEX.js';import 'nnnLIBsdsa.js';import 'nnnnnWXMsad.js';import 'nnnnINITMIN.js';console[A[155]](A[185]), console[A[155]](A[186]), _nS0C6({ 'title': A[187] });var n_d5tgf = { '_nOS60C': !![] };new window[A[188]](n_d5tgf), window[A[188]][A[189]]['_nOC06S']();if (window['_nOS06C']) clearInterval(window['_nOS06C']);window['_nOS06C'] = null, window['_nOC6S0'] = function (jo0el, unj) {
  if (!jo0el || !unj) return 0x0;jo0el = jo0el[A[190]]('.'), unj = unj[A[190]]('.');const wbr$9 = Math[A[191]](jo0el[A[164]], unj[A[164]]);while (jo0el[A[164]] < wbr$9) {
    jo0el[A[192]]('0');
  }while (unj[A[164]] < wbr$9) {
    unj[A[192]]('0');
  }for (var uh_8d = 0x0; uh_8d < wbr$9; uh_8d++) {
    const qbw69$ = parseInt(jo0el[uh_8d]),
          f57th = parseInt(unj[uh_8d]);if (qbw69$ > f57th) return 0x1;else {
      if (qbw69$ < f57th) return -0x1;
    }
  }return 0x0;
}, window[A[193]] = wx[A[194]]()[A[193]], console[A[195]](A[196] + window[A[193]]);var n_e0jl3n = wx[A[197]]();n_e0jl3n[A[198]](function (b$q9) {
  console[A[195]](A[199] + b$q9[A[200]]);
}), n_e0jl3n[A[201]](function () {
  wx[A[202]]({ 'title': A[203], 'content': A[204], 'showCancel': ![], 'success': function (zoley3) {
      n_e0jl3n[A[205]]();
    } });
}), n_e0jl3n[A[206]](function () {
  console[A[195]](A[207]);
}), window['_nOC60S'] = function () {
  console[A[195]](A[208]);var u0nj_m = wx[A[209]]({ 'name': A[210], 'success': function (huf8_d) {
      console[A[195]](A[211]), console[A[195]](huf8_d), huf8_d && huf8_d[A[212]] == A[213] ? (window['_n6C'] = !![], window['_n6C0S'](), window['_n60SC']()) : setTimeout(function () {
        window['_nOC60S']();
      }, 0x1f4);
    }, 'fail': function (sg1c) {
      console[A[195]](A[214]), console[A[195]](sg1c), setTimeout(function () {
        window['_nOC60S']();
      }, 0x1f4);
    } });u0nj_m && u0nj_m[A[215]](lmu0jn => {});
}, window['_nO0S6C'] = function () {
  console[A[195]](A[216]);var j_m8u = wx[A[209]]({ 'name': A[217], 'success': function (a$q6bw) {
      console[A[195]](A[218]), console[A[195]](a$q6bw), a$q6bw && a$q6bw[A[212]] == A[213] ? (window['_n0C6'] = !![], window['_n6C0S'](), window['_n60SC']()) : setTimeout(function () {
        window['_nO0S6C']();
      }, 0x1f4);
    }, 'fail': function (sxvcg1) {
      console[A[195]](A[219]), console[A[195]](sxvcg1), setTimeout(function () {
        window['_nO0S6C']();
      }, 0x1f4);
    } });j_m8u && j_m8u[A[215]](viskxc => {});
}, window[A[220]] = function () {
  window['_nOC6S0'](window[A[193]], A[221]) >= 0x0 ? (console[A[195]](A[222] + window[A[193]] + A[223]), window['_n0S'](), window['_nOC60S'](), window['_nO0S6C']()) : (window['_n06S'](A[224], window[A[193]]), wx[A[202]]({ 'title': A[225], 'content': A[226] }));
}, window[A[178]] = '', wx[A[227]]({ 'success'(zlyoe) {
    window[A[178]] = A[228] + zlyoe[A[229]] + A[230] + zlyoe[A[231]] + A[232] + zlyoe[A[233]] + A[234] + zlyoe[A[235]] + A[236] + zlyoe[A[237]] + A[238] + zlyoe[A[193]] + A[239] + zlyoe[A[240]], console[A[195]](window[A[178]]), console[A[195]](A[241] + zlyoe[A[242]] + A[243] + zlyoe[A[244]] + A[245] + zlyoe[A[246]] + A[247] + zlyoe[A[248]] + A[249] + zlyoe[A[250]] + A[251] + zlyoe[A[252]] + A[253] + (zlyoe[A[254]] ? zlyoe[A[254]][A[255]] + ',' + zlyoe[A[254]][A[256]] + ',' + zlyoe[A[254]][A[257]] + ',' + zlyoe[A[254]][A[258]] : ''));var lj0um = zlyoe[A[235]] ? zlyoe[A[235]][A[259]]() : '',
        kxs = zlyoe[A[231]] ? zlyoe[A[231]][A[259]]()[A[162]]('\x20', '') : '';window['_n06'][A[260]] = lj0um[A[261]](A[262]) != -0x1, window['_n06'][A[263]] = lj0um[A[261]](A[33]) != -0x1, window['_n06'][A[264]] = lj0um[A[261]](A[262]) != -0x1 || lj0um[A[261]](A[33]) != -0x1, window['_n06'][A[265]] = lj0um[A[261]](A[64]) != -0x1 || lj0um[A[261]](A[266]) != -0x1, window['_n06'][A[267]] = zlyoe[A[237]] ? zlyoe[A[237]][A[259]]() : '', window['_n06']['_nOSC60'] = ![], window['_n06']['_nOS0C6'] = 0x2;if (lj0um[A[261]](A[33]) != -0x1) {
      if (zlyoe[A[240]] >= 0x18) window['_n06']['_nOS0C6'] = 0x3;else window['_n06']['_nOS0C6'] = 0x2;
    } else {
      if (lj0um[A[261]](A[262]) != -0x1) {
        if (zlyoe[A[240]] && zlyoe[A[240]] >= 0x14) window['_n06']['_nOS0C6'] = 0x3;else {
          if (kxs[A[261]](A[268]) != -0x1 || kxs[A[261]](A[269]) != -0x1 || kxs[A[261]](A[270]) != -0x1 || kxs[A[261]](A[271]) != -0x1 || kxs[A[261]](A[272]) != -0x1) window['_n06']['_nOS0C6'] = 0x2;else window['_n06']['_nOS0C6'] = 0x3;
        }
      } else window['_n06']['_nOS0C6'] = 0x2;
    }console[A[195]](A[273] + window['_n06']['_nOSC60'] + A[274] + window['_n06']['_nOS0C6']);
  } }), wx[A[275]]({ 'success': function (h_duf) {
    console[A[195]](A[276] + h_duf[A[277]] + A[278] + h_duf[A[279]]);
  } }), wx[A[280]]({ 'success': function (yzr3) {
    console[A[195]](A[281] + yzr3[A[282]]);
  } }), wx[A[283]]({ 'keepScreenOn': !![] }), wx[A[284]](function (m0uj_) {
  console[A[195]](A[281] + m0uj_[A[282]] + A[285] + m0uj_[A[286]]);
}), wx[A[287]](function (h5f8d) {
  window['_nCS'] = h5f8d, window['_n6SC'] && window['_nCS'] && (console[A[155]](A[288] + window['_nCS'][A[289]]), window['_n6SC'](window['_nCS']), window['_nCS'] = null);
}), window[A[290]] = 0x0, window['_nO0C6S'] = 0x0, window[A[291]] = null, wx[A[292]](function () {
  window['_nO0C6S']++;var sxvc1 = Date[A[293]]();(window[A[290]] == 0x0 || sxvc1 - window[A[290]] > 0x1d4c0) && (console[A[294]](A[295]), wx[A[296]]());if (window['_nO0C6S'] >= 0x2) {
    window['_nO0C6S'] = 0x0, console[A[181]](A[297]), wx[A[298]]('0', 0x1);if (window['_n06'] && window['_n06'][A[260]]) window['_n06S'](A[299], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});