var k = wx.$f;
require('ffffBuff.js'), window[k[88272]][k[88262]][k[88155]] = null, window['client_pb'] = require('fffcleintpb.js'), window[k[84203]] = window[k[88272]][k[84095]][k[84096]](client_pb);