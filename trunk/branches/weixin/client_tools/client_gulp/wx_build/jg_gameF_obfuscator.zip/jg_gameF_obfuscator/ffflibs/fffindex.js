var k = wx.$f;
import fcdsn from '../ffffsdk/fffsdk.js';window[k[87489]] = { 'wxVersion': window[k[60540]][k[87389]] }, window[k[87490]] = ![], window['F$6L'] = 0x1, window[k[87491]] = 0x1, window['F$8L6'] = !![], window[k[87492]] = !![], window['F$I08L6'] = '', window['F$L6'] = { 'base_cdn': k[87493], 'cdn': k[87493] }, F$L6[k[87494]] = {}, F$L6[k[83780]] = '0', F$L6[k[64343]] = window[k[87489]][k[87495]], F$L6[k[87461]] = '', F$L6['os'] = '1', F$L6[k[87496]] = k[87497], F$L6[k[87498]] = k[87499], F$L6[k[87500]] = k[87501], F$L6[k[87502]] = k[87503], F$L6[k[87504]] = k[87505], F$L6[k[82500]] = '1', F$L6[k[84067]] = '', F$L6[k[84069]] = '', F$L6[k[87506]] = 0x0, F$L6[k[87507]] = {}, F$L6[k[87508]] = parseInt(F$L6[k[82500]]), F$L6[k[84065]] = F$L6[k[82500]], F$L6[k[84061]] = {}, F$L6['F$0L'] = k[87509], F$L6[k[87510]] = ![], F$L6[k[71369]] = k[87511], F$L6[k[84040]] = Date[k[60082]](), F$L6[k[70993]] = k[87512], F$L6[k[60691]] = '_a', F$L6[k[87513]] = 0x2, F$L6[k[60100]] = 0x7c1, F$L6[k[87495]] = window[k[87489]][k[87495]], F$L6[k[60715]] = ![], F$L6[k[61005]] = ![], F$L6[k[70509]] = ![], F$L6[k[83782]] = ![], window['F$86L'] = 0x5, window['F$86'] = ![], window['F$68'] = ![], window['F$L86'] = ![], window[k[87514]] = ![], window[k[87515]] = ![], window['F$L68'] = ![], window['F$8L'] = ![], window['F$L8'] = ![], window['F$68L'] = ![], window[k[63830]] = function (guv) {
  console[k[60468]](k[63830], guv), wx[k[64597]]({}), wx[k[87412]]({ 'title': k[65858], 'content': guv, 'success'(_2o6k) {
      if (_2o6k[k[87261]]) console[k[60468]](k[87516]);else _2o6k[k[60536]] && console[k[60468]](k[87237]);
    } });
}, window['F$08L6'] = function (khq05) {
  console[k[60468]](k[87517], khq05), F$0L68(), wx[k[87412]]({ 'title': k[65858], 'content': khq05, 'confirmText': k[87518], 'cancelText': k[77483], 'success'(ern8zx) {
      if (ern8zx[k[87261]]) window['F$L0']();else ern8zx[k[60536]] && (console[k[60468]](k[87519]), wx[k[83775]]({}));
    } });
}, window[k[87520]] = function (vug1) {
  console[k[60468]](k[87520], vug1), wx[k[87412]]({ 'title': k[65858], 'content': vug1, 'confirmText': k[84195], 'showCancel': ![], 'complete'(er7xz) {
      console[k[60468]](k[87519]), wx[k[83775]]({});
    } });
}, window['F$086L'] = ![], window['F$0L86'] = function (e87z) {
  window['F$086L'] = !![], wx[k[64596]](e87z);
}, window['F$0L68'] = function () {
  window['F$086L'] && (window['F$086L'] = ![], wx[k[64597]]({}));
}, window['F$068L'] = function (zr$e87) {
  window[k[87404]][k[60144]]['F$068L'](zr$e87);
}, window[k[71251]] = function (jwdx, v1uibm) {
  fcdsn[k[71251]](jwdx, function (dojw) {
    dojw && dojw[k[60011]] ? dojw[k[60011]][k[63765]] == 0x1 ? v1uibm(!![]) : (v1uibm(![]), console[k[60077]](k[87521] + dojw[k[60011]][k[87522]])) : console[k[60468]](k[71251], dojw);
  });
}, window['F$06L8'] = function (yp3$) {
  console[k[60468]](k[87523], yp3$);
}, window['F$0L6'] = function (jco6) {}, window['F$06L'] = function (jwsodc, sdjc6o, hifbt) {}, window['F$06'] = function (mfv) {
  console[k[60468]](k[87524], mfv), window[k[87404]][k[60144]][k[87525]](), window[k[87404]][k[60144]][k[87526]](), window[k[87404]][k[60144]][k[87527]]();
}, window['F$60'] = function (r73$ya) {
  window['F$08L6'](k[87528]);var dnwsx = { 'id': window['F$L6'][k[87394]], 'role': window['F$L6'][k[64273]], 'level': window['F$L6'][k[87395]], 'account': window['F$L6'][k[84066]], 'version': window['F$L6'][k[60100]], 'cdn': window['F$L6'][k[64161]], 'pkgName': window['F$L6'][k[84067]], 'gamever': window[k[60540]][k[87389]], 'serverid': window['F$L6'][k[84061]] ? window['F$L6'][k[84061]][k[70674]] : 0x0, 'systemInfo': window[k[87396]], 'error': k[87529], 'stack': r73$ya ? r73$ya : k[87528] },
      xwjds = JSON[k[64147]](dnwsx);console[k[60124]](k[87530] + xwjds), window['F$0L'](xwjds);
}, window['F$L06'] = function (jdsowc) {
  var bu1i = JSON[k[60512]](jdsowc);bu1i[k[87531]] = window[k[60540]][k[87389]], bu1i[k[87532]] = window['F$L6'][k[84061]] ? window['F$L6'][k[84061]][k[70674]] : 0x0, bu1i[k[87396]] = window[k[87396]];var vg9u1 = JSON[k[64147]](bu1i);console[k[60124]](k[87533] + vg9u1), window['F$0L'](vg9u1);
}, window['F$L60'] = function (hk_q50, t5q0f) {
  var q0kh = { 'id': window['F$L6'][k[87394]], 'role': window['F$L6'][k[64273]], 'level': window['F$L6'][k[87395]], 'account': window['F$L6'][k[84066]], 'version': window['F$L6'][k[60100]], 'cdn': window['F$L6'][k[64161]], 'pkgName': window['F$L6'][k[84067]], 'gamever': window[k[60540]][k[87389]], 'serverid': window['F$L6'][k[84061]] ? window['F$L6'][k[84061]][k[70674]] : 0x0, 'systemInfo': window[k[87396]], 'error': hk_q50, 'stack': t5q0f },
      q5_k0h = JSON[k[64147]](q0kh);console[k[60095]](k[87534] + q5_k0h), window['F$0L'](q5_k0h);
}, window['F$0L'] = function (vbg9u) {
  if (window['F$L6'][k[87462]] == k[87535]) return;var k5qh = F$L6['F$0L'] + k[87536] + F$L6[k[84066]];wx[k[60463]]({ 'url': k5qh, 'method': k[87220], 'data': vbg9u, 'header': { 'content-type': k[87537], 'cache-control': k[87538] }, 'success': function (k426) {
      DEBUG && console[k[60468]](k[87539], k5qh, vbg9u, k426);
    }, 'fail': function (z8enxw) {
      DEBUG && console[k[60468]](k[87539], k5qh, vbg9u, z8enxw);
    }, 'complete': function () {} });
}, window[k[87540]] = function () {
  function dnwjxs() {
    return ((0x1 + Math[k[60118]]()) * 0x10000 | 0x0)[k[60268]](0x10)[k[60485]](0x1);
  }return dnwjxs() + dnwjxs() + '-' + dnwjxs() + '-' + dnwjxs() + '-' + dnwjxs() + '+' + dnwjxs() + dnwjxs() + dnwjxs();
}, window['F$L0'] = function () {
  console[k[60468]](k[87541]);var oj6c24 = fcdsn[k[87542]]();F$L6[k[84065]] = oj6c24[k[87543]], F$L6[k[87508]] = oj6c24[k[87543]], F$L6[k[82500]] = oj6c24[k[87543]], F$L6[k[84067]] = oj6c24[k[87544]];var zn8x = { 'game_ver': F$L6[k[64343]] };F$L6[k[84069]] = this[k[87540]](), F$0L86({ 'title': k[87545] }), fcdsn[k[60360]](zn8x, this['F$60L'][k[60073]](this));
}, window['F$60L'] = function (f0h5tq) {
  var $z38 = f0h5tq[k[87546]];console[k[60468]](k[87547] + $z38 + k[87548] + ($z38 == 0x1) + k[87549] + f0h5tq[k[87389]] + k[87550] + window[k[87489]][k[87495]]);if (!f0h5tq[k[87389]] || window['F$I860L'](window[k[87489]][k[87495]], f0h5tq[k[87389]]) < 0x0) console[k[60468]](k[87551]), F$L6[k[87498]] = k[87552], F$L6[k[87500]] = k[87553], F$L6[k[87502]] = k[87554], F$L6[k[64161]] = k[87555], F$L6[k[83779]] = k[87556], F$L6[k[87557]] = k[87558], F$L6[k[60715]] = ![];else window['F$I860L'](window[k[87489]][k[87495]], f0h5tq[k[87389]]) == 0x0 ? (console[k[60468]](k[87559]), F$L6[k[87498]] = k[87499], F$L6[k[87500]] = k[87501], F$L6[k[87502]] = k[87503], F$L6[k[64161]] = k[87560], F$L6[k[83779]] = k[87556], F$L6[k[87557]] = k[87561], F$L6[k[60715]] = !![]) : (console[k[60468]](k[87562]), F$L6[k[87498]] = k[87499], F$L6[k[87500]] = k[87501], F$L6[k[87502]] = k[87503], F$L6[k[64161]] = k[87560], F$L6[k[83779]] = k[87556], F$L6[k[87557]] = k[87561], F$L6[k[60715]] = ![]);F$L6[k[87506]] = config[k[87563]] ? config[k[87563]] : 0x0, this['F$8L06'](), this['F$8L60'](), window[k[87564]] = 0x5, F$0L86({ 'title': k[87565] }), fcdsn[k[87296]](this['F$6L0'][k[60073]](this));
}, window[k[87564]] = 0x5, window['F$6L0'] = function (o4j, wsjdx) {
  if (o4j == 0x0 && wsjdx && wsjdx[k[87566]]) {
    F$L6[k[87567]] = wsjdx[k[87566]];var jodwc = this;F$0L86({ 'title': k[87568] }), sendApi(F$L6[k[87498]], k[87569], { 'platform': F$L6[k[87496]], 'partner_id': F$L6[k[82500]], 'token': wsjdx[k[87566]], 'game_pkg': F$L6[k[84067]], 'deviceId': F$L6[k[84069]], 'scene': k[87570] + F$L6[k[87506]] }, this['F$80L6'][k[60073]](this), F$86L, F$60);
  } else wsjdx && wsjdx[k[84240]] && window[k[87564]] > 0x0 && (wsjdx[k[84240]][k[60114]](k[87571]) != -0x1 || wsjdx[k[84240]][k[60114]](k[87572]) != -0x1 || wsjdx[k[84240]][k[60114]](k[87573]) != -0x1 || wsjdx[k[84240]][k[60114]](k[87574]) != -0x1 || wsjdx[k[84240]][k[60114]](k[87575]) != -0x1 || wsjdx[k[84240]][k[60114]](k[87576]) != -0x1) ? (window[k[87564]]--, fcdsn[k[87296]](this['F$6L0'][k[60073]](this))) : (window['F$L60'](k[87577], JSON[k[64147]]({ 'status': o4j, 'data': wsjdx })), window['F$08L6'](k[87578] + (wsjdx && wsjdx[k[84240]] ? '，' + wsjdx[k[84240]] : '')));
}, window['F$80L6'] = function (mfbht) {
  if (!mfbht) {
    window['F$L60'](k[87579], k[87580]), window['F$08L6'](k[87581]);return;
  }if (mfbht[k[63765]] != k[69216]) {
    window['F$L60'](k[87579], JSON[k[64147]](mfbht)), window['F$08L6'](k[87582] + mfbht[k[63765]]);return;
  }F$L6[k[82499]] = String(mfbht[k[84066]]), F$L6[k[84066]] = String(mfbht[k[84066]]), F$L6[k[84038]] = String(mfbht[k[84038]]), F$L6[k[84065]] = String(mfbht[k[84038]]), F$L6[k[84068]] = String(mfbht[k[84068]]), F$L6[k[87583]] = String(mfbht[k[70660]]), F$L6[k[87584]] = String(mfbht[k[60822]]), F$L6[k[70660]] = '';var h5tqk0 = this;F$0L86({ 'title': k[87585] }), sendApi(F$L6[k[87498]], k[87586], { 'partner_id': F$L6[k[82500]], 'uid': F$L6[k[84066]], 'version': F$L6[k[64343]], 'game_pkg': F$L6[k[84067]], 'device': F$L6[k[84069]] }, h5tqk0['F$806L'][k[60073]](h5tqk0), F$86L, F$60);
}, window['F$806L'] = function (_56k2) {
  if (!_56k2) {
    window['F$08L6'](k[87587]);return;
  }if (_56k2[k[63765]] != k[69216]) {
    window['F$08L6'](k[87588] + _56k2[k[63765]]);return;
  }if (!_56k2[k[60011]] || _56k2[k[60011]][k[60013]] == 0x0) {
    window['F$08L6'](k[87589]);return;
  }F$L6[k[60611]] = _56k2[k[87590]], F$L6[k[84061]] = { 'server_id': String(_56k2[k[60011]][0x0][k[70674]]), 'server_name': String(_56k2[k[60011]][0x0][k[87591]]), 'entry_ip': _56k2[k[60011]][0x0][k[84089]], 'entry_port': parseInt(_56k2[k[60011]][0x0][k[84090]]), 'status': F$L80(_56k2[k[60011]][0x0]), 'start_time': _56k2[k[60011]][0x0][k[87592]], 'cdn': F$L6[k[64161]] }, this['F$6L80']();
}, window['F$6L80'] = function () {
  if (F$L6[k[60611]] == 0x1) {
    var scdo6j = F$L6[k[84061]][k[60105]];if (scdo6j === -0x1 || scdo6j === 0x0) {
      window['F$08L6'](scdo6j === -0x1 ? k[87593] : k[87594]);return;
    }F$608L(0x0, F$L6[k[84061]][k[70674]]), window[k[87404]][k[60144]][k[87595]](F$L6[k[60611]]);
  } else window[k[87404]][k[60144]][k[87596]](), F$0L68();window['F$L8'] = !![], window['F$68L0'](), window['F$6L08']();
}, window['F$8L06'] = function () {
  sendApi(F$L6[k[87498]], k[87597], { 'game_pkg': F$L6[k[84067]], 'version_name': F$L6[k[87557]] }, this[k[87598]][k[60073]](this), F$86L, F$60);
}, window[k[87598]] = function (odscw) {
  if (!odscw) {
    window['F$08L6'](k[87599]);return;
  }if (odscw[k[63765]] != k[69216]) {
    window['F$08L6'](k[87600] + odscw[k[63765]]);return;
  }if (!odscw[k[60011]] || !odscw[k[60011]][k[64343]]) {
    window['F$08L6'](k[87601] + (odscw[k[60011]] && odscw[k[60011]][k[64343]]));return;
  }odscw[k[60011]][k[87602]] && odscw[k[60011]][k[87602]][k[60013]] > 0xa && (F$L6[k[87603]] = odscw[k[60011]][k[87602]], F$L6[k[64161]] = odscw[k[60011]][k[87602]]), odscw[k[60011]][k[64343]] && (F$L6[k[60100]] = odscw[k[60011]][k[64343]]), console[k[60077]](k[84199] + F$L6[k[60100]] + k[87604] + F$L6[k[87557]]), window['F$L68'] = !![], window['F$68L0'](), window['F$6L08']();
}, window[k[87605]], window['F$8L60'] = function () {
  sendApi(F$L6[k[87498]], k[87606], { 'game_pkg': F$L6[k[84067]] }, this['F$860L'][k[60073]](this), F$86L, F$60);
}, window['F$860L'] = function (e8zx) {
  if (e8zx[k[63765]] === k[69216] && e8zx[k[60011]]) {
    window[k[87605]] = e8zx[k[60011]];for (var edxsw in e8zx[k[60011]]) {
      F$L6[edxsw] = e8zx[k[60011]][edxsw];
    }
  } else console[k[60077]](k[87607] + e8zx[k[63765]]);window['F$8L'] = !![], window['F$6L08']();
}, window[k[87608]] = function (ze78, bfmti, ubifm, fmih, bguv9, imhtfb, scodj, sxndj, th0fmq) {
  bguv9 = String(bguv9);var qhk_50 = scodj,
      iub9 = sxndj;F$L6[k[87494]][bguv9] = { 'productid': bguv9, 'productname': qhk_50, 'productdesc': iub9, 'roleid': ze78, 'rolename': bfmti, 'rolelevel': ubifm, 'price': imhtfb, 'callback': th0fmq }, sendApi(F$L6[k[87502]], k[87609], { 'game_pkg': F$L6[k[84067]], 'server_id': F$L6[k[84061]][k[70674]], 'server_name': F$L6[k[84061]][k[87591]], 'level': ubifm, 'uid': F$L6[k[84066]], 'role_id': ze78, 'role_name': bfmti, 'product_id': bguv9, 'product_name': qhk_50, 'product_desc': iub9, 'money': imhtfb, 'partner_id': F$L6[k[82500]] }, toPayCallBack, F$86L, F$60);
}, window[k[87610]] = function (y$73ar) {
  if (y$73ar) {
    if (y$73ar[k[87611]] === 0xc8 || y$73ar[k[63765]] == k[69216]) {
      var tibvmf = F$L6[k[87494]][String(y$73ar[k[87612]])];if (tibvmf[k[60328]]) tibvmf[k[60328]](y$73ar[k[87612]], y$73ar[k[87613]], -0x1);fcdsn[k[87340]]({ 'cpbill': y$73ar[k[87613]], 'productid': y$73ar[k[87612]], 'productname': tibvmf[k[87614]], 'productdesc': tibvmf[k[87615]], 'serverid': F$L6[k[84061]][k[70674]], 'servername': F$L6[k[84061]][k[87591]], 'roleid': tibvmf[k[87616]], 'rolename': tibvmf[k[87617]], 'rolelevel': tibvmf[k[87618]], 'price': tibvmf[k[85663]], 'extension': JSON[k[64147]]({ 'cp_order_id': y$73ar[k[87613]] }) }, function (v9u1ib, osdwcj) {
        tibvmf[k[60328]] && v9u1ib == 0x0 && tibvmf[k[60328]](y$73ar[k[87612]], y$73ar[k[87613]], v9u1ib);console[k[60077]](JSON[k[64147]]({ 'type': k[87619], 'status': v9u1ib, 'data': y$73ar, 'role_name': tibvmf[k[87617]] }));if (v9u1ib === 0x0) {} else {
          if (v9u1ib === 0x1) {} else {
            if (v9u1ib === 0x2) {}
          }
        }
      });
    } else alert(y$73ar[k[60077]]);
  }
}, window['F$86L0'] = function () {}, window['F$086'] = function (qh0_k, ub9vi1, $7er8, _kq24, exsdnw) {
  fcdsn[k[87378]](F$L6[k[84061]][k[70674]], F$L6[k[84061]][k[87591]] || F$L6[k[84061]][k[70674]], qh0_k, ub9vi1, $7er8), sendApi(F$L6[k[87498]], k[87620], { 'game_pkg': F$L6[k[84067]], 'server_id': F$L6[k[84061]][k[70674]], 'role_id': qh0_k, 'uid': F$L6[k[84066]], 'role_name': ub9vi1, 'role_type': _kq24, 'level': $7er8 });
}, window['F$068'] = function (sxnwed, djnscw, xjsn, ft0mhi, x87ezr, k5qh_0, vfbmt, xe87r, uvfmi, z8x7) {
  F$L6[k[87394]] = sxnwed, F$L6[k[64273]] = djnscw, F$L6[k[87395]] = xjsn, fcdsn[k[87379]](F$L6[k[84061]][k[70674]], F$L6[k[84061]][k[87591]] || F$L6[k[84061]][k[70674]], sxnwed, djnscw, xjsn), sendApi(F$L6[k[87498]], k[87621], { 'game_pkg': F$L6[k[84067]], 'server_id': F$L6[k[84061]][k[70674]], 'role_id': sxnwed, 'uid': F$L6[k[84066]], 'role_name': djnscw, 'role_type': ft0mhi, 'level': xjsn, 'evolution': x87ezr });
}, window['F$806'] = function (e7$8, ez8nx, r3$7, fht5, fvtim, q4_2, z$83r7, r8z$37, j42o6c, x8rze) {
  F$L6[k[87394]] = e7$8, F$L6[k[64273]] = ez8nx, F$L6[k[87395]] = r3$7, fcdsn[k[87380]](F$L6[k[84061]][k[70674]], F$L6[k[84061]][k[87591]] || F$L6[k[84061]][k[70674]], e7$8, ez8nx, r3$7), sendApi(F$L6[k[87498]], k[87621], { 'game_pkg': F$L6[k[84067]], 'server_id': F$L6[k[84061]][k[70674]], 'role_id': e7$8, 'uid': F$L6[k[84066]], 'role_name': ez8nx, 'role_type': fht5, 'level': r3$7, 'evolution': fvtim });
}, window['F$860'] = function (e8nr) {}, window['F$08'] = function (djwso) {
  fcdsn[k[87316]](k[87316], function (rz38) {
    djwso && djwso(rz38);
  });
}, window[k[83760]] = function () {
  fcdsn[k[83760]]();
}, window[k[87622]] = function () {
  fcdsn[k[82395]]();
}, window[k[87623]] = function (nsxjd, ra7$3y, c62odj, mqt0hf, $z738, _hk5, htk5, _50qk4) {
  _50qk4 = _50qk4 || F$L6[k[84061]][k[70674]], sendApi(F$L6[k[87498]], k[87624], { 'phone': nsxjd, 'role_id': ra7$3y, 'uid': F$L6[k[84066]], 'game_pkg': F$L6[k[84067]], 'partner_id': F$L6[k[82500]], 'server_id': _50qk4 }, htk5);
}, window[k[70074]] = function (esxzwn) {
  window['F$608'] = esxzwn, window['F$608'] && window['F$80'] && (console[k[60077]](k[87481] + window['F$80'][k[60750]]), window['F$608'](window['F$80']), window['F$80'] = null);
}, window['F$680'] = function (qkh_5, bumvfi, xnsdwe, ivfmub) {
  window[k[60022]](k[87625], { 'game_pkg': window['F$L6'][k[84067]], 'role_id': bumvfi, 'server_id': xnsdwe }, ivfmub);
}, window['F$L086'] = function (ftq0m, fthib) {
  function u9bv1g(hmtfbi) {
    var k6_o42 = [],
        r837z = [],
        gu9b1v = window[k[60540]][k[87626]];for (var oc24j6 in gu9b1v) {
      var k426_5 = Number(oc24j6);(!ftq0m || !ftq0m[k[60013]] || ftq0m[k[60114]](k426_5) != -0x1) && (r837z[k[60029]](gu9b1v[oc24j6]), k6_o42[k[60029]]([k426_5, 0x3]));
    }window['F$I860L'](window[k[87405]], k[87627]) >= 0x0 ? (console[k[60468]](k[87628]), fcdsn[k[87356]] && fcdsn[k[87356]](r837z, function (vimft) {
      console[k[60468]](k[87629]), console[k[60468]](vimft);if (vimft && vimft[k[84240]] == k[87357]) for (var k_2q45 in gu9b1v) {
        if (vimft[gu9b1v[k_2q45]] == k[87260]) {
          var b9uvg1 = Number(k_2q45);for (var r387y = 0x0; r387y < k6_o42[k[60013]]; r387y++) {
            if (k6_o42[r387y][0x0] == b9uvg1) {
              k6_o42[r387y][0x1] = 0x1;break;
            }
          }
        }
      }window['F$I860L'](window[k[87405]], k[87630]) >= 0x0 ? wx[k[87631]]({ 'withSubscriptions': !![], 'success': function (nxwse) {
          var djocs = nxwse[k[87632]][k[87633]];if (djocs) {
            console[k[60468]](k[87634]), console[k[60468]](djocs);for (var vifu in gu9b1v) {
              if (djocs[gu9b1v[vifu]] == k[87260]) {
                var xre8nz = Number(vifu);for (var k4_q25 = 0x0; k4_q25 < k6_o42[k[60013]]; k4_q25++) {
                  if (k6_o42[k4_q25][0x0] == xre8nz) {
                    k6_o42[k4_q25][0x1] = 0x2;break;
                  }
                }
              }
            }console[k[60468]](k6_o42), fthib && fthib(k6_o42);
          } else console[k[60468]](k[87635]), console[k[60468]](nxwse), console[k[60468]](k6_o42), fthib && fthib(k6_o42);
        }, 'fail': function () {
          console[k[60468]](k[87636]), console[k[60468]](k6_o42), fthib && fthib(k6_o42);
        } }) : (console[k[60468]](k[87637] + window[k[87405]]), console[k[60468]](k6_o42), fthib && fthib(k6_o42));
    })) : (console[k[60468]](k[87638] + window[k[87405]]), console[k[60468]](k6_o42), fthib && fthib(k6_o42)), wx[k[87639]](u9bv1g);
  }wx[k[87640]](u9bv1g);
}, window['F$L068'] = { 'isSuccess': ![], 'level': k[87641], 'isCharging': ![] }, window['F$L806'] = function (nxdswj) {
  wx[k[87470]]({ 'success': function (xwndse) {
      var co6j42 = window['F$L068'];co6j42[k[87642]] = !![], co6j42[k[64249]] = Number(xwndse[k[64249]])['toFixed'](0x0), co6j42[k[87473]] = xwndse[k[87473]], nxdswj && nxdswj(co6j42[k[87642]], co6j42[k[64249]], co6j42[k[87473]]);
    }, 'fail': function (ifmtbv) {
      console[k[60468]](k[87643], ifmtbv[k[84240]]);var rz$78e = window['F$L068'];nxdswj && nxdswj(rz$78e[k[87642]], rz$78e[k[64249]], rz$78e[k[87473]]);
    } });
}, window[k[60022]] = function (tbfhmi, imthb, y3pa$7, mfibvu, _5k0h, z7r8$3, hq5t0, nxedsw) {
  if (mfibvu == undefined) mfibvu = 0x1;wx[k[60463]]({ 'url': tbfhmi, 'method': hq5t0 || k[83961], 'responseType': k[64068], 'data': imthb, 'header': { 'content-type': nxedsw || k[87537] }, 'success': function (sdwcnj) {
      DEBUG && console[k[60468]](k[87644], tbfhmi, info, sdwcnj);if (sdwcnj && sdwcnj[k[84304]] == 0xc8) {
        var tk5q0 = sdwcnj[k[60011]];!z7r8$3 || z7r8$3(tk5q0) ? y3pa$7 && y3pa$7(tk5q0) : window['sendFail'](tbfhmi, imthb, y3pa$7, mfibvu, _5k0h, z7r8$3, sdwcnj);
      } else window['sendFail'](tbfhmi, imthb, y3pa$7, mfibvu, _5k0h, z7r8$3, sdwcnj);
    }, 'fail': function (swndxe) {
      DEBUG && console[k[60468]](k[87645], tbfhmi, info, swndxe), window['sendFail'](tbfhmi, imthb, y3pa$7, mfibvu, _5k0h, z7r8$3, swndxe);
    }, 'complete': function () {} });
}, window['sendFail'] = function ($e8r7, kq0_, y3ra, nwdxs, en8xz, vubi19, um1ib) {
  nwdxs - 0x1 > 0x0 ? setTimeout(function () {
    window[k[60022]]($e8r7, kq0_, y3ra, nwdxs - 0x1, en8xz, vubi19);
  }, 0x3e8) : en8xz && en8xz(JSON[k[64147]]({ 'url': $e8r7, 'response': um1ib }));
}, window[k[87646]] = function (tmbfv, fhmbit, o462_c, ojwcds, j4c2o, ezwn8, odc62j) {
  !o462_c && (o462_c = {});var iuf = Math[k[60117]](Date[k[60082]]() / 0x3e8);o462_c[k[60822]] = iuf, o462_c[k[87647]] = fhmbit;var nsxd = Object[k[60260]](o462_c)[k[61009]](),
      k_0qh5 = '',
      nxezr8 = '';for (var $87r = 0x0; $87r < nsxd[k[60013]]; $87r++) {
    k_0qh5 = k_0qh5 + ($87r == 0x0 ? '' : '&') + nsxd[$87r] + o462_c[nsxd[$87r]], nxezr8 = nxezr8 + ($87r == 0x0 ? '' : '&') + nsxd[$87r] + '=' + encodeURIComponent(o462_c[nsxd[$87r]]);
  }k_0qh5 = k_0qh5 + F$L6[k[87504]];var r$z3 = k[87648] + md5(k_0qh5);send(tmbfv + '?' + nxezr8 + (nxezr8 == '' ? '' : '&') + r$z3, null, ojwcds, j4c2o, ezwn8, odc62j || function (djc62o) {
    return djc62o[k[63765]] == k[69216];
  }, null, k[87301]);
}, window['F$L860'] = function (mfibuv, u1vm) {
  var z7e$8r = 0x0;F$L6[k[84061]] && (z7e$8r = F$L6[k[84061]][k[70674]]), sendApi(F$L6[k[87500]], k[87649], { 'partnerId': F$L6[k[82500]], 'gamePkg': F$L6[k[84067]], 'logTime': Math[k[60117]](Date[k[60082]]() / 0x3e8), 'platformUid': F$L6[k[84068]], 'type': mfibuv, 'serverId': z7e$8r }, null, 0x2, null, function () {
    return !![];
  });
}, window['F$L608'] = function (mfibht) {
  sendApi(F$L6[k[87498]], k[87650], { 'partner_id': F$L6[k[82500]], 'uid': F$L6[k[84066]], 'version': F$L6[k[64343]], 'game_pkg': F$L6[k[84067]], 'device': F$L6[k[84069]] }, F$L680, F$86L, F$60);
}, window['F$L680'] = function (sxwdne) {
  if (sxwdne[k[63765]] === k[69216] && sxwdne[k[60011]]) {
    sxwdne[k[60011]][k[65125]]({ 'id': -0x2, 'name': k[87651] }), sxwdne[k[60011]][k[65125]]({ 'id': -0x1, 'name': k[87652] }), F$L6[k[87653]] = sxwdne[k[60011]];if (window[k[71418]]) window[k[71418]][k[87654]]();
  } else F$L6[k[87655]] = ![], window['F$08L6'](k[87656] + sxwdne[k[63765]]);
}, window['F$08L'] = function (mi1bv) {
  sendApi(F$L6[k[87498]], k[87657], { 'partner_id': F$L6[k[82500]], 'uid': F$L6[k[84066]], 'version': F$L6[k[64343]], 'game_pkg': F$L6[k[84067]], 'device': F$L6[k[84069]] }, F$0L8, F$86L, F$60);
}, window['F$0L8'] = function (dsjc6) {
  F$L6[k[87658]] = ![];if (dsjc6[k[63765]] === k[69216] && dsjc6[k[60011]]) {
    for (var yra7 = 0x0; yra7 < dsjc6[k[60011]][k[60013]]; yra7++) {
      dsjc6[k[60011]][yra7][k[60105]] = F$L80(dsjc6[k[60011]][yra7]);
    }F$L6[k[87507]][-0x1] = window[k[87659]](dsjc6[k[60011]]), window[k[71418]][k[87660]](-0x1);
  } else window['F$08L6'](k[87661] + dsjc6[k[63765]]);
}, window[k[87662]] = function (dcsojw) {
  sendApi(F$L6[k[87498]], k[87657], { 'partner_id': F$L6[k[82500]], 'uid': F$L6[k[84066]], 'version': F$L6[k[64343]], 'game_pkg': F$L6[k[84067]], 'device': F$L6[k[84069]] }, dcsojw, F$86L, F$60);
}, window['F$80L'] = function (f0t5h, mibfh) {
  sendApi(F$L6[k[87498]], k[87663], { 'partner_id': F$L6[k[82500]], 'uid': F$L6[k[84066]], 'version': F$L6[k[64343]], 'game_pkg': F$L6[k[84067]], 'device': F$L6[k[84069]], 'server_group_id': mibfh }, F$8L0, F$86L, F$60);
}, window['F$8L0'] = function (ya) {
  F$L6[k[87658]] = ![];if (ya[k[63765]] === k[69216] && ya[k[60011]] && ya[k[60011]][k[60011]]) {
    var y87 = ya[k[60011]][k[87664]],
        hkq5 = [];for (var uibv1 = 0x0; uibv1 < ya[k[60011]][k[60011]][k[60013]]; uibv1++) {
      ya[k[60011]][k[60011]][uibv1][k[60105]] = F$L80(ya[k[60011]][k[60011]][uibv1]), (hkq5[k[60013]] == 0x0 || ya[k[60011]][k[60011]][uibv1][k[60105]] != 0x0) && (hkq5[hkq5[k[60013]]] = ya[k[60011]][k[60011]][uibv1]);
    }F$L6[k[87507]][y87] = window[k[87659]](hkq5), window[k[71418]][k[87660]](y87);
  } else window['F$08L6'](k[87665] + ya[k[63765]]);
}, window['F$I86L'] = function (mbfv) {
  sendApi(F$L6[k[87498]], k[87666], { 'partner_id': F$L6[k[82500]], 'uid': F$L6[k[84066]], 'version': F$L6[k[64343]], 'game_pkg': F$L6[k[84067]], 'device': F$L6[k[84069]] }, reqServerRecommendCallBack, F$86L, F$60);
}, window[k[87667]] = function (tfmh) {
  F$L6[k[87658]] = ![];if (tfmh[k[63765]] === k[69216] && tfmh[k[60011]]) {
    for (var cjd6o = 0x0; cjd6o < tfmh[k[60011]][k[60013]]; cjd6o++) {
      tfmh[k[60011]][cjd6o][k[60105]] = F$L80(tfmh[k[60011]][cjd6o]);
    }F$L6[k[87507]][-0x2] = window[k[87659]](tfmh[k[60011]]), window[k[71418]][k[87660]](-0x2);
  } else alert(k[87668] + tfmh[k[63765]]);
}, window[k[87659]] = function (tm0h) {
  if (!tm0h && tm0h[k[60013]] <= 0x0) return tm0h;for (let _4q50 = 0x0; _4q50 < tm0h[k[60013]]; _4q50++) {
    tm0h[_4q50][k[87669]] && tm0h[_4q50][k[87669]] == 0x1 && (tm0h[_4q50][k[87591]] += k[87670]);
  }return tm0h;
}, window['F$L08'] = function (jc264, vfiu) {
  jc264 = jc264 || F$L6[k[84061]][k[70674]], sendApi(F$L6[k[87498]], k[87671], { 'type': '4', 'game_pkg': F$L6[k[84067]], 'server_id': jc264 }, vfiu);
}, window[k[87672]] = function (z8xern, q_k524, oc2jd, re7x8) {
  oc2jd = oc2jd || F$L6[k[84061]][k[70674]], sendApi(F$L6[k[87498]], k[87673], { 'type': z8xern, 'game_pkg': q_k524, 'server_id': oc2jd }, re7x8);
}, window['F$L80'] = function (k50t) {
  if (k50t) {
    if (k50t[k[60105]] == 0x1) {
      if (k50t[k[87674]] == 0x1) return 0x2;else return 0x1;
    } else return k50t[k[60105]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['F$608L'] = function (kq_5, tq0fm) {
  F$L6[k[87675]] = { 'step': kq_5, 'server_id': tq0fm };var ftq5h = this;F$0L86({ 'title': k[87676] }), sendApi(F$L6[k[87498]], k[87677], { 'partner_id': F$L6[k[82500]], 'uid': F$L6[k[84066]], 'game_pkg': F$L6[k[84067]], 'server_id': tq0fm, 'platform': F$L6[k[84038]], 'platform_uid': F$L6[k[84068]], 'check_login_time': F$L6[k[87584]], 'check_login_sign': F$L6[k[87583]], 'version_name': F$L6[k[87557]] }, F$60L8, F$86L, F$60, function (zrex87) {
    return zrex87[k[63765]] == k[69216] || zrex87[k[60077]] == k[87678] || zrex87[k[60077]] == k[87679];
  });
}, window['F$60L8'] = function (r3z$87) {
  var _5k = this;if (r3z$87[k[63765]] === k[69216] && r3z$87[k[60011]]) {
    var neszw = F$L6[k[84061]];neszw[k[87680]] = F$L6[k[87508]], neszw[k[70660]] = String(r3z$87[k[60011]][k[87681]]), neszw[k[84040]] = parseInt(r3z$87[k[60011]][k[60822]]);if (r3z$87[k[60011]][k[84039]]) neszw[k[84039]] = parseInt(r3z$87[k[60011]][k[84039]]);else neszw[k[84039]] = parseInt(r3z$87[k[60011]][k[70674]]);neszw[k[87682]] = 0x0, neszw[k[64161]] = F$L6[k[87603]], neszw[k[87683]] = r3z$87[k[60011]][k[87684]], neszw[k[87685]] = r3z$87[k[60011]][k[87685]], console[k[60468]](k[87686] + JSON[k[64147]](neszw[k[87685]])), F$L6[k[60611]] == 0x1 && neszw[k[87685]] && neszw[k[87685]][k[87687]] == 0x1 && (F$L6[k[87688]] = 0x1, window[k[87404]][k[60144]]['F$I6L']()), F$680L();
  } else F$L6[k[87675]][k[66601]] >= 0x3 ? (F$60(JSON[k[64147]](r3z$87)), window['F$08L6'](k[87689] + r3z$87[k[63765]])) : sendApi(F$L6[k[87498]], k[87569], { 'platform': F$L6[k[87496]], 'partner_id': F$L6[k[82500]], 'token': F$L6[k[87567]], 'game_pkg': F$L6[k[84067]], 'deviceId': F$L6[k[84069]], 'scene': k[87570] + F$L6[k[87506]] }, function (ap$7y3) {
    if (!ap$7y3 || ap$7y3[k[63765]] != k[69216]) {
      window['F$08L6'](k[87582] + ap$7y3 && ap$7y3[k[63765]]);return;
    }F$L6[k[87583]] = String(ap$7y3[k[70660]]), F$L6[k[87584]] = String(ap$7y3[k[60822]]), setTimeout(function () {
      F$608L(F$L6[k[87675]][k[66601]] + 0x1, F$L6[k[87675]][k[70674]]);
    }, 0x5dc);
  }, F$86L, F$60, function (kq_542) {
    return kq_542[k[63765]] == k[69216] || kq_542[k[63765]] == k[84365];
  });
}, window['F$680L'] = function () {
  ServerLoading[k[60144]][k[87595]](F$L6[k[60611]]), window['F$86'] = !![], window['F$6L08']();
}, window['F$68L0'] = function () {
  if (window['F$68'] && window['F$L86'] && window[k[87514]] && window[k[87515]] && window['F$L68'] && window['F$L8']) {
    if (!window[k[87190]][k[60144]]) {
      console[k[60468]](k[87690] + window[k[87190]][k[60144]]);var fht0i = wx[k[87691]](),
          wjxds = fht0i[k[60750]] ? fht0i[k[60750]] : 0x0,
          ern = { 'cdn': window['F$L6'][k[64161]], 'spareCdn': window['F$L6'][k[83779]], 'newRegister': window['F$L6'][k[60611]], 'wxPC': window['F$L6'][k[83782]], 'wxIOS': window['F$L6'][k[61005]], 'wxAndroid': window['F$L6'][k[70509]], 'wxParam': { 'limitLoad': window['F$L6']['F$I086L'], 'benchmarkLevel': window['F$L6']['F$I0L86'], 'wxFrom': window[k[60540]][k[87563]] == k[87692] ? 0x1 : 0x0, 'wxSDKVersion': window[k[87405]] }, 'configType': window['F$L6'][k[70993]], 'exposeType': window['F$L6'][k[60691]], 'scene': wjxds };new window[k[87190]](ern, window['F$L6'][k[60100]], window['F$I08L6']);
    }
  }
}, window['F$6L08'] = function () {
  if (window['F$68'] && window['F$L86'] && window[k[87514]] && window[k[87515]] && window['F$L68'] && window['F$L8'] && window['F$86'] && window['F$8L']) {
    F$0L68();if (!F$68L) {
      F$68L = !![];if (!window[k[87190]][k[60144]]) window['F$68L0']();var dsxnew = 0x0,
          imbhf = wx[k[87693]]();imbhf && (window['F$L6'][k[87459]] && (dsxnew = imbhf[k[60316]]), console[k[60077]](k[87694] + imbhf[k[60316]] + k[87695] + imbhf[k[61136]] + k[87696] + imbhf[k[61138]] + k[87697] + imbhf[k[61137]] + k[87698] + imbhf[k[60172]] + k[87699] + imbhf[k[60173]]));var sjcdn = {};for (const kq0_54 in F$L6[k[84061]]) {
        sjcdn[kq0_54] = F$L6[k[84061]][kq0_54];
      }var himtb = { 'channel': window['F$L6'][k[84065]], 'account': window['F$L6'][k[84066]], 'userId': window['F$L6'][k[82499]], 'cdn': window['F$L6'][k[64161]], 'data': window['F$L6'][k[60011]], 'package': window['F$L6'][k[83780]], 'newRegister': window['F$L6'][k[60611]], 'pkgName': window['F$L6'][k[84067]], 'partnerId': window['F$L6'][k[82500]], 'platform_uid': window['F$L6'][k[84068]], 'deviceId': window['F$L6'][k[84069]], 'selectedServer': sjcdn, 'configType': window['F$L6'][k[70993]], 'exposeType': window['F$L6'][k[60691]], 'debugUsers': window['F$L6'][k[71369]], 'wxMenuTop': dsxnew, 'wxShield': window['F$L6'][k[60715]] };if (window[k[87605]]) for (var iftmhb in window[k[87605]]) {
        himtb[iftmhb] = window[k[87605]][iftmhb];
      }window[k[87190]][k[60144]]['F$6LI'](himtb), setTimeout(() => {
        !F$L6[k[60715]] && new minitool();
      }, 0x2710);
    }
  } else console[k[60077]](k[87700] + window['F$68'] + k[87701] + window['F$L86'] + k[87702] + window[k[87514]] + k[87703] + window[k[87515]] + k[87704] + window['F$L68'] + k[87705] + window['F$L8'] + k[87706] + window['F$86'] + k[87707] + window['F$8L']);
};