var k = wx.$f;
import 'fffmain.js';