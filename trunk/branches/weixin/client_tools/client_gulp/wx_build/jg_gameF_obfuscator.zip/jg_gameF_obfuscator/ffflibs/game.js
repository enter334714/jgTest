var k = wx.$f;
require(k[87897]);