var k = wx.$f;
console[k[60077]](k[87386]), window[k[87387]], wx[k[87388]](function (mibftv) {
  if (mibftv) {
    if (mibftv[k[64163]]) {
      var z7e8r$ = window[k[60540]][k[87389]][k[64330]](new RegExp(/\./, 'g'), '_'),
          _h5k0q = mibftv[k[64163]],
          oj26cd = _h5k0q[k[71185]](/(ffffffff\/fffgame.js:)[0-9]{1,60}(:)/g);if (oj26cd) for (var qk0 = 0x0; qk0 < oj26cd[k[60013]]; qk0++) {
        if (oj26cd[qk0] && oj26cd[qk0][k[60013]] > 0x0) {
          var o2_k4 = parseInt(oj26cd[qk0][k[64330]](k[87390], '')[k[64330]](':', ''));_h5k0q = _h5k0q[k[64330]](oj26cd[qk0], oj26cd[qk0][k[64330]](':' + o2_k4 + ':', ':' + (o2_k4 - 0x2) + ':'));
        }
      }_h5k0q = _h5k0q[k[64330]](new RegExp(k[87391], 'g'), k[87392] + z7e8r$ + k[84164]), _h5k0q = _h5k0q[k[64330]](new RegExp(k[87393], 'g'), k[87392] + z7e8r$ + k[84164]), mibftv[k[64163]] = _h5k0q;
    }var mb1vu = { 'id': window['F$L6'][k[87394]], 'role': window['F$L6'][k[64273]], 'level': window['F$L6'][k[87395]], 'user': window['F$L6'][k[84066]], 'version': window['F$L6'][k[60100]], 'cdn': window['F$L6'][k[64161]], 'pkgName': window['F$L6'][k[84067]], 'gamever': window[k[60540]][k[87389]], 'serverid': window['F$L6'][k[84061]] ? window['F$L6'][k[84061]][k[70674]] : 0x0, 'systemInfo': window[k[87396]], 'error': k[87397], 'stack': mibftv ? mibftv[k[64163]] : '' },
        thfimb = JSON[k[64147]](mb1vu);console[k[60124]](k[87398] + thfimb), (!window[k[87387]] || window[k[87387]] != mb1vu[k[60124]]) && (window[k[87387]] = mb1vu[k[60124]], window['F$0L'](mb1vu));
  }
});import 'fffmd5min.js';import 'fffzlibs.js';window[k[87399]] = require(k[87400]);import 'fffindex.js';import 'ffflibsmin.js';import 'fffwxmini.js';import 'fffinitmin.js';import 'SyMiniTool.js';console[k[60077]](k[87401]), console[k[60077]](k[87402]), F$0L86({ 'title': k[87403] });var fmtvibf = { 'F$I06L8': !![] };new window[k[87404]](fmtvibf), window[k[87404]][k[60144]]['F$I8L60']();if (window['F$I0L68']) clearInterval(window['F$I0L68']);window['F$I0L68'] = null, window['F$I860L'] = function (_4c26o, rx8ne) {
  if (!_4c26o || !rx8ne) return 0x0;_4c26o = _4c26o[k[60015]]('.'), rx8ne = rx8ne[k[60015]]('.');const sjncdw = Math[k[60824]](_4c26o[k[60013]], rx8ne[k[60013]]);while (_4c26o[k[60013]] < sjncdw) {
    _4c26o[k[60029]]('0');
  }while (rx8ne[k[60013]] < sjncdw) {
    rx8ne[k[60029]]('0');
  }for (var wzn8xe = 0x0; wzn8xe < sjncdw; wzn8xe++) {
    const k0h_5q = parseInt(_4c26o[wzn8xe]),
          zxen8r = parseInt(rx8ne[wzn8xe]);if (k0h_5q > zxen8r) return 0x1;else {
      if (k0h_5q < zxen8r) return -0x1;
    }
  }return 0x0;
}, window[k[87405]] = wx[k[87406]]()[k[87405]], console[k[60468]](k[87407] + window[k[87405]]);var fdco62j = wx[k[87408]]();fdco62j['onCheckForUpdate'](function (hmbitf) {
  console[k[60468]](k[87409] + hmbitf[k[87410]]);
}), fdco62j[k[87411]](function () {
  wx[k[87412]]({ 'title': k[87413], 'content': k[87414], 'showCancel': ![], 'success': function ($3a7r) {
      fdco62j[k[87415]]();
    } });
}), fdco62j['onUpdateFailed'](function () {
  console[k[60468]](k[87416]);
}), window['F$I86L0'] = function () {
  console[k[60468]](k[87417]);var ensxw = wx[k[87418]]({ 'name': k[87419], 'success': function (ubimv) {
      console[k[60468]](k[87420]), console[k[60468]](ubimv), ubimv && ubimv[k[84240]] == k[87421] ? (window['F$68'] = !![], window['F$68L0'](), window['F$6L08']()) : setTimeout(function () {
        window['F$I86L0']();
      }, 0x1f4);
    }, 'fail': function (sxezw) {
      console[k[60468]](k[87422]), console[k[60468]](sxezw), setTimeout(function () {
        window['F$I86L0']();
      }, 0x1f4);
    } });ensxw && ensxw[k[87423]](ry87$3 => {});
}, window['F$IL068'] = function () {
  console[k[60468]](k[87424]);var c2o_ = wx[k[87418]]({ 'name': k[87425], 'success': function (z83r7) {
      console[k[60468]](k[87426]), console[k[60468]](z83r7), z83r7 && z83r7[k[84240]] == k[87421] ? (window['F$L86'] = !![], window['F$68L0'](), window['F$6L08']()) : setTimeout(function () {
        window['F$IL068']();
      }, 0x1f4);
    }, 'fail': function (nwdxes) {
      console[k[60468]](k[87427]), console[k[60468]](nwdxes), setTimeout(function () {
        window['F$IL068']();
      }, 0x1f4);
    } });c2o_ && c2o_[k[87423]](j6cosd => {});
}, window[k[87428]] = function () {
  window['F$I860L'](window[k[87405]], k[87429]) >= 0x0 ? (console[k[60468]](k[87430] + window[k[87405]] + k[87431]), window['F$L0'](), window['F$I86L0'](), window['F$IL068']()) : (window['F$L60'](k[87432], window[k[87405]]), wx[k[87412]]({ 'title': k[65858], 'content': k[87433] }));
}, window[k[87396]] = '', wx[k[87434]]({ 'success'(bthi) {
    window[k[87396]] = k[87435] + bthi[k[87436]] + k[87437] + bthi[k[87438]] + k[87439] + bthi[k[64343]] + k[87440] + bthi[k[60461]] + k[87441] + bthi[k[84038]] + k[87442] + bthi[k[87405]] + k[87443] + bthi[k[68647]], console[k[60468]](window[k[87396]]), console[k[60468]](k[87444] + bthi[k[87445]] + k[87446] + bthi[k[87447]] + k[87448] + bthi[k[87449]] + k[87450] + bthi[k[87451]] + k[87452] + bthi[k[87453]] + k[87454] + bthi[k[87455]] + k[87456] + (bthi[k[87457]] ? bthi[k[87457]][k[60316]] + ',' + bthi[k[87457]][k[61136]] + ',' + bthi[k[87457]][k[61138]] + ',' + bthi[k[87457]][k[61137]] : ''));var ay$73 = bthi[k[60461]] ? bthi[k[60461]][k[71465]]() : '',
        d6jc2 = bthi[k[87438]] ? bthi[k[87438]][k[71465]]()[k[64330]]('\x20', '') : '';window['F$L6'][k[61005]] = ay$73[k[60114]](k[87458]) != -0x1, window['F$L6'][k[70509]] = ay$73[k[60114]](k[87248]) != -0x1, window['F$L6'][k[87459]] = ay$73[k[60114]](k[87458]) != -0x1 || ay$73[k[60114]](k[87248]) != -0x1, window['F$L6'][k[83782]] = ay$73[k[60114]](k[87460]) != -0x1 || ay$73[k[60114]](k[87461]) != -0x1, window['F$L6'][k[87462]] = bthi[k[84038]] ? bthi[k[84038]][k[71465]]() : '', window['F$L6']['F$I086L'] = ![], window['F$L6']['F$I0L86'] = 0x2;if (ay$73[k[60114]](k[87248]) != -0x1) {
      if (bthi[k[68647]] >= 0x18) window['F$L6']['F$I0L86'] = 0x3;else window['F$L6']['F$I0L86'] = 0x2;
    } else {
      if (ay$73[k[60114]](k[87458]) != -0x1) {
        if (bthi[k[68647]] && bthi[k[68647]] >= 0x14) window['F$L6']['F$I0L86'] = 0x3;else {
          if (d6jc2[k[60114]](k[87463]) != -0x1 || d6jc2[k[60114]](k[87464]) != -0x1 || d6jc2[k[60114]](k[87465]) != -0x1 || d6jc2[k[60114]](k[87466]) != -0x1 || d6jc2[k[60114]](k[87467]) != -0x1) window['F$L6']['F$I0L86'] = 0x2;else window['F$L6']['F$I0L86'] = 0x3;
        }
      } else window['F$L6']['F$I0L86'] = 0x2;
    }console[k[60468]](k[87468] + window['F$L6']['F$I086L'] + k[87469] + window['F$L6']['F$I0L86']);
  } }), wx[k[87470]]({ 'success': function (jcdsw) {
    console[k[60468]](k[87471] + jcdsw[k[64249]] + k[87472] + jcdsw[k[87473]]);
  } }), wx[k[87474]]({ 'success': function (r87$3y) {
    console[k[60468]](k[87475] + r87$3y[k[87476]]);
  } }), wx[k[87477]]({ 'keepScreenOn': !![] }), wx[k[87478]](function (r7y$a) {
  console[k[60468]](k[87475] + r7y$a[k[87476]] + k[87479] + r7y$a[k[87480]]);
}), wx[k[70074]](function (wdncjs) {
  window['F$80'] = wdncjs, window['F$608'] && window['F$80'] && (console[k[60077]](k[87481] + window['F$80'][k[60750]]), window['F$608'](window['F$80']), window['F$80'] = null);
}), window[k[87482]] = 0x0, window['F$IL860'] = 0x0, window[k[87483]] = null, wx[k[87484]](function () {
  window['F$IL860']++;var vum1bi = Date[k[60082]]();(window[k[87482]] == 0x0 || vum1bi - window[k[87482]] > 0x1d4c0) && (console[k[60095]](k[87485]), wx[k[71046]]());if (window['F$IL860'] >= 0x2) {
    window['F$IL860'] = 0x0, console[k[60124]](k[87486]), wx[k[87487]]('0', 0x1);if (window['F$L6'] && window['F$L6'][k[61005]]) window['F$L60'](k[87488], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});