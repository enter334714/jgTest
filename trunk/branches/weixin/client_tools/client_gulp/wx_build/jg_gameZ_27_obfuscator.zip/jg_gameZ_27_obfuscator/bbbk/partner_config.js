var _ = wx.y$;
var sdk_conf = {
  game_id: 256,
  game_pkg: _[0x96ff],
  partner_label: _[0x9700],
  partner_id: _[0x9701],
  game_ver: _[0x9702],
  is_auth: false //授权登录
};

module.exports = sdk_conf;