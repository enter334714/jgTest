var _ = wx.y$;
require(_[0x96bd]);