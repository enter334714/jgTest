var _ = wx.y$;
import _dgfdhc from '../bbbk/bbbsdk.js';
window[_[0x6d03]] = { 'wxVersion': window[_[0x250]][_[0x925d]] }, window[_[0x92bf]] = ![], window['p$ED'] = 0x1, window[_[0x92c0]] = 0x1, window['p$CDE'] = !![], window[_[0x92c1]] = !![], window['p$ABCDE'] = '', window[_[0x92c2]] = !![], window['p$DE'] = {
    'base_cdn': _[0x92c3],
    'cdn': _[0x92c3]
}, p$DE[_[0x92c4]] = {}, p$DE[_[0x6d42]] = '0', p$DE[_[0x1559]] = window[_[0x6d03]][_[0x92c5]], p$DE[_[0x92a6]] = '', p$DE['os'] = '1', p$DE[_[0x92c6]] = _[0x92c7], p$DE[_[0x92c8]] = _[0x92c9], p$DE[_[0x92ca]] = _[0x92cb], p$DE[_[0x92cc]] = _[0x92cd], p$DE[_[0x92ce]] = _[0x92cf], p$DE[_[0x334c]] = '1', p$DE[_[0x6ebb]] = '', p$DE[_[0x6ebd]] = '', p$DE[_[0x92d0]] = 0x0, p$DE[_[0x92d1]] = {}, p$DE[_[0x92d2]] = parseInt(p$DE[_[0x334c]]), p$DE[_[0x3355]] = p$DE[_[0x334c]], p$DE[_[0x6eb5]] = {}, p$DE['p$BD'] = _[0x92d3], p$DE[_[0x92d4]] = ![], p$DE[_[0x33de]] = _[0x92d5], p$DE[_[0x6e8d]] = Date[_[0x55]](), p$DE[_[0x1217]] = _[0x92d6], p$DE[_[0x30d]] = '_a', p$DE[_[0x6f4d]] = '', p$DE[_[0x92d7]] = 0x2, p$DE[_[0x68]] = 0x7c1, p$DE[_[0x92c5]] = window[_[0x6d03]][_[0x92c5]], p$DE[_[0x323]] = ![], p$DE[_[0x486]] = ![], p$DE[_[0x2e9c]] = ![], p$DE[_[0x6d44]] = ![], window['p$CED'] = 0x5, window['p$CE'] = ![], window['p$EC'] = ![], window['p$DCE'] = ![], window[_[0x92d8]] = ![], window[_[0x92d9]] = ![], window['p$DEC'] = ![], window['p$CD'] = ![], window['p$DC'] = ![], window['p$ECD'] = ![], window[_[0x92da]] = null, window[_[0x2ad]] = function (gdfi) {
    console[_[0x205]](_[0x2ad], gdfi), wx[_[0x136f]]({}), wx[_[0x9275]]({
        'title': _[0x1850],
        'content': gdfi,
        'success'(efhji) {
            if (efhji[_[0x92db]]) console[_[0x205]](_[0x92dc]);else efhji[_[0x24c]] && console[_[0x205]](_[0x92dd]);
        }
    });
}, window['p$BCDE'] = function (higl) {
    console[_[0x205]](_[0x92de], higl), p$BDEC(), wx[_[0x9275]]({
        'title': _[0x1850],
        'content': higl,
        'confirmText': _[0x92df],
        'cancelText': _[0x4fbe],
        'success'(z21$0_) {
            if (z21$0_[_[0x92db]]) window['p$DB']();else z21$0_[_[0x24c]] && (console[_[0x205]](_[0x92e0]), wx[_[0x6d28]]({}));
        }
    });
}, window[_[0x92e1]] = function (dfceab) {
    console[_[0x205]](_[0x92e1], dfceab), wx[_[0x9275]]({
        'title': _[0x1850],
        'content': dfceab,
        'confirmText': _[0x6f3e],
        'showCancel': ![],
        'complete'(xtsuw) {
            console[_[0x205]](_[0x92e0]), wx[_[0x6d28]]({});
        }
    });
}, window['p$BCED'] = ![], window['p$BDCE'] = function (ighkf) {
    window['p$BCED'] = !![], wx[_[0x136e]](ighkf);
}, window['p$BDEC'] = function () {
    window['p$BCED'] && (window['p$BCED'] = ![], wx[_[0x136f]]({}));
}, window['p$BECD'] = function (onklmp) {
    window[_[0x926c]][_[0x97]]['p$BECD'](onklmp);
}, window[_[0x335c]] = function (mlijnk, oplqnm) {
    _dgfdhc[_[0x335c]](mlijnk, function (khifj) {
        khifj && khifj[_[0xa]] ? khifj[_[0xa]][_[0x54a]] == 0x1 ? oplqnm(!![]) : (oplqnm(![]), console[_[0x50]](_[0x92e2] + khifj[_[0xa]][_[0x92e3]])) : console[_[0x205]](_[0x335c], khifj);
    });
}, window['p$BEDC'] = function (ihlm) {
    console[_[0x205]](_[0x92e4], ihlm);
}, window['p$BDE'] = function (nmqrop) {}, window['p$BED'] = function (egihjf, vrust, onkjlm) {}, window['p$BE'] = function (yxw$_z) {
    console[_[0x205]](_[0x92e5], yxw$_z), window[_[0x926c]][_[0x97]][_[0x92e6]](), window[_[0x926c]][_[0x97]][_[0x92e7]](), window[_[0x926c]][_[0x97]][_[0x92e8]](), window[_[0x92e9]]();
}, window['p$EB'] = function (egbfcd) {
    window[_[0x92ea]](0xe, _[0x92eb] + egbfcd), window['p$BCDE'](_[0x92ec]);
    var $xz = {
        'id': window['p$DE'][_[0x9262]],
        'role': window['p$DE'][_[0x129c]],
        'level': window['p$DE'][_[0x9263]],
        'account': window['p$DE'][_[0x6eb9]],
        'version': window['p$DE'][_[0x68]],
        'cdn': window['p$DE'][_[0x1215]],
        'pkgName': window['p$DE'][_[0x6ebb]],
        'gamever': window[_[0x250]][_[0x925d]],
        'serverid': window['p$DE'][_[0x6eb5]] ? window['p$DE'][_[0x6eb5]][_[0x2f4c]] : 0x0,
        'systemInfo': window[_[0x9264]],
        'error': _[0x92ed],
        'stack': egbfcd ? egbfcd : _[0x92ec]
    },
        xtuywv = JSON[_[0x1207]]($xz);
    console[_[0x80]](_[0x92ee] + xtuywv), window['p$BD'](xtuywv);
}, window[_[0x92ea]] = function ($01yz, glkih) {
    sendApi(p$DE[_[0x92ca]], _[0x92ef], {
        'game_pkg': p$DE[_[0x6ebb]],
        'partner_id': p$DE[_[0x334c]],
        'server_id': p$DE[_[0x6eb5]] && p$DE[_[0x6eb5]][_[0x2f4c]] > 0x0 ? p$DE[_[0x6eb5]][_[0x2f4c]] : 0x0,
        'uid': p$DE[_[0x6eb9]] > 0x0 ? p$DE[_[0x6eb9]] : 0x0,
        'type': $01yz,
        'info': glkih
    });
}, window['p$DBE'] = function (srqutv) {
    var cafdb = JSON[_[0x230]](srqutv);
    cafdb[_[0x92f0]] = window[_[0x250]][_[0x925d]], cafdb[_[0x92f1]] = window['p$DE'][_[0x6eb5]] ? window['p$DE'][_[0x6eb5]][_[0x2f4c]] : 0x0, cafdb[_[0x9264]] = window[_[0x9264]];
    var rpmoq = JSON[_[0x1207]](cafdb);
    console[_[0x80]](_[0x92f2] + rpmoq), window['p$BD'](rpmoq);
}, window['p$DEB'] = function (knjl, qposr) {
    var wtvus = {
        'id': window['p$DE'][_[0x9262]],
        'role': window['p$DE'][_[0x129c]],
        'level': window['p$DE'][_[0x9263]],
        'account': window['p$DE'][_[0x6eb9]],
        'version': window['p$DE'][_[0x68]],
        'cdn': window['p$DE'][_[0x1215]],
        'pkgName': window['p$DE'][_[0x6ebb]],
        'gamever': window[_[0x250]][_[0x925d]],
        'serverid': window['p$DE'][_[0x6eb5]] ? window['p$DE'][_[0x6eb5]][_[0x2f4c]] : 0x0,
        'systemInfo': window[_[0x9264]],
        'error': knjl,
        'stack': qposr
    },
        cbaed = JSON[_[0x1207]](wtvus);
    console[_[0x63]](_[0x92f3] + cbaed), window['p$BD'](cbaed);
}, window['p$BD'] = function (idfgeh) {
    if (window['p$DE'][_[0x92a7]] == _[0x92f4]) return;
    var xuzyw = p$DE['p$BD'] + _[0x92f5] + p$DE[_[0x6eb9]];
    wx[_[0x200]]({
        'url': xuzyw,
        'method': _[0x92f6],
        'data': idfgeh,
        'header': {
            'content-type': _[0x92f7],
            'cache-control': _[0x6d30]
        },
        'success': function (mopqr) {
            DEBUG && console[_[0x205]](_[0x92f8], xuzyw, idfgeh, mopqr);
        },
        'fail': function (hgilj) {
            DEBUG && console[_[0x205]](_[0x92f8], xuzyw, idfgeh, hgilj);
        },
        'complete': function () {}
    });
}, window[_[0x92f9]] = function () {
    function jghkil() {
        return ((0x1 + Math[_[0x7a]]()) * 0x10000 | 0x0)[_[0x119]](0x10)[_[0x214]](0x1);
    }
    return jghkil() + jghkil() + '-' + jghkil() + '-' + jghkil() + '-' + jghkil() + '+' + jghkil() + jghkil() + jghkil();
}, window['p$DB'] = function () {
    console[_[0x205]](_[0x92fa]);
    var qruv = _dgfdhc[_[0x88d1]]();
    p$DE[_[0x3355]] = qruv[_[0x92fb]], p$DE[_[0x92d2]] = qruv[_[0x92fb]], p$DE[_[0x334c]] = qruv[_[0x92fb]], p$DE[_[0x6ebb]] = qruv[_[0x92fc]];
    var vtwru = { 'game_ver': p$DE[_[0x1559]] };
    p$DE[_[0x6ebd]] = this[_[0x92f9]](), p$BDCE({ 'title': _[0x92fd] }), _dgfdhc[_[0x18e]](vtwru, this['p$EBD'][_[0x4c]](this));
};
var wx_develop = ![];
window['p$EBD'] = function (plnokm) {
    var yxuvwt = plnokm[_[0x92fe]];
    sdkInitRes = plnokm, wx_develop = yxuvwt == 0x1, console[_[0x205]](_[0x92ff] + yxuvwt + _[0x9300] + (yxuvwt == 0x1) + _[0x9301] + plnokm[_[0x925d]] + _[0x9302] + window[_[0x6d03]][_[0x92c5]]);
    if (!plnokm[_[0x925d]] || window['p$ACEBD'](window[_[0x6d03]][_[0x92c5]], plnokm[_[0x925d]]) < 0x0) console[_[0x205]](_[0x9303]), p$DE[_[0x92c8]] = _[0x9304], p$DE[_[0x92ca]] = _[0x9305], p$DE[_[0x92cc]] = _[0x9306], p$DE[_[0x1215]] = _[0x9307], p$DE[_[0x6d41]] = _[0x9308], p$DE[_[0x1218]] = _[0x9309], p$DE[_[0x323]] = ![];else window['p$ACEBD'](window[_[0x6d03]][_[0x92c5]], plnokm[_[0x925d]]) == 0x0 ? (console[_[0x205]](_[0x930a]), p$DE[_[0x92c8]] = _[0x92c9], p$DE[_[0x92ca]] = _[0x92cb], p$DE[_[0x92cc]] = _[0x92cd], p$DE[_[0x1215]] = _[0x930b], p$DE[_[0x6d41]] = _[0x9308], p$DE[_[0x1218]] = _[0x930c], p$DE[_[0x323]] = !![]) : (console[_[0x205]](_[0x930d]), p$DE[_[0x92c8]] = _[0x92c9], p$DE[_[0x92ca]] = _[0x92cb], p$DE[_[0x92cc]] = _[0x92cd], p$DE[_[0x1215]] = _[0x930b], p$DE[_[0x6d41]] = _[0x9308], p$DE[_[0x1218]] = _[0x930c], p$DE[_[0x323]] = ![]);
    p$DE[_[0x92d0]] = config[_[0x7f3d]] ? config[_[0x7f3d]] : 0x0, this['p$CDBE'](), this['p$CDEB'](), window[_[0x930e]] = 0x5, p$BDCE({ 'title': _[0x930f] }), _dgfdhc[_[0x9310]](this['p$EDB'][_[0x4c]](this));
}, window[_[0x930e]] = 0x5, window['p$EDB'] = function (eigh, rnopm) {
    if (eigh == 0x0 && rnopm && rnopm[_[0x9071]]) {
        p$DE[_[0x9311]] = rnopm[_[0x9071]], p$DE[_[0x6f4b]] = rnopm[_[0x6f4b]], p$DE[_[0x6f46]] = rnopm[_[0x6f46]], p$DE[_[0x6f4c]] = rnopm[_[0x6f4c]], p$DE[_[0x6f45]] = rnopm[_[0x6f45]];
        var _03$12 = this;
        p$BDCE({ 'title': _[0x9312] }), sendApi(p$DE[_[0x92c8]], _[0x9313], {
            'platform': p$DE[_[0x92c6]],
            'partner_id': p$DE[_[0x334c]],
            'token': rnopm[_[0x9071]],
            'game_pkg': p$DE[_[0x6ebb]],
            'deviceId': p$DE[_[0x6ebd]],
            'scene': _[0x9314] + p$DE[_[0x92d0]]
        }, this['p$CBDE'][_[0x4c]](this), p$CED, p$EB);
    } else rnopm && rnopm[_[0x6d38]] && window[_[0x930e]] > 0x0 && (rnopm[_[0x6d38]][_[0x76]](_[0x9315]) != -0x1 || rnopm[_[0x6d38]][_[0x76]](_[0x9316]) != -0x1 || rnopm[_[0x6d38]][_[0x76]](_[0x9317]) != -0x1 || rnopm[_[0x6d38]][_[0x76]](_[0x9318]) != -0x1 || rnopm[_[0x6d38]][_[0x76]](_[0x9319]) != -0x1 || rnopm[_[0x6d38]][_[0x76]](_[0x931a]) != -0x1) ? (window[_[0x930e]]--, _dgfdhc[_[0x9310]](this['p$EDB'][_[0x4c]](this))) : (window[_[0x92ea]](0x1, _[0x931b] + eigh + _[0x931c] + (rnopm ? rnopm[_[0x6d38]] : '')), window['p$DEB'](_[0x931d], JSON[_[0x1207]]({
        'status': eigh,
        'data': rnopm
    })), window['p$BCDE'](_[0x931e] + (rnopm && rnopm[_[0x6d38]] ? '，' + rnopm[_[0x6d38]] : '')));
}, window['p$CBDE'] = function (gkjf) {
    if (!gkjf) {
        window[_[0x92ea]](0x2, _[0x931f]), window['p$DEB'](_[0x9320], _[0x9321]), window['p$BCDE'](_[0x9322]);
        return;
    }
    if (gkjf[_[0x54a]] != _[0x27e4]) {
        window[_[0x92ea]](0x2, _[0x9323] + gkjf[_[0x54a]]), window['p$DEB'](_[0x9320], JSON[_[0x1207]](gkjf)), window['p$BCDE'](_[0x9324] + gkjf[_[0x54a]]);
        return;
    }
    if (gkjf[_[0x9325]] == 0x1) {
        window['p$BCDE'](_[0x9326]);
        return;
    }
    p$DE[_[0x334a]] = String(gkjf[_[0x6eb9]]), p$DE[_[0x6eb9]] = String(gkjf[_[0x6eb9]]), p$DE[_[0x6e8b]] = String(gkjf[_[0x6e8b]]), p$DE[_[0x3355]] = String(gkjf[_[0x6e8b]]), p$DE[_[0x6ebc]] = String(gkjf[_[0x6ebc]]), p$DE[_[0x9327]] = String(gkjf[_[0x2f3b]]), p$DE[_[0x9328]] = String(gkjf[_[0x3a6]]), p$DE[_[0x2f3b]] = '';
    var wsut = this;
    p$BDCE({ 'title': _[0x9329] });
    var usptqr = localStorage[_[0x203]](_[0x932a] + p$DE[_[0x6ebb]] + p$DE[_[0x6eb9]]);
    if (usptqr && usptqr != '') {
        var prutq = Number(usptqr);
        wsut[_[0x932b]](prutq);
    } else wsut[_[0x932c]]();
}, window[_[0x932c]] = function () {
    var jolk = this;
    sendApi(p$DE[_[0x92c8]], _[0x932d], {
        'partner_id': p$DE[_[0x334c]],
        'uid': p$DE[_[0x6eb9]],
        'version': p$DE[_[0x1559]],
        'game_pkg': p$DE[_[0x6ebb]],
        'device': p$DE[_[0x6ebd]]
    }, jolk['p$CBED'][_[0x4c]](jolk), p$CED, p$EB);
}, window['p$CBED'] = function (_$21z0) {
    if (!_$21z0) {
        window[_[0x92ea]](0x3, _[0x932e]), window['p$BCDE'](_[0x932e]);
        return;
    }
    if (_$21z0[_[0x54a]] != _[0x27e4]) {
        window[_[0x92ea]](0x3, _[0x932f] + _$21z0[_[0x54a]]), window['p$BCDE'](_[0x932f] + _$21z0[_[0x54a]]);
        return;
    }
    if (!_$21z0[_[0xa]] || _$21z0[_[0xa]][_[0xc]] == 0x0) {
        window[_[0x92ea]](0x3, _[0x9330]), window['p$BCDE'](_[0x9331]);
        return;
    }
    this[_[0x9332]](_$21z0);
}, window[_[0x932b]] = function (qrosnp) {
    var zvxwuy = this;
    sendApi(p$DE[_[0x92c8]], _[0x9333], {
        'server_id': qrosnp,
        'time': Date[_[0x55]]() / 0x3e8
    }, zvxwuy[_[0x9334]][_[0x4c]](zvxwuy), p$CED, p$EB);
}, window[_[0x9334]] = function ($zxy_w) {
    if (!$zxy_w) {
        window[_[0x92ea]](0x4, _[0x9335]), this[_[0x932c]]();
        return;
    }
    if ($zxy_w[_[0x54a]] != _[0x27e4]) {
        window[_[0x92ea]](0x4, _[0x9336] + $zxy_w[_[0x54a]]), this[_[0x932c]]();
        return;
    }
    if (!$zxy_w[_[0xa]] || $zxy_w[_[0xa]][_[0xc]] == 0x0) {
        window[_[0x92ea]](0x4, _[0x9337]), this[_[0x932c]]();
        return;
    }
    this[_[0x9332]]($zxy_w);
}, window[_[0x9332]] = function (wuvtsx) {
    p$DE[_[0x2ba]] = wuvtsx[_[0x9338]] != undefined ? wuvtsx[_[0x9338]] : 0x0, p$DE[_[0x6eb5]] = {
        'server_id': String(wuvtsx[_[0xa]][0x0][_[0x2f4c]]),
        'server_name': String(wuvtsx[_[0xa]][0x0][_[0x6eba]]),
        'entry_ip': wuvtsx[_[0xa]][0x0][_[0x6d2e]],
        'entry_port': parseInt(wuvtsx[_[0xa]][0x0][_[0x6ecf]]),
        'status': p$DCB(wuvtsx[_[0xa]][0x0]),
        'start_time': wuvtsx[_[0xa]][0x0][_[0x9339]],
        'maintain_time': wuvtsx[_[0xa]][0x0][_[0x933a]] ? wuvtsx[_[0xa]][0x0][_[0x933a]] : '',
        'is_recommend': wuvtsx[_[0xa]][0x0][_[0x933b]],
        'cdn': p$DE[_[0x1215]]
    }, this[_[0x933c]](), window[_[0x926c]] && window[_[0x926c]][_[0x97]][_[0x933d]] && window[_[0x926c]][_[0x97]][_[0x933d]](sdkInitRes[_[0x933e]], sdkInitRes[_[0x933f]], sdkInitRes[_[0x9340]], sdkInitRes[_[0x9341]], sdkInitRes[_[0x9342]]);
}, window[_[0x933c]] = function () {
    window['p$DC'] = !![], window['p$EDCB']();
}, window['p$EDCB'] = function () {
    if (window['p$DC'] && window['p$CD']) {
        var lonmj = p$DE[_[0x9343]] != undefined ? p$DE[_[0x9343]] : 0x0,
            ijnklm = p$DE[_[0x6f45]] == undefined ? 0x0 : p$DE[_[0x6f45]],
            mnoqr = lonmj == 0x1 && ijnklm == 0x1 || lonmj == 0x2 && ijnklm != 0x1 || lonmj == 0x3;
        console[_[0x50]](_[0x9344] + p$DE[_[0x2ba]] + _[0x9345] + mnoqr + _[0x9346] + p$DE[_[0x6f45]] + _[0x9347] + p$DE[_[0x9343]]);
        if (!mnoqr && p$DE[_[0x2ba]] == 0x1) {
            var puqt = p$DE[_[0x6eb5]][_[0x6d]];
            if (puqt === -0x1 || puqt === 0x0) {
                window[_[0x92ea]](0xf, _[0x9348] + p$DE[_[0x6eb5]]['id'] + _[0x9349] + p$DE[_[0x6eb5]][_[0x6d]]), window['p$BCDE'](puqt === -0x1 ? _[0x934a] : _[0x934b]);
                return;
            }
            p$EBCD(0x0, p$DE[_[0x6eb5]][_[0x2f4c]]), window[_[0x926c]][_[0x97]][_[0x934c]](p$DE[_[0x2ba]]);
        } else window[_[0x926c]][_[0x97]][_[0x934d]]({
            'show': sdkInitRes[_[0x933e]],
            'skinUrl': sdkInitRes[_[0x933f]],
            'content': sdkInitRes[_[0x9340]],
            'x': sdkInitRes[_[0x9341]],
            'y': sdkInitRes[_[0x9342]]
        }), p$BDEC();
        window[_[0x934e]](), window['p$ECDB'](), window['p$EDBC']();
    }
}, window['p$CDBE'] = function () {
    sendApi(p$DE[_[0x92c8]], _[0x934f], {
        'game_pkg': p$DE[_[0x6ebb]],
        'version_name': p$DE[_[0x1218]]
    }, this[_[0x9350]][_[0x4c]](this), p$CED, p$EB);
}, window[_[0x9350]] = function (khilj) {
    if (!khilj) {
        window[_[0x92ea]](0x5, _[0x9351]), window['p$BCDE'](_[0x9351]);
        return;
    }
    if (khilj[_[0x54a]] != _[0x27e4]) {
        window[_[0x92ea]](0x5, _[0x9352] + khilj[_[0x54a]]), window['p$BCDE'](_[0x9352] + khilj[_[0x54a]]);
        return;
    }
    if (!khilj[_[0xa]] || !khilj[_[0xa]][_[0x1559]]) {
        window[_[0x92ea]](0x5, _[0x9353] + (khilj[_[0xa]] && khilj[_[0xa]][_[0x1559]])), window['p$BCDE'](_[0x9353] + (khilj[_[0xa]] && khilj[_[0xa]][_[0x1559]]));
        return;
    }
    khilj[_[0xa]][_[0x9354]] && khilj[_[0xa]][_[0x9354]][_[0xc]] > 0xa && (p$DE[_[0x9355]] = khilj[_[0xa]][_[0x9354]], p$DE[_[0x1215]] = khilj[_[0xa]][_[0x9354]]), khilj[_[0xa]][_[0x1559]] && (p$DE[_[0x68]] = khilj[_[0xa]][_[0x1559]]), console[_[0x50]](_[0x6f48] + p$DE[_[0x68]] + _[0x9356] + p$DE[_[0x1218]]), window['p$DEC'] = !![], window['p$ECDB'](), window['p$EDBC']();
}, window[_[0x9357]], window['p$CDEB'] = function () {
    sendApi(p$DE[_[0x92c8]], _[0x9358], { 'game_pkg': p$DE[_[0x6ebb]] }, this['p$CEBD'][_[0x4c]](this), p$CED, p$EB);
}, window['p$CEBD'] = function (lpkmon) {
    if (lpkmon && lpkmon[_[0x54a]] === _[0x27e4] && lpkmon[_[0xa]]) {
        window[_[0x9357]] = lpkmon[_[0xa]];
        for (var vytxwu in lpkmon[_[0xa]]) {
            p$DE[vytxwu] = lpkmon[_[0xa]][vytxwu];
        }
    } else window[_[0x92ea]](0xb, _[0x9359]), console[_[0x50]](_[0x935a] + lpkmon[_[0x54a]]);
    window['p$CD'] = !![], window['p$EDCB']();
}, window[_[0x935b]] = function (vtswux, ywvxuz, kjighl, xuzvw, mkljh, wtyuxv, dhfcge, zyv$, wyzux, gjhlki) {
    mkljh = String(mkljh);
    var ptusrq = dhfcge,
        ljikhg = zyv$;
    p$DE[_[0x92c4]][mkljh] = {
        'productid': mkljh,
        'productname': ptusrq,
        'productdesc': ljikhg,
        'roleid': vtswux,
        'rolename': ywvxuz,
        'rolelevel': kjighl,
        'price': wtyuxv,
        'callback': wyzux
    }, sendApi(p$DE[_[0x92cc]], _[0x935c], {
        'game_pkg': p$DE[_[0x6ebb]],
        'server_id': p$DE[_[0x6eb5]][_[0x2f4c]],
        'server_name': p$DE[_[0x6eb5]][_[0x6eba]],
        'level': kjighl,
        'uid': p$DE[_[0x6eb9]],
        'role_id': vtswux,
        'role_name': ywvxuz,
        'product_id': mkljh,
        'product_name': ptusrq,
        'product_desc': ljikhg,
        'money': wtyuxv,
        'partner_id': p$DE[_[0x334c]]
    }, toPayCallBack, p$CED, p$EB);
}, window[_[0x935d]] = function (lnmqpo) {
    if (lnmqpo && (lnmqpo[_[0x935e]] === 0xc8 || lnmqpo[_[0x54a]] == _[0x27e4])) {
        var fecbgd = p$DE[_[0x92c4]][String(lnmqpo[_[0x935f]])];
        if (fecbgd[_[0x16c]]) fecbgd[_[0x16c]](lnmqpo[_[0x935f]], lnmqpo[_[0x9360]], -0x1);
        _dgfdhc[_[0x9361]]({
            'cpbill': lnmqpo[_[0x9360]],
            'productid': lnmqpo[_[0x935f]],
            'productname': fecbgd[_[0x9362]],
            'productdesc': fecbgd[_[0x9363]],
            'serverid': p$DE[_[0x6eb5]][_[0x2f4c]],
            'servername': p$DE[_[0x6eb5]][_[0x6eba]],
            'roleid': fecbgd[_[0x3350]],
            'rolename': fecbgd[_[0x3351]],
            'rolelevel': fecbgd[_[0x9364]],
            'price': fecbgd[_[0x7762]],
            'extension': JSON[_[0x1207]]({ 'cp_order_id': lnmqpo[_[0x9360]] })
        }, function (sqnrpo, hji) {
            fecbgd[_[0x16c]] && sqnrpo == 0x0 && fecbgd[_[0x16c]](lnmqpo[_[0x935f]], lnmqpo[_[0x9360]], sqnrpo);
            console[_[0x50]](JSON[_[0x1207]]({
                'type': _[0x9365],
                'status': sqnrpo,
                'data': lnmqpo,
                'role_name': fecbgd[_[0x3351]]
            }));
            if (sqnrpo === 0x0) {} else {
                if (sqnrpo === 0x1) {} else {
                    if (sqnrpo === 0x2) {}
                }
            }
        });
    } else {
        var klmpn = lnmqpo ? _[0x9366] + lnmqpo[_[0x935e]] + _[0x9367] + lnmqpo[_[0x54a]] + _[0x9368] + lnmqpo[_[0x50]] : _[0x9369];
        window[_[0x92ea]](0xd, _[0x936a] + klmpn), alert(klmpn);
    }
}, window['p$CEDB'] = function () {}, window['p$BCE'] = function (z$_wyx, ghkilj, nmpqlo, sprtq, jkilh) {
    _dgfdhc[_[0x936b]](p$DE[_[0x6eb5]][_[0x2f4c]], p$DE[_[0x6eb5]][_[0x6eba]] || p$DE[_[0x6eb5]][_[0x2f4c]], z$_wyx, ghkilj, nmpqlo), sendApi(p$DE[_[0x92c8]], _[0x936c], {
        'game_pkg': p$DE[_[0x6ebb]],
        'server_id': p$DE[_[0x6eb5]][_[0x2f4c]],
        'role_id': z$_wyx,
        'uid': p$DE[_[0x6eb9]],
        'role_name': ghkilj,
        'role_type': sprtq,
        'level': nmpqlo
    });
}, window['p$BEC'] = function (befgcd, zyvuw, mkiljn, ijg, svut, efdcb, klmi, xywuvt, jmkli, hfk) {
    p$DE[_[0x9262]] = befgcd, p$DE[_[0x129c]] = zyvuw, p$DE[_[0x9263]] = mkiljn, _dgfdhc[_[0x936d]](p$DE[_[0x6eb5]][_[0x2f4c]], p$DE[_[0x6eb5]][_[0x6eba]] || p$DE[_[0x6eb5]][_[0x2f4c]], befgcd, zyvuw, mkiljn), sendApi(p$DE[_[0x92c8]], _[0x936e], {
        'game_pkg': p$DE[_[0x6ebb]],
        'server_id': p$DE[_[0x6eb5]][_[0x2f4c]],
        'role_id': befgcd,
        'uid': p$DE[_[0x6eb9]],
        'role_name': zyvuw,
        'role_type': ijg,
        'level': mkiljn,
        'evolution': svut
    });
}, window['p$CBE'] = function (knomj, hefd, fhc, z2$1_, ecdhfg, hijge, stuwv, fcegdh, nomqpl, gedhfi) {
    p$DE[_[0x9262]] = knomj, p$DE[_[0x129c]] = hefd, p$DE[_[0x9263]] = fhc, _dgfdhc[_[0x936f]](p$DE[_[0x6eb5]][_[0x2f4c]], p$DE[_[0x6eb5]][_[0x6eba]] || p$DE[_[0x6eb5]][_[0x2f4c]], knomj, hefd, fhc), sendApi(p$DE[_[0x92c8]], _[0x936e], {
        'game_pkg': p$DE[_[0x6ebb]],
        'server_id': p$DE[_[0x6eb5]][_[0x2f4c]],
        'role_id': knomj,
        'uid': p$DE[_[0x6eb9]],
        'role_name': hefd,
        'role_type': z2$1_,
        'level': fhc,
        'evolution': ecdhfg
    });
}, window['p$CEB'] = function (hegdfc) {}, window['p$BC'] = function (olnpm, tuprqs) {
    _dgfdhc[_[0x9370]](_[0x9370], { 'activity_id': tuprqs }, function (fkighj) {
        olnpm && olnpm(fkighj);
    });
}, window[_[0x658e]] = function () {
    _dgfdhc[_[0x658e]]();
}, window[_[0x9371]] = function () {
    _dgfdhc[_[0x650c]]();
}, window[_[0x9372]] = function (z0y$x, yx_$zw, opkln, z1$y_0, xwyz$v, utwyxv, noklmp, mknlp) {
    mknlp = mknlp || p$DE[_[0x6eb5]][_[0x2f4c]], sendApi(p$DE[_[0x92c8]], _[0x9373], {
        'phone': z0y$x,
        'role_id': yx_$zw,
        'uid': p$DE[_[0x6eb9]],
        'game_pkg': p$DE[_[0x6ebb]],
        'partner_id': p$DE[_[0x334c]],
        'server_id': mknlp
    }, noklmp, 0x2, null, function () {
        return !![];
    });
}, window[_[0x2c9d]] = function (bdcgfe) {
    window['p$EBC'] = bdcgfe, window['p$EBC'] && window['p$CB'] && (console[_[0x50]](_[0x92b7] + window['p$CB'][_[0x35b]]), window['p$EBC'](window['p$CB']), window['p$CB'] = null);
}, window['p$ECB'] = function (hmijlk, wvtxy, stuprq, nqpl) {
    window[_[0x15]](_[0x9374], {
        'game_pkg': window['p$DE'][_[0x6ebb]],
        'role_id': wvtxy,
        'server_id': stuprq
    }, nqpl);
}, window['p$DBCE'] = function (vrtswu, sqoprt, knmopl) {
    function optq(suptrq) {
        var vrqu = [],
            stpor = [],
            pqmnol = knmopl || window[_[0x250]][_[0x9375]];
        for (var jgif in pqmnol) {
            var yvz$xw = Number(jgif);
            (!vrtswu || !vrtswu[_[0xc]] || vrtswu[_[0x76]](yvz$xw) != -0x1) && (stpor[_[0x1c]](pqmnol[jgif]), vrqu[_[0x1c]]([yvz$xw, 0x3]));
        }
        window['p$ACEBD'](window[_[0x926d]], _[0x9376]) >= 0x0 ? (console[_[0x205]](_[0x9377]), _dgfdhc[_[0x9378]] && _dgfdhc[_[0x9378]](stpor, function (dgchef) {
            console[_[0x205]](_[0x9379]), console[_[0x205]](dgchef);
            if (dgchef && dgchef[_[0x6d38]] == _[0x937a]) for (var x$wz in pqmnol) {
                if (dgchef[pqmnol[x$wz]] == _[0x937b]) {
                    var _1$ = Number(x$wz);
                    for (var tw = 0x0; tw < vrqu[_[0xc]]; tw++) {
                        if (vrqu[tw][0x0] == _1$) {
                            vrqu[tw][0x1] = 0x1;
                            break;
                        }
                    }
                }
            }
            window['p$ACEBD'](window[_[0x926d]], _[0x937c]) >= 0x0 ? wx[_[0x937d]]({
                'withSubscriptions': !![],
                'success': function (edcbf) {
                    var kplm = edcbf[_[0x937e]][_[0x937f]];
                    if (kplm) {
                        console[_[0x205]](_[0x9380]), console[_[0x205]](kplm);
                        for (var osrpt in pqmnol) {
                            if (kplm[pqmnol[osrpt]] == _[0x937b]) {
                                var jie = Number(osrpt);
                                for (var edcab = 0x0; edcab < vrqu[_[0xc]]; edcab++) {
                                    if (vrqu[edcab][0x0] == jie) {
                                        vrqu[edcab][0x1] = 0x2;
                                        break;
                                    }
                                }
                            }
                        }
                        console[_[0x205]](vrqu), sqoprt && sqoprt(vrqu);
                    } else console[_[0x205]](_[0x9381]), console[_[0x205]](edcbf), console[_[0x205]](vrqu), sqoprt && sqoprt(vrqu);
                },
                'fail': function () {
                    console[_[0x205]](_[0x9382]), console[_[0x205]](vrqu), sqoprt && sqoprt(vrqu);
                }
            }) : (console[_[0x205]](_[0x9383] + window[_[0x926d]]), console[_[0x205]](vrqu), sqoprt && sqoprt(vrqu));
        })) : (console[_[0x205]](_[0x9384] + window[_[0x926d]]), console[_[0x205]](vrqu), sqoprt && sqoprt(vrqu)), wx[_[0x9385]](optq);
    }
    wx[_[0x9386]](optq);
}, window['p$DBEC'] = {
    'isSuccess': ![],
    'level': _[0x7f47],
    'isCharging': ![]
}, window['p$DCBE'] = function (rpqnm) {
    wx[_[0x92af]]({
        'success': function (tprsoq) {
            var iedgf = window['p$DBEC'];
            iedgf[_[0x9387]] = !![], iedgf[_[0x1284]] = Number(tprsoq[_[0x1284]])[_[0x10df]](0x0), iedgf[_[0x92b2]] = tprsoq[_[0x92b2]], rpqnm && rpqnm(iedgf[_[0x9387]], iedgf[_[0x1284]], iedgf[_[0x92b2]]);
        },
        'fail': function (likjmn) {
            console[_[0x205]](_[0x9388], likjmn[_[0x6d38]]);
            var trvs = window['p$DBEC'];
            rpqnm && rpqnm(trvs[_[0x9387]], trvs[_[0x1284]], trvs[_[0x92b2]]);
        }
    });
}, window[_[0x30cd]] = function (hdc) {
    wx[_[0x30cd]]({
        'success': function (qsrnp) {
            hdc && hdc(!![], qsrnp);
        },
        'fail': function (_4203) {
            hdc && hdc(![], _4203);
        }
    });
}, window[_[0x30cf]] = function (nklpmo) {
    if (nklpmo) wx[_[0x30cf]](nklpmo);
}, window[_[0x6d23]] = function (vutxw) {
    wx[_[0x6d23]](vutxw);
}, window[_[0x15]] = function (npomk, xy_zw$, tuwsrv, jmlk, _2031, $wvxzy, _$1z0, ebfcdg) {
    if (jmlk == undefined) jmlk = 0x1;
    wx[_[0x200]]({
        'url': npomk,
        'method': _$1z0 || _[0x6d2f],
        'responseType': _[0x11ab],
        'data': xy_zw$,
        'header': { 'content-type': ebfcdg || _[0x92f7] },
        'success': function (rsqv) {
            DEBUG && console[_[0x205]](_[0x9389], npomk, info, rsqv);
            if (rsqv && rsqv[_[0x6d36]] == 0xc8) {
                var noqmpr = rsqv[_[0xa]];
                !$wvxzy || $wvxzy(noqmpr) ? tuwsrv && tuwsrv(noqmpr) : window[_[0x938a]](npomk, xy_zw$, tuwsrv, jmlk, _2031, $wvxzy, rsqv);
            } else window[_[0x938a]](npomk, xy_zw$, tuwsrv, jmlk, _2031, $wvxzy, rsqv);
        },
        'fail': function (ikhlm) {
            DEBUG && console[_[0x205]](_[0x938b], npomk, info, ikhlm), window[_[0x938a]](npomk, xy_zw$, tuwsrv, jmlk, _2031, $wvxzy, ikhlm);
        },
        'complete': function () {}
    });
}, window[_[0x938a]] = function (jlnmk, khfgi, xvwz, hefjig, knlmji, kfig, srqot) {
    hefjig - 0x1 > 0x0 ? setTimeout(function () {
        window[_[0x15]](jlnmk, khfgi, xvwz, hefjig - 0x1, knlmji, kfig);
    }, 0x3e8) : knlmji && knlmji(JSON[_[0x1207]]({
        'url': jlnmk,
        'response': srqot
    }));
}, window[_[0x938c]] = function (jigk, hikmjl, uq, fkjgih, befdg, mnkpl, inkj) {
    !uq && (uq = {});
    var hdgcf = Math[_[0x79]](Date[_[0x55]]() / 0x3e8);
    uq[_[0x3a6]] = hdgcf, uq[_[0x938d]] = hikmjl;
    var mjnlik = Object[_[0x110]](uq)[_[0x48a]](),
        stuvqr = '',
        hljgik = '';
    for (var hgjkli = 0x0; hgjkli < mjnlik[_[0xc]]; hgjkli++) {
        stuvqr = stuvqr + (hgjkli == 0x0 ? '' : '&') + mjnlik[hgjkli] + uq[mjnlik[hgjkli]], hljgik = hljgik + (hgjkli == 0x0 ? '' : '&') + mjnlik[hgjkli] + '=' + encodeURIComponent(uq[mjnlik[hgjkli]]);
    }
    stuvqr = stuvqr + p$DE[_[0x92ce]];
    var _z021$ = _[0x938e] + md5(stuvqr);
    send(jigk + '?' + hljgik + (hljgik == '' ? '' : '&') + _z021$, null, fkjgih, befdg, mnkpl, inkj || function (ihjmk) {
        return ihjmk[_[0x54a]] == _[0x27e4];
    }, null, _[0x938f]);
}, window['p$DCEB'] = function (pnmk, ghej) {
    var gfheij = 0x0;
    p$DE[_[0x6eb5]] && (gfheij = p$DE[_[0x6eb5]][_[0x2f4c]]), sendApi(p$DE[_[0x92ca]], _[0x9390], {
        'partnerId': p$DE[_[0x334c]],
        'gamePkg': p$DE[_[0x6ebb]],
        'logTime': Math[_[0x79]](Date[_[0x55]]() / 0x3e8),
        'platformUid': p$DE[_[0x6ebc]],
        'type': pnmk,
        'serverId': gfheij
    }, null, 0x2, null, function () {
        return !![];
    });
}, window['p$DEBC'] = function (fbcda) {
    sendApi(p$DE[_[0x92c8]], _[0x9391], {
        'partner_id': p$DE[_[0x334c]],
        'uid': p$DE[_[0x6eb9]],
        'version': p$DE[_[0x1559]],
        'game_pkg': p$DE[_[0x6ebb]],
        'device': p$DE[_[0x6ebd]]
    }, p$DECB, p$CED, p$EB);
}, window['p$DECB'] = function (vsurqt) {
    if (vsurqt && vsurqt[_[0x54a]] === _[0x27e4] && vsurqt[_[0xa]]) {
        vsurqt[_[0xa]][_[0x1618]]({
            'id': -0x2,
            'name': _[0x9392]
        }), vsurqt[_[0xa]][_[0x1618]]({
            'id': -0x1,
            'name': _[0x9393]
        }), p$DE[_[0x9394]] = vsurqt[_[0xa]];
        if (window[_[0x340d]]) window[_[0x340d]][_[0x9395]]();
    } else {
        p$DE[_[0x9396]] = ![];
        var squprt = vsurqt ? vsurqt[_[0x54a]] : '';
        window[_[0x92ea]](0x7, _[0x9397] + squprt), window['p$BCDE'](_[0x9398] + squprt);
    }
}, window['p$BCD'] = function (jkon) {
    sendApi(p$DE[_[0x92c8]], _[0x9399], {
        'partner_id': p$DE[_[0x334c]],
        'uid': p$DE[_[0x6eb9]],
        'version': p$DE[_[0x1559]],
        'game_pkg': p$DE[_[0x6ebb]],
        'device': p$DE[_[0x6ebd]]
    }, p$BDC, p$CED, p$EB);
}, window['p$BDC'] = function (vw$xyz) {
    p$DE[_[0x939a]] = ![];
    if (vw$xyz && vw$xyz[_[0x54a]] === _[0x27e4] && vw$xyz[_[0xa]]) {
        for (var hjmk = 0x0; hjmk < vw$xyz[_[0xa]][_[0xc]]; hjmk++) {
            vw$xyz[_[0xa]][hjmk][_[0x6d]] = p$DCB(vw$xyz[_[0xa]][hjmk]);
        }
        p$DE[_[0x92d1]][-0x1] = window[_[0x939b]](vw$xyz[_[0xa]]), window[_[0x340d]][_[0x939c]](-0x1);
    } else {
        var bacfed = vw$xyz ? vw$xyz[_[0x54a]] : '';
        window[_[0x92ea]](0x8, _[0x939d] + bacfed), window['p$BCDE'](_[0x939e] + bacfed);
    }
}, window[_[0x939f]] = function (qonpml) {
    sendApi(p$DE[_[0x92c8]], _[0x9399], {
        'partner_id': p$DE[_[0x334c]],
        'uid': p$DE[_[0x6eb9]],
        'version': p$DE[_[0x1559]],
        'game_pkg': p$DE[_[0x6ebb]],
        'device': p$DE[_[0x6ebd]]
    }, qonpml, p$CED, p$EB);
}, window['p$CBD'] = function (roqmp, onpk) {
    sendApi(p$DE[_[0x92c8]], _[0x93a0], {
        'partner_id': p$DE[_[0x334c]],
        'uid': p$DE[_[0x6eb9]],
        'version': p$DE[_[0x1559]],
        'game_pkg': p$DE[_[0x6ebb]],
        'device': p$DE[_[0x6ebd]],
        'server_group_id': onpk
    }, p$CDB, p$CED, p$EB);
}, window['p$CDB'] = function (mpno) {
    p$DE[_[0x939a]] = ![];
    if (mpno && mpno[_[0x54a]] === _[0x27e4] && mpno[_[0xa]] && mpno[_[0xa]][_[0xa]]) {
        var egbfd = mpno[_[0xa]][_[0x93a1]],
            ijklg = [];
        for (var rtusqp = 0x0; rtusqp < mpno[_[0xa]][_[0xa]][_[0xc]]; rtusqp++) {
            mpno[_[0xa]][_[0xa]][rtusqp][_[0x6d]] = p$DCB(mpno[_[0xa]][_[0xa]][rtusqp]), (ijklg[_[0xc]] == 0x0 || mpno[_[0xa]][_[0xa]][rtusqp][_[0x6d]] != 0x0) && (ijklg[ijklg[_[0xc]]] = mpno[_[0xa]][_[0xa]][rtusqp]);
        }
        p$DE[_[0x92d1]][egbfd] = window[_[0x939b]](ijklg), window[_[0x340d]][_[0x939c]](egbfd);
    } else {
        var $yvzx = mpno ? mpno[_[0x54a]] : '';
        window[_[0x92ea]](0x9, _[0x93a2] + $yvzx), window['p$BCDE'](_[0x93a3] + $yvzx);
    }
}, window['p$ACED'] = function (vtusq) {
    sendApi(p$DE[_[0x92c8]], _[0x93a4], {
        'partner_id': p$DE[_[0x334c]],
        'uid': p$DE[_[0x6eb9]],
        'version': p$DE[_[0x1559]],
        'game_pkg': p$DE[_[0x6ebb]],
        'device': p$DE[_[0x6ebd]]
    }, reqServerRecommendCallBack, p$CED, p$EB);
}, window[_[0x93a5]] = function (tsuvq) {
    p$DE[_[0x939a]] = ![];
    if (tsuvq && tsuvq[_[0x54a]] === _[0x27e4] && tsuvq[_[0xa]]) {
        for (var qrpo = 0x0; qrpo < tsuvq[_[0xa]][_[0xc]]; qrpo++) {
            tsuvq[_[0xa]][qrpo][_[0x6d]] = p$DCB(tsuvq[_[0xa]][qrpo]);
        }
        p$DE[_[0x92d1]][-0x2] = window[_[0x939b]](tsuvq[_[0xa]]), window[_[0x340d]][_[0x939c]](-0x2);
    } else {
        var _10342 = tsuvq ? tsuvq[_[0x54a]] : '';
        window[_[0x92ea]](0xa, _[0x93a6] + _10342), alert(_[0x93a7] + _10342);
    }
}, window[_[0x939b]] = function (gchfd) {
    return gchfd;
}, window['p$DBC'] = function (cefb, qsrtup) {
    cefb = cefb || p$DE[_[0x6eb5]][_[0x2f4c]], sendApi(p$DE[_[0x92c8]], _[0x93a8], {
        'type': '4',
        'game_pkg': p$DE[_[0x6ebb]],
        'server_id': cefb
    }, qsrtup);
}, window[_[0x93a9]] = function (qlmpon, xuvzy, potq, lmnpk) {
    potq = potq || p$DE[_[0x6eb5]][_[0x2f4c]], sendApi(p$DE[_[0x92c8]], _[0x93aa], {
        'type': qlmpon,
        'game_pkg': xuvzy,
        'server_id': potq
    }, lmnpk);
}, window[_[0x93ab]] = function (dhigef, ghe) {
    sendApi(p$DE[_[0x92c8]], _[0x93ac], { 'game_pkg': dhigef }, ghe);
}, window['p$DCB'] = function (mplnqo) {
    if (mplnqo) {
        if (mplnqo[_[0x6d]] == 0x1) {
            if (mplnqo[_[0x93ad]] == 0x3) return 0x3;else return mplnqo[_[0x93ad]] == 0x1 ? 0x2 : 0x1;
        } else return mplnqo[_[0x6d]] == 0x0 ? 0x0 : -0x1;
    }
    return -0x1;
}, window['p$EBCD'] = function (nlp, cgfeb) {
    p$DE[_[0x93ae]] = {
        'step': nlp,
        'server_id': cgfeb
    };
    var qrnos = this;
    p$BDCE({ 'title': _[0x93af] }), sendApi(p$DE[_[0x92c8]], _[0x93b0], {
        'partner_id': p$DE[_[0x334c]],
        'uid': p$DE[_[0x6eb9]],
        'game_pkg': p$DE[_[0x6ebb]],
        'server_id': cgfeb,
        'platform': p$DE[_[0x6e8b]],
        'platform_uid': p$DE[_[0x6ebc]],
        'check_login_time': p$DE[_[0x9328]],
        'check_login_sign': p$DE[_[0x9327]],
        'version_name': p$DE[_[0x1218]]
    }, p$EBDC, p$CED, p$EB, function (efgd) {
        return efgd[_[0x54a]] == _[0x27e4] || efgd[_[0x50]] == _[0x93b1] || efgd[_[0x50]] == _[0x93b2];
    });
}, window['p$EBDC'] = function (_z0x$) {
    var uswvtx = this;
    if (_z0x$ && _z0x$[_[0x54a]] === _[0x27e4] && _z0x$[_[0xa]]) {
        var gkilj = p$DE[_[0x6eb5]];
        gkilj[_[0x93b3]] = p$DE[_[0x92d2]], gkilj[_[0x2f3b]] = String(_z0x$[_[0xa]][_[0x93b4]]), gkilj[_[0x6e8d]] = parseInt(_z0x$[_[0xa]][_[0x3a6]]);
        if (_z0x$[_[0xa]][_[0x6e8c]]) gkilj[_[0x6e8c]] = parseInt(_z0x$[_[0xa]][_[0x6e8c]]);else gkilj[_[0x6e8c]] = parseInt(_z0x$[_[0xa]][_[0x2f4c]]);
        gkilj[_[0x93b5]] = 0x0, gkilj[_[0x1215]] = p$DE[_[0x9355]], gkilj[_[0x93b6]] = _z0x$[_[0xa]][_[0x93b7]], gkilj[_[0x93b8]] = _z0x$[_[0xa]][_[0x93b8]];
        if (_z0x$[_[0xa]][_[0x6e91]]) gkilj[_[0x6e91]] = parseInt(_z0x$[_[0xa]][_[0x6e91]]);
        console[_[0x205]](_[0x93b9] + JSON[_[0x1207]](gkilj[_[0x93b8]])), p$DE[_[0x2ba]] == 0x1 && gkilj[_[0x93b8]] && gkilj[_[0x93b8]][_[0x93ba]] == 0x1 && (p$DE[_[0x93bb]] = 0x1, window[_[0x926c]][_[0x97]]['p$AED']()), p$ECBD();
    } else {
        if (p$DE[_[0x93ae]][_[0x11c2]] >= 0x3) {
            var pnolmq = _z0x$ ? _z0x$[_[0x54a]] : '';
            window[_[0x92ea]](0xc, _[0x93bc] + pnolmq), p$EB(JSON[_[0x1207]](_z0x$)), window['p$BCDE'](_[0x93bd] + pnolmq);
        } else sendApi(p$DE[_[0x92c8]], _[0x9313], {
            'platform': p$DE[_[0x92c6]],
            'partner_id': p$DE[_[0x334c]],
            'token': p$DE[_[0x9311]],
            'game_pkg': p$DE[_[0x6ebb]],
            'deviceId': p$DE[_[0x6ebd]],
            'scene': _[0x9314] + p$DE[_[0x92d0]]
        }, function (fejigh) {
            if (!fejigh || fejigh[_[0x54a]] != _[0x27e4]) {
                window['p$BCDE'](_[0x9324] + fejigh && fejigh[_[0x54a]]);
                return;
            }
            p$DE[_[0x9327]] = String(fejigh[_[0x2f3b]]), p$DE[_[0x9328]] = String(fejigh[_[0x3a6]]), setTimeout(function () {
                p$EBCD(p$DE[_[0x93ae]][_[0x11c2]] + 0x1, p$DE[_[0x93ae]][_[0x2f4c]]);
            }, 0x5dc);
        }, p$CED, p$EB, function (wtsur) {
            return wtsur[_[0x54a]] == _[0x27e4] || wtsur[_[0x54a]] == _[0x7015];
        });
    }
}, window['p$ECBD'] = function () {
    ServerLoading[_[0x97]][_[0x934c]](p$DE[_[0x2ba]]), window['p$CE'] = !![], window['p$EDBC']();
}, window['p$ECDB'] = function () {
    if (window['p$EC'] && window['p$DCE'] && window[_[0x92d8]] && window[_[0x92d9]] && window['p$DEC'] && window['p$DC']) {
        if (!window[_[0x9005]][_[0x97]]) {
            console[_[0x205]](_[0x93be] + window[_[0x9005]][_[0x97]]);
            var tqpr = wx[_[0x6d12]](),
                qprno = tqpr[_[0x35b]] ? tqpr[_[0x35b]] : 0x0,
                dchgef = {
                'cdn': window['p$DE'][_[0x1215]],
                'spareCdn': window['p$DE'][_[0x6d41]],
                'newRegister': window['p$DE'][_[0x2ba]],
                'wxPC': window['p$DE'][_[0x6d44]],
                'wxIOS': window['p$DE'][_[0x486]],
                'wxAndroid': window['p$DE'][_[0x2e9c]],
                'wxParam': {
                    'limitLoad': window['p$DE']['p$ABCED'],
                    'benchmarkLevel': window['p$DE']['p$ABDCE'],
                    'wxFrom': window[_[0x250]][_[0x7f3d]] == _[0x93bf] ? 0x1 : 0x0,
                    'wxSDKVersion': window[_[0x926d]]
                },
                'configType': window['p$DE'][_[0x1217]],
                'exposeType': window['p$DE'][_[0x30d]],
                'scene': qprno,
                'video_type': window['p$DE'][_[0x6f46]],
                'ad_flag': window['p$DE'][_[0x6f45]]
            };
            if (window[_[0x9357]]) for (var swtrv in window[_[0x9357]]) {
                if (!dchgef[swtrv]) dchgef[swtrv] = window[_[0x9357]][swtrv];
            }
            new window[_[0x9005]](dchgef, window['p$DE'][_[0x68]], window['p$ABCDE']);
        }
    }
}, window['p$EDBC'] = function () {
    if (window['p$EC'] && window['p$DCE'] && window[_[0x92d8]] && window[_[0x92d9]] && window['p$DEC'] && window['p$DC'] && window['p$CE'] && window['p$CD']) {
        p$BDEC();
        if (!p$ECD) {
            p$ECD = !![];
            if (!window[_[0x9005]][_[0x97]]) window['p$ECDB']();
            var rqtusv = 0x0,
                fhj = wx[_[0x93c0]]();
            fhj && (window['p$DE'][_[0x92a4]] && (rqtusv = fhj[_[0x160]]), console[_[0x50]](_[0x93c1] + fhj[_[0x160]] + _[0x93c2] + fhj[_[0x55e]] + _[0x93c3] + fhj[_[0x560]] + _[0x93c4] + fhj[_[0x55f]] + _[0x93c5] + fhj[_[0xbc]] + _[0x93c6] + fhj[_[0xbd]]));
            var yz_0$x = {};
            for (const bgefc in p$DE[_[0x6eb5]]) {
                yz_0$x[bgefc] = p$DE[_[0x6eb5]][bgefc];
            }
            var qrpust = {
                'channel': window['p$DE'][_[0x3355]],
                'account': window['p$DE'][_[0x6eb9]],
                'userId': window['p$DE'][_[0x334a]],
                'cdn': window['p$DE'][_[0x1215]],
                'data': window['p$DE'][_[0xa]],
                'package': window['p$DE'][_[0x6d42]],
                'newRegister': window['p$DE'][_[0x2ba]],
                'pkgName': window['p$DE'][_[0x6ebb]],
                'partnerId': window['p$DE'][_[0x334c]],
                'platform_uid': window['p$DE'][_[0x6ebc]],
                'deviceId': window['p$DE'][_[0x6ebd]],
                'selectedServer': yz_0$x,
                'configType': window['p$DE'][_[0x1217]],
                'exposeType': window['p$DE'][_[0x30d]],
                'debugUsers': window['p$DE'][_[0x33de]],
                'wxMenuTop': rqtusv,
                'wxShield': window['p$DE'][_[0x323]],
                'encryptParam': window['p$DE'][_[0x6f4d]],
                'wx_channel': window['p$DE'][_[0x6f4b]],
                'zsy_tp_state': window['p$DE'][_[0x6f4c]]
            };
            if (window[_[0x9357]]) for (var wtxvy in window[_[0x9357]]) {
                qrpust[wtxvy] = window[_[0x9357]][wtxvy];
            }
            window[_[0x9005]][_[0x97]]['p$EDA'](qrpust);
            if (p$DE[_[0x6eb5]] && p$DE[_[0x6eb5]][_[0x2f4c]]) localStorage[_[0x208]](_[0x932a] + p$DE[_[0x6ebb]] + p$DE[_[0x6eb9]], p$DE[_[0x6eb5]][_[0x2f4c]]);
        }
    } else console[_[0x50]](_[0x93c7] + window['p$EC'] + _[0x93c8] + window['p$DCE'] + _[0x93c9] + window[_[0x92d8]] + _[0x93ca] + window[_[0x92d9]] + _[0x93cb] + window['p$DEC'] + _[0x93cc] + window['p$DC'] + _[0x93cd] + window['p$CE'] + _[0x93ce] + window['p$CD']);
}, window[_[0x934e]] = function () {
    if (!window['p$DC'] || !window['p$CD']) return;
    var lop = p$DE[_[0x2ba]] == 0x1,
        $031 = p$DE[_[0x323]],
        imkn = p$DE[_[0x6e32]] && p$DE[_[0x6e32]] > 0x0;
    if ($031 || lop && imkn) {
        var _z1$0 = p$DE[_[0x6e33]],
            mlkjin = _z1$0 && _z1$0[_[0xc]] == 0x9;
        mlkjin && (window[_[0x7a64]] = _z1$0);
        var cbefdg = p$DE[_[0x6e34]],
            y$w_ = cbefdg && cbefdg[_[0xe]]('#')[_[0xc]] == 0x4;
        y$w_ && (window[_[0x7a65]] = cbefdg);
    }
}, window[_[0x92e9]] = function () {
    window[_[0x7a64]] = null, window[_[0x7a65]] = null;
};