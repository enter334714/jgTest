var f = wx.$B;
var sdk_conf = {
  game_id: f[642],
  game_pkg: f[643],
  partner_label: f[644],
  partner_id: f[645],
  game_ver: f[646],
  is_auth: true, //授权登录
  partner_mergeId: 1384
};

module.exports = sdk_conf;