var f = wx.$B;
require('./p67c.js'), window[f[0]][f[1]][f[2]] = null, window['client_pb'] = require('./ysw3a.js'), window[f[3]] = window[f[0]][f[4]][f[5]](client_pb);