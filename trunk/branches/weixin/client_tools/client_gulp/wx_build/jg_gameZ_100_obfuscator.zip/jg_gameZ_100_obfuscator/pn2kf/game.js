var f = wx.$B;
import 'Z_100main.js';