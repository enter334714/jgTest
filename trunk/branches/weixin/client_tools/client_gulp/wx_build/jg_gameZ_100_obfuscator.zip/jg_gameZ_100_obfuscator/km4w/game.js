var f = wx.$B;
require(f[1085]);