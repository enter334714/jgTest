
window.moosnowHeavyGameConfig = {
    nowPlatform: "wx",
    /**
     * 微信平台
     */
    wx: {
        moosnowAppId: "wx8dcbd9158bf16cbc",
        version: "1.0.0",
    }
}