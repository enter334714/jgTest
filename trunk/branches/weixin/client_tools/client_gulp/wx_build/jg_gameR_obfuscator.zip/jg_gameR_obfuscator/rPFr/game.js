var I = wx.$X;
require('rBFrr.js'), window[I[36200]][I[36201]][I[36202]] = null, window['client_pb'] = require('rCLIENTPrr.js'), window[I[32568]] = window[I[36200]][I[32496]][I[32497]](client_pb);