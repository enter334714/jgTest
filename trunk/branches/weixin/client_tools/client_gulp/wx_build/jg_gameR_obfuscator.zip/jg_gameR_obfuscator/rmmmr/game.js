var I = wx.$X;
import 'rrMAINrr.js';