var I = wx.$X;
require(I[0]);