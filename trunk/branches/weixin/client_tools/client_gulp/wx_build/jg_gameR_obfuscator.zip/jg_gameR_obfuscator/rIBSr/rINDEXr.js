var I = wx.$X;
import xi574qk from '../RskRR/rs6kr.js';window[I[167]] = { 'wxVersion': window[I[6]][I[7]] }, window[I[168]] = ![], window[I[169]] = 0x1, window[I[170]] = 0x1, window[I[171]] = !![], window[I[172]] = !![], window[I[173]] = '', window[I[174]] = ![], window[I[16]] = { 'base_cdn': I[175], 'cdn': I[175] }, r4C[I[176]] = {}, r4C[I[177]] = '0', r4C[I[93]] = window[I[167]][I[178]], r4C[I[128]] = '', r4C['os'] = '1', r4C[I[179]] = I[180], r4C[I[181]] = I[182], r4C[I[183]] = I[184], r4C[I[185]] = I[186], r4C[I[187]] = I[188], r4C[I[189]] = '1', r4C[I[23]] = '', r4C[I[190]] = '', r4C[I[191]] = 0x0, r4C[I[192]] = {}, r4C[I[193]] = parseInt(r4C[I[189]]), r4C[I[194]] = r4C[I[189]], r4C[I[24]] = {}, r4C[I[31]] = I[195], r4C[I[196]] = ![], r4C[I[197]] = I[198], r4C[I[199]] = Date[I[160]](), r4C[I[200]] = I[201], r4C[I[202]] = '_a', r4C[I[203]] = 0x2, r4C[I[21]] = 0x7c1, r4C[I[178]] = window[I[167]][I[178]], r4C[I[204]] = ![], r4C[I[120]] = ![], r4C[I[123]] = ![], r4C[I[126]] = ![], window[I[205]] = 0x5, window[I[206]] = ![], window[I[67]] = ![], window[I[76]] = ![], window[I[207]] = ![], window[I[208]] = ![], window[I[209]] = ![], window[I[210]] = ![], window[I[211]] = ![], window[I[212]] = ![], window[I[213]] = null, window[I[214]] = function (mvz3_8) {
  console[I[47]](I[214], mvz3_8), wx[I[215]]({}), wx[I[54]]({ 'title': I[85], 'content': mvz3_8, 'success'(r1p$g) {
      if (r1p$g[I[216]]) console[I[47]](I[217]);else r1p$g[I[218]] && console[I[47]](I[219]);
    } });
}, window[I[220]] = function (dy0c) {
  console[I[47]](I[221], dy0c), r34CQ(), wx[I[54]]({ 'title': I[85], 'content': dy0c, 'confirmText': I[222], 'cancelText': I[223], 'success'(c6f2t0) {
      if (c6f2t0[I[216]]) window[I[82]]();else c6f2t0[I[218]] && (console[I[47]](I[224]), wx[I[225]]({}));
    } });
}, window[I[226]] = function (opun5) {
  console[I[47]](I[226], opun5), wx[I[54]]({ 'title': I[85], 'content': opun5, 'confirmText': I[227], 'showCancel': ![], 'complete'(q4e7ki) {
      console[I[47]](I[224]), wx[I[225]]({});
    } });
}, window[I[228]] = ![], window[I[229]] = function (fdt02) {
  window[I[228]] = !![], wx[I[230]](fdt02);
}, window[I[231]] = function () {
  window[I[228]] && (window[I[228]] = ![], wx[I[215]]({}));
}, window[I[232]] = function (zmv_6) {
  window[I[37]][I[38]][I[232]](zmv_6);
}, window[I[233]] = function (c02tf6, v6zcf) {
  xi574qk[I[233]](c02tf6, function (h1rg) {
    h1rg && h1rg[I[234]] ? h1rg[I[234]][I[235]] == 0x1 ? v6zcf(!![]) : (v6zcf(![]), console[I[1]](I[236] + h1rg[I[234]][I[237]])) : console[I[47]](I[233], h1rg);
  });
}, window[I[238]] = function (dlhays) {
  console[I[47]](I[239], dlhays);
}, window[I[240]] = function (f0c2t) {}, window[I[241]] = function (hldsy, c6f02t, rob1p) {}, window[I[242]] = function ($alhy) {
  console[I[47]](I[243], $alhy), window[I[37]][I[38]][I[244]](), window[I[37]][I[38]][I[245]](), window[I[37]][I[38]][I[246]]();
}, window[I[247]] = function (ik5q) {
  window[I[248]](0xe, I[249] + ik5q), window[I[220]](I[250]);var vzf6ct = { 'id': window[I[16]][I[17]], 'role': window[I[16]][I[18]], 'level': window[I[16]][I[19]], 'account': window[I[16]][I[20]], 'version': window[I[16]][I[21]], 'cdn': window[I[16]][I[22]], 'pkgName': window[I[16]][I[23]], 'gamever': window[I[6]][I[7]], 'serverid': window[I[16]][I[24]] ? window[I[16]][I[24]][I[25]] : 0x0, 'systemInfo': window[I[26]], 'error': I[251], 'stack': ik5q ? ik5q : I[250] },
      ysa0l = JSON[I[28]](vzf6ct);console[I[29]](I[252] + ysa0l), window[I[31]](ysa0l);
}, window[I[248]] = function (unkq57, sdyal) {
  sendApi(r4C[I[183]], I[253], { 'game_pkg': r4C[I[23]], 'partner_id': r4C[I[189]], 'server_id': r4C[I[24]] && r4C[I[24]][I[25]] > 0x0 ? r4C[I[24]][I[25]] : 0x0, 'uid': r4C[I[20]] > 0x0 ? r4C[I[20]] : 0x0, 'type': unkq57, 'info': sdyal });
}, window[I[254]] = function (f_v6zt) {
  var $1grp = JSON[I[255]](f_v6zt);$1grp[I[256]] = window[I[6]][I[7]], $1grp[I[257]] = window[I[16]][I[24]] ? window[I[16]][I[24]][I[25]] : 0x0, $1grp[I[26]] = window[I[26]];var ahdys = JSON[I[28]]($1grp);console[I[29]](I[258] + ahdys), window[I[31]](ahdys);
}, window[I[83]] = function (hxl1$a, w9_3) {
  var ub5pn = { 'id': window[I[16]][I[17]], 'role': window[I[16]][I[18]], 'level': window[I[16]][I[19]], 'account': window[I[16]][I[20]], 'version': window[I[16]][I[21]], 'cdn': window[I[16]][I[22]], 'pkgName': window[I[16]][I[23]], 'gamever': window[I[6]][I[7]], 'serverid': window[I[16]][I[24]] ? window[I[16]][I[24]][I[25]] : 0x0, 'systemInfo': window[I[26]], 'error': hxl1$a, 'stack': w9_3 },
      syhxa = JSON[I[28]](ub5pn);console[I[161]](I[259] + syhxa), window[I[31]](syhxa);
}, window[I[31]] = function (c0fdt2) {
  if (window[I[16]][I[129]] == I[260]) return;var $x1hag = r4C[I[31]] + I[261] + r4C[I[20]];wx[I[262]]({ 'url': $x1hag, 'method': I[263], 'data': c0fdt2, 'header': { 'content-type': I[264], 'cache-control': I[265] }, 'success': function (rbpo) {
      DEBUG && console[I[47]](I[266], $x1hag, c0fdt2, rbpo);
    }, 'fail': function (x$pg1) {
      DEBUG && console[I[47]](I[266], $x1hag, c0fdt2, x$pg1);
    }, 'complete': function () {} });
}, window[I[267]] = function () {
  function kub5o() {
    return ((0x1 + Math[I[268]]()) * 0x10000 | 0x0)[I[269]](0x10)[I[270]](0x1);
  }return kub5o() + kub5o() + '-' + kub5o() + '-' + kub5o() + '-' + kub5o() + '+' + kub5o() + kub5o() + kub5o();
}, window[I[82]] = function () {
  console[I[47]](I[271]);var cd20sf = xi574qk[I[272]]();r4C[I[194]] = cd20sf[I[273]], r4C[I[193]] = cd20sf[I[273]], r4C[I[189]] = cd20sf[I[273]], r4C[I[23]] = cd20sf[I[274]];var kub5q = { 'game_ver': r4C[I[93]] };r4C[I[190]] = this[I[267]](), r34QC({ 'title': I[275] }), xi574qk[I[276]](kub5q, this[I[277]][I[278]](this));
};var wx_develop = ![];window[I[277]] = function (d02fc) {
  var uonp5b = d02fc[I[279]];sdkInitRes = d02fc, wx_develop = uonp5b == 0x1, console[I[47]](I[280] + uonp5b + I[281] + (uonp5b == 0x1) + I[282] + d02fc[I[7]] + I[283] + window[I[167]][I[178]]);if (!d02fc[I[7]] || window[I[41]](window[I[167]][I[178]], d02fc[I[7]]) < 0x0) console[I[47]](I[284]), r4C[I[181]] = I[285], r4C[I[183]] = I[286], r4C[I[185]] = I[287], r4C[I[22]] = I[288], r4C[I[289]] = I[290], r4C[I[291]] = 'll', r4C[I[204]] = ![];else window[I[41]](window[I[167]][I[178]], d02fc[I[7]]) == 0x0 ? (console[I[47]](I[292]), r4C[I[181]] = I[182], r4C[I[183]] = I[184], r4C[I[185]] = I[186], r4C[I[22]] = I[293], r4C[I[289]] = I[290], r4C[I[291]] = I[294], r4C[I[204]] = !![]) : (console[I[47]](I[295]), r4C[I[181]] = I[182], r4C[I[183]] = I[184], r4C[I[185]] = I[186], r4C[I[22]] = I[293], r4C[I[289]] = I[290], r4C[I[291]] = I[294], r4C[I[204]] = ![]);r4C[I[191]] = config[I[296]] ? config[I[296]] : 0x0, this[I[297]](), this[I[298]](), window[I[299]] = 0x5, r34QC({ 'title': I[300] }), xi574qk[I[301]](this[I[302]][I[278]](this));
}, window[I[299]] = 0x5, window[I[302]] = function (c0yd2s, a1hx$l) {
  if (c0yd2s == 0x0 && a1hx$l && a1hx$l[I[303]]) {
    r4C[I[304]] = a1hx$l[I[303]];var saxlh = this;r34QC({ 'title': I[305] }), sendApi(r4C[I[181]], I[306], { 'platform': r4C[I[179]], 'partner_id': r4C[I[189]], 'token': a1hx$l[I[303]], 'game_pkg': r4C[I[23]], 'deviceId': r4C[I[190]], 'scene': I[307] + r4C[I[191]] }, this[I[308]][I[278]](this), rQC4, rC3);
  } else a1hx$l && a1hx$l[I[65]] && window[I[299]] > 0x0 && (a1hx$l[I[65]][I[121]](I[309]) != -0x1 || a1hx$l[I[65]][I[121]](I[310]) != -0x1 || a1hx$l[I[65]][I[121]](I[311]) != -0x1 || a1hx$l[I[65]][I[121]](I[312]) != -0x1 || a1hx$l[I[65]][I[121]](I[313]) != -0x1 || a1hx$l[I[65]][I[121]](I[314]) != -0x1) ? (window[I[299]]--, xi574qk[I[301]](this[I[302]][I[278]](this))) : (window[I[248]](0x1, I[315] + c0yd2s + I[316] + (a1hx$l ? a1hx$l[I[65]] : '')), window[I[83]](I[317], JSON[I[28]]({ 'status': c0yd2s, 'data': a1hx$l })), window[I[220]](I[318] + (a1hx$l && a1hx$l[I[65]] ? '，' + a1hx$l[I[65]] : '')));
}, window[I[308]] = function (k5un7q) {
  if (!k5un7q) {
    window[I[248]](0x2, I[319]), window[I[83]](I[320], I[321]), window[I[220]](I[322]);return;
  }if (k5un7q[I[235]] != I[323]) {
    window[I[248]](0x2, I[324] + k5un7q[I[235]]), window[I[83]](I[320], JSON[I[28]](k5un7q)), window[I[220]](I[325] + k5un7q[I[235]]);return;
  }r4C[I[326]] = String(k5un7q[I[20]]), r4C[I[20]] = String(k5un7q[I[20]]), r4C[I[97]] = String(k5un7q[I[97]]), r4C[I[194]] = String(k5un7q[I[97]]), r4C[I[327]] = String(k5un7q[I[327]]), r4C[I[328]] = String(k5un7q[I[329]]), r4C[I[330]] = String(k5un7q[I[331]]), r4C[I[329]] = '';var pgo$1r = this;r34QC({ 'title': I[332] });var gp1x$ = localStorage[I[333]](I[334] + r4C[I[23]] + r4C[I[20]]);if (gp1x$ && gp1x$ != '') {
    var rx = Number(gp1x$);pgo$1r[I[335]](rx);
  } else pgo$1r[I[336]]();
}, window[I[336]] = function () {
  var _fzvt = this;sendApi(r4C[I[181]], I[337], { 'partner_id': r4C[I[189]], 'uid': r4C[I[20]], 'version': r4C[I[93]], 'game_pkg': r4C[I[23]], 'device': r4C[I[190]] }, _fzvt[I[338]][I[278]](_fzvt), rQC4, rC3);
}, window[I[338]] = function (v_tz) {
  if (!v_tz) {
    window[I[248]](0x3, I[339]), window[I[220]](I[339]);return;
  }if (v_tz[I[235]] != I[323]) {
    window[I[248]](0x3, I[340] + v_tz[I[235]]), window[I[220]](I[340] + v_tz[I[235]]);return;
  }if (!v_tz[I[234]] || v_tz[I[234]][I[10]] == 0x0) {
    window[I[248]](0x3, I[341]), window[I[220]](I[342]);return;
  }this[I[343]](v_tz);
}, window[I[335]] = function (_38mw) {
  var brupno = this;sendApi(r4C[I[181]], I[344], { 'server_id': _38mw, 'time': Date[I[160]]() / 0x3e8 }, brupno[I[345]][I[278]](brupno), rQC4, rC3);
}, window[I[345]] = function (_8zt) {
  if (!_8zt) {
    window[I[248]](0x4, I[346]), this[I[336]]();return;
  }if (_8zt[I[235]] != I[323]) {
    window[I[248]](0x4, I[347] + _8zt[I[235]]), this[I[336]]();return;
  }if (!_8zt[I[234]] || _8zt[I[234]][I[10]] == 0x0) {
    window[I[248]](0x4, I[348]), this[I[336]]();return;
  }this[I[343]](_8zt), window[I[37]] && window[I[37]][I[38]][I[349]] && window[I[37]][I[38]][I[349]](sdkInitRes[I[350]], sdkInitRes[I[351]], sdkInitRes[I[352]], sdkInitRes[I[353]], sdkInitRes[I[354]]);
}, window[I[343]] = function (pou5n) {
  r4C[I[355]] = pou5n[I[356]] != undefined ? pou5n[I[356]] : 0x0, r4C[I[24]] = { 'server_id': String(pou5n[I[234]][0x0][I[25]]), 'server_name': String(pou5n[I[234]][0x0][I[357]]), 'entry_ip': pou5n[I[234]][0x0][I[358]], 'entry_port': parseInt(pou5n[I[234]][0x0][I[359]]), 'status': r4Q3(pou5n[I[234]][0x0]), 'start_time': pou5n[I[234]][0x0][I[360]], 'cdn': r4C[I[22]] }, this[I[361]]();
}, window[I[361]] = function () {
  if (r4C[I[355]] == 0x1) {
    var ukn75 = r4C[I[24]][I[362]];if (ukn75 === -0x1 || ukn75 === 0x0) {
      window[I[248]](0xf, I[363] + r4C[I[24]]['id'] + I[364] + r4C[I[24]][I[362]]), window[I[220]](ukn75 === -0x1 ? I[365] : I[366]);return;
    }rC3Q4(0x0, r4C[I[24]][I[25]]), window[I[37]][I[38]][I[367]](r4C[I[355]]);
  } else window[I[37]][I[38]][I[368]](), r34CQ();window[I[211]] = !![], window[I[68]](), window[I[69]]();
}, window[I[297]] = function () {
  sendApi(r4C[I[181]], I[369], { 'game_pkg': r4C[I[23]], 'version_name': r4C[I[291]] }, this[I[370]][I[278]](this), rQC4, rC3);
}, window[I[370]] = function (xgh1$a) {
  if (!xgh1$a) {
    window[I[248]](0x5, I[371]), window[I[220]](I[371]);return;
  }if (xgh1$a[I[235]] != I[323]) {
    window[I[248]](0x5, I[372] + xgh1$a[I[235]]), window[I[220]](I[372] + xgh1$a[I[235]]);return;
  }if (!xgh1$a[I[234]] || !xgh1$a[I[234]][I[93]]) {
    window[I[248]](0x5, I[373] + (xgh1$a[I[234]] && xgh1$a[I[234]][I[93]])), window[I[220]](I[373] + (xgh1$a[I[234]] && xgh1$a[I[234]][I[93]]));return;
  }xgh1$a[I[234]][I[374]] && xgh1$a[I[234]][I[374]][I[10]] > 0xa && (r4C[I[375]] = xgh1$a[I[234]][I[374]], r4C[I[22]] = xgh1$a[I[234]][I[374]]), xgh1$a[I[234]][I[93]] && (r4C[I[21]] = xgh1$a[I[234]][I[93]]), console[I[1]](I[376] + r4C[I[21]] + I[377] + r4C[I[291]]), window[I[209]] = !![], window[I[68]](), window[I[69]]();
}, window[I[378]], window[I[298]] = function () {
  sendApi(r4C[I[181]], I[379], { 'game_pkg': r4C[I[23]] }, this[I[380]][I[278]](this), rQC4, rC3);
}, window[I[380]] = function (e74ik) {
  if (e74ik && e74ik[I[235]] === I[323] && e74ik[I[234]]) {
    window[I[378]] = e74ik[I[234]];for (var i74e in e74ik[I[234]]) {
      r4C[i74e] = e74ik[I[234]][i74e];
    }
  } else window[I[248]](0xb, I[381]), console[I[1]](I[382] + e74ik[I[235]]);window[I[210]] = !![], window[I[69]]();
}, window[I[383]] = function (uon5k, nbku, lhxya$, ysahdl, fct6v, aysdlh, lhxsy, bkuo, _ztfv6, po$1rg) {
  fct6v = String(fct6v);var $gxha1 = lhxsy,
      $1xla = bkuo;r4C[I[176]][fct6v] = { 'productid': fct6v, 'productname': $gxha1, 'productdesc': $1xla, 'roleid': uon5k, 'rolename': nbku, 'rolelevel': lhxya$, 'price': aysdlh, 'callback': _ztfv6 }, sendApi(r4C[I[185]], I[384], { 'game_pkg': r4C[I[23]], 'server_id': r4C[I[24]][I[25]], 'server_name': r4C[I[24]][I[357]], 'level': lhxya$, 'uid': r4C[I[20]], 'role_id': uon5k, 'role_name': nbku, 'product_id': fct6v, 'product_name': $gxha1, 'product_desc': $1xla, 'money': aysdlh, 'partner_id': r4C[I[189]] }, toPayCallBack, rQC4, rC3);
}, window[I[385]] = function (p5noub) {
  if (p5noub && (p5noub[I[386]] === 0xc8 || p5noub[I[235]] == I[323])) {
    var bp5n = r4C[I[176]][String(p5noub[I[387]])];if (bp5n[I[388]]) bp5n[I[388]](p5noub[I[387]], p5noub[I[389]], -0x1);xi574qk[I[390]]({ 'cpbill': p5noub[I[389]], 'productid': p5noub[I[387]], 'productname': bp5n[I[391]], 'productdesc': bp5n[I[392]], 'serverid': r4C[I[24]][I[25]], 'servername': r4C[I[24]][I[357]], 'roleid': bp5n[I[393]], 'rolename': bp5n[I[394]], 'rolelevel': bp5n[I[395]], 'price': bp5n[I[396]], 'extension': JSON[I[28]]({ 'cp_order_id': p5noub[I[389]] }) }, function (oupbn5, ysadlh) {
      bp5n[I[388]] && oupbn5 == 0x0 && bp5n[I[388]](p5noub[I[387]], p5noub[I[389]], oupbn5);console[I[1]](JSON[I[28]]({ 'type': I[397], 'status': oupbn5, 'data': p5noub, 'role_name': bp5n[I[394]] }));if (oupbn5 === 0x0) {} else {
        if (oupbn5 === 0x1) {} else {
          if (oupbn5 === 0x2) {}
        }
      }
    });
  } else {
    var ct2zf6 = p5noub ? I[398] + p5noub[I[386]] + I[399] + p5noub[I[235]] + I[400] + p5noub[I[1]] : I[401];window[I[248]](0xd, I[402] + ct2zf6), alert(ct2zf6);
  }
}, window[I[403]] = function () {}, window[I[404]] = function (pogb1r, mv8z_6, cfvtz, upnr, hg1$) {
  xi574qk[I[405]](r4C[I[24]][I[25]], r4C[I[24]][I[357]] || r4C[I[24]][I[25]], pogb1r, mv8z_6, cfvtz), sendApi(r4C[I[181]], I[406], { 'game_pkg': r4C[I[23]], 'server_id': r4C[I[24]][I[25]], 'role_id': pogb1r, 'uid': r4C[I[20]], 'role_name': mv8z_6, 'role_type': upnr, 'level': cfvtz });
}, window[I[407]] = function (hgx$1r, mz83_v, $xal, r$og1p, _t6v, ylshad, gprob1, sldhy, grxh, onbpur) {
  r4C[I[17]] = hgx$1r, r4C[I[18]] = mz83_v, r4C[I[19]] = $xal, xi574qk[I[408]](r4C[I[24]][I[25]], r4C[I[24]][I[357]] || r4C[I[24]][I[25]], hgx$1r, mz83_v, $xal), sendApi(r4C[I[181]], I[409], { 'game_pkg': r4C[I[23]], 'server_id': r4C[I[24]][I[25]], 'role_id': hgx$1r, 'uid': r4C[I[20]], 'role_name': mz83_v, 'role_type': r$og1p, 'level': $xal, 'evolution': _t6v });
}, window[I[410]] = function (q5u4, kbnqu, y0d2ls, r$x1g, nuq57, s2ly0, v_t8z, a1$gx, yhd, g$r1x) {
  r4C[I[17]] = q5u4, r4C[I[18]] = kbnqu, r4C[I[19]] = y0d2ls, xi574qk[I[411]](r4C[I[24]][I[25]], r4C[I[24]][I[357]] || r4C[I[24]][I[25]], q5u4, kbnqu, y0d2ls), sendApi(r4C[I[181]], I[409], { 'game_pkg': r4C[I[23]], 'server_id': r4C[I[24]][I[25]], 'role_id': q5u4, 'uid': r4C[I[20]], 'role_name': kbnqu, 'role_type': r$x1g, 'level': y0d2ls, 'evolution': nuq57 });
}, window[I[412]] = function (wv3_8) {}, window[I[413]] = function (q54i7k) {
  xi574qk[I[414]](I[414], function (uobp5n) {
    q54i7k && q54i7k(uobp5n);
  });
}, window[I[415]] = function () {
  xi574qk[I[415]]();
}, window[I[416]] = function () {
  xi574qk[I[417]]();
}, window[I[418]] = function (dy2cs0, bpo1, $h1xa, df2sc0, mw_93, onbpg, eik4q, sadhyl) {
  sadhyl = sadhyl || r4C[I[24]][I[25]], sendApi(r4C[I[181]], I[419], { 'phone': dy2cs0, 'role_id': bpo1, 'uid': r4C[I[20]], 'game_pkg': r4C[I[23]], 'partner_id': r4C[I[189]], 'server_id': sadhyl }, eik4q, 0x2, null, function () {
    return !![];
  });
}, window[I[151]] = function (ydlas) {
  window[I[153]] = ydlas, window[I[153]] && window[I[152]] && (console[I[1]](I[154] + window[I[152]][I[155]]), window[I[153]](window[I[152]]), window[I[152]] = null);
}, window[I[420]] = function (pr1gbo, vftzc6, syhld, rxg) {
  window[I[421]](I[422], { 'game_pkg': window[I[16]][I[23]], 'role_id': vftzc6, 'server_id': syhld }, rxg);
}, window[I[423]] = function (z86_vt, gorn, m8_39w) {
  function fs2(_mv8z3) {
    var ds0lya = [],
        z3mv8_ = [],
        pg$xr1 = m8_39w || window[I[6]][I[424]];for (var kq7e4 in pg$xr1) {
      var xr$gh1 = Number(kq7e4);(!z86_vt || !z86_vt[I[10]] || z86_vt[I[121]](xr$gh1) != -0x1) && (z3mv8_[I[44]](pg$xr1[kq7e4]), ds0lya[I[44]]([xr$gh1, 0x3]));
    }window[I[41]](window[I[45]], I[425]) >= 0x0 ? (console[I[47]](I[426]), xi574qk[I[427]] && xi574qk[I[427]](z3mv8_, function (c6tf0) {
      console[I[47]](I[428]), console[I[47]](c6tf0);if (c6tf0 && c6tf0[I[65]] == I[429]) for (var tvf6cz in pg$xr1) {
        if (c6tf0[pg$xr1[tvf6cz]] == I[430]) {
          var ct6f = Number(tvf6cz);for (var gponb = 0x0; gponb < ds0lya[I[10]]; gponb++) {
            if (ds0lya[gponb][0x0] == ct6f) {
              ds0lya[gponb][0x1] = 0x1;break;
            }
          }
        }
      }window[I[41]](window[I[45]], I[431]) >= 0x0 ? wx[I[432]]({ 'withSubscriptions': !![], 'success': function (dyc20s) {
          var k74q5i = dyc20s[I[433]][I[434]];if (k74q5i) {
            console[I[47]](I[435]), console[I[47]](k74q5i);for (var $haxl1 in pg$xr1) {
              if (k74q5i[pg$xr1[$haxl1]] == I[430]) {
                var s0ydl = Number($haxl1);for (var q4ku5 = 0x0; q4ku5 < ds0lya[I[10]]; q4ku5++) {
                  if (ds0lya[q4ku5][0x0] == s0ydl) {
                    ds0lya[q4ku5][0x1] = 0x2;break;
                  }
                }
              }
            }console[I[47]](ds0lya), gorn && gorn(ds0lya);
          } else console[I[47]](I[436]), console[I[47]](dyc20s), console[I[47]](ds0lya), gorn && gorn(ds0lya);
        }, 'fail': function () {
          console[I[47]](I[437]), console[I[47]](ds0lya), gorn && gorn(ds0lya);
        } }) : (console[I[47]](I[438] + window[I[45]]), console[I[47]](ds0lya), gorn && gorn(ds0lya));
    })) : (console[I[47]](I[439] + window[I[45]]), console[I[47]](ds0lya), gorn && gorn(ds0lya)), wx[I[440]](fs2);
  }wx[I[441]](fs2);
}, window[I[442]] = { 'isSuccess': ![], 'level': I[443], 'isCharging': ![] }, window[I[444]] = function (slyda0) {
  wx[I[139]]({ 'success': function (unbp5o) {
      var o1$gr = window[I[442]];o1$gr[I[445]] = !![], o1$gr[I[141]] = Number(unbp5o[I[141]])[I[446]](0x0), o1$gr[I[143]] = unbp5o[I[143]], slyda0 && slyda0(o1$gr[I[445]], o1$gr[I[141]], o1$gr[I[143]]);
    }, 'fail': function (ld0sy2) {
      console[I[47]](I[447], ld0sy2[I[65]]);var cftzv6 = window[I[442]];slyda0 && slyda0(cftzv6[I[445]], cftzv6[I[141]], cftzv6[I[143]]);
    } });
}, window[I[144]] = function (w_m89) {
  wx[I[144]]({ 'success': function (uq5k7) {
      w_m89 && w_m89(!![], uq5k7);
    }, 'fail': function (bon) {
      w_m89 && w_m89(![], bon);
    } });
}, window[I[148]] = function (uonkb) {
  if (uonkb) wx[I[148]](uonkb);
}, window[I[448]] = function (ubo5p) {
  wx[I[448]](ubo5p);
}, window[I[421]] = function (ki54q7, v6m8, aysl, f_6vtz, qki45, p1gxr$, xhg$r1, yaxlh) {
  if (f_6vtz == undefined) f_6vtz = 0x1;wx[I[262]]({ 'url': ki54q7, 'method': xhg$r1 || I[449], 'responseType': I[450], 'data': v6m8, 'header': { 'content-type': yaxlh || I[264] }, 'success': function (rgonp) {
      DEBUG && console[I[47]](I[451], ki54q7, info, rgonp);if (rgonp && rgonp[I[452]] == 0xc8) {
        var robgp = rgonp[I[234]];!p1gxr$ || p1gxr$(robgp) ? aysl && aysl(robgp) : window[I[453]](ki54q7, v6m8, aysl, f_6vtz, qki45, p1gxr$, rgonp);
      } else window[I[453]](ki54q7, v6m8, aysl, f_6vtz, qki45, p1gxr$, rgonp);
    }, 'fail': function (lday0) {
      DEBUG && console[I[47]](I[454], ki54q7, info, lday0), window[I[453]](ki54q7, v6m8, aysl, f_6vtz, qki45, p1gxr$, lday0);
    }, 'complete': function () {} });
}, window[I[453]] = function (tdf0c2, bk, gopbr1, $lhxya, $hxgr, h1ga, n5ukqb) {
  $lhxya - 0x1 > 0x0 ? setTimeout(function () {
    window[I[421]](tdf0c2, bk, gopbr1, $lhxya - 0x1, $hxgr, h1ga);
  }, 0x3e8) : $hxgr && $hxgr(JSON[I[28]]({ 'url': tdf0c2, 'response': n5ukqb }));
}, window[I[455]] = function (vz_8t6, onu5p, $o1gr, $1ahxl, _93m, $rog1p, wv8m_) {
  !$o1gr && ($o1gr = {});var ek47qi = Math[I[456]](Date[I[160]]() / 0x3e8);$o1gr[I[331]] = ek47qi, $o1gr[I[457]] = onu5p;var nbqk5 = Object[I[458]]($o1gr)[I[459]](),
      bonpru = '',
      $x1pgr = '';for (var ct062f = 0x0; ct062f < nbqk5[I[10]]; ct062f++) {
    bonpru = bonpru + (ct062f == 0x0 ? '' : '&') + nbqk5[ct062f] + $o1gr[nbqk5[ct062f]], $x1pgr = $x1pgr + (ct062f == 0x0 ? '' : '&') + nbqk5[ct062f] + '=' + encodeURIComponent($o1gr[nbqk5[ct062f]]);
  }bonpru = bonpru + r4C[I[187]];var ki7qe4 = I[460] + md5(bonpru);send(vz_8t6 + '?' + $x1pgr + ($x1pgr == '' ? '' : '&') + ki7qe4, null, $1ahxl, _93m, $rog1p, wv8m_ || function (czt2f) {
    return czt2f[I[235]] == I[323];
  }, null, I[461]);
}, window[I[462]] = function (r$hx1g, bnko) {
  var k75uq = 0x0;r4C[I[24]] && (k75uq = r4C[I[24]][I[25]]), sendApi(r4C[I[183]], I[463], { 'partnerId': r4C[I[189]], 'gamePkg': r4C[I[23]], 'logTime': Math[I[456]](Date[I[160]]() / 0x3e8), 'platformUid': r4C[I[327]], 'type': r$hx1g, 'serverId': k75uq }, null, 0x2, null, function () {
    return !![];
  });
}, window[I[464]] = function (dtcf) {
  sendApi(r4C[I[181]], I[465], { 'partner_id': r4C[I[189]], 'uid': r4C[I[20]], 'version': r4C[I[93]], 'game_pkg': r4C[I[23]], 'device': r4C[I[190]] }, r4CQ3, rQC4, rC3);
}, window[I[466]] = function (ognpr) {
  if (ognpr && ognpr[I[235]] === I[323] && ognpr[I[234]]) {
    ognpr[I[234]][I[467]]({ 'id': -0x2, 'name': I[468] }), ognpr[I[234]][I[467]]({ 'id': -0x1, 'name': I[469] }), r4C[I[470]] = ognpr[I[234]];if (window[I[471]]) window[I[471]][I[472]]();
  } else {
    r4C[I[473]] = ![];var qk4u5 = ognpr ? ognpr[I[235]] : '';window[I[248]](0x7, I[474] + qk4u5), window[I[220]](I[475] + qk4u5);
  }
}, window[I[476]] = function (lyhaxs) {
  sendApi(r4C[I[181]], I[477], { 'partner_id': r4C[I[189]], 'uid': r4C[I[20]], 'version': r4C[I[93]], 'game_pkg': r4C[I[23]], 'device': r4C[I[190]] }, r34Q, rQC4, rC3);
}, window[I[478]] = function (pnour) {
  r4C[I[479]] = ![];if (pnour && pnour[I[235]] === I[323] && pnour[I[234]]) {
    for (var _t8z6 = 0x0; _t8z6 < pnour[I[234]][I[10]]; _t8z6++) {
      pnour[I[234]][_t8z6][I[362]] = r4Q3(pnour[I[234]][_t8z6]);
    }r4C[I[192]][-0x1] = window[I[480]](pnour[I[234]]), window[I[471]][I[481]](-0x1);
  } else {
    var $o1gp = pnour ? pnour[I[235]] : '';window[I[248]](0x8, I[482] + $o1gp), window[I[220]](I[483] + $o1gp);
  }
}, window[I[484]] = function (cdf20s) {
  sendApi(r4C[I[181]], I[477], { 'partner_id': r4C[I[189]], 'uid': r4C[I[20]], 'version': r4C[I[93]], 'game_pkg': r4C[I[23]], 'device': r4C[I[190]] }, cdf20s, rQC4, rC3);
}, window[I[485]] = function (dl20sy, q7u54k) {
  sendApi(r4C[I[181]], I[486], { 'partner_id': r4C[I[189]], 'uid': r4C[I[20]], 'version': r4C[I[93]], 'game_pkg': r4C[I[23]], 'device': r4C[I[190]], 'server_group_id': q7u54k }, rQ43, rQC4, rC3);
}, window[I[487]] = function (c2sfd) {
  r4C[I[479]] = ![];if (c2sfd && c2sfd[I[235]] === I[323] && c2sfd[I[234]] && c2sfd[I[234]][I[234]]) {
    var ctd2f = c2sfd[I[234]][I[488]],
        f6tcvz = [];for (var cdf0 = 0x0; cdf0 < c2sfd[I[234]][I[234]][I[10]]; cdf0++) {
      c2sfd[I[234]][I[234]][cdf0][I[362]] = r4Q3(c2sfd[I[234]][I[234]][cdf0]), (f6tcvz[I[10]] == 0x0 || c2sfd[I[234]][I[234]][cdf0][I[362]] != 0x0) && (f6tcvz[f6tcvz[I[10]]] = c2sfd[I[234]][I[234]][cdf0]);
    }r4C[I[192]][ctd2f] = window[I[480]](f6tcvz), window[I[471]][I[481]](ctd2f);
  } else {
    var w_m3 = c2sfd ? c2sfd[I[235]] : '';window[I[248]](0x9, I[489] + w_m3), window[I[220]](I[490] + w_m3);
  }
}, window[I[491]] = function (rnubp) {
  sendApi(r4C[I[181]], I[492], { 'partner_id': r4C[I[189]], 'uid': r4C[I[20]], 'version': r4C[I[93]], 'game_pkg': r4C[I[23]], 'device': r4C[I[190]] }, reqServerRecommendCallBack, rQC4, rC3);
}, window[I[493]] = function (yhasxl) {
  r4C[I[479]] = ![];if (yhasxl && yhasxl[I[235]] === I[323] && yhasxl[I[234]]) {
    for (var xl$a1h = 0x0; xl$a1h < yhasxl[I[234]][I[10]]; xl$a1h++) {
      yhasxl[I[234]][xl$a1h][I[362]] = r4Q3(yhasxl[I[234]][xl$a1h]);
    }r4C[I[192]][-0x2] = window[I[480]](yhasxl[I[234]]), window[I[471]][I[481]](-0x2);
  } else {
    var yxha$ = yhasxl ? yhasxl[I[235]] : '';window[I[248]](0xa, I[494] + yxha$), alert(I[495] + yxha$);
  }
}, window[I[480]] = function (ik47q) {
  return ik47q;
}, window[I[496]] = function (q7i4ek, m68v) {
  q7i4ek = q7i4ek || r4C[I[24]][I[25]], sendApi(r4C[I[181]], I[497], { 'type': '4', 'game_pkg': r4C[I[23]], 'server_id': q7i4ek }, m68v);
}, window[I[498]] = function (k45uq7, dl0sy, $xgp1r, q7kie4) {
  $xgp1r = $xgp1r || r4C[I[24]][I[25]], sendApi(r4C[I[181]], I[499], { 'type': k45uq7, 'game_pkg': dl0sy, 'server_id': $xgp1r }, q7kie4);
}, window[I[500]] = function (_389w, rh$x) {
  sendApi(r4C[I[181]], I[501], { 'game_pkg': _389w }, rh$x);
}, window[I[502]] = function (n75) {
  if (n75) {
    if (n75[I[362]] == 0x1) {
      if (n75[I[503]] == 0x1) return 0x2;else return 0x1;
    } else return n75[I[362]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window[I[504]] = function (rgxh$, xlysha) {
  r4C[I[505]] = { 'step': rgxh$, 'server_id': xlysha };var hgr1x = this;r34QC({ 'title': I[506] }), sendApi(r4C[I[181]], I[507], { 'partner_id': r4C[I[189]], 'uid': r4C[I[20]], 'game_pkg': r4C[I[23]], 'server_id': xlysha, 'platform': r4C[I[97]], 'platform_uid': r4C[I[327]], 'check_login_time': r4C[I[330]], 'check_login_sign': r4C[I[328]], 'version_name': r4C[I[291]] }, rC34Q, rQC4, rC3, function (pbun5o) {
    return pbun5o[I[235]] == I[323] || pbun5o[I[1]] == I[508] || pbun5o[I[1]] == I[509];
  });
}, window[I[510]] = function (ei74) {
  var alyd0 = this;if (ei74 && ei74[I[235]] === I[323] && ei74[I[234]]) {
    var y0asd = r4C[I[24]];y0asd[I[511]] = r4C[I[193]], y0asd[I[329]] = String(ei74[I[234]][I[512]]), y0asd[I[199]] = parseInt(ei74[I[234]][I[331]]);if (ei74[I[234]][I[513]]) y0asd[I[513]] = parseInt(ei74[I[234]][I[513]]);else y0asd[I[513]] = parseInt(ei74[I[234]][I[25]]);y0asd[I[514]] = 0x0, y0asd[I[22]] = r4C[I[375]], y0asd[I[515]] = ei74[I[234]][I[516]], y0asd[I[517]] = ei74[I[234]][I[517]];if (ei74[I[234]][I[518]]) y0asd[I[518]] = parseInt(ei74[I[234]][I[518]]);console[I[47]](I[519] + JSON[I[28]](y0asd[I[517]])), r4C[I[355]] == 0x1 && y0asd[I[517]] && y0asd[I[517]][I[520]] == 0x1 && (r4C[I[521]] = 0x1, window[I[37]][I[38]][I[522]]()), rCQ34();
  } else {
    if (r4C[I[505]][I[523]] >= 0x3) {
      var m_8zv6 = ei74 ? ei74[I[235]] : '';window[I[248]](0xc, I[524] + m_8zv6), rC3(JSON[I[28]](ei74)), window[I[220]](I[525] + m_8zv6);
    } else sendApi(r4C[I[181]], I[306], { 'platform': r4C[I[179]], 'partner_id': r4C[I[189]], 'token': r4C[I[304]], 'game_pkg': r4C[I[23]], 'deviceId': r4C[I[190]], 'scene': I[307] + r4C[I[191]] }, function (cz6tfv) {
      if (!cz6tfv || cz6tfv[I[235]] != I[323]) {
        window[I[220]](I[325] + cz6tfv && cz6tfv[I[235]]);return;
      }r4C[I[328]] = String(cz6tfv[I[329]]), r4C[I[330]] = String(cz6tfv[I[331]]), setTimeout(function () {
        rC3Q4(r4C[I[505]][I[523]] + 0x1, r4C[I[505]][I[25]]);
      }, 0x5dc);
    }, rQC4, rC3, function (tc6zfv) {
      return tc6zfv[I[235]] == I[323] || tc6zfv[I[235]] == I[526];
    });
  }
}, window[I[527]] = function () {
  ServerLoading[I[38]][I[367]](r4C[I[355]]), window[I[206]] = !![], window[I[69]]();
}, window[I[68]] = function () {
  if (window[I[67]] && window[I[76]] && window[I[207]] && window[I[208]] && window[I[209]] && window[I[211]]) {
    if (!window[I[528]][I[38]]) {
      console[I[47]](I[529] + window[I[528]][I[38]]);var v8_m3z = wx[I[530]](),
          _mv8 = v8_m3z[I[155]] ? v8_m3z[I[155]] : 0x0,
          cs2y = { 'cdn': window[I[16]][I[22]], 'spareCdn': window[I[16]][I[289]], 'newRegister': window[I[16]][I[355]], 'wxPC': window[I[16]][I[126]], 'wxIOS': window[I[16]][I[120]], 'wxAndroid': window[I[16]][I[123]], 'wxParam': { 'limitLoad': window[I[16]][I[130]], 'benchmarkLevel': window[I[16]][I[131]], 'wxFrom': window[I[6]][I[296]] == I[531] ? 0x1 : 0x0, 'wxSDKVersion': window[I[45]] }, 'configType': window[I[16]][I[200]], 'exposeType': window[I[16]][I[202]], 'scene': _mv8 };new window[I[528]](cs2y, window[I[16]][I[21]], window[I[173]]);
    }
  }
}, window[I[69]] = function () {
  if (window[I[67]] && window[I[76]] && window[I[207]] && window[I[208]] && window[I[209]] && window[I[211]] && window[I[206]] && window[I[210]]) {
    r34CQ();if (!rCQ4) {
      rCQ4 = !![];if (!window[I[528]][I[38]]) window[I[68]]();var g1$hxr = 0x0,
          $1grxh = wx[I[532]]();$1grxh && (window[I[16]][I[125]] && (g1$hxr = $1grxh[I[115]]), console[I[1]](I[533] + $1grxh[I[115]] + I[534] + $1grxh[I[116]] + I[535] + $1grxh[I[117]] + I[536] + $1grxh[I[118]] + I[537] + $1grxh[I[538]] + I[539] + $1grxh[I[540]]));var eiq7k = {};for (const $xp1g in r4C[I[24]]) {
        eiq7k[$xp1g] = r4C[I[24]][$xp1g];
      }var cz6vt = { 'channel': window[I[16]][I[194]], 'account': window[I[16]][I[20]], 'userId': window[I[16]][I[326]], 'cdn': window[I[16]][I[22]], 'data': window[I[16]][I[234]], 'package': window[I[16]][I[177]], 'newRegister': window[I[16]][I[355]], 'pkgName': window[I[16]][I[23]], 'partnerId': window[I[16]][I[189]], 'platform_uid': window[I[16]][I[327]], 'deviceId': window[I[16]][I[190]], 'selectedServer': eiq7k, 'configType': window[I[16]][I[200]], 'exposeType': window[I[16]][I[202]], 'debugUsers': window[I[16]][I[197]], 'wxMenuTop': g1$hxr, 'wxShield': window[I[16]][I[204]] };if (window[I[378]]) for (var hly$a in window[I[378]]) {
        cz6vt[hly$a] = window[I[378]][hly$a];
      }window[I[528]][I[38]][I[541]](cz6vt);if (r4C[I[24]] && r4C[I[24]][I[25]]) localStorage[I[542]](I[334] + r4C[I[23]] + r4C[I[20]], r4C[I[24]][I[25]]);
    }
  } else console[I[1]](I[543] + window[I[67]] + I[544] + window[I[76]] + I[545] + window[I[207]] + I[546] + window[I[208]] + I[547] + window[I[209]] + I[548] + window[I[211]] + I[549] + window[I[206]] + I[550] + window[I[210]]);
};