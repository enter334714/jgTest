var I = wx.$X;
require(I[37072]);
var config = {
    game_id: I[37073],
    game_pkg: I[37074], //666-多梦江湖-剑斩星辰
    partner_label: I[37075],
    partner_id: I[37076],
    game_ver: I[37077],
    platId: 1000,
    gameId: 289,
    channelVer: I[37078],
    mode: 2,
    is_auth: true, //授权登录
    tmpId: { 1: I[37079], 2: I[37080], 3: I[37081] // 订阅的类型 和 模板id
    } };
window.config = config;
var rX4C3Q = rXCQ34();
var HOST = I[37082];
var rX4CQ3 = null;
var rXC3Q4 = null;
var partner_data = {};

function rXCQ34() {
    var callbacks = {};
    return {
        order_data: {},
        init: function (ops, callback) {
            var game_ver = ops && ops.game_ver ? ops.game_ver : 0;
            console.log(I[37083]);
            var self = this;
            var uuid = wx.getStorageSync(I[37084]);
            var is_new;
            if (!uuid) {
                uuid = self.uuid(16, 32);
                wx.setStorageSync(I[37084], uuid);
                is_new = 1;
            } else {
                is_new = 0;
            }
            var idfv = wx.getStorageSync(I[37085]);
            if (!idfv) {
                idfv = self.uuid(16, 32);
                wx.setStorageSync(I[37085], idfv);
            }

            var info = wx.getLaunchOptionsSync();
            var scene = info.scene ? info.scene : '';

            //判断今天是否已经上报过
            if (is_new && info.query && info.query.ad_code) {
                wx.setStorageSync(I[37086], info.query.ad_code);
            }

            var data = {
                install: is_new,
                scene: scene
            };
            self.log(I[1908], data);
            //TODO 替换对应参数
            var sdkCallback = function (code, data) {
                switch (code) {
                    case I[37087]:
                        // 初始化成功
                        console.log(I[37088], code, data);
                        break;
                    case I[37089]:
                        // 初始化失败
                        console.log(I[37090], code, data);
                        break;
                    case I[37091]:
                        // 登录成功
                        console.log(I[37092], code, data);
                        self.do_login(data);
                        // 登录成功后会返回uname、gameToken、time、sign；CP拿这几个字段进行登录校验
                        break;
                    case I[37093]:
                        //登录失败
                        console.log(I[37094], code, data);
                        callbacks[I[301]] && callbacks[I[301]](1, {
                            errMsg: data.msg
                        });
                        break;
                    case I[37095]:
                        // 支付成功（支付以服务端返回为准）
                        console.log(I[37096], code, data);
                        break;
                    case I[37097]:
                        // 支付失败
                        console.log(I[37098], code, data);
                        callbacks[I[390]] && callbacks[I[390]](1, {
                            errMsg: data.errMsg
                        });
                        break;
                }
            };

            ddtSDKPlat.init({
                platId: config.platId,
                gameId: config.gameId,
                channelVer: config.channelVer,
                mode: config.mode
            }, sdkCallback, true);

            wx.showShareMenu({ withShareTicket: true });

            console.log(I[37099] + ddtSDKPlat.version);

            //玩家是分享过来的，单独上报给服务器
            var invite = info.query && info.query.invite ? info.query.invite : '';
            var invite_type = info.query && info.query.invite_type ? info.query.invite_type : '';

            if (invite) {
                rXC3Q4 = {
                    invite: invite,
                    invite_type: invite_type,
                    is_new: is_new,
                    scene: scene
                };
            }

            //判断版本号
            if (game_ver) {
                this.checkGameVersion(game_ver, function (data) {
                    callback && callback(data);
                });
            }
        },

        login: function (data, callback) {
            console.log(I[37100]);
            callbacks[I[301]] = typeof callback == I[612] ? callback : null;
        },

        do_login: function (info) {
            var self = this;
            partner_data = {
                uid: info.uid,
                gameToken: info.gameToken,
                time: info.time,
                sign: info.sign
            };
            var public_data = self.getPublicData();
            public_data[I[37101]] = 1;
            public_data[I[37102]] = JSON.stringify(partner_data);
            if (rXC3Q4 && typeof rXC3Q4 == I[609]) {
                for (var key in rXC3Q4) {
                    public_data[key] = rXC3Q4[key];
                }
            }

            //发起网络请求
            wx.request({
                url: I[7267] + HOST + I[37103],
                method: I[263],
                dataType: I[2170],
                header: {
                    'content-type': I[461] // 默认值
                },
                data: public_data,
                success: function (res) {
                    console.log(I[37104]);
                    console.log(res);
                    if (res.statusCode === 200) {
                        var data = res.data;
                        if (data.state) {
                            try {
                                wx.setStorageSync(I[37105], data.data.sdk_token);
                                wx.setStorageSync(I[37106], data.data.user_id);
                                wx.setStorageSync(I[37107], data.data.username);
                                if (data.data.ext) {
                                    wx.setStorageSync(I[37108], data.data.ext);
                                }
                            } catch (e) {}
                            var userData = {
                                userid: data.data.user_id,
                                account: data.data.nick_name,
                                token: data.data.token,
                                invite_uid: data.data.invite_uid || '',
                                invite_nickname: data.data.invite_nickname || '',
                                invite_head_img: data.data.invite_head_img || '',
                                head_img: data.data.head_img || '',
                                is_client: data.data.is_client || '0',
                                ios_pay: data.data.ios_pay || '0'
                            };
                            callbacks[I[301]] && callbacks[I[301]](0, userData);
                        } else {
                            callbacks[I[301]] && callbacks[I[301]](1, {
                                errMsg: data.msg
                            });
                        }

                        //登录成功，加载右上角分享数据
                        self.getShareInfo(I[37109], function (data) {
                            console.log(I[37110]);
                            wx.onShareAppMessage(function () {
                                //记录开始分享
                                self.logStartShare(I[37109]);
                                return {
                                    title: data.title,
                                    imageUrl: data.img,
                                    query: data.query
                                };
                            });
                        });
                    } else {
                        callbacks[I[301]] && callbacks[I[301]](1, {
                            errMsg: I[37111]
                        });
                    }
                }
            });
        },

        share: function (data) {
            callbacks[I[414]] = typeof callback == I[612] ? callback : null;
            var type = data.type || I[414];
            console.log(I[37112] + type);
            var self = this;

            this.getShareInfo(type, function (data) {

                //记录开始分享
                self.logStartShare(type);
                wx.shareAppMessage({
                    title: data.title,
                    imageUrl: data.img,
                    query: data.query
                });
            });
        },

        logStartShare: function (type) {
            var sdk_token = wx.getStorageSync(I[37105]);
            wx.request({
                url: I[7267] + HOST + I[37113],
                method: I[263],
                dataType: I[2170],
                header: {
                    'content-type': I[461] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    sdk_token: sdk_token,
                    server_id: rX4CQ3 ? rX4CQ3.server_id : '',
                    role_id: rX4CQ3 ? rX4CQ3.role_id : '',
                    type: type
                },
                success: function (res) {}
            });
        },

        openService: function () {
            wx.openCustomerServiceConversation();
        },

        checkGameVersion: function (game_ver, callback) {
            console.log(I[37114]);
            var sdk_token = wx.getStorageSync(I[37105]);
            wx.request({
                url: I[7267] + HOST + I[37115],
                method: I[263],
                dataType: I[2170],
                header: {
                    'content-type': I[461] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    game_ver: game_ver
                },
                success: function (res) {
                    console.log(I[37116]);
                    console.log(res);
                    if (res.statusCode == 200) {
                        var data = res.data;
                        if (data.state) {
                            callback && callback(data.data);
                        } else {
                            callback && callback({
                                develop: 0
                            });
                        }
                    } else {
                        callback && callback({
                            develop: 0
                        });
                    }
                }
            });
        },

        getShareInfo: function (type, callback) {
            console.log(I[37117]);
            var sdk_token = wx.getStorageSync(I[37105]);
            wx.request({
                url: I[7267] + HOST + I[37118],
                method: I[263],
                dataType: I[2170],
                header: {
                    'content-type': I[461] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    sdk_token: sdk_token,
                    type: type,
                    server_id: rX4CQ3 ? rX4CQ3.server_id : '',
                    role_id: rX4CQ3 ? rX4CQ3.role_id : '',
                    no_log: 1 //设置为1后就不在这个接口打log，交给logStartShare接口
                },
                success: function (res) {
                    console.log(I[37119]);
                    console.log(res);
                    if (res.statusCode == 200) {
                        var data = res.data;
                        if (data.state) {
                            callback && callback(data.data);
                        } else {
                            callbacks[I[414]] && callbacks[I[414]](1, {
                                errMsg: I[37120] + data.msg
                            });
                        }
                    } else {
                        callbacks[I[414]] && callbacks[I[414]](1, {
                            errMsg: I[37121]
                        });
                    }
                }
            });
        },

        updateShare: function (invite, invite_type, is_new, role_id, server_id, scene) {
            console.log(I[37122]);
            var sdk_token = wx.getStorageSync(I[37105]);
            wx.request({
                url: I[7267] + HOST + I[37123],
                method: I[263],
                dataType: I[2170],
                header: {
                    'content-type': I[461] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    sdk_token: sdk_token,
                    invite: invite,
                    invite_type: invite_type,
                    is_new: is_new,
                    role_id: role_id,
                    sever_id: server_id,
                    scene: scene
                },
                success: function (res) {
                    console.log(I[37124]);
                    console.log(res);
                }
            });
        },

        msgCheck: function (content, callback) {
            console.log(I[37125]);
            var sdk_token = wx.getStorageSync(I[37105]);
            wx.request({
                url: I[7267] + HOST + I[37126] + config.partner_id + '/' + config.game_pkg,
                method: I[263],
                dataType: I[2170],
                header: {
                    'content-type': I[461] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    sdk_token: sdk_token,
                    content: content,
                    gameToken: partner_data.gameToken,
                    uid: partner_data.uid,
                    channelVer: config.channelVer,
                    gameId: config.gameId,
                    platId: config.platId
                },
                success: function (res) {
                    console.log(I[37127]);
                    console.log(res);
                    callback && callback(res);
                }
            });
        },

        pay: function (data, callback) {
            var self = this;
            self.startPay(data, callback);
        },

        //支付接口
        startPay: function (data, callback) {
            console.log(I[37128]);
            console.log(data);

            var self = this;
            callbacks[I[390]] = typeof callback == I[612] ? callback : null;
            //先下单
            var sdk_token = wx.getStorageSync(I[37105]);
            var session_key = wx.getStorageSync(I[37108]);
            if (!sdk_token && !session_key) {
                callbacks[I[390]] && callbacks[I[390]](1, {
                    errMsg: I[37129]
                });
                return;
            }

            var sysInfo = wx.getSystemInfoSync();

            var order_data = {
                cpbill: data.cpbill,
                productid: data.productid,
                productname: data.productname,
                productdesc: data.productdesc,
                serverid: data.serverid,
                servername: data.servername,
                roleid: data.roleid,
                rolename: data.rolename,
                rolelevel: data.rolelevel,
                price: data.price,
                extension: data.extension,
                sdk_token: sdk_token,
                session_key: session_key,
                platform: sysInfo.platform
            };
            self.order_data = order_data;

            var public_data = self.getPublicData();
            public_data[I[37130]] = JSON.stringify(order_data);
            public_data[I[37101]] = 1;

            //发起网络请求
            wx.request({
                url: I[7267] + HOST + I[37131],
                method: I[263],
                dataType: I[2170],
                header: {
                    'content-type': I[461] // 默认值
                },
                data: public_data,
                success: function (res) {
                    console.log(I[37132]);
                    console.log(res);
                    if (res.statusCode == 200) {
                        var data = res.data;
                        if (data.data.ext == '') {
                            if (data.state && data.data.pay_data) {
                                //TODO 替换对应方法
                                if (data.data.ext == '') {
                                    console.log(I[37133] + JSON.stringify(data.data.pay_data));
                                    var payInfo = {
                                        billNo: data.data.pay_data.billNo,
                                        amount: data.data.pay_data.amount,
                                        serverId: data.data.pay_data.serverId,
                                        roleId: data.data.pay_data.roleId,
                                        roleName: data.data.pay_data.roleName,
                                        roleLevel: data.data.pay_data.roleLevel,
                                        subject: data.data.pay_data.subject,
                                        productDesc: data.data.pay_data.productDesc,
                                        extraInfo: data.data.pay_data.extraInfo
                                    };
                                    ddtSDKPlat.pay(payInfo);
                                } else {
                                    self.extDo({ ext1: data.data.ext, ext2: data.data.pay_data });
                                }
                            } else {
                                self.extDo({ ext1: data.data.ext, ext2: data.data.pay_data });
                            }
                        } else {
                            callbacks[I[390]] && callbacks[I[390]](1, {
                                errMsg: data.errMsg
                            });
                        }
                    } else {
                        callbacks[I[301]] && callbacks[I[301]](1, {
                            errMsg: I[37111]
                        });
                    }
                }
            });
        },

        extDo: function (data) {
            wx.navigateToMiniProgram({
                appId: data.ext1,
                path: I[37134] + data.ext2.billNo + I[37135] + data.ext2.amount,
                extraData: {},
                envVersion: I[3485],
                success(res) {
                    // 打开成功
                }
            });
        },

        extDo: function (data) {
            wx.navigateToMiniProgram({
                appId: data.ext1,
                path: I[37134] + data.ext2.extraInfo + I[37135] + data.ext2.amount,
                extraData: {},
                envVersion: I[3485],
                success(res) {
                    // 打开成功
                }
            });
        },

        logCreateRole: function (data) {
            var uid = wx.getStorageSync(I[37106]);
            var username = wx.getStorageSync(I[37107]);

            var postData = {};
            postData[I[37136]] = uid;
            postData[I[37137]] = username;
            postData[I[17768]] = data.roleid;
            postData[I[37138]] = data.rolelevel;
            postData[I[37139]] = data.rolename;
            postData[I[25]] = data.serverid;

            if (data.roleid && data.serverid) {
                rX4CQ3 = {
                    role_id: data.roleid,
                    server_id: data.serverid
                };
            }
            this.log(I[618], postData);
            var roleInfo = {
                roleLevel: data.rolelevel + '',
                roleId: data.roleid + '',
                roleName: data.rolename,
                serverName: data.servername,
                serverId: data.serverid + ''
            };

            ddtSDKPlat.submitData(I[14769], roleInfo);
        },

        //进入游戏
        logEnterGame: function (data, callback) {
            var uid = wx.getStorageSync(I[37106]);
            var username = wx.getStorageSync(I[37107]);

            var postData = {};
            postData[I[37136]] = uid;
            postData[I[37137]] = username;
            postData[I[17768]] = data.roleid;
            postData[I[37138]] = data.rolelevel;
            postData[I[37139]] = data.rolename;
            postData[I[25]] = data.serverid;

            if (data.roleid && data.serverid) {
                rX4CQ3 = {
                    role_id: data.roleid,
                    server_id: data.serverid
                };
            }

            this.log(I[1894], postData);

            var roleInfo = {
                roleLevel: data.rolelevel,
                roleId: data.roleid,
                roleName: data.rolename,
                serverName: data.servername,
                serverId: data.serverid

            };

            ddtSDKPlat.submitData(I[18909], roleInfo);

            //进入游戏确认邀请成功
            if (rXC3Q4) {
                this.updateShare(rXC3Q4.invite, rXC3Q4.invite_type, rXC3Q4.is_new, data.roleid, data.serverid, rXC3Q4.scene);
            }
        },

        //角色升级
        logRoleUpLevel: function (data, callback) {
            var uid = wx.getStorageSync(I[37106]);
            var username = wx.getStorageSync(I[37107]);
            this.log(I[37140], data);

            var postData = {};
            postData[I[37136]] = uid;
            postData[I[37137]] = username;
            postData[I[17768]] = data.roleid;
            postData[I[37138]] = data.rolelevel;
            postData[I[37139]] = data.rolename;
            postData[I[25]] = data.serverid;

            if (data.roleid && data.serverid) {
                rX4CQ3 = {
                    role_id: data.roleid,
                    server_id: data.serverid,
                    role_level: data.rolelevel,
                    role_createtime: data.rolecreatetime

                };
            }

            var roleInfo = {
                roleLevel: data.rolelevel,
                roleId: data.roleid,
                roleName: data.rolename,
                serverName: data.servername,
                serverId: data.serverid,
                rolecreatetime: data.rolecreatetime,
                vipLevel: "",
                power: "",
                roleSex: "",
                partyId: "",
                partyName: ""
            };

            ddtSDKPlat.submitData(I[37141], roleInfo);
        },

        subscribeMessage: function (tmplIds, callback) {
            console.log(I[37142] + tmplIds);
            //获取模板ID
            callbacks[I[427]] = typeof callback == I[612] ? callback : null;
            wx.requestSubscribeMessage({
                tmplIds: tmplIds,
                success(res) {
                    console.log(I[37143]);
                    console.log(res);
                    callbacks[I[427]] && callbacks[I[427]](res);
                },
                fail(res) {
                    console.log(I[37144]);
                    console.log(res);
                    callbacks[I[427]] && callbacks[I[427]](res);
                }
            });
        },
        // 微端小助手
        weiduanHelper: function () {
            console.log(I[37145]);
            ddtSDKPlat.jump();
            // var queryConfig={
            //     "channelVer" : config.channelVer,
            //     "gameId" : config.gameId, 
            //     "gameToken" :partner_data.gameToken , 
            //     "mode" :config.mode,
            //     "platId":config.platId,
            //     "roleId":user_game_info.role_id,
            //     "roleLevel":user_game_info.role_level,
            //     "rolecreatetime":user_game_info.role_createtime,
            //     "sceneId":'enterGame',
            //     "serverId":user_game_info.server_id,
            //     "time":Date.parse(new Date()),
            //     "uid":partner_data.uid,
            //     "sign":'',
            //     "partyId":'',
            //     "partyName":'',
            //     "power":'',
            //     "roleSex":'',
            //     "vipLevel":'',
            // };
            // var _str = "";
            // for(var o in queryConfig){
            //     if(queryConfig[o] != -1){
            //         _str += o + "=" + queryConfig[o] + "&";
            //     }
            // };
            //  _str = _str.substr(0, _str.length-1);
            // var sendMessagePath = _str;
            // wx.openCustomerServiceConversation({
            //     sessionFrom: 'turngame',
            //     showMessageCard:true,
            //     sendMessageTitle: '多梦江湖',
            //     sendMessagePath:sendMessagePath,
            //     sendMessageImg: '',
            //     success:function(res){
            //         console.log("weiduan helper success");
            //     },
            //     fail:function(res){
            //         console.log("weiduan helper fail");
            //     },
            //     complete:function(res){
            //         console.log("weiduan helper complete");
            //     }
            // })
        },

        //获取唯一设备码（自定义）
        uuid: function (radix, len) {
            var chars = I[37146].split('');
            var uuid = [],
                i;
            radix = radix || chars.length;

            if (len) {
                for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
            } else {
                var r;

                uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
                uuid[14] = '4';

                for (i = 0; i < 36; i++) {
                    if (!uuid[i]) {
                        r = 0 | Math.random() * 16;
                        uuid[i] = chars[i == 19 ? r & 0x3 | 0x8 : r];
                    }
                }
            }

            return uuid.join('');
        },

        //获取公共参数
        getPublicData: function () {
            var system = wx.getSystemInfoSync();
            var uuid = wx.getStorageSync(I[37084]);
            var idfv = wx.getStorageSync(I[37085]);
            var ad_code = wx.getStorageSync(I[37086]);

            return {
                game_id: config.game_id,
                game_pkg: config.game_pkg,
                partner_id: config.partner_id,
                partner_label: config.partner_label,
                ad_code: ad_code,
                uuid: uuid,
                idfv: idfv,
                dname: system.model,
                mac: I[37147],
                net_type: system.wifiSignal == 0 ? I[37148] : I[37149],
                os_ver: system.system,
                sdk_ver: system.version, //存放的是微信版本号
                game_ver: config.game_ver, //存放的是SDK版本号
                device: system.platform == I[124] ? 1 : 2
            };
        },

        //统一发送log
        log: function (type, data) {
            var public_data = this.getPublicData();
            for (var key in data) {
                public_data[key] = data[key];
            }

            console.log(I[37150] + type);
            console.log(public_data);

            wx.request({
                url: I[7267] + HOST + I[37151] + type + I[37152] + encodeURIComponent(JSON.stringify(public_data))
            });
        },

        getDate: function () {
            var date = new Date();
            return date.getFullYear() + '-' + date.getMonth() + '-' + date.getDate();
        },

        downloadClient: function () {
            wx.openCustomerServiceConversation();
        }
    };
}

function run(method, data, callback) {
    method in rX4C3Q && rX4C3Q[method](data, callback);
}

exports.init = function (data, callback) {
    run(I[276], data, callback);
};

exports.login = function (callback) {
    run(I[301], '', callback);
};

exports.pay = function (data, callback) {
    run(I[390], data, callback);
};

exports.openService = function () {
    run(I[415]);
};

exports.logCreateRole = function (serverId, serverName, roleId, roleName, roleLevel) {
    var data = {
        serverid: serverId,
        servername: serverName,
        roleid: roleId,
        rolename: roleName,
        rolelevel: roleLevel
    };
    run(I[405], data);
};

exports.logEnterGame = function (serverId, serverName, roleId, roleName, roleLevel, rolecreatetime, callback) {
    var data = {
        serverid: serverId,
        servername: serverName,
        roleid: roleId,
        rolename: roleName,
        rolelevel: roleLevel,
        rolecreatetime: rolecreatetime
    };

    run(I[408], data, callback);
};

exports.logRoleUpLevel = function (serverId, serverName, roleId, roleName, roleLevel, rolecreatetime, callback) {
    var data = {
        serverid: serverId,
        servername: serverName,
        roleid: roleId,
        rolename: roleName,
        rolelevel: roleLevel,
        rolecreatetime: rolecreatetime
    };
    run(I[411], data, callback);
};

exports.share = function (type) {
    var data = {
        type: type
    };
    run(I[414], data);
};
exports.subscribeMessage = function (data, callback) {
    run(I[427], data, callback);
};

exports.msgCheck = function (data, callback) {
    run(I[233], data, callback);
};

exports.downloadClient = function () {
    run(I[37153]);
};

exports.getConfig = function () {
    return {
        game_id: config.game_id,
        game_pkg: config.game_pkg,
        partner_id: config.partner_id
    };
};

exports.getPublicData = function () {
    run(I[37154]);
};
exports.weiduanHelper = function () {
    run(I[417]);
};