var I = wx.$X;
console[I[1]](I[2]), window[I[3]], wx[I[4]](function (c0tf26) {
  if (c0tf26) {
    if (c0tf26[I[5]]) {
      var t6cvz = window[I[6]][I[7]][I[8]](new RegExp(/\./, 'g'), '_'),
          ylsd2 = c0tf26[I[5]],
          z8vt_ = ylsd2[I[9]](/(rmmmr\/rGAMErr.js:)[0-9]{1,60}(:)/g);if (z8vt_) for (var ogrb1p = 0x0; ogrb1p < z8vt_[I[10]]; ogrb1p++) {
        if (z8vt_[ogrb1p] && z8vt_[ogrb1p][I[10]] > 0x0) {
          var f0c2d = parseInt(z8vt_[ogrb1p][I[8]](I[11], '')[I[8]](':', ''));ylsd2 = ylsd2[I[8]](z8vt_[ogrb1p], z8vt_[ogrb1p][I[8]](':' + f0c2d + ':', ':' + (f0c2d - 0x2) + ':'));
        }
      }ylsd2 = ylsd2[I[8]](new RegExp(I[12], 'g'), I[13] + t6cvz + I[14]), ylsd2 = ylsd2[I[8]](new RegExp(I[15], 'g'), I[13] + t6cvz + I[14]), c0tf26[I[5]] = ylsd2;
    }var t2f6z = { 'id': window[I[16]][I[17]], 'role': window[I[16]][I[18]], 'level': window[I[16]][I[19]], 'user': window[I[16]][I[20]], 'version': window[I[16]][I[21]], 'cdn': window[I[16]][I[22]], 'pkgName': window[I[16]][I[23]], 'gamever': window[I[6]][I[7]], 'serverid': window[I[16]][I[24]] ? window[I[16]][I[24]][I[25]] : 0x0, 'systemInfo': window[I[26]], 'error': I[27], 'stack': c0tf26 ? c0tf26[I[5]] : '' },
        or1p$ = JSON[I[28]](t2f6z);console[I[29]](I[30] + or1p$), (!window[I[3]] || window[I[3]] != t2f6z[I[29]]) && (window[I[3]] = t2f6z[I[29]], window[I[31]](t2f6z));
  }
});import 'rsfs32r.js';import 'rr12rr.js';window[I[32]] = require(I[33]);import 'rINDEXr.js';import 'rrLIB12r.js';import 'rWXMsadrr.js';import 'rrINITMINrr.js';console[I[1]](I[34]), console[I[1]](I[35]), r34QC({ 'title': I[36] });var xv6zctf = { 'rX3C4Q': !![] };new window[I[37]](xv6zctf), window[I[37]][I[38]][I[39]]();if (window[I[40]]) clearInterval(window[I[40]]);window[I[40]] = null, window[I[41]] = function (pgnor, t6f02c) {
  if (!pgnor || !t6f02c) return 0x0;pgnor = pgnor[I[42]]('.'), t6f02c = t6f02c[I[42]]('.');const n75qk = Math[I[43]](pgnor[I[10]], t6f02c[I[10]]);while (pgnor[I[10]] < n75qk) {
    pgnor[I[44]]('0');
  }while (t6f02c[I[10]] < n75qk) {
    t6f02c[I[44]]('0');
  }for (var gb1po = 0x0; gb1po < n75qk; gb1po++) {
    const unbo5p = parseInt(pgnor[gb1po]),
          noup = parseInt(t6f02c[gb1po]);if (unbo5p > noup) return 0x1;else {
      if (unbo5p < noup) return -0x1;
    }
  }return 0x0;
}, window[I[45]] = wx[I[46]]()[I[45]], console[I[47]](I[48] + window[I[45]]);var xt02fd = wx[I[49]]();xt02fd[I[50]](function (unorbp) {
  console[I[47]](I[51] + unorbp[I[52]]);
}), xt02fd[I[53]](function () {
  wx[I[54]]({ 'title': I[55], 'content': I[56], 'showCancel': ![], 'success': function (zm_86) {
      xt02fd[I[57]]();
    } });
}), xt02fd[I[58]](function () {
  console[I[47]](I[59]);
}), window[I[60]] = function () {
  console[I[47]](I[61]);var z6f2c = wx[I[62]]({ 'name': I[63], 'success': function (xhg1) {
      console[I[47]](I[64]), console[I[47]](xhg1), xhg1 && xhg1[I[65]] == I[66] ? (window[I[67]] = !![], window[I[68]](), window[I[69]]()) : setTimeout(function () {
        window[I[60]]();
      }, 0x1f4);
    }, 'fail': function (ongpb) {
      console[I[47]](I[70]), console[I[47]](ongpb), setTimeout(function () {
        window[I[60]]();
      }, 0x1f4);
    } });z6f2c && z6f2c[I[71]](s0ldya => {});
}, window[I[72]] = function () {
  console[I[47]](I[73]);var $pgr1x = wx[I[62]]({ 'name': I[74], 'success': function (rg1x$h) {
      console[I[47]](I[75]), console[I[47]](rg1x$h), rg1x$h && rg1x$h[I[65]] == I[66] ? (window[I[76]] = !![], window[I[68]](), window[I[69]]()) : setTimeout(function () {
        window[I[72]]();
      }, 0x1f4);
    }, 'fail': function (i47k) {
      console[I[47]](I[77]), console[I[47]](i47k), setTimeout(function () {
        window[I[72]]();
      }, 0x1f4);
    } });$pgr1x && $pgr1x[I[71]](gop$1r => {});
}, window[I[78]] = function () {
  window[I[41]](window[I[45]], I[79]) >= 0x0 ? (console[I[47]](I[80] + window[I[45]] + I[81]), window[I[82]](), window[I[60]](), window[I[72]]()) : (window[I[83]](I[84], window[I[45]]), wx[I[54]]({ 'title': I[85], 'content': I[86] }));
}, window[I[26]] = '', wx[I[87]]({ 'success'($a) {
    window[I[26]] = I[88] + $a[I[89]] + I[90] + $a[I[91]] + I[92] + $a[I[93]] + I[94] + $a[I[95]] + I[96] + $a[I[97]] + I[98] + $a[I[45]] + I[99] + $a[I[100]], console[I[47]](window[I[26]]), console[I[47]](I[101] + $a[I[102]] + I[103] + $a[I[104]] + I[105] + $a[I[106]] + I[107] + $a[I[108]] + I[109] + $a[I[110]] + I[111] + $a[I[112]] + I[113] + ($a[I[114]] ? $a[I[114]][I[115]] + ',' + $a[I[114]][I[116]] + ',' + $a[I[114]][I[117]] + ',' + $a[I[114]][I[118]] : ''));var pnr = $a[I[95]] ? $a[I[95]][I[119]]() : '',
        ctz2f = $a[I[91]] ? $a[I[91]][I[119]]()[I[8]]('\x20', '') : '';window[I[16]][I[120]] = pnr[I[121]](I[122]) != -0x1, window[I[16]][I[123]] = pnr[I[121]](I[124]) != -0x1, window[I[16]][I[125]] = pnr[I[121]](I[122]) != -0x1 || pnr[I[121]](I[124]) != -0x1, window[I[16]][I[126]] = pnr[I[121]](I[127]) != -0x1 || pnr[I[121]](I[128]) != -0x1, window[I[16]][I[129]] = $a[I[97]] ? $a[I[97]][I[119]]() : '', window[I[16]][I[130]] = ![], window[I[16]][I[131]] = 0x2;if (pnr[I[121]](I[124]) != -0x1) {
      if ($a[I[100]] >= 0x18) window[I[16]][I[131]] = 0x3;else window[I[16]][I[131]] = 0x2;
    } else {
      if (pnr[I[121]](I[122]) != -0x1) {
        if ($a[I[100]] && $a[I[100]] >= 0x14) window[I[16]][I[131]] = 0x3;else {
          if (ctz2f[I[121]](I[132]) != -0x1 || ctz2f[I[121]](I[133]) != -0x1 || ctz2f[I[121]](I[134]) != -0x1 || ctz2f[I[121]](I[135]) != -0x1 || ctz2f[I[121]](I[136]) != -0x1) window[I[16]][I[131]] = 0x2;else window[I[16]][I[131]] = 0x3;
        }
      } else window[I[16]][I[131]] = 0x2;
    }console[I[47]](I[137] + window[I[16]][I[130]] + I[138] + window[I[16]][I[131]]);
  } }), wx[I[139]]({ 'success': function (g$o) {
    console[I[47]](I[140] + g$o[I[141]] + I[142] + g$o[I[143]]);
  } }), wx[I[144]]({ 'success': function (slyxa) {
    console[I[47]](I[145] + slyxa[I[146]]);
  } }), wx[I[147]]({ 'keepScreenOn': !![] }), wx[I[148]](function (hyaxl) {
  console[I[47]](I[145] + hyaxl[I[146]] + I[149] + hyaxl[I[150]]);
}), wx[I[151]](function (fc6tv) {
  window[I[152]] = fc6tv, window[I[153]] && window[I[152]] && (console[I[1]](I[154] + window[I[152]][I[155]]), window[I[153]](window[I[152]]), window[I[152]] = null);
}), window[I[156]] = 0x0, window[I[157]] = 0x0, window[I[158]] = null, wx[I[159]](function () {
  window[I[157]]++;var i547kq = Date[I[160]]();(window[I[156]] == 0x0 || i547kq - window[I[156]] > 0x1d4c0) && (console[I[161]](I[162]), wx[I[163]]());if (window[I[157]] >= 0x2) {
    window[I[157]] = 0x0, console[I[29]](I[164]), wx[I[165]]('0', 0x1);if (window[I[16]] && window[I[16]][I[120]]) window[I[83]](I[166], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});