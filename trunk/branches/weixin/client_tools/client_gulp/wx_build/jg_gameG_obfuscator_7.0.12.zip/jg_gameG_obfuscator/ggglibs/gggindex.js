var m = wx.$g;
import ghw1yxk from '../gggsdk/gggsdk.js';window[m[26822]] = { 'wxVersion': window[m[530]][m[26720]] }, window['DEBUG'] = ![], window['G$J3'] = 0x1, window[m[26823]] = 0x1, window['G$03J'] = !![], window[m[26824]] = !![], window['G$V20J3'] = '', window['G$3J'] = { 'base_cdn': m[26825], 'cdn': m[26825] }, G$3J[m[26826]] = {}, G$3J[m[23040]] = '0', G$3J[m[4267]] = window[m[26822]][m[26827]], G$3J[m[26795]] = '', G$3J['os'] = '1', G$3J[m[26828]] = m[26829], G$3J[m[26830]] = m[26831], G$3J[m[26832]] = m[26833], G$3J[m[26834]] = m[26835], G$3J[m[26836]] = 'MQx0mYlUWO5XYKvgAIPKWgK1w722GKih', G$3J[m[22079]] = '1', G$3J[m[23339]] = '', G$3J[m[23341]] = '', G$3J[m[26837]] = 0x0, G$3J[m[26838]] = {}, G$3J[m[26839]] = parseInt(G$3J[m[22079]]), G$3J[m[23337]] = G$3J[m[22079]], G$3J[m[23333]] = {}, G$3J['G$23'] = m[26840], G$3J[m[26841]] = ![], G$3J[m[11013]] = m[26842], G$3J[m[23311]] = Date[m[77]](), G$3J[m[10671]] = m[26843], G$3J[m[683]] = '_a', G$3J[m[26844]] = 0x2, G$3J[m[95]] = 0x7c1, G$3J[m[26827]] = window[m[26822]][m[26827]], G$3J[m[698]] = ![], G$3J[m[486]] = ![], G$3J[m[10330]] = ![], G$3J[m[23042]] = ![], window['G$0J3'] = 0x5, window['G$0J'] = ![], window['G$J0'] = ![], window['G$30J'] = ![], window[m[26845]] = ![], window[m[26846]] = ![], window['G$3J0'] = ![], window['G$03'] = ![], window['G$30'] = ![], window['G$J03'] = ![], window[m[26847]] = {}, window[m[3748]] = function (o6z2r) {
  console[m[456]](m[3748], o6z2r), wx[m[4536]]({}), wx[m[26744]]({ 'title': m[5928], 'content': o6z2r, 'success'(cvegq7) {
      if (cvegq7[m[26848]]) console[m[456]](m[26849]);else cvegq7[m[526]] && console[m[456]](m[26850]);
    } });
}, window['G$203J'] = function (p0bt) {
  console[m[456]](m[26851], p0bt), G$23J0(), wx[m[26744]]({ 'title': m[5928], 'content': p0bt, 'confirmText': m[26852], 'cancelText': m[17113], 'success'(ai51hx) {
      if (ai51hx[m[26848]]) window['G$32']();else ai51hx[m[526]] && (console[m[456]](m[26853]), wx[m[23490]]({}));
    } });
}, window['G$JV3'] = function (i5bp_) {
  console[m[456]](m[26854], i5bp_), wx[m[26744]]({ 'title': m[5928], 'content': i5bp_, 'confirmText': m[23463], 'showCancel': ![], 'complete'(od3f4) {
      console[m[456]](m[26853]), wx[m[23490]]({});
    } });
}, window['G$20J3'] = ![], window['G$230J'] = function (ye7w) {
  window['G$20J3'] = !![], wx[m[4535]](ye7w);
}, window['G$23J0'] = function () {
  window['G$20J3'] && (window['G$20J3'] = ![], wx[m[4536]]({}));
}, window['G$2J03'] = function (slg9) {
  window[m[26735]][m[141]]['G$2J03'](slg9);
}, window[m[10929]] = function (p5ab0i, sgqcv7) {
  ghw1yxk[m[10929]](p5ab0i, function (ur62$j) {
    ur62$j && ur62$j[m[11]] ? ur62$j[m[11]][m[3685]] == 0x1 ? sgqcv7(!![]) : (sgqcv7(![]), console[m[72]](m[26855] + ur62$j[m[11]][m[26856]])) : console[m[456]](m[10929], ur62$j);
  });
}, window['G$2J30'] = function (cqs7g) {
  console[m[456]](m[26857], cqs7g);
}, window['G$23J'] = function (mr6) {}, window['G$2J3'] = function (h1i5a, rm$, yevqw) {}, window['G$2J'] = function (fdo43t) {
  console[m[456]]('toEnterGame', fdo43t), window[m[26735]][m[141]][m[26858]](), window[m[26735]][m[141]][m[26859]](), window[m[26735]][m[141]][m[26860]]();
}, window['G$J2'] = function (ax1h5) {
  window['G$203J'](m[26861]);var fp50_ = { 'id': window['G$3J'][m[26725]], 'role': window['G$3J'][m[4198]], 'level': window['G$3J'][m[26726]], 'account': window['G$3J'][m[23338]], 'version': window['G$3J'][m[95]], 'cdn': window['G$3J'][m[4077]], 'pkgName': window['G$3J'][m[23339]], 'gamever': window[m[530]][m[26720]], 'serverid': window['G$3J'][m[23333]] ? window['G$3J'][m[23333]][m[10493]] : 0x0, 'systemInfo': window[m[26727]], 'error': m[26862], 'stack': ax1h5 ? ax1h5 : m[26861] },
      to4z3d = JSON[m[4063]](fp50_);console[m[119]](m[26863] + to4z3d), window['G$23'](to4z3d);
}, window['G$32J'] = function ($6j2) {
  var e7wyk = JSON[m[502]]($6j2);e7wyk[m[26864]] = window[m[530]][m[26720]], e7wyk[m[26865]] = window['G$3J'][m[23333]] ? window['G$3J'][m[23333]][m[10493]] : 0x0, e7wyk[m[26727]] = window[m[26727]];var pxi5b = JSON[m[4063]](e7wyk);console[m[119]](m[26866] + pxi5b), window['G$23'](pxi5b);
}, window['G$3J2'] = function (dz34ot, baxip) {
  var wk1v = { 'id': window['G$3J'][m[26725]], 'role': window['G$3J'][m[4198]], 'level': window['G$3J'][m[26726]], 'account': window['G$3J'][m[23338]], 'version': window['G$3J'][m[95]], 'cdn': window['G$3J'][m[4077]], 'pkgName': window['G$3J'][m[23339]], 'gamever': window[m[530]][m[26720]], 'serverid': window['G$3J'][m[23333]] ? window['G$3J'][m[23333]][m[10493]] : 0x0, 'systemInfo': window[m[26727]], 'error': dz34ot, 'stack': baxip },
      cq8ls = JSON[m[4063]](wk1v);console[m[90]](m[26867] + cq8ls), window['G$23'](cq8ls);
}, window['G$23'] = function (tb0f) {
  if (window['G$3J'][m[26796]] == m[26868]) return;var j6u$r2 = G$3J['G$23'] + m[26869] + G$3J[m[23338]];wx[m[451]]({ 'url': j6u$r2, 'method': m[26870], 'data': tb0f, 'header': { 'content-type': m[26871], 'cache-control': m[26872] }, 'success': function (xai51) {
      DEBUG && console[m[456]](m[26873], j6u$r2, tb0f, xai51);
    }, 'fail': function (veykw1) {
      DEBUG && console[m[456]](m[26873], j6u$r2, tb0f, veykw1);
    }, 'complete': function () {} });
}, window[m[26874]] = function () {
  function x1kaw() {
    return ((0x1 + Math[m[113]]()) * 0x10000 | 0x0)[m[263]](0x10)[m[474]](0x1);
  }return x1kaw() + x1kaw() + '-' + x1kaw() + '-' + x1kaw() + '-' + x1kaw() + '+' + x1kaw() + x1kaw() + x1kaw();
}, window['G$32'] = function () {
  console[m[456]](m[26875]);var piab5 = ghw1yxk[m[26876]]();G$3J[m[23337]] = piab5[m[26877]], G$3J[m[26839]] = piab5[m[26877]], G$3J[m[22079]] = piab5[m[26877]], G$3J[m[23339]] = piab5[m[26878]];var wvy1ke = { 'game_ver': G$3J[m[4267]] };G$3J[m[23341]] = this[m[26874]](), G$230J({ 'title': m[26879] }), ghw1yxk[m[355]](wvy1ke, this['G$J23'][m[68]](this));
}, window['G$J23'] = function (f43_0t) {
  var ykwev = f43_0t[m[26880]];sdk_info = f43_0t, console[m[456]](m[26881] + ykwev + m[26882] + (ykwev == 0x1) + m[26883] + f43_0t[m[26720]] + m[26884] + window[m[26822]][m[26827]]);if (!f43_0t[m[26720]] || window['G$V0J32'](window[m[26822]][m[26827]], f43_0t[m[26720]]) < 0x0) console[m[456]](m[26885]), G$3J[m[26830]] = m[26886], G$3J[m[26832]] = m[26887], G$3J[m[26834]] = m[26888], G$3J[m[4077]] = m[26889], G$3J[m[23039]] = m[26890], G$3J[m[26891]] = 'ws', G$3J[m[698]] = ![];else window['G$V0J32'](window[m[26822]][m[26827]], f43_0t[m[26720]]) == 0x0 ? (console[m[456]](m[26892]), G$3J[m[26830]] = m[26831], G$3J[m[26832]] = m[26833], G$3J[m[26834]] = m[26835], G$3J[m[4077]] = m[26893], G$3J[m[23039]] = m[26890], G$3J[m[26891]] = m[26894], G$3J[m[698]] = !![]) : (console[m[456]](m[26895]), G$3J[m[26830]] = m[26831], G$3J[m[26832]] = m[26833], G$3J[m[26834]] = m[26835], G$3J[m[4077]] = m[26893], G$3J[m[23039]] = m[26890], G$3J[m[26891]] = m[26894], G$3J[m[698]] = ![]);G$3J[m[26837]] = config[m[26600]] ? config[m[26600]] : 0x0, this['G$032J'](), this['G$03J2'](), window[m[26896]] = 0x5, G$230J({ 'title': m[26897] }), ghw1yxk[m[26898]](this['G$J32'][m[68]](this));
}, window[m[26896]] = 0x5, window['G$J32'] = function (p5f0b, f3t4_o) {
  if (p5f0b == 0x0 && f3t4_o && f3t4_o[m[26691]]) {
    G$3J[m[26899]] = f3t4_o[m[26691]], G$3J[m[26900]] = f3t4_o[m[26900]];var ey1hkw = this;G$230J({ 'title': m[26901] }), sendApi(G$3J[m[26830]], m[26902], { 'platform': G$3J[m[26828]], 'partner_id': G$3J[m[22079]], 'token': f3t4_o[m[26691]], 'game_pkg': G$3J[m[23339]], 'deviceId': G$3J[m[23341]], 'scene': m[26903] + G$3J[m[26837]] }, this['G$023J'][m[68]](this), G$0J3, G$J2);
  } else f3t4_o && f3t4_o[m[23517]] && window[m[26896]] > 0x0 && (f3t4_o[m[23517]][m[109]](m[26904]) != -0x1 || f3t4_o[m[23517]][m[109]](m[26905]) != -0x1 || f3t4_o[m[23517]][m[109]](m[26906]) != -0x1 || f3t4_o[m[23517]][m[109]](m[26907]) != -0x1 || f3t4_o[m[23517]][m[109]](m[26908]) != -0x1 || f3t4_o[m[23517]][m[109]](m[26909]) != -0x1) ? (window[m[26896]]--, ghw1yxk[m[26898]](this['G$J32'][m[68]](this))) : (window['G$3J2'](m[26910], JSON[m[4063]]({ 'status': p5f0b, 'data': f3t4_o })), window['G$203J'](m[26911] + (f3t4_o && f3t4_o[m[23517]] ? '，' + f3t4_o[m[23517]] : '')));
}, window['G$023J'] = function (rdz) {
  if (!rdz) {
    window['G$3J2'](m[26912], m[26913]), window['G$203J'](m[26914]);return;
  }if (rdz[m[3685]] != m[9072]) {
    window['G$3J2'](m[26912], JSON[m[4063]](rdz)), window['G$203J'](m[26915] + rdz[m[3685]]);return;
  }G$3J[m[22078]] = String(rdz[m[23338]]), G$3J[m[23338]] = String(rdz[m[23338]]), G$3J[m[23309]] = String(rdz[m[23309]]), G$3J[m[23337]] = String(rdz[m[23309]]), G$3J[m[23340]] = String(rdz[m[23340]]), G$3J[m[26916]] = String(rdz[m[10478]]), G$3J[m[26917]] = String(rdz[m[800]]), G$3J[m[10478]] = '';var zo3t4 = this;G$230J({ 'title': m[26918] }), sendApi(G$3J[m[26830]], m[26919], { 'partner_id': G$3J[m[22079]], 'uid': G$3J[m[23338]], 'version': G$3J[m[4267]], 'game_pkg': G$3J[m[23339]], 'device': G$3J[m[23341]] }, zo3t4['G$02J3'][m[68]](zo3t4), G$0J3, G$J2);
}, window['G$02J3'] = function (t_0p4f) {
  if (!t_0p4f) {
    window['G$203J'](m[26920]);return;
  }if (t_0p4f[m[3685]] != m[9072]) {
    window['G$203J'](m[26921] + t_0p4f[m[3685]]);return;
  }if (!t_0p4f[m[11]] || t_0p4f[m[11]][m[13]] == 0x0) {
    window['G$203J'](m[26922]);return;
  }G$3J[m[601]] = t_0p4f[m[26923]], G$3J[m[23333]] = { 'server_id': String(t_0p4f[m[11]][0x0][m[10493]]), 'server_name': String(t_0p4f[m[11]][0x0][m[26924]]), 'entry_ip': t_0p4f[m[11]][0x0][m[23361]], 'entry_port': parseInt(t_0p4f[m[11]][0x0][m[23362]]), 'status': G$J203(t_0p4f[m[11]][0x0]), 'start_time': t_0p4f[m[11]][0x0][m[26925]], 'cdn': G$3J[m[4077]] }, this['G$V203J']();
}, window['G$V203J'] = function () {
  if (G$3J[m[601]] == 0x1) {
    var hx1kai = G$3J[m[23333]][m[100]];if (hx1kai === -0x1 || hx1kai === 0x0) {
      window['G$203J'](hx1kai === -0x1 ? m[26926] : m[26927]);return;
    }G$J230(0x0, G$3J[m[23333]][m[10493]]), window[m[26735]][m[141]][m[26928]](G$3J[m[601]]);
  } else window[m[26735]][m[141]][m[26929]](), G$23J0();window['G$30'] = !![], window['G$J320'](), window['G$J302']();
}, window['G$032J'] = function () {
  sendApi(G$3J[m[26830]], m[26930], { 'game_pkg': G$3J[m[23339]], 'version_name': G$3J[m[26891]] }, this[m[26931]][m[68]](this), G$0J3, G$J2);
}, window[m[26931]] = function (ro6) {
  if (!ro6) {
    window['G$203J'](m[26932]);return;
  }if (ro6[m[3685]] != m[9072]) {
    window['G$203J'](m[26933] + ro6[m[3685]]);return;
  }if (!ro6[m[11]] || !ro6[m[11]][m[4267]]) {
    window['G$203J'](m[26934] + (ro6[m[11]] && ro6[m[11]][m[4267]]));return;
  }ro6[m[11]][m[26935]] && ro6[m[11]][m[26935]][m[13]] > 0xa && (G$3J[m[26936]] = ro6[m[11]][m[26935]], G$3J[m[4077]] = ro6[m[11]][m[26935]]), ro6[m[11]][m[4267]] && (G$3J[m[95]] = ro6[m[11]][m[4267]]), console[m[72]](m[23469] + G$3J[m[95]] + m[26937] + G$3J[m[26891]]), window['G$3J0'] = !![], window['G$J320'](), window['G$J302']();
}, window[m[26938]], window['G$03J2'] = function () {
  sendApi(G$3J[m[26830]], m[26939], { 'game_pkg': G$3J[m[23339]] }, this['G$0J23'][m[68]](this), G$0J3, G$J2);
}, window['G$0J23'] = function ($mj6) {
  if ($mj6[m[3685]] === m[9072] && $mj6[m[11]]) {
    window[m[26938]] = $mj6[m[11]];for (var d6zo in $mj6[m[11]]) {
      G$3J[d6zo] = $mj6[m[11]][d6zo];
    }
  } else console[m[72]](m[26940] + $mj6[m[3685]]);window['G$03'] = !![], window['G$J302']();
}, window[m[26941]] = function (tfo3d4, x1kwa, wkve7, _5pi, e1vkw, cql, hke1yw, _t0p, g8ls) {
  e1vkw = String(e1vkw);var egyvq = hke1yw,
      iba5xp = _t0p;G$3J[m[26826]][e1vkw] = { 'productid': e1vkw, 'productname': egyvq, 'productdesc': iba5xp, 'roleid': tfo3d4, 'rolename': x1kwa, 'rolelevel': wkve7, 'price': cql, 'callback': g8ls }, sendApi(G$3J[m[26834]], m[26942], { 'game_pkg': G$3J[m[23339]], 'server_id': G$3J[m[23333]][m[10493]], 'server_name': G$3J[m[23333]][m[26924]], 'level': wkve7, 'uid': G$3J[m[23338]], 'role_id': tfo3d4, 'role_name': x1kwa, 'product_id': e1vkw, 'product_name': egyvq, 'product_desc': iba5xp, 'money': cql, 'partner_id': G$3J[m[22079]] }, toPayCallBack, G$0J3, G$J2);
}, window[m[26943]] = function (hykw1) {
  if (hykw1) {
    if (hykw1[m[26944]] === 0xc8 || hykw1[m[3685]] == m[9072]) {
      var tzo4d3 = G$3J[m[26826]][String(hykw1[m[26945]])];if (tzo4d3[m[323]]) tzo4d3[m[323]](hykw1[m[26945]], hykw1[m[26946]], -0x1);ghw1yxk[m[26947]]({ 'cpbill': hykw1[m[26946]], 'productid': hykw1[m[26945]], 'productname': tzo4d3[m[26948]], 'productdesc': tzo4d3[m[26949]], 'serverid': G$3J[m[23333]][m[10493]], 'servername': G$3J[m[23333]][m[26924]], 'roleid': tzo4d3[m[26950]], 'rolename': tzo4d3[m[26951]], 'rolelevel': tzo4d3[m[26952]], 'price': tzo4d3[m[24927]], 'extension': JSON[m[4063]]({ 'cp_order_id': hykw1[m[26946]] }) }, function (jur6m, wvk1e) {
        tzo4d3[m[323]] && jur6m == 0x0 && tzo4d3[m[323]](hykw1[m[26945]], hykw1[m[26946]], jur6m);console[m[72]](JSON[m[4063]]({ 'type': m[26953], 'status': jur6m, 'data': hykw1, 'role_name': tzo4d3[m[26951]] }));if (jur6m === 0x0) {} else {
          if (jur6m === 0x1) {} else {
            if (jur6m === 0x2) {}
          }
        }
      });
    } else alert(hykw1[m[72]]);
  }
}, window['G$0J32'] = function () {}, window['G$20J'] = function (wkeh1, w1yehk, ixh51, gl9s8, b_f) {
  ghw1yxk[m[26954]](G$3J[m[23333]][m[10493]], G$3J[m[23333]][m[26924]] || G$3J[m[23333]][m[10493]], wkeh1, w1yehk, ixh51), sendApi(G$3J[m[26830]], m[26955], { 'game_pkg': G$3J[m[23339]], 'server_id': G$3J[m[23333]][m[10493]], 'role_id': wkeh1, 'uid': G$3J[m[23338]], 'role_name': w1yehk, 'role_type': gl9s8, 'level': ixh51 });
}, window['G$2J0'] = function (vyg7eq, pa0, ey7gv, sq8cl, kwyve7, w7ek, ih5xa, hy1e, hwye1k, ft_4) {
  G$3J[m[26725]] = vyg7eq, G$3J[m[4198]] = pa0, G$3J[m[26726]] = ey7gv, ghw1yxk['logEnterGame'](G$3J[m[23333]][m[10493]], G$3J[m[23333]][m[26924]] || G$3J[m[23333]][m[10493]], vyg7eq, pa0, ey7gv, w7ek, { 'rolepower': ih5xa }), sendApi(G$3J[m[26830]], m[26956], { 'game_pkg': G$3J[m[23339]], 'server_id': G$3J[m[23333]][m[10493]], 'role_id': vyg7eq, 'uid': G$3J[m[23338]], 'role_name': pa0, 'role_type': sq8cl, 'level': ey7gv, 'evolution': kwyve7 });
}, window['G$02J'] = function (gc8sl, b5ihx, eky1, u$6jrm, kev7y, ih5bx, csgvq7, pt04, cs98lg, hxwky1) {
  G$3J[m[26725]] = gc8sl, G$3J[m[4198]] = b5ihx, G$3J[m[26726]] = eky1, ghw1yxk[m[26957]](G$3J[m[23333]][m[10493]], G$3J[m[23333]][m[26924]] || G$3J[m[23333]][m[10493]], gc8sl, b5ihx, eky1), sendApi(G$3J[m[26830]], m[26956], { 'game_pkg': G$3J[m[23339]], 'server_id': G$3J[m[23333]][m[10493]], 'role_id': gc8sl, 'uid': G$3J[m[23338]], 'role_name': b5ihx, 'role_type': u$6jrm, 'level': eky1, 'evolution': kev7y });
}, window['G$0J2'] = function (eyw) {}, window['G$20'] = function (we7yvk) {
  ghw1yxk[m[26958]](m[26958], function (csg9) {
    we7yvk && we7yvk(csg9);
  });
}, window[m[23024]] = function () {
  ghw1yxk[m[26959]](G$3J[m[23333]][m[10493]], G$3J[m[23333]][m[26924]] || G$3J[m[23333]][m[10493]], G$3J[m[26725]], G$3J[m[4198]], G$3J[m[26726]]);
}, window['microPortGuide'] = function () {
  ghw1yxk[m[21983]]();
}, window['G$02'] = function (o43fdt) {
  window['G$J02'] = o43fdt, window['G$J02'] && window['G$J20'] && (console[m[72]](m[26816] + window['G$J20'][m[731]]), window['G$J02'](window['G$J20']), window['G$J20'] = null);
}, window['G$320J'] = function (d2jrz6, kxhi, hkwa1x, evwyk) {
  window[m[22]](m[26960], { 'game_pkg': window['G$3J'][m[23339]], 'role_id': kxhi, 'server_id': hkwa1x }, evwyk);
}, window['G$32J0'] = function (jzd26r, yk1v) {
  function f04t_(kwv7) {
    var ekh1yw = [],
        jr2u6 = [],
        urj6$m = window[m[530]][m[26961]];for (var w7k in urj6$m) {
      var qglcs = Number(w7k);(!jzd26r || !jzd26r[m[13]] || jzd26r[m[109]](qglcs) != -0x1) && (jr2u6[m[29]](urj6$m[w7k]), ekh1yw[m[29]]([qglcs, 0x3]));
    }window['G$V0J32'](window[m[26736]], m[26962]) >= 0x0 ? (console[m[456]](m[26963]), ghw1yxk[m[26964]] && ghw1yxk[m[26964]](jr2u6, function (scg8l9) {
      console[m[456]](m[26965]), console[m[456]](scg8l9);if (scg8l9 && scg8l9[m[23517]] == m[26966]) for (var aikh1x in urj6$m) {
        if (scg8l9[urj6$m[aikh1x]] == m[26967]) {
          var wahx = Number(aikh1x);for (var i0bp_5 = 0x0; i0bp_5 < ekh1yw[m[13]]; i0bp_5++) {
            if (ekh1yw[i0bp_5][0x0] == wahx) {
              ekh1yw[i0bp_5][0x1] = 0x1;break;
            }
          }
        }
      }window['G$V0J32'](window[m[26736]], m[26968]) >= 0x0 ? wx[m[26969]]({ 'withSubscriptions': !![], 'success': function (ot34df) {
          var cg = ot34df[m[26970]][m[26971]];if (cg) {
            console[m[456]](m[26972]), console[m[456]](cg);for (var vge7c in urj6$m) {
              if (cg[urj6$m[vge7c]] == m[26967]) {
                var lsqg = Number(vge7c);for (var kwyxh = 0x0; kwyxh < ekh1yw[m[13]]; kwyxh++) {
                  if (ekh1yw[kwyxh][0x0] == lsqg) {
                    ekh1yw[kwyxh][0x1] = 0x2;break;
                  }
                }
              }
            }console[m[456]](ekh1yw), yk1v && yk1v(ekh1yw);
          } else console[m[456]](m[26973]), console[m[456]](ot34df), console[m[456]](ekh1yw), yk1v && yk1v(ekh1yw);
        }, 'fail': function () {
          console[m[456]](m[26974]), console[m[456]](ekh1yw), yk1v && yk1v(ekh1yw);
        } }) : (console[m[456]](m[26975] + window[m[26736]]), console[m[456]](ekh1yw), yk1v && yk1v(ekh1yw));
    })) : (console[m[456]](m[26976] + window[m[26736]]), console[m[456]](ekh1yw), yk1v && yk1v(ekh1yw)), wx[m[26977]](f04t_);
  }wx[m[26978]](f04t_);
}, window['G$302J'] = { 'isSuccess': ![], 'level': m[26979], 'isCharging': ![] }, window['G$30J2'] = function (j6r$mu) {
  wx[m[26804]]({ 'success': function (qg7s8c) {
      var b5_pf0 = window['G$302J'];b5_pf0[m[26980]] = !![], b5_pf0[m[4174]] = Number(qg7s8c[m[4174]])[m[3793]](0x0), b5_pf0[m[26807]] = qg7s8c[m[26807]], j6r$mu && j6r$mu(b5_pf0[m[26980]], b5_pf0[m[4174]], b5_pf0[m[26807]]);
    }, 'fail': function (b0pi_) {
      console[m[456]](m[26981], b0pi_[m[23517]]);var ev = window['G$302J'];j6r$mu && j6r$mu(ev[m[26980]], ev[m[4174]], ev[m[26807]]);
    } });
}, window[m[22]] = function (t_fo34, g8lc9s, d62jz, gvqy7, doz43, p5b0f_, s8cgq, g7svc) {
  if (gvqy7 == undefined) gvqy7 = 0x1;wx[m[451]]({ 'url': t_fo34, 'method': s8cgq || 'GET', 'responseType': m[3988], 'data': g8lc9s, 'header': { 'content-type': g7svc || m[26871] }, 'success': function (dto) {
      DEBUG && console[m[456]](m[26982], t_fo34, info, dto);if (dto && dto[m[23578]] == 0xc8) {
        var v1kye = dto[m[11]];!p5b0f_ || p5b0f_(v1kye) ? d62jz && d62jz(v1kye) : window[m[26983]](t_fo34, g8lc9s, d62jz, gvqy7, doz43, p5b0f_, dto);
      } else window[m[26983]](t_fo34, g8lc9s, d62jz, gvqy7, doz43, p5b0f_, dto);
    }, 'fail': function (weky) {
      DEBUG && console[m[456]](m[26984], t_fo34, info, weky), window[m[26983]](t_fo34, g8lc9s, d62jz, gvqy7, doz43, p5b0f_, weky);
    }, 'complete': function () {} });
}, window[m[26983]] = function (vyew7k, kyxw, xbhi5a, u6mj, ecv7, t0_pf, gv7qcs) {
  u6mj - 0x1 > 0x0 ? setTimeout(function () {
    window[m[22]](vyew7k, kyxw, xbhi5a, u6mj - 0x1, ecv7, t0_pf);
  }, 0x3e8) : ecv7 && ecv7(JSON[m[4063]]({ 'url': vyew7k, 'response': gv7qcs }));
}, window[m[26985]] = function (rj$2u6, ab5xpi, xbhia, odrz26, _fot, bf_50, cq87) {
  !xbhia && (xbhia = {});var zdo4t = Math[m[112]](Date[m[77]]() / 0x3e8);xbhia[m[800]] = zdo4t, xbhia[m[23150]] = ab5xpi;var s8g7cq = Object[m[256]](xbhia)[m[983]](),
      ptbf0_ = '',
      $r62uj = '';for (var b5ixh = 0x0; b5ixh < s8g7cq[m[13]]; b5ixh++) {
    ptbf0_ = ptbf0_ + (b5ixh == 0x0 ? '' : '&') + s8g7cq[b5ixh] + xbhia[s8g7cq[b5ixh]], $r62uj = $r62uj + (b5ixh == 0x0 ? '' : '&') + s8g7cq[b5ixh] + '=' + encodeURIComponent(xbhia[s8g7cq[b5ixh]]);
  }ptbf0_ = ptbf0_ + G$3J[m[26836]];var sclq8 = m[26986] + md5(ptbf0_);send(rj$2u6 + '?' + $r62uj + ($r62uj == '' ? '' : '&') + sclq8, null, odrz26, _fot, bf_50, cq87 || function (toz43) {
    return toz43[m[3685]] == m[9072];
  }, null, m[26987]);
}, window['G$3J20'] = function (z62j$, odf43) {
  var td3z4 = 0x0;G$3J[m[23333]] && (td3z4 = G$3J[m[23333]][m[10493]]), sendApi(G$3J[m[26832]], m[26988], { 'partnerId': G$3J[m[22079]], 'gamePkg': G$3J[m[23339]], 'logTime': Math[m[112]](Date[m[77]]() / 0x3e8), 'platformUid': G$3J[m[23340]], 'type': z62j$, 'serverId': td3z4 }, null, 0x2, null, function () {
    return !![];
  });
}, window['G$3J02'] = function (mru6$) {
  sendApi(G$3J[m[26830]], 'Server.getServerGroup', { 'partner_id': G$3J[m[22079]], 'uid': G$3J[m[23338]], 'version': G$3J[m[4267]], 'game_pkg': G$3J[m[23339]], 'device': G$3J[m[23341]] }, G$203, G$0J3, G$J2);
}, window['G$203'] = function (v7qsgc) {
  if (v7qsgc[m[3685]] === m[9072] && v7qsgc[m[11]]) {
    v7qsgc[m[11]][m[5121]]({ 'id': -0x2, 'name': m[26989] }), v7qsgc[m[11]][m[5121]]({ 'id': -0x1, 'name': m[26990] }), G$3J[m[26991]] = v7qsgc[m[11]];if (window[m[11058]]) window[m[11058]]['showGroupList']();
  } else G$3J['hasGroupReq'] = ![], window['G$203J']('reqServerGroupCallBack ' + v7qsgc[m[3685]]);
}, window['G$230'] = function (gqc87s) {
  sendApi(G$3J[m[26830]], m[26992], { 'partner_id': G$3J[m[22079]], 'uid': G$3J[m[23338]], 'version': G$3J[m[4267]], 'game_pkg': G$3J[m[23339]], 'device': G$3J[m[23341]] }, G$023, G$0J3, G$J2);
}, window['G$023'] = function (kv1yw) {
  G$3J[m[26993]] = ![];if (kv1yw[m[3685]] === m[9072] && kv1yw[m[11]]) {
    for (var wa1kh = 0x0; wa1kh < kv1yw[m[11]][m[13]]; wa1kh++) {
      kv1yw[m[11]][wa1kh][m[100]] = G$J203(kv1yw[m[11]][wa1kh]);
    }G$3J[m[26838]][-0x1] = window[m[26994]](kv1yw[m[11]]), window[m[11058]][m[26995]](-0x1);
  } else window['G$203J'](m[26996] + kv1yw[m[3685]]);
}, window[m[26997]] = function (sc8qlg) {
  sendApi(G$3J[m[26830]], m[26992], { 'partner_id': G$3J[m[22079]], 'uid': G$3J[m[23338]], 'version': G$3J[m[4267]], 'game_pkg': G$3J[m[23339]], 'device': G$3J[m[23341]] }, sc8qlg, G$0J3, G$J2);
}, window['G$032'] = function (bp0i5a, sqcg7) {
  sendApi(G$3J[m[26830]], 'Server.getServerByGroup', { 'partner_id': G$3J[m[22079]], 'uid': G$3J[m[23338]], 'version': G$3J[m[4267]], 'game_pkg': G$3J[m[23339]], 'device': G$3J[m[23341]], 'server_group_id': sqcg7 }, G$320, G$0J3, G$J2);
}, window['G$320'] = function (aik1x) {
  G$3J[m[26993]] = ![];if (aik1x[m[3685]] === m[9072] && aik1x[m[11]] && aik1x[m[11]][m[11]]) {
    var axihk = aik1x[m[11]][m[26998]],
        gsqcl = [];for (var g7vqec = 0x0; g7vqec < aik1x[m[11]][m[11]][m[13]]; g7vqec++) {
      aik1x[m[11]][m[11]][g7vqec][m[100]] = G$J203(aik1x[m[11]][m[11]][g7vqec]), (gsqcl[m[13]] == 0x0 || aik1x[m[11]][m[11]][g7vqec][m[100]] != 0x0) && (gsqcl[gsqcl[m[13]]] = aik1x[m[11]][m[11]][g7vqec]);
    }G$3J[m[26838]][axihk] = window[m[26994]](gsqcl), window[m[11058]][m[26995]](axihk);
  } else window['G$203J'](m[26999] + aik1x[m[3685]]);
}, window['G$V30J'] = function (ftp_) {
  sendApi(G$3J[m[26830]], m[27000], { 'partner_id': G$3J[m[22079]], 'uid': G$3J[m[23338]], 'version': G$3J[m[4267]], 'game_pkg': G$3J[m[23339]], 'device': G$3J[m[23341]] }, reqServerRecommendCallBack, G$0J3, G$J2);
}, window[m[27001]] = function (k1hwe) {
  G$3J[m[26993]] = ![];if (k1hwe[m[3685]] === m[9072] && k1hwe[m[11]]) {
    for (var gsl8 = 0x0; gsl8 < k1hwe[m[11]][m[13]]; gsl8++) {
      k1hwe[m[11]][gsl8][m[100]] = G$J203(k1hwe[m[11]][gsl8]);
    }G$3J[m[26838]][-0x2] = window[m[26994]](k1hwe[m[11]]), window[m[11058]][m[26995]](-0x2);
  } else alert(m[27002] + k1hwe[m[3685]]);
}, window[m[26994]] = function (z$6jr2) {
  if (!z$6jr2 && z$6jr2[m[13]] <= 0x0) return z$6jr2;for (let z26dr = 0x0; z26dr < z$6jr2[m[13]]; z26dr++) {
    z$6jr2[z26dr][m[27003]] && z$6jr2[z26dr][m[27003]] == 0x1 && (z$6jr2[z26dr][m[26924]] += m[27004]);
  }return z$6jr2;
}, window['G$302'] = function (o62zd3, orz) {
  o62zd3 = o62zd3 || G$3J[m[23333]][m[10493]], sendApi(G$3J[m[26830]], m[27005], { 'type': '4', 'game_pkg': G$3J[m[23339]], 'server_id': o62zd3 }, orz);
}, window[m[27006]] = function ($j6mu, _b0, zdjr, jz2r$6) {
  zdjr = zdjr || G$3J[m[23333]][m[10493]], sendApi(G$3J[m[26830]], m[27007], { 'type': $j6mu, 'game_pkg': _b0, 'server_id': zdjr }, jz2r$6);
}, window['G$J203'] = function (r6ju2$) {
  if (r6ju2$) {
    if (r6ju2$[m[100]] == 0x1) {
      if (r6ju2$[m[27008]] == 0x1) return 0x2;else return 0x1;
    } else return r6ju2$[m[100]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['G$J230'] = function (j$mru6, eqcg7) {
  G$3J[m[27009]] = { 'step': j$mru6, 'server_id': eqcg7 };var fbt_0p = this;G$230J({ 'title': m[27010] }), sendApi(G$3J[m[26830]], m[27011], { 'partner_id': G$3J[m[22079]], 'uid': G$3J[m[23338]], 'game_pkg': G$3J[m[23339]], 'server_id': eqcg7, 'platform': G$3J[m[23309]], 'platform_uid': G$3J[m[23340]], 'check_login_time': G$3J[m[26917]], 'check_login_sign': G$3J[m[26916]], 'version_name': G$3J[m[26891]] }, G$J023, G$0J3, G$J2, function (_4tfo) {
    return _4tfo[m[3685]] == m[9072] || _4tfo[m[72]] == m[27012] || _4tfo[m[72]] == m[27013];
  });
}, window['G$J023'] = function (yhxk1w) {
  var gc98ls = this;if (yhxk1w[m[3685]] === m[9072] && yhxk1w[m[11]]) {
    var e1vwyk = G$3J[m[23333]];e1vwyk[m[27014]] = G$3J[m[26839]], e1vwyk[m[10478]] = String(yhxk1w[m[11]][m[27015]]), e1vwyk[m[23311]] = parseInt(yhxk1w[m[11]][m[800]]);if (yhxk1w[m[11]][m[23310]]) e1vwyk[m[23310]] = parseInt(yhxk1w[m[11]][m[23310]]);else e1vwyk[m[23310]] = parseInt(yhxk1w[m[11]][m[10493]]);e1vwyk[m[27016]] = 0x0, e1vwyk[m[4077]] = G$3J[m[26936]], e1vwyk[m[27017]] = yhxk1w[m[11]][m[27018]], e1vwyk[m[27019]] = yhxk1w[m[11]][m[27019]], console[m[456]](m[27020] + JSON[m[4063]](e1vwyk[m[27019]])), G$3J[m[601]] == 0x1 && e1vwyk[m[27019]] && e1vwyk[m[27019]][m[27021]] == 0x1 && (G$3J['showGetBtn'] = 0x1, window[m[26735]][m[141]]['G$VJ']()), G$J032();
  } else sendApi(G$3J[m[26830]], m[26902], { 'platform': G$3J[m[26828]], 'partner_id': G$3J[m[22079]], 'token': G$3J[m[26899]], 'game_pkg': G$3J[m[23339]], 'deviceId': G$3J[m[23341]], 'scene': m[26903] + G$3J[m[26837]] }, function (bf5_p) {
    if (bf5_p[m[3685]] == m[23649]) {
      window['G$203J'](m[26915] + bf5_p[m[3685]]);return;
    }G$3J[m[26916]] = String(bf5_p[m[10478]]), G$3J[m[26917]] = String(bf5_p[m[800]]), setTimeout(function () {
      G$J230(G$3J[m[27009]][m[6580]], G$3J[m[27009]][m[10493]]);
    }, 0x5dc);
  }, G$0J3, G$J2, function (y1khwe) {
    return y1khwe[m[3685]] == m[9072] || y1khwe[m[3685]] == m[23649];
  });
}, window['G$J032'] = function () {
  ServerLoading[m[141]][m[26928]](G$3J[m[601]]), window['G$0J'] = !![], window['G$J302']();
}, window['G$J320'] = function () {
  if (window['G$J0'] && window['G$30J'] && window[m[26845]] && window[m[26846]] && window['G$3J0'] && window['G$30']) {
    if (!window[m[26362]][m[141]]) {
      console[m[456]](m[27022] + window[m[26362]][m[141]]);var vw1ke = wx[m[27023]](),
          bpaxi5 = vw1ke[m[731]] ? vw1ke[m[731]] : 0x0,
          ft34_o = { 'cdn': window['G$3J'][m[4077]], 'spareCdn': window['G$3J'][m[23039]], 'newRegister': window['G$3J'][m[601]], 'wxPC': window['G$3J'][m[23042]], 'wxIOS': window['G$3J'][m[486]], 'wxAndroid': window['G$3J'][m[10330]], 'wxParam': { 'limitLoad': window['G$3J']['G$V230J'], 'benchmarkLevel': window['G$3J']['G$V23J0'], 'wxFrom': window[m[530]][m[26600]] == m[27024] ? 0x1 : 0x0, 'wxSDKVersion': window[m[26736]] }, 'configType': window['G$3J'][m[10671]], 'exposeType': window['G$3J'][m[683]], 'scene': bpaxi5 };new window[m[26362]](ft34_o, window['G$3J'][m[95]], window['G$V20J3']);
    }
  }
}, window['G$J302'] = function () {
  if (window['G$J0'] && window['G$30J'] && window[m[26845]] && window[m[26846]] && window['G$3J0'] && window['G$30'] && window['G$0J'] && window['G$03']) {
    G$23J0();if (!G$J03) {
      G$J03 = !![];if (!window[m[26362]][m[141]]) window['G$J320']();var od2rz = 0x0,
          dorz26 = wx[m[27025]]();dorz26 && (window['G$3J'][m[26793]] && (od2rz = dorz26[m[311]]), console[m[72]](m[27026] + dorz26[m[311]] + m[27027] + dorz26[m[1113]] + m[27028] + dorz26[m[1115]] + m[27029] + dorz26[m[1114]] + m[27030] + dorz26[m[169]] + m[27031] + dorz26[m[170]]));var tzdo43 = {};for (const $rujm6 in G$3J[m[23333]]) {
        tzdo43[$rujm6] = G$3J[m[23333]][$rujm6];
      }var heywk = { 'channel': window['G$3J'][m[23337]], 'account': window['G$3J'][m[23338]], 'userId': window['G$3J'][m[22078]], 'cdn': window['G$3J'][m[4077]], 'data': window['G$3J'][m[11]], 'package': window['G$3J'][m[23040]], 'newRegister': window['G$3J'][m[601]], 'pkgName': window['G$3J'][m[23339]], 'partnerId': window['G$3J'][m[22079]], 'platform_uid': window['G$3J'][m[23340]], 'deviceId': window['G$3J'][m[23341]], 'selectedServer': tzdo43, 'configType': window['G$3J'][m[10671]], 'exposeType': window['G$3J'][m[683]], 'debugUsers': window['G$3J'][m[11013]], 'wxMenuTop': od2rz, 'wxShield': window['G$3J'][m[698]] };if (window[m[26938]]) for (var _of34 in window[m[26938]]) {
        heywk[_of34] = window[m[26938]][_of34];
      }window[m[26362]][m[141]]['G$0VJ3'](heywk), setTimeout(() => {
        new XingJuBoxMain();
      }, 0x1388);
    }
  } else console[m[72]](m[27032] + window['G$J0'] + m[27033] + window['G$30J'] + m[27034] + window[m[26845]] + m[27035] + window[m[26846]] + m[27036] + window['G$3J0'] + m[27037] + window['G$30'] + m[27038] + window['G$0J'] + m[27039] + window['G$03']);
};