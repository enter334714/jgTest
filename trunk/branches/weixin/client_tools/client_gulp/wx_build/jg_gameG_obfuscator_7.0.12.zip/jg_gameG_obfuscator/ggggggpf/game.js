var m = wx.$g;
require('ggggBuff.js'), window[m[26363]][m[26364]][m[26365]] = null, window['client_pb'] = require('gggcleintpb.js'), window[m[23473]] = window[m[26363]][m[23367]][m[23368]](client_pb);