var m = wx.$g;
require(m[26716]);