var o = wx.$U;
console[o[340001]](o[340002]), window[o[340003]], wx[o[340004]](function (p34mh) {
  if (p34mh) {
    if (p34mh[o[340005]]) {
      var ca068r = window[o[340006]][o[340007]][o[340008]](new RegExp(/\./, 'g'), '_'),
          snv$k_ = p34mh[o[340005]],
          jm = snv$k_[o[340009]](/(uuuuuuu\/uGAMEu.js:)[0-9]{1,60}(:)/g);if (jm) for (var x7wl = 0x0; x7wl < jm[o[340010]]; x7wl++) {
        if (jm[x7wl] && jm[x7wl][o[340010]] > 0x0) {
          var o3jh = parseInt(jm[x7wl][o[340008]](o[340011], '')[o[340008]](':', ''));snv$k_ = snv$k_[o[340008]](jm[x7wl], jm[x7wl][o[340008]](':' + o3jh + ':', ':' + (o3jh - 0x2) + ':'));
        }
      }snv$k_ = snv$k_[o[340008]](new RegExp(o[340012], 'g'), o[340013] + ca068r + o[340014]), snv$k_ = snv$k_[o[340008]](new RegExp(o[340015], 'g'), o[340013] + ca068r + o[340014]), p34mh[o[340005]] = snv$k_;
    }var m4ihj = { 'id': window['u$$8'][o[340016]], 'role': window['u$$8'][o[340017]], 'level': window['u$$8'][o[340018]], 'user': window['u$$8'][o[340019]], 'version': window['u$$8'][o[340020]], 'cdn': window['u$$8'][o[340021]], 'pkgName': window['u$$8'][o[340022]], 'gamever': window[o[340006]][o[340007]], 'serverid': window['u$$8'][o[340023]] ? window['u$$8'][o[340023]][o[340024]] : 0x0, 'systemInfo': window[o[340025]], 'error': o[340026], 'stack': p34mh ? p34mh[o[340005]] : '' },
        c6ak0r = JSON[o[340027]](m4ihj);console[o[340028]](o[340029] + c6ak0r), (!window[o[340003]] || window[o[340003]] != m4ihj[o[340028]]) && (window[o[340003]] = m4ihj[o[340028]], window['u$0$'](m4ihj));
  }
});import 'uufuu.js';import 'uu112uu.js';window[o[340030]] = require(o[340031]);import 'uINDuu.js';import 'uuIB23uu.js';import 'uXMtaduu.js';import 'uuINIuu.js';console[o[340001]](o[340032]), console[o[340001]](o[340033]), u$0$G8({ 'title': o[340034] });var up3ufe4 = { 'u$708$G': !![] };new window[o[340035]](up3ufe4), window[o[340035]][o[340036]]['u$7G$80']();if (window['u$70$8G']) clearInterval(window['u$70$8G']);window['u$70$8G'] = null, window['u$7G80$'] = function (dwz5g9, nesvu) {
  if (!dwz5g9 || !nesvu) return 0x0;dwz5g9 = dwz5g9[o[340037]]('.'), nesvu = nesvu[o[340037]]('.');const k_6cva = Math[o[340038]](dwz5g9[o[340010]], nesvu[o[340010]]);while (dwz5g9[o[340010]] < k_6cva) {
    dwz5g9[o[340039]]('0');
  }while (nesvu[o[340010]] < k_6cva) {
    nesvu[o[340039]]('0');
  }for (var uen = 0x0; uen < k_6cva; uen++) {
    const jmio = parseInt(dwz5g9[uen]),
          e_$v = parseInt(nesvu[uen]);if (jmio > e_$v) return 0x1;else {
      if (jmio < e_$v) return -0x1;
    }
  }return 0x0;
}, window[o[340040]] = wx[o[340041]]()[o[340040]], console[o[340042]](o[340043] + window[o[340040]]);var udz5gw9 = wx[o[340044]]();udz5gw9[o[340045]](function (dgz9w) {
  console[o[340042]](o[340046] + dgz9w[o[340047]]);
}), udz5gw9[o[340048]](function () {
  wx[o[340049]]({ 'title': o[340050], 'content': o[340051], 'showCancel': ![], 'success': function (j3p4uf) {
      udz5gw9[o[340052]]();
    } });
}), udz5gw9[o[340053]](function () {
  console[o[340042]](o[340054]);
}), window['u$7G8$0'] = function () {
  console[o[340042]](o[340055]);var puf4e3 = wx[o[340056]]({ 'name': o[340057], 'success': function (q7iol) {
      console[o[340042]](o[340058]), console[o[340042]](q7iol), q7iol && q7iol[o[340059]] == o[340060] ? (window['u$8G'] = !![], window['u$8G$0'](), window['u$8$0G']()) : setTimeout(function () {
        window['u$7G8$0']();
      }, 0x1f4);
    }, 'fail': function (q7ixlo) {
      console[o[340042]](o[340061]), console[o[340042]](q7ixlo), setTimeout(function () {
        window['u$7G8$0']();
      }, 0x1f4);
    } });puf4e3 && puf4e3[o[340062]](gxwql7 => {});
}, window['u$7$08G'] = function () {
  console[o[340042]](o[340063]);var c10b = wx[o[340056]]({ 'name': o[340064], 'success': function (s$nk_) {
      console[o[340042]](o[340065]), console[o[340042]](s$nk_), s$nk_ && s$nk_[o[340059]] == o[340060] ? (window['u$$G8'] = !![], window['u$8G$0'](), window['u$8$0G']()) : setTimeout(function () {
        window['u$7$08G']();
      }, 0x1f4);
    }, 'fail': function (p4uef3) {
      console[o[340042]](o[340066]), console[o[340042]](p4uef3), setTimeout(function () {
        window['u$7$08G']();
      }, 0x1f4);
    } });c10b && c10b[o[340062]](snvu => {});
}, window[o[340067]] = function () {
  window['u$7G80$'](window[o[340040]], o[340068]) >= 0x0 ? (console[o[340042]](o[340069] + window[o[340040]] + o[340070]), window['u$$0'](), window['u$7G8$0'](), window['u$7$08G']()) : (window['u$$80'](o[340071], window[o[340040]]), wx[o[340049]]({ 'title': o[340072], 'content': o[340073] }));
}, window[o[340025]] = '', wx[o[340074]]({ 'success'(gx9z) {
    window[o[340025]] = o[340075] + gx9z[o[340076]] + o[340077] + gx9z[o[340078]] + o[340079] + gx9z[o[340080]] + o[340081] + gx9z[o[340082]] + o[340083] + gx9z[o[340084]] + o[340085] + gx9z[o[340040]] + o[340086] + gx9z[o[340087]], console[o[340042]](window[o[340025]]), console[o[340042]](o[340088] + gx9z[o[340089]] + o[340090] + gx9z[o[340091]] + o[340092] + gx9z[o[340093]] + o[340094] + gx9z[o[340095]] + o[340096] + gx9z[o[340097]] + o[340098] + gx9z[o[340099]] + o[340100] + (gx9z[o[340101]] ? gx9z[o[340101]][o[340102]] + ',' + gx9z[o[340101]][o[340103]] + ',' + gx9z[o[340101]][o[340104]] + ',' + gx9z[o[340101]][o[340105]] : ''));var sve_$n = gx9z[o[340082]] ? gx9z[o[340082]][o[340106]]() : '',
        i3j4 = gx9z[o[340078]] ? gx9z[o[340078]][o[340106]]()[o[340008]]('\x20', '') : '';window['u$$8'][o[340107]] = sve_$n[o[340108]](o[340109]) != -0x1, window['u$$8'][o[340110]] = sve_$n[o[340108]](o[340111]) != -0x1, window['u$$8'][o[340112]] = sve_$n[o[340108]](o[340109]) != -0x1 || sve_$n[o[340108]](o[340111]) != -0x1, window['u$$8'][o[340113]] = sve_$n[o[340108]](o[340114]) != -0x1 || sve_$n[o[340108]](o[340115]) != -0x1, window['u$$8'][o[340116]] = gx9z[o[340084]] ? gx9z[o[340084]][o[340106]]() : '', window['u$$8']['u$70G8$'] = ![], window['u$$8']['u$70$G8'] = 0x2;if (sve_$n[o[340108]](o[340111]) != -0x1) {
      if (gx9z[o[340087]] >= 0x18) window['u$$8']['u$70$G8'] = 0x3;else window['u$$8']['u$70$G8'] = 0x2;
    } else {
      if (sve_$n[o[340108]](o[340109]) != -0x1) {
        if (gx9z[o[340087]] && gx9z[o[340087]] >= 0x14) window['u$$8']['u$70$G8'] = 0x3;else {
          if (i3j4[o[340108]](o[340117]) != -0x1 || i3j4[o[340108]](o[340118]) != -0x1 || i3j4[o[340108]](o[340119]) != -0x1 || i3j4[o[340108]](o[340120]) != -0x1 || i3j4[o[340108]](o[340121]) != -0x1) window['u$$8']['u$70$G8'] = 0x2;else window['u$$8']['u$70$G8'] = 0x3;
        }
      } else window['u$$8']['u$70$G8'] = 0x2;
    }console[o[340042]](o[340122] + window['u$$8']['u$70G8$'] + o[340123] + window['u$$8']['u$70$G8']);
  } }), wx[o[340124]]({ 'success': function (ihm43) {
    console[o[340042]](o[340125] + ihm43[o[340126]] + o[340127] + ihm43[o[340128]]);
  } }), wx[o[340129]]({ 'success': function (vkc_a6) {
    console[o[340042]](o[340130] + vkc_a6[o[340131]]);
  } }), wx[o[340132]]({ 'keepScreenOn': !![] }), wx[o[340133]](function (uepf34) {
  console[o[340042]](o[340130] + uepf34[o[340131]] + o[340134] + uepf34[o[340135]]);
}), wx[o[340136]](function (j3u4fp) {
  window['u$G0'] = j3u4fp, window['u$80G'] && window['u$G0'] && (console[o[340001]](o[340137] + window['u$G0'][o[340138]]), window['u$80G'](window['u$G0']), window['u$G0'] = null);
}), window[o[340139]] = 0x0, window['u$7$G80'] = 0x0, window[o[340140]] = null, wx[o[340141]](function () {
  window['u$7$G80']++;var lmih = Date[o[340142]]();(window[o[340139]] == 0x0 || lmih - window[o[340139]] > 0x1d4c0) && (console[o[340143]](o[340144]), wx[o[340145]]());if (window['u$7$G80'] >= 0x2) {
    window['u$7$G80'] = 0x0, console[o[340028]](o[340146]), wx[o[340147]]('0', 0x1);if (window['u$$8'] && window['u$$8'][o[340107]]) window['u$$80'](o[340148], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});