var o = wx.$U;
require(o[340000]);