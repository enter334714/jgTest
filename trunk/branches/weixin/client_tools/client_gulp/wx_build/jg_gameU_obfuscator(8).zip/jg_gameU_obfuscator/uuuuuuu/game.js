var o = wx.$U;
import 'uuMAIu.js';