var o = wx.$U;
import uolqxim from '../uukuuu/u6kuu.js';window[o[340149]] = { 'wxVersion': window[o[340006]][o[340007]] }, window[o[340150]] = ![], window['u$8$'] = 0x1, window[o[340151]] = 0x1, window['u$G$8'] = !![], window[o[340152]] = !![], window['u$70G$8'] = '', window['u$$8'] = { 'base_cdn': o[340153], 'cdn': o[340153] }, u$$8[o[340154]] = {}, u$$8[o[340155]] = '0', u$$8[o[340080]] = window[o[340149]][o[340156]], u$$8[o[340115]] = '', u$$8['os'] = '1', u$$8[o[340157]] = o[340158], u$$8[o[340159]] = o[340160], u$$8[o[340161]] = o[340162], u$$8[o[340163]] = o[340164], u$$8[o[340165]] = o[340166], u$$8[o[340167]] = '1', u$$8[o[340022]] = '', u$$8[o[340168]] = '', u$$8[o[340169]] = 0x0, u$$8[o[340170]] = {}, u$$8[o[340171]] = parseInt(u$$8[o[340167]]), u$$8[o[340172]] = u$$8[o[340167]], u$$8[o[340023]] = {}, u$$8['u$0$'] = o[340173], u$$8[o[340174]] = ![], u$$8[o[340175]] = o[340176], u$$8[o[340177]] = Date[o[340142]](), u$$8[o[340178]] = o[340179], u$$8[o[340180]] = '_a', u$$8[o[340181]] = 0x2, u$$8[o[340020]] = 0x7c1, u$$8[o[340156]] = window[o[340149]][o[340156]], u$$8[o[340182]] = ![], u$$8[o[340107]] = ![], u$$8[o[340110]] = ![], u$$8[o[340113]] = ![], window['u$G8$'] = 0x5, window['u$G8'] = ![], window['u$8G'] = ![], window['u$$G8'] = ![], window[o[340183]] = ![], window[o[340184]] = ![], window['u$$8G'] = ![], window['u$G$'] = ![], window['u$$G'] = ![], window['u$8G$'] = ![], window[o[340185]] = function (asvnk) {
  console[o[340042]](o[340185], asvnk), wx[o[340186]]({}), wx[o[340049]]({ 'title': o[340072], 'content': asvnk, 'success'(ixo7lq) {
      if (ixo7lq[o[340187]]) console[o[340042]](o[340188]);else ixo7lq[o[340189]] && console[o[340042]](o[340190]);
    } });
}, window['u$0G$8'] = function (io7xq) {
  console[o[340042]](o[340191], io7xq), u$0$8G(), wx[o[340049]]({ 'title': o[340072], 'content': io7xq, 'confirmText': o[340192], 'cancelText': o[340193], 'success'(o7iqx) {
      if (o7iqx[o[340187]]) window['u$$0']();else o7iqx[o[340189]] && (console[o[340042]](o[340194]), wx[o[340195]]({}));
    } });
}, window['u$$7'] = function (qmohil) {
  console[o[340042]](o[340196], qmohil), wx[o[340049]]({ 'title': o[340072], 'content': qmohil, 'confirmText': o[340197], 'showCancel': ![], 'complete'(eu$snf) {
      console[o[340042]](o[340194]), wx[o[340195]]({});
    } });
}, window['u$0G8$'] = ![], window['u$0$G8'] = function (vn$eus) {
  window['u$0G8$'] = !![], wx[o[340198]](vn$eus);
}, window['u$0$8G'] = function () {
  window['u$0G8$'] && (window['u$0G8$'] = ![], wx[o[340186]]({}));
}, window['u$08G$'] = function (a6vnk) {
  window[o[340035]][o[340036]]['u$08G$'](a6vnk);
}, window[o[340199]] = function (ka0c6r, omqlxi) {
  uolqxim[o[340199]](ka0c6r, function (ra6kc0) {
    ra6kc0 && ra6kc0[o[340200]] ? ra6kc0[o[340200]][o[340201]] == 0x1 ? omqlxi(!![]) : (omqlxi(![]), console[o[340001]](o[340202] + ra6kc0[o[340200]][o[340203]])) : console[o[340042]](o[340199], ra6kc0);
  });
}, window[o[340204]] = function ($vsnu, qlmox) {
  $vsnu[o[340205]] = window[o[340006]][o[340206]], $vsnu[o[340207]] = window[o[340006]][o[340208]], $vsnu[o[340209]] = window['u$$8'][o[340107]] ? window[o[340006]][o[340210]] : window[o[340006]][o[340211]], $vsnu[o[340212]] = Math[o[340213]](($vsnu[o[340212]] ? $vsnu[o[340212]] : Date[o[340142]]()) / 0x3e8), $vsnu[o[340214]] = Math[o[340213]](($vsnu[o[340214]] ? $vsnu[o[340214]] : Date[o[340142]]()) / 0x3e8), console[o[340001]](o[340215] + JSON[o[340027]]($vsnu));var oih3 = function (mihloq) {
    if (!mihloq) mihloq = { 'state': 0x1, 'display': 0x1, 'msg': o[340216] };if (!mihloq[o[340203]]) mihloq[o[340203]] = o[340216];console[o[340001]](o[340217] + JSON[o[340027]](mihloq)), qlmox && qlmox(mihloq);
  },
      hjqm = function (q7xol) {
    var xlmoq = { 'state': 0x0, 'display': 0x0, 'msg': o[340216] };console[o[340001]](o[340218] + q7xol), qlmox && qlmox(xlmoq);
  };sendApi(u$$8[o[340159]], o[340219], $vsnu, oih3, 0x1, hjqm, function () {
    return !![];
  });
}, window['u$08$G'] = function (pj4f3h) {
  console[o[340042]](o[340220], pj4f3h);
}, window['u$0$8'] = function (lxq7io) {}, window['u$08$'] = function (gdz9w5, wz9g5, a_c6kv) {}, window['u$08'] = function (nas_) {
  console[o[340042]](o[340221], nas_), window[o[340035]][o[340036]][o[340222]](), window[o[340035]][o[340036]][o[340223]](), window[o[340035]][o[340036]][o[340224]]();
}, window['u$80'] = function (k6c0a) {
  window['u$0G$8'](o[340225]);var qomi = { 'id': window['u$$8'][o[340016]], 'role': window['u$$8'][o[340017]], 'level': window['u$$8'][o[340018]], 'account': window['u$$8'][o[340019]], 'version': window['u$$8'][o[340020]], 'cdn': window['u$$8'][o[340021]], 'pkgName': window['u$$8'][o[340022]], 'gamever': window[o[340006]][o[340007]], 'serverid': window['u$$8'][o[340023]] ? window['u$$8'][o[340023]][o[340024]] : 0x0, 'systemInfo': window[o[340025]], 'error': o[340226], 'stack': k6c0a ? k6c0a : o[340225] },
      ohmiqj = JSON[o[340027]](qomi);console[o[340028]](o[340227] + ohmiqj), window['u$0$'](ohmiqj);
}, window['u$$08'] = function (ne$s) {
  var hpfj43 = JSON[o[340228]](ne$s);hpfj43[o[340229]] = window[o[340006]][o[340007]], hpfj43[o[340230]] = window['u$$8'][o[340023]] ? window['u$$8'][o[340023]][o[340024]] : 0x0, hpfj43[o[340025]] = window[o[340025]];var r_6a = JSON[o[340027]](hpfj43);console[o[340028]](o[340231] + r_6a), window['u$0$'](r_6a);
}, window['u$$80'] = function (cark6_, nsuv$) {
  var vasn_ = { 'id': window['u$$8'][o[340016]], 'role': window['u$$8'][o[340017]], 'level': window['u$$8'][o[340018]], 'account': window['u$$8'][o[340019]], 'version': window['u$$8'][o[340020]], 'cdn': window['u$$8'][o[340021]], 'pkgName': window['u$$8'][o[340022]], 'gamever': window[o[340006]][o[340007]], 'serverid': window['u$$8'][o[340023]] ? window['u$$8'][o[340023]][o[340024]] : 0x0, 'systemInfo': window[o[340025]], 'error': cark6_, 'stack': nsuv$ },
      wqglx7 = JSON[o[340027]](vasn_);console[o[340143]](o[340232] + wqglx7), window['u$0$'](wqglx7);
}, window['u$0$'] = function (skv$n) {
  if (window['u$$8'][o[340116]] == o[340233]) return;var rc8b01 = u$$8['u$0$'] + o[340234] + u$$8[o[340019]];wx[o[340235]]({ 'url': rc8b01, 'method': o[340236], 'data': skv$n, 'header': { 'content-type': o[340237], 'cache-control': o[340238] }, 'success': function (g5dwz) {
      DEBUG && console[o[340042]](o[340239], rc8b01, skv$n, g5dwz);
    }, 'fail': function (pef$su) {
      DEBUG && console[o[340042]](o[340239], rc8b01, skv$n, pef$su);
    }, 'complete': function () {} });
}, window[o[340240]] = function () {
  function z9gdt() {
    return ((0x1 + Math[o[340241]]()) * 0x10000 | 0x0)[o[340242]](0x10)[o[340243]](0x1);
  }return z9gdt() + z9gdt() + '-' + z9gdt() + '-' + z9gdt() + '-' + z9gdt() + '+' + z9gdt() + z9gdt() + z9gdt();
}, window['u$$0'] = function () {
  console[o[340042]](o[340244]);var lq7xgw = uolqxim[o[340245]]();u$$8[o[340172]] = lq7xgw[o[340246]], u$$8[o[340171]] = lq7xgw[o[340246]], u$$8[o[340167]] = lq7xgw[o[340246]], u$$8[o[340022]] = lq7xgw[o[340247]];var ihjo3m = { 'game_ver': u$$8[o[340080]] };u$$8[o[340168]] = this[o[340240]](), u$0$G8({ 'title': o[340248] }), uolqxim[o[340249]](ihjo3m, this['u$80$'][o[340250]](this));
}, window['u$80$'] = function (c1r86) {
  var nev_s = c1r86[o[340251]];console[o[340042]](o[340252] + nev_s + o[340253] + (nev_s == 0x1) + o[340254] + c1r86[o[340007]] + o[340255] + window[o[340149]][o[340156]]);if (!c1r86[o[340007]] || window['u$7G80$'](window[o[340149]][o[340156]], c1r86[o[340007]]) < 0x0) console[o[340042]](o[340256]), u$$8[o[340159]] = o[340257], u$$8[o[340161]] = o[340258], u$$8[o[340163]] = o[340259], u$$8[o[340021]] = o[340260], u$$8[o[340261]] = o[340262], u$$8[o[340263]] = 'jx', u$$8[o[340182]] = ![];else window['u$7G80$'](window[o[340149]][o[340156]], c1r86[o[340007]]) == 0x0 ? (console[o[340042]](o[340264]), u$$8[o[340159]] = o[340160], u$$8[o[340161]] = o[340162], u$$8[o[340163]] = o[340164], u$$8[o[340021]] = o[340265], u$$8[o[340261]] = o[340262], u$$8[o[340263]] = o[340266], u$$8[o[340182]] = !![]) : (console[o[340042]](o[340267]), u$$8[o[340159]] = o[340160], u$$8[o[340161]] = o[340162], u$$8[o[340163]] = o[340164], u$$8[o[340021]] = o[340265], u$$8[o[340261]] = o[340262], u$$8[o[340263]] = o[340266], u$$8[o[340182]] = ![]);u$$8[o[340169]] = config[o[340268]] ? config[o[340268]] : 0x0, this['u$G$08'](), this['u$G$80'](), window[o[340269]] = 0x5, u$0$G8({ 'title': o[340270] }), uolqxim[o[340271]](this['u$8$0'][o[340250]](this));
}, window[o[340269]] = 0x5, window['u$8$0'] = function (nk_v6, $_snve) {
  if (nk_v6 == 0x0 && $_snve && $_snve[o[340272]]) {
    u$$8[o[340273]] = $_snve[o[340272]];var b8cr = this;u$0$G8({ 'title': o[340274] }), sendApi(u$$8[o[340159]], o[340275], { 'platform': u$$8[o[340157]], 'partner_id': u$$8[o[340167]], 'token': $_snve[o[340272]], 'game_pkg': u$$8[o[340022]], 'deviceId': u$$8[o[340168]], 'scene': o[340276] + u$$8[o[340169]] }, this['u$G0$8'][o[340250]](this), u$G8$, u$80);
  } else $_snve && $_snve[o[340059]] && window[o[340269]] > 0x0 && ($_snve[o[340059]][o[340108]](o[340277]) != -0x1 || $_snve[o[340059]][o[340108]](o[340278]) != -0x1 || $_snve[o[340059]][o[340108]](o[340279]) != -0x1 || $_snve[o[340059]][o[340108]](o[340280]) != -0x1 || $_snve[o[340059]][o[340108]](o[340281]) != -0x1 || $_snve[o[340059]][o[340108]](o[340282]) != -0x1) ? (window[o[340269]]--, uolqxim[o[340271]](this['u$8$0'][o[340250]](this))) : (window['u$$80'](o[340283], JSON[o[340027]]({ 'status': nk_v6, 'data': $_snve })), window['u$0G$8'](o[340284] + ($_snve && $_snve[o[340059]] ? '，' + $_snve[o[340059]] : '')));
}, window['u$G0$8'] = function (gx79lw) {
  if (!gx79lw) {
    window['u$$80'](o[340285], o[340286]), window['u$0G$8'](o[340287]);return;
  }if (gx79lw[o[340201]] != o[340288]) {
    window['u$$80'](o[340285], JSON[o[340027]](gx79lw)), window['u$0G$8'](o[340289] + gx79lw[o[340201]]);return;
  }u$$8[o[340290]] = String(gx79lw[o[340019]]), u$$8[o[340019]] = String(gx79lw[o[340019]]), u$$8[o[340084]] = String(gx79lw[o[340084]]), u$$8[o[340172]] = String(gx79lw[o[340084]]), u$$8[o[340291]] = String(gx79lw[o[340291]]), u$$8[o[340292]] = String(gx79lw[o[340293]]), u$$8[o[340294]] = String(gx79lw[o[340212]]), u$$8[o[340293]] = '';var pf34h = this;u$0$G8({ 'title': o[340295] }), sendApi(u$$8[o[340159]], o[340296], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, pf34h['u$G08$'][o[340250]](pf34h), u$G8$, u$80);
}, window['u$G08$'] = function (w97xg) {
  if (!w97xg) {
    window['u$0G$8'](o[340297]);return;
  }if (w97xg[o[340201]] != o[340288]) {
    window['u$0G$8'](o[340298] + w97xg[o[340201]]);return;
  }if (!w97xg[o[340200]] || w97xg[o[340200]][o[340010]] == 0x0) {
    window['u$0G$8'](o[340299]);return;
  }u$$8[o[340300]] = w97xg[o[340301]], u$$8[o[340023]] = { 'server_id': String(w97xg[o[340200]][0x0][o[340024]]), 'server_name': String(w97xg[o[340200]][0x0][o[340302]]), 'entry_ip': w97xg[o[340200]][0x0][o[340303]], 'entry_port': parseInt(w97xg[o[340200]][0x0][o[340304]]), 'status': u$$G0(w97xg[o[340200]][0x0]), 'start_time': w97xg[o[340200]][0x0][o[340305]], 'cdn': u$$8[o[340021]] }, this['u$8$G0']();
}, window['u$8$G0'] = function () {
  if (u$$8[o[340300]] == 0x1) {
    var us$fe = u$$8[o[340023]][o[340306]];if (us$fe === -0x1 || us$fe === 0x0) {
      window['u$0G$8'](us$fe === -0x1 ? o[340307] : o[340308]);return;
    }u$80G$(0x0, u$$8[o[340023]][o[340024]]), window[o[340035]][o[340036]][o[340309]](u$$8[o[340300]]);
  } else window[o[340035]][o[340036]][o[340310]](), u$0$8G();window['u$$G'] = !![], window['u$8G$0'](), window['u$8$0G']();
}, window['u$G$08'] = function () {
  sendApi(u$$8[o[340159]], o[340311], { 'game_pkg': u$$8[o[340022]], 'version_name': u$$8[o[340263]] }, this[o[340312]][o[340250]](this), u$G8$, u$80);
}, window[o[340312]] = function (va6c_k) {
  if (!va6c_k) {
    window['u$0G$8'](o[340313]);return;
  }if (va6c_k[o[340201]] != o[340288]) {
    window['u$0G$8'](o[340314] + va6c_k[o[340201]]);return;
  }if (!va6c_k[o[340200]] || !va6c_k[o[340200]][o[340080]]) {
    window['u$0G$8'](o[340315] + (va6c_k[o[340200]] && va6c_k[o[340200]][o[340080]]));return;
  }va6c_k[o[340200]][o[340316]] && va6c_k[o[340200]][o[340316]][o[340010]] > 0xa && (u$$8[o[340317]] = va6c_k[o[340200]][o[340316]], u$$8[o[340021]] = va6c_k[o[340200]][o[340316]]), va6c_k[o[340200]][o[340080]] && (u$$8[o[340020]] = va6c_k[o[340200]][o[340080]]), console[o[340001]](o[340318] + u$$8[o[340020]] + o[340319] + u$$8[o[340263]]), window['u$$8G'] = !![], window['u$8G$0'](), window['u$8$0G']();
}, window[o[340320]], window['u$G$80'] = function () {
  sendApi(u$$8[o[340159]], o[340321], { 'game_pkg': u$$8[o[340022]] }, this['u$G80$'][o[340250]](this), u$G8$, u$80);
}, window['u$G80$'] = function (f3j4u) {
  if (f3j4u[o[340201]] === o[340288] && f3j4u[o[340200]]) {
    window[o[340320]] = f3j4u[o[340200]];for (var $nvse in f3j4u[o[340200]]) {
      u$$8[$nvse] = f3j4u[o[340200]][$nvse];
    }
  } else console[o[340001]](o[340322] + f3j4u[o[340201]]);window['u$G$'] = !![], window['u$8$0G']();
}, window[o[340323]] = function (ijhom, _kn$v, _k6vc, hqiom, a8c0r, h4m3, k0c6ar, b10ry, n$svk) {
  a8c0r = String(a8c0r);var wzg95d = k0c6ar,
      p3ujf4 = b10ry;u$$8[o[340154]][a8c0r] = { 'productid': a8c0r, 'productname': wzg95d, 'productdesc': p3ujf4, 'roleid': ijhom, 'rolename': _kn$v, 'rolelevel': _k6vc, 'price': h4m3, 'callback': n$svk }, sendApi(u$$8[o[340163]], o[340324], { 'game_pkg': u$$8[o[340022]], 'server_id': u$$8[o[340023]][o[340024]], 'server_name': u$$8[o[340023]][o[340302]], 'level': _k6vc, 'uid': u$$8[o[340019]], 'role_id': ijhom, 'role_name': _kn$v, 'product_id': a8c0r, 'product_name': wzg95d, 'product_desc': p3ujf4, 'money': h4m3, 'partner_id': u$$8[o[340167]] }, toPayCallBack, u$G8$, u$80);
}, window[o[340325]] = function (a_sv) {
  if (a_sv) {
    if (a_sv[o[340326]] === 0xc8 || a_sv[o[340201]] == o[340288]) {
      var k_s$ = u$$8[o[340154]][String(a_sv[o[340327]])];if (k_s$[o[340328]]) k_s$[o[340328]](a_sv[o[340327]], a_sv[o[340329]], -0x1);uolqxim[o[340330]]({ 'cpbill': a_sv[o[340329]], 'productid': a_sv[o[340327]], 'productname': k_s$[o[340331]], 'productdesc': k_s$[o[340332]], 'serverid': u$$8[o[340023]][o[340024]], 'servername': u$$8[o[340023]][o[340302]], 'roleid': k_s$[o[340333]], 'rolename': k_s$[o[340334]], 'rolelevel': k_s$[o[340335]], 'price': k_s$[o[340336]], 'extension': JSON[o[340027]]({ 'cp_order_id': a_sv[o[340329]] }) }, function (w7qo, qlmiho) {
        k_s$[o[340328]] && w7qo == 0x0 && k_s$[o[340328]](a_sv[o[340327]], a_sv[o[340329]], w7qo);console[o[340001]](JSON[o[340027]]({ 'type': o[340337], 'status': w7qo, 'data': a_sv, 'role_name': k_s$[o[340334]] }));if (w7qo === 0x0) {} else {
          if (w7qo === 0x1) {} else {
            if (w7qo === 0x2) {}
          }
        }
      });
    } else alert(a_sv[o[340001]]);
  }
}, window['u$G8$0'] = function () {}, window['u$0G8'] = function (ac8r60, $spuef, jh4, xqlow, mi3hjo) {
  uolqxim[o[340338]](u$$8[o[340023]][o[340024]], u$$8[o[340023]][o[340302]] || u$$8[o[340023]][o[340024]], ac8r60, $spuef, jh4, mi3hjo), sendApi(u$$8[o[340159]], o[340339], { 'game_pkg': u$$8[o[340022]], 'server_id': u$$8[o[340023]][o[340024]], 'role_id': ac8r60, 'uid': u$$8[o[340019]], 'role_name': $spuef, 'role_type': xqlow, 'level': jh4 });
}, window['u$08G'] = function (r16, lmhoi, joqhm, a6kn, r08yb1, a6nk_, jimh4, z9xg7w, sv$un, glw9) {
  u$$8[o[340016]] = r16, u$$8[o[340017]] = lmhoi, u$$8[o[340018]] = joqhm, uolqxim[o[340340]](u$$8[o[340023]][o[340024]], u$$8[o[340023]][o[340302]] || u$$8[o[340023]][o[340024]], r16, lmhoi, joqhm, a6nk_), sendApi(u$$8[o[340159]], o[340341], { 'game_pkg': u$$8[o[340022]], 'server_id': u$$8[o[340023]][o[340024]], 'role_id': r16, 'uid': u$$8[o[340019]], 'role_name': lmhoi, 'role_type': a6kn, 'level': joqhm, 'evolution': r08yb1 });
}, window['u$G08'] = function (qiomlx, feun, oixql, fup$se, fup3j, $4fuep, ioqhl, nav, $pe4u, snev_) {
  u$$8[o[340016]] = qiomlx, u$$8[o[340017]] = feun, u$$8[o[340018]] = oixql, uolqxim[o[340342]](u$$8[o[340023]][o[340024]], u$$8[o[340023]][o[340302]] || u$$8[o[340023]][o[340024]], qiomlx, feun, oixql, $4fuep), sendApi(u$$8[o[340159]], o[340341], { 'game_pkg': u$$8[o[340022]], 'server_id': u$$8[o[340023]][o[340024]], 'role_id': qiomlx, 'uid': u$$8[o[340019]], 'role_name': feun, 'role_type': fup$se, 'level': oixql, 'evolution': fup3j });
}, window['u$G80'] = function (av6k_c) {}, window['u$0G'] = function (himoql) {
  uolqxim[o[340343]](o[340343], function (zdt9) {
    himoql && himoql(zdt9);
  });
}, window[o[340344]] = function () {
  uolqxim[o[340344]]();
}, window[o[340345]] = function () {
  uolqxim[o[340346]]();
}, window[o[340136]] = function (b1r80) {
  window['u$80G'] = b1r80, window['u$80G'] && window['u$G0'] && (console[o[340001]](o[340137] + window['u$G0'][o[340138]]), window['u$80G'](window['u$G0']), window['u$G0'] = null);
}, window['u$8G0'] = function (ixql7o, s$nufe, q7ox, nvs_) {
  window[o[340347]](o[340348], { 'game_pkg': window['u$$8'][o[340022]], 'role_id': s$nufe, 'server_id': q7ox }, nvs_);
}, window['u$$0G8'] = function (f43phj, xwglq7) {
  function uvse(c6ar80) {
    var lioqhm = [],
        $snuve = [],
        p4jfu3 = window[o[340006]][o[340349]];for (var va6_n in p4jfu3) {
      var kan_v = Number(va6_n);(!f43phj || !f43phj[o[340010]] || f43phj[o[340108]](kan_v) != -0x1) && ($snuve[o[340039]](p4jfu3[va6_n]), lioqhm[o[340039]]([kan_v, 0x3]));
    }window['u$7G80$'](window[o[340040]], o[340350]) >= 0x0 ? (console[o[340042]](o[340351]), uolqxim[o[340352]] && uolqxim[o[340352]]($snuve, function (kva6_) {
      console[o[340042]](o[340353]), console[o[340042]](kva6_);if (kva6_ && kva6_[o[340059]] == o[340354]) for (var ne$v_ in p4jfu3) {
        if (kva6_[p4jfu3[ne$v_]] == o[340355]) {
          var x7glw = Number(ne$v_);for (var wg9z7d = 0x0; wg9z7d < lioqhm[o[340010]]; wg9z7d++) {
            if (lioqhm[wg9z7d][0x0] == x7glw) {
              lioqhm[wg9z7d][0x1] = 0x1;break;
            }
          }
        }
      }window['u$7G80$'](window[o[340040]], o[340356]) >= 0x0 ? wx[o[340357]]({ 'withSubscriptions': !![], 'success': function (gwq) {
          var ep34f = gwq[o[340358]][o[340359]];if (ep34f) {
            console[o[340042]](o[340360]), console[o[340042]](ep34f);for (var zt5gd in p4jfu3) {
              if (ep34f[p4jfu3[zt5gd]] == o[340355]) {
                var gwz = Number(zt5gd);for (var uf$sne = 0x0; uf$sne < lioqhm[o[340010]]; uf$sne++) {
                  if (lioqhm[uf$sne][0x0] == gwz) {
                    lioqhm[uf$sne][0x1] = 0x2;break;
                  }
                }
              }
            }console[o[340042]](lioqhm), xwglq7 && xwglq7(lioqhm);
          } else console[o[340042]](o[340361]), console[o[340042]](gwq), console[o[340042]](lioqhm), xwglq7 && xwglq7(lioqhm);
        }, 'fail': function () {
          console[o[340042]](o[340362]), console[o[340042]](lioqhm), xwglq7 && xwglq7(lioqhm);
        } }) : (console[o[340042]](o[340363] + window[o[340040]]), console[o[340042]](lioqhm), xwglq7 && xwglq7(lioqhm));
    })) : (console[o[340042]](o[340364] + window[o[340040]]), console[o[340042]](lioqhm), xwglq7 && xwglq7(lioqhm)), wx[o[340365]](uvse);
  }wx[o[340366]](uvse);
}, window['u$$08G'] = { 'isSuccess': ![], 'level': o[340367], 'isCharging': ![] }, window['u$$G08'] = function (kacr6) {
  wx[o[340124]]({ 'success': function (lx97w) {
      var ij4h3 = window['u$$08G'];ij4h3[o[340368]] = !![], ij4h3[o[340126]] = Number(lx97w[o[340126]])[o[340369]](0x0), ij4h3[o[340128]] = lx97w[o[340128]], kacr6 && kacr6(ij4h3[o[340368]], ij4h3[o[340126]], ij4h3[o[340128]]);
    }, 'fail': function (qgl7) {
      console[o[340042]](o[340370], qgl7[o[340059]]);var dg95 = window['u$$08G'];kacr6 && kacr6(dg95[o[340368]], dg95[o[340126]], dg95[o[340128]]);
    } });
}, window[o[340347]] = function (hj4fp, _vnk$, olxwq, _$nsk, bc0r81, a_c6r, r6kca, t5z9) {
  if (_$nsk == undefined) _$nsk = 0x1;wx[o[340235]]({ 'url': hj4fp, 'method': r6kca || o[340371], 'responseType': o[340372], 'data': _vnk$, 'header': { 'content-type': t5z9 || o[340237] }, 'success': function (d592t) {
      DEBUG && console[o[340042]](o[340373], hj4fp, info, d592t);if (d592t && d592t[o[340374]] == 0xc8) {
        var c01r8 = d592t[o[340200]];!a_c6r || a_c6r(c01r8) ? olxwq && olxwq(c01r8) : window[o[340375]](hj4fp, _vnk$, olxwq, _$nsk, bc0r81, a_c6r, d592t);
      } else window[o[340375]](hj4fp, _vnk$, olxwq, _$nsk, bc0r81, a_c6r, d592t);
    }, 'fail': function (p$fseu) {
      DEBUG && console[o[340042]](o[340376], hj4fp, info, p$fseu), window[o[340375]](hj4fp, _vnk$, olxwq, _$nsk, bc0r81, a_c6r, p$fseu);
    }, 'complete': function () {} });
}, window[o[340375]] = function ($enfsu, gzd5w, brc018, p$eusf, $nuesv, xq7wlg, xwoq7) {
  p$eusf - 0x1 > 0x0 ? setTimeout(function () {
    window[o[340347]]($enfsu, gzd5w, brc018, p$eusf - 0x1, $nuesv, xq7wlg);
  }, 0x3e8) : $nuesv && $nuesv(JSON[o[340027]]({ 'url': $enfsu, 'response': xwoq7 }));
}, window[o[340377]] = function (qhiolm, hj43p, mph, mj3p4h, omi3, u34pf, g5w9d) {
  !mph && (mph = {});var n$sk_ = Math[o[340213]](Date[o[340142]]() / 0x3e8);mph[o[340212]] = n$sk_, mph[o[340378]] = hj43p;var s_knva = Object[o[340379]](mph)[o[340380]](),
      ns_ak = '',
      g9tzd5 = '';for (var fuep4$ = 0x0; fuep4$ < s_knva[o[340010]]; fuep4$++) {
    ns_ak = ns_ak + (fuep4$ == 0x0 ? '' : '&') + s_knva[fuep4$] + mph[s_knva[fuep4$]], g9tzd5 = g9tzd5 + (fuep4$ == 0x0 ? '' : '&') + s_knva[fuep4$] + '=' + encodeURIComponent(mph[s_knva[fuep4$]]);
  }ns_ak = ns_ak + u$$8[o[340165]];var wlq7o = o[340381] + md5(ns_ak);send(qhiolm + '?' + g9tzd5 + (g9tzd5 == '' ? '' : '&') + wlq7o, null, mj3p4h, omi3, u34pf, g5w9d || function (k0ac) {
    return k0ac[o[340201]] == o[340288];
  }, null, o[340382]);
}, window['u$$G80'] = function (c6k_ar, uv$sne) {
  var e4f$pu = 0x0;u$$8[o[340023]] && (e4f$pu = u$$8[o[340023]][o[340024]]), sendApi(u$$8[o[340161]], o[340383], { 'partnerId': u$$8[o[340167]], 'gamePkg': u$$8[o[340022]], 'logTime': Math[o[340213]](Date[o[340142]]() / 0x3e8), 'platformUid': u$$8[o[340291]], 'type': c6k_ar, 'serverId': e4f$pu }, null, 0x2, null, function () {
    return !![];
  });
}, window['u$$80G'] = function (mp43jh) {
  sendApi(u$$8[o[340159]], o[340384], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, u$$8G0, u$G8$, u$80);
}, window['u$$8G0'] = function (ximo) {
  if (ximo[o[340201]] === o[340288] && ximo[o[340200]]) {
    ximo[o[340200]][o[340385]]({ 'id': -0x2, 'name': o[340386] }), ximo[o[340200]][o[340385]]({ 'id': -0x1, 'name': o[340387] }), u$$8[o[340388]] = ximo[o[340200]];if (window[o[340389]]) window[o[340389]][o[340390]]();
  } else u$$8[o[340391]] = ![], window['u$0G$8'](o[340392] + ximo[o[340201]]);
}, window['u$0G$'] = function (pue3f) {
  sendApi(u$$8[o[340159]], o[340393], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, u$0$G, u$G8$, u$80);
}, window['u$0$G'] = function (oimlqh) {
  u$$8[o[340394]] = ![];if (oimlqh[o[340201]] === o[340288] && oimlqh[o[340200]]) {
    for (var jio3hm = 0x0; jio3hm < oimlqh[o[340200]][o[340010]]; jio3hm++) {
      oimlqh[o[340200]][jio3hm][o[340306]] = u$$G0(oimlqh[o[340200]][jio3hm]);
    }u$$8[o[340170]][-0x1] = window[o[340395]](oimlqh[o[340200]]), window[o[340389]][o[340396]](-0x1);
  } else window['u$0G$8'](o[340397] + oimlqh[o[340201]]);
}, window[o[340398]] = function (mohqij) {
  sendApi(u$$8[o[340159]], o[340393], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, mohqij, u$G8$, u$80);
}, window['u$G0$'] = function (ql7gx, r1680) {
  sendApi(u$$8[o[340159]], o[340399], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]], 'server_group_id': r1680 }, u$G$0, u$G8$, u$80);
}, window['u$G$0'] = function (vunse) {
  u$$8[o[340394]] = ![];if (vunse[o[340201]] === o[340288] && vunse[o[340200]] && vunse[o[340200]][o[340200]]) {
    var d9zg5t = vunse[o[340200]][o[340400]],
        e$unfs = [];for (var f34e = 0x0; f34e < vunse[o[340200]][o[340200]][o[340010]]; f34e++) {
      vunse[o[340200]][o[340200]][f34e][o[340306]] = u$$G0(vunse[o[340200]][o[340200]][f34e]), (e$unfs[o[340010]] == 0x0 || vunse[o[340200]][o[340200]][f34e][o[340306]] != 0x0) && (e$unfs[e$unfs[o[340010]]] = vunse[o[340200]][o[340200]][f34e]);
    }u$$8[o[340170]][d9zg5t] = window[o[340395]](e$unfs), window[o[340389]][o[340396]](d9zg5t);
  } else window['u$0G$8'](o[340401] + vunse[o[340201]]);
}, window['u$7G8$'] = function (d5zwg9) {
  sendApi(u$$8[o[340159]], o[340402], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, reqServerRecommendCallBack, u$G8$, u$80);
}, window[o[340403]] = function (r0c186) {
  u$$8[o[340394]] = ![];if (r0c186[o[340201]] === o[340288] && r0c186[o[340200]]) {
    for (var qj = 0x0; qj < r0c186[o[340200]][o[340010]]; qj++) {
      r0c186[o[340200]][qj][o[340306]] = u$$G0(r0c186[o[340200]][qj]);
    }u$$8[o[340170]][-0x2] = window[o[340395]](r0c186[o[340200]]), window[o[340389]][o[340396]](-0x2);
  } else alert(o[340404] + r0c186[o[340201]]);
}, window[o[340395]] = function (xq7) {
  if (!xq7 && xq7[o[340010]] <= 0x0) return xq7;for (let r6c_ak = 0x0; r6c_ak < xq7[o[340010]]; r6c_ak++) {
    xq7[r6c_ak][o[340405]] && xq7[r6c_ak][o[340405]] == 0x1 && (xq7[r6c_ak][o[340302]] += o[340406]);
  }return xq7;
}, window['u$$0G'] = function (dgz7w9, vcak_6) {
  dgz7w9 = dgz7w9 || u$$8[o[340023]][o[340024]], sendApi(u$$8[o[340159]], o[340407], { 'type': '4', 'game_pkg': u$$8[o[340022]], 'server_id': dgz7w9 }, vcak_6);
}, window[o[340408]] = function ($euvns, qx7wo, _v$se, unvs) {
  _v$se = _v$se || u$$8[o[340023]][o[340024]], sendApi(u$$8[o[340159]], o[340409], { 'type': $euvns, 'game_pkg': qx7wo, 'server_id': _v$se }, unvs);
}, window['u$$G0'] = function (w7lxqg) {
  if (w7lxqg) {
    if (w7lxqg[o[340306]] == 0x1) {
      if (w7lxqg[o[340410]] == 0x1) return 0x2;else return 0x1;
    } else return w7lxqg[o[340306]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['u$80G$'] = function (u3, lxqg7) {
  u$$8[o[340411]] = { 'step': u3, 'server_id': lxqg7 };var qmijho = this;u$0$G8({ 'title': o[340412] }), sendApi(u$$8[o[340159]], o[340413], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'game_pkg': u$$8[o[340022]], 'server_id': lxqg7, 'platform': u$$8[o[340084]], 'platform_uid': u$$8[o[340291]], 'check_login_time': u$$8[o[340294]], 'check_login_sign': u$$8[o[340292]], 'version_name': u$$8[o[340263]] }, u$80$G, u$G8$, u$80, function (kac_6) {
    return kac_6[o[340201]] == o[340288] || kac_6[o[340001]] == o[340414] || kac_6[o[340001]] == o[340415];
  });
}, window['u$80$G'] = function (r18c60) {
  var mjqo = this;if (r18c60[o[340201]] === o[340288] && r18c60[o[340200]]) {
    var imlhoq = u$$8[o[340023]];imlhoq[o[340416]] = u$$8[o[340171]], imlhoq[o[340293]] = String(r18c60[o[340200]][o[340417]]), imlhoq[o[340177]] = parseInt(r18c60[o[340200]][o[340212]]);if (r18c60[o[340200]][o[340418]]) imlhoq[o[340418]] = parseInt(r18c60[o[340200]][o[340418]]);else imlhoq[o[340418]] = parseInt(r18c60[o[340200]][o[340024]]);imlhoq[o[340419]] = 0x0, imlhoq[o[340021]] = u$$8[o[340317]], imlhoq[o[340420]] = r18c60[o[340200]][o[340421]], imlhoq[o[340422]] = r18c60[o[340200]][o[340422]], console[o[340042]](o[340423] + JSON[o[340027]](imlhoq[o[340422]])), u$$8[o[340300]] == 0x1 && imlhoq[o[340422]] && imlhoq[o[340422]][o[340424]] == 0x1 && (u$$8[o[340425]] = 0x1, window[o[340035]][o[340036]]['u$78$']()), u$8G0$();
  } else u$$8[o[340411]][o[340426]] >= 0x3 ? (u$80(JSON[o[340027]](r18c60)), window['u$0G$8'](o[340427] + r18c60[o[340201]])) : sendApi(u$$8[o[340159]], o[340275], { 'platform': u$$8[o[340157]], 'partner_id': u$$8[o[340167]], 'token': u$$8[o[340273]], 'game_pkg': u$$8[o[340022]], 'deviceId': u$$8[o[340168]], 'scene': o[340276] + u$$8[o[340169]] }, function (eup$fs) {
    if (!eup$fs || eup$fs[o[340201]] != o[340288]) {
      window['u$0G$8'](o[340289] + eup$fs && eup$fs[o[340201]]);return;
    }u$$8[o[340292]] = String(eup$fs[o[340293]]), u$$8[o[340294]] = String(eup$fs[o[340212]]), setTimeout(function () {
      u$80G$(u$$8[o[340411]][o[340426]] + 0x1, u$$8[o[340411]][o[340024]]);
    }, 0x5dc);
  }, u$G8$, u$80, function (mixqlo) {
    return mixqlo[o[340201]] == o[340288] || mixqlo[o[340201]] == o[340428];
  });
}, window['u$8G0$'] = function () {
  ServerLoading[o[340036]][o[340309]](u$$8[o[340300]]), window['u$G8'] = !![], window['u$8$0G']();
}, window['u$8G$0'] = function () {
  if (window['u$8G'] && window['u$$G8'] && window[o[340183]] && window[o[340184]] && window['u$$8G'] && window['u$$G']) {
    if (!window[o[340429]][o[340036]]) {
      console[o[340042]](o[340430] + window[o[340429]][o[340036]]);var dg97 = wx[o[340431]](),
          askv = dg97[o[340138]] ? dg97[o[340138]] : 0x0,
          feup$4 = { 'cdn': window['u$$8'][o[340021]], 'spareCdn': window['u$$8'][o[340261]], 'newRegister': window['u$$8'][o[340300]], 'wxPC': window['u$$8'][o[340113]], 'wxIOS': window['u$$8'][o[340107]], 'wxAndroid': window['u$$8'][o[340110]], 'wxParam': { 'limitLoad': window['u$$8']['u$70G8$'], 'benchmarkLevel': window['u$$8']['u$70$G8'], 'wxFrom': window[o[340006]][o[340268]] == o[340432] ? 0x1 : 0x0, 'wxSDKVersion': window[o[340040]] }, 'configType': window['u$$8'][o[340178]], 'exposeType': window['u$$8'][o[340180]], 'scene': askv };new window[o[340429]](feup$4, window['u$$8'][o[340020]], window['u$70G$8']);
    }
  }
}, window['u$8$0G'] = function () {
  if (window['u$8G'] && window['u$$G8'] && window[o[340183]] && window[o[340184]] && window['u$$8G'] && window['u$$G'] && window['u$G8'] && window['u$G$']) {
    u$0$8G();if (!u$8G$) {
      u$8G$ = !![];if (!window[o[340429]][o[340036]]) window['u$8G$0']();var oxmi = 0x0,
          vsk$_n = wx[o[340433]]();vsk$_n && (window['u$$8'][o[340112]] && (oxmi = vsk$_n[o[340102]]), console[o[340001]](o[340434] + vsk$_n[o[340102]] + o[340435] + vsk$_n[o[340103]] + o[340436] + vsk$_n[o[340104]] + o[340437] + vsk$_n[o[340105]] + o[340438] + vsk$_n[o[340439]] + o[340440] + vsk$_n[o[340441]]));var ujp3f = {};for (const jmo3 in u$$8[o[340023]]) {
        ujp3f[jmo3] = u$$8[o[340023]][jmo3];
      }var c6a = { 'channel': window['u$$8'][o[340172]], 'account': window['u$$8'][o[340019]], 'userId': window['u$$8'][o[340290]], 'cdn': window['u$$8'][o[340021]], 'data': window['u$$8'][o[340200]], 'package': window['u$$8'][o[340155]], 'newRegister': window['u$$8'][o[340300]], 'pkgName': window['u$$8'][o[340022]], 'partnerId': window['u$$8'][o[340167]], 'platform_uid': window['u$$8'][o[340291]], 'deviceId': window['u$$8'][o[340168]], 'selectedServer': ujp3f, 'configType': window['u$$8'][o[340178]], 'exposeType': window['u$$8'][o[340180]], 'debugUsers': window['u$$8'][o[340175]], 'wxMenuTop': oxmi, 'wxShield': window['u$$8'][o[340182]] };if (window[o[340320]]) for (var kra0 in window[o[340320]]) {
        c6a[kra0] = window[o[340320]][kra0];
      }window[o[340429]][o[340036]]['u$G7$8'](c6a);
    }
  } else console[o[340001]](o[340442] + window['u$8G'] + o[340443] + window['u$$G8'] + o[340444] + window[o[340183]] + o[340445] + window[o[340184]] + o[340446] + window['u$$8G'] + o[340447] + window['u$$G'] + o[340448] + window['u$G8'] + o[340449] + window['u$G$']);
};