var Y = wx.$M;
import M_$0lbd from '../mmmmmSDK/mmmSDDK.js';window[Y[180565]] = { 'wxVersion': window[Y[180006]][Y[180007]] }, window[Y[180566]] = ![], window['$m21'] = 0x1, window[Y[180567]] = 0x1, window['$m012'] = !![], window[Y[180568]] = !![], window['$m54012'] = '', window['$m12'] = { 'base_cdn': Y[180569], 'cdn': Y[180569] }, $m12[Y[180570]] = {}, $m12[Y[180571]] = '0', $m12[Y[180080]] = window[Y[180565]][Y[180348]], $m12[Y[180115]] = '', $m12['os'] = '1', $m12[Y[180572]] = Y[180573], $m12[Y[180574]] = Y[180575], $m12[Y[180576]] = Y[180577], $m12[Y[180578]] = Y[180579], $m12[Y[180580]] = Y[180581], $m12[Y[180582]] = '1', $m12[Y[180022]] = '', $m12[Y[180583]] = '', $m12[Y[180584]] = 0x0, $m12[Y[180439]] = {}, $m12[Y[180585]] = parseInt($m12[Y[180582]]), $m12[Y[180586]] = $m12[Y[180582]], $m12[Y[180023]] = {}, $m12['$m41'] = Y[180587], $m12[Y[180588]] = ![], $m12[Y[180589]] = Y[180590], $m12[Y[180591]] = Date[Y[180142]](), $m12[Y[180592]] = Y[180593], $m12[Y[180594]] = '_a', $m12[Y[180334]] = 0x2, $m12[Y[180020]] = 0x7c1, $m12[Y[180348]] = window[Y[180565]][Y[180348]], $m12[Y[180595]] = ![], $m12[Y[180107]] = ![], $m12[Y[180110]] = ![], $m12[Y[180113]] = ![], window['$m021'] = 0x5, window['$m02'] = ![], window['$m20'] = ![], window['$m102'] = ![], window[Y[180516]] = ![], window[Y[180519]] = ![], window['$m120'] = ![], window['$m01'] = ![], window['$m10'] = ![], window['$m201'] = ![], window[Y[180596]] = function (z8ec2) {
  console[Y[180042]](Y[180596], z8ec2), wx[Y[180597]]({}), wx[Y[180049]]({ 'title': Y[180072], 'content': z8ec2, 'success'(vfk9) {
      if (vfk9[Y[180598]]) console[Y[180042]](Y[180599]);else vfk9[Y[180600]] && console[Y[180042]](Y[180601]);
    } });
}, window['$m4012'] = function (c2et8) {
  console[Y[180042]](Y[180602], c2et8), $m4120(), wx[Y[180049]]({ 'title': Y[180072], 'content': c2et8, 'confirmText': Y[180603], 'cancelText': Y[180604], 'success'(k9y1u) {
      if (k9y1u[Y[180598]]) window['$m14']();else k9y1u[Y[180600]] && (console[Y[180042]](Y[180605]), wx[Y[180606]]({}));
    } });
}, window[Y[180607]] = function (im5nl) {
  console[Y[180042]](Y[180607], im5nl), wx[Y[180049]]({ 'title': Y[180072], 'content': im5nl, 'confirmText': Y[180608], 'showCancel': ![], 'complete'(brwdfv) {
      console[Y[180042]](Y[180605]), wx[Y[180606]]({});
    } });
}, window['$m4021'] = ![], window['$m4102'] = function (hlin0) {
  window['$m4021'] = !![], wx[Y[180609]](hlin0);
}, window['$m4120'] = function () {
  window['$m4021'] && (window['$m4021'] = ![], wx[Y[180597]]({}));
}, window['$m4201'] = function (s6goca) {
  window[Y[180035]][Y[180036]]['$m4201'](s6goca);
}, window[Y[180610]] = function (vfr9wb, bdw$l0) {
  M_$0lbd[Y[180610]](vfr9wb, function (quy3x) {
    quy3x && quy3x[Y[180449]] ? quy3x[Y[180449]][Y[180448]] == 0x1 ? bdw$l0(!![]) : (bdw$l0(![]), console[Y[180001]](Y[180611] + quy3x[Y[180449]][Y[180612]])) : console[Y[180042]](Y[180610], quy3x);
  });
}, window['$m4210'] = function (saog) {
  console[Y[180042]](Y[180613], saog);
}, window['$m412'] = function (uy9k1x) {}, window['$m421'] = function (hmj7n_, v19r, t8pz2) {}, window['$m42'] = function (fwd$b) {
  console[Y[180042]](Y[180614], fwd$b), window[Y[180035]][Y[180036]][Y[180338]](), window[Y[180035]][Y[180036]][Y[180339]](), window[Y[180035]][Y[180036]][Y[180352]]();
}, window['$m24'] = function (xy9k) {
  window['$m4012'](Y[180615]);var yq1kx = { 'id': window['$m12'][Y[180016]], 'role': window['$m12'][Y[180017]], 'level': window['$m12'][Y[180018]], 'account': window['$m12'][Y[180019]], 'version': window['$m12'][Y[180020]], 'cdn': window['$m12'][Y[180021]], 'pkgName': window['$m12'][Y[180022]], 'gamever': window[Y[180006]][Y[180007]], 'serverid': window['$m12'][Y[180023]] ? window['$m12'][Y[180023]][Y[180024]] : 0x0, 'systemInfo': window[Y[180025]], 'error': Y[180616], 'stack': xy9k ? xy9k : Y[180615] },
      jh7m = JSON[Y[180027]](yq1kx);console[Y[180028]](Y[180617] + jh7m), window['$m41'](jh7m);
}, window['$m142'] = function (uy1x9) {
  var _g4os = JSON[Y[180618]](uy1x9);_g4os[Y[180619]] = window[Y[180006]][Y[180007]], _g4os[Y[180620]] = window['$m12'][Y[180023]] ? window['$m12'][Y[180023]][Y[180024]] : 0x0, _g4os[Y[180025]] = window[Y[180025]];var z8e2tc = JSON[Y[180027]](_g4os);console[Y[180028]](Y[180621] + z8e2tc), window['$m41'](z8e2tc);
}, window['$m124'] = function (v1rfk9, i0n5) {
  var _67o4s = { 'id': window['$m12'][Y[180016]], 'role': window['$m12'][Y[180017]], 'level': window['$m12'][Y[180018]], 'account': window['$m12'][Y[180019]], 'version': window['$m12'][Y[180020]], 'cdn': window['$m12'][Y[180021]], 'pkgName': window['$m12'][Y[180022]], 'gamever': window[Y[180006]][Y[180007]], 'serverid': window['$m12'][Y[180023]] ? window['$m12'][Y[180023]][Y[180024]] : 0x0, 'systemInfo': window[Y[180025]], 'error': v1rfk9, 'stack': i0n5 },
      t2z8 = JSON[Y[180027]](_67o4s);console[Y[180143]](Y[180622] + t2z8), window['$m41'](t2z8);
}, window['$m41'] = function (tpz2) {
  if (window['$m12'][Y[180116]] == Y[180623]) return;var bw$f0d = $m12['$m41'] + Y[180624] + $m12[Y[180019]];wx[Y[180625]]({ 'url': bw$f0d, 'method': Y[180626], 'data': tpz2, 'header': { 'content-type': Y[180627], 'cache-control': Y[180628] }, 'success': function (og4s_) {
      DEBUG && console[Y[180042]](Y[180629], bw$f0d, tpz2, og4s_);
    }, 'fail': function (d5$0b) {
      DEBUG && console[Y[180042]](Y[180629], bw$f0d, tpz2, d5$0b);
    }, 'complete': function () {} });
}, window[Y[180630]] = function () {
  function t8p2e() {
    return ((0x1 + Math[Y[180341]]()) * 0x10000 | 0x0)[Y[180631]](0x10)[Y[180632]](0x1);
  }return t8p2e() + t8p2e() + '-' + t8p2e() + '-' + t8p2e() + '-' + t8p2e() + '+' + t8p2e() + t8p2e() + t8p2e();
}, window['$m14'] = function () {
  console[Y[180042]](Y[180633]);var _7js4 = M_$0lbd[Y[180634]]();$m12[Y[180586]] = _7js4[Y[180635]], $m12[Y[180585]] = _7js4[Y[180635]], $m12[Y[180582]] = _7js4[Y[180635]], $m12[Y[180022]] = _7js4[Y[180636]];var eacg8o = { 'game_ver': $m12[Y[180080]] };$m12[Y[180583]] = this[Y[180630]](), $m4102({ 'title': Y[180637] }), M_$0lbd[Y[180481]](eacg8o, this['$m241'][Y[180345]](this));
}, window['$m241'] = function (k3xqy) {
  var os6 = k3xqy[Y[180638]];console[Y[180042]](Y[180639] + os6 + Y[180640] + (os6 == 0x1) + Y[180641] + k3xqy[Y[180007]] + Y[180642] + window[Y[180565]][Y[180348]]);if (!k3xqy[Y[180007]] || window['$m50241'](window[Y[180565]][Y[180348]], k3xqy[Y[180007]]) < 0x0) console[Y[180042]](Y[180643]), $m12[Y[180574]] = Y[180644], $m12[Y[180576]] = Y[180645], $m12[Y[180578]] = Y[180646], $m12[Y[180021]] = Y[180647], $m12[Y[180648]] = Y[180649], $m12[Y[180650]] = 'ts', $m12[Y[180595]] = ![];else window['$m50241'](window[Y[180565]][Y[180348]], k3xqy[Y[180007]]) == 0x0 ? (console[Y[180042]](Y[180651]), $m12[Y[180574]] = Y[180575], $m12[Y[180576]] = Y[180577], $m12[Y[180578]] = Y[180579], $m12[Y[180021]] = Y[180652], $m12[Y[180648]] = Y[180649], $m12[Y[180650]] = Y[180653], $m12[Y[180595]] = !![]) : (console[Y[180042]](Y[180654]), $m12[Y[180574]] = Y[180575], $m12[Y[180576]] = Y[180577], $m12[Y[180578]] = Y[180579], $m12[Y[180021]] = Y[180652], $m12[Y[180648]] = Y[180649], $m12[Y[180650]] = Y[180653], $m12[Y[180595]] = ![]);$m12[Y[180584]] = config[Y[180655]] ? config[Y[180655]] : 0x0, this['$m0142'](), this['$m0124'](), window[Y[180656]] = 0x5, $m4102({ 'title': Y[180657] }), M_$0lbd[Y[180658]](this['$m214'][Y[180345]](this));
}, window[Y[180656]] = 0x5, window['$m214'] = function (fv1w9, og6cas) {
  if (fv1w9 == 0x0 && og6cas && og6cas[Y[180659]]) {
    $m12[Y[180660]] = og6cas[Y[180659]];var ji7hm = this;$m4102({ 'title': Y[180661] }), sendApi($m12[Y[180574]], Y[180662], { 'platform': $m12[Y[180572]], 'partner_id': $m12[Y[180582]], 'token': og6cas[Y[180659]], 'game_pkg': $m12[Y[180022]], 'deviceId': $m12[Y[180583]], 'scene': Y[180663] + $m12[Y[180584]] }, this['$m0412'][Y[180345]](this), $m021, $m24);
  } else og6cas && og6cas[Y[180059]] && window[Y[180656]] > 0x0 && (og6cas[Y[180059]][Y[180108]](Y[180664]) != -0x1 || og6cas[Y[180059]][Y[180108]](Y[180665]) != -0x1 || og6cas[Y[180059]][Y[180108]](Y[180666]) != -0x1 || og6cas[Y[180059]][Y[180108]](Y[180667]) != -0x1 || og6cas[Y[180059]][Y[180108]](Y[180668]) != -0x1 || og6cas[Y[180059]][Y[180108]](Y[180669]) != -0x1) ? (window[Y[180656]]--, M_$0lbd[Y[180658]](this['$m214'][Y[180345]](this))) : (window['$m124'](Y[180670], JSON[Y[180027]]({ 'status': fv1w9, 'data': og6cas })), window['$m4012'](Y[180671] + (og6cas && og6cas[Y[180059]] ? '，' + og6cas[Y[180059]] : '')));
}, window['$m0412'] = function (rf9v) {
  if (!rf9v) {
    window['$m124'](Y[180672], Y[180673]), window['$m4012'](Y[180674]);return;
  }if (rf9v[Y[180448]] != Y[180447]) {
    window['$m124'](Y[180672], JSON[Y[180027]](rf9v)), window['$m4012'](Y[180675] + rf9v[Y[180448]]);return;
  }$m12[Y[180676]] = String(rf9v[Y[180019]]), $m12[Y[180019]] = String(rf9v[Y[180019]]), $m12[Y[180084]] = String(rf9v[Y[180084]]), $m12[Y[180586]] = String(rf9v[Y[180084]]), $m12[Y[180677]] = String(rf9v[Y[180677]]), $m12[Y[180678]] = String(rf9v[Y[180679]]), $m12[Y[180680]] = String(rf9v[Y[180681]]), $m12[Y[180679]] = '';var fvdrb = this;$m4102({ 'title': Y[180682] }), sendApi($m12[Y[180574]], Y[180683], { 'partner_id': $m12[Y[180582]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180583]] }, fvdrb['$m0421'][Y[180345]](fvdrb), $m021, $m24);
}, window['$m0421'] = function (mjs) {
  if (!mjs) {
    window['$m4012'](Y[180684]);return;
  }if (mjs[Y[180448]] != Y[180447]) {
    window['$m4012'](Y[180685] + mjs[Y[180448]]);return;
  }if (!mjs[Y[180449]] || mjs[Y[180449]][Y[180010]] == 0x0) {
    window['$m4012'](Y[180686]);return;
  }$m12[Y[180525]] = mjs[Y[180687]], $m12[Y[180023]] = { 'server_id': String(mjs[Y[180449]][0x0][Y[180024]]), 'server_name': String(mjs[Y[180449]][0x0][Y[180427]]), 'entry_ip': mjs[Y[180449]][0x0][Y[180688]], 'entry_port': parseInt(mjs[Y[180449]][0x0][Y[180689]]), 'status': $m104(mjs[Y[180449]][0x0]), 'start_time': mjs[Y[180449]][0x0][Y[180690]], 'cdn': $m12[Y[180021]] }, this['$m2104']();
}, window['$m2104'] = function () {
  if ($m12[Y[180525]] == 0x1) {
    var kru19 = $m12[Y[180023]][Y[180426]];if (kru19 === -0x1 || kru19 === 0x0) {
      window['$m4012'](kru19 === -0x1 ? Y[180691] : Y[180692]);return;
    }$m2401(0x0, $m12[Y[180023]][Y[180024]]), window[Y[180035]][Y[180036]][Y[180520]]($m12[Y[180525]]);
  } else window[Y[180035]][Y[180036]][Y[180517]](), $m4120();window['$m10'] = !![], window['$m2014'](), window['$m2140']();
}, window['$m0142'] = function () {
  sendApi($m12[Y[180574]], Y[180693], { 'game_pkg': $m12[Y[180022]], 'version_name': $m12[Y[180650]] }, this[Y[180694]][Y[180345]](this), $m021, $m24);
}, window[Y[180694]] = function (c2age) {
  if (!c2age) {
    window['$m4012'](Y[180695]);return;
  }if (c2age[Y[180448]] != Y[180447]) {
    window['$m4012'](Y[180696] + c2age[Y[180448]]);return;
  }if (!c2age[Y[180449]] || !c2age[Y[180449]][Y[180080]]) {
    window['$m4012'](Y[180697] + (c2age[Y[180449]] && c2age[Y[180449]][Y[180080]]));return;
  }c2age[Y[180449]][Y[180698]] && c2age[Y[180449]][Y[180698]][Y[180010]] > 0xa && ($m12[Y[180699]] = c2age[Y[180449]][Y[180698]], $m12[Y[180021]] = c2age[Y[180449]][Y[180698]]), c2age[Y[180449]][Y[180080]] && ($m12[Y[180020]] = c2age[Y[180449]][Y[180080]]), console[Y[180001]](Y[180700] + $m12[Y[180020]] + Y[180701] + $m12[Y[180650]]), window['$m120'] = !![], window['$m2014'](), window['$m2140']();
}, window[Y[180702]], window['$m0124'] = function () {
  sendApi($m12[Y[180574]], Y[180703], { 'game_pkg': $m12[Y[180022]] }, this['$m0241'][Y[180345]](this), $m021, $m24);
}, window['$m0241'] = function (eoc8a) {
  if (eoc8a[Y[180448]] === Y[180447] && eoc8a[Y[180449]]) {
    window[Y[180702]] = eoc8a[Y[180449]];for (var o8cage in eoc8a[Y[180449]]) {
      $m12[o8cage] = eoc8a[Y[180449]][o8cage];
    }
  } else console[Y[180001]](Y[180704] + eoc8a[Y[180448]]);window['$m01'] = !![], window['$m2140']();
}, window[Y[180705]] = function (kx3uq, hj5nm, e2p8tz, acgo, kv1fr, g2aec8, ce2g8a, uqyxk3, $i05d) {
  kv1fr = String(kv1fr);var b$wdf = ce2g8a,
      ky3u = uqyxk3;$m12[Y[180570]][kv1fr] = { 'productid': kv1fr, 'productname': b$wdf, 'productdesc': ky3u, 'roleid': kx3uq, 'rolename': hj5nm, 'rolelevel': e2p8tz, 'price': g2aec8, 'callback': $i05d }, sendApi($m12[Y[180578]], Y[180706], { 'game_pkg': $m12[Y[180022]], 'server_id': $m12[Y[180023]][Y[180024]], 'server_name': $m12[Y[180023]][Y[180427]], 'level': e2p8tz, 'uid': $m12[Y[180019]], 'role_id': kx3uq, 'role_name': hj5nm, 'product_id': kv1fr, 'product_name': b$wdf, 'product_desc': ky3u, 'money': g2aec8, 'partner_id': $m12[Y[180582]] }, toPayCallBack, $m021, $m24);
}, window[Y[180707]] = function (vbdrfw) {
  if (vbdrfw) {
    if (vbdrfw[Y[180708]] === 0xc8 || vbdrfw[Y[180448]] == Y[180447]) {
      var h5in = $m12[Y[180570]][String(vbdrfw[Y[180709]])];if (h5in[Y[180710]]) h5in[Y[180710]](vbdrfw[Y[180709]], vbdrfw[Y[180711]], -0x1);M_$0lbd[Y[180712]]({ 'cpbill': vbdrfw[Y[180711]], 'productid': vbdrfw[Y[180709]], 'productname': h5in[Y[180713]], 'productdesc': h5in[Y[180714]], 'serverid': $m12[Y[180023]][Y[180024]], 'servername': $m12[Y[180023]][Y[180427]], 'roleid': h5in[Y[180715]], 'rolename': h5in[Y[180716]], 'rolelevel': h5in[Y[180717]], 'price': h5in[Y[180718]], 'extension': JSON[Y[180027]]({ 'cp_order_id': vbdrfw[Y[180711]] }) }, function (d0$bf, j46) {
        h5in[Y[180710]] && d0$bf == 0x0 && h5in[Y[180710]](vbdrfw[Y[180709]], vbdrfw[Y[180711]], d0$bf);console[Y[180001]](JSON[Y[180027]]({ 'type': Y[180719], 'status': d0$bf, 'data': vbdrfw, 'role_name': h5in[Y[180716]] }));if (d0$bf === 0x0) {} else {
          if (d0$bf === 0x1) {} else {
            if (d0$bf === 0x2) {}
          }
        }
      });
    } else alert(vbdrfw[Y[180001]]);
  }
}, window['$m0214'] = function () {}, window['$m402'] = function (a82cge, quk1, gca68o, nhj7_m, v$df) {
  M_$0lbd[Y[180720]]($m12[Y[180023]][Y[180024]], $m12[Y[180023]][Y[180427]] || $m12[Y[180023]][Y[180024]], a82cge, quk1, gca68o), sendApi($m12[Y[180574]], Y[180721], { 'game_pkg': $m12[Y[180022]], 'server_id': $m12[Y[180023]][Y[180024]], 'role_id': a82cge, 'uid': $m12[Y[180019]], 'role_name': quk1, 'role_type': nhj7_m, 'level': gca68o });
}, window['$m420'] = function (_4js76, i$0l5, wrfv9b, w1rv9f, b$wfv, v91frw, v19rw, rvk19f, asc, u91krx) {
  $m12[Y[180016]] = _4js76, $m12[Y[180017]] = i$0l5, $m12[Y[180018]] = wrfv9b, M_$0lbd[Y[180722]]($m12[Y[180023]][Y[180024]], $m12[Y[180023]][Y[180427]] || $m12[Y[180023]][Y[180024]], _4js76, i$0l5, wrfv9b), sendApi($m12[Y[180574]], Y[180723], { 'game_pkg': $m12[Y[180022]], 'server_id': $m12[Y[180023]][Y[180024]], 'role_id': _4js76, 'uid': $m12[Y[180019]], 'role_name': i$0l5, 'role_type': w1rv9f, 'level': wrfv9b, 'evolution': b$wfv });
}, window['$m042'] = function (kxu9y, t2ca8, acge8, rfvbd, oae8cg, bwfvr9, wbl0$d, gocae8, pe2zt, _hmn7) {
  $m12[Y[180016]] = kxu9y, $m12[Y[180017]] = t2ca8, $m12[Y[180018]] = acge8, M_$0lbd[Y[180724]]($m12[Y[180023]][Y[180024]], $m12[Y[180023]][Y[180427]] || $m12[Y[180023]][Y[180024]], kxu9y, t2ca8, acge8), sendApi($m12[Y[180574]], Y[180723], { 'game_pkg': $m12[Y[180022]], 'server_id': $m12[Y[180023]][Y[180024]], 'role_id': kxu9y, 'uid': $m12[Y[180019]], 'role_name': t2ca8, 'role_type': rfvbd, 'level': acge8, 'evolution': oae8cg });
}, window['$m024'] = function (_6s7j4) {}, window['$m40'] = function (s7j_64) {
  M_$0lbd[Y[180725]](Y[180725], function (h7mjni) {
    s7j_64 && s7j_64(h7mjni);
  });
}, window[Y[180726]] = function () {
  M_$0lbd[Y[180726]]();
}, window[Y[180727]] = function () {
  M_$0lbd[Y[180728]]();
}, window[Y[180729]] = function (b$w0, ld5b0$, g64sa, wdl0b, f9kr1, hmli, _7mjn, j4_s7m) {
  j4_s7m = j4_s7m || $m12[Y[180023]][Y[180024]], sendApi($m12[Y[180574]], Y[180730], { 'phone': b$w0, 'role_id': ld5b0$, 'uid': $m12[Y[180019]], 'game_pkg': $m12[Y[180022]], 'partner_id': $m12[Y[180582]], 'server_id': j4_s7m }, _7mjn);
}, window[Y[180136]] = function ($bl05d) {
  window['$m240'] = $bl05d, window['$m240'] && window['$m04'] && (console[Y[180001]](Y[180137] + window['$m04'][Y[180138]]), window['$m240'](window['$m04']), window['$m04'] = null);
}, window['$m204'] = function (bwfd$v, as64og, n05il$, et2a8) {
  window[Y[180731]](Y[180732], { 'game_pkg': window['$m12'][Y[180022]], 'role_id': as64og, 'server_id': n05il$ }, et2a8);
}, window['$m1402'] = function (wbrvf, gs4_o) {
  function j7_h4m(fbrd) {
    var h_74jm = [],
        m_7s4j = [],
        a64sog = window[Y[180006]][Y[180733]];for (var sg_6o in a64sog) {
      var n5li = Number(sg_6o);(!wbrvf || !wbrvf[Y[180010]] || wbrvf[Y[180108]](n5li) != -0x1) && (m_7s4j[Y[180039]](a64sog[sg_6o]), h_74jm[Y[180039]]([n5li, 0x3]));
    }window['$m50241'](window[Y[180040]], Y[180734]) >= 0x0 ? (console[Y[180042]](Y[180735]), M_$0lbd[Y[180736]] && M_$0lbd[Y[180736]](m_7s4j, function (ag2ce) {
      console[Y[180042]](Y[180737]), console[Y[180042]](ag2ce);if (ag2ce && ag2ce[Y[180059]] == Y[180738]) for (var g6ca8 in a64sog) {
        if (ag2ce[a64sog[g6ca8]] == Y[180739]) {
          var o74s6 = Number(g6ca8);for (var _4g6s = 0x0; _4g6s < h_74jm[Y[180010]]; _4g6s++) {
            if (h_74jm[_4g6s][0x0] == o74s6) {
              h_74jm[_4g6s][0x1] = 0x1;break;
            }
          }
        }
      }window['$m50241'](window[Y[180040]], Y[180740]) >= 0x0 ? wx[Y[180741]]({ 'withSubscriptions': !![], 'success': function (ru19x) {
          var fk19rv = ru19x[Y[180742]][Y[180743]];if (fk19rv) {
            console[Y[180042]](Y[180744]), console[Y[180042]](fk19rv);for (var wfd0$ in a64sog) {
              if (fk19rv[a64sog[wfd0$]] == Y[180739]) {
                var $dil = Number(wfd0$);for (var wvd = 0x0; wvd < h_74jm[Y[180010]]; wvd++) {
                  if (h_74jm[wvd][0x0] == $dil) {
                    h_74jm[wvd][0x1] = 0x2;break;
                  }
                }
              }
            }console[Y[180042]](h_74jm), gs4_o && gs4_o(h_74jm);
          } else console[Y[180042]](Y[180745]), console[Y[180042]](ru19x), console[Y[180042]](h_74jm), gs4_o && gs4_o(h_74jm);
        }, 'fail': function () {
          console[Y[180042]](Y[180746]), console[Y[180042]](h_74jm), gs4_o && gs4_o(h_74jm);
        } }) : (console[Y[180042]](Y[180747] + window[Y[180040]]), console[Y[180042]](h_74jm), gs4_o && gs4_o(h_74jm));
    })) : (console[Y[180042]](Y[180748] + window[Y[180040]]), console[Y[180042]](h_74jm), gs4_o && gs4_o(h_74jm)), wx[Y[180749]](j7_h4m);
  }wx[Y[180750]](j7_h4m);
}, window['$m1420'] = { 'isSuccess': ![], 'level': Y[180751], 'isCharging': ![] }, window['$m1042'] = function (i5$d0) {
  wx[Y[180124]]({ 'success': function ($nli50) {
      var w9vfbr = window['$m1420'];w9vfbr[Y[180752]] = !![], w9vfbr[Y[180126]] = Number($nli50[Y[180126]])[Y[180753]](0x0), w9vfbr[Y[180128]] = $nli50[Y[180128]], i5$d0 && i5$d0(w9vfbr[Y[180752]], w9vfbr[Y[180126]], w9vfbr[Y[180128]]);
    }, 'fail': function (hinml5) {
      console[Y[180042]](Y[180754], hinml5[Y[180059]]);var j5inm = window['$m1420'];i5$d0 && i5$d0(j5inm[Y[180752]], j5inm[Y[180126]], j5inm[Y[180128]]);
    } });
}, window[Y[180731]] = function (qk3uxy, v1k, cg8a, g2ce8a, h_njm7, fvw19r, cgsoa, $bdf0w) {
  if (g2ce8a == undefined) g2ce8a = 0x1;wx[Y[180625]]({ 'url': qk3uxy, 'method': cgsoa || Y[180755], 'responseType': Y[180343], 'data': v1k, 'header': { 'content-type': $bdf0w || Y[180627] }, 'success': function (h4jm7) {
      DEBUG && console[Y[180042]](Y[180756], qk3uxy, info, h4jm7);if (h4jm7 && h4jm7[Y[180757]] == 0xc8) {
        var dfwrb = h4jm7[Y[180449]];!fvw19r || fvw19r(dfwrb) ? cg8a && cg8a(dfwrb) : window[Y[180758]](qk3uxy, v1k, cg8a, g2ce8a, h_njm7, fvw19r, h4jm7);
      } else window[Y[180758]](qk3uxy, v1k, cg8a, g2ce8a, h_njm7, fvw19r, h4jm7);
    }, 'fail': function (e2ct) {
      DEBUG && console[Y[180042]](Y[180759], qk3uxy, info, e2ct), window[Y[180758]](qk3uxy, v1k, cg8a, g2ce8a, h_njm7, fvw19r, e2ct);
    }, 'complete': function () {} });
}, window[Y[180758]] = function (ku9x1y, bdfw$v, hni05l, u9kx1r, x9k1ur, i5$0ln, vbf9r) {
  u9kx1r - 0x1 > 0x0 ? setTimeout(function () {
    window[Y[180731]](ku9x1y, bdfw$v, hni05l, u9kx1r - 0x1, x9k1ur, i5$0ln);
  }, 0x3e8) : x9k1ur && x9k1ur(JSON[Y[180027]]({ 'url': ku9x1y, 'response': vbf9r }));
}, window[Y[180760]] = function (l5$ni, g_4s6o, nl50, pe2t, go6s, z8ep, ykux91) {
  !nl50 && (nl50 = {});var imj7h = Math[Y[180537]](Date[Y[180142]]() / 0x3e8);nl50[Y[180681]] = imj7h, nl50[Y[180761]] = g_4s6o;var acog6 = Object[Y[180762]](nl50)[Y[180453]](),
      ag8o6 = '',
      mn5hl = '';for (var $dfwvb = 0x0; $dfwvb < acog6[Y[180010]]; $dfwvb++) {
    ag8o6 = ag8o6 + ($dfwvb == 0x0 ? '' : '&') + acog6[$dfwvb] + nl50[acog6[$dfwvb]], mn5hl = mn5hl + ($dfwvb == 0x0 ? '' : '&') + acog6[$dfwvb] + '=' + encodeURIComponent(nl50[acog6[$dfwvb]]);
  }ag8o6 = ag8o6 + $m12[Y[180580]];var nh5mi = Y[180763] + md5(ag8o6);send(l5$ni + '?' + mn5hl + (mn5hl == '' ? '' : '&') + nh5mi, null, pe2t, go6s, z8ep, ykux91 || function (ga86oc) {
    return ga86oc[Y[180448]] == Y[180447];
  }, null, Y[180764]);
}, window['$m1024'] = function (kxu9, dlb0$w) {
  var o6s_4 = 0x0;$m12[Y[180023]] && (o6s_4 = $m12[Y[180023]][Y[180024]]), sendApi($m12[Y[180576]], Y[180765], { 'partnerId': $m12[Y[180582]], 'gamePkg': $m12[Y[180022]], 'logTime': Math[Y[180537]](Date[Y[180142]]() / 0x3e8), 'platformUid': $m12[Y[180677]], 'type': kxu9, 'serverId': o6s_4 }, null, 0x2, null, function () {
    return !![];
  });
}, window['$m1240'] = function (m5ihjn) {
  sendApi($m12[Y[180574]], Y[180766], { 'partner_id': $m12[Y[180582]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180583]] }, $m1204, $m021, $m24);
}, window['$m1204'] = function (hmn_j7) {
  if (hmn_j7[Y[180448]] === Y[180447] && hmn_j7[Y[180449]]) {
    hmn_j7[Y[180449]][Y[180767]]({ 'id': -0x2, 'name': Y[180768] }), hmn_j7[Y[180449]][Y[180767]]({ 'id': -0x1, 'name': Y[180769] }), $m12[Y[180400]] = hmn_j7[Y[180449]];if (window[Y[180392]]) window[Y[180392]][Y[180433]]();
  } else $m12[Y[180410]] = ![], window['$m4012'](Y[180770] + hmn_j7[Y[180448]]);
}, window['$m401'] = function (tecz) {
  sendApi($m12[Y[180574]], Y[180771], { 'partner_id': $m12[Y[180582]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180583]] }, $m410, $m021, $m24);
}, window['$m410'] = function (njhm7_) {
  $m12[Y[180441]] = ![];if (njhm7_[Y[180448]] === Y[180447] && njhm7_[Y[180449]]) {
    for (var hi7nm = 0x0; hi7nm < njhm7_[Y[180449]][Y[180010]]; hi7nm++) {
      njhm7_[Y[180449]][hi7nm][Y[180426]] = $m104(njhm7_[Y[180449]][hi7nm]);
    }$m12[Y[180439]][-0x1] = window[Y[180772]](njhm7_[Y[180449]]), window[Y[180392]][Y[180440]](-0x1);
  } else window['$m4012'](Y[180773] + njhm7_[Y[180448]]);
}, window[Y[180774]] = function ($vwfb) {
  sendApi($m12[Y[180574]], Y[180771], { 'partner_id': $m12[Y[180582]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180583]] }, $vwfb, $m021, $m24);
}, window['$m041'] = function (a64gos, l$5b0) {
  sendApi($m12[Y[180574]], Y[180775], { 'partner_id': $m12[Y[180582]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180583]], 'server_group_id': l$5b0 }, $m014, $m021, $m24);
}, window['$m014'] = function (ld$5b) {
  $m12[Y[180441]] = ![];if (ld$5b[Y[180448]] === Y[180447] && ld$5b[Y[180449]] && ld$5b[Y[180449]][Y[180449]]) {
    var _jmn = ld$5b[Y[180449]][Y[180776]],
        vfbr = [];for (var hln05 = 0x0; hln05 < ld$5b[Y[180449]][Y[180449]][Y[180010]]; hln05++) {
      ld$5b[Y[180449]][Y[180449]][hln05][Y[180426]] = $m104(ld$5b[Y[180449]][Y[180449]][hln05]), (vfbr[Y[180010]] == 0x0 || ld$5b[Y[180449]][Y[180449]][hln05][Y[180426]] != 0x0) && (vfbr[vfbr[Y[180010]]] = ld$5b[Y[180449]][Y[180449]][hln05]);
    }$m12[Y[180439]][_jmn] = window[Y[180772]](vfbr), window[Y[180392]][Y[180440]](_jmn);
  } else window['$m4012'](Y[180777] + ld$5b[Y[180448]]);
}, window['$m5021'] = function (db0wl) {
  sendApi($m12[Y[180574]], Y[180778], { 'partner_id': $m12[Y[180582]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180583]] }, reqServerRecommendCallBack, $m021, $m24);
}, window[Y[180779]] = function (jhm4) {
  $m12[Y[180441]] = ![];if (jhm4[Y[180448]] === Y[180447] && jhm4[Y[180449]]) {
    for (var gsoa46 = 0x0; gsoa46 < jhm4[Y[180449]][Y[180010]]; gsoa46++) {
      jhm4[Y[180449]][gsoa46][Y[180426]] = $m104(jhm4[Y[180449]][gsoa46]);
    }$m12[Y[180439]][-0x2] = window[Y[180772]](jhm4[Y[180449]]), window[Y[180392]][Y[180440]](-0x2);
  } else alert(Y[180780] + jhm4[Y[180448]]);
}, window[Y[180772]] = function (h7n_j) {
  if (!h7n_j && h7n_j[Y[180010]] <= 0x0) return h7n_j;for (let xk3quy = 0x0; xk3quy < h7n_j[Y[180010]]; xk3quy++) {
    h7n_j[xk3quy][Y[180781]] && h7n_j[xk3quy][Y[180781]] == 0x1 && (h7n_j[xk3quy][Y[180427]] += Y[180782]);
  }return h7n_j;
}, window['$m140'] = function (mhjni7, yxqku1) {
  mhjni7 = mhjni7 || $m12[Y[180023]][Y[180024]], sendApi($m12[Y[180574]], Y[180783], { 'type': '4', 'game_pkg': $m12[Y[180022]], 'server_id': mhjni7 }, yxqku1);
}, window[Y[180784]] = function (r19uxk, jmin7h, lhi50n, d5bl0) {
  lhi50n = lhi50n || $m12[Y[180023]][Y[180024]], sendApi($m12[Y[180574]], Y[180785], { 'type': r19uxk, 'game_pkg': jmin7h, 'server_id': lhi50n }, d5bl0);
}, window['$m104'] = function (geca82) {
  if (geca82) {
    if (geca82[Y[180426]] == 0x1) {
      if (geca82[Y[180786]] == 0x1) return 0x2;else return 0x1;
    } else return geca82[Y[180426]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$m2401'] = function (bd$l5, ijh5m) {
  $m12[Y[180787]] = { 'step': bd$l5, 'server_id': ijh5m };var rfw1 = this;$m4102({ 'title': Y[180788] }), sendApi($m12[Y[180574]], Y[180789], { 'partner_id': $m12[Y[180582]], 'uid': $m12[Y[180019]], 'game_pkg': $m12[Y[180022]], 'server_id': ijh5m, 'platform': $m12[Y[180084]], 'platform_uid': $m12[Y[180677]], 'check_login_time': $m12[Y[180680]], 'check_login_sign': $m12[Y[180678]], 'version_name': $m12[Y[180650]] }, $m2410, $m021, $m24, function (ec8ta2) {
    return ec8ta2[Y[180448]] == Y[180447] || ec8ta2[Y[180001]] == Y[180790] || ec8ta2[Y[180001]] == Y[180791];
  });
}, window['$m2410'] = function ($wd0b) {
  var fbvwrd = this;if ($wd0b[Y[180448]] === Y[180447] && $wd0b[Y[180449]]) {
    var ez82tc = $m12[Y[180023]];ez82tc[Y[180792]] = $m12[Y[180585]], ez82tc[Y[180679]] = String($wd0b[Y[180449]][Y[180793]]), ez82tc[Y[180591]] = parseInt($wd0b[Y[180449]][Y[180681]]);if ($wd0b[Y[180449]][Y[180794]]) ez82tc[Y[180794]] = parseInt($wd0b[Y[180449]][Y[180794]]);else ez82tc[Y[180794]] = parseInt($wd0b[Y[180449]][Y[180024]]);ez82tc[Y[180795]] = 0x0, ez82tc[Y[180021]] = $m12[Y[180699]], ez82tc[Y[180796]] = $wd0b[Y[180449]][Y[180797]], ez82tc[Y[180798]] = $wd0b[Y[180449]][Y[180798]], console[Y[180042]](Y[180799] + JSON[Y[180027]](ez82tc[Y[180798]])), $m12[Y[180525]] == 0x1 && ez82tc[Y[180798]] && ez82tc[Y[180798]][Y[180800]] == 0x1 && ($m12[Y[180349]] = 0x1, window[Y[180035]][Y[180036]]['$m521']()), $m2041();
  } else $m12[Y[180787]][Y[180801]] >= 0x3 ? ($m24(JSON[Y[180027]]($wd0b)), window['$m4012'](Y[180802] + $wd0b[Y[180448]])) : sendApi($m12[Y[180574]], Y[180662], { 'platform': $m12[Y[180572]], 'partner_id': $m12[Y[180582]], 'token': $m12[Y[180660]], 'game_pkg': $m12[Y[180022]], 'deviceId': $m12[Y[180583]], 'scene': Y[180663] + $m12[Y[180584]] }, function (jmhn5) {
    if (!jmhn5 || jmhn5[Y[180448]] != Y[180447]) {
      window['$m4012'](Y[180675] + jmhn5 && jmhn5[Y[180448]]);return;
    }$m12[Y[180678]] = String(jmhn5[Y[180679]]), $m12[Y[180680]] = String(jmhn5[Y[180681]]), setTimeout(function () {
      $m2401($m12[Y[180787]][Y[180801]] + 0x1, $m12[Y[180787]][Y[180024]]);
    }, 0x5dc);
  }, $m021, $m24, function (l0nih5) {
    return l0nih5[Y[180448]] == Y[180447] || l0nih5[Y[180448]] == Y[180803];
  });
}, window['$m2041'] = function () {
  ServerLoading[Y[180036]][Y[180520]]($m12[Y[180525]]), window['$m02'] = !![], window['$m2140']();
}, window['$m2014'] = function () {
  if (window['$m20'] && window['$m102'] && window[Y[180516]] && window[Y[180519]] && window['$m120'] && window['$m10']) {
    if (!window[Y[180804]][Y[180036]]) {
      console[Y[180042]](Y[180805] + window[Y[180804]][Y[180036]]);var b0$wl = wx[Y[180806]](),
          wvf9br = b0$wl[Y[180138]] ? b0$wl[Y[180138]] : 0x0,
          mjni7 = { 'cdn': window['$m12'][Y[180021]], 'spareCdn': window['$m12'][Y[180648]], 'newRegister': window['$m12'][Y[180525]], 'wxPC': window['$m12'][Y[180113]], 'wxIOS': window['$m12'][Y[180107]], 'wxAndroid': window['$m12'][Y[180110]], 'wxParam': { 'limitLoad': window['$m12']['$m54021'], 'benchmarkLevel': window['$m12']['$m54102'], 'wxFrom': window[Y[180006]][Y[180655]] == Y[180807] ? 0x1 : 0x0, 'wxSDKVersion': window[Y[180040]] }, 'configType': window['$m12'][Y[180592]], 'exposeType': window['$m12'][Y[180594]], 'scene': wvf9br };new window[Y[180804]](mjni7, window['$m12'][Y[180020]], window['$m54012']);
    }
  }
}, window['$m2140'] = function () {
  if (window['$m20'] && window['$m102'] && window[Y[180516]] && window[Y[180519]] && window['$m120'] && window['$m10'] && window['$m02'] && window['$m01']) {
    $m4120();if (!$m201) {
      $m201 = !![];if (!window[Y[180804]][Y[180036]]) window['$m2014']();var i05hnl = 0x0,
          j7m_nh = wx[Y[180808]]();j7m_nh && (window['$m12'][Y[180112]] && (i05hnl = j7m_nh[Y[180102]]), console[Y[180001]](Y[180809] + j7m_nh[Y[180102]] + Y[180810] + j7m_nh[Y[180103]] + Y[180811] + j7m_nh[Y[180104]] + Y[180812] + j7m_nh[Y[180105]] + Y[180813] + j7m_nh[Y[180312]] + Y[180814] + j7m_nh[Y[180314]]));var e28ac = {};for (const in5hm in $m12[Y[180023]]) {
        e28ac[in5hm] = $m12[Y[180023]][in5hm];
      }var lhimn5 = { 'channel': window['$m12'][Y[180586]], 'account': window['$m12'][Y[180019]], 'userId': window['$m12'][Y[180676]], 'cdn': window['$m12'][Y[180021]], 'data': window['$m12'][Y[180449]], 'package': window['$m12'][Y[180571]], 'newRegister': window['$m12'][Y[180525]], 'pkgName': window['$m12'][Y[180022]], 'partnerId': window['$m12'][Y[180582]], 'platform_uid': window['$m12'][Y[180677]], 'deviceId': window['$m12'][Y[180583]], 'selectedServer': e28ac, 'configType': window['$m12'][Y[180592]], 'exposeType': window['$m12'][Y[180594]], 'debugUsers': window['$m12'][Y[180589]], 'wxMenuTop': i05hnl, 'wxShield': window['$m12'][Y[180595]] };if (window[Y[180702]]) for (var qxku3 in window[Y[180702]]) {
        lhimn5[qxku3] = window[Y[180702]][qxku3];
      }window[Y[180804]][Y[180036]]['$m215'](lhimn5);
    }
  } else console[Y[180001]](Y[180815] + window['$m20'] + Y[180816] + window['$m102'] + Y[180817] + window[Y[180516]] + Y[180818] + window[Y[180519]] + Y[180819] + window['$m120'] + Y[180820] + window['$m10'] + Y[180821] + window['$m02'] + Y[180822] + window['$m01']);
};