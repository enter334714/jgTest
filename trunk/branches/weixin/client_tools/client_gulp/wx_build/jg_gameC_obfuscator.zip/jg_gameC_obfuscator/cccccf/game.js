var p = wx.$h;
require('ccccBuff.js'), window[p[48740]][p[48730]][p[48618]] = null, window['client_pb'] = require('ccccleintpb.js'), window[p[45488]] = window[p[48740]][p[45376]][p[45377]](client_pb);