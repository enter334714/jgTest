var p = wx.$h;
require(p[49675]);