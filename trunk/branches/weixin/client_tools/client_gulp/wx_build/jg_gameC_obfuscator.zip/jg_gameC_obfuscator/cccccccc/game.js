var p = wx.$h;
import 'ccccccccmain.js';