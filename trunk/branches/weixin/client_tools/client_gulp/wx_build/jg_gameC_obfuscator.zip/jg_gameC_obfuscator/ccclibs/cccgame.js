var p = wx.$h;
console[p[20078]](p[49161]), window[p[49162]], wx[p[49163]](function (p437fa) {
  if (p437fa) {
    if (p437fa[p[24549]]) {
      var lcsd = window[p[20557]][p[49164]][p[24728]](new RegExp(/\./, 'g'), '_'),
          g8_ = p437fa[p[24549]],
          w2vx = g8_[p[32099]](/(cccccccc\/cccgame.js:)[0-9]{1,60}(:)/g);if (w2vx) for (var warn4p = 0x0; warn4p < w2vx[p[20013]]; warn4p++) {
        if (w2vx[warn4p] && w2vx[warn4p][p[20013]] > 0x0) {
          var ft731j = parseInt(w2vx[warn4p][p[24728]](p[49165], '')[p[24728]](':', ''));g8_ = g8_[p[24728]](w2vx[warn4p], w2vx[warn4p][p[24728]](':' + ft731j + ':', ':' + (ft731j - 0x2) + ':'));
        }
      }g8_ = g8_[p[24728]](new RegExp(p[49166], 'g'), p[49167] + lcsd + p[45447]), g8_ = g8_[p[24728]](new RegExp(p[49168], 'g'), p[49167] + lcsd + p[45447]), p437fa[p[24549]] = g8_;
    }var ozy9bi = { 'id': window['$aQV'][p[49169]], 'role': window['$aQV'][p[24670]], 'level': window['$aQV'][p[49170]], 'user': window['$aQV'][p[45347]], 'version': window['$aQV'][p[20101]], 'cdn': window['$aQV'][p[24547]], 'pkgName': window['$aQV'][p[45348]], 'gamever': window[p[20557]][p[49164]], 'serverid': window['$aQV'][p[45342]] ? window['$aQV'][p[45342]][p[31553]] : 0x0, 'systemInfo': window[p[49171]], 'error': p[49172], 'stack': p437fa ? p437fa[p[24549]] : '' },
        _gv20x = JSON[p[24533]](ozy9bi);console[p[20125]](p[49173] + _gv20x), (!window[p[49162]] || window[p[49162]] != ozy9bi[p[20125]]) && (window[p[49162]] = ozy9bi[p[20125]], window['$a5Q'](ozy9bi));
  }
});import 'cccmd5min.js';import 'ccczlibs.js';window[p[49174]] = require(p[49175]);import 'cccindex.js';import 'ccclibsmin.js';import 'cccwxmini.js';import 'cccinitmin.js';console[p[20078]](p[49176]), console[p[20078]](p[49177]), $a5Q3V({ 'title': p[49178] });var a_n2xwp = { '$aH5VQ3': !![] };new window[p[49179]](a_n2xwp), window[p[49179]][p[20148]]['$aH3QV5']();if (window['$aH5QV3']) clearInterval(window['$aH5QV3']);window['$aH5QV3'] = null, window['$aH3V5Q'] = function (a3p4w, aw2pnr) {
  if (!a3p4w || !aw2pnr) return 0x0;a3p4w = a3p4w[p[20015]]('.'), aw2pnr = aw2pnr[p[20015]]('.');const iyo$eb = Math[p[20853]](a3p4w[p[20013]], aw2pnr[p[20013]]);while (a3p4w[p[20013]] < iyo$eb) {
    a3p4w[p[20029]]('0');
  }while (aw2pnr[p[20013]] < iyo$eb) {
    aw2pnr[p[20029]]('0');
  }for (var f3jt71 = 0x0; f3jt71 < iyo$eb; f3jt71++) {
    const ldscm = parseInt(a3p4w[f3jt71]),
          apw47 = parseInt(aw2pnr[f3jt71]);if (ldscm > apw47) return 0x1;else {
      if (ldscm < apw47) return -0x1;
    }
  }return 0x0;
}, window[p[49180]] = wx[p[49181]]()[p[49180]], console[p[20482]](p[49182] + window[p[49180]]);var a_p43wa7 = wx[p[49183]]();a_p43wa7[p[49184]](function (cjft1) {
  console[p[20482]](p[49185] + cjft1[p[49186]]);
}), a_p43wa7[p[49187]](function () {
  wx[p[49188]]({ 'title': p[49189], 'content': p[49190], 'showCancel': ![], 'success': function (nr2wap) {
      a_p43wa7[p[49191]]();
    } });
}), a_p43wa7[p[49192]](function () {
  console[p[20482]](p[49193]);
}), window['$aH3VQ5'] = function () {
  console[p[20482]](p[49194]);var ei9yob = wx[p[49195]]({ 'name': p[49196], 'success': function (e$k6h) {
      console[p[20482]](p[49197]), console[p[20482]](e$k6h), e$k6h && e$k6h[p[45533]] == p[49198] ? (window['$aV3'] = !![], window['$aV3Q5'](), window['$aVQ53']()) : setTimeout(function () {
        window['$aH3VQ5']();
      }, 0x1f4);
    }, 'fail': function (g0x) {
      console[p[20482]](p[49199]), console[p[20482]](g0x), setTimeout(function () {
        window['$aH3VQ5']();
      }, 0x1f4);
    } });ei9yob && ei9yob[p[49200]](af4p37 => {});
}, window['$aHQ5V3'] = function () {
  console[p[20482]](p[49201]);var wv2xr = wx[p[49195]]({ 'name': p[49202], 'success': function (eyi9bo) {
      console[p[20482]](p[49203]), console[p[20482]](eyi9bo), eyi9bo && eyi9bo[p[45533]] == p[49198] ? (window['$aQ3V'] = !![], window['$aV3Q5'](), window['$aVQ53']()) : setTimeout(function () {
        window['$aHQ5V3']();
      }, 0x1f4);
    }, 'fail': function ($80h6) {
      console[p[20482]](p[49204]), console[p[20482]]($80h6), setTimeout(function () {
        window['$aHQ5V3']();
      }, 0x1f4);
    } });wv2xr && wv2xr[p[49200]](fp74a3 => {});
}, window[p[49205]] = function () {
  window['$aH3V5Q'](window[p[49180]], p[49206]) >= 0x0 ? (console[p[20482]](p[49207] + window[p[49180]] + p[49208]), window['$aQ5'](), window['$aH3VQ5'](), window['$aHQ5V3']()) : (window['$aQV5'](p[49209], window[p[49180]]), wx[p[49188]]({ 'title': p[26395], 'content': p[49210] }));
}, window[p[49171]] = '', wx[p[49211]]({ 'success'(ke$6) {
    window[p[49171]] = p[49212] + ke$6[p[49213]] + p[49214] + ke$6[p[49215]] + p[49216] + ke$6[p[24741]] + p[49217] + ke$6[p[20475]] + p[49218] + ke$6[p[45319]] + p[49219] + ke$6[p[49180]] + p[49220] + ke$6[p[29350]], console[p[20482]](window[p[49171]]), console[p[20482]](p[49221] + ke$6[p[49222]] + p[49223] + ke$6[p[49224]] + p[49225] + ke$6[p[49226]] + p[49227] + ke$6[p[49228]] + p[49229] + ke$6[p[49230]] + p[49231] + ke$6[p[49232]] + p[49233] + (ke$6[p[49234]] ? ke$6[p[49234]][p[20323]] + ',' + ke$6[p[49234]][p[21216]] + ',' + ke$6[p[49234]][p[21218]] + ',' + ke$6[p[49234]][p[21217]] : ''));var o9eiyb = ke$6[p[20475]] ? ke$6[p[20475]][p[32396]]() : '',
        pan4rw = ke$6[p[49215]] ? ke$6[p[49215]][p[32396]]()[p[24728]]('\x20', '') : '';window['$aQV'][p[21074]] = o9eiyb[p[20115]](p[49235]) != -0x1, window['$aQV'][p[31375]] = o9eiyb[p[20115]](p[49060]) != -0x1, window['$aQV'][p[49236]] = o9eiyb[p[20115]](p[49235]) != -0x1 || o9eiyb[p[20115]](p[49060]) != -0x1, window['$aQV'][p[45055]] = o9eiyb[p[20115]](p[49061]) != -0x1 || o9eiyb[p[20115]](p[49237]) != -0x1, window['$aQV'][p[49238]] = ke$6[p[45319]] ? ke$6[p[45319]][p[32396]]() : '', window['$aQV']['$aH53VQ'] = ![], window['$aQV']['$aH5Q3V'] = 0x2;if (o9eiyb[p[20115]](p[49060]) != -0x1) {
      if (ke$6[p[29350]] >= 0x18) window['$aQV']['$aH5Q3V'] = 0x3;else window['$aQV']['$aH5Q3V'] = 0x2;
    } else {
      if (o9eiyb[p[20115]](p[49235]) != -0x1) {
        if (ke$6[p[29350]] && ke$6[p[29350]] >= 0x14) window['$aQV']['$aH5Q3V'] = 0x3;else {
          if (pan4rw[p[20115]](p[49239]) != -0x1 || pan4rw[p[20115]](p[49240]) != -0x1 || pan4rw[p[20115]](p[49241]) != -0x1 || pan4rw[p[20115]](p[49242]) != -0x1 || pan4rw[p[20115]](p[49243]) != -0x1) window['$aQV']['$aH5Q3V'] = 0x2;else window['$aQV']['$aH5Q3V'] = 0x3;
        }
      } else window['$aQV']['$aH5Q3V'] = 0x2;
    }console[p[20482]](p[49244] + window['$aQV']['$aH53VQ'] + p[49245] + window['$aQV']['$aH5Q3V']);
  } }), wx[p[49246]]({ 'success': function (xp2wr) {
    console[p[20482]](p[49247] + xp2wr[p[24646]] + p[49248] + xp2wr[p[49249]]);
  } }), wx[p[49250]]({ 'success': function (d5lms) {
    console[p[20482]](p[49251] + d5lms[p[49252]]);
  } }), wx[p[49253]]({ 'keepScreenOn': !![] }), wx[p[49254]](function (e$6iyk) {
  console[p[20482]](p[49251] + e$6iyk[p[49252]] + p[49255] + e$6iyk[p[49256]]);
}), wx[p[30885]](function (jtscf1) {
  window['$a35'] = jtscf1, window['$aV53'] && window['$a35'] && (console[p[20078]](p[49257] + window['$a35'][p[20776]]), window['$aV53'](window['$a35']), window['$a35'] = null);
}), window[p[49258]] = 0x0, window['$aHQ3V5'] = 0x0, window[p[49259]] = null, wx[p[49260]](function () {
  window['$aHQ3V5']++;var vxn2rw = Date[p[20083]]();(window[p[49258]] == 0x0 || vxn2rw - window[p[49258]] > 0x1d4c0) && (console[p[20096]](p[49261]), wx[p[31952]]());if (window['$aHQ3V5'] >= 0x2) {
    window['$aHQ3V5'] = 0x0, console[p[20125]](p[49262]), wx[p[49263]]('0', 0x1);if (window['$aQV'] && window['$aQV'][p[21074]]) window['$aQV5'](p[49264], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});