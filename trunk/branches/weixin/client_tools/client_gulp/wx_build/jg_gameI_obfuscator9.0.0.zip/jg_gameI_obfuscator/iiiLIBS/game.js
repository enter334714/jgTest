var Q = wx.$I;
require(Q[27546]);