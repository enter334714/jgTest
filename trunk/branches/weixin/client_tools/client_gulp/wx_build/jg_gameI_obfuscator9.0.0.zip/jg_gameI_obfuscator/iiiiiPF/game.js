var Q = wx.$I;
require('iiBF.js'), window[Q[27028]][Q[27029]][Q[27030]] = null, window['client_pb'] = require('iiiCLIENTPB.js'), window[Q[24197]] = window[Q[27028]][Q[24099]][Q[24100]](client_pb);