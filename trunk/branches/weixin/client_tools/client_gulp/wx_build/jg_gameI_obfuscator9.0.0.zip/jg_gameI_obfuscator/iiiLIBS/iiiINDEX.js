var Q = wx.$I;
import i_hdtu from '../iiiiSDK/iiiSDDK.js';window[Q[27651]] = { 'wxVersion': window[Q[547]][Q[27550]] }, window[Q[27652]] = ![], window['$iAT'] = 0x1, window[Q[27653]] = 0x1, window['$iQTA'] = !![], window[Q[27654]] = !![], window['$iVZQAT'] = '', window['$iTA'] = { 'base_cdn': Q[27655], 'cdn': Q[27655] }, $iTA[Q[27656]] = {}, $iTA[Q[23702]] = '0', $iTA[Q[4570]] = window[Q[27651]][Q[27657]], $iTA[Q[27624]] = '', $iTA['os'] = '1', $iTA[Q[27658]] = Q[27659], $iTA[Q[27660]] = Q[27661], $iTA[Q[27662]] = Q[27663], $iTA[Q[27664]] = Q[27665], $iTA[Q[27666]] = Q[27667], $iTA[Q[22814]] = '1', $iTA[Q[24071]] = '', $iTA[Q[24073]] = '', $iTA[Q[27668]] = 0x0, $iTA[Q[27669]] = {}, $iTA[Q[27670]] = parseInt($iTA[Q[22814]]), $iTA[Q[24069]] = $iTA[Q[22814]], $iTA[Q[24065]] = {}, $iTA['$iZT'] = Q[27671], $iTA[Q[27672]] = ![], $iTA[Q[11617]] = Q[27673], $iTA[Q[24045]] = Date[Q[83]](), $iTA[Q[11213]] = Q[27674], $iTA[Q[700]] = '_a', $iTA[Q[27675]] = 0x2, $iTA[Q[101]] = 0x7c1, $iTA[Q[27657]] = window[Q[27651]][Q[27657]], $iTA[Q[725]] = ![], $iTA[Q[501]] = ![], $iTA[Q[10882]] = ![], $iTA[Q[23704]] = ![], window['$iQAT'] = 0x5, window['$iQA'] = ![], window['$iAQ'] = ![], window['$iTQA'] = ![], window[Q[27676]] = ![], window[Q[27677]] = ![], window['$iTAQ'] = ![], window['$iQT'] = ![], window['$iTQ'] = ![], window['$iAQT'] = ![], window[Q[4048]] = function (s72rb) {
  console[Q[471]](Q[4048], s72rb), wx[Q[4845]]({}), wx[Q[27574]]({ 'title': Q[6237], 'content': s72rb, 'success'(fize) {
      if (fize[Q[27678]]) console[Q[471]](Q[27679]);else fize[Q[543]] && console[Q[471]](Q[27680]);
    } });
}, window['$iZQTA'] = function (_a$oz3) {
  console[Q[471]](Q[27681], _a$oz3), $iZTAQ(), wx[Q[27574]]({ 'title': Q[6237], 'content': _a$oz3, 'confirmText': Q[27682], 'cancelText': Q[17771], 'success'(yfez) {
      if (yfez[Q[27678]]) window['$iTZ']();else yfez[Q[543]] && (console[Q[471]](Q[27683]), wx[Q[24215]]({}));
    } });
}, window['$iAVT'] = function (ye8f) {
  console[Q[471]](Q[27684], ye8f), wx[Q[27574]]({ 'title': Q[6237], 'content': ye8f, 'confirmText': Q[24187], 'showCancel': ![], 'complete'(a9$3k_) {
      console[Q[471]](Q[27683]), wx[Q[24215]]({});
    } });
}, window['$iZQAT'] = ![], window['$iZTQA'] = function (htdswj) {
  window['$iZQAT'] = !![], wx[Q[4844]](htdswj);
}, window['$iZTAQ'] = function () {
  window['$iZQAT'] && (window['$iZQAT'] = ![], wx[Q[4845]]({}));
}, window['$iZAQT'] = function (e58f) {
  window[Q[27565]][Q[148]]['$iZAQT'](e58f);
}, window[Q[11532]] = function (dhwjst, dsjh) {
  i_hdtu[Q[11532]](dhwjst, function ($yio8) {
    $yio8 && $yio8[Q[11]] ? $yio8[Q[11]][Q[3985]] == 0x1 ? dsjh(!![]) : (dsjh(![]), console[Q[78]](Q[27685] + $yio8[Q[11]][Q[27686]])) : console[Q[471]](Q[11532], $yio8);
  });
}, window['$iZATQ'] = function (r2jtsh) {
  console[Q[471]](Q[27687], r2jtsh);
}, window['$iZTA'] = function (hjuwd) {}, window['$iZAT'] = function (dthjws, hjdu, gey5x) {}, window['$iZA'] = function (_$zi8o) {
  console[Q[471]](Q[27688], _$zi8o), window[Q[27565]][Q[148]][Q[27689]](), window[Q[27565]][Q[148]][Q[27690]](), window[Q[27565]][Q[148]][Q[27691]]();
}, window['$iAZ'] = function (n7cvbq) {
  console[Q[471]](Q[27692]), window['$iZQTA'](Q[27692]), $iZT(n7cvbq ? n7cvbq : Q[27693]);
}, window['$iTZA'] = function (swjhrt) {
  var juwhdt = JSON[Q[517]](swjhrt);juwhdt[Q[27694]] = window[Q[547]][Q[27550]], juwhdt[Q[27695]] = window['$iTA'][Q[24065]] ? window['$iTA'][Q[24065]][Q[11053]] : 0x0, juwhdt[Q[27557]] = window[Q[27557]];var js2htr = JSON[Q[4367]](juwhdt);console[Q[125]](Q[27696] + js2htr), $iZT(js2htr);
}, window['$iTAZ'] = function (_93$ao) {
  var l04mk9 = { 'id': window['$iTA'][Q[27555]], 'role': window['$iTA'][Q[4499]], 'level': window['$iTA'][Q[27556]], 'user': window['$iTA'][Q[24070]], 'version': window['$iTA'][Q[101]], 'cdn': window['$iTA'][Q[4379]], 'pkgName': window['$iTA'][Q[24071]], 'gamever': window[Q[547]][Q[27550]], 'serverid': window['$iTA'][Q[24065]] ? window['$iTA'][Q[24065]][Q[11053]] : 0x0, 'systemInfo': window[Q[27557]], 'error': _93$ao },
      hts7 = JSON[Q[4367]](l04mk9);console[Q[96]](Q[27697] + hts7), window['$iZT'](hts7);
}, window['$iZT'] = function (egf5p) {
  if (window['$iTA'][Q[27625]] == Q[27414]) return;var hdwuj = $iTA['$iZT'] + Q[27698] + $iTA[Q[24070]];wx[Q[466]]({ 'url': hdwuj, 'method': Q[27420], 'data': egf5p, 'header': { 'content-type': Q[27699], 'cache-control': Q[27700] }, 'success': function (qgp) {
      DEBUG && console[Q[471]](Q[27701], hdwuj, egf5p, qgp);
    }, 'fail': function (_k0a) {
      DEBUG && console[Q[471]](Q[27701], hdwuj, egf5p, _k0a);
    }, 'complete': function () {} });
}, window[Q[27702]] = function () {
  function v2cnb() {
    return ((0x1 + Math[Q[119]]()) * 0x10000 | 0x0)[Q[272]](0x10)[Q[489]](0x1);
  }return v2cnb() + v2cnb() + '-' + v2cnb() + '-' + v2cnb() + '-' + v2cnb() + '+' + v2cnb() + v2cnb() + v2cnb();
}, window['$iTZ'] = function () {
  console[Q[471]](Q[27703]);var bv1n6q = i_hdtu[Q[27704]]();$iTA[Q[24069]] = bv1n6q[Q[27705]], $iTA[Q[27670]] = bv1n6q[Q[27705]], $iTA[Q[22814]] = bv1n6q[Q[27705]], $iTA[Q[24071]] = bv1n6q[Q[27706]];var vb1q6 = { 'game_ver': $iTA[Q[4570]] };$iTA[Q[24073]] = this[Q[27702]](), $iZTQA({ 'title': Q[27707] }), i_hdtu[Q[364]](vb1q6, this['$iAZT'][Q[74]](this));
}, window['$iAZT'] = function (xefy5g) {
  var o$a9_ = xefy5g[Q[27708]];console[Q[471]](Q[27709] + o$a9_ + Q[27710] + (o$a9_ == 0x1) + Q[27711] + xefy5g[Q[27550]] + Q[27712] + window[Q[27651]][Q[27657]]);if (!xefy5g[Q[27550]] || window['$iVQATZ'](window[Q[27651]][Q[27657]], xefy5g[Q[27550]]) < 0x0) console[Q[471]](Q[27713]), $iTA[Q[27660]] = Q[27714], $iTA[Q[27662]] = Q[27715], $iTA[Q[27664]] = Q[27716], $iTA[Q[4379]] = Q[27717], $iTA[Q[23701]] = Q[27718], $iTA[Q[27719]] = 'wd', $iTA[Q[725]] = ![];else window['$iVQATZ'](window[Q[27651]][Q[27657]], xefy5g[Q[27550]]) == 0x0 ? (console[Q[471]](Q[27720]), $iTA[Q[27660]] = Q[27661], $iTA[Q[27662]] = Q[27663], $iTA[Q[27664]] = Q[27665], $iTA[Q[4379]] = Q[27721], $iTA[Q[23701]] = Q[27718], $iTA[Q[27719]] = Q[27722], $iTA[Q[725]] = !![]) : (console[Q[471]](Q[27723]), $iTA[Q[27660]] = Q[27661], $iTA[Q[27662]] = Q[27663], $iTA[Q[27664]] = Q[27665], $iTA[Q[4379]] = Q[27721], $iTA[Q[23701]] = Q[27718], $iTA[Q[27719]] = Q[27722], $iTA[Q[725]] = ![]);$iTA[Q[27668]] = config[Q[27048]] ? config[Q[27048]] : 0x0, this['$iQTZA'](), this['$iQTAZ'](), $iZTQA({ 'title': Q[27724] }), i_hdtu[Q[27491]](this['$iATZ'][Q[74]](this));
}, window['$iATZ'] = function (r2sjht, b7nvc) {
  $iZTQA({ 'title': Q[27725] });if (r2sjht === 0x0 && b7nvc && b7nvc[Q[27139]]) {
    $iTA[Q[27726]] = b7nvc[Q[27139]];var _03a = this;sendApi($iTA[Q[27660]], Q[27727], { 'platform': $iTA[Q[27658]], 'partner_id': $iTA[Q[22814]], 'token': b7nvc[Q[27139]], 'game_pkg': $iTA[Q[24071]], 'deviceId': $iTA[Q[24073]], 'scene': Q[27728] + $iTA[Q[27668]] }, this['$iQZTA'][Q[74]](this), $iQAT, $iAZ);
  } else $iZT(JSON[Q[4367]]({ 'account': $iTA[Q[24070]], 'pkgName': $iTA[Q[24071]], 'error': Q[27729], 'stack': JSON[Q[4367]]({ 'status': r2sjht, 'data': b7nvc }) })), window['$iZQTA'](Q[27730] + (b7nvc && b7nvc[Q[24236]] ? '，' + b7nvc[Q[24236]] : ''));
}, window['$iQZTA'] = function (_i8$oz) {
  if (!_i8$oz) {
    window['$iZQTA'](Q[27731]);return;
  }if (_i8$oz[Q[3985]] != Q[9575]) {
    window['$iZQTA'](Q[27732] + _i8$oz[Q[3985]]);return;
  }$iTA[Q[22813]] = String(_i8$oz[Q[24070]]), $iTA[Q[24070]] = String(_i8$oz[Q[24070]]), $iTA[Q[24043]] = String(_i8$oz[Q[24043]]), $iTA[Q[24069]] = String(_i8$oz[Q[24043]]), $iTA[Q[24072]] = String(_i8$oz[Q[24072]]), $iTA[Q[27733]] = String(_i8$oz[Q[11036]]), $iTA[Q[27734]] = String(_i8$oz[Q[838]]), $iTA[Q[11036]] = '';var v1xq6p = this;$iZTQA({ 'title': Q[27735] }), sendApi($iTA[Q[27660]], Q[27736], { 'partner_id': $iTA[Q[22814]], 'uid': $iTA[Q[24070]], 'version': $iTA[Q[4570]], 'game_pkg': $iTA[Q[24071]], 'device': $iTA[Q[24073]] }, v1xq6p['$iQZAT'][Q[74]](v1xq6p), $iQAT, $iAZ);
}, window['$iQZAT'] = function (km930) {
  if (!km930) {
    window['$iZQTA'](Q[27737]);return;
  }if (km930[Q[3985]] != Q[9575]) {
    window['$iZQTA'](Q[27738] + km930[Q[3985]]);return;
  }if (!km930[Q[11]] || km930[Q[11]][Q[13]] == 0x0) {
    window['$iZQTA'](Q[27739]);return;
  }$iTA[Q[618]] = km930[Q[27740]], $iTA[Q[24065]] = { 'server_id': String(km930[Q[11]][0x0][Q[11053]]), 'server_name': String(km930[Q[11]][0x0][Q[27741]]), 'entry_ip': km930[Q[11]][0x0][Q[24093]], 'entry_port': parseInt(km930[Q[11]][0x0][Q[24094]]), 'status': $iAZQT(km930[Q[11]][0x0]), 'start_time': km930[Q[11]][0x0][Q[27742]], 'cdn': $iTA[Q[4379]] }, this['$iVZQTA']();
}, window['$iVZQTA'] = function () {
  if ($iTA[Q[618]] == 0x1) {
    var k0m43 = $iTA[Q[24065]][Q[106]];if (k0m43 === -0x1 || k0m43 === 0x0) {
      window['$iZQTA'](k0m43 === -0x1 ? Q[27743] : Q[27744]);return;
    }$iAZTQ(0x0, $iTA[Q[24065]][Q[11053]]), window[Q[27565]][Q[148]][Q[27745]]($iTA[Q[618]]);
  } else window[Q[27565]][Q[148]][Q[27746]](), $iZTAQ();window['$iTQ'] = !![], window['$iATZQ'](), window['$iATQZ']();
}, window['$iQTZA'] = function () {
  var y85efg = this;sendApi($iTA[Q[27660]], Q[27747], { 'game_pkg': $iTA[Q[24071]], 'version_name': $iTA[Q[27719]] }, function (chsr2) {
    if (!chsr2) {
      window['$iZQTA'](Q[27748]);return;
    }if (chsr2[Q[3985]] != Q[9575]) {
      window['$iZQTA'](Q[27749] + chsr2[Q[3985]]);return;
    }if (!chsr2[Q[11]] || !chsr2[Q[11]][Q[4570]]) {
      window['$iZQTA'](Q[27750] + (chsr2[Q[11]] && chsr2[Q[11]][Q[4570]]));return;
    }$iTA[Q[27751]] = chsr2[Q[11]][Q[27752]] && chsr2[Q[11]][Q[27752]][Q[13]] ? chsr2[Q[11]][Q[27752]] : $iTA[Q[27751]], $iTA[Q[4379]] = chsr2[Q[11]][Q[27752]] && chsr2[Q[11]][Q[27752]][Q[13]] ? chsr2[Q[11]][Q[27752]] : $iTA[Q[4379]], $iTA[Q[101]] = chsr2[Q[11]][Q[4570]] || $iTA[Q[101]], console[Q[78]](Q[24193] + $iTA[Q[101]] + Q[27753] + $iTA[Q[27719]]), window['$iTAQ'] = !![], window['$iATZQ'](), window['$iATQZ']();
  });
}, window[Q[27754]], window['$iQTAZ'] = function () {
  sendApi($iTA[Q[27660]], Q[27755], { 'game_pkg': $iTA[Q[24071]] }, $iQAZT);
}, window['$iQAZT'] = function (_$izoa) {
  if (_$izoa[Q[3985]] === Q[9575] && _$izoa[Q[11]]) {
    window[Q[27754]] = _$izoa[Q[11]];for (var rs72t in _$izoa[Q[11]]) {
      $iTA[rs72t] = _$izoa[Q[11]][rs72t];
    }
  } else console[Q[78]](Q[27756] + _$izoa[Q[3985]]);window['$iQT'] = !![], window['$iATQZ']();
}, window[Q[27757]] = function (_azo3, cvn6qb, y5xfeg, a$_oiz, v6nq1, pn6qv, _o3$a, izy8$, eoiyz8) {
  v6nq1 = String(v6nq1);var zo8$i = _o3$a,
      ozeyi = izy8$;$iTA[Q[27656]][v6nq1] = { 'productid': v6nq1, 'productname': zo8$i, 'productdesc': ozeyi, 'roleid': _azo3, 'rolename': cvn6qb, 'rolelevel': y5xfeg, 'price': pn6qv, 'callback': eoiyz8 }, sendApi($iTA[Q[27664]], Q[27758], { 'game_pkg': $iTA[Q[24071]], 'server_id': $iTA[Q[24065]][Q[11053]], 'server_name': $iTA[Q[24065]][Q[27741]], 'level': y5xfeg, 'uid': $iTA[Q[24070]], 'role_id': _azo3, 'role_name': cvn6qb, 'product_id': v6nq1, 'product_name': zo8$i, 'product_desc': ozeyi, 'money': pn6qv, 'partner_id': $iTA[Q[22814]] }, toPayCallBack, $iQAT, $iAZ);
}, window[Q[27759]] = function (g5f1p) {
  if (g5f1p) {
    if (g5f1p[Q[27760]] === 0xc8 || g5f1p[Q[3985]] == Q[9575]) {
      var q7nvbc = $iTA[Q[27656]][String(g5f1p[Q[27761]])];if (q7nvbc[Q[332]]) q7nvbc[Q[332]](g5f1p[Q[27761]], g5f1p[Q[27762]], -0x1);i_hdtu[Q[27522]]({ 'cpbill': g5f1p[Q[27762]], 'productid': g5f1p[Q[27761]], 'productname': q7nvbc[Q[27763]], 'productdesc': q7nvbc[Q[27764]], 'serverid': $iTA[Q[24065]][Q[11053]], 'servername': $iTA[Q[24065]][Q[27741]], 'roleid': q7nvbc[Q[27765]], 'rolename': q7nvbc[Q[27766]], 'rolelevel': q7nvbc[Q[27767]], 'price': q7nvbc[Q[25583]], 'extension': JSON[Q[4367]]({ 'cp_order_id': g5f1p[Q[27762]] }) }, function (q16b, uthj) {
        q7nvbc[Q[332]] && q16b == 0x0 && q7nvbc[Q[332]](g5f1p[Q[27761]], g5f1p[Q[27762]], q16b);console[Q[78]](JSON[Q[4367]]({ 'type': Q[27768], 'status': q16b, 'data': g5f1p, 'role_name': q7nvbc[Q[27766]] }));if (q16b === 0x0) {} else {
          if (q16b === 0x1) {} else {
            if (q16b === 0x2) {}
          }
        }
      });
    } else alert(g5f1p[Q[78]]);
  }
}, window['$iQATZ'] = function () {}, window['$iZQA'] = function (thjuw, q1gxp, zi_8o, h2sc7r, oeyi8z) {
  i_hdtu[Q[27540]]($iTA[Q[24065]][Q[11053]], $iTA[Q[24065]][Q[27741]] || $iTA[Q[24065]][Q[11053]], thjuw, q1gxp, zi_8o), sendApi($iTA[Q[27660]], Q[27769], { 'game_pkg': $iTA[Q[24071]], 'server_id': $iTA[Q[24065]][Q[11053]], 'role_id': thjuw, 'uid': $iTA[Q[24070]], 'role_name': q1gxp, 'role_type': h2sc7r, 'level': zi_8o });
}, window['$iZAQ'] = function (n7bv, _3ak$9, hjs2t, vb6, k0a, csrh72, _zoi8$, $9ao, n27cbv, cbr7n) {
  $iTA[Q[27555]] = n7bv, $iTA[Q[4499]] = _3ak$9, $iTA[Q[27556]] = hjs2t, i_hdtu[Q[27541]]($iTA[Q[24065]][Q[11053]], $iTA[Q[24065]][Q[27741]] || $iTA[Q[24065]][Q[11053]], n7bv, _3ak$9, hjs2t), sendApi($iTA[Q[27660]], Q[27770], { 'game_pkg': $iTA[Q[24071]], 'server_id': $iTA[Q[24065]][Q[11053]], 'role_id': n7bv, 'uid': $iTA[Q[24070]], 'role_name': _3ak$9, 'role_type': vb6, 'level': hjs2t, 'evolution': k0a });
}, window['$iQZA'] = function (c7nvbq, ezi8f, pf51gx, n7vb2, x6pg, duthjw, io$8z_, _a3$9o, _ai$, fy8g5e) {
  $iTA[Q[27555]] = c7nvbq, $iTA[Q[4499]] = ezi8f, $iTA[Q[27556]] = pf51gx;
}, window['$iQAZ'] = function (_90ak3) {}, window['$iZQ'] = function (xf5yeg) {
  i_hdtu[Q[27504]](Q[27504], function (vnqp) {
    xf5yeg(vnqp);
  });
}, window[Q[23686]] = function () {
  i_hdtu[Q[23686]]();
}, window[Q[27771]] = function () {
  i_hdtu[Q[22720]]();
}, window['$iQZ'] = function (i_o$z) {
  window['$iAQZ'] = i_o$z, window['$iAQZ'] && window['$iAZQ'] && (console[Q[78]](Q[27645] + window['$iAZQ'][Q[763]]), window['$iAQZ'](window['$iAZQ']), window['$iAZQ'] = null);
}, window['$iTZQA'] = function (fiz8ey, gx1p56, gexyf, n7cqb) {
  window[Q[22]](Q[27772], { 'game_pkg': window['$iTA'][Q[24071]], 'role_id': gx1p56, 'server_id': gexyf }, n7cqb);
}, window['$iTZAQ'] = function (tr2s7, hrwt) {
  function xgf5y(uwhjd) {
    var oi8z_$ = [],
        hstr = [],
        xpeg5 = window[Q[547]][Q[27773]];for (var ie8f5 in xpeg5) {
      var m34k0 = Number(ie8f5);(!tr2s7 || !tr2s7[Q[13]] || tr2s7[Q[115]](m34k0) != -0x1) && (hstr[Q[29]](xpeg5[ie8f5]), oi8z_$[Q[29]]([m34k0, 0x3]));
    }window['$iVQATZ'](window[Q[27566]], Q[27774]) >= 0x0 ? (console[Q[471]](Q[27775]), i_hdtu[Q[27776]] && i_hdtu[Q[27776]](hstr, function (v7qnb) {
      console[Q[471]](Q[27777]), console[Q[471]](v7qnb);if (v7qnb && v7qnb[Q[24236]] == Q[27778]) for (var yef8iz in xpeg5) {
        if (v7qnb[xpeg5[yef8iz]] == Q[27779]) {
          var oyi$z = Number(yef8iz);for (var b7nc2r = 0x0; b7nc2r < oi8z_$[Q[13]]; b7nc2r++) {
            if (oi8z_$[b7nc2r][0x0] == oyi$z) {
              oi8z_$[b7nc2r][0x1] = 0x1;break;
            }
          }
        }
      }window['$iVQATZ'](window[Q[27566]], Q[27780]) >= 0x0 ? wx[Q[27781]]({ 'withSubscriptions': !![], 'success': function (b7cs2r) {
          var wshjd = b7cs2r[Q[27782]][Q[27783]];if (wshjd) {
            console[Q[471]](Q[27784]), console[Q[471]](wshjd);for (var fe58 in xpeg5) {
              if (wshjd[xpeg5[fe58]] == Q[27779]) {
                var $_iaz = Number(fe58);for (var ye5xf = 0x0; ye5xf < oi8z_$[Q[13]]; ye5xf++) {
                  if (oi8z_$[ye5xf][0x0] == $_iaz) {
                    oi8z_$[ye5xf][0x1] = 0x2;break;
                  }
                }
              }
            }console[Q[471]](oi8z_$), hrwt && hrwt(oi8z_$);
          } else console[Q[471]](Q[27785]), console[Q[471]](b7cs2r), console[Q[471]](oi8z_$), hrwt && hrwt(oi8z_$);
        }, 'fail': function () {
          console[Q[471]](Q[27786]), console[Q[471]](oi8z_$), hrwt && hrwt(oi8z_$);
        } }) : (console[Q[471]](Q[27787] + window[Q[27566]]), console[Q[471]](oi8z_$), hrwt && hrwt(oi8z_$));
    })) : (console[Q[471]](Q[27788] + window[Q[27566]]), console[Q[471]](oi8z_$), hrwt && hrwt(oi8z_$)), wx[Q[27789]](xgf5y);
  }wx[Q[27790]](xgf5y);
}, window['$iTQZA'] = { 'isSuccess': ![], 'level': Q[27791], 'isCharging': ![] }, window['$iTQAZ'] = function (yzei8o) {
  wx[Q[27633]]({ 'success': function (i$oz_8) {
      var ka_9$3 = window['$iTQZA'];ka_9$3[Q[27792]] = !![], ka_9$3[Q[4475]] = Number(i$oz_8[Q[4475]])[Q[4096]](0x0), ka_9$3[Q[27636]] = i$oz_8[Q[27636]], yzei8o && yzei8o(ka_9$3[Q[27792]], ka_9$3[Q[4475]], ka_9$3[Q[27636]]);
    }, 'fail': function (s2bc7r) {
      console[Q[471]](Q[27793], s2bc7r[Q[24236]]);var cnbq7v = window['$iTQZA'];yzei8o && yzei8o(cnbq7v[Q[27792]], cnbq7v[Q[4475]], cnbq7v[Q[27636]]);
    } });
}, window[Q[22]] = function (pq6, qv6bnc, i85fye, zo$i8, zoyie8, uh, ge5xpf, wjrh) {
  zo$i8 == undefined && (zo$i8 = 0x1);var z$iao_ = new XMLHttpRequest();z$iao_[Q[24259]] = function () {
    if (z$iao_[Q[62]] == 0x4) {
      if (z$iao_[Q[106]] == 0xc8 || z$iao_[Q[106]] == 0x12d) {
        var fyiz8 = z$iao_[Q[24260]];fyiz8 = JSON[Q[517]](z$iao_[Q[24260]]);if (!uh || uh(fyiz8, z$iao_, pq6)) {
          i85fye && i85fye(fyiz8);return;
        } else console[Q[78]](pq6), console[Q[125]](fyiz8);
      }zo$i8 - 0x1 > 0x0 ? setTimeout(function () {
        send(pq6, qv6bnc, i85fye, zo$i8 - 0x1, zoyie8, uh);
      }, 0x3e8) : zoyie8 && zoyie8(JSON[Q[4367]]({ 'account': $iTA[Q[24070]], 'pkgName': $iTA[Q[24071]], 'error': Q[27794], 'stack': JSON[Q[4367]]({ 'url': pq6, 'status': z$iao_[Q[106]], 'response': z$iao_[Q[24260]], 'responseType': z$iao_[Q[24264]] }) }));
    }
  }, z$iao_[Q[65]](ge5xpf || Q[23905], pq6), z$iao_[Q[24264]] = Q[4294], z$iao_[Q[27795]](Q[27796], wjrh || Q[27699]), z$iao_[Q[22]](qv6bnc);
}, window[Q[27797]] = function (qv1nb, $8iyoz, o8iyez, o8_z, o39_$, egfxp, dhtsj) {
  !o8iyez && (o8iyez = {});var oiz8ye = Math[Q[118]](Date[Q[83]]() / 0x3e8);o8iyez[Q[838]] = oiz8ye, o8iyez[Q[23824]] = $8iyoz;var rhs = Object[Q[264]](o8iyez)[Q[1066]](),
      l4k90 = '',
      z8$ = '';for (var wshdj = 0x0; wshdj < rhs[Q[13]]; wshdj++) {
    l4k90 = l4k90 + (wshdj == 0x0 ? '' : '&') + rhs[wshdj] + o8iyez[rhs[wshdj]], z8$ = z8$ + (wshdj == 0x0 ? '' : '&') + rhs[wshdj] + '=' + encodeURIComponent(o8iyez[rhs[wshdj]]);
  }l4k90 = l4k90 + $iTA[Q[27666]];var o8zy$ = Q[27798] + md5(l4k90);send(qv1nb + '?' + z8$ + (z8$ == '' ? '' : '&') + o8zy$, null, o8_z, o39_$, egfxp, dhtsj || function (k4m) {
    return k4m[Q[3985]] == Q[9575];
  }, null, Q[27421]);
}, window['$iTAZQ'] = function (eizoy8, rh2js) {
  var rh7t = 0x0;$iTA[Q[24065]] && (rh7t = $iTA[Q[24065]][Q[11053]]), sendApi($iTA[Q[27662]], Q[27799], { 'partnerId': $iTA[Q[22814]], 'gamePkg': $iTA[Q[24071]], 'logTime': Math[Q[118]](Date[Q[83]]() / 0x3e8), 'platformUid': $iTA[Q[24072]], 'type': eizoy8, 'serverId': rh7t }, null, 0x2, null, function () {
    return !![];
  });
}, window['$iTAQZ'] = function (q6nv1) {
  sendApi($iTA[Q[27660]], Q[27800], { 'partner_id': $iTA[Q[22814]], 'uid': $iTA[Q[24070]], 'version': $iTA[Q[4570]], 'game_pkg': $iTA[Q[24071]], 'device': $iTA[Q[24073]] }, $iZQT, $iQAT, $iAZ);
}, window['$iZQT'] = function (z_a$) {
  if (z_a$[Q[3985]] === Q[9575] && z_a$[Q[11]]) {
    z_a$[Q[11]][Q[5445]]({ 'id': -0x2, 'name': Q[27801] }), z_a$[Q[11]][Q[5445]]({ 'id': -0x1, 'name': Q[27802] }), $iTA[Q[27803]] = z_a$[Q[11]];if (window[Q[11666]]) window[Q[11666]][Q[27804]]();
  } else $iTA[Q[27805]] = ![], window['$iZQTA'](Q[27806] + z_a$[Q[3985]]);
}, window['$iZTQ'] = function (thdjuw) {
  sendApi($iTA[Q[27660]], Q[27807], { 'partner_id': $iTA[Q[22814]], 'uid': $iTA[Q[24070]], 'version': $iTA[Q[4570]], 'game_pkg': $iTA[Q[24071]], 'device': $iTA[Q[24073]] }, $iQZT, $iQAT, $iAZ);
}, window['$iQZT'] = function (v7bqnc) {
  $iTA[Q[27808]] = ![];if (v7bqnc[Q[3985]] === Q[9575] && v7bqnc[Q[11]]) {
    for (var ncqb6 = 0x0; ncqb6 < v7bqnc[Q[11]][Q[13]]; ncqb6++) {
      v7bqnc[Q[11]][ncqb6][Q[106]] = $iAZQT(v7bqnc[Q[11]][ncqb6]);
    }$iTA[Q[27669]][-0x1] = window[Q[27809]](v7bqnc[Q[11]]), window[Q[11666]][Q[27810]](-0x1);
  } else window['$iZQTA'](Q[27811] + v7bqnc[Q[3985]]);
}, window['$iQTZ'] = function (g61xp, z_io$8) {
  sendApi($iTA[Q[27660]], Q[27812], { 'partner_id': $iTA[Q[22814]], 'uid': $iTA[Q[24070]], 'version': $iTA[Q[4570]], 'game_pkg': $iTA[Q[24071]], 'device': $iTA[Q[24073]], 'server_group_id': z_io$8 }, $iTZQ, $iQAT, $iAZ);
}, window['$iTZQ'] = function (eyi8oz) {
  $iTA[Q[27808]] = ![];if (eyi8oz[Q[3985]] === Q[9575] && eyi8oz[Q[11]] && eyi8oz[Q[11]][Q[11]]) {
    var r2nc7 = eyi8oz[Q[11]][Q[27813]],
        b27cs = [];for (var b1 = 0x0; b1 < eyi8oz[Q[11]][Q[11]][Q[13]]; b1++) {
      eyi8oz[Q[11]][Q[11]][b1][Q[106]] = $iAZQT(eyi8oz[Q[11]][Q[11]][b1]), (b27cs[Q[13]] == 0x0 || eyi8oz[Q[11]][Q[11]][b1][Q[106]] != 0x0) && (b27cs[b27cs[Q[13]]] = eyi8oz[Q[11]][Q[11]][b1]);
    }$iTA[Q[27669]][r2nc7] = window[Q[27809]](b27cs), window[Q[11666]][Q[27810]](r2nc7);
  } else window['$iZQTA'](Q[27814] + eyi8oz[Q[3985]]);
}, window['$iVTQA'] = function (hwjsrt) {
  sendApi($iTA[Q[27660]], Q[27815], { 'partner_id': $iTA[Q[22814]], 'uid': $iTA[Q[24070]], 'version': $iTA[Q[4570]], 'game_pkg': $iTA[Q[24071]], 'device': $iTA[Q[24073]] }, reqServerRecommendCallBack, $iQAT, $iAZ);
}, window[Q[27816]] = function (k49l) {
  $iTA[Q[27808]] = ![];if (k49l[Q[3985]] === Q[9575] && k49l[Q[11]]) {
    for (var ze8if = 0x0; ze8if < k49l[Q[11]][Q[13]]; ze8if++) {
      k49l[Q[11]][ze8if][Q[106]] = $iAZQT(k49l[Q[11]][ze8if]);
    }$iTA[Q[27669]][-0x2] = window[Q[27809]](k49l[Q[11]]), window[Q[11666]][Q[27810]](-0x2);
  } else alert(Q[27817] + k49l[Q[3985]]);
}, window[Q[27809]] = function (vbcqn7) {
  if (!vbcqn7 && vbcqn7[Q[13]] <= 0x0) return vbcqn7;for (let wrh = 0x0; wrh < vbcqn7[Q[13]]; wrh++) {
    vbcqn7[wrh][Q[27818]] && vbcqn7[wrh][Q[27818]] == 0x1 && (vbcqn7[wrh][Q[27741]] += Q[27819]);
  }return vbcqn7;
}, window['$iTQZ'] = function (oyi8$, xvp) {
  oyi8$ = oyi8$ || $iTA[Q[24065]][Q[11053]], sendApi($iTA[Q[27660]], Q[27820], { 'type': '4', 'game_pkg': $iTA[Q[24071]], 'server_id': oyi8$ }, xvp);
}, window[Q[27821]] = function (i$8_oz, n16bqv, a093, pxf5g1) {
  a093 = a093 || $iTA[Q[24065]][Q[11053]], sendApi($iTA[Q[27660]], Q[27822], { 'type': i$8_oz, 'game_pkg': n16bqv, 'server_id': a093 }, pxf5g1);
}, window['$iAZQT'] = function (e5fxgp) {
  if (e5fxgp) {
    if (e5fxgp[Q[106]] == 0x1) {
      if (e5fxgp[Q[27823]] == 0x1) return 0x2;else return 0x1;
    } else return e5fxgp[Q[106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$iAZTQ'] = function (g5epxf, zai) {
  $iTA[Q[27824]] = { 'step': g5epxf, 'server_id': zai };var g1xf5 = this;$iZTQA({ 'title': Q[27825] }), sendApi($iTA[Q[27660]], Q[27826], { 'partner_id': $iTA[Q[22814]], 'uid': $iTA[Q[24070]], 'game_pkg': $iTA[Q[24071]], 'server_id': zai, 'platform': $iTA[Q[24043]], 'platform_uid': $iTA[Q[24072]], 'check_login_time': $iTA[Q[27734]], 'check_login_sign': $iTA[Q[27733]], 'version_name': $iTA[Q[27719]] }, $iAQZT, $iQAT, $iAZ, function (rbs7c) {
    return rbs7c[Q[3985]] == Q[9575] || rbs7c[Q[78]] == Q[27827] || rbs7c[Q[78]] == Q[27828];
  });
}, window['$iAQZT'] = function (x1qg) {
  var cqb6nv = this;if (x1qg[Q[3985]] === Q[9575] && x1qg[Q[11]]) {
    var sbrc72 = $iTA[Q[24065]];sbrc72[Q[27829]] = $iTA[Q[27670]], sbrc72[Q[11036]] = String(x1qg[Q[11]][Q[27830]]), sbrc72[Q[24045]] = parseInt(x1qg[Q[11]][Q[838]]);if (x1qg[Q[11]][Q[24044]]) sbrc72[Q[24044]] = parseInt(x1qg[Q[11]][Q[24044]]);else sbrc72[Q[24044]] = parseInt(x1qg[Q[11]][Q[11053]]);sbrc72[Q[27831]] = 0x0, sbrc72[Q[4379]] = $iTA[Q[27751]], sbrc72[Q[27832]] = x1qg[Q[11]][Q[27833]], sbrc72[Q[27834]] = x1qg[Q[11]][Q[27834]], console[Q[471]](Q[27835] + JSON[Q[4367]](sbrc72[Q[27834]])), $iTA[Q[618]] == 0x1 && sbrc72[Q[27834]] && sbrc72[Q[27834]][Q[27836]] == 0x1 && ($iTA[Q[27837]] = 0x1, window[Q[27565]][Q[148]]['$iVA']()), $iAQTZ();
  } else sendApi($iTA[Q[27660]], Q[27727], { 'platform': $iTA[Q[27658]], 'partner_id': $iTA[Q[22814]], 'token': $iTA[Q[27726]], 'game_pkg': $iTA[Q[24071]], 'deviceId': $iTA[Q[24073]], 'scene': Q[27728] + $iTA[Q[27668]] }, function (xyfge5) {
    if (xyfge5[Q[3985]] == Q[24293]) {
      window['$iZQTA'](Q[27732] + xyfge5[Q[3985]]);return;
    }$iTA[Q[27733]] = String(xyfge5[Q[11036]]), $iTA[Q[27734]] = String(xyfge5[Q[838]]), setTimeout(function () {
      $iAZTQ($iTA[Q[27824]][Q[6924]], $iTA[Q[27824]][Q[11053]]);
    }, 0x5dc);
  }, $iQAT, $iAZ, function (ye5fxg) {
    return ye5fxg[Q[3985]] == Q[9575] || ye5fxg[Q[3985]] == Q[24293];
  });
}, window['$iAQTZ'] = function () {
  ServerLoading[Q[148]][Q[27745]]($iTA[Q[618]]), window['$iQA'] = !![], window['$iATQZ']();
}, window['$iATZQ'] = function () {
  if (window['$iAQ'] && window['$iTQA'] && window[Q[27676]] && window[Q[27677]] && window['$iTAQ'] && window['$iTQ']) {
    if (!window[Q[27027]][Q[148]]) {
      console[Q[471]](Q[27838] + window[Q[27027]][Q[148]]);var b7v2nc = wx[Q[27839]](),
          jwdut = b7v2nc[Q[763]] ? b7v2nc[Q[763]] : 0x0,
          efiyz8 = { 'cdn': window['$iTA'][Q[4379]], 'spareCdn': window['$iTA'][Q[23701]], 'newRegister': window['$iTA'][Q[618]], 'wxPC': window['$iTA'][Q[23704]], 'wxIOS': window['$iTA'][Q[501]], 'wxAndroid': window['$iTA'][Q[10882]], 'wxParam': { 'limitLoad': window['$iTA']['$iVZTQA'], 'benchmarkLevel': window['$iTA']['$iVZTAQ'], 'wxFrom': window[Q[547]][Q[27048]] == Q[27840] ? 0x1 : 0x0, 'wxSDKVersion': window[Q[27566]] }, 'configType': window['$iTA'][Q[11213]], 'exposeType': window['$iTA'][Q[700]], 'scene': jwdut };new window[Q[27027]](efiyz8, window['$iTA'][Q[101]], window['$iVZQAT']);
    }
  }
}, window['$iATQZ'] = function () {
  if (window['$iAQ'] && window['$iTQA'] && window[Q[27676]] && window[Q[27677]] && window['$iTAQ'] && window['$iTQ'] && window['$iQA'] && window['$iQT']) {
    $iZTAQ();if (!$iAQT) {
      $iAQT = !![];if (!window[Q[27027]][Q[148]]) window['$iATZQ']();var qcbn7v = 0x0,
          oi_ = wx[Q[27841]]();oi_ && (window['$iTA'][Q[27622]] && (qcbn7v = oi_[Q[320]]), console[Q[78]](Q[27842] + oi_[Q[320]] + Q[27843] + oi_[Q[1200]] + Q[27844] + oi_[Q[1202]] + Q[27845] + oi_[Q[1201]] + Q[27846] + oi_[Q[176]] + Q[27847] + oi_[Q[177]]));var f85gey = {};for (const udtwjh in $iTA[Q[24065]]) {
        f85gey[udtwjh] = $iTA[Q[24065]][udtwjh];
      }var ka_3$9 = { 'channel': window['$iTA'][Q[24069]], 'account': window['$iTA'][Q[24070]], 'userId': window['$iTA'][Q[22813]], 'serverId': f85gey[Q[11053]], 'cdn': window['$iTA'][Q[4379]], 'data': window['$iTA'][Q[11]], 'package': window['$iTA'][Q[23702]], 'newRegister': window['$iTA'][Q[618]], 'pkgName': window['$iTA'][Q[24071]], 'partnerId': window['$iTA'][Q[22814]], 'platform_uid': window['$iTA'][Q[24072]], 'deviceId': window['$iTA'][Q[24073]], 'selectedServer': f85gey, 'configType': window['$iTA'][Q[11213]], 'exposeType': window['$iTA'][Q[700]], 'debugUsers': window['$iTA'][Q[11617]], 'wxMenuTop': qcbn7v, 'wxShield': window['$iTA'][Q[725]] };if (window[Q[27754]]) for (var yzfi in window[Q[27754]]) {
        ka_3$9[yzfi] = window[Q[27754]][yzfi];
      }window[Q[27027]][Q[148]]['$iQVAT'](ka_3$9);
    }
  } else console[Q[78]](Q[27848] + window['$iAQ'] + Q[27849] + window['$iTQA'] + Q[27850] + window[Q[27676]] + Q[27851] + window[Q[27677]] + Q[27852] + window['$iTAQ'] + Q[27853] + window['$iTQ'] + Q[27854] + window['$iQA'] + Q[27855] + window['$iQT']);
};