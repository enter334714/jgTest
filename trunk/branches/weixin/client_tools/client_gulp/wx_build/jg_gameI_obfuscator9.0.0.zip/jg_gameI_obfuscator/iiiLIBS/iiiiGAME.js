var Q = wx.$I;
console[Q[78]](Q[27547]), window[Q[27548]], wx[Q[27549]](function (z3o$_a) {
  if (z3o$_a) {
    if (z3o$_a[Q[4381]]) {
      var efi8z = window[Q[547]][Q[27550]][Q[4557]](new RegExp(/\./, 'g'), '_'),
          fyi8ze = z3o$_a[Q[4381]],
          h2trj = fyi8ze[Q[11463]](/(iiiiiiiii\/iiiiGAME.js:)[0-9]{1,60}(:)/g);if (h2trj) for (var izef = 0x0; izef < h2trj[Q[13]]; izef++) {
        if (h2trj[izef] && h2trj[izef][Q[13]] > 0x0) {
          var v16bnq = parseInt(h2trj[izef][Q[4557]](Q[27551], '')[Q[4557]](':', ''));fyi8ze = fyi8ze[Q[4557]](h2trj[izef], h2trj[izef][Q[4557]](':' + v16bnq + ':', ':' + (v16bnq - 0x2) + ':'));
        }
      }fyi8ze = fyi8ze[Q[4557]](new RegExp(Q[27552], 'g'), Q[27553] + efi8z + Q[24167]), fyi8ze = fyi8ze[Q[4557]](new RegExp(Q[27554], 'g'), Q[27553] + efi8z + Q[24167]), z3o$_a[Q[4381]] = fyi8ze;
    }var eg5fxy = { 'id': window['$iTA'][Q[27555]], 'role': window['$iTA'][Q[4499]], 'level': window['$iTA'][Q[27556]], 'user': window['$iTA'][Q[24070]], 'version': window['$iTA'][Q[101]], 'gamever': window[Q[547]][Q[27550]], 'cdn': window['$iTA'][Q[4379]], 'serverid': window['$iTA'][Q[24065]] ? window['$iTA'][Q[24065]][Q[11053]] : 0x0, 'systemInfo': window[Q[27557]], 'error': Q[27558], 'stack': z3o$_a ? z3o$_a[Q[4381]] : '' },
        stjdhw = JSON[Q[4367]](eg5fxy);console[Q[125]](Q[27559] + stjdhw), (!window[Q[27548]] || window[Q[27548]] != eg5fxy[Q[125]]) && (window[Q[27548]] = eg5fxy[Q[125]], window['$iZT'](eg5fxy));
  }
});import 'iiiMDFIVEMIN.js';import 'iiiZLIBS.js';window[Q[27560]] = require(Q[27561]);import 'iiiINDEX.js';import 'iiiLIBSMIN.js';import 'iiiWXMINI.js';import 'iiiINITMIN.js';console[Q[78]](Q[27562]), console[Q[78]](Q[27563]), $iZTQA({ 'title': Q[27564] });var i_a_3o9$ = { '$iVQZTA': !![] };new window[Q[27565]](i_a_3o9$), window[Q[27565]][Q[148]]['$iVQAZT']();if (window['$iVZAQT']) clearInterval(window['$iVZAQT']);window['$iVZAQT'] = null, window['$iVQATZ'] = function (x56gp1, fzi8ye) {
  if (!x56gp1 || !fzi8ye) return 0x0;x56gp1 = x56gp1[Q[15]]('.'), fzi8ye = fzi8ye[Q[15]]('.');const fp51x = Math[Q[840]](x56gp1[Q[13]], fzi8ye[Q[13]]);while (x56gp1[Q[13]] < fp51x) {
    x56gp1[Q[29]]('0');
  }while (fzi8ye[Q[13]] < fp51x) {
    fzi8ye[Q[29]]('0');
  }for (var ifyze8 = 0x0; ifyze8 < fp51x; ifyze8++) {
    const i8yzf = parseInt(x56gp1[ifyze8]),
          p1vnq6 = parseInt(fzi8ye[ifyze8]);if (i8yzf > p1vnq6) return 0x1;else {
      if (i8yzf < p1vnq6) return -0x1;
    }
  }return 0x0;
}, window[Q[27566]] = wx[Q[27567]]()[Q[27566]], console[Q[471]](Q[27568] + window[Q[27566]]);var i_hrj2 = wx[Q[27569]]();i_hrj2[Q[27570]](function (fgy85) {
  console[Q[471]](Q[27571] + fgy85[Q[27572]]);
}), i_hrj2[Q[27573]](function () {
  wx[Q[27574]]({ 'title': Q[27575], 'content': Q[27576], 'showCancel': ![], 'success': function (_9a3o) {
      i_hrj2[Q[27577]]();
    } });
}), i_hrj2[Q[27578]](function () {
  console[Q[471]](Q[27579]);
}), window['$iVTZQA'] = function () {
  console[Q[471]](Q[27580]);var chrs2 = wx[Q[27581]]({ 'name': Q[27582], 'success': function (rwjs) {
      console[Q[471]](Q[27583]), console[Q[471]](rwjs), rwjs && rwjs[Q[24236]] == Q[27584] ? (window['$iAQ'] = !![], window['$iATZQ'](), window['$iATQZ']()) : setTimeout(function () {
        window['$iVTZQA']();
      }, 0x1f4);
    }, 'fail': function (o$zi8y) {
      console[Q[471]](Q[27585]), console[Q[471]](o$zi8y), setTimeout(function () {
        window['$iVTZQA']();
      }, 0x1f4);
    } });chrs2 && chrs2[Q[27586]](sr => {});
}, window['$iVTQZA'] = function () {
  console[Q[471]](Q[27587]);var dwjhu = wx[Q[27581]]({ 'name': Q[27588], 'success': function (ze8iyo) {
      console[Q[471]](Q[27589]), console[Q[471]](ze8iyo), ze8iyo && ze8iyo[Q[24236]] == Q[27584] ? (window['$iTQA'] = !![], window['$iATZQ'](), window['$iATQZ']()) : setTimeout(function () {
        window['$iVTQZA']();
      }, 0x1f4);
    }, 'fail': function ($io_za) {
      console[Q[471]](Q[27590]), console[Q[471]]($io_za), setTimeout(function () {
        window['$iVTQZA']();
      }, 0x1f4);
    } });dwjhu && dwjhu[Q[27586]](hjdwu => {});
}, window[Q[27591]] = function () {
  window['$iVQATZ'](window[Q[27566]], Q[27592]) >= 0x0 ? (console[Q[471]](Q[27593] + window[Q[27566]] + Q[27594]), window['$iTZ'](), window['$iVTZQA'](), window['$iVTQZA']()) : (window['$iTAZ'](Q[27595] + window[Q[27566]]), wx[Q[27574]]({ 'title': Q[6237], 'content': Q[27596] }));
}, window[Q[27557]] = '', wx[Q[27597]]({ 'success'(vbcnq7) {
    window[Q[27557]] = Q[27598] + vbcnq7[Q[27599]] + Q[27600] + vbcnq7[Q[27601]] + Q[27602] + vbcnq7[Q[4570]] + Q[27603] + vbcnq7[Q[464]] + Q[27604] + vbcnq7[Q[24043]] + Q[27605] + vbcnq7[Q[27566]] + Q[27606] + vbcnq7[Q[8967]], console[Q[471]](window[Q[27557]]), console[Q[471]](Q[27607] + vbcnq7[Q[27608]] + Q[27609] + vbcnq7[Q[27610]] + Q[27611] + vbcnq7[Q[27612]] + Q[27613] + vbcnq7[Q[27614]] + Q[27615] + vbcnq7[Q[27616]] + Q[27617] + vbcnq7[Q[27618]] + Q[27619] + (vbcnq7[Q[27620]] ? vbcnq7[Q[27620]][Q[320]] + ',' + vbcnq7[Q[27620]][Q[1200]] + ',' + vbcnq7[Q[27620]][Q[1202]] + ',' + vbcnq7[Q[27620]][Q[1201]] : ''));var iy85fe = vbcnq7[Q[464]] ? vbcnq7[Q[464]][Q[11715]]() : '',
        hrcs2 = vbcnq7[Q[27601]] ? vbcnq7[Q[27601]][Q[11715]]()[Q[4557]]('\x20', '') : '';window['$iTA'][Q[501]] = iy85fe[Q[115]](Q[27621]) != -0x1, window['$iTA'][Q[10882]] = iy85fe[Q[115]](Q[27415]) != -0x1, window['$iTA'][Q[27622]] = iy85fe[Q[115]](Q[27621]) != -0x1 || iy85fe[Q[115]](Q[27415]) != -0x1, window['$iTA'][Q[23704]] = iy85fe[Q[115]](Q[27623]) != -0x1 || iy85fe[Q[115]](Q[27624]) != -0x1, window['$iTA'][Q[27625]] = vbcnq7[Q[24043]] ? vbcnq7[Q[24043]][Q[11715]]() : '', window['$iTA']['$iVZTQA'] = ![], window['$iTA']['$iVZTAQ'] = 0x2;if (iy85fe[Q[115]](Q[27415]) != -0x1) {
      if (vbcnq7[Q[8967]] >= 0x18) window['$iTA']['$iVZTAQ'] = 0x3;else window['$iTA']['$iVZTAQ'] = 0x2;
    } else {
      if (iy85fe[Q[115]](Q[27621]) != -0x1) {
        if (vbcnq7[Q[8967]] && vbcnq7[Q[8967]] >= 0x14) window['$iTA']['$iVZTAQ'] = 0x3;else {
          if (hrcs2[Q[115]](Q[27626]) != -0x1 || hrcs2[Q[115]](Q[27627]) != -0x1 || hrcs2[Q[115]](Q[27628]) != -0x1 || hrcs2[Q[115]](Q[27629]) != -0x1 || hrcs2[Q[115]](Q[27630]) != -0x1) window['$iTA']['$iVZTAQ'] = 0x2;else window['$iTA']['$iVZTAQ'] = 0x3;
        }
      } else window['$iTA']['$iVZTAQ'] = 0x2;
    }console[Q[471]](Q[27631] + window['$iTA']['$iVZTQA'] + Q[27632] + window['$iTA']['$iVZTAQ']);
  } }), wx[Q[27633]]({ 'success': function (pfxge5) {
    console[Q[471]](Q[27634] + pfxge5[Q[4475]] + Q[27635] + pfxge5[Q[27636]]);
  } }), wx[Q[27637]]({ 'success': function (s2c7h) {
    console[Q[471]](Q[27638] + s2c7h[Q[27639]]);
  } }), wx[Q[27640]]({ 'keepScreenOn': !![] }), wx[Q[27641]](function (m094) {
  console[Q[471]](Q[27638] + m094[Q[27639]] + Q[27642] + m094[Q[27643]]);
}), wx[Q[27644]](function (yzf8e) {
  window['$iAZQ'] = yzf8e, window['$iAQZ'] && window['$iAZQ'] && (console[Q[78]](Q[27645] + window['$iAZQ'][Q[763]]), window['$iAQZ'](window['$iAZQ']), window['$iAZQ'] = null);
}), window['$iVTAZQ'] = 0x0, window[Q[27646]] = null, wx[Q[27647]](function () {
  window['$iVTAZQ']++, wx[Q[11267]]();if (window['$iVTAZQ'] >= 0x2) {
    window['$iVTAZQ'] = 0x0, console[Q[125]](Q[27648]), wx[Q[27649]]('0', 0x1);if (window['$iTA'] && window['$iTA'][Q[501]]) window['$iTAZ'](Q[27650]);if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});