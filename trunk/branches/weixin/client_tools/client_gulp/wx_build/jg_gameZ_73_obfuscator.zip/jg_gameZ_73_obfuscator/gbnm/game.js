var z1 = wx.Z$;
import 'Z_73main.js';