var z1 = wx.Z$;
var sdk_conf = {
  game_id: z1[37541],
  game_pkg: z1[37542],
  partner_id: z1[37543],
  partner_label: z1[37544],
  game_ver: z1[37545],
  is_auth: false, //授权登录
  partner_zsy_game: z1[37546],
  partner_zsy_channel: z1[37547],
  partner_zsy_subChannel: z1[37547]
};
window.config = sdk_conf;
module.exports = sdk_conf;