var z1 = wx.Z$;
import _yit_ from '../jzzn/a7xfj.js';
window[z1[28036]] = { 'wxVersion': window[z1[620]][z1[37811]] }, window[z1[37812]] = ![], window[z1[37813]] = 0x1, window[z1[37814]] = 0x1, window[z1[37815]] = !![], window[z1[37816]] = !![], window[z1[37817]] = '', window[z1[37818]] = !![], window[z1[4757]] = {
    'base_cdn': z1[37819],
    'cdn': z1[37819]
}, _s5O[z1[37820]] = {}, _s5O[z1[28099]] = '0', _s5O[z1[5591]] = window[z1[28036]][z1[37673]], _s5O[z1[37821]] = '', _s5O['os'] = '1', _s5O[z1[37822]] = z1[37823], _s5O[z1[37824]] = z1[37825], _s5O[z1[37826]] = z1[37827], _s5O[z1[37828]] = z1[37829], _s5O[z1[37830]] = z1[37831], _s5O[z1[13260]] = '1', _s5O[z1[28476]] = '', _s5O[z1[28478]] = '', _s5O[z1[37832]] = 0x0, _s5O[z1[37728]] = {}, _s5O[z1[37833]] = parseInt(_s5O[z1[13260]]), _s5O[z1[13269]] = _s5O[z1[13260]], _s5O[z1[28470]] = {}, _s5O[z1[37834]] = z1[37835], _s5O[z1[37836]] = ![], _s5O[z1[13406]] = z1[37837], _s5O[z1[28430]] = Date[z1[87]](), _s5O[z1[4756]] = z1[37838], _s5O[z1[810]] = '_a', _s5O[z1[28625]] = '', _s5O[z1[37664]] = 0x2, _s5O[z1[110]] = 0x7c1, _s5O[z1[37673]] = window[z1[28036]][z1[37673]], _s5O[z1[832]] = ![], _s5O[z1[1190]] = ![], _s5O[z1[12059]] = ![], _s5O[z1[28101]] = ![], window[z1[37839]] = 0x5, window[z1[37840]] = ![], window[z1[37841]] = ![], window[z1[37842]] = ![], window[z1[37773]] = ![], window[z1[37785]] = ![], window[z1[37843]] = ![], window[z1[37844]] = ![], window[z1[37845]] = ![], window[z1[37846]] = ![], window[z1[37777]] = null, window[z1[714]] = function (h9n) {
    console[z1[544]](z1[714], h9n), wx[z1[5101]]({}), wx[z1[37847]]({
        'title': z1[6350],
        'content': h9n,
        'success'(zhn5k9) {
            if (zhn5k9[z1[37848]]) console[z1[544]](z1[37849]);else zhn5k9[z1[616]] && console[z1[544]](z1[37850]);
        }
    });
}, window[z1[37851]] = function (kn95zh) {
    console[z1[544]](z1[37852], kn95zh), _sW5OQ(), wx[z1[37847]]({
        'title': z1[6350],
        'content': kn95zh,
        'confirmText': z1[37853],
        'cancelText': z1[20543],
        'success'(k5hzn9) {
            if (k5hzn9[z1[37848]]) window[z1[37854]]();else k5hzn9[z1[616]] && (console[z1[544]](z1[37855]), wx[z1[28073]]({}));
        }
    });
}, window[z1[37856]] = function (ip_oa) {
    console[z1[544]](z1[37856], ip_oa), wx[z1[37847]]({
        'title': z1[6350],
        'content': ip_oa,
        'confirmText': z1[28609],
        'showCancel': ![],
        'complete'($w03) {
            console[z1[544]](z1[37855]), wx[z1[28073]]({});
        }
    });
}, window[z1[37857]] = ![], window[z1[37858]] = function (p_oai) {
    window[z1[37857]] = !![], wx[z1[5100]](p_oai);
}, window[z1[37859]] = function () {
    window[z1[37857]] && (window[z1[37857]] = ![], wx[z1[5101]]({}));
}, window[z1[37770]] = function (x7s6) {
    window[z1[37809]][z1[167]][z1[37770]](x7s6);
}, window[z1[13276]] = function (_tcaml, lkfh5g) {
    _yit_[z1[13276]](_tcaml, function (pcmat) {
        pcmat && pcmat[z1[11]] ? pcmat[z1[11]][z1[1439]] == 0x1 ? lkfh5g(!![]) : (lkfh5g(![]), console[z1[82]](z1[37860] + pcmat[z1[11]][z1[37861]])) : console[z1[544]](z1[13276], pcmat);
    });
}, window[z1[37862]] = function (rw$203) {
    console[z1[544]](z1[37863], rw$203);
}, window[z1[37668]] = function (sx6yd) {}, window[z1[37669]] = function (cpa_o, ftg_l, xy7ds6) {}, window[z1[37864]] = function (gmftlh) {
    console[z1[544]](z1[37865], gmftlh), window[z1[37809]][z1[167]][z1[37666]](), window[z1[37809]][z1[167]][z1[37667]](), window[z1[37809]][z1[167]][z1[37676]](), window[z1[37866]]();
}, window[z1[37867]] = function (y7d6sj) {
    window[z1[37868]](0xe, z1[37869] + y7d6sj), window[z1[37851]](z1[37870]);
    var tac = {
        'id': window[z1[4757]][z1[37871]],
        'role': window[z1[4757]][z1[4890]],
        'level': window[z1[4757]][z1[37872]],
        'account': window[z1[4757]][z1[28474]],
        'version': window[z1[4757]][z1[110]],
        'cdn': window[z1[4757]][z1[4754]],
        'pkgName': window[z1[4757]][z1[28476]],
        'gamever': window[z1[620]][z1[37811]],
        'serverid': window[z1[4757]][z1[28470]] ? window[z1[4757]][z1[28470]][z1[12235]] : 0x0,
        'systemInfo': window[z1[37873]],
        'error': z1[37874],
        'stack': y7d6sj ? y7d6sj : z1[37870]
    },
        $1r2x0 = JSON[z1[4740]](tac);
    console[z1[144]](z1[37875] + $1r2x0), window[z1[37834]]($1r2x0);
}, window[z1[37868]] = function (sd7yx, dsy6) {
    sendApi(_s5O[z1[37826]], z1[37876], {
        'game_pkg': _s5O[z1[28476]],
        'partner_id': _s5O[z1[13260]],
        'server_id': _s5O[z1[28470]] && _s5O[z1[28470]][z1[12235]] > 0x0 ? _s5O[z1[28470]][z1[12235]] : 0x0,
        'uid': _s5O[z1[28474]] > 0x0 ? _s5O[z1[28474]] : 0x0,
        'type': sd7yx,
        'info': dsy6
    });
}, window[z1[37877]] = function (tmlg_f) {
    var lkgf = JSON[z1[588]](tmlg_f);
    lkgf[z1[37878]] = window[z1[620]][z1[37811]], lkgf[z1[37879]] = window[z1[4757]][z1[28470]] ? window[z1[4757]][z1[28470]][z1[12235]] : 0x0, lkgf[z1[37873]] = window[z1[37873]];
    var ap_tcm = JSON[z1[4740]](lkgf);
    console[z1[144]](z1[37880] + ap_tcm), window[z1[37834]](ap_tcm);
}, window[z1[37881]] = function (gfht, o_acpi) {
    var qjeu8b = {
        'id': window[z1[4757]][z1[37871]],
        'role': window[z1[4757]][z1[4890]],
        'level': window[z1[4757]][z1[37872]],
        'account': window[z1[4757]][z1[28474]],
        'version': window[z1[4757]][z1[110]],
        'cdn': window[z1[4757]][z1[4754]],
        'pkgName': window[z1[4757]][z1[28476]],
        'gamever': window[z1[620]][z1[37811]],
        'serverid': window[z1[4757]][z1[28470]] ? window[z1[4757]][z1[28470]][z1[12235]] : 0x0,
        'systemInfo': window[z1[37873]],
        'error': gfht,
        'stack': o_acpi
    },
        es8q6j = JSON[z1[4740]](qjeu8b);
    console[z1[103]](z1[37882] + es8q6j), window[z1[37834]](es8q6j);
}, window[z1[37834]] = function (sd67) {
    if (window[z1[4757]][z1[37883]] == z1[37884]) return;
    var m_lcft = _s5O[z1[37834]] + z1[37885] + _s5O[z1[28474]];
    wx[z1[539]]({
        'url': m_lcft,
        'method': z1[37451],
        'data': sd67,
        'header': {
            'content-type': z1[37886],
            'cache-control': z1[28081]
        },
        'success': function (kz53n) {
            DEBUG && console[z1[544]](z1[37887], m_lcft, sd67, kz53n);
        },
        'fail': function (ftlm_g) {
            DEBUG && console[z1[544]](z1[37887], m_lcft, sd67, ftlm_g);
        },
        'complete': function () {}
    });
}, window[z1[37888]] = function () {
    function nfg5h() {
        return ((0x1 + Math[z1[131]]()) * 0x10000 | 0x0)[z1[297]](0x10)[z1[559]](0x1);
    }
    return nfg5h() + nfg5h() + '-' + nfg5h() + '-' + nfg5h() + '-' + nfg5h() + '+' + nfg5h() + nfg5h() + nfg5h();
}, window[z1[37854]] = function () {
    console[z1[544]](z1[37889]);
    var nk9z35 = _yit_[z1[35157]]();
    _s5O[z1[13269]] = nk9z35[z1[37890]], _s5O[z1[37833]] = nk9z35[z1[37890]], _s5O[z1[13260]] = nk9z35[z1[37890]], _s5O[z1[28476]] = nk9z35[z1[37765]];
    var _mtca = { 'game_ver': _s5O[z1[5591]] };
    _s5O[z1[28478]] = this[z1[37888]](), _sW5QO({ 'title': z1[37891] }), _yit_[z1[425]](_mtca, this[z1[37892]][z1[78]](this));
}, window[z1[37892]] = function (_amtp) {
    var x2r7d1 = _amtp[z1[37778]];
    sdkInitRes = _amtp, console[z1[544]](z1[37893] + x2r7d1 + z1[37894] + (x2r7d1 == 0x1) + z1[37895] + _amtp[z1[37811]] + z1[37896] + window[z1[28036]][z1[37673]] + z1[37897] + _amtp[z1[4758]]);
    if (!_amtp[z1[37811]] || window[z1[37898]](window[z1[28036]][z1[37673]], _amtp[z1[37811]]) < 0x0) console[z1[544]](z1[37899]), _s5O[z1[37824]] = z1[37900], _s5O[z1[37826]] = z1[37901], _s5O[z1[37828]] = z1[37902], _s5O[z1[4754]] = z1[37903], _s5O[z1[28098]] = z1[37904], _s5O[z1[4758]] = _amtp[z1[4758]], _s5O[z1[832]] = ![];else window[z1[37898]](window[z1[28036]][z1[37673]], _amtp[z1[37811]]) == 0x0 ? (console[z1[544]](z1[37905]), _s5O[z1[37824]] = z1[37825], _s5O[z1[37826]] = z1[37827], _s5O[z1[37828]] = z1[37829], _s5O[z1[4754]] = z1[37819], _s5O[z1[28098]] = z1[37904], _s5O[z1[4758]] = z1[37906], _s5O[z1[832]] = !![]) : (console[z1[544]](z1[37907]), _s5O[z1[37824]] = z1[37825], _s5O[z1[37826]] = z1[37827], _s5O[z1[37828]] = z1[37829], _s5O[z1[4754]] = z1[37819], _s5O[z1[28098]] = z1[37904], _s5O[z1[4758]] = z1[37906], _s5O[z1[832]] = ![]);
    _s5O[z1[37832]] = config[z1[32705]] ? config[z1[32705]] : 0x0, this[z1[37908]](), this[z1[37909]](), window[z1[37910]] = 0x5, _sW5QO({ 'title': z1[37911] }), _yit_[z1[37446]](this[z1[37912]][z1[78]](this));
}, window[z1[37910]] = 0x5, window[z1[37912]] = function (lfmgt_, ye86s) {
    if (lfmgt_ == 0x0 && ye86s && ye86s[z1[37416]]) {
        _s5O[z1[37913]] = ye86s[z1[37416]], _s5O[z1[28623]] = ye86s[z1[28623]], _s5O[z1[28618]] = ye86s[z1[28618]], _s5O[z1[28624]] = ye86s[z1[28624]], _s5O[z1[28617]] = ye86s[z1[28617]];
        var d7ysx6 = this;
        _sW5QO({ 'title': z1[37914] }), sendApi(_s5O[z1[37824]], z1[37915], {
            'platform': _s5O[z1[37822]],
            'partner_id': _s5O[z1[13260]],
            'token': ye86s[z1[37416]],
            'game_pkg': _s5O[z1[28476]],
            'deviceId': _s5O[z1[28478]],
            'scene': z1[37916] + _s5O[z1[37832]]
        }, this[z1[37917]][z1[78]](this), _sQO5, _sOW);
    } else ye86s && ye86s[z1[28089]] && window[z1[37910]] > 0x0 && (ye86s[z1[28089]][z1[125]](z1[37918]) != -0x1 || ye86s[z1[28089]][z1[125]](z1[37919]) != -0x1 || ye86s[z1[28089]][z1[125]](z1[37920]) != -0x1 || ye86s[z1[28089]][z1[125]](z1[37921]) != -0x1 || ye86s[z1[28089]][z1[125]](z1[37922]) != -0x1 || ye86s[z1[28089]][z1[125]](z1[37923]) != -0x1) ? (window[z1[37910]]--, _yit_[z1[37446]](this[z1[37912]][z1[78]](this))) : (window[z1[37868]](0x1, z1[37924] + lfmgt_ + z1[37925] + (ye86s ? ye86s[z1[28089]] : '')), window[z1[37881]](z1[37926], JSON[z1[4740]]({
        'status': lfmgt_,
        'data': ye86s
    })), window[z1[37851]](z1[37927] + (ye86s && ye86s[z1[28089]] ? '，' + ye86s[z1[28089]] : '')));
}, window[z1[37917]] = function (amcpt) {
    if (!amcpt) {
        window[z1[37868]](0x2, z1[37928]), window[z1[37881]](z1[37929], z1[37930]), window[z1[37851]](z1[37931]);
        return;
    }
    if (amcpt[z1[1439]] != z1[10339]) {
        window[z1[37868]](0x2, z1[37932] + amcpt[z1[1439]]), window[z1[37881]](z1[37929], JSON[z1[4740]](amcpt)), window[z1[37851]](z1[37933] + amcpt[z1[1439]]);
        return;
    }
    if (amcpt[z1[37934]] == 0x1) {
        window[z1[37851]](z1[37935]);
        return;
    }
    _s5O[z1[13258]] = String(amcpt[z1[28474]]), _s5O[z1[28474]] = String(amcpt[z1[28474]]), _s5O[z1[28428]] = String(amcpt[z1[28428]]), _s5O[z1[13269]] = String(amcpt[z1[28428]]), _s5O[z1[28477]] = String(amcpt[z1[28477]]), _s5O[z1[37936]] = String(amcpt[z1[12218]]), _s5O[z1[37937]] = String(amcpt[z1[963]]), _s5O[z1[12218]] = '';
    var n9w5z3 = this;
    _sW5QO({ 'title': z1[37938] });
    var ac_o = localStorage[z1[542]](z1[37939] + _s5O[z1[28476]] + _s5O[z1[28474]]);
    if (ac_o && ac_o != '') {
        var qe8j = Number(ac_o);
        n9w5z3[z1[37940]](qe8j);
    } else n9w5z3[z1[37941]]();
}, window[z1[37941]] = function () {
    var _ipact = this;
    sendApi(_s5O[z1[37824]], z1[37942], {
        'partner_id': _s5O[z1[13260]],
        'uid': _s5O[z1[28474]],
        'version': _s5O[z1[5591]],
        'game_pkg': _s5O[z1[28476]],
        'device': _s5O[z1[28478]]
    }, _ipact[z1[37943]][z1[78]](_ipact), _sQO5, _sOW);
}, window[z1[37943]] = function (ipaco) {
    if (!ipaco) {
        window[z1[37868]](0x3, z1[37944]), window[z1[37851]](z1[37944]);
        return;
    }
    if (ipaco[z1[1439]] != z1[10339]) {
        window[z1[37868]](0x3, z1[37945] + ipaco[z1[1439]]), window[z1[37851]](z1[37945] + ipaco[z1[1439]]);
        return;
    }
    if (!ipaco[z1[11]] || ipaco[z1[11]][z1[13]] == 0x0) {
        window[z1[37868]](0x3, z1[37946]), window[z1[37851]](z1[37947]);
        return;
    }
    this[z1[37948]](ipaco);
}, window[z1[37940]] = function (pa_ico) {
    var eq8ubj = this;
    sendApi(_s5O[z1[37824]], z1[37949], {
        'server_id': pa_ico,
        'time': Date[z1[87]]() / 0x3e8
    }, eq8ubj[z1[37950]][z1[78]](eq8ubj), _sQO5, _sOW);
}, window[z1[37950]] = function (hn95z) {
    if (!hn95z) {
        window[z1[37868]](0x4, z1[37951]), this[z1[37941]]();
        return;
    }
    if (hn95z[z1[1439]] != z1[10339]) {
        window[z1[37868]](0x4, z1[37952] + hn95z[z1[1439]]), this[z1[37941]]();
        return;
    }
    if (!hn95z[z1[11]] || hn95z[z1[11]][z1[13]] == 0x0) {
        window[z1[37868]](0x4, z1[37953]), this[z1[37941]]();
        return;
    }
    this[z1[37948]](hn95z);
}, window[z1[37948]] = function (fknhg) {
    _s5O[z1[727]] = fknhg[z1[37954]] != undefined ? fknhg[z1[37954]] : 0x0, _s5O[z1[28470]] = {
        'server_id': String(fknhg[z1[11]][0x0][z1[12235]]),
        'server_name': String(fknhg[z1[11]][0x0][z1[28475]]),
        'entry_ip': fknhg[z1[11]][0x0][z1[28079]],
        'entry_port': parseInt(fknhg[z1[11]][0x0][z1[28498]]),
        'status': _s5QW(fknhg[z1[11]][0x0]),
        'start_time': fknhg[z1[11]][0x0][z1[37955]],
        'maintain_time': fknhg[z1[11]][0x0][z1[37695]] ? fknhg[z1[11]][0x0][z1[37695]] : '',
        'is_recommend': fknhg[z1[11]][0x0][z1[37691]],
        'cdn': _s5O[z1[4754]]
    }, this[z1[37956]](), window[z1[37809]] && window[z1[37809]][z1[167]][z1[37957]] && window[z1[37809]][z1[167]][z1[37957]](sdkInitRes[z1[37958]], sdkInitRes[z1[37959]], sdkInitRes[z1[37960]], sdkInitRes[z1[37961]], sdkInitRes[z1[37962]]);
}, window[z1[37956]] = function () {
    window[z1[37845]] = !![], window[z1[37963]]();
}, window[z1[37963]] = function () {
    if (window[z1[37845]] && window[z1[37844]]) {
        var ebjq86 = _s5O[z1[37719]] != undefined ? _s5O[z1[37719]] : 0x0,
            p_a = _s5O[z1[28617]] == undefined ? 0x0 : _s5O[z1[28617]],
            sedj6 = ebjq86 == 0x1 && p_a == 0x1 || ebjq86 == 0x2 && p_a != 0x1 || ebjq86 == 0x3;
        console[z1[82]](z1[37964] + _s5O[z1[727]] + z1[37965] + sedj6 + z1[37966] + _s5O[z1[28617]] + z1[37967] + _s5O[z1[37719]]);
        if (!sedj6 && _s5O[z1[727]] == 0x1) {
            var w20$1r = _s5O[z1[28470]][z1[116]];
            if (w20$1r === -0x1 || w20$1r === 0x0) {
                window[z1[37868]](0xf, z1[37968] + _s5O[z1[28470]]['id'] + z1[37969] + _s5O[z1[28470]][z1[116]]), window[z1[37851]](w20$1r === -0x1 ? z1[37970] : z1[37971]);
                return;
            }
            _sOWQ5(0x0, _s5O[z1[28470]][z1[12235]]), window[z1[37809]][z1[167]][z1[37786]](_s5O[z1[727]]);
        } else window[z1[37809]][z1[167]][z1[37782]]({
            'show': sdkInitRes[z1[37958]],
            'skinUrl': sdkInitRes[z1[37959]],
            'content': sdkInitRes[z1[37960]],
            'x': sdkInitRes[z1[37961]],
            'y': sdkInitRes[z1[37962]]
        }), _sW5OQ();
        window[z1[37972]](), window[z1[37774]](), window[z1[37775]]();
    }
}, window[z1[37908]] = function () {
    sendApi(_s5O[z1[37824]], z1[37973], {
        'game_pkg': _s5O[z1[28476]],
        'version_name': _s5O[z1[4758]]
    }, this[z1[37974]][z1[78]](this), _sQO5, _sOW);
}, window[z1[37974]] = function (r$01) {
    if (!r$01) {
        window[z1[37868]](0x5, z1[37975]), window[z1[37851]](z1[37975]);
        return;
    }
    if (r$01[z1[1439]] != z1[10339]) {
        window[z1[37868]](0x5, z1[37976] + r$01[z1[1439]]), window[z1[37851]](z1[37976] + r$01[z1[1439]]);
        return;
    }
    if (!r$01[z1[11]] || !r$01[z1[11]][z1[5591]]) {
        window[z1[37868]](0x5, z1[37977] + (r$01[z1[11]] && r$01[z1[11]][z1[5591]])), window[z1[37851]](z1[37977] + (r$01[z1[11]] && r$01[z1[11]][z1[5591]]));
        return;
    }
    r$01[z1[11]][z1[37978]] && r$01[z1[11]][z1[37978]][z1[13]] > 0xa && (_s5O[z1[37979]] = r$01[z1[11]][z1[37978]], _s5O[z1[4754]] = r$01[z1[11]][z1[37978]]), r$01[z1[11]][z1[5591]] && (_s5O[z1[110]] = r$01[z1[11]][z1[5591]]), console[z1[82]](z1[28620] + _s5O[z1[110]] + z1[37980] + _s5O[z1[4758]]), window[z1[37843]] = !![], window[z1[37774]](), window[z1[37775]]();
}, window[z1[37981]], window[z1[37909]] = function () {
    sendApi(_s5O[z1[37824]], z1[37982], { 'game_pkg': _s5O[z1[28476]] }, this[z1[37983]][z1[78]](this), _sQO5, _sOW);
}, window[z1[37983]] = function (vi4pa) {
    if (vi4pa && vi4pa[z1[1439]] === z1[10339] && vi4pa[z1[11]]) {
        window[z1[37981]] = vi4pa[z1[11]];
        for (var i_ca in vi4pa[z1[11]]) {
            _s5O[i_ca] = vi4pa[z1[11]][i_ca];
        }
    } else window[z1[37868]](0xb, z1[37984]), console[z1[82]](z1[37985] + vi4pa[z1[1439]]);
    window[z1[37844]] = !![], window[z1[37963]]();
}, window[z1[37972]] = function () {
    if (!window[z1[37845]] || !window[z1[37844]]) return;
    var a_tmpc = _s5O[z1[727]] == 0x1,
        sx7yd = _s5O[z1[832]],
        $0r23 = _s5O[z1[28339]] && _s5O[z1[28339]] > 0x0;
    if (sx7yd || a_tmpc && $0r23) {
        var o4pcia = _s5O[z1[28340]],
            nzw95 = o4pcia && o4pcia[z1[13]] == 0x9;
        nzw95 && (window[z1[31464]] = o4pcia);
        var _clt = _s5O[z1[28341]],
            $0rx2 = _clt && _clt[z1[15]]('#')[z1[13]] == 0x4;
        $0rx2 && (window[z1[31465]] = _clt);
    }
}, window[z1[37866]] = function () {
    window[z1[31464]] = null, window[z1[31465]] = null;
}, window[z1[37986]] = function (x21r, pi_tca, nhf5, $72xr1, tgfhl, j6esy8, dys6je, tcml_, lgmhtf, $xr17) {
    tgfhl = String(tgfhl);
    var jed6y = dys6je,
        cp_ao = tcml_;
    _s5O[z1[37820]][tgfhl] = {
        'productid': tgfhl,
        'productname': jed6y,
        'productdesc': cp_ao,
        'roleid': x21r,
        'rolename': pi_tca,
        'rolelevel': nhf5,
        'price': j6esy8,
        'callback': lgmhtf
    }, sendApi(_s5O[z1[37828]], z1[37987], {
        'game_pkg': _s5O[z1[28476]],
        'server_id': _s5O[z1[28470]][z1[12235]],
        'server_name': _s5O[z1[28470]][z1[28475]],
        'level': nhf5,
        'uid': _s5O[z1[28474]],
        'role_id': x21r,
        'role_name': pi_tca,
        'product_id': tgfhl,
        'product_name': jed6y,
        'product_desc': cp_ao,
        'money': j6esy8,
        'partner_id': _s5O[z1[13260]]
    }, toPayCallBack, _sQO5, _sOW);
}, window[z1[37988]] = function (lmthfg) {
    if (lmthfg && (lmthfg[z1[37989]] === 0xc8 || lmthfg[z1[1439]] == z1[10339])) {
        var hk5lf = _s5O[z1[37820]][String(lmthfg[z1[37990]])];
        if (hk5lf[z1[390]]) hk5lf[z1[390]](lmthfg[z1[37990]], lmthfg[z1[37991]], -0x1);
        _yit_[z1[37478]]({
            'cpbill': lmthfg[z1[37991]],
            'productid': lmthfg[z1[37990]],
            'productname': hk5lf[z1[37992]],
            'productdesc': hk5lf[z1[37993]],
            'serverid': _s5O[z1[28470]][z1[12235]],
            'servername': _s5O[z1[28470]][z1[28475]],
            'roleid': hk5lf[z1[13264]],
            'rolename': hk5lf[z1[13265]],
            'rolelevel': hk5lf[z1[37994]],
            'price': hk5lf[z1[30694]],
            'extension': JSON[z1[4740]]({ 'cp_order_id': lmthfg[z1[37991]] })
        }, function (kzn5h9, tgmhlf) {
            hk5lf[z1[390]] && kzn5h9 == 0x0 && hk5lf[z1[390]](lmthfg[z1[37990]], lmthfg[z1[37991]], kzn5h9);
            console[z1[82]](JSON[z1[4740]]({
                'type': z1[37995],
                'status': kzn5h9,
                'data': lmthfg,
                'role_name': hk5lf[z1[13265]]
            }));
            if (kzn5h9 === 0x0) {} else {
                if (kzn5h9 === 0x1) {} else {
                    if (kzn5h9 === 0x2) {}
                }
            }
        });
    } else {
        var cma_t = lmthfg ? z1[37996] + lmthfg[z1[37989]] + z1[37997] + lmthfg[z1[1439]] + z1[37998] + lmthfg[z1[82]] : z1[37999];
        window[z1[37868]](0xd, z1[38000] + cma_t), alert(cma_t);
    }
}, window[z1[38001]] = function () {}, window[z1[38002]] = function (glfthm, pci_ta, hl5kf, d1rx7, jdy6) {
    _yit_[z1[37535]](_s5O[z1[28470]][z1[12235]], _s5O[z1[28470]][z1[28475]] || _s5O[z1[28470]][z1[12235]], glfthm, pci_ta, hl5kf), sendApi(_s5O[z1[37824]], z1[38003], {
        'game_pkg': _s5O[z1[28476]],
        'server_id': _s5O[z1[28470]][z1[12235]],
        'role_id': glfthm,
        'uid': _s5O[z1[28474]],
        'role_name': pci_ta,
        'role_type': d1rx7,
        'level': hl5kf
    });
}, window[z1[38004]] = function (wn953, n093w, r71x2, mgltfh, x217, kgh5lf, xrd21, l_at, $w012r, ydjs6) {
    _s5O[z1[37871]] = wn953, _s5O[z1[4890]] = n093w, _s5O[z1[37872]] = r71x2, _yit_[z1[37536]](_s5O[z1[28470]][z1[12235]], _s5O[z1[28470]][z1[28475]] || _s5O[z1[28470]][z1[12235]], wn953, n093w, r71x2), sendApi(_s5O[z1[37824]], z1[38005], {
        'game_pkg': _s5O[z1[28476]],
        'server_id': _s5O[z1[28470]][z1[12235]],
        'role_id': wn953,
        'uid': _s5O[z1[28474]],
        'role_name': n093w,
        'role_type': mgltfh,
        'level': r71x2,
        'evolution': x217
    });
}, window[z1[38006]] = function (co_aip, k9hng5, ao4pvi, g5nf, e8j6q, tlm_g, i4opva, flhgk5, fg5hl, tl_fgm) {
    _s5O[z1[37871]] = co_aip, _s5O[z1[4890]] = k9hng5, _s5O[z1[37872]] = ao4pvi, _yit_[z1[37537]](_s5O[z1[28470]][z1[12235]], _s5O[z1[28470]][z1[28475]] || _s5O[z1[28470]][z1[12235]], co_aip, k9hng5, ao4pvi), sendApi(_s5O[z1[37824]], z1[38005], {
        'game_pkg': _s5O[z1[28476]],
        'server_id': _s5O[z1[28470]][z1[12235]],
        'role_id': co_aip,
        'uid': _s5O[z1[28474]],
        'role_name': k9hng5,
        'role_type': g5nf,
        'level': ao4pvi,
        'evolution': e8j6q
    });
}, window[z1[38007]] = function ($w210) {}, window[z1[38008]] = function (k9hzn5, ocapi_) {
    _yit_[z1[37462]](z1[37462], { 'activity_id': ocapi_ }, function (w01$) {
        k9hzn5 && k9hzn5(w01$);
    });
}, window[z1[26127]] = function () {
    _yit_[z1[26127]]();
}, window[z1[38009]] = function () {
    _yit_[z1[25997]] && _yit_[z1[25997]]();
}, window[z1[38010]] = function (t_ipac, $w90z3, r2w3$0, kfh5g, c_opa, f5nkhg, d12xy7, _clf) {
    _clf = _clf || _s5O[z1[28470]][z1[12235]], sendApi(_s5O[z1[37824]], z1[38011], {
        'phone': t_ipac,
        'role_id': $w90z3,
        'uid': _s5O[z1[28474]],
        'game_pkg': _s5O[z1[28476]],
        'partner_id': _s5O[z1[13260]],
        'server_id': _clf
    }, d12xy7, 0x2, null, function () {
        return !![];
    });
}, window[z1[11548]] = function ($0x2) {
    window[z1[38012]] = $0x2, window[z1[38012]] && window[z1[38013]] && (console[z1[82]](z1[38014] + window[z1[38013]][z1[888]]), window[z1[38012]](window[z1[38013]]), window[z1[38013]] = null);
}, window[z1[38015]] = function (qub, d6syx7, jeys8, fthlmg) {
    window[z1[23]](z1[38016], {
        'game_pkg': window[z1[4757]][z1[28476]],
        'role_id': d6syx7,
        'server_id': jeys8
    }, fthlmg);
}, window[z1[38017]] = function (d7xs1y, nz95kh, js8qe6) {
    function $r172(i_copa) {
        var esdy = [],
            cal = [],
            ca4oi = js8qe6 || window[z1[620]][z1[38018]];
        for (var $0x12r in ca4oi) {
            var fklmh = Number($0x12r);
            (!d7xs1y || !d7xs1y[z1[13]] || d7xs1y[z1[125]](fklmh) != -0x1) && (cal[z1[30]](ca4oi[$0x12r]), esdy[z1[30]]([fklmh, 0x3]));
        }
        window[z1[37898]](window[z1[38019]], z1[38020]) >= 0x0 ? (console[z1[544]](z1[38021]), _yit_[z1[38022]] && _yit_[z1[38022]](cal, function (kf5hn) {
            console[z1[544]](z1[38023]), console[z1[544]](kf5hn);
            if (kf5hn && kf5hn[z1[28089]] == z1[38024]) for (var j6ysde in ca4oi) {
                if (kf5hn[ca4oi[j6ysde]] == z1[38025]) {
                    var fglm = Number(j6ysde);
                    for (var eydjs6 = 0x0; eydjs6 < esdy[z1[13]]; eydjs6++) {
                        if (esdy[eydjs6][0x0] == fglm) {
                            esdy[eydjs6][0x1] = 0x1;
                            break;
                        }
                    }
                }
            }
            window[z1[37898]](window[z1[38019]], z1[38026]) >= 0x0 ? wx[z1[38027]]({
                'withSubscriptions': !![],
                'success': function (sqe6j8) {
                    var $1x2 = sqe6j8[z1[38028]][z1[38029]];
                    if ($1x2) {
                        console[z1[544]](z1[38030]), console[z1[544]]($1x2);
                        for (var bq8jue in ca4oi) {
                            if ($1x2[ca4oi[bq8jue]] == z1[38025]) {
                                var tgm = Number(bq8jue);
                                for (var f_gml = 0x0; f_gml < esdy[z1[13]]; f_gml++) {
                                    if (esdy[f_gml][0x0] == tgm) {
                                        esdy[f_gml][0x1] = 0x2;
                                        break;
                                    }
                                }
                            }
                        }
                        console[z1[544]](esdy), nz95kh && nz95kh(esdy);
                    } else console[z1[544]](z1[38031]), console[z1[544]](sqe6j8), console[z1[544]](esdy), nz95kh && nz95kh(esdy);
                },
                'fail': function () {
                    console[z1[544]](z1[38032]), console[z1[544]](esdy), nz95kh && nz95kh(esdy);
                }
            }) : (console[z1[544]](z1[38033] + window[z1[38019]]), console[z1[544]](esdy), nz95kh && nz95kh(esdy));
        })) : (console[z1[544]](z1[38034] + window[z1[38019]]), console[z1[544]](esdy), nz95kh && nz95kh(esdy)), wx[z1[38035]]($r172);
    }
    wx[z1[38036]]($r172);
}, window[z1[38037]] = {
    'isSuccess': ![],
    'level': z1[32715],
    'isCharging': ![]
}, window[z1[14683]] = function ($023wr) {
    wx[z1[38038]]({
        'success': function (zk5n) {
            var $r02x = window[z1[38037]];
            $r02x[z1[38039]] = !![], $r02x[z1[4866]] = Number(zk5n[z1[4866]])[z1[4444]](0x0), $r02x[z1[38040]] = zk5n[z1[38040]], $023wr && $023wr($r02x[z1[38039]], $r02x[z1[4866]], $r02x[z1[38040]]);
        },
        'fail': function (ghltfm) {
            console[z1[544]](z1[38041], ghltfm[z1[28089]]);
            var gmklh = window[z1[38037]];
            $023wr && $023wr(gmklh[z1[38039]], gmklh[z1[4866]], gmklh[z1[38040]]);
        }
    });
}, window[z1[12620]] = function (khgl) {
    wx[z1[12620]]({
        'success': function (ghfnk) {
            khgl && khgl(!![], ghfnk);
        },
        'fail': function (klhf) {
            khgl && khgl(![], klhf);
        }
    });
}, window[z1[12622]] = function (gnhf5) {
    if (gnhf5) wx[z1[12622]](gnhf5);
}, window[z1[28068]] = function (m_lgft) {
    wx[z1[28068]](m_lgft);
}, window[z1[23]] = function (w1r20$, mgkhl, w3nz0, x7d6sy, cftm_l, mfgl_, opi4v, kn9z) {
    if (x7d6sy == undefined) x7d6sy = 0x1;
    wx[z1[539]]({
        'url': w1r20$,
        'method': opi4v || z1[28080],
        'responseType': z1[4648],
        'data': mgkhl,
        'header': { 'content-type': kn9z || z1[37886] },
        'success': function (z$w093) {
            DEBUG && console[z1[544]](z1[38042], w1r20$, info, z$w093);
            if (z$w093 && z$w093[z1[28087]] == 0xc8) {
                var _cmpa = z$w093[z1[11]];
                !mfgl_ || mfgl_(_cmpa) ? w3nz0 && w3nz0(_cmpa) : window[z1[38043]](w1r20$, mgkhl, w3nz0, x7d6sy, cftm_l, mfgl_, z$w093);
            } else window[z1[38043]](w1r20$, mgkhl, w3nz0, x7d6sy, cftm_l, mfgl_, z$w093);
        },
        'fail': function (w0$2) {
            DEBUG && console[z1[544]](z1[38044], w1r20$, info, w0$2), window[z1[38043]](w1r20$, mgkhl, w3nz0, x7d6sy, cftm_l, mfgl_, w0$2);
        },
        'complete': function () {}
    });
}, window[z1[38043]] = function (z$w0r3, oiavp, ci4ao, djey6s, tcmp_a, $rwz, lhtmfg) {
    djey6s - 0x1 > 0x0 ? setTimeout(function () {
        window[z1[23]](z$w0r3, oiavp, ci4ao, djey6s - 0x1, tcmp_a, $rwz);
    }, 0x3e8) : tcmp_a && tcmp_a(JSON[z1[4740]]({
        'url': z$w0r3,
        'response': lhtmfg
    }));
}, window[z1[38045]] = function (h95nz, s7x1y, bqju8, w30$r2, c_tmap, hkn9z, yx7d2) {
    !bqju8 && (bqju8 = {});
    var i4po = Math[z1[130]](Date[z1[87]]() / 0x3e8);
    bqju8[z1[963]] = i4po, bqju8[z1[38046]] = s7x1y;
    var nk5g9h = Object[z1[288]](bqju8)[z1[1195]](),
        g5khf = '',
        s6qe8j = '';
    for (var fg5nh = 0x0; fg5nh < nk5g9h[z1[13]]; fg5nh++) {
        g5khf = g5khf + (fg5nh == 0x0 ? '' : '&') + nk5g9h[fg5nh] + bqju8[nk5g9h[fg5nh]], s6qe8j = s6qe8j + (fg5nh == 0x0 ? '' : '&') + nk5g9h[fg5nh] + '=' + encodeURIComponent(bqju8[nk5g9h[fg5nh]]);
    }
    g5khf = g5khf + _s5O[z1[37830]];
    var oi_pc = z1[38047] + md5(g5khf);
    send(h95nz + '?' + s6qe8j + (s6qe8j == '' ? '' : '&') + oi_pc, null, w30$r2, c_tmap, hkn9z, yx7d2 || function (coipa4) {
        return coipa4[z1[1439]] == z1[10339];
    }, null, z1[37452]);
}, window[z1[38048]] = function (lkhfm, wr$320) {
    var oiapc = 0x0;
    _s5O[z1[28470]] && (oiapc = _s5O[z1[28470]][z1[12235]]), sendApi(_s5O[z1[37826]], z1[38049], {
        'partnerId': _s5O[z1[13260]],
        'gamePkg': _s5O[z1[28476]],
        'logTime': Math[z1[130]](Date[z1[87]]() / 0x3e8),
        'platformUid': _s5O[z1[28477]],
        'type': lkhfm,
        'serverId': oiapc
    }, null, 0x2, null, function () {
        return !![];
    });
}, window[z1[38050]] = function (nkz95) {
    sendApi(_s5O[z1[37824]], z1[38051], {
        'partner_id': _s5O[z1[13260]],
        'uid': _s5O[z1[28474]],
        'version': _s5O[z1[5591]],
        'game_pkg': _s5O[z1[28476]],
        'device': _s5O[z1[28478]]
    }, _s5OQW, _sQO5, _sOW);
}, window[z1[38052]] = function (cm_tl) {
    if (cm_tl && cm_tl[z1[1439]] === z1[10339] && cm_tl[z1[11]]) {
        cm_tl[z1[11]][z1[5782]]({
            'id': -0x2,
            'name': z1[38053]
        }), cm_tl[z1[11]][z1[5782]]({
            'id': -0x1,
            'name': z1[38054]
        }), _s5O[z1[37718]] = cm_tl[z1[11]];
        if (window[z1[13453]]) window[z1[13453]][z1[37727]]();
    } else {
        _s5O[z1[37722]] = ![];
        var n9hg5 = cm_tl ? cm_tl[z1[1439]] : '';
        window[z1[37868]](0x7, z1[38055] + n9hg5), window[z1[37851]](z1[38056] + n9hg5);
    }
}, window[z1[38057]] = function (sqj6e) {
    sendApi(_s5O[z1[37824]], z1[38058], {
        'partner_id': _s5O[z1[13260]],
        'uid': _s5O[z1[28474]],
        'version': _s5O[z1[5591]],
        'game_pkg': _s5O[z1[28476]],
        'device': _s5O[z1[28478]]
    }, _sW5Q, _sQO5, _sOW);
}, window[z1[38059]] = function (js6ed) {
    _s5O[z1[37730]] = ![];
    if (js6ed && js6ed[z1[1439]] === z1[10339] && js6ed[z1[11]]) {
        for (var tmgf_l = 0x0; tmgf_l < js6ed[z1[11]][z1[13]]; tmgf_l++) {
            js6ed[z1[11]][tmgf_l][z1[116]] = _s5QW(js6ed[z1[11]][tmgf_l]);
        }
        _s5O[z1[37728]][-0x1] = window[z1[38060]](js6ed[z1[11]]), window[z1[13453]][z1[37729]](-0x1);
    } else {
        var e6sdjy = js6ed ? js6ed[z1[1439]] : '';
        window[z1[37868]](0x8, z1[38061] + e6sdjy), window[z1[37851]](z1[38062] + e6sdjy);
    }
}, window[z1[38063]] = function (lct_ma) {
    sendApi(_s5O[z1[37824]], z1[38058], {
        'partner_id': _s5O[z1[13260]],
        'uid': _s5O[z1[28474]],
        'version': _s5O[z1[5591]],
        'game_pkg': _s5O[z1[28476]],
        'device': _s5O[z1[28478]]
    }, lct_ma, _sQO5, _sOW);
}, window[z1[38064]] = function ($x0r21, gflmt_) {
    sendApi(_s5O[z1[37824]], z1[38065], {
        'partner_id': _s5O[z1[13260]],
        'uid': _s5O[z1[28474]],
        'version': _s5O[z1[5591]],
        'game_pkg': _s5O[z1[28476]],
        'device': _s5O[z1[28478]],
        'server_group_id': gflmt_
    }, _sQ5W, _sQO5, _sOW);
}, window[z1[38066]] = function (w$r203) {
    _s5O[z1[37730]] = ![];
    if (w$r203 && w$r203[z1[1439]] === z1[10339] && w$r203[z1[11]] && w$r203[z1[11]][z1[11]]) {
        var s67jy = w$r203[z1[11]][z1[38067]],
            jy68 = [];
        for (var rwz0 = 0x0; rwz0 < w$r203[z1[11]][z1[11]][z1[13]]; rwz0++) {
            w$r203[z1[11]][z1[11]][rwz0][z1[116]] = _s5QW(w$r203[z1[11]][z1[11]][rwz0]), (jy68[z1[13]] == 0x0 || w$r203[z1[11]][z1[11]][rwz0][z1[116]] != 0x0) && (jy68[jy68[z1[13]]] = w$r203[z1[11]][z1[11]][rwz0]);
        }
        _s5O[z1[37728]][s67jy] = window[z1[38060]](jy68), window[z1[13453]][z1[37729]](s67jy);
    } else {
        var i_tpca = w$r203 ? w$r203[z1[1439]] : '';
        window[z1[37868]](0x9, z1[38068] + i_tpca), window[z1[37851]](z1[38069] + i_tpca);
    }
}, window[z1[38070]] = function (jyd76s) {
    sendApi(_s5O[z1[37824]], z1[38071], {
        'partner_id': _s5O[z1[13260]],
        'uid': _s5O[z1[28474]],
        'version': _s5O[z1[5591]],
        'game_pkg': _s5O[z1[28476]],
        'device': _s5O[z1[28478]]
    }, reqServerRecommendCallBack, _sQO5, _sOW);
}, window[z1[38072]] = function (h5lkfg) {
    _s5O[z1[37730]] = ![];
    if (h5lkfg && h5lkfg[z1[1439]] === z1[10339] && h5lkfg[z1[11]]) {
        for (var o4pia = 0x0; o4pia < h5lkfg[z1[11]][z1[13]]; o4pia++) {
            h5lkfg[z1[11]][o4pia][z1[116]] = _s5QW(h5lkfg[z1[11]][o4pia]);
        }
        _s5O[z1[37728]][-0x2] = window[z1[38060]](h5lkfg[z1[11]]), window[z1[13453]][z1[37729]](-0x2);
    } else {
        var fmtlgh = h5lkfg ? h5lkfg[z1[1439]] : '';
        window[z1[37868]](0xa, z1[38073] + fmtlgh), alert(z1[38074] + fmtlgh);
    }
}, window[z1[38060]] = function (hnkz9) {
    return hnkz9;
}, window[z1[38075]] = function (oipc4a, amtc_p) {
    oipc4a = oipc4a || _s5O[z1[28470]][z1[12235]], sendApi(_s5O[z1[37824]], z1[38076], {
        'type': '4',
        'game_pkg': _s5O[z1[28476]],
        'server_id': oipc4a
    }, amtc_p);
}, window[z1[38077]] = function (mftl_g, xs7yd1, w023$, paio4v) {
    w023$ = w023$ || _s5O[z1[28470]][z1[12235]], sendApi(_s5O[z1[37824]], z1[38078], {
        'type': mftl_g,
        'game_pkg': xs7yd1,
        'server_id': w023$
    }, paio4v);
}, window[z1[38079]] = function (itpa_, mpact) {
    sendApi(_s5O[z1[37824]], z1[38080], { 'game_pkg': itpa_ }, mpact);
}, window[z1[38081]] = function (tm_al) {
    if (tm_al) {
        if (tm_al[z1[116]] == 0x1) {
            if (tm_al[z1[38082]] == 0x3) return 0x3;else return tm_al[z1[38082]] == 0x1 ? 0x2 : 0x1;
        } else return tm_al[z1[116]] == 0x0 ? 0x0 : -0x1;
    }
    return -0x1;
}, window[z1[38083]] = function (jb8ueq, $0w3rz) {
    _s5O[z1[38084]] = {
        'step': jb8ueq,
        'server_id': $0w3rz
    };
    var tmglf = this;
    _sW5QO({ 'title': z1[38085] }), sendApi(_s5O[z1[37824]], z1[38086], {
        'partner_id': _s5O[z1[13260]],
        'uid': _s5O[z1[28474]],
        'game_pkg': _s5O[z1[28476]],
        'server_id': $0w3rz,
        'platform': _s5O[z1[28428]],
        'platform_uid': _s5O[z1[28477]],
        'check_login_time': _s5O[z1[37937]],
        'check_login_sign': _s5O[z1[37936]],
        'version_name': _s5O[z1[4758]]
    }, _sOW5Q, _sQO5, _sOW, function (zn03w9) {
        return zn03w9[z1[1439]] == z1[10339] || zn03w9[z1[82]] == z1[38087] || zn03w9[z1[82]] == z1[38088];
    });
}, window[z1[38089]] = function (icp_ta) {
    var sdy7x = this;
    if (icp_ta && icp_ta[z1[1439]] === z1[10339] && icp_ta[z1[11]]) {
        var $9zw3 = _s5O[z1[28470]];
        $9zw3[z1[38090]] = _s5O[z1[37833]], $9zw3[z1[12218]] = String(icp_ta[z1[11]][z1[38091]]), $9zw3[z1[28430]] = parseInt(icp_ta[z1[11]][z1[963]]);
        if (icp_ta[z1[11]][z1[28429]]) $9zw3[z1[28429]] = parseInt(icp_ta[z1[11]][z1[28429]]);else $9zw3[z1[28429]] = parseInt(icp_ta[z1[11]][z1[12235]]);
        $9zw3[z1[38092]] = 0x0, $9zw3[z1[4754]] = _s5O[z1[37979]], $9zw3[z1[38093]] = icp_ta[z1[11]][z1[38094]], $9zw3[z1[38095]] = icp_ta[z1[11]][z1[38095]];
        if (icp_ta[z1[11]][z1[28434]]) $9zw3[z1[28434]] = parseInt(icp_ta[z1[11]][z1[28434]]);
        console[z1[544]](z1[38096] + JSON[z1[4740]]($9zw3[z1[38095]])), _s5O[z1[727]] == 0x1 && $9zw3[z1[38095]] && $9zw3[z1[38095]][z1[38097]] == 0x1 && (_s5O[z1[37674]] = 0x1, window[z1[37809]][z1[167]][z1[37788]]()), _sOQW5();
    } else {
        if (_s5O[z1[38084]][z1[4671]] >= 0x3) {
            var _fcl = icp_ta ? icp_ta[z1[1439]] : '';
            window[z1[37868]](0xc, z1[38098] + _fcl), _sOW(JSON[z1[4740]](icp_ta)), window[z1[37851]](z1[38099] + _fcl);
        } else sendApi(_s5O[z1[37824]], z1[37915], {
            'platform': _s5O[z1[37822]],
            'partner_id': _s5O[z1[13260]],
            'token': _s5O[z1[37913]],
            'game_pkg': _s5O[z1[28476]],
            'deviceId': _s5O[z1[28478]],
            'scene': z1[37916] + _s5O[z1[37832]]
        }, function (cp_) {
            if (!cp_ || cp_[z1[1439]] != z1[10339]) {
                window[z1[37851]](z1[37933] + cp_ && cp_[z1[1439]]);
                return;
            }
            _s5O[z1[37936]] = String(cp_[z1[12218]]), _s5O[z1[37937]] = String(cp_[z1[963]]), setTimeout(function () {
                _sOWQ5(_s5O[z1[38084]][z1[4671]] + 0x1, _s5O[z1[38084]][z1[12235]]);
            }, 0x5dc);
        }, _sQO5, _sOW, function (aoi_c) {
            return aoi_c[z1[1439]] == z1[10339] || aoi_c[z1[1439]] == z1[28825];
        });
    }
}, window[z1[38100]] = function () {
    ServerLoading[z1[167]][z1[37786]](_s5O[z1[727]]), window[z1[37840]] = !![], window[z1[37775]]();
}, window[z1[37774]] = function () {
    if (window[z1[37841]] && window[z1[37842]] && window[z1[37773]] && window[z1[37785]] && window[z1[37843]] && window[z1[37845]]) {
        if (!window[z1[37001]][z1[167]]) {
            console[z1[544]](z1[38101] + window[z1[37001]][z1[167]]);
            var k5zhn9 = wx[z1[28051]](),
                g5fn = k5zhn9[z1[888]] ? k5zhn9[z1[888]] : 0x0,
                ng5k = {
                'cdn': window[z1[4757]][z1[4754]],
                'spareCdn': window[z1[4757]][z1[28098]],
                'newRegister': window[z1[4757]][z1[727]],
                'wxPC': window[z1[4757]][z1[28101]],
                'wxIOS': window[z1[4757]][z1[1190]],
                'wxAndroid': window[z1[4757]][z1[12059]],
                'wxParam': {
                    'limitLoad': window[z1[4757]][z1[38102]],
                    'benchmarkLevel': window[z1[4757]][z1[38103]],
                    'wxFrom': window[z1[620]][z1[32705]] == z1[38104] ? 0x1 : 0x0,
                    'wxSDKVersion': window[z1[38019]],
                    'qudao': z1[38105]
                },
                'configType': window[z1[4757]][z1[4756]],
                'exposeType': window[z1[4757]][z1[810]],
                'scene': g5fn,
                'video_type': window[z1[4757]][z1[28618]],
                'ad_flag': window[z1[4757]][z1[28617]]
            };
            if (window[z1[37981]]) for (var p_coai in window[z1[37981]]) {
                if (!ng5k[p_coai]) ng5k[p_coai] = window[z1[37981]][p_coai];
            }
            new window[z1[37001]](ng5k, window[z1[4757]][z1[110]], window[z1[37817]]);
        }
    }
}, window[z1[37775]] = function () {
    if (window[z1[37841]] && window[z1[37842]] && window[z1[37773]] && window[z1[37785]] && window[z1[37843]] && window[z1[37845]] && window[z1[37840]] && window[z1[37844]]) {
        _sW5OQ();
        if (!_sOQ5) {
            _sOQ5 = !![];
            if (!window[z1[37001]][z1[167]]) window[z1[37774]]();
            var q6ej = 0x0,
                aocpi_ = wx[z1[38106]]();
            aocpi_ && (window[z1[4757]][z1[38107]] && (q6ej = aocpi_[z1[374]]), console[z1[82]](z1[38108] + aocpi_[z1[374]] + z1[38109] + aocpi_[z1[1465]] + z1[38110] + aocpi_[z1[1467]] + z1[38111] + aocpi_[z1[1466]] + z1[38112] + aocpi_[z1[204]] + z1[38113] + aocpi_[z1[205]]));
            var sy7x1d = {};
            for (const e8qjs in _s5O[z1[28470]]) {
                sy7x1d[e8qjs] = _s5O[z1[28470]][e8qjs];
            }
            var jd6eys = {
                'channel': window[z1[4757]][z1[13269]],
                'account': window[z1[4757]][z1[28474]],
                'userId': window[z1[4757]][z1[13258]],
                'cdn': window[z1[4757]][z1[4754]],
                'data': window[z1[4757]][z1[11]],
                'package': window[z1[4757]][z1[28099]],
                'newRegister': window[z1[4757]][z1[727]],
                'pkgName': window[z1[4757]][z1[28476]],
                'partnerId': window[z1[4757]][z1[13260]],
                'platform_uid': window[z1[4757]][z1[28477]],
                'deviceId': window[z1[4757]][z1[28478]],
                'selectedServer': sy7x1d,
                'configType': window[z1[4757]][z1[4756]],
                'exposeType': window[z1[4757]][z1[810]],
                'debugUsers': window[z1[4757]][z1[13406]],
                'wxMenuTop': q6ej,
                'wxShield': window[z1[4757]][z1[832]],
                'encryptParam': window[z1[4757]][z1[28625]],
                'wx_channel': window[z1[4757]][z1[28623]],
                'zsy_tp_state': window[z1[4757]][z1[28624]]
            };
            if (window[z1[37981]]) for (var lf_ in window[z1[37981]]) {
                jd6eys[lf_] = window[z1[37981]][lf_];
            }
            window[z1[37001]][z1[167]][z1[28492]](jd6eys);
            if (_s5O[z1[28470]] && _s5O[z1[28470]][z1[12235]]) localStorage[z1[547]](z1[37939] + _s5O[z1[28476]] + _s5O[z1[28474]], _s5O[z1[28470]][z1[12235]]);
        }
    } else console[z1[82]](z1[38114] + window[z1[37841]] + z1[38115] + window[z1[37842]] + z1[38116] + window[z1[37773]] + z1[38117] + window[z1[37785]] + z1[38118] + window[z1[37843]] + z1[38119] + window[z1[37845]] + z1[38120] + window[z1[37840]] + z1[38121] + window[z1[37844]]);
};