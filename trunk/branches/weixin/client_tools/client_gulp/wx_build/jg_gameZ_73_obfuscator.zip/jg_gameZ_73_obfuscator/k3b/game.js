var z1 = wx.Z$;
require('./ru.js'), window[z1[37312]][z1[30631]][z1[37313]] = null, window['client_pb'] = require('./a8r.js'), window[z1[28628]] = window[z1[37312]][z1[28504]][z1[28505]](client_pb);