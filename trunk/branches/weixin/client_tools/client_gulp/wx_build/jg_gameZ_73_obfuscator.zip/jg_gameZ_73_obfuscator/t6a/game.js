var z1 = wx.Z$;
require(z1[37810]);