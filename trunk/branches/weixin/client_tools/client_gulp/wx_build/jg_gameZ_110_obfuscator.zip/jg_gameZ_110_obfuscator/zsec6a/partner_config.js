var b = wx.$e;
var sdk_conf = {
  game_id: b[38041],
  game_pkg: b[38042],
  partner_id: b[38043],
  game_ver: b[38044],
  is_auth: false, //授权登录
  partner_app_id: b[38045],
  partner_app_key: b[38046]
};
window.config = sdk_conf;
module.exports = sdk_conf;