var b = wx.$e;
import eqis6r from '../zsec6a/gdl.js';
window[b[28409]] = { 'wxVersion': window[b[1088]][b[37606]] }, window[b[37607]] = ![], window[b[37608]] = 0x1, window[b[37609]] = 0x1, window['e1$VJ'] = !![], window[b[37610]] = !![], window['e1PK$VJ'] = '', window[b[37611]] = !![], window[b[5155]] = {
    'base_cdn': b[37612],
    'cdn': b[37612]
}, e1VJ[b[37613]] = {}, e1VJ[b[192]] = '0', e1VJ[b[5987]] = window[b[28409]][b[37474]], e1VJ[b[37614]] = '', e1VJ['os'] = '1', e1VJ[b[37615]] = b[37616], e1VJ[b[37617]] = b[37618], e1VJ[b[37619]] = b[37620], e1VJ[b[37621]] = b[37622], e1VJ[b[37623]] = b[37624], e1VJ[b[13640]] = '1', e1VJ[b[28847]] = '', e1VJ[b[28849]] = '', e1VJ[b[37625]] = 0x0, e1VJ[b[37529]] = {}, e1VJ[b[37626]] = parseInt(e1VJ[b[13640]]), e1VJ[b[13649]] = e1VJ[b[13640]], e1VJ[b[28841]] = {}, e1VJ[b[37627]] = b[37628], e1VJ[b[37629]] = ![], e1VJ[b[13786]] = b[37630], e1VJ[b[28801]] = Date[b[625]](), e1VJ[b[5154]] = b[37631], e1VJ[b[1275]] = '_a', e1VJ[b[28994]] = '', e1VJ[b[37465]] = 0x2, e1VJ[b[640]] = 0x7c1, e1VJ[b[37474]] = window[b[28409]][b[37474]], e1VJ[b[1297]] = ![], e1VJ[b[1649]] = ![], e1VJ[b[12442]] = ![], e1VJ[b[28473]] = ![], window['e1$JV'] = 0x5, window['e1$J'] = ![], window['e1J$'] = ![], window['e1V$J'] = ![], window[b[37571]] = ![], window[b[37581]] = ![], window['e1VJ$'] = ![], window['e1$V'] = ![], window['e1V$'] = ![], window['e1J$V'] = ![], window[b[37573]] = null, window[b[1179]] = function (u7mvp) {
    console[b[156]](b[1179], u7mvp), wx[b[5497]]({}), wx[b[37632]]({
        'title': b[6739],
        'content': u7mvp,
        'success'(fa) {
            if (fa[b[37633]]) console[b[156]](b[37634]);else fa[b[1084]] && console[b[156]](b[37635]);
        }
    });
}, window['e1K$VJ'] = function (grhq6) {
    console[b[156]](b[37636], grhq6), e1KVJ$(), wx[b[37632]]({
        'title': b[6739],
        'content': grhq6,
        'confirmText': b[37637],
        'cancelText': b[20918],
        'success'(zy79u) {
            if (zy79u[b[37633]]) window[b[37638]]();else zy79u[b[1084]] && (console[b[156]](b[37639]), wx[b[28446]]({}));
        }
    });
}, window[b[37640]] = function (ish6r) {
    console[b[156]](b[37640], ish6r), wx[b[37632]]({
        'title': b[6739],
        'content': ish6r,
        'confirmText': b[28978],
        'showCancel': ![],
        'complete'(x5pkd2) {
            console[b[156]](b[37639]), wx[b[28446]]({});
        }
    });
}, window['e1K$JV'] = ![], window['e1KV$J'] = function (c_t$w) {
    window['e1K$JV'] = !![], wx[b[5496]](c_t$w);
}, window['e1KVJ$'] = function () {
    window['e1K$JV'] && (window['e1K$JV'] = ![], wx[b[5497]]({}));
}, window['e1KJ$V'] = function (kp) {
    window[b[37605]][b[676]]['e1KJ$V'](kp);
}, window[b[13656]] = function (zuv97m, h0qi8) {
    eqis6r[b[13656]](zuv97m, function (vp9um7) {
        vp9um7 && vp9um7[b[201]] ? vp9um7[b[201]][b[1872]] == 0x1 ? h0qi8(!![]) : (h0qi8(![]), console[b[620]](b[37641] + vp9um7[b[201]][b[37642]])) : console[b[156]](b[13656], vp9um7);
    });
}, window['e1KJV$'] = function (mvp7u) {
    console[b[156]](b[37643], mvp7u);
}, window[b[37469]] = function (h0o83) {}, window[b[37470]] = function (u79y, hi6rqs, foi803) {}, window[b[37644]] = function (m79upv) {
    console[b[156]](b[37645], m79upv), window[b[37605]][b[676]][b[37467]](), window[b[37605]][b[676]][b[37468]](), window[b[37605]][b[676]][b[37477]](), window[b[37646]]();
}, window[b[37647]] = function (c_wtl) {
    window[b[37648]](0xe, b[37649] + c_wtl), window['e1K$VJ'](b[37650]);
    var a0fj13 = {
        'id': window[b[5155]][b[37651]],
        'role': window[b[5155]][b[5286]],
        'level': window[b[5155]][b[37652]],
        'account': window[b[5155]][b[28845]],
        'version': window[b[5155]][b[640]],
        'cdn': window[b[5155]][b[5152]],
        'pkgName': window[b[5155]][b[28847]],
        'gamever': window[b[1088]][b[37606]],
        'serverid': window[b[5155]][b[28841]] ? window[b[5155]][b[28841]][b[12618]] : 0x0,
        'systemInfo': window[b[37653]],
        'error': b[37654],
        'stack': c_wtl ? c_wtl : b[37650]
    },
        u79yz = JSON[b[5138]](a0fj13);
    console[b[199]](b[37655] + u79yz), window[b[37627]](u79yz);
}, window[b[37648]] = function (gq64rs, o8i3f) {
    sendApi(e1VJ[b[37619]], b[37656], {
        'game_pkg': e1VJ[b[28847]],
        'partner_id': e1VJ[b[13640]],
        'server_id': e1VJ[b[28841]] && e1VJ[b[28841]][b[12618]] > 0x0 ? e1VJ[b[28841]][b[12618]] : 0x0,
        'uid': e1VJ[b[28845]] > 0x0 ? e1VJ[b[28845]] : 0x0,
        'type': gq64rs,
        'info': o8i3f
    });
}, window[b[37657]] = function (a3nf1j) {
    var $wbclt = JSON[b[155]](a3nf1j);
    $wbclt[b[37658]] = window[b[1088]][b[37606]], $wbclt[b[37659]] = window[b[5155]][b[28841]] ? window[b[5155]][b[28841]][b[12618]] : 0x0, $wbclt[b[37653]] = window[b[37653]];
    var xkd5vp = JSON[b[5138]]($wbclt);
    console[b[199]](b[37660] + xkd5vp), window[b[37627]](xkd5vp);
}, window[b[37661]] = function (rqhsg6, qgh6s) {
    var nmyz = {
        'id': window[b[5155]][b[37651]],
        'role': window[b[5155]][b[5286]],
        'level': window[b[5155]][b[37652]],
        'account': window[b[5155]][b[28845]],
        'version': window[b[5155]][b[640]],
        'cdn': window[b[5155]][b[5152]],
        'pkgName': window[b[5155]][b[28847]],
        'gamever': window[b[1088]][b[37606]],
        'serverid': window[b[5155]][b[28841]] ? window[b[5155]][b[28841]][b[12618]] : 0x0,
        'systemInfo': window[b[37653]],
        'error': rqhsg6,
        'stack': qgh6s
    },
        dbxt2 = JSON[b[5138]](nmyz);
    console[b[213]](b[37662] + dbxt2), window[b[37627]](dbxt2);
}, window[b[37627]] = function (ymz9) {
    if (window[b[5155]][b[37663]] == b[37664]) return;
    var $cwbtl = e1VJ[b[37627]] + b[37665] + e1VJ[b[28845]];
    wx[b[1013]]({
        'url': $cwbtl,
        'method': b[37666],
        'data': ymz9,
        'header': {
            'content-type': b[37667],
            'cache-control': b[28454]
        },
        'success': function (bl$) {
            DEBUG && console[b[156]](b[37668], $cwbtl, ymz9, bl$);
        },
        'fail': function (gsq64) {
            DEBUG && console[b[156]](b[37668], $cwbtl, ymz9, gsq64);
        },
        'complete': function () {}
    });
}, window[b[37669]] = function () {
    function rs4eg6() {
        return ((0x1 + Math[b[652]]()) * 0x10000 | 0x0)[b[38]](0x10)[b[162]](0x1);
    }
    return rs4eg6() + rs4eg6() + '-' + rs4eg6() + '-' + rs4eg6() + '-' + rs4eg6() + '+' + rs4eg6() + rs4eg6() + rs4eg6();
}, window[b[37638]] = function () {
    console[b[156]](b[37670]);
    var rgs6 = eqis6r[b[35512]]();
    e1VJ[b[13649]] = rgs6[b[37671]], e1VJ[b[37626]] = rgs6[b[37671]], e1VJ[b[13640]] = rgs6[b[37671]], e1VJ[b[28847]] = rgs6[b[37565]];
    var kpvxum = { 'game_ver': e1VJ[b[5987]] };
    e1VJ[b[28849]] = this[b[37669]](), e1KV$J({ 'title': b[37672] }), eqis6r[b[903]](kpvxum, this[b[37673]][b[8]](this));
}, window[b[37673]] = function (g6rqsh) {
    var s4rqg = g6rqsh[b[37574]];
    sdkInitRes = g6rqsh, console[b[156]](b[37674] + s4rqg + b[37675] + (s4rqg == 0x1) + b[37676] + g6rqsh[b[37606]] + b[37677] + window[b[28409]][b[37474]] + b[37678] + g6rqsh[b[5156]]);
    if (!g6rqsh[b[37606]] || window['e1P$JKV'](window[b[28409]][b[37474]], g6rqsh[b[37606]]) < 0x0) console[b[156]](b[37679]), e1VJ[b[37617]] = b[37680], e1VJ[b[37619]] = b[37681], e1VJ[b[37621]] = b[37682], e1VJ[b[5152]] = b[37683], e1VJ[b[28471]] = b[37684], e1VJ[b[5156]] = g6rqsh[b[5156]], e1VJ[b[1297]] = ![];else window['e1P$JKV'](window[b[28409]][b[37474]], g6rqsh[b[37606]]) == 0x0 ? (console[b[156]](b[37685]), e1VJ[b[37617]] = b[37618], e1VJ[b[37619]] = b[37620], e1VJ[b[37621]] = b[37622], e1VJ[b[5152]] = b[37612], e1VJ[b[28471]] = b[37684], e1VJ[b[5156]] = b[37686], e1VJ[b[1297]] = !![]) : (console[b[156]](b[37687]), e1VJ[b[37617]] = b[37618], e1VJ[b[37619]] = b[37620], e1VJ[b[37621]] = b[37622], e1VJ[b[5152]] = b[37612], e1VJ[b[28471]] = b[37684], e1VJ[b[5156]] = b[37686], e1VJ[b[1297]] = ![]);
    e1VJ[b[37625]] = config[b[33]] ? config[b[33]] : 0x0, this['e1$VKJ'](), this['e1$VJK'](), window[b[37688]] = 0x5, e1KV$J({ 'title': b[37689] }), eqis6r[b[37690]](this[b[37691]][b[8]](this));
}, window[b[37688]] = 0x5, window[b[37691]] = function (gers64, xmpkvu) {
    if (gers64 == 0x0 && xmpkvu && xmpkvu[b[187]]) {
        e1VJ[b[37692]] = xmpkvu[b[187]], e1VJ[b[28992]] = xmpkvu[b[28992]], e1VJ[b[28987]] = xmpkvu[b[28987]], e1VJ[b[28993]] = xmpkvu[b[28993]], e1VJ[b[28986]] = xmpkvu[b[28986]];
        var dpv5 = this;
        e1KV$J({ 'title': b[37693] }), sendApi(e1VJ[b[37617]], b[37694], {
            'platform': e1VJ[b[37615]],
            'partner_id': e1VJ[b[13640]],
            'token': xmpkvu[b[187]],
            'game_pkg': e1VJ[b[28847]],
            'deviceId': e1VJ[b[28849]],
            'scene': b[37695] + e1VJ[b[37625]]
        }, this['e1$KVJ'][b[8]](this), e1$JV, e1JK);
    } else xmpkvu && xmpkvu[b[28462]] && window[b[37688]] > 0x0 && (xmpkvu[b[28462]][b[102]](b[37696]) != -0x1 || xmpkvu[b[28462]][b[102]](b[37697]) != -0x1 || xmpkvu[b[28462]][b[102]](b[37698]) != -0x1 || xmpkvu[b[28462]][b[102]](b[37699]) != -0x1 || xmpkvu[b[28462]][b[102]](b[37700]) != -0x1 || xmpkvu[b[28462]][b[102]](b[37701]) != -0x1) ? (window[b[37688]]--, eqis6r[b[37690]](this[b[37691]][b[8]](this))) : (window[b[37648]](0x1, b[37702] + gers64 + b[37703] + (xmpkvu ? xmpkvu[b[28462]] : '')), window[b[37661]](b[37704], JSON[b[5138]]({
        'status': gers64,
        'data': xmpkvu
    })), window['e1K$VJ'](b[37705] + (xmpkvu && xmpkvu[b[28462]] ? '，' + xmpkvu[b[28462]] : '')));
}, window['e1$KVJ'] = function (sqgh6) {
    if (!sqgh6) {
        window[b[37648]](0x2, b[37706]), window[b[37661]](b[37707], b[37708]), window['e1K$VJ'](b[37709]);
        return;
    }
    if (sqgh6[b[1872]] != b[10722]) {
        window[b[37648]](0x2, b[37710] + sqgh6[b[1872]]), window[b[37661]](b[37707], JSON[b[5138]](sqgh6)), window['e1K$VJ'](b[37711] + sqgh6[b[1872]]);
        return;
    }
    if (sqgh6[b[37712]] == 0x1) {
        window['e1K$VJ'](b[37713]);
        return;
    }
    e1VJ[b[13638]] = String(sqgh6[b[28845]]), e1VJ[b[28845]] = String(sqgh6[b[28845]]), e1VJ[b[28799]] = String(sqgh6[b[28799]]), e1VJ[b[13649]] = String(sqgh6[b[28799]]), e1VJ[b[28848]] = String(sqgh6[b[28848]]), e1VJ[b[37714]] = String(sqgh6[b[12601]]), e1VJ[b[37715]] = String(sqgh6[b[1427]]), e1VJ[b[12601]] = '';
    var o083h = this;
    e1KV$J({ 'title': b[37716] });
    var k52dx = localStorage[b[1016]](b[37717] + e1VJ[b[28847]] + e1VJ[b[28845]]);
    if (k52dx && k52dx != '') {
        var pkmux = Number(k52dx);
        o083h[b[37718]](pkmux);
    } else o083h[b[37719]]();
}, window[b[37719]] = function () {
    var zja1y = this;
    sendApi(e1VJ[b[37617]], b[37720], {
        'partner_id': e1VJ[b[13640]],
        'uid': e1VJ[b[28845]],
        'version': e1VJ[b[5987]],
        'game_pkg': e1VJ[b[28847]],
        'device': e1VJ[b[28849]]
    }, zja1y['e1$KJV'][b[8]](zja1y), e1$JV, e1JK);
}, window['e1$KJV'] = function (b$lwct) {
    if (!b$lwct) {
        window[b[37648]](0x3, b[37721]), window['e1K$VJ'](b[37721]);
        return;
    }
    if (b$lwct[b[1872]] != b[10722]) {
        window[b[37648]](0x3, b[37722] + b$lwct[b[1872]]), window['e1K$VJ'](b[37722] + b$lwct[b[1872]]);
        return;
    }
    if (!b$lwct[b[201]] || b$lwct[b[201]][b[19]] == 0x0) {
        window[b[37648]](0x3, b[37723]), window['e1K$VJ'](b[37724]);
        return;
    }
    this[b[37725]](b$lwct);
}, window[b[37718]] = function (t$d2b) {
    var zaj1y = this;
    sendApi(e1VJ[b[37617]], b[37726], {
        'server_id': t$d2b,
        'time': Date[b[625]]() / 0x3e8
    }, zaj1y[b[37727]][b[8]](zaj1y), e1$JV, e1JK);
}, window[b[37727]] = function (cwbt) {
    if (!cwbt) {
        window[b[37648]](0x4, b[37728]), this[b[37719]]();
        return;
    }
    if (cwbt[b[1872]] != b[10722]) {
        window[b[37648]](0x4, b[37729] + cwbt[b[1872]]), this[b[37719]]();
        return;
    }
    if (!cwbt[b[201]] || cwbt[b[201]][b[19]] == 0x0) {
        window[b[37648]](0x4, b[37730]), this[b[37719]]();
        return;
    }
    this[b[37725]](cwbt);
}, window[b[37725]] = function (kdx25) {
    e1VJ[b[1192]] = kdx25[b[37731]] != undefined ? kdx25[b[37731]] : 0x0, e1VJ[b[28841]] = {
        'server_id': String(kdx25[b[201]][0x0][b[12618]]),
        'server_name': String(kdx25[b[201]][0x0][b[28846]]),
        'entry_ip': kdx25[b[201]][0x0][b[28452]],
        'entry_port': parseInt(kdx25[b[201]][0x0][b[28869]]),
        'status': e1V$K(kdx25[b[201]][0x0]),
        'start_time': kdx25[b[201]][0x0][b[37732]],
        'maintain_time': kdx25[b[201]][0x0][b[37496]] ? kdx25[b[201]][0x0][b[37496]] : '',
        'cdn': e1VJ[b[5152]]
    }, this[b[37733]](), window[b[37605]] && window[b[37605]][b[676]][b[37734]] && window[b[37605]][b[676]][b[37734]](sdkInitRes[b[37735]], sdkInitRes[b[37736]], sdkInitRes[b[37737]], sdkInitRes[b[37738]], sdkInitRes[b[37739]]);
}, window[b[37733]] = function () {
    window['e1V$'] = !![], window['e1JV$K']();
}, window['e1JV$K'] = function () {
    if (window['e1V$'] && window['e1$V']) {
        var r6q = e1VJ[b[37520]] != undefined ? e1VJ[b[37520]] : 0x0,
            g4es = e1VJ[b[28986]] == undefined ? 0x0 : e1VJ[b[28986]],
            xvpmku = r6q == 0x1 && g4es == 0x1 || r6q == 0x2 && g4es != 0x1 || r6q == 0x3;
        console[b[620]](b[37740] + e1VJ[b[1192]] + b[37741] + xvpmku + b[37742] + e1VJ[b[28986]] + b[37743] + e1VJ[b[37520]]);
        if (!xvpmku && e1VJ[b[1192]] == 0x1) {
            var uk9v = e1VJ[b[28841]][b[644]];
            if (uk9v === -0x1 || uk9v === 0x0) {
                window[b[37648]](0xf, b[37744] + e1VJ[b[28841]]['id'] + b[37745] + e1VJ[b[28841]][b[644]]), window['e1K$VJ'](uk9v === -0x1 ? b[37746] : b[37747]);
                return;
            }
            e1JK$V(0x0, e1VJ[b[28841]][b[12618]]), window[b[37605]][b[676]][b[37582]](e1VJ[b[1192]]);
        } else window[b[37605]][b[676]][b[37578]]({
            'show': sdkInitRes[b[37735]],
            'skinUrl': sdkInitRes[b[37736]],
            'content': sdkInitRes[b[37737]],
            'x': sdkInitRes[b[37738]],
            'y': sdkInitRes[b[37739]]
        }), e1KVJ$();
        window[b[37748]](), window['e1J$VK'](), window['e1JVK$']();
    }
}, window['e1$VKJ'] = function () {
    sendApi(e1VJ[b[37617]], b[37749], {
        'game_pkg': e1VJ[b[28847]],
        'version_name': e1VJ[b[5156]]
    }, this[b[37750]][b[8]](this), e1$JV, e1JK);
}, window[b[37750]] = function (kvum) {
    if (!kvum) {
        window[b[37648]](0x5, b[37751]), window['e1K$VJ'](b[37751]);
        return;
    }
    if (kvum[b[1872]] != b[10722]) {
        window[b[37648]](0x5, b[37752] + kvum[b[1872]]), window['e1K$VJ'](b[37752] + kvum[b[1872]]);
        return;
    }
    if (!kvum[b[201]] || !kvum[b[201]][b[5987]]) {
        window[b[37648]](0x5, b[37753] + (kvum[b[201]] && kvum[b[201]][b[5987]])), window['e1K$VJ'](b[37753] + (kvum[b[201]] && kvum[b[201]][b[5987]]));
        return;
    }
    kvum[b[201]][b[37754]] && kvum[b[201]][b[37754]][b[19]] > 0xa && (e1VJ[b[37755]] = kvum[b[201]][b[37754]], e1VJ[b[5152]] = kvum[b[201]][b[37754]]), kvum[b[201]][b[5987]] && (e1VJ[b[640]] = kvum[b[201]][b[5987]]), console[b[620]](b[28989] + e1VJ[b[640]] + b[37756] + e1VJ[b[5156]]), window['e1VJ$'] = !![], window['e1J$VK'](), window['e1JVK$']();
}, window[b[37757]], window['e1$VJK'] = function () {
    sendApi(e1VJ[b[37617]], b[37758], { 'game_pkg': e1VJ[b[28847]] }, this['e1$JKV'][b[8]](this), e1$JV, e1JK);
}, window['e1$JKV'] = function (xdkb2) {
    if (xdkb2 && xdkb2[b[1872]] === b[10722] && xdkb2[b[201]]) {
        window[b[37757]] = xdkb2[b[201]];
        for (var mxpuv in xdkb2[b[201]]) {
            e1VJ[mxpuv] = xdkb2[b[201]][mxpuv];
        }
    } else window[b[37648]](0xb, b[37759]), console[b[620]](b[37760] + xdkb2[b[1872]]);
    window['e1$V'] = !![], window['e1JV$K']();
}, window[b[37748]] = function () {
    if (!window['e1V$'] || !window['e1$V']) return;
    var jn1z = e1VJ[b[1192]] == 0x1,
        o8h0i3 = e1VJ[b[1297]],
        dvx5pk = e1VJ[b[28711]] && e1VJ[b[28711]] > 0x0;
    if (o8h0i3 || jn1z && dvx5pk) {
        var fj1yan = e1VJ[b[28712]],
            jf03a = fj1yan && fj1yan[b[19]] == 0x9;
        jf03a && (window[b[31824]] = fj1yan);
        var za7y1n = e1VJ[b[28713]],
            zy179n = za7y1n && za7y1n[b[144]]('#')[b[19]] == 0x4;
        zy179n && (window[b[31825]] = za7y1n);
    }
}, window[b[37646]] = function () {
    window[b[31824]] = null, window[b[31825]] = null;
}, window[b[37761]] = function (j1f, qih, rsge, cw_$tl, ofi38, pkxmv, uvm97z, zn79m, zj1yn, kp9) {
    ofi38 = String(ofi38);
    var tx2bd = uvm97z,
        tlc$wb = zn79m;
    e1VJ[b[37613]][ofi38] = {
        'productid': ofi38,
        'productname': tx2bd,
        'productdesc': tlc$wb,
        'roleid': j1f,
        'rolename': qih,
        'rolelevel': rsge,
        'price': pkxmv,
        'callback': zj1yn
    }, sendApi(e1VJ[b[37621]], b[37762], {
        'game_pkg': e1VJ[b[28847]],
        'server_id': e1VJ[b[28841]][b[12618]],
        'server_name': e1VJ[b[28841]][b[28846]],
        'level': rsge,
        'uid': e1VJ[b[28845]],
        'role_id': j1f,
        'role_name': qih,
        'product_id': ofi38,
        'product_name': tx2bd,
        'product_desc': tlc$wb,
        'money': pkxmv,
        'partner_id': e1VJ[b[13640]]
    }, toPayCallBack, e1$JV, e1JK);
}, window[b[37763]] = function (cbw2t$) {
    if (cbw2t$ && (cbw2t$[b[37764]] === 0xc8 || cbw2t$[b[1872]] == b[10722])) {
        var puvmxk = e1VJ[b[37613]][String(cbw2t$[b[37765]])];
        if (puvmxk[b[869]]) puvmxk[b[869]](cbw2t$[b[37765]], cbw2t$[b[37766]], -0x1);
        eqis6r[b[37767]]({
            'cpbill': cbw2t$[b[37766]],
            'productid': cbw2t$[b[37765]],
            'productname': puvmxk[b[37768]],
            'productdesc': puvmxk[b[37769]],
            'serverid': e1VJ[b[28841]][b[12618]],
            'servername': e1VJ[b[28841]][b[28846]],
            'roleid': puvmxk[b[13644]],
            'rolename': puvmxk[b[13645]],
            'rolelevel': puvmxk[b[37770]],
            'price': puvmxk[b[31054]],
            'extension': JSON[b[5138]]({ 'cp_order_id': cbw2t$[b[37766]] })
        }, function (db$5, pm9vuk) {
            puvmxk[b[869]] && db$5 == 0x0 && puvmxk[b[869]](cbw2t$[b[37765]], cbw2t$[b[37766]], db$5);
            console[b[620]](JSON[b[5138]]({
                'type': b[37771],
                'status': db$5,
                'data': cbw2t$,
                'role_name': puvmxk[b[13645]]
            }));
            if (db$5 === 0x0) {} else {
                if (db$5 === 0x1) {} else {
                    if (db$5 === 0x2) {}
                }
            }
        });
    } else {
        var xd5bk2 = cbw2t$ ? b[37772] + cbw2t$[b[37764]] + b[37773] + cbw2t$[b[1872]] + b[37774] + cbw2t$[b[620]] : b[37775];
        window[b[37648]](0xd, b[37776] + xd5bk2), alert(xd5bk2);
    }
}, window['e1$JVK'] = function () {}, window['e1K$J'] = function (io6qh, iqh0o8, sq4, xkd25p, $b2tc5) {
    eqis6r[b[37777]](e1VJ[b[28841]][b[12618]], e1VJ[b[28841]][b[28846]] || e1VJ[b[28841]][b[12618]], io6qh, iqh0o8, sq4), sendApi(e1VJ[b[37617]], b[37778], {
        'game_pkg': e1VJ[b[28847]],
        'server_id': e1VJ[b[28841]][b[12618]],
        'role_id': io6qh,
        'uid': e1VJ[b[28845]],
        'role_name': iqh0o8,
        'role_type': xkd25p,
        'level': sq4
    });
}, window['e1KJ$'] = function (b2x, gshq6r, fyajn1, td5xb2, z9mvu, rqhis6, jazy, zn179y, gse64, zym7n9) {
    e1VJ[b[37651]] = b2x, e1VJ[b[5286]] = gshq6r, e1VJ[b[37652]] = fyajn1, eqis6r[b[37779]](e1VJ[b[28841]][b[12618]], e1VJ[b[28841]][b[28846]] || e1VJ[b[28841]][b[12618]], b2x, gshq6r, fyajn1), sendApi(e1VJ[b[37617]], b[37780], {
        'game_pkg': e1VJ[b[28847]],
        'server_id': e1VJ[b[28841]][b[12618]],
        'role_id': b2x,
        'uid': e1VJ[b[28845]],
        'role_name': gshq6r,
        'role_type': td5xb2,
        'level': fyajn1,
        'evolution': z9mvu
    });
}, window['e1$KJ'] = function (ja830f, t_w$l, qhoi86, vp7um9, an17y, of08j3, n7zm9, $2tb5c, a71z, ihq08) {
    e1VJ[b[37651]] = ja830f, e1VJ[b[5286]] = t_w$l, e1VJ[b[37652]] = qhoi86, eqis6r[b[37781]](e1VJ[b[28841]][b[12618]], e1VJ[b[28841]][b[28846]] || e1VJ[b[28841]][b[12618]], ja830f, t_w$l, qhoi86), sendApi(e1VJ[b[37617]], b[37780], {
        'game_pkg': e1VJ[b[28847]],
        'server_id': e1VJ[b[28841]][b[12618]],
        'role_id': ja830f,
        'uid': e1VJ[b[28845]],
        'role_name': t_w$l,
        'role_type': vp7um9,
        'level': qhoi86,
        'evolution': an17y
    });
}, window['e1$JK'] = function (y9z7um) {}, window['e1K$'] = function (gr4s) {
    eqis6r[b[37782]](b[37782], function (i30f8o) {
        gr4s && gr4s(i30f8o);
    });
}, window[b[26501]] = function () {
    eqis6r[b[26501]]();
}, window[b[37783]] = function () {
    eqis6r[b[26371]] && eqis6r[b[26371]]();
}, window[b[37784]] = function (oq8h0i, foj038, j1naf3, fy1nj, f1j3n, riqhs6, p5xdk2, kpdv5x) {
    kpdv5x = kpdv5x || e1VJ[b[28841]][b[12618]], sendApi(e1VJ[b[37617]], b[37785], {
        'phone': oq8h0i,
        'role_id': foj038,
        'uid': e1VJ[b[28845]],
        'game_pkg': e1VJ[b[28847]],
        'partner_id': e1VJ[b[13640]],
        'server_id': kpdv5x
    }, p5xdk2, 0x2, null, function () {
        return !![];
    });
}, window[b[11931]] = function (v97z) {
    window['e1JK$'] = v97z, window['e1JK$'] && window['e1$K'] && (console[b[620]](b[37786] + window['e1$K'][b[1353]]), window['e1JK$'](window['e1$K']), window['e1$K'] = null);
}, window['e1J$K'] = function (es4g6, $w2cbt, jn31fa, yz1) {
    window[b[567]](b[37787], {
        'game_pkg': window[b[5155]][b[28847]],
        'role_id': $w2cbt,
        'server_id': jn31fa
    }, yz1);
}, window['e1VK$J'] = function (pdukx, segr, oqi86h) {
    function zymn(na31j) {
        var pvdxk = [],
            m7yn = [],
            d$5bt2 = oqi86h || window[b[1088]][b[37788]];
        for (var zay71 in d$5bt2) {
            var d5kxpv = Number(zay71);
            (!pdukx || !pdukx[b[19]] || pdukx[b[102]](d5kxpv) != -0x1) && (m7yn[b[41]](d$5bt2[zay71]), pvdxk[b[41]]([d5kxpv, 0x3]));
        }
        window['e1P$JKV'](window[b[37789]], b[37790]) >= 0x0 ? (console[b[156]](b[37791]), eqis6r[b[37792]] && eqis6r[b[37792]](m7yn, function (uvmp9) {
            console[b[156]](b[37793]), console[b[156]](uvmp9);
            if (uvmp9 && uvmp9[b[28462]] == b[37794]) for (var yj1fn in d$5bt2) {
                if (uvmp9[d$5bt2[yj1fn]] == b[37795]) {
                    var rgh6s = Number(yj1fn);
                    for (var hqo86 = 0x0; hqo86 < pvdxk[b[19]]; hqo86++) {
                        if (pvdxk[hqo86][0x0] == rgh6s) {
                            pvdxk[hqo86][0x1] = 0x1;
                            break;
                        }
                    }
                }
            }
            window['e1P$JKV'](window[b[37789]], b[37796]) >= 0x0 ? wx[b[37797]]({
                'withSubscriptions': !![],
                'success': function (cwtb2$) {
                    var yn1z7 = cwtb2$[b[37798]][b[37799]];
                    if (yn1z7) {
                        console[b[156]](b[37800]), console[b[156]](yn1z7);
                        for (var $twc_l in d$5bt2) {
                            if (yn1z7[d$5bt2[$twc_l]] == b[37795]) {
                                var uvmz7 = Number($twc_l);
                                for (var txbd5 = 0x0; txbd5 < pvdxk[b[19]]; txbd5++) {
                                    if (pvdxk[txbd5][0x0] == uvmz7) {
                                        pvdxk[txbd5][0x1] = 0x2;
                                        break;
                                    }
                                }
                            }
                        }
                        console[b[156]](pvdxk), segr && segr(pvdxk);
                    } else console[b[156]](b[37801]), console[b[156]](cwtb2$), console[b[156]](pvdxk), segr && segr(pvdxk);
                },
                'fail': function () {
                    console[b[156]](b[37802]), console[b[156]](pvdxk), segr && segr(pvdxk);
                }
            }) : (console[b[156]](b[37803] + window[b[37789]]), console[b[156]](pvdxk), segr && segr(pvdxk));
        })) : (console[b[156]](b[37804] + window[b[37789]]), console[b[156]](pvdxk), segr && segr(pvdxk)), wx[b[37805]](zymn);
    }
    wx[b[37806]](zymn);
}, window['e1VKJ$'] = {
    'isSuccess': ![],
    'level': b[33073],
    'isCharging': ![]
}, window['e1V$KJ'] = function (rhqoi) {
    wx[b[37807]]({
        'success': function (twb$lc) {
            var kduvx = window['e1VKJ$'];
            kduvx[b[37808]] = !![], kduvx[b[5262]] = Number(twb$lc[b[5262]])[b[4844]](0x0), kduvx[b[37809]] = twb$lc[b[37809]], rhqoi && rhqoi(kduvx[b[37808]], kduvx[b[5262]], kduvx[b[37809]]);
        },
        'fail': function (oq6i8h) {
            console[b[156]](b[37810], oq6i8h[b[28462]]);
            var g6hs = window['e1VKJ$'];
            rhqoi && rhqoi(g6hs[b[37808]], g6hs[b[5262]], g6hs[b[37809]]);
        }
    });
}, window[b[13003]] = function (x25td) {
    wx[b[13003]]({
        'success': function (z7ny1) {
            x25td && x25td(!![], z7ny1);
        },
        'fail': function (kdu) {
            x25td && x25td(![], kdu);
        }
    });
}, window[b[13005]] = function (sqhg6) {
    if (sqhg6) wx[b[13005]](sqhg6);
}, window[b[28441]] = function (qi6o8) {
    wx[b[28441]](qi6o8);
}, window[b[567]] = function (gqhrs6, fa3nj1, ih6q, wt$cbl, x52bdk, ih0qo, w$2tc, c$w_l) {
    if (wt$cbl == undefined) wt$cbl = 0x1;
    wx[b[1013]]({
        'url': gqhrs6,
        'method': w$2tc || b[28453],
        'responseType': b[5047],
        'data': fa3nj1,
        'header': { 'content-type': c$w_l || b[37667] },
        'success': function (vpd5k) {
            DEBUG && console[b[156]](b[37811], gqhrs6, info, vpd5k);
            if (vpd5k && vpd5k[b[28460]] == 0xc8) {
                var t_cl$w = vpd5k[b[201]];
                !ih0qo || ih0qo(t_cl$w) ? ih6q && ih6q(t_cl$w) : window[b[37812]](gqhrs6, fa3nj1, ih6q, wt$cbl, x52bdk, ih0qo, vpd5k);
            } else window[b[37812]](gqhrs6, fa3nj1, ih6q, wt$cbl, x52bdk, ih0qo, vpd5k);
        },
        'fail': function (upkvm9) {
            DEBUG && console[b[156]](b[37813], gqhrs6, info, upkvm9), window[b[37812]](gqhrs6, fa3nj1, ih6q, wt$cbl, x52bdk, ih0qo, upkvm9);
        },
        'complete': function () {}
    });
}, window[b[37812]] = function (ctl$w_, p2dx5, ukv9m, fjo308, v7uz9m, tl$w, o30fi8) {
    fjo308 - 0x1 > 0x0 ? setTimeout(function () {
        window[b[567]](ctl$w_, p2dx5, ukv9m, fjo308 - 0x1, v7uz9m, tl$w);
    }, 0x3e8) : v7uz9m && v7uz9m(JSON[b[5138]]({
        'url': ctl$w_,
        'response': o30fi8
    }));
}, window[b[37814]] = function ($b5, qioh0, bctwl, h03io, kxpdv5, of803j, uz7vm) {
    !bctwl && (bctwl = {});
    var $lwbt = Math[b[46]](Date[b[625]]() / 0x3e8);
    bctwl[b[1427]] = $lwbt, bctwl[b[37815]] = qioh0;
    var o68qih = Object[b[18]](bctwl)[b[212]](),
        x2d5p = '',
        n1z9 = '';
    for (var zmu97 = 0x0; zmu97 < o68qih[b[19]]; zmu97++) {
        x2d5p = x2d5p + (zmu97 == 0x0 ? '' : '&') + o68qih[zmu97] + bctwl[o68qih[zmu97]], n1z9 = n1z9 + (zmu97 == 0x0 ? '' : '&') + o68qih[zmu97] + '=' + encodeURIComponent(bctwl[o68qih[zmu97]]);
    }
    x2d5p = x2d5p + e1VJ[b[37623]];
    var pxmu = b[37816] + md5(x2d5p);
    send($b5 + '?' + n1z9 + (n1z9 == '' ? '' : '&') + pxmu, null, h03io, kxpdv5, of803j, uz7vm || function (a1nfj) {
        return a1nfj[b[1872]] == b[10722];
    }, null, b[37817]);
}, window['e1V$JK'] = function (p9uvkm, lwc$) {
    var t2wc$b = 0x0;
    e1VJ[b[28841]] && (t2wc$b = e1VJ[b[28841]][b[12618]]), sendApi(e1VJ[b[37619]], b[37818], {
        'partnerId': e1VJ[b[13640]],
        'gamePkg': e1VJ[b[28847]],
        'logTime': Math[b[46]](Date[b[625]]() / 0x3e8),
        'platformUid': e1VJ[b[28848]],
        'type': p9uvkm,
        'serverId': t2wc$b
    }, null, 0x2, null, function () {
        return !![];
    });
}, window['e1VJK$'] = function (wtc2) {
    sendApi(e1VJ[b[37617]], b[37819], {
        'partner_id': e1VJ[b[13640]],
        'uid': e1VJ[b[28845]],
        'version': e1VJ[b[5987]],
        'game_pkg': e1VJ[b[28847]],
        'device': e1VJ[b[28849]]
    }, e1VJ$K, e1$JV, e1JK);
}, window['e1VJ$K'] = function (h03oi) {
    if (h03oi && h03oi[b[1872]] === b[10722] && h03oi[b[201]]) {
        h03oi[b[201]][b[125]]({
            'id': -0x2,
            'name': b[37820]
        }), h03oi[b[201]][b[125]]({
            'id': -0x1,
            'name': b[37821]
        }), e1VJ[b[37519]] = h03oi[b[201]];
        if (window[b[13833]]) window[b[13833]][b[37528]]();
    } else {
        e1VJ[b[37523]] = ![];
        var s6qgr = h03oi ? h03oi[b[1872]] : '';
        window[b[37648]](0x7, b[37822] + s6qgr), window['e1K$VJ'](b[37823] + s6qgr);
    }
}, window['e1K$V'] = function (az1njy) {
    sendApi(e1VJ[b[37617]], b[37824], {
        'partner_id': e1VJ[b[13640]],
        'uid': e1VJ[b[28845]],
        'version': e1VJ[b[5987]],
        'game_pkg': e1VJ[b[28847]],
        'device': e1VJ[b[28849]]
    }, e1KV$, e1$JV, e1JK);
}, window['e1KV$'] = function (b25dkx) {
    e1VJ[b[37531]] = ![];
    if (b25dkx && b25dkx[b[1872]] === b[10722] && b25dkx[b[201]]) {
        for (var r4qgs = 0x0; r4qgs < b25dkx[b[201]][b[19]]; r4qgs++) {
            b25dkx[b[201]][r4qgs][b[644]] = e1V$K(b25dkx[b[201]][r4qgs]);
        }
        e1VJ[b[37529]][-0x1] = window[b[37825]](b25dkx[b[201]]), window[b[13833]][b[37530]](-0x1);
    } else {
        var my7nz = b25dkx ? b25dkx[b[1872]] : '';
        window[b[37648]](0x8, b[37826] + my7nz), window['e1K$VJ'](b[37827] + my7nz);
    }
}, window[b[37828]] = function (j80of) {
    sendApi(e1VJ[b[37617]], b[37824], {
        'partner_id': e1VJ[b[13640]],
        'uid': e1VJ[b[28845]],
        'version': e1VJ[b[5987]],
        'game_pkg': e1VJ[b[28847]],
        'device': e1VJ[b[28849]]
    }, j80of, e1$JV, e1JK);
}, window['e1$KV'] = function (mzy9n, f3ja1n) {
    sendApi(e1VJ[b[37617]], b[37829], {
        'partner_id': e1VJ[b[13640]],
        'uid': e1VJ[b[28845]],
        'version': e1VJ[b[5987]],
        'game_pkg': e1VJ[b[28847]],
        'device': e1VJ[b[28849]],
        'server_group_id': f3ja1n
    }, e1$VK, e1$JV, e1JK);
}, window['e1$VK'] = function (sqirh6) {
    e1VJ[b[37531]] = ![];
    if (sqirh6 && sqirh6[b[1872]] === b[10722] && sqirh6[b[201]] && sqirh6[b[201]][b[201]]) {
        var ho03i = sqirh6[b[201]][b[37830]],
            jz1 = [];
        for (var db = 0x0; db < sqirh6[b[201]][b[201]][b[19]]; db++) {
            sqirh6[b[201]][b[201]][db][b[644]] = e1V$K(sqirh6[b[201]][b[201]][db]), (jz1[b[19]] == 0x0 || sqirh6[b[201]][b[201]][db][b[644]] != 0x0) && (jz1[jz1[b[19]]] = sqirh6[b[201]][b[201]][db]);
        }
        e1VJ[b[37529]][ho03i] = window[b[37825]](jz1), window[b[13833]][b[37530]](ho03i);
    } else {
        var kvpxud = sqirh6 ? sqirh6[b[1872]] : '';
        window[b[37648]](0x9, b[37831] + kvpxud), window['e1K$VJ'](b[37832] + kvpxud);
    }
}, window['e1P$JV'] = function (f10j) {
    sendApi(e1VJ[b[37617]], b[37833], {
        'partner_id': e1VJ[b[13640]],
        'uid': e1VJ[b[28845]],
        'version': e1VJ[b[5987]],
        'game_pkg': e1VJ[b[28847]],
        'device': e1VJ[b[28849]]
    }, reqServerRecommendCallBack, e1$JV, e1JK);
}, window[b[37834]] = function (af10) {
    e1VJ[b[37531]] = ![];
    if (af10 && af10[b[1872]] === b[10722] && af10[b[201]]) {
        for (var l$ctwb = 0x0; l$ctwb < af10[b[201]][b[19]]; l$ctwb++) {
            af10[b[201]][l$ctwb][b[644]] = e1V$K(af10[b[201]][l$ctwb]);
        }
        e1VJ[b[37529]][-0x2] = window[b[37825]](af10[b[201]]), window[b[13833]][b[37530]](-0x2);
    } else {
        var ish6rq = af10 ? af10[b[1872]] : '';
        window[b[37648]](0xa, b[37835] + ish6rq), alert(b[37836] + ish6rq);
    }
}, window[b[37825]] = function (muvpk) {
    return muvpk;
}, window['e1VK$'] = function (z9my7u, b2t$wc) {
    z9my7u = z9my7u || e1VJ[b[28841]][b[12618]], sendApi(e1VJ[b[37617]], b[37837], {
        'type': '4',
        'game_pkg': e1VJ[b[28847]],
        'server_id': z9my7u
    }, b2t$wc);
}, window[b[37838]] = function (iqshr6, $2t5b, qs4, f0a1) {
    qs4 = qs4 || e1VJ[b[28841]][b[12618]], sendApi(e1VJ[b[37617]], b[37839], {
        'type': iqshr6,
        'game_pkg': $2t5b,
        'server_id': qs4
    }, f0a1);
}, window[b[37840]] = function (jf8o30, kpd5) {
    sendApi(e1VJ[b[37617]], b[37841], { 'game_pkg': jf8o30 }, kpd5);
}, window['e1V$K'] = function (qi8h0o) {
    if (qi8h0o) {
        if (qi8h0o[b[644]] == 0x1) {
            if (qi8h0o[b[37842]] == 0x1) return 0x2;else return 0x1;
        } else return qi8h0o[b[644]] == 0x0 ? 0x0 : -0x1;
    }
    return -0x1;
}, window['e1JK$V'] = function (y1njfa, fo8j) {
    e1VJ[b[37843]] = {
        'step': y1njfa,
        'server_id': fo8j
    };
    var wlt_ = this;
    e1KV$J({ 'title': b[37844] }), sendApi(e1VJ[b[37617]], b[37845], {
        'partner_id': e1VJ[b[13640]],
        'uid': e1VJ[b[28845]],
        'game_pkg': e1VJ[b[28847]],
        'server_id': fo8j,
        'platform': e1VJ[b[28799]],
        'platform_uid': e1VJ[b[28848]],
        'check_login_time': e1VJ[b[37715]],
        'check_login_sign': e1VJ[b[37714]],
        'version_name': e1VJ[b[5156]]
    }, e1JKV$, e1$JV, e1JK, function (e6sgr) {
        return e6sgr[b[1872]] == b[10722] || e6sgr[b[620]] == b[37846] || e6sgr[b[620]] == b[37847];
    });
}, window['e1JKV$'] = function (upvm9) {
    var y7an1 = this;
    if (upvm9 && upvm9[b[1872]] === b[10722] && upvm9[b[201]]) {
        var ayz71 = e1VJ[b[28841]];
        ayz71[b[37848]] = e1VJ[b[37626]], ayz71[b[12601]] = String(upvm9[b[201]][b[37849]]), ayz71[b[28801]] = parseInt(upvm9[b[201]][b[1427]]);
        if (upvm9[b[201]][b[28800]]) ayz71[b[28800]] = parseInt(upvm9[b[201]][b[28800]]);else ayz71[b[28800]] = parseInt(upvm9[b[201]][b[12618]]);
        ayz71[b[37850]] = 0x0, ayz71[b[5152]] = e1VJ[b[37755]], ayz71[b[37851]] = upvm9[b[201]][b[37852]], ayz71[b[37853]] = upvm9[b[201]][b[37853]];
        if (upvm9[b[201]][b[28805]]) ayz71[b[28805]] = parseInt(upvm9[b[201]][b[28805]]);
        console[b[156]](b[37854] + JSON[b[5138]](ayz71[b[37853]])), e1VJ[b[1192]] == 0x1 && ayz71[b[37853]] && ayz71[b[37853]][b[37855]] == 0x1 && (e1VJ[b[37475]] = 0x1, window[b[37605]][b[676]][b[37584]]()), e1J$KV();
    } else {
        if (e1VJ[b[37843]][b[5069]] >= 0x3) {
            var mzny79 = upvm9 ? upvm9[b[1872]] : '';
            window[b[37648]](0xc, b[37856] + mzny79), e1JK(JSON[b[5138]](upvm9)), window['e1K$VJ'](b[37857] + mzny79);
        } else sendApi(e1VJ[b[37617]], b[37694], {
            'platform': e1VJ[b[37615]],
            'partner_id': e1VJ[b[13640]],
            'token': e1VJ[b[37692]],
            'game_pkg': e1VJ[b[28847]],
            'deviceId': e1VJ[b[28849]],
            'scene': b[37695] + e1VJ[b[37625]]
        }, function (uv9mz7) {
            if (!uv9mz7 || uv9mz7[b[1872]] != b[10722]) {
                window['e1K$VJ'](b[37711] + uv9mz7 && uv9mz7[b[1872]]);
                return;
            }
            e1VJ[b[37714]] = String(uv9mz7[b[12601]]), e1VJ[b[37715]] = String(uv9mz7[b[1427]]), setTimeout(function () {
                e1JK$V(e1VJ[b[37843]][b[5069]] + 0x1, e1VJ[b[37843]][b[12618]]);
            }, 0x5dc);
        }, e1$JV, e1JK, function (m7vpu) {
            return m7vpu[b[1872]] == b[10722] || m7vpu[b[1872]] == b[29190];
        });
    }
}, window['e1J$KV'] = function () {
    ServerLoading[b[676]][b[37582]](e1VJ[b[1192]]), window['e1$J'] = !![], window['e1JVK$']();
}, window['e1J$VK'] = function () {
    if (window['e1J$'] && window['e1V$J'] && window[b[37571]] && window[b[37581]] && window['e1VJ$'] && window['e1V$']) {
        if (!window[b[37348]][b[676]]) {
            console[b[156]](b[37858] + window[b[37348]][b[676]]);
            var gq6s4 = wx[b[28424]](),
                hsrg6q = gq6s4[b[1353]] ? gq6s4[b[1353]] : 0x0,
                z1n7ay = {
                'cdn': window[b[5155]][b[5152]],
                'spareCdn': window[b[5155]][b[28471]],
                'newRegister': window[b[5155]][b[1192]],
                'wxPC': window[b[5155]][b[28473]],
                'wxIOS': window[b[5155]][b[1649]],
                'wxAndroid': window[b[5155]][b[12442]],
                'wxParam': {
                    'limitLoad': window[b[5155]]['e1PK$JV'],
                    'benchmarkLevel': window[b[5155]]['e1PKV$J'],
                    'wxFrom': window[b[1088]][b[33]] == b[37859] ? 0x1 : 0x0,
                    'wxSDKVersion': window[b[37789]],
                    'qudao': b[37860]
                },
                'configType': window[b[5155]][b[5154]],
                'exposeType': window[b[5155]][b[1275]],
                'scene': hsrg6q,
                'video_type': window[b[5155]][b[28987]],
                'ad_flag': window[b[5155]][b[28986]]
            };
            if (window[b[37757]]) for (var qsi6 in window[b[37757]]) {
                if (!z1n7ay[qsi6]) z1n7ay[qsi6] = window[b[37757]][qsi6];
            }
            new window[b[37348]](z1n7ay, window[b[5155]][b[640]], window['e1PK$VJ']);
        }
    }
}, window['e1JVK$'] = function () {
    if (window['e1J$'] && window['e1V$J'] && window[b[37571]] && window[b[37581]] && window['e1VJ$'] && window['e1V$'] && window['e1$J'] && window['e1$V']) {
        e1KVJ$();
        if (!e1J$V) {
            e1J$V = !![];
            if (!window[b[37348]][b[676]]) window['e1J$VK']();
            var n79zm = 0x0,
                anzyj1 = wx[b[37861]]();
            anzyj1 && (window[b[5155]][b[37862]] && (n79zm = anzyj1[b[858]]), console[b[620]](b[37863] + anzyj1[b[858]] + b[37864] + anzyj1[b[1898]] + b[37865] + anzyj1[b[1900]] + b[37866] + anzyj1[b[1899]] + b[37867] + anzyj1[b[710]] + b[37868] + anzyj1[b[711]]));
            var uvxkdp = {};
            for (const tc5$b in e1VJ[b[28841]]) {
                uvxkdp[tc5$b] = e1VJ[b[28841]][tc5$b];
            }
            var mvk9up = {
                'channel': window[b[5155]][b[13649]],
                'account': window[b[5155]][b[28845]],
                'userId': window[b[5155]][b[13638]],
                'cdn': window[b[5155]][b[5152]],
                'data': window[b[5155]][b[201]],
                'package': window[b[5155]][b[192]],
                'newRegister': window[b[5155]][b[1192]],
                'pkgName': window[b[5155]][b[28847]],
                'partnerId': window[b[5155]][b[13640]],
                'platform_uid': window[b[5155]][b[28848]],
                'deviceId': window[b[5155]][b[28849]],
                'selectedServer': uvxkdp,
                'configType': window[b[5155]][b[5154]],
                'exposeType': window[b[5155]][b[1275]],
                'debugUsers': window[b[5155]][b[13786]],
                'wxMenuTop': n79zm,
                'wxShield': window[b[5155]][b[1297]],
                'encryptParam': window[b[5155]][b[28994]],
                'wx_channel': window[b[5155]][b[28992]],
                'zsy_tp_state': window[b[5155]][b[28993]]
            };
            if (window[b[37757]]) for (var ior6q in window[b[37757]]) {
                mvk9up[ior6q] = window[b[37757]][ior6q];
            }
            window[b[37348]][b[676]][b[28863]](mvk9up);
            if (e1VJ[b[28841]] && e1VJ[b[28841]][b[12618]]) localStorage[b[1020]](b[37717] + e1VJ[b[28847]] + e1VJ[b[28845]], e1VJ[b[28841]][b[12618]]);
        }
    } else console[b[620]](b[37869] + window['e1J$'] + b[37870] + window['e1V$J'] + b[37871] + window[b[37571]] + b[37872] + window[b[37581]] + b[37873] + window['e1VJ$'] + b[37874] + window['e1V$'] + b[37875] + window['e1$J'] + b[37876] + window['e1$V']);
}, window[b[37877]] = function (x2pd) {
    if (!window[b[13488]]) {
        console[b[199]](b[37878]);
        return;
    }
    var d$25 = x2pd[b[880]];
    d$25 == 0x1 ? window[b[13488]][b[608]](0x2327, x2pd) : window[b[13488]][b[623]](0x2327);
};