var b = wx.$e;
import 'Z_110main.js';