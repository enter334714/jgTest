var b = wx.$e;
require(b[37349]);