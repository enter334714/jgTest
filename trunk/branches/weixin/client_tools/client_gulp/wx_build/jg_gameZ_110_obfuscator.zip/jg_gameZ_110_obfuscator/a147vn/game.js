var b = wx.$e;
require('./a3ik.js'), window[b[225]][b[211]][b[12]] = null, window['client_pb'] = require('./fcklr.js'), window[b[556]] = window[b[225]][b[152]][b[53]](client_pb);