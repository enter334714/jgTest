var O = wx.$C;
import 'hhhhmain.js';