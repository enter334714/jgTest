var O = wx.$C;
console[O[100078]](O[129156]), window[O[129157]], wx[O[129158]](function ($5pluc) {
  if ($5pluc) {
    if ($5pluc[O[104549]]) {
      var hdqw0 = window[O[100557]][O[129159]][O[104728]](new RegExp(/\./, 'g'), '_'),
          hj0w = $5pluc[O[104549]],
          j09h = hj0w[O[112095]](/(hhhhhhhh\/hhhhgame.js:)[0-9]{1,60}(:)/g);if (j09h) for (var moltc5 = 0x0; moltc5 < j09h[O[100013]]; moltc5++) {
        if (j09h[moltc5] && j09h[moltc5][O[100013]] > 0x0) {
          var n2yas6 = parseInt(j09h[moltc5][O[104728]](O[129160], '')[O[104728]](':', ''));hj0w = hj0w[O[104728]](j09h[moltc5], j09h[moltc5][O[104728]](':' + n2yas6 + ':', ':' + (n2yas6 - 0x2) + ':'));
        }
      }hj0w = hj0w[O[104728]](new RegExp(O[129161], 'g'), O[129162] + hdqw0 + O[125443]), hj0w = hj0w[O[104728]](new RegExp(O[129163], 'g'), O[129162] + hdqw0 + O[125443]), $5pluc[O[104549]] = hj0w;
    }var opl5uc = { 'id': window['$h6R'][O[129164]], 'role': window['$h6R'][O[104670]], 'level': window['$h6R'][O[129165]], 'user': window['$h6R'][O[125343]], 'version': window['$h6R'][O[100101]], 'cdn': window['$h6R'][O[104547]], 'pkgName': window['$h6R'][O[125344]], 'gamever': window[O[100557]][O[129159]], 'serverid': window['$h6R'][O[125338]] ? window['$h6R'][O[125338]][O[111549]] : 0x0, 'systemInfo': window[O[129166]], 'error': O[129167], 'stack': $5pluc ? $5pluc[O[104549]] : '' },
        nv_ay = JSON[O[104533]](opl5uc);console[O[100125]](O[129168] + nv_ay), (!window[O[129157]] || window[O[129157]] != opl5uc[O[100125]]) && (window[O[129157]] = opl5uc[O[100125]], window['$hY6'](opl5uc));
  }
});import 'hhhmd5min.js';import 'hhhzlibs.js';window[O[129169]] = require(O[129170]);import 'hhhindex.js';import 'hhhlibsmin.js';import 'hhhwxmini.js';import 'hhhinitmin.js';console[O[100078]](O[129171]), console[O[100078]](O[129172]), $hY6UR({ 'title': O[129173] });var h_zj89dr = { '$hXYR6U': !![] };new window[O[129174]](h_zj89dr), window[O[129174]][O[100148]]['$hXU6RY']();if (window['$hXY6RU']) clearInterval(window['$hXY6RU']);window['$hXY6RU'] = null, window['$hXURY6'] = function (clo5tm, sna6y_) {
  if (!clo5tm || !sna6y_) return 0x0;clo5tm = clo5tm[O[100015]]('.'), sna6y_ = sna6y_[O[100015]]('.');const djhz = Math[O[100853]](clo5tm[O[100013]], sna6y_[O[100013]]);while (clo5tm[O[100013]] < djhz) {
    clo5tm[O[100029]]('0');
  }while (sna6y_[O[100013]] < djhz) {
    sna6y_[O[100029]]('0');
  }for (var wdz9h = 0x0; wdz9h < djhz; wdz9h++) {
    const ygsnv = parseInt(clo5tm[wdz9h]),
          q0137 = parseInt(sna6y_[wdz9h]);if (ygsnv > q0137) return 0x1;else {
      if (ygsnv < q0137) return -0x1;
    }
  }return 0x0;
}, window[O[129175]] = wx[O[129176]]()[O[129175]], console[O[100482]](O[129177] + window[O[129175]]);var h_fq31 = wx[O[129178]]();h_fq31[O[129179]](function (hjwd0) {
  console[O[100482]](O[129180] + hjwd0[O[129181]]);
}), h_fq31[O[129182]](function () {
  wx[O[129183]]({ 'title': O[129184], 'content': O[129185], 'showCancel': ![], 'success': function (sny2a) {
      h_fq31[O[129186]]();
    } });
}), h_fq31[O[129187]](function () {
  console[O[100482]](O[129188]);
}), window['$hXUR6Y'] = function () {
  console[O[100482]](O[129189]);var gvfns_ = wx[O[129190]]({ 'name': O[129191], 'success': function (g_f3) {
      console[O[100482]](O[129192]), console[O[100482]](g_f3), g_f3 && g_f3[O[125527]] == O[129193] ? (window['$hRU'] = !![], window['$hRU6Y'](), window['$hR6YU']()) : setTimeout(function () {
        window['$hXUR6Y']();
      }, 0x1f4);
    }, 'fail': function (nys2a6) {
      console[O[100482]](O[129194]), console[O[100482]](nys2a6), setTimeout(function () {
        window['$hXUR6Y']();
      }, 0x1f4);
    } });gvfns_ && gvfns_[O[129195]](rc8up => {});
}, window['$hX6YRU'] = function () {
  console[O[100482]](O[129196]);var c$l5u = wx[O[129190]]({ 'name': O[129197], 'success': function (bei6a2) {
      console[O[100482]](O[129198]), console[O[100482]](bei6a2), bei6a2 && bei6a2[O[125527]] == O[129193] ? (window['$h6UR'] = !![], window['$hRU6Y'](), window['$hR6YU']()) : setTimeout(function () {
        window['$hX6YRU']();
      }, 0x1f4);
    }, 'fail': function (a62biy) {
      console[O[100482]](O[129199]), console[O[100482]](a62biy), setTimeout(function () {
        window['$hX6YRU']();
      }, 0x1f4);
    } });c$l5u && c$l5u[O[129195]](ul8c$p => {});
}, window[O[129200]] = function () {
  window['$hXURY6'](window[O[129175]], O[129201]) >= 0x0 ? (console[O[100482]](O[129202] + window[O[129175]] + O[129203]), window['$h6Y'](), window['$hXUR6Y'](), window['$hX6YRU']()) : (window['$h6RY'](O[129204], window[O[129175]]), wx[O[129183]]({ 'title': O[106391], 'content': O[129205] }));
}, window[O[129166]] = '', wx[O[129206]]({ 'success'(cul8$) {
    window[O[129166]] = O[129207] + cul8$[O[129208]] + O[129209] + cul8$[O[129210]] + O[129211] + cul8$[O[104741]] + O[129212] + cul8$[O[100475]] + O[129213] + cul8$[O[125315]] + O[129214] + cul8$[O[129175]] + O[129215] + cul8$[O[109346]], console[O[100482]](window[O[129166]]), console[O[100482]](O[129216] + cul8$[O[129217]] + O[129218] + cul8$[O[129219]] + O[129220] + cul8$[O[129221]] + O[129222] + cul8$[O[129223]] + O[129224] + cul8$[O[129225]] + O[129226] + cul8$[O[129227]] + O[129228] + (cul8$[O[129229]] ? cul8$[O[129229]][O[100323]] + ',' + cul8$[O[129229]][O[101216]] + ',' + cul8$[O[129229]][O[101218]] + ',' + cul8$[O[129229]][O[101217]] : ''));var lpc8u$ = cul8$[O[100475]] ? cul8$[O[100475]][O[112392]]() : '',
        hd0jx = cul8$[O[129210]] ? cul8$[O[129210]][O[112392]]()[O[104728]]('\x20', '') : '';window['$h6R'][O[101074]] = lpc8u$[O[100115]](O[129230]) != -0x1, window['$h6R'][O[111371]] = lpc8u$[O[100115]](O[129017]) != -0x1, window['$h6R'][O[129231]] = lpc8u$[O[100115]](O[129230]) != -0x1 || lpc8u$[O[100115]](O[129017]) != -0x1, window['$h6R'][O[125051]] = lpc8u$[O[100115]](O[129232]) != -0x1 || lpc8u$[O[100115]](O[129233]) != -0x1, window['$h6R'][O[129234]] = cul8$[O[125315]] ? cul8$[O[125315]][O[112392]]() : '', window['$h6R']['$hXYUR6'] = ![], window['$h6R']['$hXY6UR'] = 0x2;if (lpc8u$[O[100115]](O[129017]) != -0x1) {
      if (cul8$[O[109346]] >= 0x18) window['$h6R']['$hXY6UR'] = 0x3;else window['$h6R']['$hXY6UR'] = 0x2;
    } else {
      if (lpc8u$[O[100115]](O[129230]) != -0x1) {
        if (cul8$[O[109346]] && cul8$[O[109346]] >= 0x14) window['$h6R']['$hXY6UR'] = 0x3;else {
          if (hd0jx[O[100115]](O[129235]) != -0x1 || hd0jx[O[100115]](O[129236]) != -0x1 || hd0jx[O[100115]](O[129237]) != -0x1 || hd0jx[O[100115]](O[129238]) != -0x1 || hd0jx[O[100115]](O[129239]) != -0x1) window['$h6R']['$hXY6UR'] = 0x2;else window['$h6R']['$hXY6UR'] = 0x3;
        }
      } else window['$h6R']['$hXY6UR'] = 0x2;
    }console[O[100482]](O[129240] + window['$h6R']['$hXYUR6'] + O[129241] + window['$h6R']['$hXY6UR']);
  } }), wx[O[129242]]({ 'success': function (rjhdz9) {
    console[O[100482]](O[129243] + rjhdz9[O[104646]] + O[129244] + rjhdz9[O[129245]]);
  } }), wx[O[129246]]({ 'success': function (p5cul$) {
    console[O[100482]](O[129247] + p5cul$[O[129248]]);
  } }), wx[O[129249]]({ 'keepScreenOn': !![] }), wx[O[129250]](function (byi6) {
  console[O[100482]](O[129247] + byi6[O[129248]] + O[129251] + byi6[O[129252]]);
}), wx[O[110881]](function (z8pru) {
  window['$hUY'] = z8pru, window['$hRYU'] && window['$hUY'] && (console[O[100078]](O[129253] + window['$hUY'][O[100776]]), window['$hRYU'](window['$hUY']), window['$hUY'] = null);
}), window[O[129254]] = 0x0, window['$hX6URY'] = 0x0, window[O[129255]] = null, wx[O[129256]](function () {
  window['$hX6URY']++;var q3f4 = Date[O[100083]]();(window[O[129254]] == 0x0 || q3f4 - window[O[129254]] > 0x1d4c0) && (console[O[100096]](O[129257]), wx[O[111948]]());if (window['$hX6URY'] >= 0x2) {
    window['$hX6URY'] = 0x0, console[O[100125]](O[129258]), wx[O[129259]]('0', 0x1);if (window['$h6R'] && window['$h6R'][O[101074]]) window['$h6RY'](O[129260], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});