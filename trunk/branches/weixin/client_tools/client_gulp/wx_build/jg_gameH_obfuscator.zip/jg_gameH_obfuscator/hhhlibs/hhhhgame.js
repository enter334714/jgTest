var O = wx.$C;
console[O[0x4e]](O[0x76f9]), window[O[0x76fa]], wx[O[0x76fb]](function (g3f1v) {
  if (g3f1v) {
    if (g3f1v[O[0x1280]]) {
      var zr9hj = window[O[0x22e]][O[0x76fc]][O[0x1334]](new RegExp(/\./, 'g'), '_'),
          sngv = g3f1v[O[0x1280]],
          rj89z = sngv[O[0x309a]](/(hhhhhhhh\/hhhhgame.js:)[0-9]{1,60}(:)/g);if (rj89z) for (var _gfnv4 = 0x0; _gfnv4 < rj89z[O[0xd]]; _gfnv4++) {
        if (rj89z[_gfnv4] && rj89z[_gfnv4][O[0xd]] > 0x0) {
          var jzh9dr = parseInt(rj89z[_gfnv4][O[0x1334]](O[0x76fd], '')[O[0x1334]](':', ''));sngv = sngv[O[0x1334]](rj89z[_gfnv4], rj89z[_gfnv4][O[0x1334]](':' + jzh9dr + ':', ':' + (jzh9dr - 0x2) + ':'));
        }
      }sngv = sngv[O[0x1334]](new RegExp(O[0x76fe], 'g'), O[0x76ff] + zr9hj + O[0x661e]), sngv = sngv[O[0x1334]](new RegExp(O[0x7700], 'g'), O[0x76ff] + zr9hj + O[0x661e]), g3f1v[O[0x1280]] = sngv;
    }var u$pzr8 = { 'id': window['$h6R'][O[0x7701]], 'role': window['$h6R'][O[0x12f9]], 'level': window['$h6R'][O[0x7702]], 'user': window['$h6R'][O[0x65bb]], 'version': window['$h6R'][O[0x65]], 'cdn': window['$h6R'][O[0x127e]], 'pkgName': window['$h6R'][O[0x65bc]], 'gamever': window[O[0x22e]][O[0x76fc]], 'serverid': window['$h6R'][O[0x65b6]] ? window['$h6R'][O[0x65b6]][O[0x2e25]] : 0x0, 'systemInfo': window[O[0x7703]], 'error': O[0x7704], 'stack': g3f1v ? g3f1v[O[0x1280]] : '' },
        dwqxh0 = JSON[O[0x1270]](u$pzr8);console[O[0x7d]](O[0x7705] + dwqxh0), (!window[O[0x76fa]] || window[O[0x76fa]] != u$pzr8[O[0x7d]]) && (window[O[0x76fa]] = u$pzr8[O[0x7d]], window['$hY6'](u$pzr8));
  }
});import 'hhhmd5min.js';import 'hhhzlibs.js';window[O[0x7706]] = require(O[0x7707]);import 'hhhindex.js';import 'hhhlibsmin.js';import 'hhhwxmini.js';import 'hhhinitmin.js';console[O[0x4e]](O[0x7708]), console[O[0x4e]](O[0x7709]), $hY6UR({ 'title': O[0x770a] });var h_sa2yi = { '$hXYR6U': !![] };new window[O[0x770b]](h_sa2yi), window[O[0x770b]][O[0x94]]['$hXU6RY']();if (window['$hXY6RU']) clearInterval(window['$hXY6RU']);window['$hXY6RU'] = null, window['$hXURY6'] = function (eai, nsfg) {
  if (!eai || !nsfg) return 0x0;eai = eai[O[0xf]]('.'), nsfg = nsfg[O[0xf]]('.');const x7q3 = Math[O[0x36c]](eai[O[0xd]], nsfg[O[0xd]]);while (eai[O[0xd]] < x7q3) {
    eai[O[0x1d]]('0');
  }while (nsfg[O[0xd]] < x7q3) {
    nsfg[O[0x1d]]('0');
  }for (var u8cr$p = 0x0; u8cr$p < x7q3; u8cr$p++) {
    const _g4fvn = parseInt(eai[u8cr$p]),
          upl5$c = parseInt(nsfg[u8cr$p]);if (_g4fvn > upl5$c) return 0x1;else {
      if (_g4fvn < upl5$c) return -0x1;
    }
  }return 0x0;
}, window[O[0x770c]] = wx[O[0x770d]]()[O[0x770c]], console[O[0x1e2]](O[0x770e] + window[O[0x770c]]);var h_zhrdj = wx[O[0x770f]]();h_zhrdj[O[0x7710]](function (y_an) {
  console[O[0x1e2]](O[0x7711] + y_an[O[0x7712]]);
}), h_zhrdj[O[0x7713]](function () {
  wx[O[0x7714]]({ 'title': O[0x7715], 'content': O[0x7716], 'showCancel': ![], 'success': function (p5cto) {
      h_zhrdj[O[0x7717]]();
    } });
}), h_zhrdj[O[0x7718]](function () {
  console[O[0x1e2]](O[0x7719]);
}), window['$hXUR6Y'] = function () {
  console[O[0x1e2]](O[0x771a]);var jzd9 = wx[O[0x771b]]({ 'name': O[0x771c], 'success': function (c5olu) {
      console[O[0x1e2]](O[0x771d]), console[O[0x1e2]](c5olu), c5olu && c5olu[O[0x667d]] == O[0x771e] ? (window['$hRU'] = !![], window['$hRU6Y'](), window['$hR6YU']()) : setTimeout(function () {
        window['$hXUR6Y']();
      }, 0x1f4);
    }, 'fail': function (x7q10w) {
      console[O[0x1e2]](O[0x771f]), console[O[0x1e2]](x7q10w), setTimeout(function () {
        window['$hXUR6Y']();
      }, 0x1f4);
    } });jzd9 && jzd9[O[0x740c]](a6iyb2 => {});
}, window['$hX6YRU'] = function () {
  console[O[0x1e2]](O[0x7720]);var p8zr$ = wx[O[0x771b]]({ 'name': O[0x7721], 'success': function ($pu8rc) {
      console[O[0x1e2]](O[0x7722]), console[O[0x1e2]]($pu8rc), $pu8rc && $pu8rc[O[0x667d]] == O[0x771e] ? (window['$h6UR'] = !![], window['$hRU6Y'](), window['$hR6YU']()) : setTimeout(function () {
        window['$hX6YRU']();
      }, 0x1f4);
    }, 'fail': function (lmtoc5) {
      console[O[0x1e2]](O[0x7723]), console[O[0x1e2]](lmtoc5), setTimeout(function () {
        window['$hX6YRU']();
      }, 0x1f4);
    } });p8zr$ && p8zr$[O[0x740c]](n_y6sa => {});
}, window[O[0x7724]] = function () {
  window['$hXURY6'](window[O[0x770c]], O[0x7725]) >= 0x0 ? (console[O[0x1e2]](O[0x7726] + window[O[0x770c]] + O[0x7727]), window['$h6Y'](), window['$hXUR6Y'](), window['$hX6YRU']()) : (window['$h6RY'](O[0x7728], window[O[0x770c]]), wx[O[0x7714]]({ 'title': O[0x19c7], 'content': O[0x7729] }));
}, window[O[0x7703]] = '', wx[O[0x772a]]({ 'success'(z9dhj) {
    window[O[0x7703]] = O[0x772b] + z9dhj[O[0x772c]] + O[0x772d] + z9dhj[O[0x772e]] + O[0x772f] + z9dhj[O[0x1341]] + O[0x7730] + z9dhj[O[0x1db]] + O[0x7731] + z9dhj[O[0x6598]] + O[0x7732] + z9dhj[O[0x770c]] + O[0x7733] + z9dhj[O[0x2566]], console[O[0x1e2]](window[O[0x7703]]), console[O[0x1e2]](O[0x7734] + z9dhj[O[0x7735]] + O[0x7736] + z9dhj[O[0x7737]] + O[0x7738] + z9dhj[O[0x7739]] + O[0x773a] + z9dhj[O[0x773b]] + O[0x773c] + z9dhj[O[0x773d]] + O[0x773e] + z9dhj[O[0x773f]] + O[0x7740] + (z9dhj[O[0x7741]] ? z9dhj[O[0x7741]][O[0x13e]] + ',' + z9dhj[O[0x7741]][O[0x4e4]] + ',' + z9dhj[O[0x7741]][O[0x4e6]] + ',' + z9dhj[O[0x7741]][O[0x4e5]] : ''));var fg34v1 = z9dhj[O[0x1db]] ? z9dhj[O[0x1db]][O[0x31cc]]() : '',
        w0xhq = z9dhj[O[0x772e]] ? z9dhj[O[0x772e]][O[0x31cc]]()[O[0x1334]]('\x20', '') : '';window['$h6R'][O[0x44a]] = fg34v1[O[0x73]](O[0x7742]) != -0x1, window['$h6R'][O[0x2d73]] = fg34v1[O[0x73]](O[0x766e]) != -0x1, window['$h6R'][O[0x7743]] = fg34v1[O[0x73]](O[0x7742]) != -0x1 || fg34v1[O[0x73]](O[0x766e]) != -0x1, window['$h6R'][O[0x648a]] = fg34v1[O[0x73]](O[0x7744]) != -0x1 || fg34v1[O[0x73]](O[0x7745]) != -0x1, window['$h6R'][O[0x7746]] = z9dhj[O[0x6598]] ? z9dhj[O[0x6598]][O[0x31cc]]() : '', window['$h6R']['$hXYUR6'] = ![], window['$h6R']['$hXY6UR'] = 0x2;if (fg34v1[O[0x73]](O[0x766e]) != -0x1) {
      if (z9dhj[O[0x2566]] >= 0x18) window['$h6R']['$hXY6UR'] = 0x3;else window['$h6R']['$hXY6UR'] = 0x2;
    } else {
      if (fg34v1[O[0x73]](O[0x7742]) != -0x1) {
        if (z9dhj[O[0x2566]] && z9dhj[O[0x2566]] >= 0x14) window['$h6R']['$hXY6UR'] = 0x3;else {
          if (w0xhq[O[0x73]](O[0x7747]) != -0x1 || w0xhq[O[0x73]](O[0x7748]) != -0x1 || w0xhq[O[0x73]](O[0x7749]) != -0x1 || w0xhq[O[0x73]](O[0x774a]) != -0x1 || w0xhq[O[0x73]](O[0x774b]) != -0x1) window['$h6R']['$hXY6UR'] = 0x2;else window['$h6R']['$hXY6UR'] = 0x3;
        }
      } else window['$h6R']['$hXY6UR'] = 0x2;
    }console[O[0x1e2]](O[0x774c] + window['$h6R']['$hXYUR6'] + O[0x774d] + window['$h6R']['$hXY6UR']);
  } }), wx[O[0x774e]]({ 'success': function (_ng4) {
    console[O[0x1e2]](O[0x774f] + _ng4[O[0x12e1]] + O[0x7750] + _ng4[O[0x7751]]);
  } }), wx[O[0x2fb7]]({ 'success': function (xdjh) {
    console[O[0x1e2]](O[0x7752] + xdjh[O[0x34da]]);
  } }), wx[O[0x7753]]({ 'keepScreenOn': !![] }), wx[O[0x2fb9]](function (djz) {
  console[O[0x1e2]](O[0x7752] + djz[O[0x34da]] + O[0x7754] + djz[O[0x7755]]);
}), wx[O[0x2b85]](function ($r8pz) {
  window['$hUY'] = $r8pz, window['$hRYU'] && window['$hUY'] && (console[O[0x4e]](O[0x7756] + window['$hUY'][O[0x31f]]), window['$hRYU'](window['$hUY']), window['$hUY'] = null);
}), window[O[0x7757]] = 0x0, window['$hX6URY'] = 0x0, window[O[0x7758]] = null, wx[O[0x7759]](function () {
  window['$hX6URY']++;var j9d8r = Date[O[0x53]]();(window[O[0x7757]] == 0x0 || j9d8r - window[O[0x7757]] > 0x1d4c0) && (console[O[0x60]](O[0x775a]), wx[O[0x2ffe]]());if (window['$hX6URY'] >= 0x2) {
    window['$hX6URY'] = 0x0, console[O[0x7d]](O[0x775b]), wx[O[0x775c]]('0', 0x1);if (window['$h6R'] && window['$h6R'][O[0x44a]]) window['$h6RY'](O[0x775d], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});