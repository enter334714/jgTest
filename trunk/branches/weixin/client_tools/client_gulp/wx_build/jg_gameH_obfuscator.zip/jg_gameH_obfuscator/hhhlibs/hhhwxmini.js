var O = wx.$C;
(function (window, document, $up) {
  var siya26 = $up['un'],
      q71x4 = $up['uns'],
      x0h7w = $up['static'],
      f31q4 = $up['class'],
      pl$c8 = $up['getset'],
      $rpu8c = $up['__newvec'],
      lu$pc8 = laya['utils']['Browser'],
      u$8zr9 = laya['events']['Event'],
      hxjwd0 = laya['events']['EventDispatcher'],
      w0hjxd = laya['resource']['HTMLImage'],
      jdxh0w = laya['utils']['Handler'],
      y6aib2 = laya['display']['Input'],
      ucp8l = laya['net']['Loader'],
      n4vgf_ = laya['maths']['Matrix'],
      pl8uc$ = laya['renders']['Render'],
      drhj9 = laya['utils']['RunDriver'],
      w0xhdj = laya['media']['Sound'],
      j0dxh = laya['media']['SoundChannel'],
      h9rdz = laya['media']['SoundManager'],
      rjdhz = laya['display']['Stage'],
      w1x0q = laya['net']['URL'],
      plu$8c = laya['utils']['Utils'],
      ul8p$ = function () {
    function xhj0dw() {}return f31q4(xhj0dw, 'laya.wx.mini.MiniAdpter'), xhj0dw['getJson'] = function (tmok5) {
      return JSON['parse'](tmok5);
    }, xhj0dw['init'] = function (ct5lm, f7q431) {
      ct5lm === void 0x0 && (ct5lm = ![]), f7q431 === void 0x0 && (f7q431 = ![]);if (xhj0dw['_inited']) return;xhj0dw['window'] = window;if (xhj0dw['window']['navigator']['userAgent']['indexOf']('MiniGame') < 0x0) return;xhj0dw['_inited'] = !![], xhj0dw['isZiYu'] = f7q431, xhj0dw['isPosMsgYu'] = ct5lm, xhj0dw['EnvConfig'] = {}, !xhj0dw['isZiYu'] && (_sfv['setNativeFileDir']('/layaairGame'), _sfv['existDir'](_sfv['fileNativeDir'], jdxh0w['create'](xhj0dw, xhj0dw['onMkdirCallBack']))), xhj0dw['window']['focus'] = function () {}, $up['getUrlPath'] = function () {}, xhj0dw['window']['logtime'] = function (an26y) {}, xhj0dw['window']['alertTimeLog'] = function (hdjw90) {}, xhj0dw['window']['resetShareInfo'] = function () {}, xhj0dw['window']['CanvasRenderingContext2D'] = function () {}, xhj0dw['window']['CanvasRenderingContext2D']['prototype'] = xhj0dw['window']['wx']['createCanvas']()['getContext']('2d')['__proto__'], xhj0dw['window']['document']['body']['appendChild'] = function () {}, xhj0dw['EnvConfig']['pixelRatioInt'] = 0x0, drhj9['getPixelRatio'] = xhj0dw['pixelRatio'], xhj0dw['_preCreateElement'] = lu$pc8['createElement'], lu$pc8['createElement'] = xhj0dw['createElement'], drhj9['createShaderCondition'] = xhj0dw['createShaderCondition'], plu$8c['parseXMLFromString'] = xhj0dw['parseXMLFromString'], y6aib2['_createInputElement'] = xd0qw['_createInputElement'], xhj0dw['EnvConfig']['load'] = ucp8l['prototype']['load'], ucp8l['prototype']['load'] = n_vys['prototype']['load'], xhj0dw['isZiYu'] && ct5lm && wx['onMessage'](function (sny) {
        sny['isLoad'] && (_sfv['ziyuFileData'][sny['url']] = sny['data']);
      });
    }, xhj0dw['onMkdirCallBack'] = function (ulcp8$, avyns_) {
      if (!ulcp8$) _sfv['filesListObj'] = JSON['parse'](avyns_['data']);
    }, xhj0dw['pixelRatio'] = function () {
      if (!xhj0dw['EnvConfig']['pixelRatioInt']) try {
        var x0317q = wx['getSystemInfoSync']();return xhj0dw['EnvConfig']['pixelRatioInt'] = x0317q['pixelRatio'], x0317q = x0317q, x0317q['pixelRatio'];
      } catch (u8c$r) {}return xhj0dw['EnvConfig']['pixelRatioInt'];
    }, xhj0dw['createElement'] = function (y6a_) {
      if (y6a_ == 'canvas') {
        var iyas;return xhj0dw['idx'] == 0x1 ? xhj0dw['isZiYu'] ? (iyas = sharedCanvas, iyas['style'] = {}) : iyas = window['canvas'] : iyas = window['wx']['createCanvas'](), xhj0dw['idx']++, iyas;
      } else {
        if (y6a_ == 'textarea' || y6a_ == 'input') return xhj0dw['onCreateInput'](y6a_);else {
          if (y6a_ == 'div') {
            var gvsn_f = xhj0dw['_preCreateElement'](y6a_);return gvsn_f['contains'] = function (tklmo5) {
              return null;
            }, gvsn_f['removeChild'] = function (xqh0) {}, gvsn_f;
          } else return xhj0dw['_preCreateElement'](y6a_);
        }
      }
    }, xhj0dw['onCreateInput'] = function (xdwh0q) {
      var as6ny = xhj0dw['_preCreateElement'](xdwh0q);return as6ny['focus'] = xd0qw['wxinputFocus'], as6ny['blur'] = xd0qw['wxinputblur'], as6ny['style'] = {}, as6ny['value'] = 0x0, as6ny['parentElement'] = {}, as6ny['placeholder'] = {}, as6ny['type'] = {}, as6ny['setColor'] = function (ruc$p) {}, as6ny['setType'] = function (w0q7xh) {}, as6ny['setFontFace'] = function (g_v3f4) {}, as6ny['addEventListener'] = function (ba6yi2) {}, as6ny['contains'] = function (x30) {
        return null;
      }, as6ny['removeChild'] = function (_g3v) {}, as6ny;
    }, xhj0dw['createShaderCondition'] = function (omtl5c) {
      var uplco = this,
          z9hdjr = function () {
        var wdhz9j = omtl5c;return uplco[omtl5c['replace']('this.', '')];
      };return z9hdjr;
    }, xhj0dw['EnvConfig'] = null, xhj0dw['window'] = null, xhj0dw['_preCreateElement'] = null, xhj0dw['_inited'] = ![], xhj0dw['wxRequest'] = null, xhj0dw['systemInfo'] = null, xhj0dw['version'] = '0.0.1', xhj0dw['isZiYu'] = ![], xhj0dw['isPosMsgYu'] = ![], xhj0dw['parseXMLFromString'] = function (plt) {
      var ur$9, pucl8$;plt = plt['replace'](/>\s+</g, '><');try {
        ur$9 = new window['Parser']['DOMParser']()['parseFromString'](plt, 'text/xml');
      } catch (ol5ctm) {
        throw '需要引入xml解析库文件';
      }return ur$9;
    }, xhj0dw['idx'] = 0x1, xhj0dw;
  }(),
      ngsyv_ = function () {
    function omlt5k() {}f31q4(omlt5k, 'laya.wx.mini.MiniImage');var $8lup = omlt5k['prototype'];return $8lup['_loadImage'] = function (y_nvas) {
      var zpr8$u = this,
          d9zjr = ![];y_nvas['indexOf']('layaNativeDir/') == -0x1 && (d9zjr = !![], y_nvas = w1x0q['formatURL'](y_nvas));if (!_sfv['getFileInfo'](y_nvas)) {
        if (y_nvas['indexOf']('http://') != -0x1 || y_nvas['indexOf']('https://') != -0x1) _sfv['downImg'](y_nvas, new jdxh0w(omlt5k, omlt5k['onDownImgCallBack'], [y_nvas, zpr8$u]), y_nvas);else omlt5k['onCreateImage'](y_nvas, zpr8$u, !![]);
      } else omlt5k['onCreateImage'](y_nvas, zpr8$u, !d9zjr);
    }, omlt5k['onDownImgCallBack'] = function (jr9zd, ea6bi, jd9rz8) {
      if (!jd9rz8) omlt5k['onCreateImage'](jr9zd, ea6bi);else ea6bi['onError'](null);
    }, omlt5k['onCreateImage'] = function ($pcr8u, u$8r9, pltc) {
      pltc === void 0x0 && (pltc = ![]);var jw09hd;if (!pltc) {
        var _4fn = _sfv['getFileInfo']($pcr8u),
            f4 = _4fn['md5'];jw09hd = _sfv['getFileNativePath'](f4);
      } else jw09hd = $pcr8u;if (u$8r9['imgCache'] == null) u$8r9['imgCache'] = {};var xq0731;function lup$5c() {
        xq0731['onload'] = null, xq0731['onerror'] = null, delete u$8r9['imgCache'][$pcr8u];
      };var ct5po = function () {
        lup$5c(), u$8r9['onLoaded'](xq0731);
      },
          km5lo = function () {
        lup$5c(), u$8r9['event']('error', 'Load image failed');
      };u$8r9['_type'] == 'nativeimage' ? (xq0731 = new lu$pc8['window']['Image'](), xq0731['crossOrigin'] = '', xq0731['onload'] = ct5po, xq0731['onerror'] = km5lo, xq0731['src'] = jw09hd, u$8r9['imgCache'][$pcr8u] = xq0731) : new w0hjxd['create'](jw09hd, { 'onload': ct5po, 'onerror': km5lo, 'onCreate': function (nfg_v4) {
          xq0731 = nfg_v4, u$8r9['imgCache'][$pcr8u] = nfg_v4;
        } });
    }, omlt5k;
  }(),
      xd0qw = function () {
    function xhd0jw() {}return f31q4(xhd0jw, 'laya.wx.mini.MiniInput'), xhd0jw['_createInputElement'] = function () {
      y6aib2['_initInput'](y6aib2['area'] = lu$pc8['createElement']('textarea')), y6aib2['_initInput'](y6aib2['input'] = lu$pc8['createElement']('input')), y6aib2['inputContainer'] = lu$pc8['createElement']('div'), y6aib2['inputContainer']['style']['position'] = 'absolute', y6aib2['inputContainer']['style']['zIndex'] = 0x186a0, lu$pc8['container']['appendChild'](y6aib2['inputContainer']), y6aib2['inputContainer']['setPos'] = function (rdjh, cpu8$r) {
        y6aib2['inputContainer']['style']['left'] = rdjh + 'px', y6aib2['inputContainer']['style']['top'] = cpu8$r + 'px';
      }, $up['stage']['on']('resize', null, xhd0jw['_onStageResize']), wx['onWindowResize'] && wx['onWindowResize'](function (xwdhq) {
        window['dispatchEvent'] && window['dispatchEvent']('resize');
      }), h9rdz['_soundClass'] = crp$u, h9rdz['_musicClass'] = crp$u, window['_videoClass'] = hj;
    }, xhd0jw['_onStageResize'] = function () {
      var jhxw = $up['stage']['_canvasTransform']['identity']();jhxw['scale'](lu$pc8['width'] / pl8uc$['canvas']['width'] / drhj9['getPixelRatio'](), lu$pc8['height'] / pl8uc$['canvas']['height'] / drhj9['getPixelRatio']());
    }, xhd0jw['wxinputFocus'] = function (m5kol) {
      var yai26s = y6aib2['inputElement']['target'];if (yai26s && !yai26s['editable']) return;ul8p$['window']['wx']['offKeyboardConfirm'](), ul8p$['window']['wx']['offKeyboardInput'](), ul8p$['window']['wx']['showKeyboard']({ 'defaultValue': yai26s['text'], 'maxLength': yai26s['maxChars'], 'multiple': yai26s['multiline'], 'confirmHold': !![], 'confirmType': 'done', 'success': function (dw9hjz) {}, 'fail': function (f3v41g) {} }), ul8p$['window']['wx']['onKeyboardConfirm'](function (p8$uzr) {
        var pol5tc = p8$uzr ? p8$uzr['value'] : '';yai26s['text'] = pol5tc, yai26s['event']('input'), laya['wx']['mini']['MiniInput']['inputEnter']();
      }), ul8p$['window']['wx']['onKeyboardInput'](function (gf743) {
        var ctom5l = gf743 ? gf743['value'] : '';if (!yai26s['multiline']) {
          if (ctom5l['indexOf']('\x0a') != -0x1) {
            laya['wx']['mini']['MiniInput']['inputEnter']();return;
          }
        }yai26s['text'] = ctom5l, yai26s['event']('input');
      });
    }, xhd0jw['inputEnter'] = function () {
      y6aib2['inputElement']['target']['focus'] = ![];
    }, xhd0jw['wxinputblur'] = function () {
      xhd0jw['hideKeyboard']();
    }, xhd0jw['hideKeyboard'] = function () {
      ul8p$['window']['wx']['offKeyboardConfirm'](), ul8p$['window']['wx']['offKeyboardInput'](), ul8p$['window']['wx']['hideKeyboard']({ 'success': function (whx0qd) {
          console['log']('隐藏键盘');
        }, 'fail': function (bayi2) {
          console['log']('隐藏键盘出错:' + (bayi2 ? bayi2['errMsg'] : ''));
        } });
    }, xhd0jw;
  }(),
      n_vys = function () {
    function as_n() {}f31q4(as_n, 'laya.wx.mini.MiniLoader');var dw9j0 = as_n['prototype'];return dw9j0['load'] = function (g34_f, lo5, ngfv4, jzr$98, puoc5l) {
      ngfv4 === void 0x0 && (ngfv4 = !![]), puoc5l === void 0x0 && (puoc5l = ![]);var $8ucr = this;$8ucr['_url'] = g34_f;if (g34_f['indexOf']('data:image') === 0x0) $8ucr['_type'] = lo5 = 'image';else $8ucr['_type'] = lo5 || (lo5 = $8ucr['getTypeFromUrl'](g34_f));$8ucr['_cache'] = ngfv4, $8ucr['_data'] = null;var tmk5o = 'ascii';if (g34_f['indexOf']('.fnt') != -0x1) tmk5o = 'utf8';else lo5 == 'arraybuffer' && (tmk5o = '');;var qf47 = plu$8c['getFileExtension'](g34_f);if (as_n['_fileTypeArr']['indexOf'](qf47) != -0x1) ul8p$['EnvConfig']['load']['call'](this, g34_f, lo5, ngfv4, jzr$98, puoc5l);else {
        if (!_sfv['getFileInfo'](g34_f)) {
          if (g34_f['indexOf']('layaNativeDir/') != -0x1) {
            if (ul8p$['isZiYu']) {
              var wh90j = _sfv['ziyuFileData'][g34_f];$8ucr['onLoaded'](wh90j);return;
            } else {
              cosnole['log']('read read'), _sfv['read'](g34_f, tmk5o, new jdxh0w(as_n, as_n['onReadNativeCallBack'], [tmk5o, g34_f, lo5, ngfv4, jzr$98, puoc5l, $8ucr]));return;
            }
          }if (w1x0q['rootPath'] == '') var r$zu89 = g34_f;else r$zu89 = g34_f['split'](w1x0q['rootPath'])[0x0];g34_f['indexOf']('http://') != -0x1 || g34_f['indexOf']('https://') != -0x1 ? ul8p$['EnvConfig']['load']['call']($8ucr, g34_f, lo5, ngfv4, jzr$98, puoc5l) : _sfv['readFile'](r$zu89, tmk5o, new jdxh0w(as_n, as_n['onReadNativeCallBack'], [tmk5o, g34_f, lo5, ngfv4, jzr$98, puoc5l, $8ucr]), g34_f);
        } else ul8p$['EnvConfig']['load']['call'](this, g34_f, lo5, ngfv4, jzr$98, puoc5l);
      }
    }, dw9j0['resMgrLoad'] = function (ay_, x0q7, sy_gnv, whjd9z, d8rj9z, f_sgn, uc5p) {
      sy_gnv === void 0x0 && (sy_gnv = 0x0), whjd9z === void 0x0 && (whjd9z = ![]), d8rj9z === void 0x0 && (d8rj9z = ![]), f_sgn === void 0x0 && (f_sgn = 0x0), uc5p === void 0x0 && (uc5p = 0x3), ay_['indexOf']('mpack') != -0x1 && console['log']('=============resMgrLoad url:', ay_), ul8p$['EnvConfig']['resMgrLoad'](ay_, (_ns6ya, qw7xh, ysi) => {
        as_n['prototype']['resMgrLoadCallBack'](_ns6ya, qw7xh, ysi, x0q7);
      }, sy_gnv, whjd9z, d8rj9z, f_sgn, uc5p);
    }, dw9j0['resMgrLoadCallBack'] = function (gfsvn_, x0w7qh, om5k, b2iy6a) {
      console['log']('buff:::', gfsvn_, om5k, _sfv['fileNativeDir'] + '///' + _sfv['fileListName']), b2iy6a(gfsvn_, x0w7qh, om5k);
    }, dw9j0['clearRes'] = function (l$pc5u, nsy) {
      nsy === void 0x0 && (nsy = ![]);var uprz8$ = this;uprz8$['clearRes'](l$pc5u, nsy);var otcm5l = _sfv['getFileInfo'](l$pc5u);if (otcm5l && (l$pc5u['indexOf']('http://') != -0x1 || l$pc5u['indexOf']('https://') != -0x1)) {
        var yn6_as = otcm5l['md5'],
            x7w1q = _sfv['getFileNativePath'](yn6_as);_sfv['remove'](x7w1q);
      }
    }, as_n['onReadNativeCallBack'] = function (h9wjd0, u5polc, s2nay6, sy6a_, up$cl, f4q17, optcl5, xhwq70, _y6ns) {
      sy6a_ === void 0x0 && (sy6a_ = !![]), f4q17 === void 0x0 && (f4q17 = ![]), xhwq70 === void 0x0 && (xhwq70 = 0x0);if (!xhwq70) {
        var o5lctm;if (s2nay6 == 'json' || s2nay6 == 'atlas') o5lctm = ul8p$['getJson'](_y6ns['data']);else s2nay6 == 'xml' ? o5lctm = plu$8c['parseXMLFromString'](_y6ns['data']) : o5lctm = _y6ns['data'];optcl5['onLoaded'](o5lctm), !ul8p$['isZiYu'] && ul8p$['isPosMsgYu'] && s2nay6 != 'arraybuffer' && wx['postMessage']({ 'url': u5polc, 'data': o5lctm, 'isLoad': !![] });
      } else xhwq70 == 0x1 && ul8p$['EnvConfig']['load']['call'](optcl5, u5polc, s2nay6, sy6a_, up$cl, f4q17);
    }, x0h7w(as_n, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['png', 'jpg', 'bmp', 'jpeg', 'gif'];
    }]), as_n;
  }(),
      _sfv = function (pulco5) {
    function mot5kl() {
      mot5kl['__super']['call'](this);;
    }return f31q4(mot5kl, 'laya.wx.mini.MiniFileMgr', pulco5), mot5kl['isLoadFile'] = function (yn_avs) {
      return mot5kl['_fileTypeArr']['indexOf'](yn_avs) != -0x1 ? !![] : ![];
    }, mot5kl['getFileInfo'] = function (xq7w0) {
      var _snvgy = xq7w0['split']('?')[0x0],
          opu5 = mot5kl['filesListObj'][_snvgy];if (opu5 == null) return null;else return opu5;return null;
    }, mot5kl['onFileUpdate'] = function ($zrj9, g_f3) {
      var jw0dxh = $zrj9['split']('/'),
          up8$r = jw0dxh[jw0dxh['length'] - 0x1],
          v_asy = mot5kl['getFileInfo'](g_f3);if (v_asy == null) mot5kl['onSaveFile'](g_f3, up8$r);else {
        if (v_asy['readyUrl'] != g_f3) mot5kl['remove'](up8$r, g_f3);
      }
    }, mot5kl['exits'] = function (qw07, f34v_) {
      var x4137 = mot5kl['getFileNativePath'](qw07);mot5kl['fs']['getFileInfo']({ 'filePath': x4137, 'success': function (svgn_) {
          f34v_ != null && f34v_['runWith']([0x0, svgn_]);
        }, 'fail': function (zd9wj) {
          f34v_ != null && f34v_['runWith']([0x1, zd9wj]);
        } });
    }, mot5kl['read'] = function (_fv3g4, vgs_f, tmol5k, ny_a6) {
      vgs_f === void 0x0 && (vgs_f = 'ascill'), ny_a6 === void 0x0 && (ny_a6 = '');var k5lm;ny_a6 != '' ? k5lm = mot5kl['getFileNativePath'](_fv3g4) : k5lm = _fv3g4, mot5kl['fs']['readFile']({ 'filePath': k5lm, 'encoding': vgs_f, 'success': function (yan6s2) {
          tmol5k != null && tmol5k['runWith']([0x0, yan6s2]);
        }, 'fail': function (x70hw) {
          if (x70hw && ny_a6 != '') mot5kl['down'](ny_a6, vgs_f, tmol5k, ny_a6);else tmol5k != null && tmol5k['runWith']([0x1]);
        } });
    }, mot5kl['readNativeFile'] = function (g_nfv4, g734) {
      mot5kl['fs']['readFile']({ 'filePath': g_nfv4, 'encoding': '', 'success': function (l8c$) {
          g734 != null && g734['runWith']([0x0]);
        }, 'fail': function (dxj0w) {
          g734 != null && g734['runWith']([0x1]);
        } });
    }, mot5kl['down'] = function (f4q73, zhdw9j, yns2, $pcl8u) {
      zhdw9j === void 0x0 && (zhdw9j = 'ascill'), $pcl8u === void 0x0 && ($pcl8u = '');var gv_ysn = mot5kl['getFileNativePath']($pcl8u),
          _an6 = mot5kl['wxdown']({ 'url': f4q73, 'filePath': gv_ysn, 'success': function (f4g317) {
          if (f4g317['statusCode'] === 0xc8) mot5kl['readFile'](f4g317['filePath'], zhdw9j, yns2, $pcl8u);
        }, 'fail': function (s_n6a) {
          yns2 != null && yns2['runWith']([0x1, s_n6a]);
        } });_an6['onProgressUpdate'](function (_ngf) {
        yns2 != null && yns2['runWith']([0x2, _ngf['progress']]);
      });
    }, mot5kl['readFile'] = function (djh9rz, cr8p, tkmlo, hd9zj) {
      cr8p === void 0x0 && (cr8p = 'ascill'), hd9zj === void 0x0 && (hd9zj = ''), mot5kl['fs']['readFile']({ 'filePath': djh9rz, 'encoding': cr8p, 'success': function (c8pu$) {
          if (djh9rz['indexOf']('http://') != -0x1 || djh9rz['indexOf']('https://') != -0x1) mot5kl['onFileUpdate'](djh9rz, hd9zj);tkmlo != null && tkmlo['runWith']([0x0, c8pu$]);
        }, 'fail': function (z8$jr) {
          if (z8$jr) tkmlo != null && tkmlo['runWith']([0x1, z8$jr]);
        } });
    }, mot5kl['downImg'] = function (jw9hd, dwjh9z, gsvy_) {
      gsvy_ === void 0x0 && (gsvy_ = '');var x7w0h = mot5kl['wxdown']({ 'url': jw9hd, 'success': function (gn_f4v) {
          gn_f4v['statusCode'] === 0xc8 && mot5kl['copyFile'](gn_f4v['tempFilePath'], gsvy_, dwjh9z);
        }, 'fail': function (hj9dwz) {
          dwjh9z != null && dwjh9z['runWith']([0x1, hj9dwz]);
        } });
    }, mot5kl['copyFile'] = function (cup5l, n_y6s, jhdw9z) {
      var _gsnfv = cup5l['split']('/'),
          ruc = _gsnfv[_gsnfv['length'] - 0x1],
          f4q13 = n_y6s['split']('?')[0x0],
          dhjxw = mot5kl['getFileInfo'](n_y6s),
          yg_s = mot5kl['getFileNativePath'](ruc);mot5kl['fs']['copyFile']({ 'srcPath': cup5l, 'destPath': yg_s, 'success': function (_6ayn) {
          if (!dhjxw) mot5kl['onSaveFile'](n_y6s, ruc), jhdw9z != null && jhdw9z['runWith']([0x0]);else {
            if (dhjxw['readyUrl'] != n_y6s) mot5kl['remove'](ruc, n_y6s, jhdw9z);
          }
        }, 'fail': function (lucop5) {
          jhdw9z != null && jhdw9z['runWith']([0x1, lucop5]);
        } });
    }, mot5kl['getFileNativePath'] = function (tkm) {
      return laya['wx']['mini']['MiniFileMgr']['fileNativeDir'] + '/' + tkm;
    }, mot5kl['remove'] = function (p$u8rz, n2s, x0djw) {
      n2s === void 0x0 && (n2s = '');var u8p$z = mot5kl['getFileInfo'](n2s),
          _vsny = mot5kl['getFileNativePath'](u8p$z['md5']);$up['loader']['clearRes'](u8p$z['readyUrl']), mot5kl['fs']['unlink']({ 'filePath': _vsny, 'success': function (ul5pco) {
          if (n2s != '') mot5kl['onSaveFile'](n2s, p$u8rz);x0djw != null && x0djw['runWith']([0x0]);
        }, 'fail': function (vg1f3) {} });
    }, mot5kl['onSaveFile'] = function (x0qwh, hxw0dq) {
      var cltm5o = x0qwh['split']('?')[0x0];mot5kl['filesListObj'][cltm5o] = { 'md5': hxw0dq, 'readyUrl': x0qwh }, mot5kl['fs']['writeFile']({ 'filePath': mot5kl['fileNativeDir'] + '/' + mot5kl['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](mot5kl['filesListObj']), 'success': function (wjd9z) {
          console['log']('写入测试测试成功：', wjd9z);
        }, 'fail': function (klto5) {
          console['log']('写入测试测试失败：', klto5);
        } });
    }, mot5kl['existDir'] = function (nay6_, n_6) {
      mot5kl['fs']['mkdir']({ 'dirPath': nay6_, 'success': function (hd9w) {
          n_6 != null && n_6['runWith']([0x0, { 'data': JSON['stringify']({}) }]);
        }, 'fail': function (mtk5o) {
          if (mtk5o['errMsg']['indexOf']('file already exists') != -0x1) mot5kl['readSync'](mot5kl['fileListName'], 'utf8', n_6);else n_6 != null && n_6['runWith']([0x1, mtk5o]);
        } });
    }, mot5kl['readSync'] = function (puc5l$, _ynv, j8dz, r$c8) {
      _ynv === void 0x0 && (_ynv = 'ascill'), r$c8 === void 0x0 && (r$c8 = '');var wdx0hq = mot5kl['getFileNativePath'](puc5l$),
          c$upr;try {
        c$upr = mot5kl['fs']['readFileSync'](wdx0hq), j8dz != null && j8dz['runWith']([0x0, { 'data': c$upr }]);
      } catch (f371g) {
        j8dz != null && j8dz['runWith']([0x1]);
      }
    }, mot5kl['readCache'] = function () {}, mot5kl['writeCache'] = function (ltpco) {
      var q314 = readyUrl['split']('?')[0x0];mot5kl['filesListObj'][q314] = { 'md5': md5Name, 'readyUrl': readyUrl }, mot5kl['fs']['writeFile']({ 'filePath': mot5kl['fileNativeDir'] + '/' + mot5kl['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](mot5kl['filesListObj']), 'success': function (zdr98j) {}, 'fail': function (yn2a6s) {} });
    }, mot5kl['setNativeFileDir'] = function (u5l$) {
      mot5kl['fileNativeDir'] = wx['env']['USER_DATA_PATH'] + u5l$;
    }, mot5kl['filesListObj'] = {}, mot5kl['fileNativeDir'] = null, mot5kl['fileListName'] = 'layaairfiles.txt', mot5kl['ziyuFileData'] = {}, x0h7w(mot5kl, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['json', 'ani', 'xml', 'sk', 'txt', 'atlas', 'swf', 'part', 'fnt', 'proto', 'lh', 'lav', 'lani', 'lmat', 'lm', 'ltc'];
    }, 'fs', function () {
      return this['fs'] = wx['getFileSystemManager']();
    }, 'wxdown', function () {
      return this['wxdown'] = wx['downloadFile'];
    }]), mot5kl;
  }(hxjwd0),
      crp$u = function (iy2b6) {
    function rzu9$8() {
      this['_sound'] = null, this['_chanell'] = null, this['url'] = null, this['loaded'] = ![], rzu9$8['__super']['call'](this), this['_sound'] = rzu9$8['_createSound'](), this['_chanell'] = new nvfg4_(this['_sound']);
    }f31q4(rzu9$8, 'laya.wx.mini.MiniSound', iy2b6);var dz9jhr = rzu9$8['prototype'];return dz9jhr['load'] = function (n4) {
      var r8zj9d = this;n4 = w1x0q['formatURL'](n4), this['url'] = n4;if (rzu9$8['_audioCache'][n4]) {
        this['event']('complete');return;
      }function l5tkom() {
        if (rzu9$8['_null'] != undefined) r8zj9d['_sound']['onCanplay'](rzu9$8['_null']), r8zj9d['_sound']['onError'](rzu9$8['_null']);else try {
          r8zj9d['_sound']['onCanplay'](null), r8zj9d['_sound']['onError'](null), rzu9$8['_null'] = null;
        } catch (x37q1) {
          console['warn']('[wxmini] _clearSound:' + x37q1), r8zj9d['_sound']['onCanplay'](c$pl5u), r8zj9d['_sound']['onError'](c$pl5u), rzu9$8['_null'] = c$pl5u;
        }
      }function uocl() {
        pc$ul8['loaded'] = !![], pc$ul8['event']('complete'), rzu9$8['_audioCache'][pc$ul8['url']] = pc$ul8;
      }function ys6_na(h7xq) {
        console['error']('errCode=' + h7xq['errCode'] + '  errMsg=' + h7xq['errMsg']), pc$ul8['event']('error');
      }function c$pl5u() {}this['_sound']['onCanplay'](uocl), this['_sound']['onError'](ys6_na), this['_sound']['src'] = n4;var pc$ul8 = this;
    }, dz9jhr['play'] = function (_vn4, gnv) {
      _vn4 === void 0x0 && (_vn4 = 0x0), gnv === void 0x0 && (gnv = 0x0);var wd9hjz, y2s6ai;if (this['url'] == h9rdz['_tMusic']) {
        if (!rzu9$8['_musicAudio']) rzu9$8['_musicAudio'] = this['_sound'];wd9hjz = rzu9$8['_musicAudio'], y2s6ai = this['_chanell'];
      } else wd9hjz = this['_sound'], y2s6ai = this['_chanell'];return wd9hjz['src'] = this['url'], wd9hjz['startTime'] = 0x0, y2s6ai['isStopped'] && (y2s6ai['url'] = this['url'], y2s6ai['loops'] = gnv, y2s6ai['startTime'] = _vn4, y2s6ai['play'](), h9rdz['addChannel'](y2s6ai)), y2s6ai;
    }, dz9jhr['dispose'] = function () {
      var mctlo = rzu9$8['_audioCache'][this['url']];mctlo && (mctlo['src'] = '', delete rzu9$8['_audioCache'][this['url']]);
    }, pl$c8(0x0, dz9jhr, 'duration', function () {
      return this['_sound']['duration'];
    }), rzu9$8['_createSound'] = function () {
      rzu9$8['_id']++;var vyas = ul8p$['window']['wx']['createInnerAudioContext']({ 'useWebAudioImplement': ![] });return vyas;
    }, rzu9$8['_musicAudio'] = null, rzu9$8['_id'] = 0x0, rzu9$8['_audioCache'] = {}, rzu9$8['_null'] = undefined, rzu9$8;
  }(hxjwd0),
      nvfg4_ = function (xqhw) {
    function z9hjrd(gf4_v3) {
      this['_audio'] = null, this['_onEnd'] = null, z9hjrd['__super']['call'](this), this['isStopped'] = !![], this['_audio'] = gf4_v3, this['_onEnd'] = plu$8c['bind'](this['__onEnd'], this), gf4_v3['onEnded'](this['_onEnd']);
    }f31q4(z9hjrd, 'laya.wx.mini.MiniSoundChannel', xqhw);var ot5klm = z9hjrd['prototype'];return ot5klm['__onEnd'] = function () {
      if (this['loops'] == 0x1) {
        this['completeHandler'] && ($up['timer']['once'](0xa, this, this['__runComplete'], [this['completeHandler']], ![]), this['completeHandler'] = null);this['stop'](), this['event']('complete');return;
      }this['loops'] > 0x0 && this['loops']--, this['startTime'] = 0x0, this['play']();
    }, ot5klm['__onNull'] = function () {}, ot5klm['play'] = function () {
      this['isStopped'] = ![], h9rdz['addChannel'](this);if (this['_audio']) this['_audio']['play']();
    }, ot5klm['stop'] = function () {
      this['isStopped'] = !![], h9rdz['removeChannel'](this), this['completeHandler'] = null;if (!this['_audio']) return;this['_audio']['stop']();
    }, ot5klm['pause'] = function () {
      this['isStopped'] = !![], this['_audio']['pause']();
    }, ot5klm['resume'] = function () {
      if (!this['_audio']) return;this['isStopped'] = ![], h9rdz['addChannel'](this), this['_audio']['play']();
    }, pl$c8(0x0, ot5klm, 'position', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['currentTime'];
    }), pl$c8(0x0, ot5klm, 'duration', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['duration'];
    }), pl$c8(0x0, ot5klm, 'volume', function () {
      return 0x1;
    }, function (r89$j) {}), z9hjrd['_null'] = undefined, z9hjrd;
  }(j0dxh),
      hj = function () {
    function ocmtl5() {
      this['videoend'] = ![], this['videourl'] = '', this['videoElement'] = ul8p$['window']['wx']['createVideo']({ 'showCenterPlayBtn': ![], 'showProgressInControlMode': ![], 'objectFit': 'fill' });
    }f31q4(ocmtl5, 'laya.wx.mini.MiniVideo');var vf14g = ocmtl5['prototype'];return vf14g['on'] = function (tolmc, av_n, fv41) {
      if (tolmc == 'loadedmetadata') this['onPlayFunc'] = fv41['bind'](av_n), this['videoElement']['onPlay'] = this['onPlayFunction']['bind'](this);else tolmc == 'ended' && (this['onEndedFunC'] = fv41['bind'](av_n), this['videoElement']['onEnded'] = this['onEndedFunction']['bind'](this));this['videoElement']['onTimeUpdate'] = this['onTimeUpdateFunc']['bind'](this);
    }, vf14g['onTimeUpdateFunc'] = function (yvgn_s) {
      this['position'] = yvgn_s['position'], this['_duration'] = yvgn_s['duration'];
    }, vf14g['onPlayFunction'] = function () {
      if (this['videoElement']) this['videoElement']['readyState'] = 0xc8;console['log']('=====视频加载完成========'), this['onPlayFunc'] != null && this['onPlayFunc']();
    }, vf14g['onended'] = function (jxdhw0, ys_an) {
      this['onEndedFunC'] = ys_an['bind'](jxdhw0), this['videoElement']['onended'] = this['onEndedFunction']['bind'](this);
    }, vf14g['onEndedFunction'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], console['log']('=====视频播放完毕========'), this['onEndedFunC'] != null && this['onEndedFunC']();
    }, vf14g['off'] = function (sygv, zwjh, mok5l) {
      if (sygv == 'loadedmetadata') this['onPlayFunc'] = mok5l['bind'](zwjh), this['videoElement']['offPlay'] = this['onPlayFunction']['bind'](this);else sygv == 'ended' && (this['onEndedFunC'] = mok5l['bind'](zwjh), this['videoElement']['offEnded'] = this['onEndedFunction']['bind'](this));
    }, vf14g['load'] = function (ur8pc$) {
      if (!this['videoElement']) return;this['videoElement']['src'] = ur8pc$;
    }, vf14g['play'] = function () {
      if (!this['videoElement']) return;this['videoend'] = ![], this['videoElement']['play']();
    }, vf14g['pause'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], this['videoElement']['pause']();
    }, vf14g['size'] = function (q1473, ulp5c) {
      if (!this['videoElement']) return;this['videoElement']['width'] = q1473, this['videoElement']['height'] = ulp5c;
    }, vf14g['destroy'] = function () {
      if (this['videoElement']) this['videoElement']['destroy']();this['videoElement'] = null, this['onEndedFunC'] = null, this['onPlayFunc'] = null, this['videoend'] = ![], this['videourl'] = null;
    }, vf14g['reload'] = function () {
      if (!this['videoElement']) return;this['videoElement']['src'] = this['videourl'];
    }, pl$c8(0x0, vf14g, 'duration', function () {
      return this['_duration'];
    }), pl$c8(0x0, vf14g, 'currentTime', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['initialTime'];
    }, function (q0hx7w) {
      if (!this['videoElement']) return;this['videoElement']['initialTime'] = q0hx7w;
    }), pl$c8(0x0, vf14g, 'videoWidth', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['width'];
    }), pl$c8(0x0, vf14g, 'videoHeight', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['height'];
    }), pl$c8(0x0, vf14g, 'ended', function () {
      return this['videoend'];
    }), pl$c8(0x0, vf14g, 'loop', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['loop'];
    }, function (olc5p) {
      if (!this['videoElement']) return;this['videoElement']['loop'] = olc5p;
    }), pl$c8(0x0, vf14g, 'playbackRate', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['playbackRate'];
    }, function (vf_n4g) {
      if (!this['videoElement']) return;this['videoElement']['playbackRate'] = vf_n4g;
    }), pl$c8(0x0, vf14g, 'muted', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['muted'];
    }, function (lc5mot) {
      if (!this['videoElement']) return;this['videoElement']['muted'] = lc5mot;
    }), pl$c8(0x0, vf14g, 'paused', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['paused'];
    }), pl$c8(0x0, vf14g, 'x', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['x'];
    }, function (pruz8) {
      if (!this['videoElement']) return;this['videoElement']['x'] = pruz8;
    }), pl$c8(0x0, vf14g, 'y', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['y'];
    }, function (p5tcl) {
      if (!this['videoElement']) return;this['videoElement']['y'] = p5tcl;
    }), pl$c8(0x0, vf14g, 'currentSrc', function () {
      return this['videoElement']['src'];
    }), pl$c8(0x0, vf14g, 'src', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['src'];
    }, function (d0jxh) {
      if (!this['videoElement']) return;this['videoElement']['src'] = d0jxh;
    }), pl$c8(0x0, vf14g, 'controls', function () {
      if (!this['videoElement']) return;return this['videoElement']['controls'];
    }, function (d9wjhz) {
      if (!this['videoElement']) return;this['videoElement']['controls'] = d9wjhz;
    }), pl$c8(0x0, vf14g, 'autoplay', function () {
      if (!this['videoElement']) return;return this['videoElement']['autoplay'];
    }, function (urz9) {
      if (!this['videoElement']) return;this['videoElement']['autoplay'] = urz9;
    }), ocmtl5;
  }();
})(window, document, Laya);typeof define === 'function' && define['amd'] && define('laya.core', ['require', 'exports'], function (require, exports) {
  'use strict';
  Object['defineProperty'](exports, '__esModule', { 'value': !![] });for (var nf4g in Laya) {
    var z8$upr = Laya[nf4g];z8$upr && z8$upr['__isclass'] && (exports[nf4g] = z8$upr);
  }
});