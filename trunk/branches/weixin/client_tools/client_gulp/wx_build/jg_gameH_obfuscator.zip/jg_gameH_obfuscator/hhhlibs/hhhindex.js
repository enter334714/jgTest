var O = wx.$C;
import h_f_v3g4 from '../hhhhsdk/hhhsdk.js';window[O[0x775e]] = { 'wxVersion': window[O[0x22e]][O[0x76fc]] }, window[O[0x775f]] = ![], window['$hR6'] = 0x1, window[O[0x7760]] = 0x1, window['$hU6R'] = !![], window[O[0x7761]] = !![], window['$hXYU6R'] = '', window[O[0x7762]] = ![], window['$h6R'] = { 'base_cdn': O[0x7763], 'cdn': O[0x7763] }, $h6R[O[0x7764]] = {}, $h6R[O[0x6488]] = '0', $h6R[O[0x1341]] = window[O[0x775e]][O[0x7765]], $h6R[O[0x7745]] = '', $h6R['os'] = '1', $h6R[O[0x7766]] = O[0x7767], $h6R[O[0x7768]] = O[0x7769], $h6R[O[0x776a]] = O[0x776b], $h6R[O[0x776c]] = O[0x776d], $h6R[O[0x776e]] = O[0x776f], $h6R[O[0x5f18]] = '1', $h6R[O[0x65bc]] = '', $h6R[O[0x65be]] = '', $h6R[O[0x7770]] = 0x0, $h6R[O[0x7771]] = {}, $h6R[O[0x7772]] = parseInt($h6R[O[0x5f18]]), $h6R[O[0x65ba]] = $h6R[O[0x5f18]], $h6R[O[0x65b6]] = {}, $h6R['$hY6'] = O[0x7773], $h6R[O[0x7774]] = ![], $h6R[O[0x3168]] = O[0x7775], $h6R[O[0x659a]] = Date[O[0x53]](), $h6R[O[0x2fd5]] = O[0x7776], $h6R[O[0x2e1]] = '_a', $h6R[O[0x7777]] = 0x2, $h6R[O[0x65]] = 0x7c1, $h6R[O[0x7765]] = window[O[0x775e]][O[0x7765]], $h6R[O[0x2f9]] = ![], $h6R[O[0x44a]] = ![], $h6R[O[0x2d73]] = ![], $h6R[O[0x648a]] = ![], window['$hUR6'] = 0x5, window['$hUR'] = ![], window['$hRU'] = ![], window['$h6UR'] = ![], window[O[0x7778]] = ![], window[O[0x7779]] = ![], window['$h6RU'] = ![], window['$hU6'] = ![], window['$h6U'] = ![], window['$hRU6'] = ![], window[O[0x777a]] = null, window[O[0x27f]] = function (dh09w) {
  console[O[0x1e2]](O[0x27f], dh09w), wx[O[0x145a]]({}), wx[O[0x7714]]({ 'title': O[0x19c7], 'content': dh09w, 'success'(anvs_) {
      if (anvs_[O[0x777b]]) console[O[0x1e2]](O[0x777c]);else anvs_[O[0x22a]] && console[O[0x1e2]](O[0x777d]);
    } });
}, window['$hYU6R'] = function (q43x17) {
  console[O[0x1e2]](O[0x777e], q43x17), $hY6RU(), wx[O[0x7714]]({ 'title': O[0x19c7], 'content': q43x17, 'confirmText': O[0x777f], 'cancelText': O[0x4ab4], 'success'(hw9j0d) {
      if (hw9j0d[O[0x777b]]) window['$h6Y']();else hw9j0d[O[0x22a]] && (console[O[0x1e2]](O[0x7780]), wx[O[0x6486]]({}));
    } });
}, window[O[0x7781]] = function (nvgsf) {
  console[O[0x1e2]](O[0x7781], nvgsf), wx[O[0x7714]]({ 'title': O[0x19c7], 'content': nvgsf, 'confirmText': O[0x663d], 'showCancel': ![], 'complete'(uzpr$8) {
      console[O[0x1e2]](O[0x7780]), wx[O[0x6486]]({});
    } });
}, window['$hYUR6'] = ![], window['$hY6UR'] = function (u$prz8) {
  window['$hYUR6'] = !![], wx[O[0x1459]](u$prz8);
}, window['$hY6RU'] = function () {
  window['$hYUR6'] && (window['$hYUR6'] = ![], wx[O[0x145a]]({}));
}, window['$hYRU6'] = function (q743f1) {
  window[O[0x770b]][O[0x94]]['$hYRU6'](q743f1);
}, window[O[0x30e6]] = function ($9, i62ba) {
  h_f_v3g4[O[0x30e6]]($9, function (hj0wd9) {
    hj0wd9 && hj0wd9[O[0xb]] ? hj0wd9[O[0xb]][O[0x4d0]] == 0x1 ? i62ba(!![]) : (i62ba(![]), console[O[0x4e]](O[0x7782] + hj0wd9[O[0xb]][O[0x7783]])) : console[O[0x1e2]](O[0x30e6], hj0wd9);
  });
}, window['$hYR6U'] = function (g4vfn) {
  console[O[0x1e2]](O[0x7784], g4vfn);
}, window['$hY6R'] = function ($pclu8) {}, window['$hYR6'] = function (g1v4f, vf_g3, dhzj9w) {}, window['$hYR'] = function (lmtco5) {
  console[O[0x1e2]](O[0x7785], lmtco5), window[O[0x770b]][O[0x94]][O[0x7786]](), window[O[0x770b]][O[0x94]][O[0x7787]](), window[O[0x770b]][O[0x94]][O[0x7788]]();
}, window['$hRY'] = function (clu5o) {
  window[O[0x7789]](0xe, O[0x778a] + clu5o), window['$hYU6R'](O[0x778b]);var whxq = { 'id': window['$h6R'][O[0x7701]], 'role': window['$h6R'][O[0x12f9]], 'level': window['$h6R'][O[0x7702]], 'account': window['$h6R'][O[0x65bb]], 'version': window['$h6R'][O[0x65]], 'cdn': window['$h6R'][O[0x127e]], 'pkgName': window['$h6R'][O[0x65bc]], 'gamever': window[O[0x22e]][O[0x76fc]], 'serverid': window['$h6R'][O[0x65b6]] ? window['$h6R'][O[0x65b6]][O[0x2e25]] : 0x0, 'systemInfo': window[O[0x7703]], 'error': O[0x778c], 'stack': clu5o ? clu5o : O[0x778b] },
      vgsyn = JSON[O[0x1270]](whxq);console[O[0x7d]](O[0x778d] + vgsyn), window['$hY6'](vgsyn);
}, window[O[0x7789]] = function (ys62na, clopu) {
  sendApi($h6R[O[0x776a]], O[0x778e], { 'game_pkg': $h6R[O[0x65bc]], 'partner_id': $h6R[O[0x5f18]], 'server_id': $h6R[O[0x65b6]] && $h6R[O[0x65b6]][O[0x2e25]] > 0x0 ? $h6R[O[0x65b6]][O[0x2e25]] : 0x0, 'uid': $h6R[O[0x65bb]] > 0x0 ? $h6R[O[0x65bb]] : 0x0, 'type': ys62na, 'info': clopu });
}, window['$h6YR'] = function (ib2) {
  var si2y6a = JSON[O[0x20e]](ib2);si2y6a[O[0x778f]] = window[O[0x22e]][O[0x76fc]], si2y6a[O[0x7790]] = window['$h6R'][O[0x65b6]] ? window['$h6R'][O[0x65b6]][O[0x2e25]] : 0x0, si2y6a[O[0x7703]] = window[O[0x7703]];var v_g43f = JSON[O[0x1270]](si2y6a);console[O[0x7d]](O[0x7791] + v_g43f), window['$hY6'](v_g43f);
}, window['$h6RY'] = function (r$8pu, cotp) {
  var nfv4_g = { 'id': window['$h6R'][O[0x7701]], 'role': window['$h6R'][O[0x12f9]], 'level': window['$h6R'][O[0x7702]], 'account': window['$h6R'][O[0x65bb]], 'version': window['$h6R'][O[0x65]], 'cdn': window['$h6R'][O[0x127e]], 'pkgName': window['$h6R'][O[0x65bc]], 'gamever': window[O[0x22e]][O[0x76fc]], 'serverid': window['$h6R'][O[0x65b6]] ? window['$h6R'][O[0x65b6]][O[0x2e25]] : 0x0, 'systemInfo': window[O[0x7703]], 'error': r$8pu, 'stack': cotp },
      ur8$c = JSON[O[0x1270]](nfv4_g);console[O[0x60]](O[0x7792] + ur8$c), window['$hY6'](ur8$c);
}, window['$hY6'] = function (n2yas6) {
  if (window['$h6R'][O[0x7746]] == O[0x766d]) return;var e2i6ab = $h6R['$hY6'] + O[0x7793] + $h6R[O[0x65bb]];wx[O[0x1dd]]({ 'url': e2i6ab, 'method': O[0x7673], 'data': n2yas6, 'header': { 'content-type': O[0x7794], 'cache-control': O[0x7795] }, 'success': function (xdjhw) {
      DEBUG && console[O[0x1e2]](O[0x7796], e2i6ab, n2yas6, xdjhw);
    }, 'fail': function (nsav) {
      DEBUG && console[O[0x1e2]](O[0x7796], e2i6ab, n2yas6, nsav);
    }, 'complete': function () {} });
}, window[O[0x7797]] = function () {
  function j09wh() {
    return ((0x1 + Math[O[0x77]]()) * 0x10000 | 0x0)[O[0x10e]](0x10)[O[0x1f1]](0x1);
  }return j09wh() + j09wh() + '-' + j09wh() + '-' + j09wh() + '-' + j09wh() + '+' + j09wh() + j09wh() + j09wh();
}, window['$h6Y'] = function () {
  console[O[0x1e2]](O[0x7798]);var jw09hd = h_f_v3g4[O[0x7799]]();$h6R[O[0x65ba]] = jw09hd[O[0x779a]], $h6R[O[0x7772]] = jw09hd[O[0x779a]], $h6R[O[0x5f18]] = jw09hd[O[0x779a]], $h6R[O[0x65bc]] = jw09hd[O[0x779b]];var vs_n = { 'game_ver': $h6R[O[0x1341]] };$h6R[O[0x65be]] = this[O[0x7797]](), $hY6UR({ 'title': O[0x779c] }), h_f_v3g4[O[0x16b]](vs_n, this['$hRY6'][O[0x4a]](this));
}, window['$hRY6'] = function (lmt5k) {
  var c8upr = lmt5k[O[0x779d]];sdkInitRes = lmt5k, console[O[0x1e2]](O[0x779e] + c8upr + O[0x779f] + (c8upr == 0x1) + O[0x77a0] + lmt5k[O[0x76fc]] + O[0x77a1] + window[O[0x775e]][O[0x7765]]);if (!lmt5k[O[0x76fc]] || window['$hXURY6'](window[O[0x775e]][O[0x7765]], lmt5k[O[0x76fc]]) < 0x0) console[O[0x1e2]](O[0x77a2]), $h6R[O[0x7768]] = O[0x77a3], $h6R[O[0x776a]] = O[0x77a4], $h6R[O[0x776c]] = O[0x77a5], $h6R[O[0x127e]] = O[0x77a6], $h6R[O[0x6487]] = O[0x77a7], $h6R[O[0x77a8]] = 'wd', $h6R[O[0x2f9]] = ![];else window['$hXURY6'](window[O[0x775e]][O[0x7765]], lmt5k[O[0x76fc]]) == 0x0 ? (console[O[0x1e2]](O[0x77a9]), $h6R[O[0x7768]] = O[0x7769], $h6R[O[0x776a]] = O[0x776b], $h6R[O[0x776c]] = O[0x776d], $h6R[O[0x127e]] = O[0x77aa], $h6R[O[0x6487]] = O[0x77a7], $h6R[O[0x77a8]] = O[0x77ab], $h6R[O[0x2f9]] = !![]) : (console[O[0x1e2]](O[0x77ac]), $h6R[O[0x7768]] = O[0x7769], $h6R[O[0x776a]] = O[0x776b], $h6R[O[0x776c]] = O[0x776d], $h6R[O[0x127e]] = O[0x77aa], $h6R[O[0x6487]] = O[0x77a7], $h6R[O[0x77a8]] = O[0x77ab], $h6R[O[0x2f9]] = ![]);$h6R[O[0x7770]] = config[O[0x74d3]] ? config[O[0x74d3]] : 0x0, this['$hU6YR'](), this['$hU6RY'](), window[O[0x77ad]] = 0x5, $hY6UR({ 'title': O[0x77ae] }), h_f_v3g4[O[0x76ba]](this['$hR6Y'][O[0x4a]](this));
}, window[O[0x77ad]] = 0x5, window['$hR6Y'] = function (_avsny, wdjz9h) {
  if (_avsny == 0x0 && wdjz9h && wdjz9h[O[0x752f]]) {
    $h6R[O[0x77af]] = wdjz9h[O[0x752f]];var c5ml = this;$hY6UR({ 'title': O[0x77b0] }), sendApi($h6R[O[0x7768]], O[0x77b1], { 'platform': $h6R[O[0x7766]], 'partner_id': $h6R[O[0x5f18]], 'token': wdjz9h[O[0x752f]], 'game_pkg': $h6R[O[0x65bc]], 'deviceId': $h6R[O[0x65be]], 'scene': O[0x77b2] + $h6R[O[0x7770]] }, this['$hUY6R'][O[0x4a]](this), $hUR6, $hRY);
  } else wdjz9h && wdjz9h[O[0x667d]] && window[O[0x77ad]] > 0x0 && (wdjz9h[O[0x667d]][O[0x73]](O[0x77b3]) != -0x1 || wdjz9h[O[0x667d]][O[0x73]](O[0x77b4]) != -0x1 || wdjz9h[O[0x667d]][O[0x73]](O[0x77b5]) != -0x1 || wdjz9h[O[0x667d]][O[0x73]](O[0x77b6]) != -0x1 || wdjz9h[O[0x667d]][O[0x73]](O[0x77b7]) != -0x1 || wdjz9h[O[0x667d]][O[0x73]](O[0x77b8]) != -0x1) ? (window[O[0x77ad]]--, h_f_v3g4[O[0x76ba]](this['$hR6Y'][O[0x4a]](this))) : (window[O[0x7789]](0x1, O[0x77b9] + _avsny + O[0x77ba] + (wdjz9h ? wdjz9h[O[0x667d]] : '')), window['$h6RY'](O[0x77bb], JSON[O[0x1270]]({ 'status': _avsny, 'data': wdjz9h })), window['$hYU6R'](O[0x77bc] + (wdjz9h && wdjz9h[O[0x667d]] ? '，' + wdjz9h[O[0x667d]] : '')));
}, window['$hUY6R'] = function ($r9jz) {
  if (!$r9jz) {
    window[O[0x7789]](0x2, O[0x77bd]), window['$h6RY'](O[0x77be], O[0x77bf]), window['$hYU6R'](O[0x77c0]);return;
  }if ($r9jz[O[0x4d0]] != O[0x27ca]) {
    window[O[0x7789]](0x2, O[0x77c1] + $r9jz[O[0x4d0]]), window['$h6RY'](O[0x77be], JSON[O[0x1270]]($r9jz)), window['$hYU6R'](O[0x77c2] + $r9jz[O[0x4d0]]);return;
  }$h6R[O[0x4c2f]] = String($r9jz[O[0x65bb]]), $h6R[O[0x65bb]] = String($r9jz[O[0x65bb]]), $h6R[O[0x6598]] = String($r9jz[O[0x6598]]), $h6R[O[0x65ba]] = String($r9jz[O[0x6598]]), $h6R[O[0x65bd]] = String($r9jz[O[0x65bd]]), $h6R[O[0x77c3]] = String($r9jz[O[0x2e14]]), $h6R[O[0x77c4]] = String($r9jz[O[0x36a]]), $h6R[O[0x2e14]] = '';var w7x = this;$hY6UR({ 'title': O[0x77c5] });var zu89$r = localStorage[O[0x1e0]](O[0x77c6] + $h6R[O[0x65bc]] + $h6R[O[0x65bb]]);if (zu89$r && zu89$r != '') {
    var eib6a = Number(zu89$r);w7x[O[0x77c7]](eib6a);
  } else w7x[O[0x77c8]]();
}, window[O[0x77c8]] = function () {
  var p$l5 = this;sendApi($h6R[O[0x7768]], O[0x77c9], { 'partner_id': $h6R[O[0x5f18]], 'uid': $h6R[O[0x65bb]], 'version': $h6R[O[0x1341]], 'game_pkg': $h6R[O[0x65bc]], 'device': $h6R[O[0x65be]] }, p$l5['$hUYR6'][O[0x4a]](p$l5), $hUR6, $hRY);
}, window['$hUYR6'] = function (j0d9hw) {
  if (!j0d9hw) {
    window[O[0x7789]](0x3, O[0x77ca]), window['$hYU6R'](O[0x77ca]);return;
  }if (j0d9hw[O[0x4d0]] != O[0x27ca]) {
    window[O[0x7789]](0x3, O[0x77cb] + j0d9hw[O[0x4d0]]), window['$hYU6R'](O[0x77cb] + j0d9hw[O[0x4d0]]);return;
  }if (!j0d9hw[O[0xb]] || j0d9hw[O[0xb]][O[0xd]] == 0x0) {
    window[O[0x7789]](0x3, O[0x77cc]), window['$hYU6R'](O[0x77cd]);return;
  }this[O[0x77ce]](j0d9hw);
}, window[O[0x77c7]] = function (otlpc) {
  var vsnfg_ = this;sendApi($h6R[O[0x7768]], O[0x77cf], { 'server_id': otlpc, 'time': Date[O[0x53]]() / 0x3e8 }, vsnfg_[O[0x77d0]][O[0x4a]](vsnfg_), $hUR6, $hRY);
}, window[O[0x77d0]] = function (sai2y6) {
  if (!sai2y6) {
    window[O[0x7789]](0x4, O[0x77d1]), this[O[0x77c8]]();return;
  }if (sai2y6[O[0x4d0]] != O[0x27ca]) {
    window[O[0x7789]](0x4, O[0x77d2] + sai2y6[O[0x4d0]]), this[O[0x77c8]]();return;
  }if (!sai2y6[O[0xb]] || sai2y6[O[0xb]][O[0xd]] == 0x0) {
    window[O[0x7789]](0x4, O[0x77d3]), this[O[0x77c8]]();return;
  }this[O[0x77ce]](sai2y6), window[O[0x770b]] && window[O[0x770b]][O[0x94]][O[0x77d4]] && window[O[0x770b]][O[0x94]][O[0x77d4]](sdkInitRes[O[0x77d5]], sdkInitRes[O[0x77d6]], sdkInitRes[O[0x77d7]], sdkInitRes[O[0x77d8]], sdkInitRes[O[0x77d9]]);
}, window[O[0x77ce]] = function (d9jzrh) {
  $h6R[O[0x289]] = d9jzrh[O[0x77da]] != undefined ? d9jzrh[O[0x77da]] : 0x0, $h6R[O[0x65b6]] = { 'server_id': String(d9jzrh[O[0xb]][0x0][O[0x2e25]]), 'server_name': String(d9jzrh[O[0xb]][0x0][O[0x77db]]), 'entry_ip': d9jzrh[O[0xb]][0x0][O[0x65d2]], 'entry_port': parseInt(d9jzrh[O[0xb]][0x0][O[0x65d3]]), 'status': $h6UY(d9jzrh[O[0xb]][0x0]), 'start_time': d9jzrh[O[0xb]][0x0][O[0x77dc]], 'cdn': $h6R[O[0x127e]] }, this['$hR6UY']();
}, window['$hR6UY'] = function () {
  if ($h6R[O[0x289]] == 0x1) {
    var l5opu = $h6R[O[0x65b6]][O[0x6a]];if (l5opu === -0x1 || l5opu === 0x0) {
      window[O[0x7789]](0xf, O[0x77dd] + $h6R[O[0x65b6]]['id'] + O[0x77de] + $h6R[O[0x65b6]][O[0x6a]]), window['$hYU6R'](l5opu === -0x1 ? O[0x77df] : O[0x77e0]);return;
    }$hRYU6(0x0, $h6R[O[0x65b6]][O[0x2e25]]), window[O[0x770b]][O[0x94]][O[0x77e1]]($h6R[O[0x289]]);
  } else window[O[0x770b]][O[0x94]][O[0x77e2]](), $hY6RU();window['$h6U'] = !![], window['$hRU6Y'](), window['$hR6YU']();
}, window['$hU6YR'] = function () {
  sendApi($h6R[O[0x7768]], O[0x77e3], { 'game_pkg': $h6R[O[0x65bc]], 'version_name': $h6R[O[0x77a8]] }, this[O[0x77e4]][O[0x4a]](this), $hUR6, $hRY);
}, window[O[0x77e4]] = function (u$lp8c) {
  if (!u$lp8c) {
    window[O[0x7789]](0x5, O[0x77e5]), window['$hYU6R'](O[0x77e5]);return;
  }if (u$lp8c[O[0x4d0]] != O[0x27ca]) {
    window[O[0x7789]](0x5, O[0x77e6] + u$lp8c[O[0x4d0]]), window['$hYU6R'](O[0x77e6] + u$lp8c[O[0x4d0]]);return;
  }if (!u$lp8c[O[0xb]] || !u$lp8c[O[0xb]][O[0x1341]]) {
    window[O[0x7789]](0x5, O[0x77e7] + (u$lp8c[O[0xb]] && u$lp8c[O[0xb]][O[0x1341]])), window['$hYU6R'](O[0x77e7] + (u$lp8c[O[0xb]] && u$lp8c[O[0xb]][O[0x1341]]));return;
  }u$lp8c[O[0xb]][O[0x77e8]] && u$lp8c[O[0xb]][O[0x77e8]][O[0xd]] > 0xa && ($h6R[O[0x77e9]] = u$lp8c[O[0xb]][O[0x77e8]], $h6R[O[0x127e]] = u$lp8c[O[0xb]][O[0x77e8]]), u$lp8c[O[0xb]][O[0x1341]] && ($h6R[O[0x65]] = u$lp8c[O[0xb]][O[0x1341]]), console[O[0x4e]](O[0x6643] + $h6R[O[0x65]] + O[0x77ea] + $h6R[O[0x77a8]]), window['$h6RU'] = !![], window['$hRU6Y'](), window['$hR6YU']();
}, window[O[0x77eb]], window['$hU6RY'] = function () {
  sendApi($h6R[O[0x7768]], O[0x77ec], { 'game_pkg': $h6R[O[0x65bc]] }, this['$hURY6'][O[0x4a]](this), $hUR6, $hRY);
}, window['$hURY6'] = function (hx0wd) {
  if (hx0wd && hx0wd[O[0x4d0]] === O[0x27ca] && hx0wd[O[0xb]]) {
    window[O[0x77eb]] = hx0wd[O[0xb]];for (var i2abe in hx0wd[O[0xb]]) {
      $h6R[i2abe] = hx0wd[O[0xb]][i2abe];
    }
  } else window[O[0x7789]](0xb, O[0x77ed]), console[O[0x4e]](O[0x77ee] + hx0wd[O[0x4d0]]);window['$hU6'] = !![], window['$hR6YU']();
}, window[O[0x77ef]] = function (kmtl5o, j9r8$z, ny2a6s, zpur$8, _f3v, u8z, m5clt, z9rj$, j90wdh, hd09jw) {
  _f3v = String(_f3v);var l$cu = m5clt,
      _gvsf = z9rj$;$h6R[O[0x7764]][_f3v] = { 'productid': _f3v, 'productname': l$cu, 'productdesc': _gvsf, 'roleid': kmtl5o, 'rolename': j9r8$z, 'rolelevel': ny2a6s, 'price': u8z, 'callback': j90wdh }, sendApi($h6R[O[0x776c]], O[0x77f0], { 'game_pkg': $h6R[O[0x65bc]], 'server_id': $h6R[O[0x65b6]][O[0x2e25]], 'server_name': $h6R[O[0x65b6]][O[0x77db]], 'level': ny2a6s, 'uid': $h6R[O[0x65bb]], 'role_id': kmtl5o, 'role_name': j9r8$z, 'product_id': _f3v, 'product_name': l$cu, 'product_desc': _gvsf, 'money': u8z, 'partner_id': $h6R[O[0x5f18]] }, toPayCallBack, $hUR6, $hRY);
}, window[O[0x77f1]] = function (kmotl) {
  if (kmotl && (kmotl[O[0x77f2]] === 0xc8 || kmotl[O[0x4d0]] == O[0x27ca])) {
    var _snay = $h6R[O[0x7764]][String(kmotl[O[0x77f3]])];if (_snay[O[0x14a]]) _snay[O[0x14a]](kmotl[O[0x77f3]], kmotl[O[0x77f4]], -0x1);h_f_v3g4[O[0x76e0]]({ 'cpbill': kmotl[O[0x77f4]], 'productid': kmotl[O[0x77f3]], 'productname': _snay[O[0x77f5]], 'productdesc': _snay[O[0x77f6]], 'serverid': $h6R[O[0x65b6]][O[0x2e25]], 'servername': $h6R[O[0x65b6]][O[0x77db]], 'roleid': _snay[O[0x77f7]], 'rolename': _snay[O[0x77f8]], 'rolelevel': _snay[O[0x77f9]], 'price': _snay[O[0x6cb3]], 'extension': JSON[O[0x1270]]({ 'cp_order_id': kmotl[O[0x77f4]] }) }, function (hxd0jw, dh09wj) {
      _snay[O[0x14a]] && hxd0jw == 0x0 && _snay[O[0x14a]](kmotl[O[0x77f3]], kmotl[O[0x77f4]], hxd0jw);console[O[0x4e]](JSON[O[0x1270]]({ 'type': O[0x77fa], 'status': hxd0jw, 'data': kmotl, 'role_name': _snay[O[0x77f8]] }));if (hxd0jw === 0x0) {} else {
        if (hxd0jw === 0x1) {} else {
          if (hxd0jw === 0x2) {}
        }
      }
    });
  } else {
    var ibe = kmotl ? O[0x77fb] + kmotl[O[0x77f2]] + O[0x77fc] + kmotl[O[0x4d0]] + O[0x77fd] + kmotl[O[0x4e]] : O[0x77fe];window[O[0x7789]](0xd, O[0x77ff] + ibe), alert(ibe);
  }
}, window['$hUR6Y'] = function () {}, window['$hYUR'] = function (ocmlt5, wzhjd9, iya, $c5u, tmo) {
  h_f_v3g4[O[0x76f2]]($h6R[O[0x65b6]][O[0x2e25]], $h6R[O[0x65b6]][O[0x77db]] || $h6R[O[0x65b6]][O[0x2e25]], ocmlt5, wzhjd9, iya), sendApi($h6R[O[0x7768]], O[0x7800], { 'game_pkg': $h6R[O[0x65bc]], 'server_id': $h6R[O[0x65b6]][O[0x2e25]], 'role_id': ocmlt5, 'uid': $h6R[O[0x65bb]], 'role_name': wzhjd9, 'role_type': $c5u, 'level': iya });
}, window['$hYRU'] = function (yb62ia, f34gv, f3vg_4, rhjdz9, gf_3v4, y6i2s, ibea26, gn_vy, $8rup, ltk5o) {
  $h6R[O[0x7701]] = yb62ia, $h6R[O[0x12f9]] = f34gv, $h6R[O[0x7702]] = f3vg_4, h_f_v3g4[O[0x76f3]]($h6R[O[0x65b6]][O[0x2e25]], $h6R[O[0x65b6]][O[0x77db]] || $h6R[O[0x65b6]][O[0x2e25]], yb62ia, f34gv, f3vg_4), sendApi($h6R[O[0x7768]], O[0x7801], { 'game_pkg': $h6R[O[0x65bc]], 'server_id': $h6R[O[0x65b6]][O[0x2e25]], 'role_id': yb62ia, 'uid': $h6R[O[0x65bb]], 'role_name': f34gv, 'role_type': rhjdz9, 'level': f3vg_4, 'evolution': gf_3v4 });
}, window['$hUYR'] = function (q1073, fgvs_, vnys, ltkmo, h7w0q, lu5pc, xw0q, eai6b, wh7q, d0hw9) {
  $h6R[O[0x7701]] = q1073, $h6R[O[0x12f9]] = fgvs_, $h6R[O[0x7702]] = vnys, h_f_v3g4[O[0x76f4]]($h6R[O[0x65b6]][O[0x2e25]], $h6R[O[0x65b6]][O[0x77db]] || $h6R[O[0x65b6]][O[0x2e25]], q1073, fgvs_, vnys), sendApi($h6R[O[0x7768]], O[0x7801], { 'game_pkg': $h6R[O[0x65bc]], 'server_id': $h6R[O[0x65b6]][O[0x2e25]], 'role_id': q1073, 'uid': $h6R[O[0x65bb]], 'role_name': fgvs_, 'role_type': ltkmo, 'level': vnys, 'evolution': h7w0q });
}, window['$hURY'] = function (u$pz8r) {}, window['$hYU'] = function (yv_s) {
  h_f_v3g4[O[0x76cc]](O[0x76cc], function (xj0wd) {
    yv_s && yv_s(xj0wd);
  });
}, window[O[0x5f16]] = function () {
  h_f_v3g4[O[0x5f16]]();
}, window[O[0x7802]] = function () {
  h_f_v3g4[O[0x5ea8]]();
}, window[O[0x7803]] = function (mlot5c, x0w7hq, rhzj9, dqhw, vf431g, x0q71, p8$zru, luo5c) {
  luo5c = luo5c || $h6R[O[0x65b6]][O[0x2e25]], sendApi($h6R[O[0x7768]], O[0x7804], { 'phone': mlot5c, 'role_id': x0w7hq, 'uid': $h6R[O[0x65bb]], 'game_pkg': $h6R[O[0x65bc]], 'partner_id': $h6R[O[0x5f18]], 'server_id': luo5c }, p8$zru, 0x2, null, function () {
    return !![];
  });
}, window[O[0x2b85]] = function (cl5ot) {
  window['$hRYU'] = cl5ot, window['$hRYU'] && window['$hUY'] && (console[O[0x4e]](O[0x7756] + window['$hUY'][O[0x31f]]), window['$hRYU'](window['$hUY']), window['$hUY'] = null);
}, window['$hRUY'] = function (plu$c5, kol5, oulcp5, co) {
  window[O[0x16]](O[0x7805], { 'game_pkg': window['$h6R'][O[0x65bc]], 'role_id': kol5, 'server_id': oulcp5 }, co);
}, window['$h6YUR'] = function (v31f4, jhd0w9, dw9hzj) {
  function ns_yv(cp$lu5) {
    var ans62 = [],
        $zur = [],
        rp$cu = dw9hzj || window[O[0x22e]][O[0x7806]];for (var puz$r8 in rp$cu) {
      var _n4gf = Number(puz$r8);(!v31f4 || !v31f4[O[0xd]] || v31f4[O[0x73]](_n4gf) != -0x1) && ($zur[O[0x1d]](rp$cu[puz$r8]), ans62[O[0x1d]]([_n4gf, 0x3]));
    }window['$hXURY6'](window[O[0x770c]], O[0x7807]) >= 0x0 ? (console[O[0x1e2]](O[0x7808]), h_f_v3g4[O[0x7809]] && h_f_v3g4[O[0x7809]]($zur, function (gs_) {
      console[O[0x1e2]](O[0x780a]), console[O[0x1e2]](gs_);if (gs_ && gs_[O[0x667d]] == O[0x780b]) for (var cp$lu in rp$cu) {
        if (gs_[rp$cu[cp$lu]] == O[0x780c]) {
          var ru$p8c = Number(cp$lu);for (var jrd9z = 0x0; jrd9z < ans62[O[0xd]]; jrd9z++) {
            if (ans62[jrd9z][0x0] == ru$p8c) {
              ans62[jrd9z][0x1] = 0x1;break;
            }
          }
        }
      }window['$hXURY6'](window[O[0x770c]], O[0x780d]) >= 0x0 ? wx[O[0x780e]]({ 'withSubscriptions': !![], 'success': function (qxw01) {
          var luc8$ = qxw01[O[0x780f]][O[0x7810]];if (luc8$) {
            console[O[0x1e2]](O[0x7811]), console[O[0x1e2]](luc8$);for (var h9zwj in rp$cu) {
              if (luc8$[rp$cu[h9zwj]] == O[0x780c]) {
                var fg_34v = Number(h9zwj);for (var x37q = 0x0; x37q < ans62[O[0xd]]; x37q++) {
                  if (ans62[x37q][0x0] == fg_34v) {
                    ans62[x37q][0x1] = 0x2;break;
                  }
                }
              }
            }console[O[0x1e2]](ans62), jhd0w9 && jhd0w9(ans62);
          } else console[O[0x1e2]](O[0x7812]), console[O[0x1e2]](qxw01), console[O[0x1e2]](ans62), jhd0w9 && jhd0w9(ans62);
        }, 'fail': function () {
          console[O[0x1e2]](O[0x7813]), console[O[0x1e2]](ans62), jhd0w9 && jhd0w9(ans62);
        } }) : (console[O[0x1e2]](O[0x7814] + window[O[0x770c]]), console[O[0x1e2]](ans62), jhd0w9 && jhd0w9(ans62));
    })) : (console[O[0x1e2]](O[0x7815] + window[O[0x770c]]), console[O[0x1e2]](ans62), jhd0w9 && jhd0w9(ans62)), wx[O[0x7816]](ns_yv);
  }wx[O[0x7817]](ns_yv);
}, window['$h6YRU'] = { 'isSuccess': ![], 'level': O[0x7818], 'isCharging': ![] }, window['$h6UYR'] = function (vf4_gn) {
  wx[O[0x774e]]({ 'success': function (ou5lcp) {
      var x701 = window['$h6YRU'];x701[O[0x7819]] = !![], x701[O[0x12e1]] = Number(ou5lcp[O[0x12e1]])[O[0x1166]](0x0), x701[O[0x7751]] = ou5lcp[O[0x7751]], vf4_gn && vf4_gn(x701[O[0x7819]], x701[O[0x12e1]], x701[O[0x7751]]);
    }, 'fail': function (kmlo5t) {
      console[O[0x1e2]](O[0x781a], kmlo5t[O[0x667d]]);var j9z = window['$h6YRU'];vf4_gn && vf4_gn(j9z[O[0x7819]], j9z[O[0x12e1]], j9z[O[0x7751]]);
    } });
}, window[O[0x2fb7]] = function (ia2e6b) {
  wx[O[0x2fb7]]({ 'success': function (cp8ru$) {
      ia2e6b && ia2e6b(!![], cp8ru$);
    }, 'fail': function (o5ltk) {
      ia2e6b && ia2e6b(![], o5ltk);
    } });
}, window[O[0x2fb9]] = function (zj98$) {
  if (zj98$) wx[O[0x2fb9]](zj98$);
}, window[O[0x6482]] = function (x0wqh7) {
  wx[O[0x6482]](x0wqh7);
}, window[O[0x16]] = function ($8z9ru, z9rdj, w70xqh, r$9u8z, lcto5, djrz9, up8zr$, ctpl5) {
  if (r$9u8z == undefined) r$9u8z = 0x1;wx[O[0x1dd]]({ 'url': $8z9ru, 'method': up8zr$ || O[0x6546], 'responseType': O[0x121e], 'data': z9rdj, 'header': { 'content-type': ctpl5 || O[0x7794] }, 'success': function (ml5) {
      DEBUG && console[O[0x1e2]](O[0x781b], $8z9ru, info, ml5);if (ml5 && ml5[O[0x66c3]] == 0xc8) {
        var w0hjd = ml5[O[0xb]];!djrz9 || djrz9(w0hjd) ? w70xqh && w70xqh(w0hjd) : window[O[0x781c]]($8z9ru, z9rdj, w70xqh, r$9u8z, lcto5, djrz9, ml5);
      } else window[O[0x781c]]($8z9ru, z9rdj, w70xqh, r$9u8z, lcto5, djrz9, ml5);
    }, 'fail': function (jd9zr) {
      DEBUG && console[O[0x1e2]](O[0x781d], $8z9ru, info, jd9zr), window[O[0x781c]]($8z9ru, z9rdj, w70xqh, r$9u8z, lcto5, djrz9, jd9zr);
    }, 'complete': function () {} });
}, window[O[0x781c]] = function (pul$, ctl5op, fgv_43, olcm5t, n_ysa6, ns_6ay, xw071) {
  olcm5t - 0x1 > 0x0 ? setTimeout(function () {
    window[O[0x16]](pul$, ctl5op, fgv_43, olcm5t - 0x1, n_ysa6, ns_6ay);
  }, 0x3e8) : n_ysa6 && n_ysa6(JSON[O[0x1270]]({ 'url': pul$, 'response': xw071 }));
}, window[O[0x781e]] = function (yna_6, zhwj, cpr$8, po5uc, yia26s, ans_v, xq0whd) {
  !cpr$8 && (cpr$8 = {});var _g3v4f = Math[O[0x76]](Date[O[0x53]]() / 0x3e8);cpr$8[O[0x36a]] = _g3v4f, cpr$8[O[0x781f]] = zhwj;var vng_sy = Object[O[0x106]](cpr$8)[O[0x44e]](),
      lpou5 = '',
      q7w10 = '';for (var ys6n_a = 0x0; ys6n_a < vng_sy[O[0xd]]; ys6n_a++) {
    lpou5 = lpou5 + (ys6n_a == 0x0 ? '' : '&') + vng_sy[ys6n_a] + cpr$8[vng_sy[ys6n_a]], q7w10 = q7w10 + (ys6n_a == 0x0 ? '' : '&') + vng_sy[ys6n_a] + '=' + encodeURIComponent(cpr$8[vng_sy[ys6n_a]]);
  }lpou5 = lpou5 + $h6R[O[0x776e]];var whzd9 = O[0x7820] + md5(lpou5);send(yna_6 + '?' + q7w10 + (q7w10 == '' ? '' : '&') + whzd9, null, po5uc, yia26s, ans_v, xq0whd || function ($c8lup) {
    return $c8lup[O[0x4d0]] == O[0x27ca];
  }, null, O[0x7674]);
}, window['$h6URY'] = function (v_nygs, y6i2b) {
  var r$z8u9 = 0x0;$h6R[O[0x65b6]] && (r$z8u9 = $h6R[O[0x65b6]][O[0x2e25]]), sendApi($h6R[O[0x776a]], O[0x7821], { 'partnerId': $h6R[O[0x5f18]], 'gamePkg': $h6R[O[0x65bc]], 'logTime': Math[O[0x76]](Date[O[0x53]]() / 0x3e8), 'platformUid': $h6R[O[0x65bd]], 'type': v_nygs, 'serverId': r$z8u9 }, null, 0x2, null, function () {
    return !![];
  });
}, window['$h6RYU'] = function (v_sny) {
  sendApi($h6R[O[0x7768]], O[0x7822], { 'partner_id': $h6R[O[0x5f18]], 'uid': $h6R[O[0x65bb]], 'version': $h6R[O[0x1341]], 'game_pkg': $h6R[O[0x65bc]], 'device': $h6R[O[0x65be]] }, $h6RUY, $hUR6, $hRY);
}, window['$h6RUY'] = function (hzw9) {
  if (hzw9 && hzw9[O[0x4d0]] === O[0x27ca] && hzw9[O[0xb]]) {
    hzw9[O[0xb]][O[0x16b7]]({ 'id': -0x2, 'name': O[0x7823] }), hzw9[O[0xb]][O[0x16b7]]({ 'id': -0x1, 'name': O[0x7824] }), $h6R[O[0x7825]] = hzw9[O[0xb]];if (window[O[0x319b]]) window[O[0x319b]][O[0x7826]]();
  } else {
    $h6R[O[0x7827]] = ![];var iab = hzw9 ? hzw9[O[0x4d0]] : '';window[O[0x7789]](0x7, O[0x7828] + iab), window['$hYU6R'](O[0x7829] + iab);
  }
}, window['$hYU6'] = function ($prz8u) {
  sendApi($h6R[O[0x7768]], O[0x782a], { 'partner_id': $h6R[O[0x5f18]], 'uid': $h6R[O[0x65bb]], 'version': $h6R[O[0x1341]], 'game_pkg': $h6R[O[0x65bc]], 'device': $h6R[O[0x65be]] }, $hY6U, $hUR6, $hRY);
}, window['$hY6U'] = function (vs_yg) {
  $h6R[O[0x782b]] = ![];if (vs_yg && vs_yg[O[0x4d0]] === O[0x27ca] && vs_yg[O[0xb]]) {
    for (var jrz8$9 = 0x0; jrz8$9 < vs_yg[O[0xb]][O[0xd]]; jrz8$9++) {
      vs_yg[O[0xb]][jrz8$9][O[0x6a]] = $h6UY(vs_yg[O[0xb]][jrz8$9]);
    }$h6R[O[0x7771]][-0x1] = window[O[0x782c]](vs_yg[O[0xb]]), window[O[0x319b]][O[0x782d]](-0x1);
  } else {
    var d9 = vs_yg ? vs_yg[O[0x4d0]] : '';window[O[0x7789]](0x8, O[0x782e] + d9), window['$hYU6R'](O[0x782f] + d9);
  }
}, window[O[0x7830]] = function (lm5otc) {
  sendApi($h6R[O[0x7768]], O[0x782a], { 'partner_id': $h6R[O[0x5f18]], 'uid': $h6R[O[0x65bb]], 'version': $h6R[O[0x1341]], 'game_pkg': $h6R[O[0x65bc]], 'device': $h6R[O[0x65be]] }, lm5otc, $hUR6, $hRY);
}, window['$hUY6'] = function (xwhjd0, hx70wq) {
  sendApi($h6R[O[0x7768]], O[0x7831], { 'partner_id': $h6R[O[0x5f18]], 'uid': $h6R[O[0x65bb]], 'version': $h6R[O[0x1341]], 'game_pkg': $h6R[O[0x65bc]], 'device': $h6R[O[0x65be]], 'server_group_id': hx70wq }, $hU6Y, $hUR6, $hRY);
}, window['$hU6Y'] = function (m5otlc) {
  $h6R[O[0x782b]] = ![];if (m5otlc && m5otlc[O[0x4d0]] === O[0x27ca] && m5otlc[O[0xb]] && m5otlc[O[0xb]][O[0xb]]) {
    var clu8$p = m5otlc[O[0xb]][O[0x7832]],
        qf41 = [];for (var s2na6 = 0x0; s2na6 < m5otlc[O[0xb]][O[0xb]][O[0xd]]; s2na6++) {
      m5otlc[O[0xb]][O[0xb]][s2na6][O[0x6a]] = $h6UY(m5otlc[O[0xb]][O[0xb]][s2na6]), (qf41[O[0xd]] == 0x0 || m5otlc[O[0xb]][O[0xb]][s2na6][O[0x6a]] != 0x0) && (qf41[qf41[O[0xd]]] = m5otlc[O[0xb]][O[0xb]][s2na6]);
    }$h6R[O[0x7771]][clu8$p] = window[O[0x782c]](qf41), window[O[0x319b]][O[0x782d]](clu8$p);
  } else {
    var vnf = m5otlc ? m5otlc[O[0x4d0]] : '';window[O[0x7789]](0x9, O[0x7833] + vnf), window['$hYU6R'](O[0x7834] + vnf);
  }
}, window['$hXUR6'] = function (z9ur$) {
  sendApi($h6R[O[0x7768]], O[0x7835], { 'partner_id': $h6R[O[0x5f18]], 'uid': $h6R[O[0x65bb]], 'version': $h6R[O[0x1341]], 'game_pkg': $h6R[O[0x65bc]], 'device': $h6R[O[0x65be]] }, reqServerRecommendCallBack, $hUR6, $hRY);
}, window[O[0x7836]] = function (_nfsgv) {
  $h6R[O[0x782b]] = ![];if (_nfsgv && _nfsgv[O[0x4d0]] === O[0x27ca] && _nfsgv[O[0xb]]) {
    for (var eb2a6 = 0x0; eb2a6 < _nfsgv[O[0xb]][O[0xd]]; eb2a6++) {
      _nfsgv[O[0xb]][eb2a6][O[0x6a]] = $h6UY(_nfsgv[O[0xb]][eb2a6]);
    }$h6R[O[0x7771]][-0x2] = window[O[0x782c]](_nfsgv[O[0xb]]), window[O[0x319b]][O[0x782d]](-0x2);
  } else {
    var mc5lt = _nfsgv ? _nfsgv[O[0x4d0]] : '';window[O[0x7789]](0xa, O[0x7837] + mc5lt), alert(O[0x7838] + mc5lt);
  }
}, window[O[0x782c]] = function (wzjd9) {
  return wzjd9;
}, window['$h6YU'] = function ($pzr, d9hjr) {
  $pzr = $pzr || $h6R[O[0x65b6]][O[0x2e25]], sendApi($h6R[O[0x7768]], O[0x7839], { 'type': '4', 'game_pkg': $h6R[O[0x65bc]], 'server_id': $pzr }, d9hjr);
}, window[O[0x783a]] = function (qdx0wh, hjxdw, q1x347, ru$89) {
  q1x347 = q1x347 || $h6R[O[0x65b6]][O[0x2e25]], sendApi($h6R[O[0x7768]], O[0x783b], { 'type': qdx0wh, 'game_pkg': hjxdw, 'server_id': q1x347 }, ru$89);
}, window[O[0x783c]] = function (savn_y, ya2b6) {
  sendApi($h6R[O[0x7768]], O[0x783d], { 'game_pkg': savn_y }, ya2b6);
}, window['$h6UY'] = function (x7301q) {
  if (x7301q) {
    if (x7301q[O[0x6a]] == 0x1) {
      if (x7301q[O[0x783e]] == 0x1) return 0x2;else return 0x1;
    } else return x7301q[O[0x6a]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$hRYU6'] = function (j0hd9w, u$lc5) {
  $h6R[O[0x783f]] = { 'step': j0hd9w, 'server_id': u$lc5 };var j8r$z9 = this;$hY6UR({ 'title': O[0x7840] }), sendApi($h6R[O[0x7768]], O[0x7841], { 'partner_id': $h6R[O[0x5f18]], 'uid': $h6R[O[0x65bb]], 'game_pkg': $h6R[O[0x65bc]], 'server_id': u$lc5, 'platform': $h6R[O[0x6598]], 'platform_uid': $h6R[O[0x65bd]], 'check_login_time': $h6R[O[0x77c4]], 'check_login_sign': $h6R[O[0x77c3]], 'version_name': $h6R[O[0x77a8]] }, $hRY6U, $hUR6, $hRY, function (w0d9jh) {
    return w0d9jh[O[0x4d0]] == O[0x27ca] || w0d9jh[O[0x4e]] == O[0x7842] || w0d9jh[O[0x4e]] == O[0x7843];
  });
}, window['$hRY6U'] = function (si26y) {
  var purz8 = this;if (si26y && si26y[O[0x4d0]] === O[0x27ca] && si26y[O[0xb]]) {
    var p$8c = $h6R[O[0x65b6]];p$8c[O[0x7844]] = $h6R[O[0x7772]], p$8c[O[0x2e14]] = String(si26y[O[0xb]][O[0x7845]]), p$8c[O[0x659a]] = parseInt(si26y[O[0xb]][O[0x36a]]);if (si26y[O[0xb]][O[0x6599]]) p$8c[O[0x6599]] = parseInt(si26y[O[0xb]][O[0x6599]]);else p$8c[O[0x6599]] = parseInt(si26y[O[0xb]][O[0x2e25]]);p$8c[O[0x7846]] = 0x0, p$8c[O[0x127e]] = $h6R[O[0x77e9]], p$8c[O[0x7847]] = si26y[O[0xb]][O[0x7848]], p$8c[O[0x7849]] = si26y[O[0xb]][O[0x7849]];if (si26y[O[0xb]][O[0x659d]]) p$8c[O[0x659d]] = parseInt(si26y[O[0xb]][O[0x659d]]);console[O[0x1e2]](O[0x784a] + JSON[O[0x1270]](p$8c[O[0x7849]])), $h6R[O[0x289]] == 0x1 && p$8c[O[0x7849]] && p$8c[O[0x7849]][O[0x784b]] == 0x1 && ($h6R[O[0x784c]] = 0x1, window[O[0x770b]][O[0x94]]['$hXR6']()), $hRUY6();
  } else {
    if ($h6R[O[0x783f]][O[0x1cd8]] >= 0x3) {
      var klt5o = si26y ? si26y[O[0x4d0]] : '';window[O[0x7789]](0xc, O[0x784d] + klt5o), $hRY(JSON[O[0x1270]](si26y)), window['$hYU6R'](O[0x784e] + klt5o);
    } else sendApi($h6R[O[0x7768]], O[0x77b1], { 'platform': $h6R[O[0x7766]], 'partner_id': $h6R[O[0x5f18]], 'token': $h6R[O[0x77af]], 'game_pkg': $h6R[O[0x65bc]], 'deviceId': $h6R[O[0x65be]], 'scene': O[0x77b2] + $h6R[O[0x7770]] }, function (fgn_s) {
      if (!fgn_s || fgn_s[O[0x4d0]] != O[0x27ca]) {
        window['$hYU6R'](O[0x77c2] + fgn_s && fgn_s[O[0x4d0]]);return;
      }$h6R[O[0x77c3]] = String(fgn_s[O[0x2e14]]), $h6R[O[0x77c4]] = String(fgn_s[O[0x36a]]), setTimeout(function () {
        $hRYU6($h6R[O[0x783f]][O[0x1cd8]] + 0x1, $h6R[O[0x783f]][O[0x2e25]]);
      }, 0x5dc);
    }, $hUR6, $hRY, function (rpuc$8) {
      return rpuc$8[O[0x4d0]] == O[0x27ca] || rpuc$8[O[0x4d0]] == O[0x6711];
    });
  }
}, window['$hRUY6'] = function () {
  ServerLoading[O[0x94]][O[0x77e1]]($h6R[O[0x289]]), window['$hUR'] = !![], window['$hR6YU']();
}, window['$hRU6Y'] = function () {
  if (window['$hRU'] && window['$h6UR'] && window[O[0x7778]] && window[O[0x7779]] && window['$h6RU'] && window['$h6U']) {
    if (!window[O[0x74be]][O[0x94]]) {
      console[O[0x1e2]](O[0x784f] + window[O[0x74be]][O[0x94]]);var syn2a6 = wx[O[0x7850]](),
          jrd9zh = syn2a6[O[0x31f]] ? syn2a6[O[0x31f]] : 0x0,
          hj9dr = { 'cdn': window['$h6R'][O[0x127e]], 'spareCdn': window['$h6R'][O[0x6487]], 'newRegister': window['$h6R'][O[0x289]], 'wxPC': window['$h6R'][O[0x648a]], 'wxIOS': window['$h6R'][O[0x44a]], 'wxAndroid': window['$h6R'][O[0x2d73]], 'wxParam': { 'limitLoad': window['$h6R']['$hXYUR6'], 'benchmarkLevel': window['$h6R']['$hXY6UR'], 'wxFrom': window[O[0x22e]][O[0x74d3]] == O[0x7851] ? 0x1 : 0x0, 'wxSDKVersion': window[O[0x770c]] }, 'configType': window['$h6R'][O[0x2fd5]], 'exposeType': window['$h6R'][O[0x2e1]], 'scene': jrd9zh };new window[O[0x74be]](hj9dr, window['$h6R'][O[0x65]], window['$hXYU6R']);
    }
  }
}, window['$hR6YU'] = function () {
  if (window['$hRU'] && window['$h6UR'] && window[O[0x7778]] && window[O[0x7779]] && window['$h6RU'] && window['$h6U'] && window['$hUR'] && window['$hU6']) {
    $hY6RU();if (!$hRU6) {
      $hRU6 = !![];if (!window[O[0x74be]][O[0x94]]) window['$hRU6Y']();var luc$8p = 0x0,
          x70wq1 = wx[O[0x7852]]();x70wq1 && (window['$h6R'][O[0x7743]] && (luc$8p = x70wq1[O[0x13e]]), console[O[0x4e]](O[0x7853] + x70wq1[O[0x13e]] + O[0x7854] + x70wq1[O[0x4e4]] + O[0x7855] + x70wq1[O[0x4e6]] + O[0x7856] + x70wq1[O[0x4e5]] + O[0x7857] + x70wq1[O[0xb2]] + O[0x7858] + x70wq1[O[0xb3]]));var g4f_v = {};for (const sia2 in $h6R[O[0x65b6]]) {
        g4f_v[sia2] = $h6R[O[0x65b6]][sia2];
      }var hdjzw = { 'channel': window['$h6R'][O[0x65ba]], 'account': window['$h6R'][O[0x65bb]], 'userId': window['$h6R'][O[0x4c2f]], 'cdn': window['$h6R'][O[0x127e]], 'data': window['$h6R'][O[0xb]], 'package': window['$h6R'][O[0x6488]], 'newRegister': window['$h6R'][O[0x289]], 'pkgName': window['$h6R'][O[0x65bc]], 'partnerId': window['$h6R'][O[0x5f18]], 'platform_uid': window['$h6R'][O[0x65bd]], 'deviceId': window['$h6R'][O[0x65be]], 'selectedServer': g4f_v, 'configType': window['$h6R'][O[0x2fd5]], 'exposeType': window['$h6R'][O[0x2e1]], 'debugUsers': window['$h6R'][O[0x3168]], 'wxMenuTop': luc$8p, 'wxShield': window['$h6R'][O[0x2f9]] };if (window[O[0x77eb]]) for (var tmlk5o in window[O[0x77eb]]) {
        hdjzw[tmlk5o] = window[O[0x77eb]][tmlk5o];
      }window[O[0x74be]][O[0x94]]['$hR6X'](hdjzw);if ($h6R[O[0x65b6]] && $h6R[O[0x65b6]][O[0x2e25]]) localStorage[O[0x1e5]](O[0x77c6] + $h6R[O[0x65bc]] + $h6R[O[0x65bb]], $h6R[O[0x65b6]][O[0x2e25]]);
    }
  } else console[O[0x4e]](O[0x7859] + window['$hRU'] + O[0x785a] + window['$h6UR'] + O[0x785b] + window[O[0x7778]] + O[0x785c] + window[O[0x7779]] + O[0x785d] + window['$h6RU'] + O[0x785e] + window['$h6U'] + O[0x785f] + window['$hUR'] + O[0x7860] + window['$hU6']);
};