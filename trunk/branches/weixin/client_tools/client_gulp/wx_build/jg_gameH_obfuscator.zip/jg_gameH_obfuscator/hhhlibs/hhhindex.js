var O = wx.$C;
import h_$9rj8z from '../hhhhsdk/hhhsdk.js';window[O[129261]] = { 'wxVersion': window[O[100557]][O[129159]] }, window[O[129262]] = ![], window['$hR6'] = 0x1, window[O[129263]] = 0x1, window['$hU6R'] = !![], window[O[129264]] = !![], window['$hXYU6R'] = '', window['$h6R'] = { 'base_cdn': O[129265], 'cdn': O[129265] }, $h6R[O[129266]] = {}, $h6R[O[125049]] = '0', $h6R[O[104741]] = window[O[129261]][O[129267]], $h6R[O[129233]] = '', $h6R['os'] = '1', $h6R[O[129268]] = O[129269], $h6R[O[129270]] = O[129271], $h6R[O[129272]] = O[129273], $h6R[O[129274]] = O[129275], $h6R[O[129276]] = O[129277], $h6R[O[123749]] = '1', $h6R[O[125344]] = '', $h6R[O[125346]] = '', $h6R[O[129278]] = 0x0, $h6R[O[129279]] = {}, $h6R[O[129280]] = parseInt($h6R[O[123749]]), $h6R[O[125342]] = $h6R[O[123749]], $h6R[O[125338]] = {}, $h6R['$hY6'] = O[129281], $h6R[O[129282]] = ![], $h6R[O[112293]] = O[129283], $h6R[O[125317]] = Date[O[100083]](), $h6R[O[111895]] = O[129284], $h6R[O[100714]] = '_a', $h6R[O[129285]] = 0x2, $h6R[O[100101]] = 0x7c1, $h6R[O[129267]] = window[O[129261]][O[129267]], $h6R[O[100738]] = ![], $h6R[O[101074]] = ![], $h6R[O[111371]] = ![], $h6R[O[125051]] = ![], window['$hUR6'] = 0x5, window['$hUR'] = ![], window['$hRU'] = ![], window['$h6UR'] = ![], window[O[129286]] = ![], window[O[129287]] = ![], window['$h6RU'] = ![], window['$hU6'] = ![], window['$h6U'] = ![], window['$hRU6'] = ![], window[O[104209]] = function (r$8pzu) {
  console[O[100482]](O[104209], r$8pzu), wx[O[105021]]({}), wx[O[129183]]({ 'title': O[106391], 'content': r$8pzu, 'success'(vn4f_g) {
      if (vn4f_g[O[129288]]) console[O[100482]](O[129289]);else vn4f_g[O[100553]] && console[O[100482]](O[129290]);
    } });
}, window['$hYU6R'] = function (omtk) {
  console[O[100482]](O[129291], omtk), $hY6RU(), wx[O[129183]]({ 'title': O[106391], 'content': omtk, 'confirmText': O[129292], 'cancelText': O[118581], 'success'(omltk) {
      if (omltk[O[129288]]) window['$h6Y']();else omltk[O[100553]] && (console[O[100482]](O[129293]), wx[O[125044]]({}));
    } });
}, window[O[129294]] = function (r8$pcu) {
  console[O[100482]](O[129294], r8$pcu), wx[O[129183]]({ 'title': O[106391], 'content': r8$pcu, 'confirmText': O[125474], 'showCancel': ![], 'complete'(y2nas6) {
      console[O[100482]](O[129293]), wx[O[125044]]({});
    } });
}, window['$hYUR6'] = ![], window['$hY6UR'] = function (g3v4) {
  window['$hYUR6'] = !![], wx[O[105020]](g3v4);
}, window['$hY6RU'] = function () {
  window['$hYUR6'] && (window['$hYUR6'] = ![], wx[O[105021]]({}));
}, window['$hYRU6'] = function (lu5po) {
  window[O[129174]][O[100148]]['$hYRU6'](lu5po);
}, window[O[112171]] = function (i6a2be, opcl) {
  h_$9rj8z[O[112171]](i6a2be, function (cu$8rp) {
    cu$8rp && cu$8rp[O[100011]] ? cu$8rp[O[100011]][O[104142]] == 0x1 ? opcl(!![]) : (opcl(![]), console[O[100078]](O[129295] + cu$8rp[O[100011]][O[129296]])) : console[O[100482]](O[112171], cu$8rp);
  });
}, window['$hYR6U'] = function (z9drjh) {
  console[O[100482]](O[129297], z9drjh);
}, window['$hY6R'] = function (oclm5) {}, window['$hYR6'] = function (qwdh, jd9rzh, hzr9) {}, window['$hYR'] = function (cu5$p) {
  console[O[100482]](O[129298], cu5$p), window[O[129174]][O[100148]][O[129299]](), window[O[129174]][O[100148]][O[129300]](), window[O[129174]][O[100148]][O[129301]]();
}, window['$hRY'] = function (j9hw0) {
  window['$hYU6R'](O[129302]);var vg_sny = { 'id': window['$h6R'][O[129164]], 'role': window['$h6R'][O[104670]], 'level': window['$h6R'][O[129165]], 'account': window['$h6R'][O[125343]], 'version': window['$h6R'][O[100101]], 'cdn': window['$h6R'][O[104547]], 'pkgName': window['$h6R'][O[125344]], 'gamever': window[O[100557]][O[129159]], 'serverid': window['$h6R'][O[125338]] ? window['$h6R'][O[125338]][O[111549]] : 0x0, 'systemInfo': window[O[129166]], 'error': O[129303], 'stack': j9hw0 ? j9hw0 : O[129302] },
      rzu$98 = JSON[O[104533]](vg_sny);console[O[100125]](O[129304] + rzu$98), window['$hY6'](rzu$98);
}, window['$h6YR'] = function (gvs_fn) {
  var oulp = JSON[O[100527]](gvs_fn);oulp[O[129305]] = window[O[100557]][O[129159]], oulp[O[129306]] = window['$h6R'][O[125338]] ? window['$h6R'][O[125338]][O[111549]] : 0x0, oulp[O[129166]] = window[O[129166]];var c5tlop = JSON[O[104533]](oulp);console[O[100125]](O[129307] + c5tlop), window['$hY6'](c5tlop);
}, window['$h6RY'] = function (jwhz, opt5cl) {
  var qxhw70 = { 'id': window['$h6R'][O[129164]], 'role': window['$h6R'][O[104670]], 'level': window['$h6R'][O[129165]], 'account': window['$h6R'][O[125343]], 'version': window['$h6R'][O[100101]], 'cdn': window['$h6R'][O[104547]], 'pkgName': window['$h6R'][O[125344]], 'gamever': window[O[100557]][O[129159]], 'serverid': window['$h6R'][O[125338]] ? window['$h6R'][O[125338]][O[111549]] : 0x0, 'systemInfo': window[O[129166]], 'error': jwhz, 'stack': opt5cl },
      ys_na6 = JSON[O[104533]](qxhw70);console[O[100096]](O[129308] + ys_na6), window['$hY6'](ys_na6);
}, window['$hY6'] = function (vg_ysn) {
  if (window['$h6R'][O[129234]] == O[129016]) return;var hrdj9z = $h6R['$hY6'] + O[129309] + $h6R[O[125343]];wx[O[100477]]({ 'url': hrdj9z, 'method': O[129022], 'data': vg_ysn, 'header': { 'content-type': O[129310], 'cache-control': O[129311] }, 'success': function (o5plt) {
      DEBUG && console[O[100482]](O[129312], hrdj9z, vg_ysn, o5plt);
    }, 'fail': function (gf4_vn) {
      DEBUG && console[O[100482]](O[129312], hrdj9z, vg_ysn, gf4_vn);
    }, 'complete': function () {} });
}, window[O[129313]] = function () {
  function rzdj98() {
    return ((0x1 + Math[O[100119]]()) * 0x10000 | 0x0)[O[100275]](0x10)[O[100500]](0x1);
  }return rzdj98() + rzdj98() + '-' + rzdj98() + '-' + rzdj98() + '-' + rzdj98() + '+' + rzdj98() + rzdj98() + rzdj98();
}, window['$h6Y'] = function () {
  console[O[100482]](O[129314]);var jw09hd = h_$9rj8z[O[129315]]();$h6R[O[125342]] = jw09hd[O[129316]], $h6R[O[129280]] = jw09hd[O[129316]], $h6R[O[123749]] = jw09hd[O[129316]], $h6R[O[125344]] = jw09hd[O[129317]];var fgn_v4 = { 'game_ver': $h6R[O[104741]] };$h6R[O[125346]] = this[O[129313]](), $hY6UR({ 'title': O[129318] }), h_$9rj8z[O[100368]](fgn_v4, this['$hRY6'][O[100074]](this));
}, window['$hRY6'] = function (sgn_yv) {
  var sy_a6n = sgn_yv[O[129319]];console[O[100482]](O[129320] + sy_a6n + O[129321] + (sy_a6n == 0x1) + O[129322] + sgn_yv[O[129159]] + O[129323] + window[O[129261]][O[129267]]);if (!sgn_yv[O[129159]] || window['$hXURY6'](window[O[129261]][O[129267]], sgn_yv[O[129159]]) < 0x0) console[O[100482]](O[129324]), $h6R[O[129270]] = O[129325], $h6R[O[129272]] = O[129326], $h6R[O[129274]] = O[129327], $h6R[O[104547]] = O[129328], $h6R[O[125048]] = O[129329], $h6R[O[129330]] = 'wd', $h6R[O[100738]] = ![];else window['$hXURY6'](window[O[129261]][O[129267]], sgn_yv[O[129159]]) == 0x0 ? (console[O[100482]](O[129331]), $h6R[O[129270]] = O[129271], $h6R[O[129272]] = O[129273], $h6R[O[129274]] = O[129275], $h6R[O[104547]] = O[129332], $h6R[O[125048]] = O[129329], $h6R[O[129330]] = O[129333], $h6R[O[100738]] = !![]) : (console[O[100482]](O[129334]), $h6R[O[129270]] = O[129271], $h6R[O[129272]] = O[129273], $h6R[O[129274]] = O[129275], $h6R[O[104547]] = O[129332], $h6R[O[125048]] = O[129329], $h6R[O[129330]] = O[129333], $h6R[O[100738]] = ![]);$h6R[O[129278]] = config[O[128629]] ? config[O[128629]] : 0x0, this['$hU6YR'](), this['$hU6RY'](), window[O[129335]] = 0x5, $hY6UR({ 'title': O[129336] }), h_$9rj8z[O[129093]](this['$hR6Y'][O[100074]](this));
}, window[O[129335]] = 0x5, window['$hR6Y'] = function (xq0wdh, n6y2sa) {
  if (xq0wdh == 0x0 && n6y2sa && n6y2sa[O[128722]]) {
    $h6R[O[129337]] = n6y2sa[O[128722]];var vfsg_ = this;$hY6UR({ 'title': O[129338] }), sendApi($h6R[O[129270]], O[129339], { 'platform': $h6R[O[129268]], 'partner_id': $h6R[O[123749]], 'token': n6y2sa[O[128722]], 'game_pkg': $h6R[O[125344]], 'deviceId': $h6R[O[125346]], 'scene': O[129340] + $h6R[O[129278]] }, this['$hUY6R'][O[100074]](this), $hUR6, $hRY);
  } else n6y2sa && n6y2sa[O[125527]] && window[O[129335]] > 0x0 && (n6y2sa[O[125527]][O[100115]](O[129341]) != -0x1 || n6y2sa[O[125527]][O[100115]](O[129342]) != -0x1 || n6y2sa[O[125527]][O[100115]](O[129343]) != -0x1 || n6y2sa[O[125527]][O[100115]](O[129344]) != -0x1 || n6y2sa[O[125527]][O[100115]](O[129345]) != -0x1 || n6y2sa[O[125527]][O[100115]](O[129346]) != -0x1) ? (window[O[129335]]--, h_$9rj8z[O[129093]](this['$hR6Y'][O[100074]](this))) : (window['$h6RY'](O[129347], JSON[O[104533]]({ 'status': xq0wdh, 'data': n6y2sa })), window['$hYU6R'](O[129348] + (n6y2sa && n6y2sa[O[125527]] ? '，' + n6y2sa[O[125527]] : '')));
}, window['$hUY6R'] = function (syg_n) {
  if (!syg_n) {
    window['$h6RY'](O[129349], O[129350]), window['$hYU6R'](O[129351]);return;
  }if (syg_n[O[104142]] != O[109959]) {
    window['$h6RY'](O[129349], JSON[O[104533]](syg_n)), window['$hYU6R'](O[129352] + syg_n[O[104142]]);return;
  }$h6R[O[123748]] = String(syg_n[O[125343]]), $h6R[O[125343]] = String(syg_n[O[125343]]), $h6R[O[125315]] = String(syg_n[O[125315]]), $h6R[O[125342]] = String(syg_n[O[125315]]), $h6R[O[125345]] = String(syg_n[O[125345]]), $h6R[O[129353]] = String(syg_n[O[111532]]), $h6R[O[129354]] = String(syg_n[O[100851]]), $h6R[O[111532]] = '';var r8u$c = this;$hY6UR({ 'title': O[129355] }), sendApi($h6R[O[129270]], O[129356], { 'partner_id': $h6R[O[123749]], 'uid': $h6R[O[125343]], 'version': $h6R[O[104741]], 'game_pkg': $h6R[O[125344]], 'device': $h6R[O[125346]] }, r8u$c['$hUYR6'][O[100074]](r8u$c), $hUR6, $hRY);
}, window['$hUYR6'] = function (abi2e) {
  if (!abi2e) {
    window['$hYU6R'](O[129357]);return;
  }if (abi2e[O[104142]] != O[109959]) {
    window['$hYU6R'](O[129358] + abi2e[O[104142]]);return;
  }if (!abi2e[O[100011]] || abi2e[O[100011]][O[100013]] == 0x0) {
    window['$hYU6R'](O[129359]);return;
  }$h6R[O[100630]] = abi2e[O[129360]], $h6R[O[125338]] = { 'server_id': String(abi2e[O[100011]][0x0][O[111549]]), 'server_name': String(abi2e[O[100011]][0x0][O[129361]]), 'entry_ip': abi2e[O[100011]][0x0][O[125366]], 'entry_port': parseInt(abi2e[O[100011]][0x0][O[125367]]), 'status': $h6UY(abi2e[O[100011]][0x0]), 'start_time': abi2e[O[100011]][0x0][O[129362]], 'cdn': $h6R[O[104547]] }, this['$hR6UY']();
}, window['$hR6UY'] = function () {
  if ($h6R[O[100630]] == 0x1) {
    var _fg4vn = $h6R[O[125338]][O[100106]];if (_fg4vn === -0x1 || _fg4vn === 0x0) {
      window['$hYU6R'](_fg4vn === -0x1 ? O[129363] : O[129364]);return;
    }$hRYU6(0x0, $h6R[O[125338]][O[111549]]), window[O[129174]][O[100148]][O[129365]]($h6R[O[100630]]);
  } else window[O[129174]][O[100148]][O[129366]](), $hY6RU();window['$h6U'] = !![], window['$hRU6Y'](), window['$hR6YU']();
}, window['$hU6YR'] = function () {
  sendApi($h6R[O[129270]], O[129367], { 'game_pkg': $h6R[O[125344]], 'version_name': $h6R[O[129330]] }, this[O[129368]][O[100074]](this), $hUR6, $hRY);
}, window[O[129368]] = function (whxq70) {
  if (!whxq70) {
    window['$hYU6R'](O[129369]);return;
  }if (whxq70[O[104142]] != O[109959]) {
    window['$hYU6R'](O[129370] + whxq70[O[104142]]);return;
  }if (!whxq70[O[100011]] || !whxq70[O[100011]][O[104741]]) {
    window['$hYU6R'](O[129371] + (whxq70[O[100011]] && whxq70[O[100011]][O[104741]]));return;
  }whxq70[O[100011]][O[129372]] && whxq70[O[100011]][O[129372]][O[100013]] > 0xa && ($h6R[O[129373]] = whxq70[O[100011]][O[129372]], $h6R[O[104547]] = whxq70[O[100011]][O[129372]]), whxq70[O[100011]][O[104741]] && ($h6R[O[100101]] = whxq70[O[100011]][O[104741]]), console[O[100078]](O[125480] + $h6R[O[100101]] + O[129374] + $h6R[O[129330]]), window['$h6RU'] = !![], window['$hRU6Y'](), window['$hR6YU']();
}, window[O[129375]], window['$hU6RY'] = function () {
  sendApi($h6R[O[129270]], O[129376], { 'game_pkg': $h6R[O[125344]] }, this['$hURY6'][O[100074]](this), $hUR6, $hRY);
}, window['$hURY6'] = function (n26asy) {
  if (n26asy[O[104142]] === O[109959] && n26asy[O[100011]]) {
    window[O[129375]] = n26asy[O[100011]];for (var _anvs in n26asy[O[100011]]) {
      $h6R[_anvs] = n26asy[O[100011]][_anvs];
    }
  } else console[O[100078]](O[129377] + n26asy[O[104142]]);window['$hU6'] = !![], window['$hR6YU']();
}, window[O[129378]] = function (xd0hqw, rzp$8u, r8c, p8$uc, vgny_, p$cul, iay62b, uclop5, ys6a_) {
  vgny_ = String(vgny_);var g4_f3v = iay62b,
      g74f = uclop5;$h6R[O[129266]][vgny_] = { 'productid': vgny_, 'productname': g4_f3v, 'productdesc': g74f, 'roleid': xd0hqw, 'rolename': rzp$8u, 'rolelevel': r8c, 'price': p$cul, 'callback': ys6a_ }, sendApi($h6R[O[129274]], O[129379], { 'game_pkg': $h6R[O[125344]], 'server_id': $h6R[O[125338]][O[111549]], 'server_name': $h6R[O[125338]][O[129361]], 'level': r8c, 'uid': $h6R[O[125343]], 'role_id': xd0hqw, 'role_name': rzp$8u, 'product_id': vgny_, 'product_name': g4_f3v, 'product_desc': g74f, 'money': p$cul, 'partner_id': $h6R[O[123749]] }, toPayCallBack, $hUR6, $hRY);
}, window[O[129380]] = function (lpcou) {
  if (lpcou) {
    if (lpcou[O[129381]] === 0xc8 || lpcou[O[104142]] == O[109959]) {
      var q70wh = $h6R[O[129266]][String(lpcou[O[129382]])];if (q70wh[O[100335]]) q70wh[O[100335]](lpcou[O[129382]], lpcou[O[129383]], -0x1);h_$9rj8z[O[129131]]({ 'cpbill': lpcou[O[129383]], 'productid': lpcou[O[129382]], 'productname': q70wh[O[129384]], 'productdesc': q70wh[O[129385]], 'serverid': $h6R[O[125338]][O[111549]], 'servername': $h6R[O[125338]][O[129361]], 'roleid': q70wh[O[129386]], 'rolename': q70wh[O[129387]], 'rolelevel': q70wh[O[129388]], 'price': q70wh[O[127044]], 'extension': JSON[O[104533]]({ 'cp_order_id': lpcou[O[129383]] }) }, function (rdjz9, eb62ai) {
        q70wh[O[100335]] && rdjz9 == 0x0 && q70wh[O[100335]](lpcou[O[129382]], lpcou[O[129383]], rdjz9);console[O[100078]](JSON[O[104533]]({ 'type': O[129389], 'status': rdjz9, 'data': lpcou, 'role_name': q70wh[O[129387]] }));if (rdjz9 === 0x0) {} else {
          if (rdjz9 === 0x1) {} else {
            if (rdjz9 === 0x2) {}
          }
        }
      });
    } else alert(lpcou[O[100078]]);
  }
}, window['$hUR6Y'] = function () {}, window['$hYUR'] = function (q7013x, mlotk5, n6s_ya, s_ngv, x7qh) {
  h_$9rj8z[O[129149]]($h6R[O[125338]][O[111549]], $h6R[O[125338]][O[129361]] || $h6R[O[125338]][O[111549]], q7013x, mlotk5, n6s_ya), sendApi($h6R[O[129270]], O[129390], { 'game_pkg': $h6R[O[125344]], 'server_id': $h6R[O[125338]][O[111549]], 'role_id': q7013x, 'uid': $h6R[O[125343]], 'role_name': mlotk5, 'role_type': s_ngv, 'level': n6s_ya });
}, window['$hYRU'] = function (x1437, ur$z98, puol, jr9$z8, uc8lp, _3gv4f, eaib, n_fg, zr$8, ebai2) {
  $h6R[O[129164]] = x1437, $h6R[O[104670]] = ur$z98, $h6R[O[129165]] = puol, h_$9rj8z[O[129150]]($h6R[O[125338]][O[111549]], $h6R[O[125338]][O[129361]] || $h6R[O[125338]][O[111549]], x1437, ur$z98, puol), sendApi($h6R[O[129270]], O[129391], { 'game_pkg': $h6R[O[125344]], 'server_id': $h6R[O[125338]][O[111549]], 'role_id': x1437, 'uid': $h6R[O[125343]], 'role_name': ur$z98, 'role_type': jr9$z8, 'level': puol, 'evolution': uc8lp });
}, window['$hUYR'] = function ($r8, s26ya, jhdw9, vf_43g, rj9, _nf4gv, fvg134, ocl5t, a26yn, fg341v) {
  $h6R[O[129164]] = $r8, $h6R[O[104670]] = s26ya, $h6R[O[129165]] = jhdw9, h_$9rj8z[O[129151]]($h6R[O[125338]][O[111549]], $h6R[O[125338]][O[129361]] || $h6R[O[125338]][O[111549]], $r8, s26ya, jhdw9), sendApi($h6R[O[129270]], O[129391], { 'game_pkg': $h6R[O[125344]], 'server_id': $h6R[O[125338]][O[111549]], 'role_id': $r8, 'uid': $h6R[O[125343]], 'role_name': s26ya, 'role_type': vf_43g, 'level': jhdw9, 'evolution': rj9 });
}, window['$hURY'] = function (g1f73) {}, window['$hYU'] = function (_fsnvg) {
  h_$9rj8z[O[129111]](O[129111], function (lc8up) {
    _fsnvg && _fsnvg(lc8up);
  });
}, window[O[125028]] = function () {
  h_$9rj8z[O[125028]]();
}, window[O[129392]] = function () {
  h_$9rj8z[O[123641]]();
}, window[O[129393]] = function (zu89r, hwd0xj, b2a6, vsy_ng, s6iy2a, dzjh9w, yba2, z$89ru) {
  z$89ru = z$89ru || $h6R[O[125338]][O[111549]], sendApi($h6R[O[129270]], O[129394], { 'phone': zu89r, 'role_id': hwd0xj, 'uid': $h6R[O[125343]], 'game_pkg': $h6R[O[125344]], 'partner_id': $h6R[O[123749]], 'server_id': z$89ru }, yba2);
}, window[O[110881]] = function (g1f3v4) {
  window['$hRYU'] = g1f3v4, window['$hRYU'] && window['$hUY'] && (console[O[100078]](O[129253] + window['$hUY'][O[100776]]), window['$hRYU'](window['$hUY']), window['$hUY'] = null);
}, window['$hRUY'] = function (lc5oup, _vnay, yg_v, $98uzr) {
  window[O[100022]](O[129395], { 'game_pkg': window['$h6R'][O[125344]], 'role_id': _vnay, 'server_id': yg_v }, $98uzr);
}, window['$h6YUR'] = function (byi6, zj9h) {
  function vf3g1(p5$lu) {
    var qx301 = [],
        rjhzd9 = [],
        lmc5t = window[O[100557]][O[129396]];for (var w9h0j in lmc5t) {
      var ngf_sv = Number(w9h0j);(!byi6 || !byi6[O[100013]] || byi6[O[100115]](ngf_sv) != -0x1) && (rjhzd9[O[100029]](lmc5t[w9h0j]), qx301[O[100029]]([ngf_sv, 0x3]));
    }window['$hXURY6'](window[O[129175]], O[129397]) >= 0x0 ? (console[O[100482]](O[129398]), h_$9rj8z[O[129399]] && h_$9rj8z[O[129399]](rjhzd9, function (yvsn_g) {
      console[O[100482]](O[129400]), console[O[100482]](yvsn_g);if (yvsn_g && yvsn_g[O[125527]] == O[129401]) for (var q4 in lmc5t) {
        if (yvsn_g[lmc5t[q4]] == O[129402]) {
          var ulc5p = Number(q4);for (var zur8 = 0x0; zur8 < qx301[O[100013]]; zur8++) {
            if (qx301[zur8][0x0] == ulc5p) {
              qx301[zur8][0x1] = 0x1;break;
            }
          }
        }
      }window['$hXURY6'](window[O[129175]], O[129403]) >= 0x0 ? wx[O[129404]]({ 'withSubscriptions': !![], 'success': function (bi6ay2) {
          var sn2a6y = bi6ay2[O[129405]][O[129406]];if (sn2a6y) {
            console[O[100482]](O[129407]), console[O[100482]](sn2a6y);for (var rhdjz in lmc5t) {
              if (sn2a6y[lmc5t[rhdjz]] == O[129402]) {
                var n_gf4v = Number(rhdjz);for (var synv_ = 0x0; synv_ < qx301[O[100013]]; synv_++) {
                  if (qx301[synv_][0x0] == n_gf4v) {
                    qx301[synv_][0x1] = 0x2;break;
                  }
                }
              }
            }console[O[100482]](qx301), zj9h && zj9h(qx301);
          } else console[O[100482]](O[129408]), console[O[100482]](bi6ay2), console[O[100482]](qx301), zj9h && zj9h(qx301);
        }, 'fail': function () {
          console[O[100482]](O[129409]), console[O[100482]](qx301), zj9h && zj9h(qx301);
        } }) : (console[O[100482]](O[129410] + window[O[129175]]), console[O[100482]](qx301), zj9h && zj9h(qx301));
    })) : (console[O[100482]](O[129411] + window[O[129175]]), console[O[100482]](qx301), zj9h && zj9h(qx301)), wx[O[129412]](vf3g1);
  }wx[O[129413]](vf3g1);
}, window['$h6YRU'] = { 'isSuccess': ![], 'level': O[129414], 'isCharging': ![] }, window['$h6UYR'] = function (t5cop) {
  wx[O[129242]]({ 'success': function (c$8lp) {
      var qf7 = window['$h6YRU'];qf7[O[129415]] = !![], qf7[O[104646]] = Number(c$8lp[O[104646]])[O[104257]](0x0), qf7[O[129245]] = c$8lp[O[129245]], t5cop && t5cop(qf7[O[129415]], qf7[O[104646]], qf7[O[129245]]);
    }, 'fail': function (fq413) {
      console[O[100482]](O[129416], fq413[O[125527]]);var toplc5 = window['$h6YRU'];t5cop && t5cop(toplc5[O[129415]], toplc5[O[104646]], toplc5[O[129245]]);
    } });
}, window[O[100022]] = function (nsa_6, y6b2, x01q3, vf41g3, lk5tom, rupz8, gf1743, s_n6a) {
  if (vf41g3 == undefined) vf41g3 = 0x1;wx[O[100477]]({ 'url': nsa_6, 'method': gf1743 || O[125234], 'responseType': O[104454], 'data': y6b2, 'header': { 'content-type': s_n6a || O[129310] }, 'success': function (mko5t) {
      DEBUG && console[O[100482]](O[129417], nsa_6, info, mko5t);if (mko5t && mko5t[O[125598]] == 0xc8) {
        var y_vgn = mko5t[O[100011]];!rupz8 || rupz8(y_vgn) ? x01q3 && x01q3(y_vgn) : window[O[129418]](nsa_6, y6b2, x01q3, vf41g3, lk5tom, rupz8, mko5t);
      } else window[O[129418]](nsa_6, y6b2, x01q3, vf41g3, lk5tom, rupz8, mko5t);
    }, 'fail': function (lptoc) {
      DEBUG && console[O[100482]](O[129419], nsa_6, info, lptoc), window[O[129418]](nsa_6, y6b2, x01q3, vf41g3, lk5tom, rupz8, lptoc);
    }, 'complete': function () {} });
}, window[O[129418]] = function (nya2s, sa62y, cm5o, xq314, y2ans, qd0x, urz$8) {
  xq314 - 0x1 > 0x0 ? setTimeout(function () {
    window[O[100022]](nya2s, sa62y, cm5o, xq314 - 0x1, y2ans, qd0x);
  }, 0x3e8) : y2ans && y2ans(JSON[O[104533]]({ 'url': nya2s, 'response': urz$8 }));
}, window[O[129420]] = function (v_g3f4, $cu8p, tclmo, b6iya2, xw0q7, v4g13, n6say_) {
  !tclmo && (tclmo = {});var a6be2 = Math[O[100118]](Date[O[100083]]() / 0x3e8);tclmo[O[100851]] = a6be2, tclmo[O[129421]] = $cu8p;var zrp8$u = Object[O[100267]](tclmo)[O[101078]](),
      z9jrdh = '',
      i2yab6 = '';for (var dj0hw = 0x0; dj0hw < zrp8$u[O[100013]]; dj0hw++) {
    z9jrdh = z9jrdh + (dj0hw == 0x0 ? '' : '&') + zrp8$u[dj0hw] + tclmo[zrp8$u[dj0hw]], i2yab6 = i2yab6 + (dj0hw == 0x0 ? '' : '&') + zrp8$u[dj0hw] + '=' + encodeURIComponent(tclmo[zrp8$u[dj0hw]]);
  }z9jrdh = z9jrdh + $h6R[O[129276]];var z9j8 = O[129422] + md5(z9jrdh);send(v_g3f4 + '?' + i2yab6 + (i2yab6 == '' ? '' : '&') + z9j8, null, b6iya2, xw0q7, v4g13, n6say_ || function (h0dwj) {
    return h0dwj[O[104142]] == O[109959];
  }, null, O[129023]);
}, window['$h6URY'] = function (pcu$l8, d9zjw) {
  var ngv_sy = 0x0;$h6R[O[125338]] && (ngv_sy = $h6R[O[125338]][O[111549]]), sendApi($h6R[O[129272]], O[129423], { 'partnerId': $h6R[O[123749]], 'gamePkg': $h6R[O[125344]], 'logTime': Math[O[100118]](Date[O[100083]]() / 0x3e8), 'platformUid': $h6R[O[125345]], 'type': pcu$l8, 'serverId': ngv_sy }, null, 0x2, null, function () {
    return !![];
  });
}, window['$h6RYU'] = function (zhrd) {
  sendApi($h6R[O[129270]], O[129424], { 'partner_id': $h6R[O[123749]], 'uid': $h6R[O[125343]], 'version': $h6R[O[104741]], 'game_pkg': $h6R[O[125344]], 'device': $h6R[O[125346]] }, $h6RUY, $hUR6, $hRY);
}, window['$h6RUY'] = function (clpuo5) {
  if (clpuo5[O[104142]] === O[109959] && clpuo5[O[100011]]) {
    clpuo5[O[100011]][O[105624]]({ 'id': -0x2, 'name': O[129425] }), clpuo5[O[100011]][O[105624]]({ 'id': -0x1, 'name': O[129426] }), $h6R[O[129427]] = clpuo5[O[100011]];if (window[O[112343]]) window[O[112343]][O[129428]]();
  } else $h6R[O[129429]] = ![], window['$hYU6R'](O[129430] + clpuo5[O[104142]]);
}, window['$hYU6'] = function (_nyg) {
  sendApi($h6R[O[129270]], O[129431], { 'partner_id': $h6R[O[123749]], 'uid': $h6R[O[125343]], 'version': $h6R[O[104741]], 'game_pkg': $h6R[O[125344]], 'device': $h6R[O[125346]] }, $hY6U, $hUR6, $hRY);
}, window['$hY6U'] = function (vg_s) {
  $h6R[O[129432]] = ![];if (vg_s[O[104142]] === O[109959] && vg_s[O[100011]]) {
    for (var clmt5o = 0x0; clmt5o < vg_s[O[100011]][O[100013]]; clmt5o++) {
      vg_s[O[100011]][clmt5o][O[100106]] = $h6UY(vg_s[O[100011]][clmt5o]);
    }$h6R[O[129279]][-0x1] = window[O[129433]](vg_s[O[100011]]), window[O[112343]][O[129434]](-0x1);
  } else window['$hYU6R'](O[129435] + vg_s[O[104142]]);
}, window[O[129436]] = function (s62ai) {
  sendApi($h6R[O[129270]], O[129431], { 'partner_id': $h6R[O[123749]], 'uid': $h6R[O[125343]], 'version': $h6R[O[104741]], 'game_pkg': $h6R[O[125344]], 'device': $h6R[O[125346]] }, s62ai, $hUR6, $hRY);
}, window['$hUY6'] = function (a2byi6, to5lpc) {
  sendApi($h6R[O[129270]], O[129437], { 'partner_id': $h6R[O[123749]], 'uid': $h6R[O[125343]], 'version': $h6R[O[104741]], 'game_pkg': $h6R[O[125344]], 'device': $h6R[O[125346]], 'server_group_id': to5lpc }, $hU6Y, $hUR6, $hRY);
}, window['$hU6Y'] = function (baie6) {
  $h6R[O[129432]] = ![];if (baie6[O[104142]] === O[109959] && baie6[O[100011]] && baie6[O[100011]][O[100011]]) {
    var okml = baie6[O[100011]][O[129438]],
        r9jz$8 = [];for (var k5tl = 0x0; k5tl < baie6[O[100011]][O[100011]][O[100013]]; k5tl++) {
      baie6[O[100011]][O[100011]][k5tl][O[100106]] = $h6UY(baie6[O[100011]][O[100011]][k5tl]), (r9jz$8[O[100013]] == 0x0 || baie6[O[100011]][O[100011]][k5tl][O[100106]] != 0x0) && (r9jz$8[r9jz$8[O[100013]]] = baie6[O[100011]][O[100011]][k5tl]);
    }$h6R[O[129279]][okml] = window[O[129433]](r9jz$8), window[O[112343]][O[129434]](okml);
  } else window['$hYU6R'](O[129439] + baie6[O[104142]]);
}, window['$hXUR6'] = function (lup$c) {
  sendApi($h6R[O[129270]], O[129440], { 'partner_id': $h6R[O[123749]], 'uid': $h6R[O[125343]], 'version': $h6R[O[104741]], 'game_pkg': $h6R[O[125344]], 'device': $h6R[O[125346]] }, reqServerRecommendCallBack, $hUR6, $hRY);
}, window[O[129441]] = function (y62nas) {
  $h6R[O[129432]] = ![];if (y62nas[O[104142]] === O[109959] && y62nas[O[100011]]) {
    for (var tpl5c = 0x0; tpl5c < y62nas[O[100011]][O[100013]]; tpl5c++) {
      y62nas[O[100011]][tpl5c][O[100106]] = $h6UY(y62nas[O[100011]][tpl5c]);
    }$h6R[O[129279]][-0x2] = window[O[129433]](y62nas[O[100011]]), window[O[112343]][O[129434]](-0x2);
  } else alert(O[129442] + y62nas[O[104142]]);
}, window[O[129433]] = function (g4f1v) {
  if (!g4f1v && g4f1v[O[100013]] <= 0x0) return g4f1v;for (let vy_sna = 0x0; vy_sna < g4f1v[O[100013]]; vy_sna++) {
    g4f1v[vy_sna][O[129443]] && g4f1v[vy_sna][O[129443]] == 0x1 && (g4f1v[vy_sna][O[129361]] += O[129444]);
  }return g4f1v;
}, window['$h6YU'] = function (y26ab, $lucp8) {
  y26ab = y26ab || $h6R[O[125338]][O[111549]], sendApi($h6R[O[129270]], O[129445], { 'type': '4', 'game_pkg': $h6R[O[125344]], 'server_id': y26ab }, $lucp8);
}, window[O[129446]] = function (r89d, g417, wdjzh, nsy2a) {
  wdjzh = wdjzh || $h6R[O[125338]][O[111549]], sendApi($h6R[O[129270]], O[129447], { 'type': r89d, 'game_pkg': g417, 'server_id': wdjzh }, nsy2a);
}, window['$h6UY'] = function (p$l5c) {
  if (p$l5c) {
    if (p$l5c[O[100106]] == 0x1) {
      if (p$l5c[O[129448]] == 0x1) return 0x2;else return 0x1;
    } else return p$l5c[O[100106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$hRYU6'] = function (fg3v_, ysnv) {
  $h6R[O[129449]] = { 'step': fg3v_, 'server_id': ysnv };var upo5 = this;$hY6UR({ 'title': O[129450] }), sendApi($h6R[O[129270]], O[129451], { 'partner_id': $h6R[O[123749]], 'uid': $h6R[O[125343]], 'game_pkg': $h6R[O[125344]], 'server_id': ysnv, 'platform': $h6R[O[125315]], 'platform_uid': $h6R[O[125345]], 'check_login_time': $h6R[O[129354]], 'check_login_sign': $h6R[O[129353]], 'version_name': $h6R[O[129330]] }, $hRY6U, $hUR6, $hRY, function (u5olc) {
    return u5olc[O[104142]] == O[109959] || u5olc[O[100078]] == O[129452] || u5olc[O[100078]] == O[129453];
  });
}, window['$hRY6U'] = function (a_sy) {
  var tlcom = this;if (a_sy[O[104142]] === O[109959] && a_sy[O[100011]]) {
    var v4gf_ = $h6R[O[125338]];v4gf_[O[129454]] = $h6R[O[129280]], v4gf_[O[111532]] = String(a_sy[O[100011]][O[129455]]), v4gf_[O[125317]] = parseInt(a_sy[O[100011]][O[100851]]);if (a_sy[O[100011]][O[125316]]) v4gf_[O[125316]] = parseInt(a_sy[O[100011]][O[125316]]);else v4gf_[O[125316]] = parseInt(a_sy[O[100011]][O[111549]]);v4gf_[O[129456]] = 0x0, v4gf_[O[104547]] = $h6R[O[129373]], v4gf_[O[129457]] = a_sy[O[100011]][O[129458]], v4gf_[O[129459]] = a_sy[O[100011]][O[129459]], console[O[100482]](O[129460] + JSON[O[104533]](v4gf_[O[129459]])), $h6R[O[100630]] == 0x1 && v4gf_[O[129459]] && v4gf_[O[129459]][O[129461]] == 0x1 && ($h6R[O[129462]] = 0x1, window[O[129174]][O[100148]]['$hXR6']()), $hRUY6();
  } else $h6R[O[129449]][O[107161]] >= 0x3 ? ($hRY(JSON[O[104533]](a_sy)), window['$hYU6R'](O[129463] + a_sy[O[104142]])) : sendApi($h6R[O[129270]], O[129339], { 'platform': $h6R[O[129268]], 'partner_id': $h6R[O[123749]], 'token': $h6R[O[129337]], 'game_pkg': $h6R[O[125344]], 'deviceId': $h6R[O[125346]], 'scene': O[129340] + $h6R[O[129278]] }, function (as_6ny) {
    if (!as_6ny || as_6ny[O[104142]] != O[109959]) {
      window['$hYU6R'](O[129352] + as_6ny && as_6ny[O[104142]]);return;
    }$h6R[O[129353]] = String(as_6ny[O[111532]]), $h6R[O[129354]] = String(as_6ny[O[100851]]), setTimeout(function () {
      $hRYU6($h6R[O[129449]][O[107161]] + 0x1, $h6R[O[129449]][O[111549]]);
    }, 0x5dc);
  }, $hUR6, $hRY, function (lupo5c) {
    return lupo5c[O[104142]] == O[109959] || lupo5c[O[104142]] == O[125677];
  });
}, window['$hRUY6'] = function () {
  ServerLoading[O[100148]][O[129365]]($h6R[O[100630]]), window['$hUR'] = !![], window['$hR6YU']();
}, window['$hRU6Y'] = function () {
  if (window['$hRU'] && window['$h6UR'] && window[O[129286]] && window[O[129287]] && window['$h6RU'] && window['$h6U']) {
    if (!window[O[128608]][O[100148]]) {
      console[O[100482]](O[129464] + window[O[128608]][O[100148]]);var rz89$ = wx[O[129465]](),
          q3f = rz89$[O[100776]] ? rz89$[O[100776]] : 0x0,
          u8r$ = { 'cdn': window['$h6R'][O[104547]], 'spareCdn': window['$h6R'][O[125048]], 'newRegister': window['$h6R'][O[100630]], 'wxPC': window['$h6R'][O[125051]], 'wxIOS': window['$h6R'][O[101074]], 'wxAndroid': window['$h6R'][O[111371]], 'wxParam': { 'limitLoad': window['$h6R']['$hXYUR6'], 'benchmarkLevel': window['$h6R']['$hXY6UR'], 'wxFrom': window[O[100557]][O[128629]] == O[129466] ? 0x1 : 0x0, 'wxSDKVersion': window[O[129175]] }, 'configType': window['$h6R'][O[111895]], 'exposeType': window['$h6R'][O[100714]], 'scene': q3f };new window[O[128608]](u8r$, window['$h6R'][O[100101]], window['$hXYU6R']);
    }
  }
}, window['$hR6YU'] = function () {
  if (window['$hRU'] && window['$h6UR'] && window[O[129286]] && window[O[129287]] && window['$h6RU'] && window['$h6U'] && window['$hUR'] && window['$hU6']) {
    $hY6RU();if (!$hRU6) {
      $hRU6 = !![];if (!window[O[128608]][O[100148]]) window['$hRU6Y']();var d9hrzj = 0x0,
          g7f431 = wx[O[129467]]();g7f431 && (window['$h6R'][O[129231]] && (d9hrzj = g7f431[O[100323]]), console[O[100078]](O[129468] + g7f431[O[100323]] + O[129469] + g7f431[O[101216]] + O[129470] + g7f431[O[101218]] + O[129471] + g7f431[O[101217]] + O[129472] + g7f431[O[100176]] + O[129473] + g7f431[O[100177]]));var hd9j = {};for (const whdjx in $h6R[O[125338]]) {
        hd9j[whdjx] = $h6R[O[125338]][whdjx];
      }var na6s2 = { 'channel': window['$h6R'][O[125342]], 'account': window['$h6R'][O[125343]], 'userId': window['$h6R'][O[123748]], 'cdn': window['$h6R'][O[104547]], 'data': window['$h6R'][O[100011]], 'package': window['$h6R'][O[125049]], 'newRegister': window['$h6R'][O[100630]], 'pkgName': window['$h6R'][O[125344]], 'partnerId': window['$h6R'][O[123749]], 'platform_uid': window['$h6R'][O[125345]], 'deviceId': window['$h6R'][O[125346]], 'selectedServer': hd9j, 'configType': window['$h6R'][O[111895]], 'exposeType': window['$h6R'][O[100714]], 'debugUsers': window['$h6R'][O[112293]], 'wxMenuTop': d9hrzj, 'wxShield': window['$h6R'][O[100738]] };if (window[O[129375]]) for (var _syna6 in window[O[129375]]) {
        na6s2[_syna6] = window[O[129375]][_syna6];
      }window[O[128608]][O[100148]]['$hR6X'](na6s2);
    }
  } else console[O[100078]](O[129474] + window['$hRU'] + O[129475] + window['$h6UR'] + O[129476] + window[O[129286]] + O[129477] + window[O[129287]] + O[129478] + window['$h6RU'] + O[129479] + window['$h6U'] + O[129480] + window['$hUR'] + O[129481] + window['$hU6']);
};