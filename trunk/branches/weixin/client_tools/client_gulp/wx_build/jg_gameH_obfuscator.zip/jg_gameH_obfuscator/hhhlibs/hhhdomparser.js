var O = wx.$C;
function h_w71x0(jh0d9w) {
  this['options'] = jh0d9w || { 'locator': {} };
}function h_v4_fn(q1xw70, na2y6s, _fgv43) {
  function z$98ru(dw0hjx) {
    var djhwz9 = q1xw70[dw0hjx];!djhwz9 && w710x && (djhwz9 = 0x2 == q1xw70['length'] ? function (q4x73) {
      q1xw70(dw0hjx, q4x73);
    } : q1xw70), hjdz9w[dw0hjx] = djhwz9 && function (rjd9zh) {
      djhwz9('[xmldom ' + dw0hjx + ']\t' + rjd9zh + h_v_yg(_fgv43));
    } || function () {};
  }if (!q1xw70) {
    if (na2y6s instanceof h_s_fvng) return na2y6s;q1xw70 = na2y6s;
  }var hjdz9w = {},
      w710x = q1xw70 instanceof Function;return _fgv43 = _fgv43 || {}, z$98ru('warning'), z$98ru('error'), z$98ru('fatalError'), hjdz9w;
}function h_s_fvng() {
  this['cdata'] = !0x1;
}function h_urc8p(_6syn, u9r) {
  u9r['lineNumber'] = _6syn['lineNumber'], u9r['columnNumber'] = _6syn['columnNumber'];
}function h_v_yg(f4nvg) {
  return f4nvg ? '\x0a@' + (f4nvg['systemId'] || '') + '#[line:' + f4nvg['lineNumber'] + ',col:' + f4nvg['columnNumber'] + ']' : void 0x0;
}function h_sa(jd9rzh, jdzh9w, j9wdh0) {
  return 'string' == typeof jd9rzh ? jd9rzh['substr'](jdzh9w, j9wdh0) : jd9rzh['length'] >= jdzh9w + j9wdh0 || jdzh9w ? new java['lang']['String'](jd9rzh, jdzh9w, j9wdh0) + '' : jd9rzh;
}function h_wd90(sng, i6e2a) {
  sng['currentElement'] ? sng['currentElement']['appendChild'](i6e2a) : sng['doc']['appendChild'](i6e2a);
}h_w71x0['prototype']['parseFromString'] = function (mklto5, p8$lu) {
  var rd9jhz = this['options'],
      uc$p = new h_hwq0(),
      u$8pl = rd9jhz['domBuilder'] || new h_s_fvng(),
      gsnf_v = rd9jhz['errorHandler'],
      h0djw = rd9jhz['locator'],
      $r98jz = rd9jhz['xmlns'] || {},
      uc$5lp = { 'lt': '<', 'gt': '>', 'amp': '&', 'quot': '\x22', 'apos': '\x27' };return h0djw && u$8pl['setDocumentLocator'](h0djw), uc$p['errorHandler'] = h_v4_fn(gsnf_v, u$8pl, h0djw), uc$p['domBuilder'] = rd9jhz['domBuilder'] || u$8pl, /\/x?html?$/['test'](p8$lu) && (uc$5lp['nbsp'] = '\u00a0', uc$5lp['copy'] = '©', $r98jz[''] = 'http://www.w3.org/1999/xhtml'), $r98jz['xml'] = $r98jz['xml'] || 'http://www.w3.org/XML/1998/namespace', mklto5 ? uc$p['parse'](mklto5, $r98jz, uc$5lp) : uc$p['errorHandler']['error']('invalid doc source'), u$8pl['doc'];
}, h_s_fvng['prototype'] = { 'startDocument': function () {
    this['doc'] = new h_hrzd()['createDocument'](null, null, null), this['locator'] && (this['doc']['documentURI'] = this['locator']['systemId']);
  }, 'startElement': function (n_yas6, pct5lo, a2ibe, $8crpu) {
    var g_sfvn = this['doc'],
        $z8r9u = g_sfvn['createElementNS'](n_yas6, a2ibe || pct5lo),
        v_fsgn = $8crpu['length'];h_wd90(this, $z8r9u), this['currentElement'] = $z8r9u, this['locator'] && h_urc8p(this['locator'], $z8r9u);for (var say62i = 0x0; v_fsgn > say62i; say62i++) {
      var n_yas6 = $8crpu['getURI'](say62i),
          jwh9dz = $8crpu['getValue'](say62i),
          a2ibe = $8crpu['getQName'](say62i),
          rz9dhj = g_sfvn['createAttributeNS'](n_yas6, a2ibe);this['locator'] && h_urc8p($8crpu['getLocator'](say62i), rz9dhj), rz9dhj['value'] = rz9dhj['nodeValue'] = jwh9dz, $z8r9u['setAttributeNode'](rz9dhj);
    }
  }, 'endElement': function () {
    {
      var urpz8 = this['currentElement'];urpz8['tagName'];
    }this['currentElement'] = urpz8['parentNode'];
  }, 'startPrefixMapping': function () {}, 'endPrefixMapping': function () {}, 'processingInstruction': function (v431fg, qf713) {
    var qdx = this['doc']['createProcessingInstruction'](v431fg, qf713);this['locator'] && h_urc8p(this['locator'], qdx), h_wd90(this, qdx);
  }, 'ignorableWhitespace': function () {}, 'characters': function (_ny6) {
    if (_ny6 = h_sa['apply'](this, arguments)) {
      if (this['cdata']) var q3f714 = this['doc']['createCDATASection'](_ny6);else var q3f714 = this['doc']['createTextNode'](_ny6);this['currentElement'] ? this['currentElement']['appendChild'](q3f714) : /^\s*$/['test'](_ny6) && this['doc']['appendChild'](q3f714), this['locator'] && h_urc8p(this['locator'], q3f714);
    }
  }, 'skippedEntity': function () {}, 'endDocument': function () {
    this['doc']['normalize']();
  }, 'setDocumentLocator': function (c8pl) {
    (this['locator'] = c8pl) && (c8pl['lineNumber'] = 0x0);
  }, 'comment': function (lkmo5) {
    lkmo5 = h_sa['apply'](this, arguments);var zpr8 = this['doc']['createComment'](lkmo5);this['locator'] && h_urc8p(this['locator'], zpr8), h_wd90(this, zpr8);
  }, 'startCDATA': function () {
    this['cdata'] = !0x0;
  }, 'endCDATA': function () {
    this['cdata'] = !0x1;
  }, 'startDTD': function (ay62sn, $pr8, qf47) {
    var _f34vg = this['doc']['implementation'];if (_f34vg && _f34vg['createDocumentType']) {
      var j$z8 = _f34vg['createDocumentType'](ay62sn, $pr8, qf47);this['locator'] && h_urc8p(this['locator'], j$z8), h_wd90(this, j$z8);
    }
  }, 'warning': function (l5tcm) {
    console['warn']('[xmldom warning]\t' + l5tcm, h_v_yg(this['locator']));
  }, 'error': function (y62ab) {
    console['error']('[xmldom error]\t' + y62ab, h_v_yg(this['locator']));
  }, 'fatalError': function (_vysn) {
    throw console['error']('[xmldom fatalError]\t' + _vysn, h_v_yg(this['locator'])), _vysn;
  } }, 'endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl'['replace'](/\w+/g, function (hj9drz) {
  h_s_fvng['prototype'][hj9drz] = function () {
    return null;
  };
});var h_hwq0 = require('./hhhsax')['XMLReader'],
    h_hrzd = exports['DOMImplementation'] = require('./hhhdom')['DOMImplementation'];exports['XMLSerializer'] = require('./hhhdom')['XMLSerializer'], exports['DOMParser'] = h_w71x0;