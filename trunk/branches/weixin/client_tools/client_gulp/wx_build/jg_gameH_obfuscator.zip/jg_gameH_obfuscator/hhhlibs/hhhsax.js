var O = wx.$C;
function h_f3g_4() {}function h_cto5(zrj$89, aie62b, pz8$u, r8z9j$, gf3v_) {
  function sgnvy(hw90) {
    if (hw90 > 0xffff) {
      hw90 -= 0x10000;var f_g4 = 0xd800 + (hw90 >> 0xa),
          ot5clm = 0xdc00 + (0x3ff & hw90);return String['fromCharCode'](f_g4, ot5clm);
    }return String['fromCharCode'](hw90);
  }function vg_s(ya_sn) {
    var _34fv = ya_sn['slice'](0x1, -0x1);return _34fv in pz8$u ? pz8$u[_34fv] : '#' === _34fv['charAt'](0x0) ? sgnvy(parseInt(_34fv['substr'](0x1)['replace']('x', '0x'))) : (gf3v_['error']('entity not found:' + ya_sn), ya_sn);
  }function eb6i2a(r8zup) {
    if (r8zup > ucp8$r) {
      var f1q374 = zrj$89['substring'](ucp8$r, r8zup)['replace'](/&#?\w+;/g, vg_s);ctmlo && h9d0wj(ucp8$r), r8z9j$['characters'](f1q374, 0x0, r8zup - ucp8$r), ucp8$r = r8zup;
    }
  }function h9d0wj(pc$r8, syi6a2) {
    for (; pc$r8 >= xq7 && (syi6a2 = y6asn_['exec'](zrj$89));) cpou5 = syi6a2['index'], xq7 = cpou5 + syi6a2[0x0]['length'], ctmlo['lineNumber']++;ctmlo['columnNumber'] = pc$r8 - cpou5 + 0x1;
  }for (var cpou5 = 0x0, xq7 = 0x0, y6asn_ = /.*(?:\r\n?|\n)|.*$/g, ctmlo = r8z9j$['locator'], z8r9j = [{ 'currentNSMap': aie62b }], tclpo5 = {}, ucp8$r = 0x0;;) {
    try {
      var _vfgsn = zrj$89['indexOf']('<', ucp8$r);if (0x0 > _vfgsn) {
        if (!zrj$89['substr'](ucp8$r)['match'](/^\s*$/)) {
          var _vgf34 = r8z9j$['doc'],
              x0wh7 = _vgf34['createTextNode'](zrj$89['substr'](ucp8$r));_vgf34['appendChild'](x0wh7), r8z9j$['currentElement'] = x0wh7;
        }return;
      }switch (_vfgsn > ucp8$r && eb6i2a(_vfgsn), zrj$89['charAt'](_vfgsn + 0x1)) {case '/':
          var h9jzdw = zrj$89['indexOf']('>', _vfgsn + 0x3),
              ayi26 = zrj$89['substring'](_vfgsn + 0x2, h9jzdw),
              jd9hwz = z8r9j['pop']();0x0 > h9jzdw ? (ayi26 = zrj$89['substring'](_vfgsn + 0x2)['replace'](/[\s<].*/, ''), gf3v_['error']('end tag name: ' + ayi26 + ' is not complete:' + jd9hwz['tagName']), h9jzdw = _vfgsn + 0x1 + ayi26['length']) : ayi26['match'](/\s</) && (ayi26 = ayi26['replace'](/[\s<].*/, ''), gf3v_['error']('end tag name: ' + ayi26 + ' maybe not complete'), h9jzdw = _vfgsn + 0x1 + ayi26['length']);var n4fv_g = jd9hwz['localNSMap'],
              nsya_v = jd9hwz['tagName'] == ayi26,
              cmt5l = nsya_v || jd9hwz['tagName'] && jd9hwz['tagName']['toLowerCase']() == ayi26['toLowerCase']();if (cmt5l) {
            if (r8z9j$['endElement'](jd9hwz['uri'], jd9hwz['localName'], ayi26), n4fv_g) {
              for (var wdxj0 in n4fv_g) r8z9j$['endPrefixMapping'](wdxj0);
            }nsya_v || gf3v_['fatalError']('end tag name: ' + ayi26 + ' is not match the current start tagName:' + jd9hwz['tagName']);
          } else z8r9j['push'](jd9hwz);h9jzdw++;break;case '?':
          ctmlo && h9d0wj(_vfgsn), h9jzdw = h_p5luo(zrj$89, _vfgsn, r8z9j$);break;case '!':
          ctmlo && h9d0wj(_vfgsn), h9jzdw = h__v43f(zrj$89, _vfgsn, r8z9j$, gf3v_);break;default:
          ctmlo && h9d0wj(_vfgsn);var z$rpu8 = new h__4vgf(),
              svngf = z8r9j[z8r9j['length'] - 0x1]['currentNSMap'],
              h9jzdw = h_u5p$cl(zrj$89, _vfgsn, z$rpu8, svngf, vg_s, gf3v_),
              n_fs = z$rpu8['length'];if (!z$rpu8['closed'] && h_ea26ib(zrj$89, h9jzdw, z$rpu8['tagName'], tclpo5) && (z$rpu8['closed'] = !0x0, pz8$u['nbsp'] || gf3v_['warning']('unclosed xml attribute')), ctmlo && n_fs) {
            for (var dxhq0 = h__nyvsg(ctmlo, {}), xqdwh = 0x0; n_fs > xqdwh; xqdwh++) {
              var b62ae = z$rpu8[xqdwh];h9d0wj(b62ae['offset']), b62ae['locator'] = h__nyvsg(ctmlo, {});
            }r8z9j$['locator'] = dxhq0, h__gvf43(z$rpu8, r8z9j$, svngf) && z8r9j['push'](z$rpu8), r8z9j$['locator'] = ctmlo;
          } else h__gvf43(z$rpu8, r8z9j$, svngf) && z8r9j['push'](z$rpu8);'http://www.w3.org/1999/xhtml' !== z$rpu8['uri'] || z$rpu8['closed'] ? h9jzdw++ : h9jzdw = h_yi2b6a(zrj$89, h9jzdw, z$rpu8['tagName'], vg_s, r8z9j$);}
    } catch (ko5mlt) {
      gf3v_['error']('element parse error: ' + ko5mlt), h9jzdw = -0x1;
    }h9jzdw > ucp8$r ? ucp8$r = h9jzdw : eb6i2a(Math['max'](_vfgsn, ucp8$r) + 0x1);
  }
}function h__nyvsg(qw71x0, ocl5up) {
  return ocl5up['lineNumber'] = qw71x0['lineNumber'], ocl5up['columnNumber'] = qw71x0['columnNumber'], ocl5up;
}function h_u5p$cl(_ngv, $rj9, zr$8, f3g4_, g_svfn, hd9wzj) {
  for (var z8$r9j, _ysng, $p5lcu = ++$rj9, a_6ny = h_qw71x;;) {
    var fg3714 = _ngv['charAt']($p5lcu);switch (fg3714) {case '=':
        if (a_6ny === h_djr9z8) z8$r9j = _ngv['slice']($rj9, $p5lcu), a_6ny = h_j89zdr;else {
          if (a_6ny !== h_nsf_v) throw new Error('attribute equal must after attrName');a_6ny = h_j89zdr;
        }break;case '\x27':case '\x22':
        if (a_6ny === h_j89zdr || a_6ny === h_djr9z8) {
          if (a_6ny === h_djr9z8 && (hd9wzj['warning']('attribute value must after "="'), z8$r9j = _ngv['slice']($rj9, $p5lcu)), $rj9 = $p5lcu + 0x1, $p5lcu = _ngv['indexOf'](fg3714, $rj9), !($p5lcu > 0x0)) throw new Error('attribute value no end \'' + fg3714 + '\' match');_ysng = _ngv['slice']($rj9, $p5lcu)['replace'](/&#?\w+;/g, g_svfn), zr$8['add'](z8$r9j, _ysng, $rj9 - 0x1), a_6ny = h_f3q17;
        } else {
          if (a_6ny != h_yv_ns) throw new Error('attribute value must after "="');_ysng = _ngv['slice']($rj9, $p5lcu)['replace'](/&#?\w+;/g, g_svfn), zr$8['add'](z8$r9j, _ysng, $rj9), hd9wzj['warning']('attribute "' + z8$r9j + '" missed start quot(' + fg3714 + ')!!'), $rj9 = $p5lcu + 0x1, a_6ny = h_f3q17;
        }break;case '/':
        switch (a_6ny) {case h_qw71x:
            zr$8['setTagName'](_ngv['slice']($rj9, $p5lcu));case h_f3q17:case h_ctpo:case h_pul5$c:
            a_6ny = h_pul5$c, zr$8['closed'] = !0x0;case h_yv_ns:case h_djr9z8:case h_nsf_v:
            break;default:
            throw new Error('attribute invalid close char(\'/\')');}break;case '':
        return hd9wzj['error']('unexpected end of input'), a_6ny == h_qw71x && zr$8['setTagName'](_ngv['slice']($rj9, $p5lcu)), $p5lcu;case '>':
        switch (a_6ny) {case h_qw71x:
            zr$8['setTagName'](_ngv['slice']($rj9, $p5lcu));case h_f3q17:case h_ctpo:case h_pul5$c:
            break;case h_yv_ns:case h_djr9z8:
            _ysng = _ngv['slice']($rj9, $p5lcu), '/' === _ysng['slice'](-0x1) && (zr$8['closed'] = !0x0, _ysng = _ysng['slice'](0x0, -0x1));case h_nsf_v:
            a_6ny === h_nsf_v && (_ysng = z8$r9j), a_6ny == h_yv_ns ? (hd9wzj['warning']('attribute "' + _ysng + '" missed quot(")!!'), zr$8['add'](z8$r9j, _ysng['replace'](/&#?\w+;/g, g_svfn), $rj9)) : ('http://www.w3.org/1999/xhtml' === f3g4_[''] && _ysng['match'](/^(?:disabled|checked|selected)$/i) || hd9wzj['warning']('attribute "' + _ysng + '" missed value!! "' + _ysng + '" instead!!'), zr$8['add'](_ysng, _ysng, $rj9));break;case h_j89zdr:
            throw new Error('attribute value missed!!');}return $p5lcu;case '\u0080':
        fg3714 = '\x20';default:
        if ('\x20' >= fg3714) switch (a_6ny) {case h_qw71x:
            zr$8['setTagName'](_ngv['slice']($rj9, $p5lcu)), a_6ny = h_ctpo;break;case h_djr9z8:
            z8$r9j = _ngv['slice']($rj9, $p5lcu), a_6ny = h_nsf_v;break;case h_yv_ns:
            var _ysng = _ngv['slice']($rj9, $p5lcu)['replace'](/&#?\w+;/g, g_svfn);hd9wzj['warning']('attribute "' + _ysng + '" missed quot(")!!'), zr$8['add'](z8$r9j, _ysng, $rj9);case h_f3q17:
            a_6ny = h_ctpo;} else switch (a_6ny) {case h_nsf_v:
            {
              zr$8['tagName'];
            }'http://www.w3.org/1999/xhtml' === f3g4_[''] && z8$r9j['match'](/^(?:disabled|checked|selected)$/i) || hd9wzj['warning']('attribute "' + z8$r9j + '" missed value!! "' + z8$r9j + '" instead2!!'), zr$8['add'](z8$r9j, z8$r9j, $rj9), $rj9 = $p5lcu, a_6ny = h_djr9z8;break;case h_f3q17:
            hd9wzj['warning']('attribute space is required"' + z8$r9j + '\x22!!');case h_ctpo:
            a_6ny = h_djr9z8, $rj9 = $p5lcu;break;case h_j89zdr:
            a_6ny = h_yv_ns, $rj9 = $p5lcu;break;case h_pul5$c:
            throw new Error('elements closed character \'/\' and \'>\' must be connected to');}}$p5lcu++;
  }
}function h__gvf43(uc$8l, $9ur, pco5ul) {
  for (var cl8p$ = uc$8l['tagName'], z8r$u = null, o5clt = uc$8l['length']; o5clt--;) {
    var dhqw0 = uc$8l[o5clt],
        co5ltp = dhqw0['qName'],
        r8dj9z = dhqw0['value'],
        ba6ie = co5ltp['indexOf'](':');if (ba6ie > 0x0) var pcolt = dhqw0['prefix'] = co5ltp['slice'](0x0, ba6ie),
        avnys = co5ltp['slice'](ba6ie + 0x1),
        ulpco5 = 'xmlns' === pcolt && avnys;else avnys = co5ltp, pcolt = null, ulpco5 = 'xmlns' === co5ltp && '';dhqw0['localName'] = avnys, ulpco5 !== !0x1 && (null == z8r$u && (z8r$u = {}, h_lp8uc$(pco5ul, pco5ul = {})), pco5ul[ulpco5] = z8r$u[ulpco5] = r8dj9z, dhqw0['uri'] = 'http://www.w3.org/2000/xmlns/', $9ur['startPrefixMapping'](ulpco5, r8dj9z));
  }for (var o5clt = uc$8l['length']; o5clt--;) {
    dhqw0 = uc$8l[o5clt];var pcolt = dhqw0['prefix'];pcolt && ('xml' === pcolt && (dhqw0['uri'] = 'http://www.w3.org/XML/1998/namespace'), 'xmlns' !== pcolt && (dhqw0['uri'] = pco5ul[pcolt || '']));
  }var ba6ie = cl8p$['indexOf'](':');ba6ie > 0x0 ? (pcolt = uc$8l['prefix'] = cl8p$['slice'](0x0, ba6ie), avnys = uc$8l['localName'] = cl8p$['slice'](ba6ie + 0x1)) : (pcolt = null, avnys = uc$8l['localName'] = cl8p$);var hjdw09 = uc$8l['uri'] = pco5ul[pcolt || ''];if ($9ur['startElement'](hjdw09, avnys, cl8p$, uc$8l), !uc$8l['closed']) return uc$8l['currentNSMap'] = pco5ul, uc$8l['localNSMap'] = z8r$u, !0x0;if ($9ur['endElement'](hjdw09, avnys, cl8p$), z8r$u) {
    for (pcolt in z8r$u) $9ur['endPrefixMapping'](pcolt);
  }
}function h_yi2b6a(u$c5, v31, z89j$, s_nfv, vys_an) {
  if (/^(?:script|textarea)$/i['test'](z89j$)) {
    var dx0hwq = u$c5['indexOf']('</' + z89j$ + '>', v31),
        fg431 = u$c5['substring'](v31 + 0x1, dx0hwq);if (/[&<]/['test'](fg431)) return (/^script$/i['test'](z89j$) ? (vys_an['characters'](fg431, 0x0, fg431['length']), dx0hwq) : (fg431 = fg431['replace'](/&#?\w+;/g, s_nfv), vys_an['characters'](fg431, 0x0, fg431['length']), dx0hwq)
    );
  }return v31 + 0x1;
}function h_ea26ib(clp$5, _ng, y62bi, f4g3v) {
  var ie62ba = f4g3v[y62bi];return null == ie62ba && (ie62ba = clp$5['lastIndexOf']('</' + y62bi + '>'), _ng > ie62ba && (ie62ba = clp$5['lastIndexOf']('</' + y62bi)), f4g3v[y62bi] = ie62ba), _ng > ie62ba;
}function h_lp8uc$(vngf_, tmcl) {
  for (var $up8r in vngf_) tmcl[$up8r] = vngf_[$up8r];
}function h__v43f(mol5kt, lom5ct, syn_, j9zhrd) {
  var tom5kl = mol5kt['charAt'](lom5ct + 0x2);switch (tom5kl) {case '-':
      if ('-' === mol5kt['charAt'](lom5ct + 0x3)) {
        var _3f4v = mol5kt['indexOf']('-->', lom5ct + 0x4);return _3f4v > lom5ct ? (syn_['comment'](mol5kt, lom5ct + 0x4, _3f4v - lom5ct - 0x4), _3f4v + 0x3) : (j9zhrd['error']('Unclosed comment'), -0x1);
      }return -0x1;default:
      if ('CDATA[' == mol5kt['substr'](lom5ct + 0x3, 0x6)) {
        var _3f4v = mol5kt['indexOf'](']]>', lom5ct + 0x9);return syn_['startCDATA'](), syn_['characters'](mol5kt, lom5ct + 0x9, _3f4v - lom5ct - 0x9), syn_['endCDATA'](), _3f4v + 0x3;
      }var c$pl8u = h_g4fv31(mol5kt, lom5ct),
          _sgf = c$pl8u['length'];if (_sgf > 0x1 && /!doctype/i['test'](c$pl8u[0x0][0x0])) {
        var djzr8 = c$pl8u[0x1][0x0],
            vs = _sgf > 0x3 && /^public$/i['test'](c$pl8u[0x2][0x0]) && c$pl8u[0x3][0x0],
            lc8p$u = _sgf > 0x4 && c$pl8u[0x4][0x0],
            ia2yb6 = c$pl8u[_sgf - 0x1];return syn_['startDTD'](djzr8, vs && vs['replace'](/^(['"])(.*?)\1$/, '$2'), lc8p$u && lc8p$u['replace'](/^(['"])(.*?)\1$/, '$2')), syn_['endDTD'](), ia2yb6['index'] + ia2yb6[0x0]['length'];
      }}return -0x1;
}function h_p5luo($p8clu, gf_, f7134q) {
  var lmcto5 = $p8clu['indexOf']('?>', gf_);if (lmcto5) {
    var tocp5l = $p8clu['substring'](gf_, lmcto5)['match'](/^<\?(\S*)\s*([\s\S]*?)\s*$/);if (tocp5l) {
      {
        tocp5l[0x0]['length'];
      }return f7134q['processingInstruction'](tocp5l[0x1], tocp5l[0x2]), lmcto5 + 0x2;
    }return -0x1;
  }return -0x1;
}function h__4vgf() {}function h_x0jwh(qx3417, lk5tom) {
  return qx3417['__proto__'] = lk5tom, qx3417;
}function h_g4fv31(_vf34g, r8up$z) {
  var zhd9j,
      hzd9 = [],
      mklo5 = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;for (mklo5['lastIndex'] = r8up$z, mklo5['exec'](_vf34g); zhd9j = mklo5['exec'](_vf34g);) if (hzd9['push'](zhd9j), zhd9j[0x1]) return hzd9;
}var h_w90dhj = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    h_r$j8 = new RegExp('[\\-\\.0-9' + h_w90dhj['source']['slice'](0x1, -0x1) + '\\u00B7\\u0300-\\u036F\\u203F-\\u2040]'),
    h_j98$zr = new RegExp('^' + h_w90dhj['source'] + h_r$j8['source'] + '*(?::' + h_w90dhj['source'] + h_r$j8['source'] + '*)?$'),
    h_qw71x = 0x0,
    h_djr9z8 = 0x1,
    h_nsf_v = 0x2,
    h_j89zdr = 0x3,
    h_yv_ns = 0x4,
    h_f3q17 = 0x5,
    h_ctpo = 0x6,
    h_pul5$c = 0x7;h_f3g_4['prototype'] = { 'parse': function (otlm5c, zjhw, zjrdh) {
    var qdh = this['domBuilder'];qdh['startDocument'](), h_lp8uc$(zjhw, zjhw = {}), h_cto5(otlm5c, zjhw, zjrdh, qdh, this['errorHandler']), qdh['endDocument']();
  } }, h__4vgf['prototype'] = { 'setTagName': function (xwd0) {
    if (!h_j98$zr['test'](xwd0)) throw new Error('invalid tagName:' + xwd0);this['tagName'] = xwd0;
  }, 'add': function (ptol, tm5lok, p8r$z) {
    if (!h_j98$zr['test'](ptol)) throw new Error('invalid attribute:' + ptol);this[this['length']++] = { 'qName': ptol, 'value': tm5lok, 'offset': p8r$z };
  }, 'length': 0x0, 'getLocalName': function (i6b2ea) {
    return this[i6b2ea]['localName'];
  }, 'getLocator': function (ucl8$) {
    return this[ucl8$]['locator'];
  }, 'getQName': function (_6yns) {
    return this[_6yns]['qName'];
  }, 'getURI': function (ibe2a6) {
    return this[ibe2a6]['uri'];
  }, 'getValue': function (r$98zj) {
    return this[r$98zj]['value'];
  } }, h_x0jwh({}, h_x0jwh['prototype']) instanceof h_x0jwh || (h_x0jwh = function (g3f_v4, sa6i) {
  function x130q() {}x130q['prototype'] = sa6i, x130q = new x130q();for (sa6i in g3f_v4) x130q[sa6i] = g3f_v4[sa6i];return x130q;
}), exports['XMLReader'] = h_f3g_4;