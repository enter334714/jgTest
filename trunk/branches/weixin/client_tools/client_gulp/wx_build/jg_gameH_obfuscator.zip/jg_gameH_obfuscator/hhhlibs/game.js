var O = wx.$C;
require(O[0x76f8]);