var O = wx.$C;
require(O[129155]);