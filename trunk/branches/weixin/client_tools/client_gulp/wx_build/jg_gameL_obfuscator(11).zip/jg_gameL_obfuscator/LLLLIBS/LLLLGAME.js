var W = wx.$l;
console[W[436]](W[437]), window[W[438]], wx[W[439]](function (r3ymc) {
  if (r3ymc) {
    if (r3ymc[W[440]]) {
      var qf5lt = window[W[441]][W[442]][W[286]](new RegExp(/\./, 'g'), '_'),
          qhjzk = r3ymc[W[440]],
          gev6 = qhjzk[W[443]](/(LLLLLLLL\/LLLLGAME.js:)[0-9]{1,60}(:)/g);if (gev6) for (var imcr3w = 0x0; imcr3w < gev6[W[178]]; imcr3w++) {
        if (gev6[imcr3w] && gev6[imcr3w][W[178]] > 0x0) {
          var $sn84 = parseInt(gev6[imcr3w][W[286]](W[444], '')[W[286]](':', ''));qhjzk = qhjzk[W[286]](gev6[imcr3w], gev6[imcr3w][W[286]](':' + $sn84 + ':', ':' + ($sn84 - 0x2) + ':'));
        }
      }qhjzk = qhjzk[W[286]](new RegExp(W[445], 'g'), W[446] + qf5lt + W[447]), qhjzk = qhjzk[W[286]](new RegExp(W[448], 'g'), W[446] + qf5lt + W[447]), r3ymc[W[440]] = qhjzk;
    }var vg1e6u = { 'id': window['$LHD'][W[449]], 'role': window['$LHD'][W[450]], 'level': window['$LHD'][W[451]], 'user': window['$LHD'][W[452]], 'version': window['$LHD'][W[206]], 'cdn': window['$LHD'][W[296]], 'pkgName': window['$LHD'][W[262]], 'gamever': window[W[441]][W[442]], 'serverid': window['$LHD'][W[149]] ? window['$LHD'][W[149]][W[150]] : 0x0, 'systemInfo': window[W[453]], 'error': W[454], 'stack': r3ymc ? r3ymc[W[440]] : '' },
        kahbz = JSON[W[402]](vg1e6u);console[W[404]](W[455] + kahbz), (!window[W[438]] || window[W[438]] != vg1e6u[W[404]]) && (window[W[438]] = vg1e6u[W[404]], window['$LTH'](vg1e6u));
  }
});import 'lllMDFIVEMIN.js';import 'lllZLIBS.js';window[W[456]] = require(W[457]);import 'LLLLINDEX.js';import 'llllLIBSMIN.js';import 'LLLLWXMINI.js';import 'LLLINITMIN.js';console[W[436]](W[458]), console[W[436]](W[459]), $LTH0D({ 'title': W[460] });var L9zkhjq = { '$LBTDH0': !![] };new window[W[435]](L9zkhjq), window[W[435]][W[145]]['$LB0HDT']();if (window['$LBTHD0']) clearInterval(window['$LBTHD0']);window['$LBTHD0'] = null, window['$LB0DTH'] = function (r3m0y, y84_n) {
  if (!r3m0y || !y84_n) return 0x0;r3m0y = r3m0y[W[461]]('.'), y84_n = y84_n[W[461]]('.');const jh2ab = Math[W[462]](r3m0y[W[178]], y84_n[W[178]]);while (r3m0y[W[178]] < jh2ab) {
    r3m0y[W[318]]('0');
  }while (y84_n[W[178]] < jh2ab) {
    y84_n[W[318]]('0');
  }for (var e1 = 0x0; e1 < jh2ab; e1++) {
    const u1ve7 = parseInt(r3m0y[e1]),
          x4_8yn = parseInt(y84_n[e1]);if (u1ve7 > x4_8yn) return 0x1;else {
      if (u1ve7 < x4_8yn) return -0x1;
    }
  }return 0x0;
}, window[W[463]] = wx[W[464]]()[W[463]], console[W[310]](W[465] + window[W[463]]);var L9y_xn48 = wx[W[466]]();L9y_xn48[W[467]](function (hkzlj) {
  console[W[310]](W[468] + hkzlj[W[469]]);
}), L9y_xn48[W[470]](function () {
  wx[W[471]]({ 'title': W[472], 'content': W[473], 'showCancel': ![], 'success': function (zkq) {
      L9y_xn48[W[474]]();
    } });
}), L9y_xn48[W[475]](function () {
  console[W[310]](W[476]);
}), window['$LB0DHT'] = function () {
  console[W[310]](W[477]);var z5ft = wx[W[478]]({ 'name': W[479], 'success': function (qhjlt) {
      console[W[310]](W[480]), console[W[310]](qhjlt), qhjlt && qhjlt[W[481]] == W[482] ? (window['$LD0'] = !![], window['$LD0HT'](), window['$LDHT0']()) : setTimeout(function () {
        window['$LB0DHT']();
      }, 0x1f4);
    }, 'fail': function (f9l5q) {
      console[W[310]](W[483]), console[W[310]](f9l5q), setTimeout(function () {
        window['$LB0DHT']();
      }, 0x1f4);
    } });z5ft && z5ft[W[484]](yx_48n => {});
}, window['$LBHTD0'] = function () {
  console[W[310]](W[485]);var _8x4ns = wx[W[478]]({ 'name': W[486], 'success': function (c3irm) {
      console[W[310]](W[487]), console[W[310]](c3irm), c3irm && c3irm[W[481]] == W[482] ? (window['$LH0D'] = !![], window['$LD0HT'](), window['$LDHT0']()) : setTimeout(function () {
        window['$LBHTD0']();
      }, 0x1f4);
    }, 'fail': function (s8d_4$) {
      console[W[310]](W[488]), console[W[310]](s8d_4$), setTimeout(function () {
        window['$LBHTD0']();
      }, 0x1f4);
    } });_8x4ns && _8x4ns[W[484]](tfq5 => {});
}, window[W[489]] = function () {
  window['$LB0DTH'](window[W[463]], W[490]) >= 0x0 ? (console[W[310]](W[491] + window[W[463]] + W[492]), window['$LHT'](), window['$LB0DHT'](), window['$LBHTD0']()) : (window['$LHDT'](W[493], window[W[463]]), wx[W[471]]({ 'title': W[494], 'content': W[495] }));
}, window[W[453]] = '', wx[W[496]]({ 'success'(kj2da) {
    window[W[453]] = W[497] + kj2da[W[498]] + W[499] + kj2da[W[500]] + W[501] + kj2da[W[502]] + W[503] + kj2da[W[504]] + W[505] + kj2da[W[506]] + W[507] + kj2da[W[463]] + W[508] + kj2da[W[509]], console[W[310]](window[W[453]]), console[W[310]](W[510] + kj2da[W[511]] + W[512] + kj2da[W[513]] + W[514] + kj2da[W[515]] + W[516] + kj2da[W[517]] + W[518] + kj2da[W[519]] + W[520] + kj2da[W[521]] + W[522] + (kj2da[W[523]] ? kj2da[W[523]][W[108]] + ',' + kj2da[W[523]][W[220]] + ',' + kj2da[W[523]][W[524]] + ',' + kj2da[W[523]][W[69]] : ''));var hajq = kj2da[W[504]] ? kj2da[W[504]][W[525]]() : '',
        bkzha = kj2da[W[500]] ? kj2da[W[500]][W[525]]()[W[286]]('\x20', '') : '';window['$LHD'][W[526]] = hajq[W[424]](W[527]) != -0x1, window['$LHD'][W[528]] = hajq[W[424]](W[529]) != -0x1, window['$LHD'][W[530]] = hajq[W[424]](W[527]) != -0x1 || hajq[W[424]](W[529]) != -0x1, window['$LHD'][W[531]] = hajq[W[424]](W[532]) != -0x1 || hajq[W[424]](W[533]) != -0x1, window['$LHD'][W[534]] = kj2da[W[506]] ? kj2da[W[506]][W[525]]() : '', window['$LHD']['$LBT0DH'] = ![], window['$LHD']['$LBTH0D'] = 0x2;if (hajq[W[424]](W[529]) != -0x1) {
      if (kj2da[W[509]] >= 0x18) window['$LHD']['$LBTH0D'] = 0x3;else window['$LHD']['$LBTH0D'] = 0x2;
    } else {
      if (hajq[W[424]](W[527]) != -0x1) {
        if (kj2da[W[509]] && kj2da[W[509]] >= 0x14) window['$LHD']['$LBTH0D'] = 0x3;else {
          if (bkzha[W[424]](W[535]) != -0x1 || bkzha[W[424]](W[536]) != -0x1 || bkzha[W[424]](W[537]) != -0x1 || bkzha[W[424]](W[538]) != -0x1 || bkzha[W[424]](W[539]) != -0x1) window['$LHD']['$LBTH0D'] = 0x2;else window['$LHD']['$LBTH0D'] = 0x3;
        }
      } else window['$LHD']['$LBTH0D'] = 0x2;
    }console[W[310]](W[540] + window['$LHD']['$LBT0DH'] + W[541] + window['$LHD']['$LBTH0D']);
  } }), wx[W[542]]({ 'success': function (y03xr) {
    console[W[310]](W[543] + y03xr[W[544]] + W[545] + y03xr[W[546]]);
  } }), wx[W[547]]({ 'success': function (o7ev91) {
    console[W[310]](W[548] + o7ev91[W[549]]);
  } }), wx[W[550]]({ 'keepScreenOn': !![] }), wx[W[551]](function (r30mic) {
  console[W[310]](W[548] + r30mic[W[549]] + W[552] + r30mic[W[553]]);
}), wx[W[554]](function (x0cy3r) {
  window['$L0T'] = x0cy3r, window['$LDT0'] && window['$L0T'] && (console[W[436]](W[555] + window['$L0T'][W[556]]), window['$LDT0'](window['$L0T']), window['$L0T'] = null);
}), window[W[557]] = 0x0, window['$LBH0DT'] = 0x0, window[W[558]] = null, wx[W[559]](function () {
  window['$LBH0DT']++;var p16ueg = Date[W[144]]();(window[W[557]] == 0x0 || p16ueg - window[W[557]] > 0x1d4c0) && (console[W[421]](W[560]), wx[W[561]]());if (window['$LBH0DT'] >= 0x2) {
    window['$LBH0DT'] = 0x0, console[W[404]](W[562]), wx[W[563]]('0', 0x1);if (window['$LHD'] && window['$LHD'][W[526]]) window['$LHDT'](W[564], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});