var W = wx.$l;
require('llllllBF.js'), window[W[29140]][W[29141]][W[29142]] = null, window['client_pb'] = require('LLLCLIENTPB.js'), window[W[26022]] = window[W[29140]][W[25934]][W[25935]](client_pb);