var W = wx.$l;
import L9jthlqz from '../llllSDK/llllSDDK.js';window[W[565]] = { 'wxVersion': window[W[441]][W[442]] }, window[W[566]] = ![], window['$LDH'] = 0x1, window[W[567]] = 0x1, window['$L0HD'] = !![], window[W[568]] = !![], window['$LBT0HD'] = '', window['$LHD'] = { 'base_cdn': W[569], 'cdn': W[569] }, $LHD[W[570]] = {}, $LHD[W[571]] = '0', $LHD[W[502]] = window[W[565]][W[208]], $LHD[W[533]] = '', $LHD['os'] = '1', $LHD[W[572]] = W[573], $LHD[W[574]] = W[575], $LHD[W[576]] = W[577], $LHD[W[578]] = W[579], $LHD[W[580]] = W[581], $LHD[W[582]] = '1', $LHD[W[262]] = '', $LHD[W[583]] = '', $LHD[W[584]] = 0x0, $LHD[W[303]] = {}, $LHD[W[585]] = parseInt($LHD[W[582]]), $LHD[W[586]] = $LHD[W[582]], $LHD[W[149]] = {}, $LHD['$LTH'] = W[587], $LHD[W[588]] = ![], $LHD[W[589]] = W[590], $LHD[W[591]] = Date[W[144]](), $LHD[W[592]] = W[593], $LHD[W[594]] = '_a', $LHD[W[193]] = 0x1, $LHD[W[206]] = 0x7c1, $LHD[W[208]] = window[W[565]][W[208]], $LHD[W[595]] = ![], $LHD[W[526]] = ![], $LHD[W[528]] = ![], $LHD[W[531]] = ![], window['$L0DH'] = 0x5, window['$L0D'] = ![], window['$LD0'] = ![], window['$LH0D'] = ![], window[W[382]] = ![], window[W[385]] = ![], window['$LHD0'] = ![], window['$L0H'] = ![], window['$LH0'] = ![], window['$LD0H'] = ![], window[W[596]] = function (of97v1) {
  console[W[310]](W[596], of97v1), wx[W[597]]({}), wx[W[471]]({ 'title': W[494], 'content': of97v1, 'success'(sa2db$) {
      if (sa2db$[W[598]]) console[W[310]](W[599]);else sa2db$[W[600]] && console[W[310]](W[601]);
    } });
}, window['$LT0HD'] = function ($8ds42) {
  console[W[310]](W[602], $8ds42), $LTHD0(), wx[W[471]]({ 'title': W[494], 'content': $8ds42, 'confirmText': W[603], 'cancelText': W[604], 'success'(jzhb) {
      if (jzhb[W[598]]) window['$LHT']();else jzhb[W[600]] && (console[W[310]](W[605]), wx[W[606]]({}));
    } });
}, window[W[607]] = function (eu7vg) {
  console[W[310]](W[607], eu7vg), wx[W[471]]({ 'title': W[494], 'content': eu7vg, 'confirmText': W[608], 'showCancel': ![], 'complete'(_yn0) {
      console[W[310]](W[605]), wx[W[606]]({});
    } });
}, window['$LT0DH'] = ![], window['$LTH0D'] = function (tolf59) {
  window['$LT0DH'] = !![], wx[W[609]](tolf59);
}, window['$LTHD0'] = function () {
  window['$LT0DH'] && (window['$LT0DH'] = ![], wx[W[597]]({}));
}, window['$LTD0H'] = function (qajzh) {
  window[W[435]][W[145]]['$LTD0H'](qajzh);
}, window[W[610]] = function (s824d$, tlzhqj) {
  L9jthlqz[W[610]](s824d$, function (kjqlhz) {
    kjqlhz && kjqlhz[W[314]] ? kjqlhz[W[314]][W[313]] == 0x1 ? tlzhqj(!![]) : (tlzhqj(![]), console[W[436]](W[611] + kjqlhz[W[314]][W[612]])) : console[W[310]](W[610], kjqlhz);
  });
}, window['$LTDH0'] = function (yr0x3n) {
  console[W[310]](W[613], yr0x3n);
}, window['$LTHD'] = function (mrc0y) {}, window['$LTDH'] = function (x8sn4, e61gup, fzlq5t) {}, window['$LTD'] = function (dbkja) {
  console[W[310]](W[614], dbkja), window[W[435]][W[145]][W[197]](), window[W[435]][W[145]][W[198]](), window[W[435]][W[145]][W[212]]();
}, window['$LDT'] = function (i3rmw) {
  window['$LT0HD'](W[615]);var ny04 = { 'id': window['$LHD'][W[449]], 'role': window['$LHD'][W[450]], 'level': window['$LHD'][W[451]], 'account': window['$LHD'][W[452]], 'version': window['$LHD'][W[206]], 'cdn': window['$LHD'][W[296]], 'pkgName': window['$LHD'][W[262]], 'gamever': window[W[441]][W[442]], 'serverid': window['$LHD'][W[149]] ? window['$LHD'][W[149]][W[150]] : 0x0, 'systemInfo': window[W[453]], 'error': W[616], 'stack': i3rmw ? i3rmw : W[615] },
      cmwri = JSON[W[402]](ny04);console[W[404]](W[617] + cmwri), window['$LTH'](cmwri);
}, window['$LHTD'] = function (n0x_) {
  var i30rmc = JSON[W[618]](n0x_);i30rmc[W[619]] = window[W[441]][W[442]], i30rmc[W[620]] = window['$LHD'][W[149]] ? window['$LHD'][W[149]][W[150]] : 0x0, i30rmc[W[453]] = window[W[453]];var jlzhq = JSON[W[402]](i30rmc);console[W[404]](W[621] + jlzhq), window['$LTH'](jlzhq);
}, window['$LHDT'] = function (m3ri0c, $dbka) {
  var n8x_4y = { 'id': window['$LHD'][W[449]], 'role': window['$LHD'][W[450]], 'level': window['$LHD'][W[451]], 'account': window['$LHD'][W[452]], 'version': window['$LHD'][W[206]], 'cdn': window['$LHD'][W[296]], 'pkgName': window['$LHD'][W[262]], 'gamever': window[W[441]][W[442]], 'serverid': window['$LHD'][W[149]] ? window['$LHD'][W[149]][W[150]] : 0x0, 'systemInfo': window[W[453]], 'error': m3ri0c, 'stack': $dbka },
      xyr3 = JSON[W[402]](n8x_4y);console[W[421]](W[622] + xyr3), window['$LTH'](xyr3);
}, window['$LTH'] = function (ltqj) {
  if (window['$LHD'][W[534]] == W[623]) return;var jh2abk = $LHD['$LTH'] + W[624] + $LHD[W[452]];wx[W[625]]({ 'url': jh2abk, 'method': W[626], 'data': ltqj, 'header': { 'content-type': W[627], 'cache-control': W[628] }, 'success': function (e1v7) {
      DEBUG && console[W[310]](W[629], jh2abk, ltqj, e1v7);
    }, 'fail': function (xy4_0) {
      DEBUG && console[W[310]](W[629], jh2abk, ltqj, xy4_0);
    }, 'complete': function () {} });
}, window[W[630]] = function () {
  function bd2s$() {
    return ((0x1 + Math[W[200]]()) * 0x10000 | 0x0)[W[631]](0x10)[W[632]](0x1);
  }return bd2s$() + bd2s$() + '-' + bd2s$() + '-' + bd2s$() + '-' + bd2s$() + '+' + bd2s$() + bd2s$() + bd2s$();
}, window['$LHT'] = function () {
  console[W[310]](W[633]);var z5lq = L9jthlqz[W[634]]();$LHD[W[586]] = z5lq[W[635]], $LHD[W[585]] = z5lq[W[635]], $LHD[W[582]] = z5lq[W[635]], $LHD[W[262]] = z5lq[W[636]];var s$da2 = { 'game_ver': $LHD[W[502]] };$LHD[W[583]] = this[W[630]](), $LTH0D({ 'title': W[637] }), L9jthlqz[W[347]](s$da2, this['$LDTH'][W[204]](this));
}, window['$LDTH'] = function (eg7uv) {
  var im3cr = eg7uv[W[638]];console[W[310]](W[639] + im3cr + W[640] + (im3cr == 0x1) + W[641] + eg7uv[W[442]] + W[642] + window[W[565]][W[208]]);if (!eg7uv[W[442]] || window['$LB0DTH'](window[W[565]][W[208]], eg7uv[W[442]]) < 0x0) console[W[310]](W[643]), $LHD[W[574]] = W[644], $LHD[W[576]] = W[645], $LHD[W[578]] = W[646], $LHD[W[296]] = W[647], $LHD[W[648]] = W[649], $LHD[W[650]] = W[651], $LHD[W[595]] = ![];else window['$LB0DTH'](window[W[565]][W[208]], eg7uv[W[442]]) == 0x0 ? (console[W[310]](W[652]), $LHD[W[574]] = W[575], $LHD[W[576]] = W[577], $LHD[W[578]] = W[579], $LHD[W[296]] = W[569], $LHD[W[648]] = W[649], $LHD[W[650]] = W[651], $LHD[W[595]] = !![]) : (console[W[310]](W[653]), $LHD[W[574]] = W[575], $LHD[W[576]] = W[577], $LHD[W[578]] = W[579], $LHD[W[296]] = W[569], $LHD[W[648]] = W[649], $LHD[W[650]] = W[651], $LHD[W[595]] = ![]);$LHD[W[584]] = config[W[654]] ? config[W[654]] : 0x0, this['$L0HTD'](), this['$L0HDT'](), window[W[655]] = 0x5, $LTH0D({ 'title': W[656] }), L9jthlqz[W[657]](this['$LDHT'][W[204]](this));
}, window[W[655]] = 0x5, window['$LDHT'] = function (k2d$ab, yn8_x) {
  if (k2d$ab == 0x0 && yn8_x && yn8_x[W[658]]) {
    $LHD[W[659]] = yn8_x[W[658]];var y0n3rx = this;$LTH0D({ 'title': W[660] }), sendApi($LHD[W[574]], W[661], { 'platform': $LHD[W[572]], 'partner_id': $LHD[W[582]], 'token': yn8_x[W[658]], 'game_pkg': $LHD[W[262]], 'deviceId': $LHD[W[583]], 'scene': W[662] + $LHD[W[584]] }, this['$L0THD'][W[204]](this), $L0DH, $LDT);
  } else yn8_x && yn8_x[W[481]] && window[W[655]] > 0x0 && (yn8_x[W[481]][W[424]](W[663]) != -0x1 || yn8_x[W[481]][W[424]](W[664]) != -0x1 || yn8_x[W[481]][W[424]](W[665]) != -0x1 || yn8_x[W[481]][W[424]](W[666]) != -0x1 || yn8_x[W[481]][W[424]](W[667]) != -0x1 || yn8_x[W[481]][W[424]](W[668]) != -0x1) ? (window[W[655]]--, L9jthlqz[W[657]](this['$LDHT'][W[204]](this))) : (window['$LHDT'](W[669], JSON[W[402]]({ 'status': k2d$ab, 'data': yn8_x })), window['$LT0HD'](W[670] + (yn8_x && yn8_x[W[481]] ? '，' + yn8_x[W[481]] : '')));
}, window['$L0THD'] = function (jhzaq) {
  if (!jhzaq) {
    window['$LHDT'](W[671], W[672]), window['$LT0HD'](W[673]);return;
  }if (jhzaq[W[313]] != W[312]) {
    window['$LHDT'](W[671], JSON[W[402]](jhzaq)), window['$LT0HD'](W[674] + jhzaq[W[313]]);return;
  }$LHD[W[675]] = String(jhzaq[W[452]]), $LHD[W[452]] = String(jhzaq[W[452]]), $LHD[W[506]] = String(jhzaq[W[506]]), $LHD[W[586]] = String(jhzaq[W[506]]), $LHD[W[676]] = String(jhzaq[W[676]]), $LHD[W[677]] = String(jhzaq[W[678]]), $LHD[W[679]] = String(jhzaq[W[680]]), $LHD[W[678]] = '';var $2bsda = this;$LTH0D({ 'title': W[681] }), sendApi($LHD[W[574]], W[682], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, $2bsda['$L0TDH'][W[204]]($2bsda), $L0DH, $LDT);
}, window['$L0TDH'] = function (hlt5zq) {
  if (!hlt5zq) {
    window['$LT0HD'](W[683]);return;
  }if (hlt5zq[W[313]] != W[312]) {
    window['$LT0HD'](W[684] + hlt5zq[W[313]]);return;
  }if (!hlt5zq[W[314]] || hlt5zq[W[314]][W[178]] == 0x0) {
    window['$LT0HD'](W[685]);return;
  }$LHD[W[391]] = hlt5zq[W[686]], $LHD[W[149]] = { 'server_id': String(hlt5zq[W[314]][0x0][W[150]]), 'server_name': String(hlt5zq[W[314]][0x0][W[290]]), 'entry_ip': hlt5zq[W[314]][0x0][W[687]], 'entry_port': parseInt(hlt5zq[W[314]][0x0][W[688]]), 'status': $LH0T(hlt5zq[W[314]][0x0]), 'start_time': hlt5zq[W[314]][0x0][W[689]], 'cdn': $LHD[W[296]] }, this['$LDH0T']();
}, window['$LDH0T'] = function () {
  if ($LHD[W[391]] == 0x1) {
    var rny3x0 = $LHD[W[149]][W[289]];if (rny3x0 === -0x1 || rny3x0 === 0x0) {
      window['$LT0HD'](rny3x0 === -0x1 ? W[690] : W[691]);return;
    }$LDT0H(0x0, $LHD[W[149]][W[150]]), window[W[435]][W[145]][W[386]]($LHD[W[391]]);
  } else window[W[435]][W[145]][W[383]](), $LTHD0();window['$LH0'] = !![], window['$LD0HT'](), window['$LDHT0']();
}, window['$L0HTD'] = function () {
  sendApi($LHD[W[574]], W[692], { 'game_pkg': $LHD[W[262]], 'version_name': $LHD[W[650]] }, this[W[693]][W[204]](this), $L0DH, $LDT);
}, window[W[693]] = function (ka2hj) {
  if (!ka2hj) {
    window['$LT0HD'](W[694]);return;
  }if (ka2hj[W[313]] != W[312]) {
    window['$LT0HD'](W[695] + ka2hj[W[313]]);return;
  }if (!ka2hj[W[314]] || !ka2hj[W[314]][W[502]]) {
    window['$LT0HD'](W[696] + (ka2hj[W[314]] && ka2hj[W[314]][W[502]]));return;
  }ka2hj[W[314]][W[697]] && ka2hj[W[314]][W[697]][W[178]] > 0xa && ($LHD[W[698]] = ka2hj[W[314]][W[697]], $LHD[W[296]] = ka2hj[W[314]][W[697]]), ka2hj[W[314]][W[502]] && ($LHD[W[206]] = ka2hj[W[314]][W[502]]), console[W[436]](W[699] + $LHD[W[206]] + W[700] + $LHD[W[650]]), window['$LHD0'] = !![], window['$LD0HT'](), window['$LDHT0']();
}, window[W[701]], window['$L0HDT'] = function () {
  sendApi($LHD[W[574]], W[702], { 'game_pkg': $LHD[W[262]] }, this['$L0DTH'][W[204]](this), $L0DH, $LDT);
}, window['$L0DTH'] = function (k2$dba) {
  if (k2$dba[W[313]] === W[312] && k2$dba[W[314]]) {
    window[W[701]] = k2$dba[W[314]];for (var zqhjtl in k2$dba[W[314]]) {
      $LHD[zqhjtl] = k2$dba[W[314]][zqhjtl];
    }
  } else console[W[436]](W[703] + k2$dba[W[313]]);window['$L0H'] = !![], window['$LDHT0']();
}, window[W[704]] = function (jka2db, akh, m3irw, lqhzt5, bjad2, gv7u1e, _xy30, ka2jh, zjqlh) {
  bjad2 = String(bjad2);var ev1o7g = _xy30,
      cimr3w = ka2jh;$LHD[W[570]][bjad2] = { 'productid': bjad2, 'productname': ev1o7g, 'productdesc': cimr3w, 'roleid': jka2db, 'rolename': akh, 'rolelevel': m3irw, 'price': gv7u1e, 'callback': zjqlh }, sendApi($LHD[W[578]], W[705], { 'game_pkg': $LHD[W[262]], 'server_id': $LHD[W[149]][W[150]], 'server_name': $LHD[W[149]][W[290]], 'level': m3irw, 'uid': $LHD[W[452]], 'role_id': jka2db, 'role_name': akh, 'product_id': bjad2, 'product_name': ev1o7g, 'product_desc': cimr3w, 'money': gv7u1e, 'partner_id': $LHD[W[582]] }, toPayCallBack, $L0DH, $LDT);
}, window[W[706]] = function (qhzjtl) {
  if (qhzjtl) {
    if (qhzjtl[W[707]] === 0xc8 || qhzjtl[W[313]] == W[312]) {
      var v7ug = $LHD[W[570]][String(qhzjtl[W[708]])];if (v7ug[W[709]]) v7ug[W[709]](qhzjtl[W[708]], qhzjtl[W[710]], -0x1);L9jthlqz[W[711]]({ 'cpbill': qhzjtl[W[710]], 'productid': qhzjtl[W[708]], 'productname': v7ug[W[712]], 'productdesc': v7ug[W[713]], 'serverid': $LHD[W[149]][W[150]], 'servername': $LHD[W[149]][W[290]], 'roleid': v7ug[W[714]], 'rolename': v7ug[W[715]], 'rolelevel': v7ug[W[716]], 'price': v7ug[W[717]], 'extension': JSON[W[402]]({ 'cp_order_id': qhzjtl[W[710]] }) }, function (yrnx, fqlzt5) {
        v7ug[W[709]] && yrnx == 0x0 && v7ug[W[709]](qhzjtl[W[708]], qhzjtl[W[710]], yrnx);console[W[436]](JSON[W[402]]({ 'type': W[718], 'status': yrnx, 'data': qhzjtl, 'role_name': v7ug[W[715]] }));if (yrnx === 0x0) {} else {
          if (yrnx === 0x1) {} else {
            if (yrnx === 0x2) {}
          }
        }
      });
    } else alert(qhzjtl[W[436]]);
  }
}, window['$L0DHT'] = function () {}, window['$LT0D'] = function (uv16g, l9t, tzjq, xcry30, ny4_x0) {
  L9jthlqz[W[719]]($LHD[W[149]][W[150]], $LHD[W[149]][W[290]] || $LHD[W[149]][W[150]], uv16g, l9t, tzjq), sendApi($LHD[W[574]], W[720], { 'game_pkg': $LHD[W[262]], 'server_id': $LHD[W[149]][W[150]], 'role_id': uv16g, 'uid': $LHD[W[452]], 'role_name': l9t, 'role_type': xcry30, 'level': tzjq });
}, window['$LTD0'] = function (adbj2k, g1vo7, b2$kd, kdajb2, cyx30r, ha, rx03cy, jhlt, n_8y4, d2b$a) {
  $LHD[W[449]] = adbj2k, $LHD[W[450]] = g1vo7, $LHD[W[451]] = b2$kd, L9jthlqz[W[721]]($LHD[W[149]][W[150]], $LHD[W[149]][W[290]] || $LHD[W[149]][W[150]], adbj2k, g1vo7, b2$kd), sendApi($LHD[W[574]], W[722], { 'game_pkg': $LHD[W[262]], 'server_id': $LHD[W[149]][W[150]], 'role_id': adbj2k, 'uid': $LHD[W[452]], 'role_name': g1vo7, 'role_type': kdajb2, 'level': b2$kd, 'evolution': cyx30r });
}, window['$L0TD'] = function (tlzh, t5zlfq, gepu61, ym3r, jhkza, lzqhtj, f9o5, gv61ue, f9ot57, _s8x) {
  $LHD[W[449]] = tlzh, $LHD[W[450]] = t5zlfq, $LHD[W[451]] = gepu61, L9jthlqz[W[723]]($LHD[W[149]][W[150]], $LHD[W[149]][W[290]] || $LHD[W[149]][W[150]], tlzh, t5zlfq, gepu61), sendApi($LHD[W[574]], W[722], { 'game_pkg': $LHD[W[262]], 'server_id': $LHD[W[149]][W[150]], 'role_id': tlzh, 'uid': $LHD[W[452]], 'role_name': t5zlfq, 'role_type': ym3r, 'level': gepu61, 'evolution': jhkza });
}, window['$L0DT'] = function (h5zql) {}, window['$LT0'] = function (x_yn3) {
  L9jthlqz[W[724]](W[724], function (ftlo59) {
    x_yn3 && x_yn3(ftlo59);
  });
}, window[W[725]] = function () {
  L9jthlqz[W[725]]();
}, window[W[726]] = function () {
  L9jthlqz[W[727]]();
}, window[W[728]] = function (s_$n84, o9l5tf, bkdja, _x3ny0, tlq59, b2jk, hjqa, y0mc3r) {
  y0mc3r = y0mc3r || $LHD[W[149]][W[150]], sendApi($LHD[W[574]], W[729], { 'phone': s_$n84, 'role_id': o9l5tf, 'uid': $LHD[W[452]], 'game_pkg': $LHD[W[262]], 'partner_id': $LHD[W[582]], 'server_id': y0mc3r }, hjqa);
}, window[W[554]] = function ($8s42d) {
  window['$LDT0'] = $8s42d, window['$LDT0'] && window['$L0T'] && (console[W[436]](W[555] + window['$L0T'][W[556]]), window['$LDT0'](window['$L0T']), window['$L0T'] = null);
}, window['$LD0T'] = function (eu1vg6, n48sx_, i3mwrc, vg7) {
  window[W[730]](W[731], { 'game_pkg': window['$LHD'][W[262]], 'role_id': n48sx_, 'server_id': i3mwrc }, vg7);
}, window['$LHT0D'] = function (e1ugv, h5zlq) {
  function bsd82$(wir) {
    var yn4_x = [],
        khba2j = [],
        eu6g1 = window[W[441]][W[732]];for (var s2b$a in eu6g1) {
      var habkj = Number(s2b$a);(!e1ugv || !e1ugv[W[178]] || e1ugv[W[424]](habkj) != -0x1) && (khba2j[W[318]](eu6g1[s2b$a]), yn4_x[W[318]]([habkj, 0x3]));
    }window['$LB0DTH'](window[W[463]], W[733]) >= 0x0 ? (console[W[310]](W[734]), L9jthlqz[W[735]](khba2j, function (e7ugv1) {
      console[W[310]](W[736]), console[W[310]](e7ugv1);if (e7ugv1 && e7ugv1[W[481]] == W[737]) for (var p6e1u in eu6g1) {
        if (e7ugv1[eu6g1[p6e1u]] == W[738]) {
          var ftq9l = Number(p6e1u);for (var eo917v = 0x0; eo917v < yn4_x[W[178]]; eo917v++) {
            if (yn4_x[eo917v][0x0] == ftq9l) {
              yn4_x[eo917v][0x1] = 0x1;break;
            }
          }
        }
      }window['$LB0DTH'](window[W[463]], W[739]) >= 0x0 ? wx[W[740]]({ 'withSubscriptions': !![], 'success': function (xy4) {
          var aqhkjz = xy4[W[741]][W[742]];if (aqhkjz) {
            console[W[310]](W[743]), console[W[310]](aqhkjz);for (var ny_8 in eu6g1) {
              if (aqhkjz[eu6g1[ny_8]] == W[738]) {
                var abh2j = Number(ny_8);for (var wi3c = 0x0; wi3c < yn4_x[W[178]]; wi3c++) {
                  if (yn4_x[wi3c][0x0] == abh2j) {
                    yn4_x[wi3c][0x1] = 0x2;break;
                  }
                }
              }
            }console[W[310]](yn4_x), h5zlq && h5zlq(yn4_x);
          } else console[W[310]](W[744]), console[W[310]](xy4), console[W[310]](yn4_x), h5zlq && h5zlq(yn4_x);
        }, 'fail': function () {
          console[W[310]](W[745]), console[W[310]](yn4_x), h5zlq && h5zlq(yn4_x);
        } }) : (console[W[310]](W[746] + window[W[463]]), console[W[310]](yn4_x), h5zlq && h5zlq(yn4_x));
    })) : (console[W[310]](W[747] + window[W[463]]), console[W[310]](yn4_x), h5zlq && h5zlq(yn4_x)), wx[W[748]](bsd82$);
  }wx[W[749]](bsd82$);
}, window['$LHTD0'] = { 'isSuccess': ![], 'level': W[750], 'isCharging': ![] }, window['$LH0TD'] = function (kzhjab) {
  wx[W[542]]({ 'success': function (v71e9) {
      var r3mc0i = window['$LHTD0'];r3mc0i[W[751]] = !![], r3mc0i[W[544]] = Number(v71e9[W[544]])[W[752]](0x0), r3mc0i[W[546]] = v71e9[W[546]], kzhjab && kzhjab(r3mc0i[W[751]], r3mc0i[W[544]], r3mc0i[W[546]]);
    }, 'fail': function (x3cy0r) {
      console[W[310]](W[753], x3cy0r[W[481]]);var v16uge = window['$LHTD0'];kzhjab && kzhjab(v16uge[W[751]], v16uge[W[544]], v16uge[W[546]]);
    } });
}, window[W[730]] = function (uev1, ve6ug1, hqjl, $s8d2b, lt5zfq, jda2kb, otl5f9, $adb2) {
  if ($s8d2b == undefined) $s8d2b = 0x1;wx[W[625]]({ 'url': uev1, 'method': otl5f9 || W[754], 'responseType': W[202], 'data': ve6ug1, 'header': { 'content-type': $adb2 || W[627] }, 'success': function (g1veo7) {
      DEBUG && console[W[310]](W[755], uev1, info, g1veo7);if (g1veo7 && g1veo7[W[756]] == 0xc8) {
        var qhzt5 = g1veo7[W[314]];!jda2kb || jda2kb(qhzt5) ? hqjl && hqjl(qhzt5) : window[W[757]](uev1, ve6ug1, hqjl, $s8d2b, lt5zfq, jda2kb, g1veo7);
      } else window[W[757]](uev1, ve6ug1, hqjl, $s8d2b, lt5zfq, jda2kb, g1veo7);
    }, 'fail': function (qzkah) {
      DEBUG && console[W[310]](W[758], uev1, info, qzkah), window[W[757]](uev1, ve6ug1, hqjl, $s8d2b, lt5zfq, jda2kb, qzkah);
    }, 'complete': function () {} });
}, window[W[757]] = function ($4_sd8, r0ci, n_$s84, euv1g, kqlj, $8_ns, f7o9v1) {
  euv1g - 0x1 > 0x0 ? setTimeout(function () {
    window[W[730]]($4_sd8, r0ci, n_$s84, euv1g - 0x1, kqlj, $8_ns);
  }, 0x3e8) : kqlj && kqlj(JSON[W[402]]({ 'url': $4_sd8, 'response': f7o9v1 }));
}, window[W[759]] = function (fv75o9, bkda2, a2$ds, lof5t9, kaqjhz, ov1g7e, hljzkq) {
  !a2$ds && (a2$ds = {});var myr0c3 = Math[W[405]](Date[W[144]]() / 0x3e8);a2$ds[W[680]] = myr0c3, a2$ds[W[760]] = bkda2;var ajd2kb = Object[W[761]](a2$ds)[W[319]](),
      k$2b = '',
      v917e = '';for (var hzkl = 0x0; hzkl < ajd2kb[W[178]]; hzkl++) {
    k$2b = k$2b + (hzkl == 0x0 ? '' : '&') + ajd2kb[hzkl] + a2$ds[ajd2kb[hzkl]], v917e = v917e + (hzkl == 0x0 ? '' : '&') + ajd2kb[hzkl] + '=' + encodeURIComponent(a2$ds[ajd2kb[hzkl]]);
  }k$2b = k$2b + $LHD[W[580]];var rx3yc = W[762] + md5(k$2b);send(fv75o9 + '?' + v917e + (v917e == '' ? '' : '&') + rx3yc, null, lof5t9, kaqjhz, ov1g7e, hljzkq || function (_4$s) {
    return _4$s[W[313]] == W[312];
  }, null, W[763]);
}, window['$LH0DT'] = function ($d428s, ir03) {
  var jaq = 0x0;$LHD[W[149]] && (jaq = $LHD[W[149]][W[150]]), sendApi($LHD[W[576]], W[764], { 'partnerId': $LHD[W[582]], 'gamePkg': $LHD[W[262]], 'logTime': Math[W[405]](Date[W[144]]() / 0x3e8), 'platformUid': $LHD[W[676]], 'type': $d428s, 'serverId': jaq }, null, 0x2, null, function () {
    return !![];
  });
}, window['$LHDT0'] = function (_xn84y) {
  sendApi($LHD[W[574]], W[765], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, $LHD0T, $L0DH, $LDT);
}, window['$LHD0T'] = function (bka2d) {
  if (bka2d[W[313]] === W[312] && bka2d[W[314]]) {
    bka2d[W[314]][W[766]]({ 'id': -0x2, 'name': W[767] }), bka2d[W[314]][W[766]]({ 'id': -0x1, 'name': W[768] }), $LHD[W[261]] = bka2d[W[314]];if (window[W[253]]) window[W[253]][W[297]]();
  } else $LHD[W[272]] = ![], window['$LT0HD'](W[769] + bka2d[W[313]]);
}, window['$LT0H'] = function (ryx0n) {
  sendApi($LHD[W[574]], W[770], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, $LTH0, $L0DH, $LDT);
}, window['$LTH0'] = function (u71ge) {
  $LHD[W[305]] = ![];if (u71ge[W[313]] === W[312] && u71ge[W[314]]) {
    for (var gv1u7 = 0x0; gv1u7 < u71ge[W[314]][W[178]]; gv1u7++) {
      u71ge[W[314]][gv1u7][W[289]] = $LH0T(u71ge[W[314]][gv1u7]);
    }$LHD[W[303]][-0x1] = window[W[771]](u71ge[W[314]]), window[W[253]][W[304]](-0x1);
  } else window['$LT0HD'](W[772] + u71ge[W[313]]);
}, window[W[773]] = function (kqjza) {
  sendApi($LHD[W[574]], W[770], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, kqjza, $L0DH, $LDT);
}, window['$L0TH'] = function (_d8s4$, vg7e1) {
  sendApi($LHD[W[574]], W[774], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]], 'server_group_id': vg7e1 }, $L0HT, $L0DH, $LDT);
}, window['$L0HT'] = function (abd2k$) {
  $LHD[W[305]] = ![];if (abd2k$[W[313]] === W[312] && abd2k$[W[314]] && abd2k$[W[314]][W[314]]) {
    var l9f5o = abd2k$[W[314]][W[775]],
        x0n_y = [];for (var y0n_4x = 0x0; y0n_4x < abd2k$[W[314]][W[314]][W[178]]; y0n_4x++) {
      abd2k$[W[314]][W[314]][y0n_4x][W[289]] = $LH0T(abd2k$[W[314]][W[314]][y0n_4x]), (x0n_y[W[178]] == 0x0 || abd2k$[W[314]][W[314]][y0n_4x][W[289]] != 0x0) && (x0n_y[x0n_y[W[178]]] = abd2k$[W[314]][W[314]][y0n_4x]);
    }$LHD[W[303]][l9f5o] = window[W[771]](x0n_y), window[W[253]][W[304]](l9f5o);
  } else window['$LT0HD'](W[776] + abd2k$[W[313]]);
}, window['$LB0DH'] = function (zljkh) {
  sendApi($LHD[W[574]], W[777], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, reqServerRecommendCallBack, $L0DH, $LDT);
}, window[W[778]] = function (f57ot9) {
  $LHD[W[305]] = ![];if (f57ot9[W[313]] === W[312] && f57ot9[W[314]]) {
    for (var ds8$4 = 0x0; ds8$4 < f57ot9[W[314]][W[178]]; ds8$4++) {
      f57ot9[W[314]][ds8$4][W[289]] = $LH0T(f57ot9[W[314]][ds8$4]);
    }$LHD[W[303]][-0x2] = window[W[771]](f57ot9[W[314]]), window[W[253]][W[304]](-0x2);
  } else alert(W[779] + f57ot9[W[313]]);
}, window[W[771]] = function (g71v) {
  if (!g71v && g71v[W[178]] <= 0x0) return g71v;for (let s$d82 = 0x0; s$d82 < g71v[W[178]]; s$d82++) {
    g71v[s$d82][W[780]] && g71v[s$d82][W[780]] == 0x1 && (g71v[s$d82][W[290]] += W[781]);
  }return g71v;
}, window['$LHT0'] = function (e7o19, im0rc3) {
  e7o19 = e7o19 || $LHD[W[149]][W[150]], sendApi($LHD[W[574]], W[782], { 'type': '4', 'game_pkg': $LHD[W[262]], 'server_id': e7o19 }, im0rc3);
}, window[W[783]] = function (vueg16, bd2jka, mrwic3, y0x_n3) {
  mrwic3 = mrwic3 || $LHD[W[149]][W[150]], sendApi($LHD[W[574]], W[784], { 'type': vueg16, 'game_pkg': bd2jka, 'server_id': mrwic3 }, y0x_n3);
}, window['$LH0T'] = function (yrm3c0) {
  if (yrm3c0) {
    if (yrm3c0[W[289]] == 0x1) {
      if (yrm3c0[W[785]] == 0x1) return 0x2;else return 0x1;
    } else return yrm3c0[W[289]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$LDT0H'] = function (s_8n4, g6e1u) {
  $LHD[W[786]] = { 'step': s_8n4, 'server_id': g6e1u };var $ad2bk = this;$LTH0D({ 'title': W[787] }), sendApi($LHD[W[574]], W[788], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'game_pkg': $LHD[W[262]], 'server_id': g6e1u, 'platform': $LHD[W[506]], 'platform_uid': $LHD[W[676]], 'check_login_time': $LHD[W[679]], 'check_login_sign': $LHD[W[677]], 'version_name': $LHD[W[650]] }, $LDTH0, $L0DH, $LDT, function (sb$) {
    return sb$[W[313]] == W[312] || sb$[W[436]] == W[789] || sb$[W[436]] == W[790];
  });
}, window['$LDTH0'] = function (nr3yx0) {
  var d28$ = this;if (nr3yx0[W[313]] === W[312] && nr3yx0[W[314]]) {
    var bjk2h = $LHD[W[149]];bjk2h[W[791]] = $LHD[W[585]], bjk2h[W[678]] = String(nr3yx0[W[314]][W[792]]), bjk2h[W[591]] = parseInt(nr3yx0[W[314]][W[680]]);if (nr3yx0[W[314]][W[793]]) bjk2h[W[793]] = parseInt(nr3yx0[W[314]][W[793]]);else bjk2h[W[793]] = parseInt(nr3yx0[W[314]][W[150]]);bjk2h[W[794]] = 0x0, bjk2h[W[296]] = $LHD[W[698]], bjk2h[W[795]] = nr3yx0[W[314]][W[796]], bjk2h[W[797]] = nr3yx0[W[314]][W[797]], console[W[310]](W[798] + JSON[W[402]](bjk2h[W[797]])), $LHD[W[391]] == 0x1 && bjk2h[W[797]] && bjk2h[W[797]][W[799]] == 0x1 && ($LHD[W[209]] = 0x1, window[W[435]][W[145]]['$LBDH']()), $LD0TH();
  } else $LHD[W[786]][W[800]] >= 0x3 ? ($LDT(JSON[W[402]](nr3yx0)), window['$LT0HD'](W[801] + nr3yx0[W[313]])) : sendApi($LHD[W[574]], W[661], { 'platform': $LHD[W[572]], 'partner_id': $LHD[W[582]], 'token': $LHD[W[659]], 'game_pkg': $LHD[W[262]], 'deviceId': $LHD[W[583]], 'scene': W[662] + $LHD[W[584]] }, function (ka2hb) {
    if (!ka2hb || ka2hb[W[313]] != W[312]) {
      window['$LT0HD'](W[674] + ka2hb && ka2hb[W[313]]);return;
    }$LHD[W[677]] = String(ka2hb[W[678]]), $LHD[W[679]] = String(ka2hb[W[680]]), setTimeout(function () {
      $LDT0H($LHD[W[786]][W[800]] + 0x1, $LHD[W[786]][W[150]]);
    }, 0x5dc);
  }, $L0DH, $LDT, function (n_3y0x) {
    return n_3y0x[W[313]] == W[312] || n_3y0x[W[313]] == W[802];
  });
}, window['$LD0TH'] = function () {
  ServerLoading[W[145]][W[386]]($LHD[W[391]]), window['$L0D'] = !![], window['$LDHT0']();
}, window['$LD0HT'] = function () {
  if (window['$LD0'] && window['$LH0D'] && window[W[382]] && window[W[385]] && window['$LHD0'] && window['$LH0']) {
    if (!window[W[803]][W[145]]) {
      console[W[310]](W[804] + window[W[803]][W[145]]);var jqkzlh = wx[W[805]](),
          jk2ab = jqkzlh[W[556]] ? jqkzlh[W[556]] : 0x0,
          jkahbz = { 'cdn': window['$LHD'][W[296]], 'spareCdn': window['$LHD'][W[648]], 'newRegister': window['$LHD'][W[391]], 'wxPC': window['$LHD'][W[531]], 'wxIOS': window['$LHD'][W[526]], 'wxAndroid': window['$LHD'][W[528]], 'wxParam': { 'limitLoad': window['$LHD']['$LBT0DH'], 'benchmarkLevel': window['$LHD']['$LBTH0D'], 'wxFrom': window[W[441]][W[654]] == W[806] ? 0x1 : 0x0, 'wxSDKVersion': window[W[463]] }, 'configType': window['$LHD'][W[592]], 'exposeType': window['$LHD'][W[594]], 'scene': jk2ab };new window[W[803]](jkahbz, window['$LHD'][W[206]], window['$LBT0HD']);
    }
  }
}, window['$LDHT0'] = function () {
  if (window['$LD0'] && window['$LH0D'] && window[W[382]] && window[W[385]] && window['$LHD0'] && window['$LH0'] && window['$L0D'] && window['$L0H']) {
    $LTHD0();if (!$LD0H) {
      $LD0H = !![];if (!window[W[803]][W[145]]) window['$LD0HT']();var e1vg = 0x0,
          _nyx = wx[W[807]]();_nyx && (window['$LHD'][W[530]] && (e1vg = _nyx[W[108]]), console[W[436]](W[808] + _nyx[W[108]] + W[809] + _nyx[W[220]] + W[810] + _nyx[W[524]] + W[811] + _nyx[W[69]] + W[812] + _nyx[W[170]] + W[813] + _nyx[W[172]]));var s_$84 = {};for (const i3cmrw in $LHD[W[149]]) {
        s_$84[i3cmrw] = $LHD[W[149]][i3cmrw];
      }var jhbkaz = { 'channel': window['$LHD'][W[586]], 'account': window['$LHD'][W[452]], 'userId': window['$LHD'][W[675]], 'cdn': window['$LHD'][W[296]], 'data': window['$LHD'][W[314]], 'package': window['$LHD'][W[571]], 'newRegister': window['$LHD'][W[391]], 'pkgName': window['$LHD'][W[262]], 'partnerId': window['$LHD'][W[582]], 'platform_uid': window['$LHD'][W[676]], 'deviceId': window['$LHD'][W[583]], 'selectedServer': s_$84, 'configType': window['$LHD'][W[592]], 'exposeType': window['$LHD'][W[594]], 'debugUsers': window['$LHD'][W[589]], 'wxMenuTop': e1vg, 'wxShield': window['$LHD'][W[595]] };if (window[W[701]]) for (var hqzaj in window[W[701]]) {
        jhbkaz[hqzaj] = window[W[701]][hqzaj];
      }window[W[803]][W[145]]['$LDHB'](jhbkaz);
    }
  } else console[W[436]](W[814] + window['$LD0'] + W[815] + window['$LH0D'] + W[816] + window[W[382]] + W[817] + window[W[385]] + W[818] + window['$LHD0'] + W[819] + window['$LH0'] + W[820] + window['$L0D'] + W[821] + window['$L0H']);
};