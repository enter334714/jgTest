var W = wx.$l;
require(W[0]);