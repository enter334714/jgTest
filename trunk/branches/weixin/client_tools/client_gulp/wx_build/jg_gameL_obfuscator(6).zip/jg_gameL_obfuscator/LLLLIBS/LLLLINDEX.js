var W = wx.$l;
import L9guve61 from '../llllSDK/llllSDDK.js';window[W[29155]] = { 'wxVersion': window[W[555]][W[29053]] }, window[W[29156]] = ![], window['$LDH'] = 0x1, window[W[29157]] = 0x1, window['$L0HD'] = !![], window[W[29158]] = !![], window['$LBT0HD'] = '', window['$LHD'] = { 'base_cdn': W[29159], 'cdn': W[29159] }, $LHD[W[29160]] = {}, $LHD[W[24906]] = '0', $LHD[W[4716]] = window[W[29155]][W[28957]], $LHD[W[29127]] = '', $LHD['os'] = '1', $LHD[W[29161]] = W[29162], $LHD[W[29163]] = W[29164], $LHD[W[29165]] = W[29166], $LHD[W[29167]] = W[29168], $LHD[W[29169]] = W[29170], $LHD[W[23641]] = '1', $LHD[W[25220]] = '', $LHD[W[25222]] = '', $LHD[W[29171]] = 0x0, $LHD[W[28995]] = {}, $LHD[W[29172]] = parseInt($LHD[W[23641]]), $LHD[W[25218]] = $LHD[W[23641]], $LHD[W[25214]] = {}, $LHD['$LTH'] = W[29173], $LHD[W[29174]] = ![], $LHD[W[12244]] = W[29175], $LHD[W[25191]] = Date[W[83]](), $LHD[W[11854]] = W[29176], $LHD[W[712]] = '_a', $LHD[W[28950]] = 0x1, $LHD[W[101]] = 0x7c1, $LHD[W[28957]] = window[W[29155]][W[28957]], $LHD[W[736]] = ![], $LHD[W[1072]] = ![], $LHD[W[11332]] = ![], $LHD[W[24908]] = ![], window['$L0DH'] = 0x5, window['$L0D'] = ![], window['$LD0'] = ![], window['$LH0D'] = ![], window[W[29026]] = ![], window[W[29029]] = ![], window['$LHD0'] = ![], window['$L0H'] = ![], window['$LH0'] = ![], window['$LD0H'] = ![], window[W[4185]] = function (j2bkda) {
  console[W[480]](W[4185], j2bkda), wx[W[4995]]({}), wx[W[29076]]({ 'title': W[6361], 'content': j2bkda, 'success'(m30ycr) {
      if (m30ycr[W[29177]]) console[W[480]](W[29178]);else m30ycr[W[551]] && console[W[480]](W[29179]);
    } });
}, window['$LT0HD'] = function (e7ovg) {
  console[W[480]](W[29180], e7ovg), $LTHD0(), wx[W[29076]]({ 'title': W[6361], 'content': e7ovg, 'confirmText': W[29181], 'cancelText': W[18499], 'success'(asb2$) {
      if (asb2$[W[29177]]) window['$LHT']();else asb2$[W[551]] && (console[W[480]](W[29182]), wx[W[25378]]({}));
    } });
}, window['$LHB'] = function (ahzj) {
  console[W[480]](W[29183], ahzj), wx[W[29076]]({ 'title': W[6361], 'content': ahzj, 'confirmText': W[25350], 'showCancel': ![], 'complete'(kdbj) {
      console[W[480]](W[29182]), wx[W[25378]]({});
    } });
}, window['$LT0DH'] = ![], window['$LTH0D'] = function (flt5q) {
  window['$LT0DH'] = !![], wx[W[4994]](flt5q);
}, window['$LTHD0'] = function () {
  window['$LT0DH'] && (window['$LT0DH'] = ![], wx[W[4995]]({}));
}, window['$LTD0H'] = function (yx0rc) {
  window[W[29049]][W[148]]['$LTD0H'](yx0rc);
}, window[W[12127]] = function (o71f, e179ov) {
  L9guve61[W[12127]](o71f, function (fl5q9) {
    fl5q9 && fl5q9[W[11]] ? fl5q9[W[11]][W[4118]] == 0x1 ? e179ov(!![]) : (e179ov(![]), console[W[78]](W[29184] + fl5q9[W[11]][W[29185]])) : console[W[480]](W[12127], fl5q9);
  });
}, window['$LTDH0'] = function (_n8x4y) {
  console[W[480]](W[29186], _n8x4y);
}, window['$LTHD'] = function (x0rn3y) {}, window['$LTDH'] = function (lhtjz, l5qft9, n3x0_) {}, window['$LTD'] = function (_sd8$4) {
  console[W[480]](W[29187], _sd8$4), window[W[29049]][W[148]][W[28952]](), window[W[29049]][W[148]][W[28953]](), window[W[29049]][W[148]][W[28960]]();
}, window['$LDT'] = function (gu6v1) {
  window['$LT0HD'](W[29188]);var akjzhb = { 'id': window['$LHD'][W[29058]], 'role': window['$LHD'][W[4645]], 'level': window['$LHD'][W[29059]], 'account': window['$LHD'][W[25219]], 'version': window['$LHD'][W[101]], 'cdn': window['$LHD'][W[4524]], 'pkgName': window['$LHD'][W[25220]], 'gamever': window[W[555]][W[29053]], 'serverid': window['$LHD'][W[25214]] ? window['$LHD'][W[25214]][W[11510]] : 0x0, 'systemInfo': window[W[29060]], 'error': W[29189], 'stack': gu6v1 ? gu6v1 : W[29188] },
      geov17 = JSON[W[4510]](akjzhb);console[W[125]](W[29190] + geov17), window['$LTH'](geov17);
}, window['$LHTD'] = function (r3c0im) {
  var c3irm = JSON[W[525]](r3c0im);c3irm[W[29191]] = window[W[555]][W[29053]], c3irm[W[29192]] = window['$LHD'][W[25214]] ? window['$LHD'][W[25214]][W[11510]] : 0x0, c3irm[W[29060]] = window[W[29060]];var hkazb = JSON[W[4510]](c3irm);console[W[125]](W[29193] + hkazb), window['$LTH'](hkazb);
}, window['$LHDT'] = function (r0n3x, n0r3y) {
  var x3y0n_ = { 'id': window['$LHD'][W[29058]], 'role': window['$LHD'][W[4645]], 'level': window['$LHD'][W[29059]], 'account': window['$LHD'][W[25219]], 'version': window['$LHD'][W[101]], 'cdn': window['$LHD'][W[4524]], 'pkgName': window['$LHD'][W[25220]], 'gamever': window[W[555]][W[29053]], 'serverid': window['$LHD'][W[25214]] ? window['$LHD'][W[25214]][W[11510]] : 0x0, 'systemInfo': window[W[29060]], 'error': r0n3x, 'stack': n0r3y },
      x3c0 = JSON[W[4510]](x3y0n_);console[W[96]](W[29194] + x3c0), window['$LTH'](x3c0);
}, window['$LTH'] = function (akqjhz) {
  if (window['$LHD'][W[29128]] == W[29195]) return;var ynx_30 = $LHD['$LTH'] + W[29196] + $LHD[W[25219]];wx[W[475]]({ 'url': ynx_30, 'method': W[29197], 'data': akqjhz, 'header': { 'content-type': W[29198], 'cache-control': W[29199] }, 'success': function (y_n03x) {
      DEBUG && console[W[480]](W[29200], ynx_30, akqjhz, y_n03x);
    }, 'fail': function (l5t9f) {
      DEBUG && console[W[480]](W[29200], ynx_30, akqjhz, l5t9f);
    }, 'complete': function () {} });
}, window[W[29201]] = function () {
  function lhqzt5() {
    return ((0x1 + Math[W[119]]()) * 0x10000 | 0x0)[W[272]](0x10)[W[498]](0x1);
  }return lhqzt5() + lhqzt5() + '-' + lhqzt5() + '-' + lhqzt5() + '-' + lhqzt5() + '+' + lhqzt5() + lhqzt5() + lhqzt5();
}, window['$LHT'] = function () {
  console[W[480]](W[29202]);var ev17o9 = L9guve61[W[29203]]();$LHD[W[25218]] = ev17o9[W[29204]], $LHD[W[29172]] = ev17o9[W[29204]], $LHD[W[23641]] = ev17o9[W[29204]], $LHD[W[25220]] = ev17o9[W[29205]];var y0_n3 = { 'game_ver': $LHD[W[4716]] };$LHD[W[25222]] = this[W[29201]](), $LTH0D({ 'title': W[29206] }), L9guve61[W[366]](y0_n3, this['$LDTH'][W[74]](this));
}, window['$LDTH'] = function (qjakz) {
  var ryx3c = qjakz[W[29207]];console[W[480]](W[29208] + ryx3c + W[29209] + (ryx3c == 0x1) + W[29210] + qjakz[W[29053]] + W[29211] + window[W[29155]][W[28957]]);if (!qjakz[W[29053]] || window['$LB0DTH'](window[W[29155]][W[28957]], qjakz[W[29053]]) < 0x0) console[W[480]](W[29212]), $LHD[W[29163]] = W[29213], $LHD[W[29165]] = W[29214], $LHD[W[29167]] = W[29215], $LHD[W[4524]] = W[29216], $LHD[W[24905]] = W[29217], $LHD[W[29218]] = W[29219], $LHD[W[736]] = ![];else window['$LB0DTH'](window[W[29155]][W[28957]], qjakz[W[29053]]) == 0x0 ? (console[W[480]](W[29220]), $LHD[W[29163]] = W[29164], $LHD[W[29165]] = W[29166], $LHD[W[29167]] = W[29168], $LHD[W[4524]] = W[29159], $LHD[W[24905]] = W[29217], $LHD[W[29218]] = W[29219], $LHD[W[736]] = !![]) : (console[W[480]](W[29221]), $LHD[W[29163]] = W[29164], $LHD[W[29165]] = W[29166], $LHD[W[29167]] = W[29168], $LHD[W[4524]] = W[29159], $LHD[W[24905]] = W[29217], $LHD[W[29218]] = W[29219], $LHD[W[736]] = ![]);$LHD[W[29171]] = config[W[28724]] ? config[W[28724]] : 0x0, this['$L0HTD'](), this['$L0HDT'](), window[W[29222]] = 0x5, $LTH0D({ 'title': W[29223] }), L9guve61[W[29224]](this['$LDHT'][W[74]](this));
}, window[W[29222]] = 0x5, window['$LDHT'] = function (ve7o1, $dbk2a) {
  if (ve7o1 == 0x0 && $dbk2a && $dbk2a[W[28815]]) {
    $LHD[W[29225]] = $dbk2a[W[28815]];var ak2$db = this;$LTH0D({ 'title': W[29226] }), sendApi($LHD[W[29163]], W[29227], { 'platform': $LHD[W[29161]], 'partner_id': $LHD[W[23641]], 'token': $dbk2a[W[28815]], 'game_pkg': $LHD[W[25220]], 'deviceId': $LHD[W[25222]], 'scene': W[29228] + $LHD[W[29171]] }, this['$L0THD'][W[74]](this), $L0DH, $LDT);
  } else $dbk2a && $dbk2a[W[25405]] && window[W[29222]] > 0x0 && ($dbk2a[W[25405]][W[115]](W[29229]) != -0x1 || $dbk2a[W[25405]][W[115]](W[29230]) != -0x1 || $dbk2a[W[25405]][W[115]](W[29231]) != -0x1 || $dbk2a[W[25405]][W[115]](W[29232]) != -0x1 || $dbk2a[W[25405]][W[115]](W[29233]) != -0x1 || $dbk2a[W[25405]][W[115]](W[29234]) != -0x1) ? (window[W[29222]]--, L9guve61[W[29224]](this['$LDHT'][W[74]](this))) : (window['$LHDT'](W[29235], JSON[W[4510]]({ 'status': ve7o1, 'data': $dbk2a })), window['$LT0HD'](W[29236] + ($dbk2a && $dbk2a[W[25405]] ? '，' + $dbk2a[W[25405]] : '')));
}, window['$L0THD'] = function (t9lqf) {
  if (!t9lqf) {
    window['$LHDT'](W[29237], W[29238]), window['$LT0HD'](W[29239]);return;
  }if (t9lqf[W[4118]] != W[9922]) {
    window['$LHDT'](W[29237], JSON[W[4510]](t9lqf)), window['$LT0HD'](W[29240] + t9lqf[W[4118]]);return;
  }$LHD[W[23640]] = String(t9lqf[W[25219]]), $LHD[W[25219]] = String(t9lqf[W[25219]]), $LHD[W[25189]] = String(t9lqf[W[25189]]), $LHD[W[25218]] = String(t9lqf[W[25189]]), $LHD[W[25221]] = String(t9lqf[W[25221]]), $LHD[W[29241]] = String(t9lqf[W[11493]]), $LHD[W[29242]] = String(t9lqf[W[849]]), $LHD[W[11493]] = '';var qhazkj = this;$LTH0D({ 'title': W[29243] }), sendApi($LHD[W[29163]], W[29244], { 'partner_id': $LHD[W[23641]], 'uid': $LHD[W[25219]], 'version': $LHD[W[4716]], 'game_pkg': $LHD[W[25220]], 'device': $LHD[W[25222]] }, qhazkj['$L0TDH'][W[74]](qhazkj), $L0DH, $LDT);
}, window['$L0TDH'] = function (d2sb$8) {
  if (!d2sb$8) {
    window['$LT0HD'](W[29245]);return;
  }if (d2sb$8[W[4118]] != W[9922]) {
    window['$LT0HD'](W[29246] + d2sb$8[W[4118]]);return;
  }if (!d2sb$8[W[11]] || d2sb$8[W[11]][W[13]] == 0x0) {
    window['$LT0HD'](W[29247]);return;
  }$LHD[W[628]] = d2sb$8[W[29248]], $LHD[W[25214]] = { 'server_id': String(d2sb$8[W[11]][0x0][W[11510]]), 'server_name': String(d2sb$8[W[11]][0x0][W[28989]]), 'entry_ip': d2sb$8[W[11]][0x0][W[25242]], 'entry_port': parseInt(d2sb$8[W[11]][0x0][W[25243]]), 'status': $LH0T(d2sb$8[W[11]][0x0]), 'start_time': d2sb$8[W[11]][0x0][W[29249]], 'cdn': $LHD[W[4524]] }, this['$LDH0T']();
}, window['$LDH0T'] = function () {
  if ($LHD[W[628]] == 0x1) {
    var zhqjtl = $LHD[W[25214]][W[106]];if (zhqjtl === -0x1 || zhqjtl === 0x0) {
      window['$LT0HD'](zhqjtl === -0x1 ? W[29250] : W[29251]);return;
    }$LDT0H(0x0, $LHD[W[25214]][W[11510]]), window[W[29049]][W[148]][W[29030]]($LHD[W[628]]);
  } else window[W[29049]][W[148]][W[29027]](), $LTHD0();window['$LH0'] = !![], window['$LD0HT'](), window['$LDHT0']();
}, window['$L0HTD'] = function () {
  sendApi($LHD[W[29163]], W[29252], { 'game_pkg': $LHD[W[25220]], 'version_name': $LHD[W[29218]] }, this[W[29253]][W[74]](this), $L0DH, $LDT);
}, window[W[29253]] = function (db8s) {
  if (!db8s) {
    window['$LT0HD'](W[29254]);return;
  }if (db8s[W[4118]] != W[9922]) {
    window['$LT0HD'](W[29255] + db8s[W[4118]]);return;
  }if (!db8s[W[11]] || !db8s[W[11]][W[4716]]) {
    window['$LT0HD'](W[29256] + (db8s[W[11]] && db8s[W[11]][W[4716]]));return;
  }db8s[W[11]][W[29257]] && db8s[W[11]][W[29257]][W[13]] > 0xa && ($LHD[W[29258]] = db8s[W[11]][W[29257]], $LHD[W[4524]] = db8s[W[11]][W[29257]]), db8s[W[11]][W[4716]] && ($LHD[W[101]] = db8s[W[11]][W[4716]]), console[W[78]](W[25356] + $LHD[W[101]] + W[29259] + $LHD[W[29218]]), window['$LHD0'] = !![], window['$LD0HT'](), window['$LDHT0']();
}, window[W[29260]], window['$L0HDT'] = function () {
  sendApi($LHD[W[29163]], W[29261], { 'game_pkg': $LHD[W[25220]] }, this['$L0DTH'][W[74]](this), $L0DH, $LDT);
}, window['$L0DTH'] = function (e6vg) {
  if (e6vg[W[4118]] === W[9922] && e6vg[W[11]]) {
    window[W[29260]] = e6vg[W[11]];for (var mr0ic in e6vg[W[11]]) {
      $LHD[mr0ic] = e6vg[W[11]][mr0ic];
    }
  } else console[W[78]](W[29262] + e6vg[W[4118]]);window['$L0H'] = !![], window['$LDHT0']();
}, window[W[29263]] = function (qzhjka, my3c0, rcmi30, zl5ht, lkhqzj, m3rci0, _30xy, ajkbd, s_x8) {
  lkhqzj = String(lkhqzj);var g1p = _30xy,
      tqlzh5 = ajkbd;$LHD[W[29160]][lkhqzj] = { 'productid': lkhqzj, 'productname': g1p, 'productdesc': tqlzh5, 'roleid': qzhjka, 'rolename': my3c0, 'rolelevel': rcmi30, 'price': m3rci0, 'callback': s_x8 }, sendApi($LHD[W[29167]], W[29264], { 'game_pkg': $LHD[W[25220]], 'server_id': $LHD[W[25214]][W[11510]], 'server_name': $LHD[W[25214]][W[28989]], 'level': rcmi30, 'uid': $LHD[W[25219]], 'role_id': qzhjka, 'role_name': my3c0, 'product_id': lkhqzj, 'product_name': g1p, 'product_desc': tqlzh5, 'money': m3rci0, 'partner_id': $LHD[W[23641]] }, toPayCallBack, $L0DH, $LDT);
}, window[W[29265]] = function (k2bajh) {
  if (k2bajh) {
    if (k2bajh[W[29266]] === 0xc8 || k2bajh[W[4118]] == W[9922]) {
      var mwc3ir = $LHD[W[29160]][String(k2bajh[W[29267]])];if (mwc3ir[W[332]]) mwc3ir[W[332]](k2bajh[W[29267]], k2bajh[W[29268]], -0x1);L9guve61[W[29269]]({ 'cpbill': k2bajh[W[29268]], 'productid': k2bajh[W[29267]], 'productname': mwc3ir[W[29270]], 'productdesc': mwc3ir[W[29271]], 'serverid': $LHD[W[25214]][W[11510]], 'servername': $LHD[W[25214]][W[28989]], 'roleid': mwc3ir[W[29272]], 'rolename': mwc3ir[W[29273]], 'rolelevel': mwc3ir[W[29274]], 'price': mwc3ir[W[26913]], 'extension': JSON[W[4510]]({ 'cp_order_id': k2bajh[W[29268]] }) }, function (kjhqlz, tf579) {
        mwc3ir[W[332]] && kjhqlz == 0x0 && mwc3ir[W[332]](k2bajh[W[29267]], k2bajh[W[29268]], kjhqlz);console[W[78]](JSON[W[4510]]({ 'type': W[29275], 'status': kjhqlz, 'data': k2bajh, 'role_name': mwc3ir[W[29273]] }));if (kjhqlz === 0x0) {} else {
          if (kjhqlz === 0x1) {} else {
            if (kjhqlz === 0x2) {}
          }
        }
      });
    } else alert(k2bajh[W[78]]);
  }
}, window['$L0DHT'] = function () {}, window['$LT0D'] = function (z5lfq, kh2abj, ny3, m3riw, a2sd$) {
  L9guve61[W[29276]]($LHD[W[25214]][W[11510]], $LHD[W[25214]][W[28989]] || $LHD[W[25214]][W[11510]], z5lfq, kh2abj, ny3), sendApi($LHD[W[29163]], W[29277], { 'game_pkg': $LHD[W[25220]], 'server_id': $LHD[W[25214]][W[11510]], 'role_id': z5lfq, 'uid': $LHD[W[25219]], 'role_name': kh2abj, 'role_type': m3riw, 'level': ny3 });
}, window['$LTD0'] = function (badkj, f7t5o, v57f, lf5zqt, n48$, zhqkjl, sb$2d, d$4s2, sd$ab, $8_s4) {
  $LHD[W[29058]] = badkj, $LHD[W[4645]] = f7t5o, $LHD[W[29059]] = v57f, L9guve61[W[29278]]($LHD[W[25214]][W[11510]], $LHD[W[25214]][W[28989]] || $LHD[W[25214]][W[11510]], badkj, f7t5o, v57f), sendApi($LHD[W[29163]], W[29279], { 'game_pkg': $LHD[W[25220]], 'server_id': $LHD[W[25214]][W[11510]], 'role_id': badkj, 'uid': $LHD[W[25219]], 'role_name': f7t5o, 'role_type': lf5zqt, 'level': v57f, 'evolution': n48$ });
}, window['$L0TD'] = function (x8n_s, ep61, iwm, v6eu, kqhaj, hltzqj, $84sd_, m3rwic, htqjz, f5o9) {
  $LHD[W[29058]] = x8n_s, $LHD[W[4645]] = ep61, $LHD[W[29059]] = iwm, L9guve61[W[29280]]($LHD[W[25214]][W[11510]], $LHD[W[25214]][W[28989]] || $LHD[W[25214]][W[11510]], x8n_s, ep61, iwm), sendApi($LHD[W[29163]], W[29279], { 'game_pkg': $LHD[W[25220]], 'server_id': $LHD[W[25214]][W[11510]], 'role_id': x8n_s, 'uid': $LHD[W[25219]], 'role_name': ep61, 'role_type': v6eu, 'level': iwm, 'evolution': kqhaj });
}, window['$L0DT'] = function (qhzja) {}, window['$LT0'] = function (ka2j) {
  L9guve61[W[29281]](W[29281], function (hzb) {
    ka2j && ka2j(hzb);
  });
}, window[W[24889]] = function () {
  L9guve61[W[24889]]();
}, window[W[29282]] = function () {
  L9guve61[W[23534]]();
}, window[W[10843]] = function (jkabzh) {
  window['$LDT0'] = jkabzh, window['$LDT0'] && window['$L0T'] && (console[W[78]](W[29147] + window['$L0T'][W[774]]), window['$LDT0'](window['$L0T']), window['$L0T'] = null);
}, window['$LD0T'] = function (ve71, kjabh2, o971f, vo7ge) {
  window[W[22]](W[29283], { 'game_pkg': window['$LHD'][W[25220]], 'role_id': kjabh2, 'server_id': o971f }, vo7ge);
}, window['$LHT0D'] = function (hlqztj, n_s4x8) {
  function mc0y(aj2dk) {
    var zqjhk = [],
        kda$2b = [],
        v1eog = window[W[555]][W[29284]];for (var xny_40 in v1eog) {
      var hak2jb = Number(xny_40);(!hlqztj || !hlqztj[W[13]] || hlqztj[W[115]](hak2jb) != -0x1) && (kda$2b[W[29]](v1eog[xny_40]), zqjhk[W[29]]([hak2jb, 0x3]));
    }window['$LB0DTH'](window[W[29068]], W[29285]) >= 0x0 ? (console[W[480]](W[29286]), L9guve61[W[29287]](kda$2b, function (ri3cm0) {
      console[W[480]](W[29288]), console[W[480]](ri3cm0);if (ri3cm0 && ri3cm0[W[25405]] == W[29289]) for (var $8bd2 in v1eog) {
        if (ri3cm0[v1eog[$8bd2]] == W[29290]) {
          var u61gv = Number($8bd2);for (var s$_d8 = 0x0; s$_d8 < zqjhk[W[13]]; s$_d8++) {
            if (zqjhk[s$_d8][0x0] == u61gv) {
              zqjhk[s$_d8][0x1] = 0x1;break;
            }
          }
        }
      }window['$LB0DTH'](window[W[29068]], W[29291]) >= 0x0 ? wx[W[29292]]({ 'withSubscriptions': !![], 'success': function (d2k) {
          var jlqkh = d2k[W[29293]][W[29294]];if (jlqkh) {
            console[W[480]](W[29295]), console[W[480]](jlqkh);for (var jkzaq in v1eog) {
              if (jlqkh[v1eog[jkzaq]] == W[29290]) {
                var bkad$ = Number(jkzaq);for (var adjb2 = 0x0; adjb2 < zqjhk[W[13]]; adjb2++) {
                  if (zqjhk[adjb2][0x0] == bkad$) {
                    zqjhk[adjb2][0x1] = 0x2;break;
                  }
                }
              }
            }console[W[480]](zqjhk), n_s4x8 && n_s4x8(zqjhk);
          } else console[W[480]](W[29296]), console[W[480]](d2k), console[W[480]](zqjhk), n_s4x8 && n_s4x8(zqjhk);
        }, 'fail': function () {
          console[W[480]](W[29297]), console[W[480]](zqjhk), n_s4x8 && n_s4x8(zqjhk);
        } }) : (console[W[480]](W[29298] + window[W[29068]]), console[W[480]](zqjhk), n_s4x8 && n_s4x8(zqjhk));
    })) : (console[W[480]](W[29299] + window[W[29068]]), console[W[480]](zqjhk), n_s4x8 && n_s4x8(zqjhk)), wx[W[29300]](mc0y);
  }wx[W[29301]](mc0y);
}, window['$LHTD0'] = { 'isSuccess': ![], 'level': W[29302], 'isCharging': ![] }, window['$LH0TD'] = function (hlqzt) {
  wx[W[29136]]({ 'success': function (kjqzl) {
      var v7o19 = window['$LHTD0'];v7o19[W[29303]] = !![], v7o19[W[4621]] = Number(kjqzl[W[4621]])[W[4233]](0x0), v7o19[W[29139]] = kjqzl[W[29139]], hlqzt && hlqzt(v7o19[W[29303]], v7o19[W[4621]], v7o19[W[29139]]);
    }, 'fail': function (s4$28d) {
      console[W[480]](W[29304], s4$28d[W[25405]]);var pgu = window['$LHTD0'];hlqzt && hlqzt(pgu[W[29303]], pgu[W[4621]], pgu[W[29139]]);
    } });
}, window[W[22]] = function (k$bad, y3xn_, ds82, v6uge, n_0xy4, ogv, yx_04n, yx04n_) {
  if (v6uge == undefined) v6uge = 0x1;wx[W[475]]({ 'url': k$bad, 'method': yx_04n || W[25108], 'responseType': W[4430], 'data': y3xn_, 'header': { 'content-type': yx04n_ || W[29198] }, 'success': function (n$84_s) {
      DEBUG && console[W[480]](W[29305], k$bad, info, n$84_s);if (n$84_s && n$84_s[W[25471]] == 0xc8) {
        var zahjq = n$84_s[W[11]];!ogv || ogv(zahjq) ? ds82 && ds82(zahjq) : window[W[29306]](k$bad, y3xn_, ds82, v6uge, n_0xy4, ogv, n$84_s);
      } else window[W[29306]](k$bad, y3xn_, ds82, v6uge, n_0xy4, ogv, n$84_s);
    }, 'fail': function (xy3n) {
      DEBUG && console[W[480]](W[29307], k$bad, info, xy3n), window[W[29306]](k$bad, y3xn_, ds82, v6uge, n_0xy4, ogv, xy3n);
    }, 'complete': function () {} });
}, window[W[29306]] = function (mwcr, l9ftq, tl5f9, f975ot, khjzlq, tjzlhq, ge6) {
  f975ot - 0x1 > 0x0 ? setTimeout(function () {
    window[W[22]](mwcr, l9ftq, tl5f9, f975ot - 0x1, khjzlq, tjzlhq);
  }, 0x3e8) : khjzlq && khjzlq(JSON[W[4510]]({ 'url': mwcr, 'response': ge6 }));
}, window[W[29308]] = function (c0rmi, rw3i, x0y_n, qzhjt, f75to, uvge1, v1of79) {
  !x0y_n && (x0y_n = {});var lzqtf5 = Math[W[118]](Date[W[83]]() / 0x3e8);x0y_n[W[849]] = lzqtf5, x0y_n[W[25029]] = rw3i;var epu6g1 = Object[W[264]](x0y_n)[W[1076]](),
      abkjh2 = '',
      zft5lq = '';for (var wmi3r = 0x0; wmi3r < epu6g1[W[13]]; wmi3r++) {
    abkjh2 = abkjh2 + (wmi3r == 0x0 ? '' : '&') + epu6g1[wmi3r] + x0y_n[epu6g1[wmi3r]], zft5lq = zft5lq + (wmi3r == 0x0 ? '' : '&') + epu6g1[wmi3r] + '=' + encodeURIComponent(x0y_n[epu6g1[wmi3r]]);
  }abkjh2 = abkjh2 + $LHD[W[29169]];var bhzk = W[29309] + md5(abkjh2);send(c0rmi + '?' + zft5lq + (zft5lq == '' ? '' : '&') + bhzk, null, qzhjt, f75to, uvge1, v1of79 || function (egpu1) {
    return egpu1[W[4118]] == W[9922];
  }, null, W[29310]);
}, window['$LH0DT'] = function (db2ja, qlt59f) {
  var cmr0y3 = 0x0;$LHD[W[25214]] && (cmr0y3 = $LHD[W[25214]][W[11510]]), sendApi($LHD[W[29165]], W[29311], { 'partnerId': $LHD[W[23641]], 'gamePkg': $LHD[W[25220]], 'logTime': Math[W[118]](Date[W[83]]() / 0x3e8), 'platformUid': $LHD[W[25221]], 'type': db2ja, 'serverId': cmr0y3 }, null, 0x2, null, function () {
    return !![];
  });
}, window['$LHDT0'] = function (bs2$a) {
  sendApi($LHD[W[29163]], W[29312], { 'partner_id': $LHD[W[23641]], 'uid': $LHD[W[25219]], 'version': $LHD[W[4716]], 'game_pkg': $LHD[W[25220]], 'device': $LHD[W[25222]] }, $LHD0T, $L0DH, $LDT);
}, window['$LHD0T'] = function (htlzq) {
  if (htlzq[W[4118]] === W[9922] && htlzq[W[11]]) {
    htlzq[W[11]][W[5598]]({ 'id': -0x2, 'name': W[29313] }), htlzq[W[11]][W[5598]]({ 'id': -0x1, 'name': W[29314] }), $LHD[W[28982]] = htlzq[W[11]];if (window[W[12290]]) window[W[12290]][W[28994]]();
  } else $LHD[W[28985]] = ![], window['$LT0HD'](W[29315] + htlzq[W[4118]]);
}, window['$LT0H'] = function (f9lto) {
  sendApi($LHD[W[29163]], W[29316], { 'partner_id': $LHD[W[23641]], 'uid': $LHD[W[25219]], 'version': $LHD[W[4716]], 'game_pkg': $LHD[W[25220]], 'device': $LHD[W[25222]] }, $LTH0, $L0DH, $LDT);
}, window['$LTH0'] = function (y_03nx) {
  $LHD[W[28997]] = ![];if (y_03nx[W[4118]] === W[9922] && y_03nx[W[11]]) {
    for (var f5o9l = 0x0; f5o9l < y_03nx[W[11]][W[13]]; f5o9l++) {
      y_03nx[W[11]][f5o9l][W[106]] = $LH0T(y_03nx[W[11]][f5o9l]);
    }$LHD[W[28995]][-0x1] = window[W[29317]](y_03nx[W[11]]), window[W[12290]][W[28996]](-0x1);
  } else window['$LT0HD'](W[29318] + y_03nx[W[4118]]);
}, window[W[29319]] = function (yrn3) {
  sendApi($LHD[W[29163]], W[29316], { 'partner_id': $LHD[W[23641]], 'uid': $LHD[W[25219]], 'version': $LHD[W[4716]], 'game_pkg': $LHD[W[25220]], 'device': $LHD[W[25222]] }, yrn3, $L0DH, $LDT);
}, window['$L0TH'] = function (d$42s8, s_x84n) {
  sendApi($LHD[W[29163]], W[29320], { 'partner_id': $LHD[W[23641]], 'uid': $LHD[W[25219]], 'version': $LHD[W[4716]], 'game_pkg': $LHD[W[25220]], 'device': $LHD[W[25222]], 'server_group_id': s_x84n }, $L0HT, $L0DH, $LDT);
}, window['$L0HT'] = function (m3yr) {
  $LHD[W[28997]] = ![];if (m3yr[W[4118]] === W[9922] && m3yr[W[11]] && m3yr[W[11]][W[11]]) {
    var tlqzj = m3yr[W[11]][W[29321]],
        ajbh2 = [];for (var uvg6e = 0x0; uvg6e < m3yr[W[11]][W[11]][W[13]]; uvg6e++) {
      m3yr[W[11]][W[11]][uvg6e][W[106]] = $LH0T(m3yr[W[11]][W[11]][uvg6e]), (ajbh2[W[13]] == 0x0 || m3yr[W[11]][W[11]][uvg6e][W[106]] != 0x0) && (ajbh2[ajbh2[W[13]]] = m3yr[W[11]][W[11]][uvg6e]);
    }$LHD[W[28995]][tlqzj] = window[W[29317]](ajbh2), window[W[12290]][W[28996]](tlqzj);
  } else window['$LT0HD'](W[29322] + m3yr[W[4118]]);
}, window['$LB0DH'] = function (ztlqh) {
  sendApi($LHD[W[29163]], W[29323], { 'partner_id': $LHD[W[23641]], 'uid': $LHD[W[25219]], 'version': $LHD[W[4716]], 'game_pkg': $LHD[W[25220]], 'device': $LHD[W[25222]] }, reqServerRecommendCallBack, $L0DH, $LDT);
}, window[W[29324]] = function (qht5l) {
  $LHD[W[28997]] = ![];if (qht5l[W[4118]] === W[9922] && qht5l[W[11]]) {
    for (var cwmri = 0x0; cwmri < qht5l[W[11]][W[13]]; cwmri++) {
      qht5l[W[11]][cwmri][W[106]] = $LH0T(qht5l[W[11]][cwmri]);
    }$LHD[W[28995]][-0x2] = window[W[29317]](qht5l[W[11]]), window[W[12290]][W[28996]](-0x2);
  } else alert(W[29325] + qht5l[W[4118]]);
}, window[W[29317]] = function (_8sd4$) {
  if (!_8sd4$ && _8sd4$[W[13]] <= 0x0) return _8sd4$;for (let f59ol = 0x0; f59ol < _8sd4$[W[13]]; f59ol++) {
    _8sd4$[f59ol][W[29326]] && _8sd4$[f59ol][W[29326]] == 0x1 && (_8sd4$[f59ol][W[28989]] += W[29327]);
  }return _8sd4$;
}, window['$LHT0'] = function (t7o95, _ny8) {
  t7o95 = t7o95 || $LHD[W[25214]][W[11510]], sendApi($LHD[W[29163]], W[29328], { 'type': '4', 'game_pkg': $LHD[W[25220]], 'server_id': t7o95 }, _ny8);
}, window[W[29329]] = function (o5f7t, wcri3m, e7gvu, kbzaj) {
  e7gvu = e7gvu || $LHD[W[25214]][W[11510]], sendApi($LHD[W[29163]], W[29330], { 'type': o5f7t, 'game_pkg': wcri3m, 'server_id': e7gvu }, kbzaj);
}, window['$LH0T'] = function (o9ve7) {
  if (o9ve7) {
    if (o9ve7[W[106]] == 0x1) {
      if (o9ve7[W[29331]] == 0x1) return 0x2;else return 0x1;
    } else return o9ve7[W[106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$LDT0H'] = function (y_4x8n, ue6) {
  $LHD[W[29332]] = { 'step': y_4x8n, 'server_id': ue6 };var y4nx_8 = this;$LTH0D({ 'title': W[29333] }), sendApi($LHD[W[29163]], W[29334], { 'partner_id': $LHD[W[23641]], 'uid': $LHD[W[25219]], 'game_pkg': $LHD[W[25220]], 'server_id': ue6, 'platform': $LHD[W[25189]], 'platform_uid': $LHD[W[25221]], 'check_login_time': $LHD[W[29242]], 'check_login_sign': $LHD[W[29241]], 'version_name': $LHD[W[29218]] }, $LDTH0, $L0DH, $LDT, function (lqtfz) {
    return lqtfz[W[4118]] == W[9922] || lqtfz[W[78]] == W[29335] || lqtfz[W[78]] == W[29336];
  });
}, window['$LDTH0'] = function (m3r0yc) {
  var uvge16 = this;if (m3r0yc[W[4118]] === W[9922] && m3r0yc[W[11]]) {
    var u6g1ev = $LHD[W[25214]];u6g1ev[W[29337]] = $LHD[W[29172]], u6g1ev[W[11493]] = String(m3r0yc[W[11]][W[29338]]), u6g1ev[W[25191]] = parseInt(m3r0yc[W[11]][W[849]]);if (m3r0yc[W[11]][W[25190]]) u6g1ev[W[25190]] = parseInt(m3r0yc[W[11]][W[25190]]);else u6g1ev[W[25190]] = parseInt(m3r0yc[W[11]][W[11510]]);u6g1ev[W[29339]] = 0x0, u6g1ev[W[4524]] = $LHD[W[29258]], u6g1ev[W[29340]] = m3r0yc[W[11]][W[29341]], u6g1ev[W[29342]] = m3r0yc[W[11]][W[29342]], console[W[480]](W[29343] + JSON[W[4510]](u6g1ev[W[29342]])), $LHD[W[628]] == 0x1 && u6g1ev[W[29342]] && u6g1ev[W[29342]][W[29344]] == 0x1 && ($LHD[W[28958]] = 0x1, window[W[29049]][W[148]]['$LBDH']()), $LD0TH();
  } else $LHD[W[29332]][W[7118]] >= 0x3 ? ($LDT(JSON[W[4510]](m3r0yc)), window['$LT0HD'](W[29345] + m3r0yc[W[4118]])) : sendApi($LHD[W[29163]], W[29227], { 'platform': $LHD[W[29161]], 'partner_id': $LHD[W[23641]], 'token': $LHD[W[29225]], 'game_pkg': $LHD[W[25220]], 'deviceId': $LHD[W[25222]], 'scene': W[29228] + $LHD[W[29171]] }, function (cwimr) {
    if (!cwimr || cwimr[W[4118]] != W[9922]) {
      window['$LT0HD'](W[29240] + cwimr && cwimr[W[4118]]);return;
    }$LHD[W[29241]] = String(cwimr[W[11493]]), $LHD[W[29242]] = String(cwimr[W[849]]), setTimeout(function () {
      $LDT0H($LHD[W[29332]][W[7118]] + 0x1, $LHD[W[29332]][W[11510]]);
    }, 0x5dc);
  }, $L0DH, $LDT, function (_4$) {
    return _4$[W[4118]] == W[9922] || _4$[W[4118]] == W[25549];
  });
}, window['$LD0TH'] = function () {
  ServerLoading[W[148]][W[29030]]($LHD[W[628]]), window['$L0D'] = !![], window['$LDHT0']();
}, window['$LD0HT'] = function () {
  if (window['$LD0'] && window['$LH0D'] && window[W[29026]] && window[W[29029]] && window['$LHD0'] && window['$LH0']) {
    if (!window[W[28445]][W[148]]) {
      console[W[480]](W[29346] + window[W[28445]][W[148]]);var lhztjq = wx[W[29347]](),
          khj2ab = lhztjq[W[774]] ? lhztjq[W[774]] : 0x0,
          _$ = { 'cdn': window['$LHD'][W[4524]], 'spareCdn': window['$LHD'][W[24905]], 'newRegister': window['$LHD'][W[628]], 'wxPC': window['$LHD'][W[24908]], 'wxIOS': window['$LHD'][W[1072]], 'wxAndroid': window['$LHD'][W[11332]], 'wxParam': { 'limitLoad': window['$LHD']['$LBT0DH'], 'benchmarkLevel': window['$LHD']['$LBTH0D'], 'wxFrom': window[W[555]][W[28724]] == W[29348] ? 0x1 : 0x0, 'wxSDKVersion': window[W[29068]] }, 'configType': window['$LHD'][W[11854]], 'exposeType': window['$LHD'][W[712]], 'scene': khj2ab };new window[W[28445]](_$, window['$LHD'][W[101]], window['$LBT0HD']);
    }
  }
}, window['$LDHT0'] = function () {
  if (window['$LD0'] && window['$LH0D'] && window[W[29026]] && window[W[29029]] && window['$LHD0'] && window['$LH0'] && window['$L0D'] && window['$L0H']) {
    $LTHD0();if (!$LD0H) {
      $LD0H = !![];if (!window[W[28445]][W[148]]) window['$LD0HT']();var ajzhk = 0x0,
          jqtzl = wx[W[29349]]();jqtzl && (window['$LHD'][W[29125]] && (ajzhk = jqtzl[W[320]]), console[W[78]](W[29350] + jqtzl[W[320]] + W[29351] + jqtzl[W[1213]] + W[29352] + jqtzl[W[1215]] + W[29353] + jqtzl[W[1214]] + W[29354] + jqtzl[W[176]] + W[29355] + jqtzl[W[177]]));var _0ynx4 = {};for (const t5f9lo in $LHD[W[25214]]) {
        _0ynx4[t5f9lo] = $LHD[W[25214]][t5f9lo];
      }var nr03yx = { 'channel': window['$LHD'][W[25218]], 'account': window['$LHD'][W[25219]], 'userId': window['$LHD'][W[23640]], 'cdn': window['$LHD'][W[4524]], 'data': window['$LHD'][W[11]], 'package': window['$LHD'][W[24906]], 'newRegister': window['$LHD'][W[628]], 'pkgName': window['$LHD'][W[25220]], 'partnerId': window['$LHD'][W[23641]], 'platform_uid': window['$LHD'][W[25221]], 'deviceId': window['$LHD'][W[25222]], 'selectedServer': _0ynx4, 'configType': window['$LHD'][W[11854]], 'exposeType': window['$LHD'][W[712]], 'debugUsers': window['$LHD'][W[12244]], 'wxMenuTop': ajzhk, 'wxShield': window['$LHD'][W[736]] };if (window[W[29260]]) for (var t5qzlh in window[W[29260]]) {
        nr03yx[t5qzlh] = window[W[29260]][t5qzlh];
      }window[W[28445]][W[148]]['$L0BHD'](nr03yx);
    }
  } else console[W[78]](W[29356] + window['$LD0'] + W[29357] + window['$LH0D'] + W[29358] + window[W[29026]] + W[29359] + window[W[29029]] + W[29360] + window['$LHD0'] + W[29361] + window['$LH0'] + W[29362] + window['$L0D'] + W[29363] + window['$L0H']);
};