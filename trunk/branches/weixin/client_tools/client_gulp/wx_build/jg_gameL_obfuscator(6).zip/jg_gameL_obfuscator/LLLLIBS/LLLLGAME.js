var W = wx.$l;
console[W[78]](W[29050]), window[W[29051]], wx[W[29052]](function (ftzq) {
  if (ftzq) {
    if (ftzq[W[4525]]) {
      var hzq5t = window[W[555]][W[29053]][W[4703]](new RegExp(/\./, 'g'), '_'),
          cwri3 = ftzq[W[4525]],
          jhkzql = cwri3[W[12054]](/(LLLLLLLL\/LLLLGAME.js:)[0-9]{1,60}(:)/g);if (jhkzql) for (var jbakd = 0x0; jbakd < jhkzql[W[13]]; jbakd++) {
        if (jhkzql[jbakd] && jhkzql[jbakd][W[13]] > 0x0) {
          var jqzthl = parseInt(jhkzql[jbakd][W[4703]](W[29054], '')[W[4703]](':', ''));cwri3 = cwri3[W[4703]](jhkzql[jbakd], jhkzql[jbakd][W[4703]](':' + jqzthl + ':', ':' + (jqzthl - 0x2) + ':'));
        }
      }cwri3 = cwri3[W[4703]](new RegExp(W[29055], 'g'), W[29056] + hzq5t + W[25319]), cwri3 = cwri3[W[4703]](new RegExp(W[29057], 'g'), W[29056] + hzq5t + W[25319]), ftzq[W[4525]] = cwri3;
    }var yn3x_ = { 'id': window['$LHD'][W[29058]], 'role': window['$LHD'][W[4645]], 'level': window['$LHD'][W[29059]], 'user': window['$LHD'][W[25219]], 'version': window['$LHD'][W[101]], 'cdn': window['$LHD'][W[4524]], 'pkgName': window['$LHD'][W[25220]], 'gamever': window[W[555]][W[29053]], 'serverid': window['$LHD'][W[25214]] ? window['$LHD'][W[25214]][W[11510]] : 0x0, 'systemInfo': window[W[29060]], 'error': W[29061], 'stack': ftzq ? ftzq[W[4525]] : '' },
        s_84n$ = JSON[W[4510]](yn3x_);console[W[125]](W[29062] + s_84n$), (!window[W[29051]] || window[W[29051]] != yn3x_[W[125]]) && (window[W[29051]] = yn3x_[W[125]], window['$LTH'](yn3x_));
  }
});import 'lllMDFIVEMIN.js';import 'lllZLIBS.js';window[W[29063]] = require(W[29064]);import 'LLLLINDEX.js';import 'llllLIBSMIN.js';import 'LLLLWXMINI.js';import 'LLLINITMIN.js';console[W[78]](W[29065]), console[W[78]](W[29066]), $LTH0D({ 'title': W[29067] });var L9ev1ug7 = { '$LBTDH0': !![] };new window[W[29049]](L9ev1ug7), window[W[29049]][W[148]]['$LB0HDT']();if (window['$LBTHD0']) clearInterval(window['$LBTHD0']);window['$LBTHD0'] = null, window['$LB0DTH'] = function (cm30ry, v1ge7u) {
  if (!cm30ry || !v1ge7u) return 0x0;cm30ry = cm30ry[W[15]]('.'), v1ge7u = v1ge7u[W[15]]('.');const sn4_8$ = Math[W[851]](cm30ry[W[13]], v1ge7u[W[13]]);while (cm30ry[W[13]] < sn4_8$) {
    cm30ry[W[29]]('0');
  }while (v1ge7u[W[13]] < sn4_8$) {
    v1ge7u[W[29]]('0');
  }for (var $sn_84 = 0x0; $sn_84 < sn4_8$; $sn_84++) {
    const yn_4x8 = parseInt(cm30ry[$sn_84]),
          ab$s2 = parseInt(v1ge7u[$sn_84]);if (yn_4x8 > ab$s2) return 0x1;else {
      if (yn_4x8 < ab$s2) return -0x1;
    }
  }return 0x0;
}, window[W[29068]] = wx[W[29069]]()[W[29068]], console[W[480]](W[29070] + window[W[29068]]);var L9hltq = wx[W[29071]]();L9hltq[W[29072]](function (ym03rc) {
  console[W[480]](W[29073] + ym03rc[W[29074]]);
}), L9hltq[W[29075]](function () {
  wx[W[29076]]({ 'title': W[29077], 'content': W[29078], 'showCancel': ![], 'success': function (k2bjad) {
      L9hltq[W[29079]]();
    } });
}), L9hltq[W[29080]](function () {
  console[W[480]](W[29081]);
}), window['$LB0DHT'] = function () {
  console[W[480]](W[29082]);var y04_ = wx[W[29083]]({ 'name': W[29084], 'success': function (f5q9lt) {
      console[W[480]](W[29085]), console[W[480]](f5q9lt), f5q9lt && f5q9lt[W[25405]] == W[29086] ? (window['$LD0'] = !![], window['$LD0HT'](), window['$LDHT0']()) : setTimeout(function () {
        window['$LB0DHT']();
      }, 0x1f4);
    }, 'fail': function (u17vge) {
      console[W[480]](W[29087]), console[W[480]](u17vge), setTimeout(function () {
        window['$LB0DHT']();
      }, 0x1f4);
    } });y04_ && y04_[W[29088]]($48s_n => {});
}, window['$LBHTD0'] = function () {
  console[W[480]](W[29089]);var eo19v = wx[W[29083]]({ 'name': W[29090], 'success': function (c3yr0x) {
      console[W[480]](W[29091]), console[W[480]](c3yr0x), c3yr0x && c3yr0x[W[25405]] == W[29086] ? (window['$LH0D'] = !![], window['$LD0HT'](), window['$LDHT0']()) : setTimeout(function () {
        window['$LBHTD0']();
      }, 0x1f4);
    }, 'fail': function (jbh2ka) {
      console[W[480]](W[29092]), console[W[480]](jbh2ka), setTimeout(function () {
        window['$LBHTD0']();
      }, 0x1f4);
    } });eo19v && eo19v[W[29088]](to95f => {});
}, window[W[29093]] = function () {
  window['$LB0DTH'](window[W[29068]], W[29094]) >= 0x0 ? (console[W[480]](W[29095] + window[W[29068]] + W[29096]), window['$LHT'](), window['$LB0DHT'](), window['$LBHTD0']()) : (window['$LHDT'](W[29097], window[W[29068]]), wx[W[29076]]({ 'title': W[6361], 'content': W[29098] }));
}, window[W[29060]] = '', wx[W[29099]]({ 'success'(d2$bsa) {
    window[W[29060]] = W[29100] + d2$bsa[W[29101]] + W[29102] + d2$bsa[W[29103]] + W[29104] + d2$bsa[W[4716]] + W[29105] + d2$bsa[W[473]] + W[29106] + d2$bsa[W[25189]] + W[29107] + d2$bsa[W[29068]] + W[29108] + d2$bsa[W[9309]], console[W[480]](window[W[29060]]), console[W[480]](W[29109] + d2$bsa[W[29110]] + W[29111] + d2$bsa[W[29112]] + W[29113] + d2$bsa[W[29114]] + W[29115] + d2$bsa[W[29116]] + W[29117] + d2$bsa[W[29118]] + W[29119] + d2$bsa[W[29120]] + W[29121] + (d2$bsa[W[29122]] ? d2$bsa[W[29122]][W[320]] + ',' + d2$bsa[W[29122]][W[1213]] + ',' + d2$bsa[W[29122]][W[1215]] + ',' + d2$bsa[W[29122]][W[1214]] : ''));var fl95q = d2$bsa[W[473]] ? d2$bsa[W[473]][W[12339]]() : '',
        _$8n4 = d2$bsa[W[29103]] ? d2$bsa[W[29103]][W[12339]]()[W[4703]]('\x20', '') : '';window['$LHD'][W[1072]] = fl95q[W[115]](W[29123]) != -0x1, window['$LHD'][W[11332]] = fl95q[W[115]](W[29124]) != -0x1, window['$LHD'][W[29125]] = fl95q[W[115]](W[29123]) != -0x1 || fl95q[W[115]](W[29124]) != -0x1, window['$LHD'][W[24908]] = fl95q[W[115]](W[29126]) != -0x1 || fl95q[W[115]](W[29127]) != -0x1, window['$LHD'][W[29128]] = d2$bsa[W[25189]] ? d2$bsa[W[25189]][W[12339]]() : '', window['$LHD']['$LBT0DH'] = ![], window['$LHD']['$LBTH0D'] = 0x2;if (fl95q[W[115]](W[29124]) != -0x1) {
      if (d2$bsa[W[9309]] >= 0x18) window['$LHD']['$LBTH0D'] = 0x3;else window['$LHD']['$LBTH0D'] = 0x2;
    } else {
      if (fl95q[W[115]](W[29123]) != -0x1) {
        if (d2$bsa[W[9309]] && d2$bsa[W[9309]] >= 0x14) window['$LHD']['$LBTH0D'] = 0x3;else {
          if (_$8n4[W[115]](W[29129]) != -0x1 || _$8n4[W[115]](W[29130]) != -0x1 || _$8n4[W[115]](W[29131]) != -0x1 || _$8n4[W[115]](W[29132]) != -0x1 || _$8n4[W[115]](W[29133]) != -0x1) window['$LHD']['$LBTH0D'] = 0x2;else window['$LHD']['$LBTH0D'] = 0x3;
        }
      } else window['$LHD']['$LBTH0D'] = 0x2;
    }console[W[480]](W[29134] + window['$LHD']['$LBT0DH'] + W[29135] + window['$LHD']['$LBTH0D']);
  } }), wx[W[29136]]({ 'success': function (jadk2) {
    console[W[480]](W[29137] + jadk2[W[4621]] + W[29138] + jadk2[W[29139]]);
  } }), wx[W[29140]]({ 'success': function (tfo957) {
    console[W[480]](W[29141] + tfo957[W[29142]]);
  } }), wx[W[29143]]({ 'keepScreenOn': !![] }), wx[W[29144]](function (e1og7v) {
  console[W[480]](W[29141] + e1og7v[W[29142]] + W[29145] + e1og7v[W[29146]]);
}), wx[W[10843]](function (yc3r0) {
  window['$L0T'] = yc3r0, window['$LDT0'] && window['$L0T'] && (console[W[78]](W[29147] + window['$L0T'][W[774]]), window['$LDT0'](window['$L0T']), window['$L0T'] = null);
}), window[W[29148]] = 0x0, window['$LBH0DT'] = 0x0, window[W[29149]] = null, wx[W[29150]](function () {
  window['$LBH0DT']++;var yn04_x = Date[W[83]]();(window[W[29148]] == 0x0 || yn04_x - window[W[29148]] > 0x1d4c0) && (console[W[96]](W[29151]), wx[W[11908]]());if (window['$LBH0DT'] >= 0x2) {
    window['$LBH0DT'] = 0x0, console[W[125]](W[29152]), wx[W[29153]]('0', 0x1);if (window['$LHD'] && window['$LHD'][W[1072]]) window['$LHDT'](W[29154], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});