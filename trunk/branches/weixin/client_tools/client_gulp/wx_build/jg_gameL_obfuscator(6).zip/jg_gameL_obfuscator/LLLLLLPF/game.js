var W = wx.$l;
require('llllllBF.js'), window[W[28446]][W[28447]][W[28448]] = null, window['client_pb'] = require('LLLCLIENTPB.js'), window[W[25360]] = window[W[28446]][W[25248]][W[25249]](client_pb);