var s = wx.$W;
import 'WWMAIW.js';