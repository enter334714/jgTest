var s = wx.$W;
require(s[0x0]);