var s = wx.$W;
import wvodh64 from '../wwawww/w7ww.js';window[s[0x1]] = { 'wxVersion': window[s[0x2]][s[0x3]] }, window[s[0x4]] = ![], window['_w1A'] = 0x1, window[s[0x5]] = 0x1, window['_wYA1'] = !![], window[s[0x6]] = !![], window['_w$IYA1'] = '', window['_wA1'] = { 'base_cdn': s[0x7], 'cdn': s[0x7] }, _wA1[s[0x8]] = {}, _wA1[s[0x9]] = '0', _wA1[s[0xa]] = window[s[0x1]][s[0xb]], _wA1[s[0xc]] = '', _wA1['os'] = '1', _wA1[s[0xd]] = s[0xe], _wA1[s[0xf]] = s[0x10], _wA1[s[0x11]] = s[0x12], _wA1[s[0x13]] = s[0x14], _wA1[s[0x15]] = s[0x16], _wA1[s[0x17]] = '1', _wA1[s[0x18]] = '', _wA1[s[0x19]] = '', _wA1[s[0x1a]] = 0x0, _wA1[s[0x1b]] = {}, _wA1[s[0x1c]] = parseInt(_wA1[s[0x17]]), _wA1[s[0x1d]] = _wA1[s[0x17]], _wA1[s[0x1e]] = {}, _wA1['_wIA'] = s[0x1f], _wA1[s[0x20]] = ![], _wA1[s[0x21]] = s[0x22], _wA1[s[0x23]] = Date[s[0x24]](), _wA1[s[0x25]] = '_weixin', _wA1[s[0x26]] = '_a', _wA1[s[0x27]] = 0x2, _wA1[s[0x28]] = 0x7c1, _wA1[s[0xb]] = window[s[0x1]][s[0xb]], _wA1[s[0x29]] = ![], _wA1[s[0x2a]] = ![], _wA1[s[0x2b]] = ![], _wA1[s[0x2c]] = ![], window['_wY1A'] = 0x5, window['_wY1'] = ![], window['_w1Y'] = ![], window['_wAY1'] = ![], window[s[0x2d]] = ![], window[s[0x2e]] = ![], window['_wA1Y'] = ![], window['_wYA'] = ![], window['_wAY'] = ![], window['_w1YA'] = ![], window[s[0x2f]] = function (i9yp0) {
  console[s[0x30]](s[0x2f], i9yp0), wx[s[0x31]]({}), wx[s[0x32]]({ 'title': s[0x33], 'content': i9yp0, 'success'(jr9_7) {
      if (jr9_7[s[0x34]]) console[s[0x30]](s[0x35]);else jr9_7[s[0x36]] && console[s[0x30]](s[0x37]);
    } });
}, window['_wIYA1'] = function (n$il) {
  console[s[0x30]](s[0x38], n$il), _wIA1Y(), wx[s[0x32]]({ 'title': s[0x33], 'content': n$il, 'confirmText': s[0x39], 'cancelText': s[0x3a], 'success'(v6xm) {
      if (v6xm[s[0x34]]) window['_wAI']();else v6xm[s[0x36]] && (console[s[0x30]](s[0x3b]), wx[s[0x3c]]({}));
    } });
}, window[s[0x3d]] = function (ec1a8k) {
  console[s[0x30]](s[0x3d], ec1a8k), wx[s[0x32]]({ 'title': s[0x33], 'content': ec1a8k, 'confirmText': s[0x3e], 'showCancel': ![], 'complete'(n9p0l) {
      console[s[0x30]](s[0x3b]), wx[s[0x3c]]({});
    } });
}, window['_wIY1A'] = ![], window['_wIAY1'] = function (i90nyp) {
  window['_wIY1A'] = !![], wx[s[0x3f]](i90nyp);
}, window['_wIA1Y'] = function () {
  window['_wIY1A'] && (window['_wIY1A'] = ![], wx[s[0x31]]({}));
}, window['_wI1YA'] = function (o6v5hd) {
  window[s[0x40]][s[0x41]]['_wI1YA'](o6v5hd);
}, window[s[0x42]] = function (c18ze3, uzw5b) {
  wvodh64[s[0x42]](c18ze3, function (rpyj9_) {
    rpyj9_ && rpyj9_[s[0x43]] ? rpyj9_[s[0x43]][s[0x44]] == 0x1 ? uzw5b(!![]) : (uzw5b(![]), console[s[0x45]](s[0x46] + rpyj9_[s[0x43]][s[0x47]])) : console[s[0x30]](s[0x42], rpyj9_);
  });
}, window['_wI1AY'] = function (w1b3zu) {
  console[s[0x30]](s[0x48], w1b3zu);
}, window['_wIA1'] = function (i9n0) {}, window['_wI1A'] = function (uz8, uwdb, _rjk) {}, window['_wI1'] = function (yp_90i) {
  console[s[0x30]](s[0x49], yp_90i), window[s[0x40]][s[0x41]][s[0x4a]](), window[s[0x40]][s[0x41]][s[0x4b]](), window[s[0x40]][s[0x41]][s[0x4c]]();
}, window['_w1I'] = function (acjr) {
  window['_wIYA1'](s[0x4d]);var e8ca = { 'id': window['_wA1'][s[0x4e]], 'role': window['_wA1'][s[0x4f]], 'level': window['_wA1'][s[0x50]], 'account': window['_wA1'][s[0x51]], 'version': window['_wA1'][s[0x28]], 'cdn': window['_wA1'][s[0x52]], 'pkgName': window['_wA1'][s[0x18]], 'gamever': window[s[0x2]][s[0x3]], 'serverid': window['_wA1'][s[0x1e]] ? window['_wA1'][s[0x1e]][s[0x53]] : 0x0, 'systemInfo': window[s[0x54]], 'error': s[0x55], 'stack': acjr ? acjr : s[0x4d] },
      d6xvh = JSON[s[0x56]](e8ca);console[s[0x57]](s[0x58] + d6xvh), window['_wIA'](d6xvh);
}, window['_wAI1'] = function (lq$s) {
  var yn90i = JSON[s[0x59]](lq$s);yn90i[s[0x5a]] = window[s[0x2]][s[0x3]], yn90i[s[0x5b]] = window['_wA1'][s[0x1e]] ? window['_wA1'][s[0x1e]][s[0x53]] : 0x0, yn90i[s[0x54]] = window[s[0x54]];var _9pyj = JSON[s[0x56]](yn90i);console[s[0x57]](s[0x5c] + _9pyj), window['_wIA'](_9pyj);
}, window['_wA1I'] = function (y_r0p, ovd56h) {
  var pi$nl0 = { 'id': window['_wA1'][s[0x4e]], 'role': window['_wA1'][s[0x4f]], 'level': window['_wA1'][s[0x50]], 'account': window['_wA1'][s[0x51]], 'version': window['_wA1'][s[0x28]], 'cdn': window['_wA1'][s[0x52]], 'pkgName': window['_wA1'][s[0x18]], 'gamever': window[s[0x2]][s[0x3]], 'serverid': window['_wA1'][s[0x1e]] ? window['_wA1'][s[0x1e]][s[0x53]] : 0x0, 'systemInfo': window[s[0x54]], 'error': y_r0p, 'stack': ovd56h },
      jy7ra_ = JSON[s[0x56]](pi$nl0);console[s[0x5d]](s[0x5e] + jy7ra_), window['_wIA'](jy7ra_);
}, window['_wIA'] = function (l$si) {
  if (window['_wA1'][s[0x5f]] == s[0x60]) return;var ra7y_j = _wA1['_wIA'] + s[0x61] + _wA1[s[0x51]];wx[s[0x62]]({ 'url': ra7y_j, 'method': s[0x63], 'data': l$si, 'header': { 'content-type': s[0x64], 'cache-control': s[0x65] }, 'success': function (wvo) {
      DEBUG && console[s[0x30]](s[0x66], ra7y_j, l$si, wvo);
    }, 'fail': function (vx6m4h) {
      DEBUG && console[s[0x30]](s[0x66], ra7y_j, l$si, vx6m4h);
    }, 'complete': function () {} });
}, window[s[0x67]] = function () {
  function r7y_9() {
    return ((0x1 + Math[s[0x68]]()) * 0x10000 | 0x0)[s[0x69]](0x10)[s[0x6a]](0x1);
  }return r7y_9() + r7y_9() + '-' + r7y_9() + '-' + r7y_9() + '-' + r7y_9() + '+' + r7y_9() + r7y_9() + r7y_9();
}, window['_wAI'] = function () {
  console[s[0x30]](s[0x6b]);var w1z3ub = wvodh64[s[0x6c]]();_wA1[s[0x1d]] = w1z3ub[s[0x6d]], _wA1[s[0x1c]] = w1z3ub[s[0x6d]], _wA1[s[0x17]] = w1z3ub[s[0x6d]], _wA1[s[0x18]] = w1z3ub[s[0x6e]];var w5o6d = { 'game_ver': _wA1[s[0xa]] };_wA1[s[0x19]] = this[s[0x67]](), _wIAY1({ 'title': s[0x6f] }), wvodh64[s[0x70]](w5o6d, this['_w1IA'][s[0x71]](this));
}, window['_w1IA'] = function (d5owv6) {
  var ec8a7 = d5owv6[s[0x72]];console[s[0x30]](s[0x73] + ec8a7 + s[0x74] + (ec8a7 == 0x1) + s[0x75] + d5owv6[s[0x3]] + s[0x76] + window[s[0x1]][s[0xb]]);if (!d5owv6[s[0x3]] || window['_w$Y1IA'](window[s[0x1]][s[0xb]], d5owv6[s[0x3]]) < 0x0) console[s[0x30]](s[0x77]), _wA1[s[0xf]] = s[0x78], _wA1[s[0x11]] = s[0x79], _wA1[s[0x13]] = s[0x7a], _wA1[s[0x52]] = s[0x7b], _wA1[s[0x7c]] = s[0x7d], _wA1[s[0x7e]] = 'xh', _wA1[s[0x29]] = ![];else window['_w$Y1IA'](window[s[0x1]][s[0xb]], d5owv6[s[0x3]]) == 0x0 ? (console[s[0x30]](s[0x7f]), _wA1[s[0xf]] = s[0x10], _wA1[s[0x11]] = s[0x12], _wA1[s[0x13]] = s[0x14], _wA1[s[0x52]] = s[0x80], _wA1[s[0x7c]] = s[0x7d], _wA1[s[0x7e]] = s[0x81], _wA1[s[0x29]] = !![]) : (console[s[0x30]](s[0x82]), _wA1[s[0xf]] = s[0x10], _wA1[s[0x11]] = s[0x12], _wA1[s[0x13]] = s[0x14], _wA1[s[0x52]] = s[0x80], _wA1[s[0x7c]] = s[0x7d], _wA1[s[0x7e]] = s[0x81], _wA1[s[0x29]] = ![]);_wA1[s[0x1a]] = config[s[0x83]] ? config[s[0x83]] : 0x0, this['_wYAI1'](), this['_wYA1I'](), window[s[0x84]] = 0x5, _wIAY1({ 'title': s[0x85] }), wvodh64[s[0x86]](this['_w1AI'][s[0x71]](this));
}, window[s[0x84]] = 0x5, window['_w1AI'] = function (_pyr, k81eca) {
  if (_pyr == 0x0 && k81eca && k81eca[s[0x87]]) {
    _wA1[s[0x88]] = k81eca[s[0x87]];var sft$ql = this;_wIAY1({ 'title': s[0x89] }), sendApi(_wA1[s[0xf]], s[0x8a], { 'platform': _wA1[s[0xd]], 'partner_id': _wA1[s[0x17]], 'token': k81eca[s[0x87]], 'game_pkg': _wA1[s[0x18]], 'deviceId': _wA1[s[0x19]], 'scene': s[0x8b] + _wA1[s[0x1a]] }, this['_wYIA1'][s[0x71]](this), _wY1A, _w1I);
  } else k81eca && k81eca[s[0x8c]] && window[s[0x84]] > 0x0 && (k81eca[s[0x8c]][s[0x8d]](s[0x8e]) != -0x1 || k81eca[s[0x8c]][s[0x8d]](s[0x8f]) != -0x1 || k81eca[s[0x8c]][s[0x8d]](s[0x90]) != -0x1 || k81eca[s[0x8c]][s[0x8d]](s[0x91]) != -0x1 || k81eca[s[0x8c]][s[0x8d]](s[0x92]) != -0x1 || k81eca[s[0x8c]][s[0x8d]](s[0x93]) != -0x1) ? (window[s[0x84]]--, wvodh64[s[0x86]](this['_w1AI'][s[0x71]](this))) : (window['_wA1I'](s[0x94], JSON[s[0x56]]({ 'status': _pyr, 'data': k81eca })), window['_wIYA1'](s[0x95] + (k81eca && k81eca[s[0x8c]] ? '，' + k81eca[s[0x8c]] : '')));
}, window['_wYIA1'] = function (a18kce) {
  if (!a18kce) {
    window['_wA1I'](s[0x96], s[0x97]), window['_wIYA1'](s[0x98]);return;
  }if (a18kce[s[0x44]] != s[0x99]) {
    window['_wA1I'](s[0x96], JSON[s[0x56]](a18kce)), window['_wIYA1'](s[0x9a] + a18kce[s[0x44]]);return;
  }_wA1[s[0x9b]] = String(a18kce[s[0x51]]), _wA1[s[0x51]] = String(a18kce[s[0x51]]), _wA1[s[0x9c]] = String(a18kce[s[0x9c]]), _wA1[s[0x1d]] = String(a18kce[s[0x9c]]), _wA1[s[0x9d]] = String(a18kce[s[0x9d]]), _wA1[s[0x9e]] = String(a18kce[s[0x9f]]), _wA1[s[0xa0]] = String(a18kce[s[0xa1]]), _wA1[s[0x9f]] = '';var pi$0nl = this;_wIAY1({ 'title': s[0xa2] }), sendApi(_wA1[s[0xf]], s[0xa3], { 'partner_id': _wA1[s[0x17]], 'uid': _wA1[s[0x51]], 'version': _wA1[s[0xa]], 'game_pkg': _wA1[s[0x18]], 'device': _wA1[s[0x19]] }, pi$0nl['_wYI1A'][s[0x71]](pi$0nl), _wY1A, _w1I);
}, window['_wYI1A'] = function (e38c1) {
  if (!e38c1) {
    window['_wIYA1'](s[0xa4]);return;
  }if (e38c1[s[0x44]] != s[0x99]) {
    window['_wIYA1'](s[0xa5] + e38c1[s[0x44]]);return;
  }if (!e38c1[s[0x43]] || e38c1[s[0x43]][s[0xa6]] == 0x0) {
    window['_wIYA1'](s[0xa7]);return;
  }_wA1[s[0xa8]] = e38c1[s[0xa9]], _wA1[s[0x1e]] = { 'server_id': String(e38c1[s[0x43]][0x0][s[0x53]]), 'server_name': String(e38c1[s[0x43]][0x0][s[0xaa]]), 'entry_ip': e38c1[s[0x43]][0x0][s[0xab]], 'entry_port': parseInt(e38c1[s[0x43]][0x0][s[0xac]]), 'status': _wAYI(e38c1[s[0x43]][0x0]), 'start_time': e38c1[s[0x43]][0x0][s[0xad]], 'cdn': _wA1[s[0x52]] }, this['_w1AYI']();
}, window['_w1AYI'] = function () {
  if (_wA1[s[0xa8]] == 0x1) {
    var r_jp = _wA1[s[0x1e]][s[0xae]];if (r_jp === -0x1 || r_jp === 0x0) {
      window['_wIYA1'](r_jp === -0x1 ? s[0xaf] : s[0xb0]);return;
    }_w1IYA(0x0, _wA1[s[0x1e]][s[0x53]]), window[s[0x40]][s[0x41]][s[0xb1]](_wA1[s[0xa8]]);
  } else window[s[0x40]][s[0x41]][s[0xb2]](), _wIA1Y();window['_wAY'] = !![], window['_w1YAI'](), window['_w1AIY']();
}, window['_wYAI1'] = function () {
  sendApi(_wA1[s[0xf]], s[0xb3], { 'game_pkg': _wA1[s[0x18]], 'version_name': _wA1[s[0x7e]] }, this[s[0xb4]][s[0x71]](this), _wY1A, _w1I);
}, window[s[0xb4]] = function ($tflq) {
  if (!$tflq) {
    window['_wIYA1'](s[0xb5]);return;
  }if ($tflq[s[0x44]] != s[0x99]) {
    window['_wIYA1'](s[0xb6] + $tflq[s[0x44]]);return;
  }if (!$tflq[s[0x43]] || !$tflq[s[0x43]][s[0xa]]) {
    window['_wIYA1'](s[0xb7] + ($tflq[s[0x43]] && $tflq[s[0x43]][s[0xa]]));return;
  }$tflq[s[0x43]][s[0xb8]] && $tflq[s[0x43]][s[0xb8]][s[0xa6]] > 0xa && (_wA1[s[0xb9]] = $tflq[s[0x43]][s[0xb8]], _wA1[s[0x52]] = $tflq[s[0x43]][s[0xb8]]), $tflq[s[0x43]][s[0xa]] && (_wA1[s[0x28]] = $tflq[s[0x43]][s[0xa]]), console[s[0x45]](s[0xba] + _wA1[s[0x28]] + s[0xbb] + _wA1[s[0x7e]]), window['_wA1Y'] = !![], window['_w1YAI'](), window['_w1AIY']();
}, window[s[0xbc]], window['_wYA1I'] = function () {
  sendApi(_wA1[s[0xf]], s[0xbd], { 'game_pkg': _wA1[s[0x18]] }, this['_wY1IA'][s[0x71]](this), _wY1A, _w1I);
}, window['_wY1IA'] = function (jr_ka) {
  if (jr_ka[s[0x44]] === s[0x99] && jr_ka[s[0x43]]) {
    window[s[0xbc]] = jr_ka[s[0x43]];for (var acjk78 in jr_ka[s[0x43]]) {
      _wA1[acjk78] = jr_ka[s[0x43]][acjk78];
    }
  } else console[s[0x45]](s[0xbe] + jr_ka[s[0x44]]);window['_wYA'] = !![], window['_w1AIY']();
}, window[s[0xbf]] = function (in90p, ke18, k18ace, y0pi9_, gvx4h, $tl, obd65w, udobw5, rj_7) {
  gvx4h = String(gvx4h);var p9inl0 = obd65w,
      d6h4o = udobw5;_wA1[s[0x8]][gvx4h] = { 'productid': gvx4h, 'productname': p9inl0, 'productdesc': d6h4o, 'roleid': in90p, 'rolename': ke18, 'rolelevel': k18ace, 'price': $tl, 'callback': rj_7 }, sendApi(_wA1[s[0x13]], s[0xc0], { 'game_pkg': _wA1[s[0x18]], 'server_id': _wA1[s[0x1e]][s[0x53]], 'server_name': _wA1[s[0x1e]][s[0xaa]], 'level': k18ace, 'uid': _wA1[s[0x51]], 'role_id': in90p, 'role_name': ke18, 'product_id': gvx4h, 'product_name': p9inl0, 'product_desc': d6h4o, 'money': $tl, 'partner_id': _wA1[s[0x17]] }, toPayCallBack, _wY1A, _w1I);
}, window[s[0xc1]] = function (l$t0) {
  if (l$t0) {
    if (l$t0[s[0xc2]] === 0xc8 || l$t0[s[0x44]] == s[0x99]) {
      var v6do5w = _wA1[s[0x8]][String(l$t0[s[0xc3]])];if (v6do5w[s[0xc4]]) v6do5w[s[0xc4]](l$t0[s[0xc3]], l$t0[s[0xc5]], -0x1);wvodh64[s[0xc6]]({ 'cpbill': l$t0[s[0xc5]], 'productid': l$t0[s[0xc3]], 'productname': v6do5w[s[0xc7]], 'productdesc': v6do5w[s[0xc8]], 'serverid': _wA1[s[0x1e]][s[0x53]], 'servername': _wA1[s[0x1e]][s[0xaa]], 'roleid': v6do5w[s[0xc9]], 'rolename': v6do5w[s[0xca]], 'rolelevel': v6do5w[s[0xcb]], 'price': v6do5w[s[0xcc]], 'extension': JSON[s[0x56]]({ 'cp_order_id': l$t0[s[0xc5]] }) }, function (_ary, rp9_y) {
        v6do5w[s[0xc4]] && _ary == 0x0 && v6do5w[s[0xc4]](l$t0[s[0xc3]], l$t0[s[0xc5]], _ary);console[s[0x45]](JSON[s[0x56]]({ 'type': s[0xcd], 'status': _ary, 'data': l$t0, 'role_name': v6do5w[s[0xca]] }));if (_ary === 0x0) {} else {
          if (_ary === 0x1) {} else {
            if (_ary === 0x2) {}
          }
        }
      });
    } else alert(l$t0[s[0x45]]);
  }
}, window['_wY1AI'] = function () {}, window['_wIY1'] = function (ka7e, ec318, z3c1e8, gmvx, od5w6b) {
  wvodh64[s[0xce]](_wA1[s[0x1e]][s[0x53]], _wA1[s[0x1e]][s[0xaa]] || _wA1[s[0x1e]][s[0x53]], ka7e, ec318, z3c1e8), sendApi(_wA1[s[0xf]], s[0xcf], { 'game_pkg': _wA1[s[0x18]], 'server_id': _wA1[s[0x1e]][s[0x53]], 'role_id': ka7e, 'uid': _wA1[s[0x51]], 'role_name': ec318, 'role_type': gmvx, 'level': z3c1e8 });
}, window['_wI1Y'] = function (tl$nsq, duob5w, o4vhd, dho6v, i_y90, d46hvo, t$f2, nli$p, wu35z, y09_r) {
  _wA1[s[0x4e]] = tl$nsq, _wA1[s[0x4f]] = duob5w, _wA1[s[0x50]] = o4vhd, wvodh64[s[0xd0]](_wA1[s[0x1e]][s[0x53]], _wA1[s[0x1e]][s[0xaa]] || _wA1[s[0x1e]][s[0x53]], tl$nsq, duob5w, o4vhd), sendApi(_wA1[s[0xf]], s[0xd1], { 'game_pkg': _wA1[s[0x18]], 'server_id': _wA1[s[0x1e]][s[0x53]], 'role_id': tl$nsq, 'uid': _wA1[s[0x51]], 'role_name': duob5w, 'role_type': dho6v, 'level': o4vhd, 'evolution': i_y90 });
}, window['_wYI1'] = function (mx4h6, bze31, ni$l, ubw5, u8ez, j_rp9, ryj_97, e1zub3, ce1zk8, $0n) {
  _wA1[s[0x4e]] = mx4h6, _wA1[s[0x4f]] = bze31, _wA1[s[0x50]] = ni$l, wvodh64[s[0xd2]](_wA1[s[0x1e]][s[0x53]], _wA1[s[0x1e]][s[0xaa]] || _wA1[s[0x1e]][s[0x53]], mx4h6, bze31, ni$l), sendApi(_wA1[s[0xf]], s[0xd1], { 'game_pkg': _wA1[s[0x18]], 'server_id': _wA1[s[0x1e]][s[0x53]], 'role_id': mx4h6, 'uid': _wA1[s[0x51]], 'role_name': bze31, 'role_type': ubw5, 'level': ni$l, 'evolution': u8ez });
}, window['_wY1I'] = function (lftqs$) {}, window['_wIY'] = function (wdbo56) {
  wvodh64[s[0xd3]](s[0xd3], function (lnip09) {
    wdbo56 && wdbo56(lnip09);
  });
}, window[s[0xd4]] = function () {
  wvodh64[s[0xd4]]();
}, window[s[0xd5]] = function () {
  wvodh64[s[0xd6]]();
}, window[s[0xd7]] = function (ka87ce, p$ln, $0pin, dw, o65bd, xh6vm4, d4hx6v, ac1k) {
  ac1k = ac1k || _wA1[s[0x1e]][s[0x53]], sendApi(_wA1[s[0xf]], s[0xd8], { 'phone': ka87ce, 'role_id': p$ln, 'uid': _wA1[s[0x51]], 'game_pkg': _wA1[s[0x18]], 'partner_id': _wA1[s[0x17]], 'server_id': ac1k }, d4hx6v);
}, window[s[0xd9]] = function (st$lqf) {
  window['_w1IY'] = st$lqf, window['_w1IY'] && window['_wYI'] && (console[s[0x45]](s[0xda] + window['_wYI'][s[0xdb]]), window['_w1IY'](window['_wYI']), window['_wYI'] = null);
}, window['_w1YI'] = function (ltsq, ypi90_, n0lp9i, h4vx6d) {
  window[s[0xdc]](s[0xdd], { 'game_pkg': window['_wA1'][s[0x18]], 'role_id': ypi90_, 'server_id': n0lp9i }, h4vx6d);
}, window['_wAIY1'] = function (sqt$f2, gvmxh4) {
  function nqt$sl(tn$l0i) {
    var tf$s2 = [],
        bo65w = [],
        lstnq = window[s[0x2]][s[0xde]];for (var np0il9 in lstnq) {
      var a_kj = Number(np0il9);(!sqt$f2 || !sqt$f2[s[0xa6]] || sqt$f2[s[0x8d]](a_kj) != -0x1) && (bo65w[s[0xdf]](lstnq[np0il9]), tf$s2[s[0xdf]]([a_kj, 0x3]));
    }window['_w$Y1IA'](window[s[0xe0]], s[0xe1]) >= 0x0 ? (console[s[0x30]](s[0xe2]), wvodh64[s[0xe3]] && wvodh64[s[0xe3]](bo65w, function (ue1z38) {
      console[s[0x30]](s[0xe4]), console[s[0x30]](ue1z38);if (ue1z38 && ue1z38[s[0x8c]] == s[0xe5]) for (var ajk7c in lstnq) {
        if (ue1z38[lstnq[ajk7c]] == s[0xe6]) {
          var kcaj = Number(ajk7c);for (var ow3ub = 0x0; ow3ub < tf$s2[s[0xa6]]; ow3ub++) {
            if (tf$s2[ow3ub][0x0] == kcaj) {
              tf$s2[ow3ub][0x1] = 0x1;break;
            }
          }
        }
      }window['_w$Y1IA'](window[s[0xe0]], s[0xe7]) >= 0x0 ? wx[s[0xe8]]({ 'withSubscriptions': !![], 'success': function (b3z5) {
          var v5d6wo = b3z5[s[0xe9]][s[0xea]];if (v5d6wo) {
            console[s[0x30]](s[0xeb]), console[s[0x30]](v5d6wo);for (var yja_7 in lstnq) {
              if (v5d6wo[lstnq[yja_7]] == s[0xe6]) {
                var zw = Number(yja_7);for (var _r7ayj = 0x0; _r7ayj < tf$s2[s[0xa6]]; _r7ayj++) {
                  if (tf$s2[_r7ayj][0x0] == zw) {
                    tf$s2[_r7ayj][0x1] = 0x2;break;
                  }
                }
              }
            }console[s[0x30]](tf$s2), gvmxh4 && gvmxh4(tf$s2);
          } else console[s[0x30]](s[0xec]), console[s[0x30]](b3z5), console[s[0x30]](tf$s2), gvmxh4 && gvmxh4(tf$s2);
        }, 'fail': function () {
          console[s[0x30]](s[0xed]), console[s[0x30]](tf$s2), gvmxh4 && gvmxh4(tf$s2);
        } }) : (console[s[0x30]](s[0xee] + window[s[0xe0]]), console[s[0x30]](tf$s2), gvmxh4 && gvmxh4(tf$s2));
    })) : (console[s[0x30]](s[0xef] + window[s[0xe0]]), console[s[0x30]](tf$s2), gvmxh4 && gvmxh4(tf$s2)), wx[s[0xf0]](nqt$sl);
  }wx[s[0xf1]](nqt$sl);
}, window['_wAI1Y'] = { 'isSuccess': ![], 'level': s[0xf2], 'isCharging': ![] }, window['_wAYI1'] = function (til$) {
  wx[s[0xf3]]({ 'success': function (w56obd) {
      var ou3bw = window['_wAI1Y'];ou3bw[s[0xf4]] = !![], ou3bw[s[0xf5]] = Number(w56obd[s[0xf5]])[s[0xf6]](0x0), ou3bw[s[0xf7]] = w56obd[s[0xf7]], til$ && til$(ou3bw[s[0xf4]], ou3bw[s[0xf5]], ou3bw[s[0xf7]]);
    }, 'fail': function (y97rj_) {
      console[s[0x30]](s[0xf8], y97rj_[s[0x8c]]);var tf$lqs = window['_wAI1Y'];til$ && til$(tf$lqs[s[0xf4]], tf$lqs[s[0xf5]], tf$lqs[s[0xf7]]);
    } });
}, window[s[0xdc]] = function (eb13zu, wob5, w3b5, o6vh5, w1z, $qtfl, tl$fsq, ub31wz) {
  if (o6vh5 == undefined) o6vh5 = 0x1;wx[s[0x62]]({ 'url': eb13zu, 'method': tl$fsq || s[0xf9], 'responseType': s[0xfa], 'data': wob5, 'header': { 'content-type': ub31wz || s[0x64] }, 'success': function (jya) {
      DEBUG && console[s[0x30]](s[0xfb], eb13zu, info, jya);if (jya && jya[s[0xfc]] == 0xc8) {
        var u1w3bz = jya[s[0x43]];!$qtfl || $qtfl(u1w3bz) ? w3b5 && w3b5(u1w3bz) : window[s[0xfd]](eb13zu, wob5, w3b5, o6vh5, w1z, $qtfl, jya);
      } else window[s[0xfd]](eb13zu, wob5, w3b5, o6vh5, w1z, $qtfl, jya);
    }, 'fail': function (w6dov) {
      DEBUG && console[s[0x30]](s[0xfe], eb13zu, info, w6dov), window[s[0xfd]](eb13zu, wob5, w3b5, o6vh5, w1z, $qtfl, w6dov);
    }, 'complete': function () {} });
}, window[s[0xfd]] = function (dbwu5o, wv5d6, ni9l0, hx4dv, tsq2, akrj7_, tfs$) {
  hx4dv - 0x1 > 0x0 ? setTimeout(function () {
    window[s[0xdc]](dbwu5o, wv5d6, ni9l0, hx4dv - 0x1, tsq2, akrj7_);
  }, 0x3e8) : tsq2 && tsq2(JSON[s[0x56]]({ 'url': dbwu5o, 'response': tfs$ }));
}, window[s[0xff]] = function (p_r9j, i0$l, ec18ka, xm4gvh, r_7a, uez3, l09nip) {
  !ec18ka && (ec18ka = {});var _y9p0 = Math[s[0x100]](Date[s[0x24]]() / 0x3e8);ec18ka[s[0xa1]] = _y9p0, ec18ka[s[0x101]] = i0$l;var duow5 = Object[s[0x102]](ec18ka)[s[0x103]](),
      y97jr = '',
      ypjr = '';for (var b1z3uw = 0x0; b1z3uw < duow5[s[0xa6]]; b1z3uw++) {
    y97jr = y97jr + (b1z3uw == 0x0 ? '' : '&') + duow5[b1z3uw] + ec18ka[duow5[b1z3uw]], ypjr = ypjr + (b1z3uw == 0x0 ? '' : '&') + duow5[b1z3uw] + '=' + encodeURIComponent(ec18ka[duow5[b1z3uw]]);
  }y97jr = y97jr + _wA1[s[0x15]];var vhxgm = s[0x104] + md5(y97jr);send(p_r9j + '?' + ypjr + (ypjr == '' ? '' : '&') + vhxgm, null, xm4gvh, r_7a, uez3, l09nip || function (db6w5o) {
    return db6w5o[s[0x44]] == s[0x99];
  }, null, s[0x105]);
}, window['_wAY1I'] = function (n$i0lt, vwdo5) {
  var a7k8j = 0x0;_wA1[s[0x1e]] && (a7k8j = _wA1[s[0x1e]][s[0x53]]), sendApi(_wA1[s[0x11]], s[0x106], { 'partnerId': _wA1[s[0x17]], 'gamePkg': _wA1[s[0x18]], 'logTime': Math[s[0x100]](Date[s[0x24]]() / 0x3e8), 'platformUid': _wA1[s[0x9d]], 'type': n$i0lt, 'serverId': a7k8j }, null, 0x2, null, function () {
    return !![];
  });
}, window['_wA1IY'] = function (zeub31) {
  sendApi(_wA1[s[0xf]], s[0x107], { 'partner_id': _wA1[s[0x17]], 'uid': _wA1[s[0x51]], 'version': _wA1[s[0xa]], 'game_pkg': _wA1[s[0x18]], 'device': _wA1[s[0x19]] }, _wA1YI, _wY1A, _w1I);
}, window['_wA1YI'] = function (lsqtn$) {
  if (lsqtn$[s[0x44]] === s[0x99] && lsqtn$[s[0x43]]) {
    lsqtn$[s[0x43]][s[0x108]]({ 'id': -0x2, 'name': s[0x109] }), lsqtn$[s[0x43]][s[0x108]]({ 'id': -0x1, 'name': s[0x10a] }), _wA1[s[0x10b]] = lsqtn$[s[0x43]];if (window[s[0x10c]]) window[s[0x10c]][s[0x10d]]();
  } else _wA1[s[0x10e]] = ![], window['_wIYA1'](s[0x10f] + lsqtn$[s[0x44]]);
}, window['_wIYA'] = function (uzeb1) {
  sendApi(_wA1[s[0xf]], s[0x110], { 'partner_id': _wA1[s[0x17]], 'uid': _wA1[s[0x51]], 'version': _wA1[s[0xa]], 'game_pkg': _wA1[s[0x18]], 'device': _wA1[s[0x19]] }, _wIAY, _wY1A, _w1I);
}, window['_wIAY'] = function (e3c18z) {
  _wA1[s[0x111]] = ![];if (e3c18z[s[0x44]] === s[0x99] && e3c18z[s[0x43]]) {
    for (var ltn0 = 0x0; ltn0 < e3c18z[s[0x43]][s[0xa6]]; ltn0++) {
      e3c18z[s[0x43]][ltn0][s[0xae]] = _wAYI(e3c18z[s[0x43]][ltn0]);
    }_wA1[s[0x1b]][-0x1] = window[s[0x112]](e3c18z[s[0x43]]), window[s[0x10c]][s[0x113]](-0x1);
  } else window['_wIYA1'](s[0x114] + e3c18z[s[0x44]]);
}, window[s[0x115]] = function ($lip) {
  sendApi(_wA1[s[0xf]], s[0x110], { 'partner_id': _wA1[s[0x17]], 'uid': _wA1[s[0x51]], 'version': _wA1[s[0xa]], 'game_pkg': _wA1[s[0x18]], 'device': _wA1[s[0x19]] }, $lip, _wY1A, _w1I);
}, window['_wYIA'] = function (dw6v5o, wvdo56) {
  sendApi(_wA1[s[0xf]], s[0x116], { 'partner_id': _wA1[s[0x17]], 'uid': _wA1[s[0x51]], 'version': _wA1[s[0xa]], 'game_pkg': _wA1[s[0x18]], 'device': _wA1[s[0x19]], 'server_group_id': wvdo56 }, _wYAI, _wY1A, _w1I);
}, window['_wYAI'] = function ($t0lin) {
  _wA1[s[0x111]] = ![];if ($t0lin[s[0x44]] === s[0x99] && $t0lin[s[0x43]] && $t0lin[s[0x43]][s[0x43]]) {
    var $f2qt = $t0lin[s[0x43]][s[0x117]],
        bwo6d5 = [];for (var _9yjr = 0x0; _9yjr < $t0lin[s[0x43]][s[0x43]][s[0xa6]]; _9yjr++) {
      $t0lin[s[0x43]][s[0x43]][_9yjr][s[0xae]] = _wAYI($t0lin[s[0x43]][s[0x43]][_9yjr]), (bwo6d5[s[0xa6]] == 0x0 || $t0lin[s[0x43]][s[0x43]][_9yjr][s[0xae]] != 0x0) && (bwo6d5[bwo6d5[s[0xa6]]] = $t0lin[s[0x43]][s[0x43]][_9yjr]);
    }_wA1[s[0x1b]][$f2qt] = window[s[0x112]](bwo6d5), window[s[0x10c]][s[0x113]]($f2qt);
  } else window['_wIYA1'](s[0x118] + $t0lin[s[0x44]]);
}, window['_w$Y1A'] = function (yrj_7) {
  sendApi(_wA1[s[0xf]], s[0x119], { 'partner_id': _wA1[s[0x17]], 'uid': _wA1[s[0x51]], 'version': _wA1[s[0xa]], 'game_pkg': _wA1[s[0x18]], 'device': _wA1[s[0x19]] }, reqServerRecommendCallBack, _wY1A, _w1I);
}, window[s[0x11a]] = function (i$slnt) {
  _wA1[s[0x111]] = ![];if (i$slnt[s[0x44]] === s[0x99] && i$slnt[s[0x43]]) {
    for (var lqn$s = 0x0; lqn$s < i$slnt[s[0x43]][s[0xa6]]; lqn$s++) {
      i$slnt[s[0x43]][lqn$s][s[0xae]] = _wAYI(i$slnt[s[0x43]][lqn$s]);
    }_wA1[s[0x1b]][-0x2] = window[s[0x112]](i$slnt[s[0x43]]), window[s[0x10c]][s[0x113]](-0x2);
  } else alert(s[0x11b] + i$slnt[s[0x44]]);
}, window[s[0x112]] = function (y9n) {
  if (!y9n && y9n[s[0xa6]] <= 0x0) return y9n;for (let h4mx6 = 0x0; h4mx6 < y9n[s[0xa6]]; h4mx6++) {
    y9n[h4mx6][s[0x11c]] && y9n[h4mx6][s[0x11c]] == 0x1 && (y9n[h4mx6][s[0xaa]] += s[0x11d]);
  }return y9n;
}, window['_wAIY'] = function (kj_r, inlts) {
  kj_r = kj_r || _wA1[s[0x1e]][s[0x53]], sendApi(_wA1[s[0xf]], s[0x11e], { 'type': '4', 'game_pkg': _wA1[s[0x18]], 'server_id': kj_r }, inlts);
}, window[s[0x11f]] = function (y7ja, wu3bz, _jakr, jka7r) {
  _jakr = _jakr || _wA1[s[0x1e]][s[0x53]], sendApi(_wA1[s[0xf]], s[0x120], { 'type': y7ja, 'game_pkg': wu3bz, 'server_id': _jakr }, jka7r);
}, window['_wAYI'] = function (b3ow) {
  if (b3ow) {
    if (b3ow[s[0xae]] == 0x1) {
      if (b3ow[s[0x121]] == 0x1) return 0x2;else return 0x1;
    } else return b3ow[s[0xae]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_w1IYA'] = function (_yi9p0, a8kc) {
  _wA1[s[0x122]] = { 'step': _yi9p0, 'server_id': a8kc };var r7ak_ = this;_wIAY1({ 'title': s[0x123] }), sendApi(_wA1[s[0xf]], s[0x124], { 'partner_id': _wA1[s[0x17]], 'uid': _wA1[s[0x51]], 'game_pkg': _wA1[s[0x18]], 'server_id': a8kc, 'platform': _wA1[s[0x9c]], 'platform_uid': _wA1[s[0x9d]], 'check_login_time': _wA1[s[0xa0]], 'check_login_sign': _wA1[s[0x9e]], 'version_name': _wA1[s[0x7e]] }, _w1IAY, _wY1A, _w1I, function (y9pi) {
    return y9pi[s[0x44]] == s[0x99] || y9pi[s[0x45]] == s[0x125] || y9pi[s[0x45]] == s[0x126];
  });
}, window['_w1IAY'] = function (_y90) {
  var uzb3e = this;if (_y90[s[0x44]] === s[0x99] && _y90[s[0x43]]) {
    var p9ln0 = _wA1[s[0x1e]];p9ln0[s[0x127]] = _wA1[s[0x1c]], p9ln0[s[0x9f]] = String(_y90[s[0x43]][s[0x128]]), p9ln0[s[0x23]] = parseInt(_y90[s[0x43]][s[0xa1]]);if (_y90[s[0x43]][s[0x129]]) p9ln0[s[0x129]] = parseInt(_y90[s[0x43]][s[0x129]]);else p9ln0[s[0x129]] = parseInt(_y90[s[0x43]][s[0x53]]);p9ln0[s[0x12a]] = 0x0, p9ln0[s[0x52]] = _wA1[s[0xb9]], p9ln0[s[0x12b]] = _y90[s[0x43]][s[0x12c]], p9ln0[s[0x12d]] = _y90[s[0x43]][s[0x12d]], console[s[0x30]](s[0x12e] + JSON[s[0x56]](p9ln0[s[0x12d]])), _wA1[s[0xa8]] == 0x1 && p9ln0[s[0x12d]] && p9ln0[s[0x12d]][s[0x12f]] == 0x1 && (_wA1[s[0x130]] = 0x1, window[s[0x40]][s[0x41]]['_w$1A']()), _w1YIA();
  } else _wA1[s[0x122]][s[0x131]] >= 0x3 ? (_w1I(JSON[s[0x56]](_y90)), window['_wIYA1'](s[0x132] + _y90[s[0x44]])) : sendApi(_wA1[s[0xf]], s[0x8a], { 'platform': _wA1[s[0xd]], 'partner_id': _wA1[s[0x17]], 'token': _wA1[s[0x88]], 'game_pkg': _wA1[s[0x18]], 'deviceId': _wA1[s[0x19]], 'scene': s[0x8b] + _wA1[s[0x1a]] }, function (jk7_ar) {
    if (!jk7_ar || jk7_ar[s[0x44]] != s[0x99]) {
      window['_wIYA1'](s[0x9a] + jk7_ar && jk7_ar[s[0x44]]);return;
    }_wA1[s[0x9e]] = String(jk7_ar[s[0x9f]]), _wA1[s[0xa0]] = String(jk7_ar[s[0xa1]]), setTimeout(function () {
      _w1IYA(_wA1[s[0x122]][s[0x131]] + 0x1, _wA1[s[0x122]][s[0x53]]);
    }, 0x5dc);
  }, _wY1A, _w1I, function (ni0yp) {
    return ni0yp[s[0x44]] == s[0x99] || ni0yp[s[0x44]] == s[0x133];
  });
}, window['_w1YIA'] = function () {
  ServerLoading[s[0x41]][s[0xb1]](_wA1[s[0xa8]]), window['_wY1'] = !![], window['_w1AIY']();
}, window['_w1YAI'] = function () {
  if (window['_w1Y'] && window['_wAY1'] && window[s[0x2d]] && window[s[0x2e]] && window['_wA1Y'] && window['_wAY']) {
    if (!window[s[0x134]][s[0x41]]) {
      console[s[0x30]](s[0x135] + window[s[0x134]][s[0x41]]);var yr_j9p = wx[s[0x136]](),
          xv46mh = yr_j9p[s[0xdb]] ? yr_j9p[s[0xdb]] : 0x0,
          ub3w5 = { 'cdn': window['_wA1'][s[0x52]], 'spareCdn': window['_wA1'][s[0x7c]], 'newRegister': window['_wA1'][s[0xa8]], 'wxPC': window['_wA1'][s[0x2c]], 'wxIOS': window['_wA1'][s[0x2a]], 'wxAndroid': window['_wA1'][s[0x2b]], 'wxParam': { 'limitLoad': window['_wA1']['_w$IY1A'], 'benchmarkLevel': window['_wA1']['_w$IAY1'], 'wxFrom': window[s[0x2]][s[0x83]] == s[0x137] ? 0x1 : 0x0, 'wxSDKVersion': window[s[0xe0]] }, 'configType': window['_wA1'][s[0x25]], 'exposeType': window['_wA1'][s[0x26]], 'scene': xv46mh };new window[s[0x134]](ub3w5, window['_wA1'][s[0x28]], window['_w$IYA1']);
    }
  }
}, window['_w1AIY'] = function () {
  if (window['_w1Y'] && window['_wAY1'] && window[s[0x2d]] && window[s[0x2e]] && window['_wA1Y'] && window['_wAY'] && window['_wY1'] && window['_wYA']) {
    _wIA1Y();if (!_w1YA) {
      _w1YA = !![];if (!window[s[0x134]][s[0x41]]) window['_w1YAI']();var zc1ke8 = 0x0,
          c81zek = wx[s[0x138]]();c81zek && (window['_wA1'][s[0x139]] && (zc1ke8 = c81zek[s[0x13a]]), console[s[0x45]](s[0x13b] + c81zek[s[0x13a]] + s[0x13c] + c81zek[s[0x13d]] + s[0x13e] + c81zek[s[0x13f]] + s[0x140] + c81zek[s[0x141]] + s[0x142] + c81zek[s[0x143]] + s[0x144] + c81zek[s[0x145]]));var j_rpy9 = {};for (const sln$tq in _wA1[s[0x1e]]) {
        j_rpy9[sln$tq] = _wA1[s[0x1e]][sln$tq];
      }var uwo53b = { 'channel': window['_wA1'][s[0x1d]], 'account': window['_wA1'][s[0x51]], 'userId': window['_wA1'][s[0x9b]], 'cdn': window['_wA1'][s[0x52]], 'data': window['_wA1'][s[0x43]], 'package': window['_wA1'][s[0x9]], 'newRegister': window['_wA1'][s[0xa8]], 'pkgName': window['_wA1'][s[0x18]], 'partnerId': window['_wA1'][s[0x17]], 'platform_uid': window['_wA1'][s[0x9d]], 'deviceId': window['_wA1'][s[0x19]], 'selectedServer': j_rpy9, 'configType': window['_wA1'][s[0x25]], 'exposeType': window['_wA1'][s[0x26]], 'debugUsers': window['_wA1'][s[0x21]], 'wxMenuTop': zc1ke8, 'wxShield': window['_wA1'][s[0x29]] };if (window[s[0xbc]]) for (var ec8ak1 in window[s[0xbc]]) {
        uwo53b[ec8ak1] = window[s[0xbc]][ec8ak1];
      }window[s[0x134]][s[0x41]]['_w1A$'](uwo53b), setTimeout(() => {
        wvodh64[s[0x146]]();
      }, 0x2710);
    }
  } else console[s[0x45]](s[0x147] + window['_w1Y'] + s[0x148] + window['_wAY1'] + s[0x149] + window[s[0x2d]] + s[0x14a] + window[s[0x2e]] + s[0x14b] + window['_wA1Y'] + s[0x14c] + window['_wAY'] + s[0x14d] + window['_wY1'] + s[0x14e] + window['_wYA']);
};