var s = wx.$W;
require('wBFww.js'), window[s[0x336]][s[0x337]][s[0x338]] = null, window['client_pb'] = require('wwCLIENw.js'), window[s[0x339]] = window[s[0x336]][s[0x33a]][s[0x33b]](client_pb);