var U = wx.$k;
console[U[140657]](U[169515]), window[U[169516]], wx[U[169517]](function (q209s8) {
  if (q209s8) {
    if (q209s8[U[140129]]) {
      var pg3fr5 = window[U[141092]][U[169090]][U[140258]](new RegExp(/\./, 'g'), '_'),
          alzubx = q209s8[U[140129]],
          v0qon = alzubx[U[140136]](/(kkkkkkkkkk\/kkkkGAME.js:)[0-9]{1,60}(:)/g);if (v0qon) for (var sk9h6e = 0x0; sk9h6e < v0qon[U[140113]]; sk9h6e++) {
        if (v0qon[sk9h6e] && v0qon[sk9h6e][U[140113]] > 0x0) {
          var s90q28 = parseInt(v0qon[sk9h6e][U[140258]](U[169518], '')[U[140258]](':', ''));alzubx = alzubx[U[140258]](v0qon[sk9h6e], v0qon[sk9h6e][U[140258]](':' + s90q28 + ':', ':' + (s90q28 - 0x2) + ':'));
        }
      }alzubx = alzubx[U[140258]](new RegExp(U[169519], 'g'), U[169520] + pg3fr5 + U[165936]), alzubx = alzubx[U[140258]](new RegExp(U[169521], 'g'), U[169520] + pg3fr5 + U[165936]), q209s8[U[140129]] = alzubx;
    }var q0n8v1 = { 'id': window['$KE2'][U[169136]], 'role': window['$KE2'][U[145193]], 'level': window['$KE2'][U[169137]], 'user': window['$KE2'][U[165838]], 'version': window['$KE2'][U[140675]], 'cdn': window['$KE2'][U[145073]], 'pkgName': window['$KE2'][U[165839]], 'gamever': window[U[141092]][U[169090]], 'serverid': window['$KE2'][U[165833]] ? window['$KE2'][U[165833]][U[140066]] : 0x0, 'systemInfo': window[U[169138]], 'error': U[169522], 'stack': q209s8 ? q209s8[U[140129]] : '' },
        bozxw = JSON[U[145059]](q0n8v1);console[U[140291]](U[169523] + bozxw), (!window[U[169516]] || window[U[169516]] != q0n8v1[U[140291]]) && (window[U[169516]] = q0n8v1[U[140291]], window['$KPE'](q0n8v1));
  }
});import 'kkkMDFIVEMIN.js';import 'kkkZLIBS.js';window[U[169524]] = require(U[169525]);import 'kkkINDEX.js';import 'KKKLIBSMIN.js';import 'kkkWXMINI.js';import 'kkkINITMIN.js';console[U[140657]](U[169526]), console[U[140657]](U[169527]), $KPE72({ 'title': U[169528] });var K1_udlr_ = { '$KTP2E7': !![] };new window[U[169126]](K1_udlr_), window[U[169126]][U[140711]]['$KT7E2P']();if (window['$KTPE27']) clearInterval(window['$KTPE27']);window['$KTPE27'] = null, window['$KT72PE'] = function (i7jtm4, r_lud) {
  if (!i7jtm4 || !r_lud) return 0x0;i7jtm4 = i7jtm4[U[140236]]('.'), r_lud = r_lud[U[140236]]('.');const h9e6sk = Math[U[140283]](i7jtm4[U[140113]], r_lud[U[140113]]);while (i7jtm4[U[140113]] < h9e6sk) {
    i7jtm4[U[140135]]('0');
  }while (r_lud[U[140113]] < h9e6sk) {
    r_lud[U[140135]]('0');
  }for (var g3fpc5 = 0x0; g3fpc5 < h9e6sk; g3fpc5++) {
    const u$dxl = parseInt(i7jtm4[g3fpc5]),
          g3ycf = parseInt(r_lud[g3fpc5]);if (u$dxl > g3ycf) return 0x1;else {
      if (u$dxl < g3ycf) return -0x1;
    }
  }return 0x0;
}, window[U[169236]] = wx[U[169529]]()[U[169236]], console[U[140248]](U[169530] + window[U[169236]]);var K1_sq920 = wx[U[169531]]();K1_sq920[U[169532]](function (sh2k6) {
  console[U[140248]](U[169533] + sh2k6[U[169534]]);
}), K1_sq920[U[169535]](function () {
  wx[U[169118]]({ 'title': U[169536], 'content': U[169537], 'showCancel': ![], 'success': function (eski) {
      K1_sq920[U[169538]]();
    } });
}), K1_sq920[U[169539]](function () {
  console[U[140248]](U[169540]);
}), window['$KT72EP'] = function () {
  console[U[140248]](U[169541]);var hk629 = wx[U[169542]]({ 'name': U[169543], 'success': function (xvoz) {
      console[U[140248]](U[169544]), console[U[140248]](xvoz), xvoz && xvoz[U[166018]] == U[169545] ? (window['$K27'] = !![], window['$K27EP'](), window['$K2EP7']()) : setTimeout(function () {
        window['$KT72EP']();
      }, 0x1f4);
    }, 'fail': function (bzvxow) {
      console[U[140248]](U[169546]), console[U[140248]](bzvxow), setTimeout(function () {
        window['$KT72EP']();
      }, 0x1f4);
    } });hk629 && hk629[U[169547]](au$z => {});
}, window['$KTEP27'] = function () {
  console[U[140248]](U[169548]);var nvowb = wx[U[169542]]({ 'name': U[169549], 'success': function (fcg53p) {
      console[U[140248]](U[169550]), console[U[140248]](fcg53p), fcg53p && fcg53p[U[166018]] == U[169545] ? (window['$KE72'] = !![], window['$K27EP'](), window['$K2EP7']()) : setTimeout(function () {
        window['$KTEP27']();
      }, 0x1f4);
    }, 'fail': function (r3p5fg) {
      console[U[140248]](U[169551]), console[U[140248]](r3p5fg), setTimeout(function () {
        window['$KTEP27']();
      }, 0x1f4);
    } });nvowb && nvowb[U[169547]](xuzbl => {});
}, window[U[169552]] = function () {
  window['$KT72PE'](window[U[169236]], U[169553]) >= 0x0 ? (console[U[140248]](U[169554] + window[U[169236]] + U[169555]), window['$KEP'](), window['$KT72EP'](), window['$KTEP27']()) : (window['$KE2P'](U[169556], window[U[169236]]), wx[U[169118]]({ 'title': U[146905], 'content': U[169557] }));
}, window[U[169138]] = '', wx[U[169558]]({ 'success'(zboxwa) {
    window[U[169138]] = U[169559] + zboxwa[U[169560]] + U[169561] + zboxwa[U[169562]] + U[169563] + zboxwa[U[145263]] + U[169564] + zboxwa[U[141015]] + U[169565] + zboxwa[U[165810]] + U[169566] + zboxwa[U[169236]] + U[169567] + zboxwa[U[149856]], console[U[140248]](window[U[169138]]), console[U[140248]](U[169568] + zboxwa[U[169569]] + U[169570] + zboxwa[U[169571]] + U[169572] + zboxwa[U[169573]] + U[169574] + zboxwa[U[169575]] + U[169576] + zboxwa[U[169577]] + U[169578] + zboxwa[U[169579]] + U[169580] + (zboxwa[U[169581]] ? zboxwa[U[169581]][U[140868]] + ',' + zboxwa[U[169581]][U[141744]] + ',' + zboxwa[U[169581]][U[141746]] + ',' + zboxwa[U[169581]][U[141745]] : ''));var url$ = zboxwa[U[141015]] ? zboxwa[U[141015]][U[140161]]() : '',
        p5_3gr = zboxwa[U[169562]] ? zboxwa[U[169562]][U[140161]]()[U[140258]]('\x20', '') : '';window['$KE2'][U[141603]] = url$[U[140194]](U[169582]) != -0x1, window['$KE2'][U[151880]] = url$[U[140194]](U[140059]) != -0x1, window['$KE2'][U[169310]] = url$[U[140194]](U[169582]) != -0x1 || url$[U[140194]](U[140059]) != -0x1, window['$KE2'][U[165545]] = url$[U[140194]](U[140060]) != -0x1 || url$[U[140194]](U[169097]) != -0x1, window['$KE2'][U[169145]] = zboxwa[U[165810]] ? zboxwa[U[165810]][U[140161]]() : '', window['$KE2']['$KTP72E'] = ![], window['$KE2']['$KTPE72'] = 0x2;if (url$[U[140194]](U[140059]) != -0x1) {
      if (zboxwa[U[149856]] >= 0x18) window['$KE2']['$KTPE72'] = 0x3;else window['$KE2']['$KTPE72'] = 0x2;
    } else {
      if (url$[U[140194]](U[169582]) != -0x1) {
        if (zboxwa[U[149856]] && zboxwa[U[149856]] >= 0x14) window['$KE2']['$KTPE72'] = 0x3;else {
          if (p5_3gr[U[140194]](U[169583]) != -0x1 || p5_3gr[U[140194]](U[169584]) != -0x1 || p5_3gr[U[140194]](U[169585]) != -0x1 || p5_3gr[U[140194]](U[169586]) != -0x1 || p5_3gr[U[140194]](U[169587]) != -0x1) window['$KE2']['$KTPE72'] = 0x2;else window['$KE2']['$KTPE72'] = 0x3;
        }
      } else window['$KE2']['$KTPE72'] = 0x2;
    }console[U[140248]](U[169588] + window['$KE2']['$KTP72E'] + U[169589] + window['$KE2']['$KTPE72']);
  } }), wx[U[169255]]({ 'success': function (ux$dal) {
    console[U[140248]](U[169590] + ux$dal[U[145170]] + U[169591] + ux$dal[U[169257]]);
  } }), wx[U[169592]]({ 'success': function (h6ti7e) {
    console[U[140248]](U[169593] + h6ti7e[U[169594]]);
  } }), wx[U[169595]]({ 'keepScreenOn': !![] }), wx[U[169596]](function (l$aux) {
  console[U[140248]](U[169593] + l$aux[U[169594]] + U[169597] + l$aux[U[169598]]);
}), wx[U[151390]](function (n1wvoq) {
  window['$K7P'] = n1wvoq, window['$K2P7'] && window['$K7P'] && (console[U[140657]](U[169233] + window['$K7P'][U[141309]]), window['$K2P7'](window['$K7P']), window['$K7P'] = null);
}), window[U[169599]] = 0x0, window['$KTE72P'] = 0x0, window[U[169600]] = null, wx[U[169601]](function () {
  window['$KTE72P']++;var lu$rd_ = Date[U[140662]]();(window[U[169599]] == 0x0 || lu$rd_ - window[U[169599]] > 0x1d4c0) && (console[U[140303]](U[169602]), wx[U[152456]]());if (window['$KTE72P'] >= 0x2) {
    window['$KTE72P'] = 0x0, console[U[140291]](U[169603]), wx[U[169604]]('0', 0x1);if (window['$KE2'] && window['$KE2'][U[141603]]) window['$KE2P'](U[169605], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});