var U = wx.$k;
import K1_uzxawb from '../kkkkSDK/kkkSDDK.js';window[U[169089]] = { 'wxVersion': window[U[141092]][U[169090]] }, window[U[169091]] = ![], window['$K2E'] = 0x1, window[U[169092]] = 0x1, window['$K7E2'] = !![], window[U[169093]] = !![], window['$KTP7E2'] = '', window['$KE2'] = { 'base_cdn': U[169094], 'cdn': U[169094] }, $KE2[U[169095]] = {}, $KE2[U[140284]] = '0', $KE2[U[145263]] = window[U[169089]][U[169096]], $KE2[U[169097]] = '', $KE2['os'] = '1', $KE2[U[169098]] = U[169099], $KE2[U[169100]] = U[169101], $KE2[U[169102]] = U[169103], $KE2[U[169104]] = U[169105], $KE2[U[169106]] = U[169107], $KE2[U[164247]] = '1', $KE2[U[165839]] = '', $KE2[U[165841]] = '', $KE2[U[169108]] = 0x0, $KE2[U[169109]] = {}, $KE2[U[169110]] = parseInt($KE2[U[164247]]), $KE2[U[165837]] = $KE2[U[164247]], $KE2[U[165833]] = {}, $KE2['$KPE'] = U[169111], $KE2[U[169112]] = ![], $KE2[U[152798]] = U[169113], $KE2[U[165812]] = Date[U[140662]](), $KE2[U[152403]] = U[169114], $KE2[U[141247]] = '_a', $KE2[U[169115]] = 0x2, $KE2[U[140675]] = 0x7c1, $KE2[U[169096]] = window[U[169089]][U[169096]], $KE2[U[141271]] = ![], $KE2[U[141603]] = ![], $KE2[U[151880]] = ![], $KE2[U[165545]] = ![], window['$K72E'] = 0x5, window['$K72'] = ![], window['$K27'] = ![], window['$KE72'] = ![], window[U[169116]] = ![], window[U[169117]] = ![], window['$KE27'] = ![], window['$K7E'] = ![], window['$KE7'] = ![], window['$K27E'] = ![], window[U[144735]] = function (r_l$) {
  console[U[140248]](U[144735], r_l$), wx[U[145542]]({}), wx[U[169118]]({ 'title': U[146905], 'content': r_l$, 'success'(r$du_) {
      if (r$du_[U[169119]]) console[U[140248]](U[169120]);else r$du_[U[141088]] && console[U[140248]](U[169121]);
    } });
}, window['$KP7E2'] = function (nq892) {
  console[U[140248]](U[169122], nq892), $KPE27(), wx[U[169118]]({ 'title': U[146905], 'content': nq892, 'confirmText': U[169123], 'cancelText': U[159081], 'success'(ki6th) {
      if (ki6th[U[169119]]) window['$KEP']();else ki6th[U[141088]] && (console[U[140248]](U[169124]), wx[U[165539]]({}));
    } });
}, window[U[169125]] = function (s28k9) {
  console[U[140248]](U[169125], s28k9), wx[U[169118]]({ 'title': U[146905], 'content': s28k9, 'confirmText': U[165967], 'showCancel': ![], 'complete'(auxl) {
      console[U[140248]](U[169124]), wx[U[165539]]({});
    } });
}, window['$KP72E'] = ![], window['$KPE72'] = function (xbwzau) {
  window['$KP72E'] = !![], wx[U[145541]](xbwzau);
}, window['$KPE27'] = function () {
  window['$KP72E'] && (window['$KP72E'] = ![], wx[U[145542]]({}));
}, window['$KP27E'] = function (zua$x) {
  window[U[169126]][U[140711]]['$KP27E'](zua$x);
}, window[U[152676]] = function (luxazb, tkhei6) {
  K1_uzxawb[U[140085]](luxazb, function (ij4t7) {
    ij4t7 && ij4t7[U[140293]] ? ij4t7[U[140293]][U[169127]] == 0x0 ? tkhei6(!![]) : (tkhei6(![]), console[U[140657]](U[169128] + ij4t7[U[140293]][U[169129]])) : console[U[140248]](U[152676], ij4t7);
  });
}, window['$KP2E7'] = function (gf5cy) {
  console[U[140248]](U[169130], gf5cy);
}, window['$KPE2'] = function (rp5d3_) {}, window['$KP2E'] = function (s28q90, j7tm4, tehki) {}, window['$KP2'] = function (xvzob) {
  console[U[140248]](U[169131], xvzob), window[U[169126]][U[140711]][U[169132]](), window[U[169126]][U[140711]][U[169133]](), window[U[169126]][U[140711]][U[169134]]();
}, window['$K2P'] = function (woxba) {
  window['$KP7E2'](U[169135]);var _5drp3 = { 'id': window['$KE2'][U[169136]], 'role': window['$KE2'][U[145193]], 'level': window['$KE2'][U[169137]], 'account': window['$KE2'][U[165838]], 'version': window['$KE2'][U[140675]], 'cdn': window['$KE2'][U[145073]], 'pkgName': window['$KE2'][U[165839]], 'gamever': window[U[141092]][U[169090]], 'serverid': window['$KE2'][U[165833]] ? window['$KE2'][U[165833]][U[140066]] : 0x0, 'systemInfo': window[U[169138]], 'error': U[169139], 'stack': woxba ? woxba : U[169135] },
      ygfc = JSON[U[145059]](_5drp3);console[U[140291]](U[169140] + ygfc), window['$KPE'](ygfc);
}, window['$KEP2'] = function (l$zax) {
  var zwo = JSON[U[140247]](l$zax);zwo[U[169141]] = window[U[141092]][U[169090]], zwo[U[169142]] = window['$KE2'][U[165833]] ? window['$KE2'][U[165833]][U[140066]] : 0x0, zwo[U[169138]] = window[U[169138]];var ulr$_d = JSON[U[145059]](zwo);console[U[140291]](U[169143] + ulr$_d), window['$KPE'](ulr$_d);
}, window['$KE2P'] = function (la_u$, bo1nv) {
  var xubzw = { 'id': window['$KE2'][U[169136]], 'role': window['$KE2'][U[145193]], 'level': window['$KE2'][U[169137]], 'account': window['$KE2'][U[165838]], 'version': window['$KE2'][U[140675]], 'cdn': window['$KE2'][U[145073]], 'pkgName': window['$KE2'][U[165839]], 'gamever': window[U[141092]][U[169090]], 'serverid': window['$KE2'][U[165833]] ? window['$KE2'][U[165833]][U[140066]] : 0x0, 'systemInfo': window[U[169138]], 'error': la_u$, 'stack': bo1nv },
      _dp35 = JSON[U[145059]](xubzw);console[U[140303]](U[169144] + _dp35), window['$KPE'](_dp35);
}, window['$KPE'] = function (ovqw) {
  if (window['$KE2'][U[169145]] == U[169146]) return;var _rdp$ = $KE2['$KPE'] + U[169147] + $KE2[U[165838]];wx[U[141017]]({ 'url': _rdp$, 'method': U[140016], 'data': ovqw, 'header': { 'content-type': U[169148], 'cache-control': U[169149] }, 'success': function (l_rpd$) {
      DEBUG && console[U[140248]](U[169150], _rdp$, ovqw, l_rpd$);
    }, 'fail': function (xlabzu) {
      DEBUG && console[U[140248]](U[169150], _rdp$, ovqw, xlabzu);
    }, 'complete': function () {} });
}, window[U[169151]] = function () {
  function boxvw() {
    return ((0x1 + Math[U[140687]]()) * 0x10000 | 0x0)[U[140132]](0x10)[U[140254]](0x1);
  }return boxvw() + boxvw() + '-' + boxvw() + '-' + boxvw() + '-' + boxvw() + '+' + boxvw() + boxvw() + boxvw();
}, window['$KEP'] = function () {
  console[U[140248]](U[169152]);var lr$dp = K1_uzxawb[U[169153]]();$KE2[U[165837]] = lr$dp[U[169154]], $KE2[U[169110]] = lr$dp[U[169154]], $KE2[U[164247]] = lr$dp[U[169154]], $KE2[U[165839]] = lr$dp[U[169155]];var nv1q8 = { 'game_ver': $KE2[U[145263]] };$KE2[U[165841]] = this[U[169151]](), $KPE72({ 'title': U[169156] }), K1_uzxawb[U[140077]](nv1q8, this['$K2PE'][U[140103]](this));
}, window['$K2PE'] = function (zwbxv) {
  var t4mji = zwbxv[U[169157]];console[U[140248]](U[169158] + t4mji + U[169159] + (t4mji == 0x1) + U[169160] + zwbxv[U[169090]] + U[169161] + window[U[169089]][U[169096]]);if (!zwbxv[U[169090]] || window['$KT72PE'](window[U[169089]][U[169096]], zwbxv[U[169090]]) < 0x0) console[U[140248]](U[169162]), $KE2[U[169100]] = U[169163], $KE2[U[169102]] = U[169164], $KE2[U[169104]] = U[169165], $KE2[U[145073]] = U[169166], $KE2[U[165543]] = U[169167], $KE2[U[169168]] = 'hy', $KE2[U[141271]] = ![];else window['$KT72PE'](window[U[169089]][U[169096]], zwbxv[U[169090]]) == 0x0 ? (console[U[140248]](U[169169]), $KE2[U[169100]] = U[169101], $KE2[U[169102]] = U[169103], $KE2[U[169104]] = U[169105], $KE2[U[145073]] = U[169170], $KE2[U[165543]] = U[169167], $KE2[U[169168]] = U[169171], $KE2[U[141271]] = !![]) : (console[U[140248]](U[169172]), $KE2[U[169100]] = U[169101], $KE2[U[169102]] = U[169103], $KE2[U[169104]] = U[169105], $KE2[U[145073]] = U[169170], $KE2[U[165543]] = U[169167], $KE2[U[169168]] = U[169171], $KE2[U[141271]] = ![]);$KE2[U[169108]] = config[U[140127]] ? config[U[140127]] : 0x0, this['$K7EP2'](), this['$K7E2P'](), window[U[169173]] = 0x5, $KPE72({ 'title': U[169174] }), K1_uzxawb[U[140011]](this['$K2EP'][U[140103]](this));
}, window[U[169173]] = 0x5, window['$K2EP'] = function (zoxwvb, siek6h) {
  if (zoxwvb == 0x0 && siek6h && siek6h[U[140279]]) {
    $KE2[U[169175]] = siek6h[U[140279]];var g35p_r = this;$KPE72({ 'title': U[169176] }), sendApi($KE2[U[169100]], U[169177], { 'platform': $KE2[U[169098]], 'partner_id': $KE2[U[164247]], 'token': siek6h[U[140279]], 'game_pkg': $KE2[U[165839]], 'deviceId': $KE2[U[165841]], 'scene': U[169178] + $KE2[U[169108]] }, this['$K7PE2'][U[140103]](this), $K72E, $K2P);
  } else siek6h && siek6h[U[166018]] && window[U[169173]] > 0x0 && (siek6h[U[166018]][U[140194]](U[169179]) != -0x1 || siek6h[U[166018]][U[140194]](U[169180]) != -0x1 || siek6h[U[166018]][U[140194]](U[169181]) != -0x1 || siek6h[U[166018]][U[140194]](U[169182]) != -0x1 || siek6h[U[166018]][U[140194]](U[169183]) != -0x1 || siek6h[U[166018]][U[140194]](U[169184]) != -0x1) ? (window[U[169173]]--, K1_uzxawb[U[140011]](this['$K2EP'][U[140103]](this))) : (window['$KE2P'](U[169185], JSON[U[145059]]({ 'status': zoxwvb, 'data': siek6h })), window['$KP7E2'](U[169186] + (siek6h && siek6h[U[166018]] ? '，' + siek6h[U[166018]] : '')));
}, window['$K7PE2'] = function (hite) {
  if (!hite) {
    window['$KE2P'](U[169187], U[169188]), window['$KP7E2'](U[169189]);return;
  }if (hite[U[144668]] != U[150469]) {
    window['$KE2P'](U[169187], JSON[U[145059]](hite)), window['$KP7E2'](U[169190] + hite[U[144668]]);return;
  }$KE2[U[164246]] = String(hite[U[165838]]), $KE2[U[165838]] = String(hite[U[165838]]), $KE2[U[165810]] = String(hite[U[165810]]), $KE2[U[165837]] = String(hite[U[165810]]), $KE2[U[165840]] = String(hite[U[165840]]), $KE2[U[169191]] = String(hite[U[152041]]), $KE2[U[169192]] = String(hite[U[141383]]), $KE2[U[152041]] = '';var baxuzw = this;$KPE72({ 'title': U[169193] }), sendApi($KE2[U[169100]], U[169194], { 'partner_id': $KE2[U[164247]], 'uid': $KE2[U[165838]], 'version': $KE2[U[145263]], 'game_pkg': $KE2[U[165839]], 'device': $KE2[U[165841]] }, baxuzw['$K7P2E'][U[140103]](baxuzw), $K72E, $K2P);
}, window['$K7P2E'] = function (zovbxw) {
  if (!zovbxw) {
    window['$KP7E2'](U[169195]);return;
  }if (zovbxw[U[144668]] != U[150469]) {
    window['$KP7E2'](U[169196] + zovbxw[U[144668]]);return;
  }if (!zovbxw[U[140293]] || zovbxw[U[140293]][U[140113]] == 0x0) {
    window['$KP7E2'](U[169197]);return;
  }$KE2[U[141163]] = zovbxw[U[169198]], $KE2[U[165833]] = { 'server_id': String(zovbxw[U[140293]][0x0][U[140066]]), 'server_name': String(zovbxw[U[140293]][0x0][U[169199]]), 'entry_ip': zovbxw[U[140293]][0x0][U[165861]], 'entry_port': parseInt(zovbxw[U[140293]][0x0][U[165862]]), 'status': $KE7P(zovbxw[U[140293]][0x0]), 'start_time': zovbxw[U[140293]][0x0][U[169200]], 'cdn': $KE2[U[145073]] }, this['$K2E7P']();
}, window['$K2E7P'] = function () {
  if ($KE2[U[141163]] == 0x1) {
    var s86k = $KE2[U[165833]][U[140679]];if (s86k === -0x1 || s86k === 0x0) {
      window['$KP7E2'](s86k === -0x1 ? U[169201] : U[169202]);return;
    }$K2P7E(0x0, $KE2[U[165833]][U[140066]]), window[U[169126]][U[140711]][U[169203]]($KE2[U[141163]]);
  } else window[U[169126]][U[140711]][U[169204]](), $KPE27();window['$KE7'] = !![], window['$K27EP'](), window['$K2EP7']();
}, window['$K7EP2'] = function () {
  sendApi($KE2[U[169100]], U[169205], { 'game_pkg': $KE2[U[165839]], 'version_name': $KE2[U[169168]] }, this[U[169206]][U[140103]](this), $K72E, $K2P);
}, window[U[169206]] = function (alud$_) {
  if (!alud$_) {
    window['$KP7E2'](U[169207]);return;
  }if (alud$_[U[144668]] != U[150469]) {
    window['$KP7E2'](U[169208] + alud$_[U[144668]]);return;
  }if (!alud$_[U[140293]] || !alud$_[U[140293]][U[145263]]) {
    window['$KP7E2'](U[169209] + (alud$_[U[140293]] && alud$_[U[140293]][U[145263]]));return;
  }alud$_[U[140293]][U[169210]] && alud$_[U[140293]][U[169210]][U[140113]] > 0xa && ($KE2[U[169211]] = alud$_[U[140293]][U[169210]], $KE2[U[145073]] = alud$_[U[140293]][U[169210]]), alud$_[U[140293]][U[145263]] && ($KE2[U[140675]] = alud$_[U[140293]][U[145263]]), console[U[140657]](U[165973] + $KE2[U[140675]] + U[169212] + $KE2[U[169168]]), window['$KE27'] = !![], window['$K27EP'](), window['$K2EP7']();
}, window[U[169213]], window['$K7E2P'] = function () {
  sendApi($KE2[U[169100]], U[169214], { 'game_pkg': $KE2[U[165839]] }, this['$K72PE'][U[140103]](this), $K72E, $K2P);
}, window['$K72PE'] = function (oxvzbw) {
  if (oxvzbw[U[144668]] === U[150469] && oxvzbw[U[140293]]) {
    window[U[169213]] = oxvzbw[U[140293]];for (var q18nv0 in oxvzbw[U[140293]]) {
      $KE2[q18nv0] = oxvzbw[U[140293]][q18nv0];
    }
  } else console[U[140657]](U[169215] + oxvzbw[U[144668]]);window['$K7E'] = !![], window['$K2EP7']();
}, window[U[169216]] = function (kthi, blazx, o1wnvq, ihek, tki6he, $d_pr5, g3c5pf, l$d_r, axlbuz) {
  tki6he = String(tki6he);var uz$la = g3c5pf,
      g5yf = l$d_r;$KE2[U[169095]][tki6he] = { 'productid': tki6he, 'productname': uz$la, 'productdesc': g5yf, 'roleid': kthi, 'rolename': blazx, 'rolelevel': o1wnvq, 'price': $d_pr5, 'callback': axlbuz }, sendApi($KE2[U[169104]], U[169217], { 'game_pkg': $KE2[U[165839]], 'server_id': $KE2[U[165833]][U[140066]], 'server_name': $KE2[U[165833]][U[169199]], 'level': o1wnvq, 'uid': $KE2[U[165838]], 'role_id': kthi, 'role_name': blazx, 'product_id': tki6he, 'product_name': uz$la, 'product_desc': g5yf, 'money': $d_pr5, 'partner_id': $KE2[U[164247]] }, toPayCallBack, $K72E, $K2P);
}, window[U[169218]] = function (_$lrdu) {
  if (_$lrdu) {
    if (_$lrdu[U[169219]] === 0xc8 || _$lrdu[U[144668]] == U[150469]) {
      var zoxv = $KE2[U[169095]][String(_$lrdu[U[169220]])];if (zoxv[U[140879]]) zoxv[U[140879]](_$lrdu[U[169220]], _$lrdu[U[169221]], -0x1);K1_uzxawb[U[140053]]({ 'cpbill': _$lrdu[U[169221]], 'productid': _$lrdu[U[169220]], 'productname': zoxv[U[169222]], 'productdesc': zoxv[U[169223]], 'serverid': $KE2[U[165833]][U[140066]], 'servername': $KE2[U[165833]][U[169199]], 'roleid': zoxv[U[169224]], 'rolename': zoxv[U[169225]], 'rolelevel': zoxv[U[169226]], 'price': zoxv[U[167529]], 'extension': JSON[U[145059]]({ 'cp_order_id': _$lrdu[U[169221]] }) }, function (vzbwox, n0892q) {
        zoxv[U[140879]] && vzbwox == 0x0 && zoxv[U[140879]](_$lrdu[U[169220]], _$lrdu[U[169221]], vzbwox);console[U[140657]](JSON[U[145059]]({ 'type': U[169227], 'status': vzbwox, 'data': _$lrdu, 'role_name': zoxv[U[169225]] }));if (vzbwox === 0x0) {} else {
          if (vzbwox === 0x1) {} else {
            if (vzbwox === 0x2) {}
          }
        }
      });
    } else alert(_$lrdu[U[140657]]);
  }
}, window['$K72EP'] = function () {}, window['$KP72'] = function ($dulr_, wbo1vn, t4jmi7, xazwu, n18vq0) {
  K1_uzxawb[U[140079]]($KE2[U[165833]][U[140066]], $KE2[U[165833]][U[169199]] || $KE2[U[165833]][U[140066]], $dulr_, wbo1vn, t4jmi7), sendApi($KE2[U[169100]], U[169228], { 'game_pkg': $KE2[U[165839]], 'server_id': $KE2[U[165833]][U[140066]], 'role_id': $dulr_, 'uid': $KE2[U[165838]], 'role_name': wbo1vn, 'role_type': xazwu, 'level': t4jmi7 });
}, window['$KP27'] = function (q298n, zvxwbo, iht7, wq, hk9es, bxwzu, m4i7jt, xawzo, a$uxdl, q2908s) {
  $KE2[U[169136]] = q298n, $KE2[U[145193]] = zvxwbo, $KE2[U[169137]] = iht7, K1_uzxawb[U[140080]]($KE2[U[165833]][U[140066]], $KE2[U[165833]][U[169199]] || $KE2[U[165833]][U[140066]], q298n, zvxwbo, iht7), sendApi($KE2[U[169100]], U[169229], { 'game_pkg': $KE2[U[165839]], 'server_id': $KE2[U[165833]][U[140066]], 'role_id': q298n, 'uid': $KE2[U[165838]], 'role_name': zvxwbo, 'role_type': wq, 'level': iht7, 'evolution': hk9es });
}, window['$K7P2'] = function (hi7et, the7i6, p5g3cf, sh6ek9, ldr$_p, rf5g3, fc53gp, ei67, kht6ei, b1zwo) {
  $KE2[U[169136]] = hi7et, $KE2[U[145193]] = the7i6, $KE2[U[169137]] = p5g3cf, K1_uzxawb[U[140081]]($KE2[U[165833]][U[140066]], $KE2[U[165833]][U[169199]] || $KE2[U[165833]][U[140066]], hi7et, the7i6, p5g3cf), sendApi($KE2[U[169100]], U[169229], { 'game_pkg': $KE2[U[165839]], 'server_id': $KE2[U[165833]][U[140066]], 'role_id': hi7et, 'uid': $KE2[U[165838]], 'role_name': the7i6, 'role_type': sh6ek9, 'level': p5g3cf, 'evolution': ldr$_p });
}, window['$K72P'] = function (htek6) {}, window['$KP7'] = function (prf3g5) {
  K1_uzxawb[U[140033]](U[140033], function (h6kis) {
    prf3g5 && prf3g5(h6kis);
  });
}, window[U[140078]] = function () {
  K1_uzxawb[U[140078]]();
}, window[U[169230]] = function () {
  K1_uzxawb[U[164139]]();
}, window[U[169231]] = function (fpgr53, htj7ie, axozb, ld_$r, zxovw, d$xa, $ulxza, ulx$da) {
  ulx$da = ulx$da || $KE2[U[165833]][U[140066]], sendApi($KE2[U[169100]], U[169232], { 'phone': fpgr53, 'role_id': htj7ie, 'uid': $KE2[U[165838]], 'game_pkg': $KE2[U[165839]], 'partner_id': $KE2[U[164247]], 'server_id': ulx$da }, $ulxza);
}, window[U[151390]] = function (k96es) {
  window['$K2P7'] = k96es, window['$K2P7'] && window['$K7P'] && (console[U[140657]](U[169233] + window['$K7P'][U[141309]]), window['$K2P7'](window['$K7P']), window['$K7P'] = null);
}, window['$K27P'] = function (ud$al, gy3f5c, mjtie, oz1wvb) {
  window[U[140607]](U[169234], { 'game_pkg': window['$KE2'][U[165839]], 'role_id': gy3f5c, 'server_id': mjtie }, oz1wvb);
}, window['$KEP72'] = function (azxwbu, d53rp_) {
  function no01qv(m4ji7) {
    var pgfr = [],
        bzwvx = [],
        ie6shk = window[U[141092]][U[169235]];for (var cg5yf in ie6shk) {
      var xudl = Number(cg5yf);(!azxwbu || !azxwbu[U[140113]] || azxwbu[U[140194]](xudl) != -0x1) && (bzwvx[U[140135]](ie6shk[cg5yf]), pgfr[U[140135]]([xudl, 0x3]));
    }window['$KT72PE'](window[U[169236]], U[169237]) >= 0x0 ? (console[U[140248]](U[169238]), K1_uzxawb[U[169239]] && K1_uzxawb[U[169239]](bzwvx, function (bwoxzv) {
      console[U[140248]](U[169240]), console[U[140248]](bwoxzv);if (bwoxzv && bwoxzv[U[166018]] == U[169241]) for (var h6iesk in ie6shk) {
        if (bwoxzv[ie6shk[h6iesk]] == U[169242]) {
          var nvoq1 = Number(h6iesk);for (var i6eh7 = 0x0; i6eh7 < pgfr[U[140113]]; i6eh7++) {
            if (pgfr[i6eh7][0x0] == nvoq1) {
              pgfr[i6eh7][0x1] = 0x1;break;
            }
          }
        }
      }window['$KT72PE'](window[U[169236]], U[169243]) >= 0x0 ? wx[U[169244]]({ 'withSubscriptions': !![], 'success': function (wozvb) {
          var gyc35 = wozvb[U[169245]][U[169246]];if (gyc35) {
            console[U[140248]](U[169247]), console[U[140248]](gyc35);for (var im47j in ie6shk) {
              if (gyc35[ie6shk[im47j]] == U[169242]) {
                var uzxal = Number(im47j);for (var l$_ud = 0x0; l$_ud < pgfr[U[140113]]; l$_ud++) {
                  if (pgfr[l$_ud][0x0] == uzxal) {
                    pgfr[l$_ud][0x1] = 0x2;break;
                  }
                }
              }
            }console[U[140248]](pgfr), d53rp_ && d53rp_(pgfr);
          } else console[U[140248]](U[169248]), console[U[140248]](wozvb), console[U[140248]](pgfr), d53rp_ && d53rp_(pgfr);
        }, 'fail': function () {
          console[U[140248]](U[169249]), console[U[140248]](pgfr), d53rp_ && d53rp_(pgfr);
        } }) : (console[U[140248]](U[169250] + window[U[169236]]), console[U[140248]](pgfr), d53rp_ && d53rp_(pgfr));
    })) : (console[U[140248]](U[169251] + window[U[169236]]), console[U[140248]](pgfr), d53rp_ && d53rp_(pgfr)), wx[U[169252]](no01qv);
  }wx[U[169253]](no01qv);
}, window['$KEP27'] = { 'isSuccess': ![], 'level': U[169254], 'isCharging': ![] }, window['$KE7P2'] = function (e6sik) {
  wx[U[169255]]({ 'success': function (r_5p) {
      var hkeit6 = window['$KEP27'];hkeit6[U[169256]] = !![], hkeit6[U[145170]] = Number(r_5p[U[145170]])[U[144783]](0x0), hkeit6[U[169257]] = r_5p[U[169257]], e6sik && e6sik(hkeit6[U[169256]], hkeit6[U[145170]], hkeit6[U[169257]]);
    }, 'fail': function (es9kh6) {
      console[U[140248]](U[169258], es9kh6[U[166018]]);var a_$dul = window['$KEP27'];e6sik && e6sik(a_$dul[U[169256]], a_$dul[U[145170]], a_$dul[U[169257]]);
    } });
}, window[U[140607]] = function (v1nwb, xwzao, bxoazw, aux$, q892n0, e7mij, u$_drl, ji4t7m) {
  if (aux$ == undefined) aux$ = 0x1;wx[U[141017]]({ 'url': v1nwb, 'method': u$_drl || U[165729], 'responseType': U[144980], 'data': xwzao, 'header': { 'content-type': ji4t7m || U[169148] }, 'success': function (sikhe) {
      DEBUG && console[U[140248]](U[169259], v1nwb, info, sikhe);if (sikhe && sikhe[U[166086]] == 0xc8) {
        var s6kei = sikhe[U[140293]];!e7mij || e7mij(s6kei) ? bxoazw && bxoazw(s6kei) : window[U[169260]](v1nwb, xwzao, bxoazw, aux$, q892n0, e7mij, sikhe);
      } else window[U[169260]](v1nwb, xwzao, bxoazw, aux$, q892n0, e7mij, sikhe);
    }, 'fail': function (fgc5y) {
      DEBUG && console[U[140248]](U[169261], v1nwb, info, fgc5y), window[U[169260]](v1nwb, xwzao, bxoazw, aux$, q892n0, e7mij, fgc5y);
    }, 'complete': function () {} });
}, window[U[169260]] = function (u$_d, xwuza, k2980, hti6e7, k26h9, ad_l$u, axwzo) {
  hti6e7 - 0x1 > 0x0 ? setTimeout(function () {
    window[U[140607]](u$_d, xwuza, k2980, hti6e7 - 0x1, k26h9, ad_l$u);
  }, 0x3e8) : k26h9 && k26h9(JSON[U[145059]]({ 'url': u$_d, 'response': axwzo }));
}, window[U[169262]] = function (wvob1z, lu$rd, fc5p, vbxwz, bwuax, r_p5d, vo1bzw) {
  !fc5p && (fc5p = {});var ual$d = Math[U[140140]](Date[U[140662]]() / 0x3e8);fc5p[U[141383]] = ual$d, fc5p[U[169263]] = lu$rd;var laud$ = Object[U[140112]](fc5p)[U[140302]](),
      _p3rg5 = '',
      qs092 = '';for (var ubaxlz = 0x0; ubaxlz < laud$[U[140113]]; ubaxlz++) {
    _p3rg5 = _p3rg5 + (ubaxlz == 0x0 ? '' : '&') + laud$[ubaxlz] + fc5p[laud$[ubaxlz]], qs092 = qs092 + (ubaxlz == 0x0 ? '' : '&') + laud$[ubaxlz] + '=' + encodeURIComponent(fc5p[laud$[ubaxlz]]);
  }_p3rg5 = _p3rg5 + $KE2[U[169106]];var nvoqw1 = U[169264] + md5(_p3rg5);send(wvob1z + '?' + qs092 + (qs092 == '' ? '' : '&') + nvoqw1, null, vbxwz, bwuax, r_p5d, vo1bzw || function (k6ihse) {
    return k6ihse[U[144668]] == U[150469];
  }, null, U[140018]);
}, window['$KE72P'] = function (zvbo, oxvw) {
  var ux$zl = 0x0;$KE2[U[165833]] && (ux$zl = $KE2[U[165833]][U[140066]]), sendApi($KE2[U[169102]], U[169265], { 'partnerId': $KE2[U[164247]], 'gamePkg': $KE2[U[165839]], 'logTime': Math[U[140140]](Date[U[140662]]() / 0x3e8), 'platformUid': $KE2[U[165840]], 'type': zvbo, 'serverId': ux$zl }, null, 0x2, null, function () {
    return !![];
  });
}, window['$KE2P7'] = function (oxbazw) {
  sendApi($KE2[U[169100]], U[169266], { 'partner_id': $KE2[U[164247]], 'uid': $KE2[U[165838]], 'version': $KE2[U[145263]], 'game_pkg': $KE2[U[165839]], 'device': $KE2[U[165841]] }, $KE27P, $K72E, $K2P);
}, window['$KE27P'] = function (w1onvq) {
  if (w1onvq[U[144668]] === U[150469] && w1onvq[U[140293]]) {
    w1onvq[U[140293]][U[140217]]({ 'id': -0x2, 'name': U[169267] }), w1onvq[U[140293]][U[140217]]({ 'id': -0x1, 'name': U[169268] }), $KE2[U[169269]] = w1onvq[U[140293]];if (window[U[152848]]) window[U[152848]][U[169270]]();
  } else $KE2[U[169271]] = ![], window['$KP7E2'](U[169272] + w1onvq[U[144668]]);
}, window['$KP7E'] = function (rp5g3f) {
  sendApi($KE2[U[169100]], U[169273], { 'partner_id': $KE2[U[164247]], 'uid': $KE2[U[165838]], 'version': $KE2[U[145263]], 'game_pkg': $KE2[U[165839]], 'device': $KE2[U[165841]] }, $KPE7, $K72E, $K2P);
}, window['$KPE7'] = function (kseh6i) {
  $KE2[U[169274]] = ![];if (kseh6i[U[144668]] === U[150469] && kseh6i[U[140293]]) {
    for (var hi6ket = 0x0; hi6ket < kseh6i[U[140293]][U[140113]]; hi6ket++) {
      kseh6i[U[140293]][hi6ket][U[140679]] = $KE7P(kseh6i[U[140293]][hi6ket]);
    }$KE2[U[169109]][-0x1] = window[U[169275]](kseh6i[U[140293]]), window[U[152848]][U[169276]](-0x1);
  } else window['$KP7E2'](U[169277] + kseh6i[U[144668]]);
}, window[U[169278]] = function (gr3_5) {
  sendApi($KE2[U[169100]], U[169273], { 'partner_id': $KE2[U[164247]], 'uid': $KE2[U[165838]], 'version': $KE2[U[145263]], 'game_pkg': $KE2[U[165839]], 'device': $KE2[U[165841]] }, gr3_5, $K72E, $K2P);
}, window['$K7PE'] = function (_$p5, du$r_) {
  sendApi($KE2[U[169100]], U[169279], { 'partner_id': $KE2[U[164247]], 'uid': $KE2[U[165838]], 'version': $KE2[U[145263]], 'game_pkg': $KE2[U[165839]], 'device': $KE2[U[165841]], 'server_group_id': du$r_ }, $K7EP, $K72E, $K2P);
}, window['$K7EP'] = function (al) {
  $KE2[U[169274]] = ![];if (al[U[144668]] === U[150469] && al[U[140293]] && al[U[140293]][U[140293]]) {
    var v0no1 = al[U[140293]][U[169280]],
        aul$ = [];for (var on1v0q = 0x0; on1v0q < al[U[140293]][U[140293]][U[140113]]; on1v0q++) {
      al[U[140293]][U[140293]][on1v0q][U[140679]] = $KE7P(al[U[140293]][U[140293]][on1v0q]), (aul$[U[140113]] == 0x0 || al[U[140293]][U[140293]][on1v0q][U[140679]] != 0x0) && (aul$[aul$[U[140113]]] = al[U[140293]][U[140293]][on1v0q]);
    }$KE2[U[169109]][v0no1] = window[U[169275]](aul$), window[U[152848]][U[169276]](v0no1);
  } else window['$KP7E2'](U[169281] + al[U[144668]]);
}, window['$KT72E'] = function (lauz) {
  sendApi($KE2[U[169100]], U[169282], { 'partner_id': $KE2[U[164247]], 'uid': $KE2[U[165838]], 'version': $KE2[U[145263]], 'game_pkg': $KE2[U[165839]], 'device': $KE2[U[165841]] }, reqServerRecommendCallBack, $K72E, $K2P);
}, window[U[169283]] = function (ud$_r) {
  $KE2[U[169274]] = ![];if (ud$_r[U[144668]] === U[150469] && ud$_r[U[140293]]) {
    for (var g5p_ = 0x0; g5p_ < ud$_r[U[140293]][U[140113]]; g5p_++) {
      ud$_r[U[140293]][g5p_][U[140679]] = $KE7P(ud$_r[U[140293]][g5p_]);
    }$KE2[U[169109]][-0x2] = window[U[169275]](ud$_r[U[140293]]), window[U[152848]][U[169276]](-0x2);
  } else alert(U[169284] + ud$_r[U[144668]]);
}, window[U[169275]] = function (h7ie6t) {
  if (!h7ie6t && h7ie6t[U[140113]] <= 0x0) return h7ie6t;for (let p_g3r = 0x0; p_g3r < h7ie6t[U[140113]]; p_g3r++) {
    h7ie6t[p_g3r][U[169285]] && h7ie6t[p_g3r][U[169285]] == 0x1 && (h7ie6t[p_g3r][U[169199]] += U[169286]);
  }return h7ie6t;
}, window['$KEP7'] = function (wvoz1b, pdr_5) {
  wvoz1b = wvoz1b || $KE2[U[165833]][U[140066]], sendApi($KE2[U[169100]], U[169287], { 'type': '4', 'game_pkg': $KE2[U[165839]], 'server_id': wvoz1b }, pdr_5);
}, window[U[169288]] = function (uxdla$, xawzbu, cy5fg, ul$_) {
  cy5fg = cy5fg || $KE2[U[165833]][U[140066]], sendApi($KE2[U[169100]], U[169289], { 'type': uxdla$, 'game_pkg': xawzbu, 'server_id': cy5fg }, ul$_);
}, window['$KE7P'] = function (zbwo) {
  if (zbwo) {
    if (zbwo[U[140679]] == 0x1) {
      if (zbwo[U[169290]] == 0x1) return 0x2;else return 0x1;
    } else return zbwo[U[140679]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$K2P7E'] = function ($_rd5p, ovqnw) {
  $KE2[U[169291]] = { 'step': $_rd5p, 'server_id': ovqnw };var xob = this;$KPE72({ 'title': U[169292] }), sendApi($KE2[U[169100]], U[169293], { 'partner_id': $KE2[U[164247]], 'uid': $KE2[U[165838]], 'game_pkg': $KE2[U[165839]], 'server_id': ovqnw, 'platform': $KE2[U[165810]], 'platform_uid': $KE2[U[165840]], 'check_login_time': $KE2[U[169192]], 'check_login_sign': $KE2[U[169191]], 'version_name': $KE2[U[169168]] }, $K2PE7, $K72E, $K2P, function (s0q928) {
    return s0q928[U[144668]] == U[150469] || s0q928[U[140657]] == U[169294] || s0q928[U[140657]] == U[169295];
  });
}, window['$K2PE7'] = function (uxwb) {
  var sh62 = this;if (uxwb[U[144668]] === U[150469] && uxwb[U[140293]]) {
    var bxazow = $KE2[U[165833]];bxazow[U[169296]] = $KE2[U[169110]], bxazow[U[152041]] = String(uxwb[U[140293]][U[169297]]), bxazow[U[165812]] = parseInt(uxwb[U[140293]][U[141383]]);if (uxwb[U[140293]][U[165811]]) bxazow[U[165811]] = parseInt(uxwb[U[140293]][U[165811]]);else bxazow[U[165811]] = parseInt(uxwb[U[140293]][U[140066]]);bxazow[U[169298]] = 0x0, bxazow[U[145073]] = $KE2[U[169211]], bxazow[U[169299]] = uxwb[U[140293]][U[169300]], bxazow[U[169301]] = uxwb[U[140293]][U[169301]], console[U[140248]](U[169302] + JSON[U[145059]](bxazow[U[169301]])), $KE2[U[141163]] == 0x1 && bxazow[U[169301]] && bxazow[U[169301]][U[169303]] == 0x1 && ($KE2[U[169304]] = 0x1, window[U[169126]][U[140711]]['$KT2E']()), $K27PE();
  } else $KE2[U[169291]][U[147673]] >= 0x3 ? ($K2P(JSON[U[145059]](uxwb)), window['$KP7E2'](U[169305] + uxwb[U[144668]])) : sendApi($KE2[U[169100]], U[169177], { 'platform': $KE2[U[169098]], 'partner_id': $KE2[U[164247]], 'token': $KE2[U[169175]], 'game_pkg': $KE2[U[165839]], 'deviceId': $KE2[U[165841]], 'scene': U[169178] + $KE2[U[169108]] }, function (v18) {
    if (!v18 || v18[U[144668]] != U[150469]) {
      window['$KP7E2'](U[169190] + v18 && v18[U[144668]]);return;
    }$KE2[U[169191]] = String(v18[U[152041]]), $KE2[U[169192]] = String(v18[U[141383]]), setTimeout(function () {
      $K2P7E($KE2[U[169291]][U[147673]] + 0x1, $KE2[U[169291]][U[140066]]);
    }, 0x5dc);
  }, $K72E, $K2P, function (te7mi) {
    return te7mi[U[144668]] == U[150469] || te7mi[U[144668]] == U[166164];
  });
}, window['$K27PE'] = function () {
  ServerLoading[U[140711]][U[169203]]($KE2[U[141163]]), window['$K72'] = !![], window['$K2EP7']();
}, window['$K27EP'] = function () {
  if (window['$K27'] && window['$KE72'] && window[U[169116]] && window[U[169117]] && window['$KE27'] && window['$KE7']) {
    if (!window[U[169087]][U[140711]]) {
      console[U[140248]](U[169306] + window[U[169087]][U[140711]]);var s6ie = wx[U[169307]](),
          jehi7 = s6ie[U[141309]] ? s6ie[U[141309]] : 0x0,
          wvoz = { 'cdn': window['$KE2'][U[145073]], 'spareCdn': window['$KE2'][U[165543]], 'newRegister': window['$KE2'][U[141163]], 'wxPC': window['$KE2'][U[165545]], 'wxIOS': window['$KE2'][U[141603]], 'wxAndroid': window['$KE2'][U[151880]], 'wxParam': { 'limitLoad': window['$KE2']['$KTP72E'], 'benchmarkLevel': window['$KE2']['$KTPE72'], 'wxFrom': window[U[141092]][U[140127]] == U[169308] ? 0x1 : 0x0, 'wxSDKVersion': window[U[169236]] }, 'configType': window['$KE2'][U[152403]], 'exposeType': window['$KE2'][U[141247]], 'scene': jehi7 };new window[U[169087]](wvoz, window['$KE2'][U[140675]], window['$KTP7E2']);
    }
  }
}, window['$K2EP7'] = function () {
  if (window['$K27'] && window['$KE72'] && window[U[169116]] && window[U[169117]] && window['$KE27'] && window['$KE7'] && window['$K72'] && window['$K7E']) {
    $KPE27();if (!$K27E) {
      $K27E = !![];if (!window[U[169087]][U[140711]]) window['$K27EP']();var ks69 = 0x0,
          $pd_ = wx[U[169309]]();$pd_ && (window['$KE2'][U[169310]] && (ks69 = $pd_[U[140868]]), console[U[140657]](U[169311] + $pd_[U[140868]] + U[169312] + $pd_[U[141744]] + U[169313] + $pd_[U[141746]] + U[169314] + $pd_[U[141745]] + U[169315] + $pd_[U[140738]] + U[169316] + $pd_[U[140739]]));var esik6h = {};for (const xua$ in $KE2[U[165833]]) {
        esik6h[xua$] = $KE2[U[165833]][xua$];
      }var tkieh = { 'channel': window['$KE2'][U[165837]], 'account': window['$KE2'][U[165838]], 'userId': window['$KE2'][U[164246]], 'cdn': window['$KE2'][U[145073]], 'data': window['$KE2'][U[140293]], 'package': window['$KE2'][U[140284]], 'newRegister': window['$KE2'][U[141163]], 'pkgName': window['$KE2'][U[165839]], 'partnerId': window['$KE2'][U[164247]], 'platform_uid': window['$KE2'][U[165840]], 'deviceId': window['$KE2'][U[165841]], 'selectedServer': esik6h, 'configType': window['$KE2'][U[152403]], 'exposeType': window['$KE2'][U[141247]], 'debugUsers': window['$KE2'][U[152798]], 'wxMenuTop': ks69, 'wxShield': window['$KE2'][U[141271]] };if (window[U[169213]]) for (var zl$uax in window[U[169213]]) {
        tkieh[zl$uax] = window[U[169213]][zl$uax];
      }window[U[169087]][U[140711]]['$K2ET'](tkieh);
    }
  } else console[U[140657]](U[169317] + window['$K27'] + U[169318] + window['$KE72'] + U[169319] + window[U[169116]] + U[169320] + window[U[169117]] + U[169321] + window['$KE27'] + U[169322] + window['$KE7'] + U[169323] + window['$K72'] + U[169324] + window['$K7E']);
};