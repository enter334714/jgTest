var U = wx.$k;
require(U[169088]);