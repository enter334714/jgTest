var v = wx.$d;
console[v[176]](v[891]), window[v[892]], wx[v[893]](function (f8ib1) {
  if (f8ib1) {
    if (f8ib1[v[894]]) {
      var i68_1 = window[v[107]][v[108]][v[742]](new RegExp(/\./, 'g'), '_'),
          rnc = f8ib1[v[894]],
          a4h5 = rnc[v[878]](/(z21ttttttt\/z21tGAMEtt.js:)[0-9]{1,60}(:)/g);if (a4h5) for (var n7ecw = 0x0; n7ecw < a4h5[v[281]]; n7ecw++) {
        if (a4h5[n7ecw] && a4h5[n7ecw][v[281]] > 0x0) {
          var oq0$h = parseInt(a4h5[n7ecw][v[742]](v[895], '')[v[742]](':', ''));rnc = rnc[v[742]](a4h5[n7ecw], a4h5[n7ecw][v[742]](':' + oq0$h + ':', ':' + (oq0$h - 0x2) + ':'));
        }
      }rnc = rnc[v[742]](new RegExp(v[896], 'g'), v[897] + i68_1 + v[898]), rnc = rnc[v[742]](new RegExp(v[899], 'g'), v[897] + i68_1 + v[898]), f8ib1[v[894]] = rnc;
    }var q5p = { 'id': window['D$UX'][v[187]], 'role': window['D$UX'][v[188]], 'level': window['D$UX'][v[189]], 'user': window['D$UX'][v[190]], 'version': window['D$UX'][v[147]], 'cdn': window['D$UX'][v[191]], 'pkgName': window['D$UX'][v[130]], 'gamever': window[v[107]][v[108]], 'serverid': window['D$UX'][v[136]] ? window['D$UX'][v[136]][v[66]] : 0x0, 'systemInfo': window[v[192]], 'error': v[900], 'stack': f8ib1 ? f8ib1[v[894]] : '' },
        wy3zvk = JSON[v[194]](q5p);console[v[195]](v[901] + wy3zvk), (!window[v[892]] || window[v[892]] != q5p[v[195]]) && (window[v[892]] = q5p[v[195]], window['D$RU'](q5p));
  }
});import 'ttfttt.js';import 'tt112tt.js';window[v[902]] = require(v[903]);import 'tINDtt.js';import 'ttLIB23tt.js';import 'tWXMtadtt.js';import 'ttINItt.js';console[v[176]](v[904]), console[v[176]](v[905]), D$RU7X({ 'title': v[906] });var zecr7wn = { 'D$MRXU7': !![] };new window[v[172]](zecr7wn), window[v[172]][v[173]]['D$M7UXR']();if (window['D$MRUX7']) clearInterval(window['D$MRUX7']);window['D$MRUX7'] = null, window['D$M7XRU'] = function (q0oh4p, q5axp) {
  if (!q0oh4p || !q5axp) return 0x0;q0oh4p = q0oh4p[v[907]]('.'), q5axp = q5axp[v[907]]('.');const i_1b68 = Math[v[908]](q0oh4p[v[281]], q5axp[v[281]]);while (q0oh4p[v[281]] < i_1b68) {
    q0oh4p[v[352]]('0');
  }while (q5axp[v[281]] < i_1b68) {
    q5axp[v[352]]('0');
  }for (var ib_18 = 0x0; ib_18 < i_1b68; ib_18++) {
    const bli16 = parseInt(q0oh4p[ib_18]),
          hmo0t = parseInt(q5axp[ib_18]);if (bli16 > hmo0t) return 0x1;else {
      if (bli16 < hmo0t) return -0x1;
    }
  }return 0x0;
}, window[v[353]] = wx[v[909]]()[v[353]], console[v[156]](v[910] + window[v[353]]);var zpd95ax = wx[v[911]]();zpd95ax[v[912]](function (_8612) {
  console[v[156]](v[913] + _8612[v[914]]);
}), zpd95ax[v[915]](function () {
  wx[v[158]]({ 'title': v[916], 'content': v[917], 'showCancel': ![], 'success': function (fxul) {
      zpd95ax[v[918]]();
    } });
}), zpd95ax[v[919]](function () {
  console[v[156]](v[920]);
}), window['D$M7XUR'] = function () {
  console[v[156]](v[921]);var cwer7 = wx[v[922]]({ 'name': v[923], 'success': function (a5u9d) {
      console[v[156]](v[924]), console[v[156]](a5u9d), a5u9d && a5u9d[v[247]] == v[925] ? (window['D$X7'] = !![], window['D$X7UR'](), window['D$XUR7']()) : setTimeout(function () {
        window['D$M7XUR']();
      }, 0x1f4);
    }, 'fail': function (cw3yzk) {
      console[v[156]](v[926]), console[v[156]](cw3yzk), setTimeout(function () {
        window['D$M7XUR']();
      }, 0x1f4);
    } });cwer7 && cwer7[v[927]](v3z62 => {});
}, window['D$MURX7'] = function () {
  console[v[156]](v[928]);var dl8uf = wx[v[922]]({ 'name': v[929], 'success': function (qax5p) {
      console[v[156]](v[930]), console[v[156]](qax5p), qax5p && qax5p[v[247]] == v[925] ? (window['D$U7X'] = !![], window['D$X7UR'](), window['D$XUR7']()) : setTimeout(function () {
        window['D$MURX7']();
      }, 0x1f4);
    }, 'fail': function (yv3wzk) {
      console[v[156]](v[931]), console[v[156]](yv3wzk), setTimeout(function () {
        window['D$MURX7']();
      }, 0x1f4);
    } });dl8uf && dl8uf[v[927]](rcnej7 => {});
}, window[v[932]] = function () {
  window['D$M7XRU'](window[v[353]], v[933]) >= 0x0 ? (console[v[156]](v[934] + window[v[353]] + v[935]), window['D$UR'](), window['D$M7XUR'](), window['D$MURX7']()) : (window['D$UXR'](v[936], window[v[353]]), wx[v[158]]({ 'title': v[159], 'content': v[937] }));
}, window[v[192]] = '', wx[v[938]]({ 'success'(da5u) {
    window[v[192]] = v[939] + da5u[v[940]] + v[941] + da5u[v[942]] + v[943] + da5u[v[116]] + v[944] + da5u[v[945]] + v[946] + da5u[v[267]] + v[947] + da5u[v[353]] + v[948] + da5u[v[949]], console[v[156]](window[v[192]]), console[v[156]](v[950] + da5u[v[951]] + v[952] + da5u[v[953]] + v[954] + da5u[v[955]] + v[956] + da5u[v[957]] + v[958] + da5u[v[959]] + v[960] + da5u[v[961]] + v[962] + (da5u[v[963]] ? da5u[v[963]][v[451]] + ',' + da5u[v[963]][v[454]] + ',' + da5u[v[963]][v[456]] + ',' + da5u[v[963]][v[458]] : ''));var ywkv = da5u[v[945]] ? da5u[v[945]][v[964]]() : '',
        ufx9d = da5u[v[942]] ? da5u[v[942]][v[964]]()[v[742]]('\x20', '') : '';window['D$UX'][v[149]] = ywkv[v[248]](v[965]) != -0x1, window['D$UX'][v[150]] = ywkv[v[248]](v[86]) != -0x1, window['D$UX'][v[450]] = ywkv[v[248]](v[965]) != -0x1 || ywkv[v[248]](v[86]) != -0x1, window['D$UX'][v[151]] = ywkv[v[248]](v[966]) != -0x1 || ywkv[v[248]](v[118]) != -0x1, window['D$UX'][v[204]] = da5u[v[267]] ? da5u[v[267]][v[964]]() : '', window['D$UX']['D$MR7XU'] = ![], window['D$UX']['D$MRU7X'] = 0x2;if (ywkv[v[248]](v[86]) != -0x1) {
      if (da5u[v[949]] >= 0x18) window['D$UX']['D$MRU7X'] = 0x3;else window['D$UX']['D$MRU7X'] = 0x2;
    } else {
      if (ywkv[v[248]](v[965]) != -0x1) {
        if (da5u[v[949]] && da5u[v[949]] >= 0x14) window['D$UX']['D$MRU7X'] = 0x3;else {
          if (ufx9d[v[248]](v[967]) != -0x1 || ufx9d[v[248]](v[968]) != -0x1 || ufx9d[v[248]](v[969]) != -0x1 || ufx9d[v[248]](v[970]) != -0x1 || ufx9d[v[248]](v[971]) != -0x1) window['D$UX']['D$MRU7X'] = 0x2;else window['D$UX']['D$MRU7X'] = 0x3;
        }
      } else window['D$UX']['D$MRU7X'] = 0x2;
    }console[v[156]](v[972] + window['D$UX']['D$MR7XU'] + v[973] + window['D$UX']['D$MRU7X']);
  } }), wx[v[372]]({ 'success': function (hapq) {
    console[v[156]](v[974] + hapq[v[374]] + v[975] + hapq[v[376]]);
  } }), wx[v[378]]({ 'success': function (yc) {
    console[v[156]](v[976] + yc[v[977]]);
  } }), wx[v[978]]({ 'keepScreenOn': !![] }), wx[v[379]](function (d9ap) {
  console[v[156]](v[976] + d9ap[v[977]] + v[979] + d9ap[v[980]]);
}), wx[v[346]](function (p9axd5) {
  window['D$7R'] = p9axd5, window['D$XR7'] && window['D$7R'] && (console[v[176]](v[347] + window['D$7R'][v[348]]), window['D$XR7'](window['D$7R']), window['D$7R'] = null);
}), window[v[981]] = 0x0, window['D$MU7XR'] = 0x0, window[v[982]] = null, wx[v[983]](function () {
  window['D$MU7XR']++;var x9fdu = Date[v[142]]();(window[v[981]] == 0x0 || x9fdu - window[v[981]] > 0x1d4c0) && (console[v[202]](v[984]), wx[v[985]]());if (window['D$MU7XR'] >= 0x2) {
    window['D$MU7XR'] = 0x0, console[v[195]](v[986]), wx[v[987]]('0', 0x1);if (window['D$UX'] && window['D$UX'][v[149]]) window['D$UXR'](v[988], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});