var v = wx.$d;
require(v[105]);