var v = wx.$d;
require('tBFtt.js'), window[v[989]][v[990]][v[991]] = null, window['client_pb'] = require('z21tCLIENTtt.js'), window[v[992]] = window[v[989]][v[993]][v[994]](client_pb);