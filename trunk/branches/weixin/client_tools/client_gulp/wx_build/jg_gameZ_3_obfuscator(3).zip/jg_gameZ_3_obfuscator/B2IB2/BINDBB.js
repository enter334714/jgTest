var D = wx.$b;
import bzitum from '../BBbasdB/B5sdkB.js';window[D[501453]] = { 'wxVersion': window[D[500919]][D[500920]] }, window[D[501454]] = ![], window['b11P'] = 0x1, window[D[501455]] = 0x1, window['b1TP1'] = !![], window[D[501456]] = !![], window['b17STP1'] = '', window['b1P1'] = { 'base_cdn': D[501457], 'cdn': D[501457] }, b1P1[D[501458]] = {}, b1P1[D[500301]] = '0', b1P1[D[500985]] = window[D[501453]][D[501243]], b1P1[D[501018]] = '', b1P1['os'] = '1', b1P1[D[501459]] = D[501460], b1P1[D[501461]] = D[501462], b1P1[D[501463]] = D[501464], b1P1[D[501465]] = D[501466], b1P1[D[501467]] = D[501468], b1P1[D[501469]] = '1', b1P1[D[500932]] = '', b1P1[D[501470]] = '', b1P1[D[501471]] = 0x0, b1P1[D[501331]] = {}, b1P1[D[501472]] = parseInt(b1P1[D[501469]]), b1P1[D[501473]] = b1P1[D[501469]], b1P1[D[500933]] = {}, b1P1['b1SP'] = D[501474], b1P1[D[501475]] = ![], b1P1[D[501476]] = D[501477], b1P1[D[501478]] = Date[D[501045]](), b1P1[D[501479]] = D[501480], b1P1[D[501481]] = '_a', b1P1[D[501230]] = 0x2, b1P1[D[500930]] = 0x7c1, b1P1[D[501243]] = window[D[501453]][D[501243]], b1P1[D[501482]] = ![], b1P1[D[501011]] = ![], b1P1[D[501013]] = ![], b1P1[D[501016]] = ![], window['b1T1P'] = 0x5, window['b1T1'] = ![], window['b11T'] = ![], window['b1PT1'] = ![], window[D[501405]] = ![], window[D[501408]] = ![], window['b1P1T'] = ![], window['b1TP'] = ![], window['b1PT'] = ![], window['b11TP'] = ![], window[D[501483]] = function (l67ok) {
  console[D[500222]](D[501483], l67ok), wx[D[501484]]({}), wx[D[500954]]({ 'title': D[500977], 'content': l67ok, 'success'(cmy1) {
      if (cmy1[D[501485]]) console[D[500222]](D[501486]);else cmy1[D[501487]] && console[D[500222]](D[501488]);
    } });
}, window['b1STP1'] = function (ea5$4f) {
  console[D[500222]](D[501489], ea5$4f), b1SP1T(), wx[D[500954]]({ 'title': D[500977], 'content': ea5$4f, 'confirmText': D[501490], 'cancelText': D[501491], 'success'(olxq7) {
      if (olxq7[D[501485]]) window['b1PS']();else olxq7[D[501487]] && (console[D[500222]](D[501492]), wx[D[501493]]({}));
    } });
}, window[D[501494]] = function (_92srh) {
  console[D[500222]](D[501494], _92srh), wx[D[500954]]({ 'title': D[500977], 'content': _92srh, 'confirmText': D[501495], 'showCancel': ![], 'complete'(j54i0) {
      console[D[500222]](D[501492]), wx[D[501493]]({});
    } });
}, window['b1ST1P'] = ![], window['b1SPT1'] = function (uzytim) {
  window['b1ST1P'] = !![], wx[D[501496]](uzytim);
}, window['b1SP1T'] = function () {
  window['b1ST1P'] && (window['b1ST1P'] = ![], wx[D[501484]]({}));
}, window['b1S1TP'] = function (twmp1) {
  window[D[500944]][D[500945]]['b1S1TP'](twmp1);
}, window[D[501497]] = function (n0i4, ct1mwz) {
  bzitum[D[501497]](n0i4, function (fj45) {
    fj45 && fj45[D[500332]] ? fj45[D[500332]][D[501340]] == 0x1 ? ct1mwz(!![]) : (ct1mwz(![]), console[D[500915]](D[501498] + fj45[D[500332]][D[501499]])) : console[D[500222]](D[501497], fj45);
  });
}, window['b1S1PT'] = function ($5ja) {
  console[D[500222]](D[501500], $5ja);
}, window['b1SP1'] = function (ynj0) {}, window['b1S1P'] = function (v2r_h, olds, lso) {}, window['b1S1'] = function (okld6) {
  console[D[500222]](D[501501], okld6), window[D[500944]][D[500945]][D[501234]](), window[D[500944]][D[500945]][D[501235]](), window[D[500944]][D[500945]][D[501247]]();
}, window['b11S'] = function (z0ymui) {
  window['b1STP1'](D[501502]);var mtp1wc = { 'id': window['b1P1'][D[500926]], 'role': window['b1P1'][D[500927]], 'level': window['b1P1'][D[500928]], 'account': window['b1P1'][D[500929]], 'version': window['b1P1'][D[500930]], 'cdn': window['b1P1'][D[500931]], 'pkgName': window['b1P1'][D[500932]], 'gamever': window[D[500919]][D[500920]], 'serverid': window['b1P1'][D[500933]] ? window['b1P1'][D[500933]][D[500934]] : 0x0, 'systemInfo': window[D[500935]], 'error': D[501503], 'stack': z0ymui ? z0ymui : D[501502] },
      z0niy = JSON[D[500937]](mtp1wc);console[D[500330]](D[501504] + z0niy), window['b1SP'](z0niy);
}, window['b1PS1'] = function (cmzuty) {
  var ld8s6 = JSON[D[500220]](cmzuty);ld8s6[D[501505]] = window[D[500919]][D[500920]], ld8s6[D[501506]] = window['b1P1'][D[500933]] ? window['b1P1'][D[500933]][D[500934]] : 0x0, ld8s6[D[500935]] = window[D[500935]];var v2wh = JSON[D[500937]](ld8s6);console[D[500330]](D[501507] + v2wh), window['b1SP'](v2wh);
}, window['b1P1S'] = function (mwt1cp, cphwv1) {
  var zuiy0n = { 'id': window['b1P1'][D[500926]], 'role': window['b1P1'][D[500927]], 'level': window['b1P1'][D[500928]], 'account': window['b1P1'][D[500929]], 'version': window['b1P1'][D[500930]], 'cdn': window['b1P1'][D[500931]], 'pkgName': window['b1P1'][D[500932]], 'gamever': window[D[500919]][D[500920]], 'serverid': window['b1P1'][D[500933]] ? window['b1P1'][D[500933]][D[500934]] : 0x0, 'systemInfo': window[D[500935]], 'error': mwt1cp, 'stack': cphwv1 },
      xkdl6o = JSON[D[500937]](zuiy0n);console[D[500381]](D[501508] + xkdl6o), window['b1SP'](xkdl6o);
}, window['b1SP'] = function (u0in4j) {
  if (window['b1P1'][D[501019]] == D[501509]) return;var qx73gk = b1P1['b1SP'] + D[501510] + b1P1[D[500929]];wx[D[501511]]({ 'url': qx73gk, 'method': D[501512], 'data': u0in4j, 'header': { 'content-type': D[501513], 'cache-control': D[501514] }, 'success': function (r2ph_v) {
      DEBUG && console[D[500222]](D[501515], qx73gk, u0in4j, r2ph_v);
    }, 'fail': function (nj$450) {
      DEBUG && console[D[500222]](D[501515], qx73gk, u0in4j, nj$450);
    }, 'complete': function () {} });
}, window[D[501516]] = function () {
  function j$na45() {
    return ((0x1 + Math[D[501237]]()) * 0x10000 | 0x0)[D[500055]](0x10)[D[500231]](0x1);
  }return j$na45() + j$na45() + '-' + j$na45() + '-' + j$na45() + '-' + j$na45() + '+' + j$na45() + j$na45() + j$na45();
}, window['b1PS'] = function () {
  console[D[500222]](D[501517]);var u4i0j = bzitum[D[501518]]();b1P1[D[501473]] = u4i0j[D[501519]], b1P1[D[501472]] = u4i0j[D[501519]], b1P1[D[501469]] = u4i0j[D[501519]], b1P1[D[500932]] = u4i0j[D[501520]];var umyti = { 'game_ver': b1P1[D[500985]] };b1P1[D[501470]] = this[D[501516]](), b1SPT1({ 'title': D[501521] }), bzitum[D[501372]](umyti, this['b11SP'][D[500011]](this));
};var wx_develop = ![];window['b11SP'] = function (kl8) {
  var ld68o = kl8[D[501522]];wx_develop = ld68o == 0x1, console[D[500222]](D[501523] + ld68o + D[501524] + (ld68o == 0x1) + D[501525] + kl8[D[500920]] + D[501526] + window[D[501453]][D[501243]]);if (!kl8[D[500920]] || window['b17T1SP'](window[D[501453]][D[501243]], kl8[D[500920]]) < 0x0) console[D[500222]](D[501527]), b1P1[D[501461]] = D[501528], b1P1[D[501463]] = D[501529], b1P1[D[501465]] = D[501530], b1P1[D[500931]] = D[501531], b1P1[D[501532]] = D[501533], b1P1[D[501534]] = 'll', b1P1[D[501482]] = ![];else window['b17T1SP'](window[D[501453]][D[501243]], kl8[D[500920]]) == 0x0 ? (console[D[500222]](D[501535]), b1P1[D[501461]] = D[501462], b1P1[D[501463]] = D[501464], b1P1[D[501465]] = D[501466], b1P1[D[500931]] = D[501536], b1P1[D[501532]] = D[501533], b1P1[D[501534]] = D[501537], b1P1[D[501482]] = !![]) : (console[D[500222]](D[501538]), b1P1[D[501461]] = D[501462], b1P1[D[501463]] = D[501464], b1P1[D[501465]] = D[501466], b1P1[D[500931]] = D[501536], b1P1[D[501532]] = D[501533], b1P1[D[501534]] = D[501537], b1P1[D[501482]] = ![]);b1P1[D[501471]] = config[D[500046]] ? config[D[500046]] : 0x0, this['b1TPS1'](), this['b1TP1S'](), window[D[501539]] = 0x5, b1SPT1({ 'title': D[501540] }), bzitum[D[501541]](this['b11PS'][D[500011]](this));
}, window[D[501539]] = 0x5, window['b11PS'] = function (hcpwv, wzm1tc) {
  if (hcpwv == 0x0 && wzm1tc && wzm1tc[D[500282]]) {
    b1P1[D[501542]] = wzm1tc[D[500282]];var nziu = this;b1SPT1({ 'title': D[501543] }), sendApi(b1P1[D[501461]], D[501544], { 'platform': b1P1[D[501459]], 'partner_id': b1P1[D[501469]], 'token': wzm1tc[D[500282]], 'game_pkg': b1P1[D[500932]], 'deviceId': b1P1[D[501470]], 'scene': D[501545] + b1P1[D[501471]] }, this['b1TSP1'][D[500011]](this), b1T1P, b11S);
  } else wzm1tc && wzm1tc[D[500964]] && window[D[501539]] > 0x0 && (wzm1tc[D[500964]][D[500142]](D[501546]) != -0x1 || wzm1tc[D[500964]][D[500142]](D[501547]) != -0x1 || wzm1tc[D[500964]][D[500142]](D[501548]) != -0x1 || wzm1tc[D[500964]][D[500142]](D[501549]) != -0x1 || wzm1tc[D[500964]][D[500142]](D[501550]) != -0x1 || wzm1tc[D[500964]][D[500142]](D[501551]) != -0x1) ? (window[D[501539]]--, bzitum[D[501541]](this['b11PS'][D[500011]](this))) : (window['b1P1S'](D[501552], JSON[D[500937]]({ 'status': hcpwv, 'data': wzm1tc })), window['b1STP1'](D[501553] + (wzm1tc && wzm1tc[D[500964]] ? '，' + wzm1tc[D[500964]] : '')));
}, window['b1TSP1'] = function (y0nji) {
  if (!y0nji) {
    window['b1P1S'](D[501554], D[501555]), window['b1STP1'](D[501556]);return;
  }if (y0nji[D[501340]] != D[501339]) {
    window['b1P1S'](D[501554], JSON[D[500937]](y0nji)), window['b1STP1'](D[501557] + y0nji[D[501340]]);return;
  }b1P1[D[501558]] = String(y0nji[D[500929]]), b1P1[D[500929]] = String(y0nji[D[500929]]), b1P1[D[500989]] = String(y0nji[D[500989]]), b1P1[D[501473]] = String(y0nji[D[500989]]), b1P1[D[501559]] = String(y0nji[D[501559]]), b1P1[D[501560]] = String(y0nji[D[501561]]), b1P1[D[501562]] = String(y0nji[D[501563]]), b1P1[D[501561]] = '';var zy1 = this;b1SPT1({ 'title': D[501564] }), sendApi(b1P1[D[501461]], D[501565], { 'partner_id': b1P1[D[501469]], 'uid': b1P1[D[500929]], 'version': b1P1[D[500985]], 'game_pkg': b1P1[D[500932]], 'device': b1P1[D[501470]] }, zy1['b1TS1P'][D[500011]](zy1), b1T1P, b11S);
}, window['b1TS1P'] = function (rh9s_2) {
  if (!rh9s_2) {
    window['b1STP1'](D[501566]);return;
  }if (rh9s_2[D[501340]] != D[501339]) {
    window['b1STP1'](D[501567] + rh9s_2[D[501340]]);return;
  }if (!rh9s_2[D[500332]] || rh9s_2[D[500332]][D[500026]] == 0x0) {
    window['b1STP1'](D[501568]);return;
  }b1P1[D[501414]] = rh9s_2[D[501569]], b1P1[D[500933]] = { 'server_id': String(rh9s_2[D[500332]][0x0][D[500934]]), 'server_name': String(rh9s_2[D[500332]][0x0][D[501321]]), 'entry_ip': rh9s_2[D[500332]][0x0][D[501570]], 'entry_port': parseInt(rh9s_2[D[500332]][0x0][D[501571]]), 'status': b1PTS(rh9s_2[D[500332]][0x0]), 'start_time': rh9s_2[D[500332]][0x0][D[501572]], 'cdn': b1P1[D[500931]] }, this['b11PTS']();
}, window['b11PTS'] = function () {
  if (b1P1[D[501414]] == 0x1) {
    var mtz1cy = b1P1[D[500933]][D[501320]];if (mtz1cy === -0x1 || mtz1cy === 0x0) {
      window['b1STP1'](mtz1cy === -0x1 ? D[501573] : D[501574]);return;
    }b11STP(0x0, b1P1[D[500933]][D[500934]]), window[D[500944]][D[500945]][D[501409]](b1P1[D[501414]]);
  } else window[D[500944]][D[500945]][D[501406]](), b1SP1T();window['b1PT'] = !![], window['b11TPS'](), window['b11PST']();
}, window['b1TPS1'] = function () {
  sendApi(b1P1[D[501461]], D[501575], { 'game_pkg': b1P1[D[500932]], 'version_name': b1P1[D[501534]] }, this[D[501576]][D[500011]](this), b1T1P, b11S);
}, window[D[501576]] = function (uj0niy) {
  if (!uj0niy) {
    window['b1STP1'](D[501577]);return;
  }if (uj0niy[D[501340]] != D[501339]) {
    window['b1STP1'](D[501578] + uj0niy[D[501340]]);return;
  }if (!uj0niy[D[500332]] || !uj0niy[D[500332]][D[500985]]) {
    window['b1STP1'](D[501579] + (uj0niy[D[500332]] && uj0niy[D[500332]][D[500985]]));return;
  }uj0niy[D[500332]][D[501580]] && uj0niy[D[500332]][D[501580]][D[500026]] > 0xa && (b1P1[D[501581]] = uj0niy[D[500332]][D[501580]], b1P1[D[500931]] = uj0niy[D[500332]][D[501580]]), uj0niy[D[500332]][D[500985]] && (b1P1[D[500930]] = uj0niy[D[500332]][D[500985]]), console[D[500915]](D[501582] + b1P1[D[500930]] + D[501583] + b1P1[D[501534]]), window['b1P1T'] = !![], window['b11TPS'](), window['b11PST']();
}, window[D[501584]], window['b1TP1S'] = function () {
  sendApi(b1P1[D[501461]], D[501585], { 'game_pkg': b1P1[D[500932]] }, this['b1T1SP'][D[500011]](this), b1T1P, b11S);
}, window['b1T1SP'] = function (o7xlqk) {
  if (o7xlqk[D[501340]] === D[501339] && o7xlqk[D[500332]]) {
    window[D[501584]] = o7xlqk[D[500332]];for (var v1pchw in o7xlqk[D[500332]]) {
      b1P1[v1pchw] = o7xlqk[D[500332]][v1pchw];
    }
  } else console[D[500915]](D[501586] + o7xlqk[D[501340]]);window['b1TP'] = !![], window['b11PST']();
}, window[D[501587]] = function (zm1tw, ynju0, fa4j$, xqlo, kx67o, lqk7x, kx3g7q, pvr2_h, mwc1) {
  kx67o = String(kx67o);var l6dso8 = kx3g7q,
      sdr9 = pvr2_h;b1P1[D[501458]][kx67o] = { 'productid': kx67o, 'productname': l6dso8, 'productdesc': sdr9, 'roleid': zm1tw, 'rolename': ynju0, 'rolelevel': fa4j$, 'price': lqk7x, 'callback': mwc1 }, sendApi(b1P1[D[501465]], D[501588], { 'game_pkg': b1P1[D[500932]], 'server_id': b1P1[D[500933]][D[500934]], 'server_name': b1P1[D[500933]][D[501321]], 'level': fa4j$, 'uid': b1P1[D[500929]], 'role_id': zm1tw, 'role_name': ynju0, 'product_id': kx67o, 'product_name': l6dso8, 'product_desc': sdr9, 'money': lqk7x, 'partner_id': b1P1[D[501469]] }, toPayCallBack, b1T1P, b11S);
}, window[D[501589]] = function (dk6lo8) {
  if (dk6lo8) {
    if (dk6lo8[D[501590]] === 0xc8 || dk6lo8[D[501340]] == D[501339]) {
      var hpv_2w = b1P1[D[501458]][String(dk6lo8[D[501591]])];if (hpv_2w[D[501592]]) hpv_2w[D[501592]](dk6lo8[D[501591]], dk6lo8[D[501593]], -0x1);bzitum[D[501594]]({ 'cpbill': dk6lo8[D[501593]], 'productid': dk6lo8[D[501591]], 'productname': hpv_2w[D[501595]], 'productdesc': hpv_2w[D[501596]], 'serverid': b1P1[D[500933]][D[500934]], 'servername': b1P1[D[500933]][D[501321]], 'roleid': hpv_2w[D[501597]], 'rolename': hpv_2w[D[501598]], 'rolelevel': hpv_2w[D[501599]], 'price': hpv_2w[D[501600]], 'extension': JSON[D[500937]]({ 'cp_order_id': dk6lo8[D[501593]] }) }, function (srd892, ij0yu) {
        hpv_2w[D[501592]] && srd892 == 0x0 && hpv_2w[D[501592]](dk6lo8[D[501591]], dk6lo8[D[501593]], srd892);console[D[500915]](JSON[D[500937]]({ 'type': D[501601], 'status': srd892, 'data': dk6lo8, 'role_name': hpv_2w[D[501598]] }));if (srd892 === 0x0) {} else {
          if (srd892 === 0x1) {} else {
            if (srd892 === 0x2) {}
          }
        }
      });
    } else alert(dk6lo8[D[500915]]);
  }
}, window['b1T1PS'] = function () {}, window['b1ST1'] = function (n4j50, s2r98_, hp1cv, phc, qkxlo) {
  bzitum[D[501602]](b1P1[D[500933]][D[500934]], b1P1[D[500933]][D[501321]] || b1P1[D[500933]][D[500934]], n4j50, s2r98_, hp1cv), sendApi(b1P1[D[501461]], D[501603], { 'game_pkg': b1P1[D[500932]], 'server_id': b1P1[D[500933]][D[500934]], 'role_id': n4j50, 'uid': b1P1[D[500929]], 'role_name': s2r98_, 'role_type': phc, 'level': hp1cv });
}, window['b1S1T'] = function (lx7g, yi0nj, s2r9_h, ja5f, w1mtpc, v1pctw, lqg, ok6dx, umcyt, hp) {
  b1P1[D[500926]] = lx7g, b1P1[D[500927]] = yi0nj, b1P1[D[500928]] = s2r9_h, bzitum[D[501604]](b1P1[D[500933]][D[500934]], b1P1[D[500933]][D[501321]] || b1P1[D[500933]][D[500934]], lx7g, yi0nj, s2r9_h), sendApi(b1P1[D[501461]], D[501605], { 'game_pkg': b1P1[D[500932]], 'server_id': b1P1[D[500933]][D[500934]], 'role_id': lx7g, 'uid': b1P1[D[500929]], 'role_name': yi0nj, 'role_type': ja5f, 'level': s2r9_h, 'evolution': w1mtpc });
}, window['b1TS1'] = function (n04u, ae54, mw1ct, $4fae5, ko67x, yi0mz, inzyu, w2pvh_, tmiyz, mwtp) {
  b1P1[D[500926]] = n04u, b1P1[D[500927]] = ae54, b1P1[D[500928]] = mw1ct, bzitum[D[501606]](b1P1[D[500933]][D[500934]], b1P1[D[500933]][D[501321]] || b1P1[D[500933]][D[500934]], n04u, ae54, mw1ct), sendApi(b1P1[D[501461]], D[501605], { 'game_pkg': b1P1[D[500932]], 'server_id': b1P1[D[500933]][D[500934]], 'role_id': n04u, 'uid': b1P1[D[500929]], 'role_name': ae54, 'role_type': $4fae5, 'level': mw1ct, 'evolution': ko67x });
}, window['b1T1S'] = function (qgxlk7) {}, window['b1ST'] = function (os9d6) {
  bzitum[D[501607]](D[501607], function (v2hw_) {
    os9d6 && os9d6(v2hw_);
  });
}, window[D[501608]] = function () {
  bzitum[D[501608]]();
}, window[D[501609]] = function () {
  bzitum[D[501610]]();
}, window[D[501039]] = function (wv_hp) {
  window['b11ST'] = wv_hp, window['b11ST'] && window['b1TS'] && (console[D[500915]](D[501040] + window['b1TS'][D[501041]]), window['b11ST'](window['b1TS']), window['b1TS'] = null);
}, window['b11TS'] = function (j4n5$a, os986, ef$a5, t1cpm) {
  window[D[501611]](D[501612], { 'game_pkg': window['b1P1'][D[500932]], 'role_id': os986, 'server_id': ef$a5 }, t1cpm);
}, window['b1PST1'] = function (ql, uy0iz) {
  function r_p2vh(doxlk) {
    var tzw1 = [],
        s92_8r = [],
        $5jaf = window[D[500919]][D[501613]];for (var mp1cw in $5jaf) {
      var vtpc = Number(mp1cw);(!ql || !ql[D[500026]] || ql[D[500142]](vtpc) != -0x1) && (s92_8r[D[500061]]($5jaf[mp1cw]), tzw1[D[500061]]([vtpc, 0x3]));
    }window['b17T1SP'](window[D[500946]], D[501614]) >= 0x0 ? (console[D[500222]](D[501615]), bzitum[D[501616]] && bzitum[D[501616]](s92_8r, function (olxd6) {
      console[D[500222]](D[501617]), console[D[500222]](olxd6);if (olxd6 && olxd6[D[500964]] == D[501618]) for (var vpcw1 in $5jaf) {
        if (olxd6[$5jaf[vpcw1]] == D[501619]) {
          var dolk = Number(vpcw1);for (var pwvch = 0x0; pwvch < tzw1[D[500026]]; pwvch++) {
            if (tzw1[pwvch][0x0] == dolk) {
              tzw1[pwvch][0x1] = 0x1;break;
            }
          }
        }
      }window['b17T1SP'](window[D[500946]], D[501620]) >= 0x0 ? wx[D[501621]]({ 'withSubscriptions': !![], 'success': function ($efa54) {
          var $4ja = $efa54[D[501622]][D[501623]];if ($4ja) {
            console[D[500222]](D[501624]), console[D[500222]]($4ja);for (var l7k6o in $5jaf) {
              if ($4ja[$5jaf[l7k6o]] == D[501619]) {
                var yizn0u = Number(l7k6o);for (var y1c = 0x0; y1c < tzw1[D[500026]]; y1c++) {
                  if (tzw1[y1c][0x0] == yizn0u) {
                    tzw1[y1c][0x1] = 0x2;break;
                  }
                }
              }
            }console[D[500222]](tzw1), uy0iz && uy0iz(tzw1);
          } else console[D[500222]](D[501625]), console[D[500222]]($efa54), console[D[500222]](tzw1), uy0iz && uy0iz(tzw1);
        }, 'fail': function () {
          console[D[500222]](D[501626]), console[D[500222]](tzw1), uy0iz && uy0iz(tzw1);
        } }) : (console[D[500222]](D[501627] + window[D[500946]]), console[D[500222]](tzw1), uy0iz && uy0iz(tzw1));
    })) : (console[D[500222]](D[501628] + window[D[500946]]), console[D[500222]](tzw1), uy0iz && uy0iz(tzw1)), wx[D[501629]](r_p2vh);
  }wx[D[501630]](r_p2vh);
}, window['b1PS1T'] = { 'isSuccess': ![], 'level': D[501631], 'isCharging': ![] }, window['b1PTS1'] = function (r2d9) {
  wx[D[501027]]({ 'success': function (tcmz) {
      var qxgl = window['b1PS1T'];qxgl[D[501632]] = !![], qxgl[D[501029]] = Number(tcmz[D[501029]])[D[501633]](0x0), qxgl[D[501031]] = tcmz[D[501031]], r2d9 && r2d9(qxgl[D[501632]], qxgl[D[501029]], qxgl[D[501031]]);
    }, 'fail': function (zni0u) {
      console[D[500222]](D[501634], zni0u[D[500964]]);var kl7oqx = window['b1PS1T'];r2d9 && r2d9(kl7oqx[D[501632]], kl7oqx[D[501029]], kl7oqx[D[501031]]);
    } });
}, window[D[501611]] = function (_2vhr, m1wczt, x76k, gq7lkx, zmuyt, jn405, yznu0i, xolq7) {
  if (gq7lkx == undefined) gq7lkx = 0x1;wx[D[501511]]({ 'url': _2vhr, 'method': yznu0i || D[501635], 'responseType': D[501239], 'data': m1wczt, 'header': { 'content-type': xolq7 || D[501513] }, 'success': function (i045) {
      DEBUG && console[D[500222]](D[501636], _2vhr, info, i045);if (i045 && i045[D[501637]] == 0xc8) {
        var h2vpr = i045[D[500332]];!jn405 || jn405(h2vpr) ? x76k && x76k(h2vpr) : window[D[501638]](_2vhr, m1wczt, x76k, gq7lkx, zmuyt, jn405, i045);
      } else window[D[501638]](_2vhr, m1wczt, x76k, gq7lkx, zmuyt, jn405, i045);
    }, 'fail': function (k6dol) {
      DEBUG && console[D[500222]](D[501639], _2vhr, info, k6dol), window[D[501638]](_2vhr, m1wczt, x76k, gq7lkx, zmuyt, jn405, k6dol);
    }, 'complete': function () {} });
}, window[D[501638]] = function (ct1yz, ytucz, j4an5$, okdx6l, q7lxkg, hw1pcv, h2_r9) {
  okdx6l - 0x1 > 0x0 ? setTimeout(function () {
    window[D[501611]](ct1yz, ytucz, j4an5$, okdx6l - 0x1, q7lxkg, hw1pcv);
  }, 0x3e8) : q7lxkg && q7lxkg(JSON[D[500937]]({ 'url': ct1yz, 'response': h2_r9 }));
}, window[D[501640]] = function (vw1pc, y1zcm, oqlk7, wv_2ph, ctumz, ytz, jn5a$4) {
  !oqlk7 && (oqlk7 = {});var yuijn = Math[D[500066]](Date[D[501045]]() / 0x3e8);oqlk7[D[501563]] = yuijn, oqlk7[D[501641]] = y1zcm;var yzmu0i = Object[D[500025]](oqlk7)[D[500380]](),
      _2hwv = '',
      c1mtzw = '';for (var e4a = 0x0; e4a < yzmu0i[D[500026]]; e4a++) {
    _2hwv = _2hwv + (e4a == 0x0 ? '' : '&') + yzmu0i[e4a] + oqlk7[yzmu0i[e4a]], c1mtzw = c1mtzw + (e4a == 0x0 ? '' : '&') + yzmu0i[e4a] + '=' + encodeURIComponent(oqlk7[yzmu0i[e4a]]);
  }_2hwv = _2hwv + b1P1[D[501467]];var kol8d6 = D[501642] + md5(_2hwv);send(vw1pc + '?' + c1mtzw + (c1mtzw == '' ? '' : '&') + kol8d6, null, wv_2ph, ctumz, ytz, jn5a$4 || function (qg37k) {
    return qg37k[D[501340]] == D[501339];
  }, null, D[501643]);
}, window['b1PT1S'] = function (jn$5a4, s_r8) {
  var kxl7oq = 0x0;b1P1[D[500933]] && (kxl7oq = b1P1[D[500933]][D[500934]]), sendApi(b1P1[D[501463]], D[501644], { 'partnerId': b1P1[D[501469]], 'gamePkg': b1P1[D[500932]], 'logTime': Math[D[500066]](Date[D[501045]]() / 0x3e8), 'platformUid': b1P1[D[501559]], 'type': jn$5a4, 'serverId': kxl7oq }, null, 0x2, null, function () {
    return !![];
  });
}, window['b1P1ST'] = function (klg7) {
  sendApi(b1P1[D[501461]], D[501645], { 'partner_id': b1P1[D[501469]], 'uid': b1P1[D[500929]], 'version': b1P1[D[500985]], 'game_pkg': b1P1[D[500932]], 'device': b1P1[D[501470]] }, b1P1TS, b1T1P, b11S);
}, window['b1P1TS'] = function (jun0i) {
  if (jun0i[D[501340]] === D[501339] && jun0i[D[500332]]) {
    jun0i[D[500332]][D[500170]]({ 'id': -0x2, 'name': D[501646] }), jun0i[D[500332]][D[500170]]({ 'id': -0x1, 'name': D[501647] }), b1P1[D[501294]] = jun0i[D[500332]];if (window[D[501286]]) window[D[501286]][D[501327]]();
  } else b1P1[D[501304]] = ![], window['b1STP1'](D[501648] + jun0i[D[501340]]);
}, window['b1STP'] = function (inu0y) {
  sendApi(b1P1[D[501461]], D[501649], { 'partner_id': b1P1[D[501469]], 'uid': b1P1[D[500929]], 'version': b1P1[D[500985]], 'game_pkg': b1P1[D[500932]], 'device': b1P1[D[501470]] }, b1SPT, b1T1P, b11S);
}, window['b1SPT'] = function (j54fa) {
  b1P1[D[501333]] = ![];if (j54fa[D[501340]] === D[501339] && j54fa[D[500332]]) {
    for (var qxkg37 = 0x0; qxkg37 < j54fa[D[500332]][D[500026]]; qxkg37++) {
      j54fa[D[500332]][qxkg37][D[501320]] = b1PTS(j54fa[D[500332]][qxkg37]);
    }b1P1[D[501331]][-0x1] = window[D[501650]](j54fa[D[500332]]), window[D[501286]][D[501332]](-0x1);
  } else window['b1STP1'](D[501651] + j54fa[D[501340]]);
}, window[D[501652]] = function (cuztm) {
  sendApi(b1P1[D[501461]], D[501649], { 'partner_id': b1P1[D[501469]], 'uid': b1P1[D[500929]], 'version': b1P1[D[500985]], 'game_pkg': b1P1[D[500932]], 'device': b1P1[D[501470]] }, cuztm, b1T1P, b11S);
}, window['b1TSP'] = function (sr_298, yj0ni) {
  sendApi(b1P1[D[501461]], D[501653], { 'partner_id': b1P1[D[501469]], 'uid': b1P1[D[500929]], 'version': b1P1[D[500985]], 'game_pkg': b1P1[D[500932]], 'device': b1P1[D[501470]], 'server_group_id': yj0ni }, b1TPS, b1T1P, b11S);
}, window['b1TPS'] = function (h_vr92) {
  b1P1[D[501333]] = ![];if (h_vr92[D[501340]] === D[501339] && h_vr92[D[500332]] && h_vr92[D[500332]][D[500332]]) {
    var iuzymt = h_vr92[D[500332]][D[501654]],
        qxk37 = [];for (var tuc = 0x0; tuc < h_vr92[D[500332]][D[500332]][D[500026]]; tuc++) {
      h_vr92[D[500332]][D[500332]][tuc][D[501320]] = b1PTS(h_vr92[D[500332]][D[500332]][tuc]), (qxk37[D[500026]] == 0x0 || h_vr92[D[500332]][D[500332]][tuc][D[501320]] != 0x0) && (qxk37[qxk37[D[500026]]] = h_vr92[D[500332]][D[500332]][tuc]);
    }b1P1[D[501331]][iuzymt] = window[D[501650]](qxk37), window[D[501286]][D[501332]](iuzymt);
  } else window['b1STP1'](D[501655] + h_vr92[D[501340]]);
}, window['b17T1P'] = function (n54j0i) {
  sendApi(b1P1[D[501461]], D[501656], { 'partner_id': b1P1[D[501469]], 'uid': b1P1[D[500929]], 'version': b1P1[D[500985]], 'game_pkg': b1P1[D[500932]], 'device': b1P1[D[501470]] }, reqServerRecommendCallBack, b1T1P, b11S);
}, window[D[501657]] = function (mz1twc) {
  b1P1[D[501333]] = ![];if (mz1twc[D[501340]] === D[501339] && mz1twc[D[500332]]) {
    for (var czt1mw = 0x0; czt1mw < mz1twc[D[500332]][D[500026]]; czt1mw++) {
      mz1twc[D[500332]][czt1mw][D[501320]] = b1PTS(mz1twc[D[500332]][czt1mw]);
    }b1P1[D[501331]][-0x2] = window[D[501650]](mz1twc[D[500332]]), window[D[501286]][D[501332]](-0x2);
  } else alert(D[501658] + mz1twc[D[501340]]);
}, window[D[501650]] = function (mzuct) {
  if (!mzuct && mzuct[D[500026]] <= 0x0) return mzuct;for (let lxk6od = 0x0; lxk6od < mzuct[D[500026]]; lxk6od++) {
    mzuct[lxk6od][D[501659]] && mzuct[lxk6od][D[501659]] == 0x1 && (mzuct[lxk6od][D[501321]] += D[501660]);
  }return mzuct;
}, window['b1PST'] = function (hv1wp, r28s9) {
  hv1wp = hv1wp || b1P1[D[500933]][D[500934]], sendApi(b1P1[D[501461]], D[501661], { 'type': '4', 'game_pkg': b1P1[D[500932]], 'server_id': hv1wp }, r28s9);
}, window[D[501662]] = function (r9d, n0ui, rd68s, a5j4f$) {
  rd68s = rd68s || b1P1[D[500933]][D[500934]], sendApi(b1P1[D[501461]], D[501663], { 'type': r9d, 'game_pkg': n0ui, 'server_id': rd68s }, a5j4f$);
}, window['b1PTS'] = function (vwp1c) {
  if (vwp1c) {
    if (vwp1c[D[501320]] == 0x1) {
      if (vwp1c[D[501664]] == 0x1) return 0x2;else return 0x1;
    } else return vwp1c[D[501320]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['b11STP'] = function (ja5$, pw1) {
  b1P1[D[501665]] = { 'step': ja5$, 'server_id': pw1 };var c1pwm = this;b1SPT1({ 'title': D[501666] }), sendApi(b1P1[D[501461]], D[501667], { 'partner_id': b1P1[D[501469]], 'uid': b1P1[D[500929]], 'game_pkg': b1P1[D[500932]], 'server_id': pw1, 'platform': b1P1[D[500989]], 'platform_uid': b1P1[D[501559]], 'check_login_time': b1P1[D[501562]], 'check_login_sign': b1P1[D[501560]], 'version_name': b1P1[D[501534]] }, b11SPT, b1T1P, b11S, function ($f4a5j) {
    return $f4a5j[D[501340]] == D[501339] || $f4a5j[D[500915]] == D[501668] || $f4a5j[D[500915]] == D[501669];
  });
}, window['b11SPT'] = function (ctp) {
  var lk7oqx = this;if (ctp[D[501340]] === D[501339] && ctp[D[500332]]) {
    var dols8 = b1P1[D[500933]];dols8[D[501670]] = b1P1[D[501472]], dols8[D[501561]] = String(ctp[D[500332]][D[501671]]), dols8[D[501478]] = parseInt(ctp[D[500332]][D[501563]]);if (ctp[D[500332]][D[501672]]) dols8[D[501672]] = parseInt(ctp[D[500332]][D[501672]]);else dols8[D[501672]] = parseInt(ctp[D[500332]][D[500934]]);dols8[D[501673]] = 0x0, dols8[D[500931]] = b1P1[D[501581]], dols8[D[501674]] = ctp[D[500332]][D[501675]], dols8[D[501676]] = ctp[D[500332]][D[501676]], console[D[500222]](D[501677] + JSON[D[500937]](dols8[D[501676]])), b1P1[D[501414]] == 0x1 && dols8[D[501676]] && dols8[D[501676]][D[501678]] == 0x1 && (b1P1[D[501244]] = 0x1, window[D[500944]][D[500945]]['b171P']()), b11TSP();
  } else b1P1[D[501665]][D[501679]] >= 0x3 ? (b11S(JSON[D[500937]](ctp)), window['b1STP1'](D[501680] + ctp[D[501340]])) : sendApi(b1P1[D[501461]], D[501544], { 'platform': b1P1[D[501459]], 'partner_id': b1P1[D[501469]], 'token': b1P1[D[501542]], 'game_pkg': b1P1[D[500932]], 'deviceId': b1P1[D[501470]], 'scene': D[501545] + b1P1[D[501471]] }, function ($5a4jn) {
    if (!$5a4jn || $5a4jn[D[501340]] != D[501339]) {
      window['b1STP1'](D[501557] + $5a4jn && $5a4jn[D[501340]]);return;
    }b1P1[D[501560]] = String($5a4jn[D[501561]]), b1P1[D[501562]] = String($5a4jn[D[501563]]), setTimeout(function () {
      b11STP(b1P1[D[501665]][D[501679]] + 0x1, b1P1[D[501665]][D[500934]]);
    }, 0x5dc);
  }, b1T1P, b11S, function (izyun0) {
    return izyun0[D[501340]] == D[501339] || izyun0[D[501340]] == D[501681];
  });
}, window['b11TSP'] = function () {
  ServerLoading[D[500945]][D[501409]](b1P1[D[501414]]), window['b1T1'] = !![], window['b11PST']();
}, window['b11TPS'] = function () {
  if (window['b11T'] && window['b1PT1'] && window[D[501405]] && window[D[501408]] && window['b1P1T'] && window['b1PT']) {
    if (!window[D[501682]][D[500945]]) {
      console[D[500222]](D[501683] + window[D[501682]][D[500945]]);var i0nzy = wx[D[501684]](),
          hvp1cw = i0nzy[D[501041]] ? i0nzy[D[501041]] : 0x0,
          aef5$4 = { 'cdn': window['b1P1'][D[500931]], 'spareCdn': window['b1P1'][D[501532]], 'newRegister': window['b1P1'][D[501414]], 'wxPC': window['b1P1'][D[501016]], 'wxIOS': window['b1P1'][D[501011]], 'wxAndroid': window['b1P1'][D[501013]], 'wxParam': { 'limitLoad': window['b1P1']['b17ST1P'], 'benchmarkLevel': window['b1P1']['b17SPT1'], 'wxFrom': window[D[500919]][D[500046]] == D[501685] ? 0x1 : 0x0, 'wxSDKVersion': window[D[500946]] }, 'configType': window['b1P1'][D[501479]], 'exposeType': window['b1P1'][D[501481]], 'scene': hvp1cw };new window[D[501682]](aef5$4, window['b1P1'][D[500930]], window['b17STP1']);
    }
  }
}, window['b11PST'] = function () {
  if (window['b11T'] && window['b1PT1'] && window[D[501405]] && window[D[501408]] && window['b1P1T'] && window['b1PT'] && window['b1T1'] && window['b1TP']) {
    b1SP1T();if (!b11TP) {
      b11TP = !![];if (!window[D[501682]][D[500945]]) window['b11TPS']();var s9o68d = 0x0,
          klo6xd = wx[D[501686]]();klo6xd && (window['b1P1'][D[501015]] && (s9o68d = klo6xd[D[501007]]), console[D[500915]](D[501687] + klo6xd[D[501007]] + D[501688] + klo6xd[D[501008]] + D[501689] + klo6xd[D[501009]] + D[501690] + klo6xd[D[501010]] + D[501691] + klo6xd[D[501209]] + D[501692] + klo6xd[D[501211]]));var srd896 = {};for (const jyn0ui in b1P1[D[500933]]) {
        srd896[jyn0ui] = b1P1[D[500933]][jyn0ui];
      }var dlk8 = { 'channel': window['b1P1'][D[501473]], 'account': window['b1P1'][D[500929]], 'userId': window['b1P1'][D[501558]], 'cdn': window['b1P1'][D[500931]], 'data': window['b1P1'][D[500332]], 'package': window['b1P1'][D[500301]], 'newRegister': window['b1P1'][D[501414]], 'pkgName': window['b1P1'][D[500932]], 'partnerId': window['b1P1'][D[501469]], 'platform_uid': window['b1P1'][D[501559]], 'deviceId': window['b1P1'][D[501470]], 'selectedServer': srd896, 'configType': window['b1P1'][D[501479]], 'exposeType': window['b1P1'][D[501481]], 'debugUsers': window['b1P1'][D[501476]], 'wxMenuTop': s9o68d, 'wxShield': window['b1P1'][D[501482]] };if (window[D[501584]]) for (var q3gx7k in window[D[501584]]) {
        dlk8[q3gx7k] = window[D[501584]][q3gx7k];
      }window[D[501682]][D[500945]]['b11P7'](dlk8);
    }
  } else console[D[500915]](D[501693] + window['b11T'] + D[501694] + window['b1PT1'] + D[501695] + window[D[501405]] + D[501696] + window[D[501408]] + D[501697] + window['b1P1T'] + D[501698] + window['b1PT'] + D[501699] + window['b1T1'] + D[501700] + window['b1TP']);
};