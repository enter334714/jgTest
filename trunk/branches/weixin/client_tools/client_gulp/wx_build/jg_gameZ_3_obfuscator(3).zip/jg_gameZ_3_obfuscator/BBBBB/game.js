var D = wx.$b;
import 'B2MBIB2.js';