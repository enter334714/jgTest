var D = wx.$b;
console[D[500915]](D[500916]), window[D[500917]], wx[D[500918]](function ($ae4f) {
  if ($ae4f) {
    if ($ae4f[D[500051]]) {
      var s829_ = window[D[500919]][D[500920]][D[500240]](new RegExp(/\./, 'g'), '_'),
          uyimz = $ae4f[D[500051]],
          d9r6s = uyimz[D[500062]](/(BBBBB\/B2GBMEB2.js:)[0-9]{1,60}(:)/g);if (d9r6s) for (var n4j0$5 = 0x0; n4j0$5 < d9r6s[D[500026]]; n4j0$5++) {
        if (d9r6s[n4j0$5] && d9r6s[n4j0$5][D[500026]] > 0x0) {
          var f54$a = parseInt(d9r6s[n4j0$5][D[500240]](D[500921], '')[D[500240]](':', ''));uyimz = uyimz[D[500240]](d9r6s[n4j0$5], d9r6s[n4j0$5][D[500240]](':' + f54$a + ':', ':' + (f54$a - 0x2) + ':'));
        }
      }uyimz = uyimz[D[500240]](new RegExp(D[500922], 'g'), D[500923] + s829_ + D[500924]), uyimz = uyimz[D[500240]](new RegExp(D[500925], 'g'), D[500923] + s829_ + D[500924]), $ae4f[D[500051]] = uyimz;
    }var s82r9_ = { 'id': window['b1P1'][D[500926]], 'role': window['b1P1'][D[500927]], 'level': window['b1P1'][D[500928]], 'user': window['b1P1'][D[500929]], 'version': window['b1P1'][D[500930]], 'cdn': window['b1P1'][D[500931]], 'pkgName': window['b1P1'][D[500932]], 'gamever': window[D[500919]][D[500920]], 'serverid': window['b1P1'][D[500933]] ? window['b1P1'][D[500933]][D[500934]] : 0x0, 'systemInfo': window[D[500935]], 'error': D[500936], 'stack': $ae4f ? $ae4f[D[500051]] : '' },
        odx6lk = JSON[D[500937]](s82r9_);console[D[500330]](D[500938] + odx6lk), (!window[D[500917]] || window[D[500917]] != s82r9_[D[500330]]) && (window[D[500917]] = s82r9_[D[500330]], window['b1SP'](s82r9_));
  }
});import 'BBbfBB.js';import 'BB11BB.js';window[D[500939]] = require(D[500940]);import 'BINDBB.js';import 'BBIB1BB.js';import 'BBMtadBB.js';import 'BBINIBaB.js';console[D[500915]](D[500941]), console[D[500915]](D[500942]), b1SPT1({ 'title': D[500943] });var bnyi0uj = { 'b17S1PT': !![] };new window[D[500944]](bnyi0uj), window[D[500944]][D[500945]]['b17TP1S']();if (window['b17SP1T']) clearInterval(window['b17SP1T']);window['b17SP1T'] = null, window['b17T1SP'] = function (h_2rvp, p1hwvc) {
  if (!h_2rvp || !p1hwvc) return 0x0;h_2rvp = h_2rvp[D[500197]]('.'), p1hwvc = p1hwvc[D[500197]]('.');const ols = Math[D[500298]](h_2rvp[D[500026]], p1hwvc[D[500026]]);while (h_2rvp[D[500026]] < ols) {
    h_2rvp[D[500061]]('0');
  }while (p1hwvc[D[500026]] < ols) {
    p1hwvc[D[500061]]('0');
  }for (var _p1vwh = 0x0; _p1vwh < ols; _p1vwh++) {
    const ol6d8 = parseInt(h_2rvp[_p1vwh]),
          dlso = parseInt(p1hwvc[_p1vwh]);if (ol6d8 > dlso) return 0x1;else {
      if (ol6d8 < dlso) return -0x1;
    }
  }return 0x0;
}, window[D[500946]] = wx[D[500947]]()[D[500946]], console[D[500222]](D[500948] + window[D[500946]]);var bvwc1 = wx[D[500949]]();bvwc1[D[500950]](function (j4an$5) {
  console[D[500222]](D[500951] + j4an$5[D[500952]]);
}), bvwc1[D[500953]](function () {
  wx[D[500954]]({ 'title': D[500955], 'content': D[500956], 'showCancel': ![], 'success': function (pvw1h) {
      bvwc1[D[500957]]();
    } });
}), bvwc1[D[500958]](function () {
  console[D[500222]](D[500959]);
}), window['b17T1PS'] = function () {
  console[D[500222]](D[500960]);var $5fea4 = wx[D[500961]]({ 'name': D[500962], 'success': function (wzmt1) {
      console[D[500222]](D[500963]), console[D[500222]](wzmt1), wzmt1 && wzmt1[D[500964]] == D[500965] ? (window['b11T'] = !![], window['b11TPS'](), window['b11PST']()) : setTimeout(function () {
        window['b17T1PS']();
      }, 0x1f4);
    }, 'fail': function (dko6lx) {
      console[D[500222]](D[500966]), console[D[500222]](dko6lx), setTimeout(function () {
        window['b17T1PS']();
      }, 0x1f4);
    } });$5fea4 && $5fea4[D[500967]](jn4$a => {});
}, window['b17PS1T'] = function () {
  console[D[500222]](D[500968]);var _pvr2 = wx[D[500961]]({ 'name': D[500969], 'success': function (af54) {
      console[D[500222]](D[500970]), console[D[500222]](af54), af54 && af54[D[500964]] == D[500965] ? (window['b1PT1'] = !![], window['b11TPS'](), window['b11PST']()) : setTimeout(function () {
        window['b17PS1T']();
      }, 0x1f4);
    }, 'fail': function (e$4f5a) {
      console[D[500222]](D[500971]), console[D[500222]](e$4f5a), setTimeout(function () {
        window['b17PS1T']();
      }, 0x1f4);
    } });_pvr2 && _pvr2[D[500967]](z0n => {});
}, window[D[500972]] = function () {
  window['b17T1SP'](window[D[500946]], D[500973]) >= 0x0 ? (console[D[500222]](D[500974] + window[D[500946]] + D[500975]), window['b1PS'](), window['b17T1PS'](), window['b17PS1T']()) : (window['b1P1S'](D[500976], window[D[500946]]), wx[D[500954]]({ 'title': D[500977], 'content': D[500978] }));
}, window[D[500935]] = '', wx[D[500979]]({ 'success'(hwv1c) {
    window[D[500935]] = D[500980] + hwv1c[D[500981]] + D[500982] + hwv1c[D[500983]] + D[500984] + hwv1c[D[500985]] + D[500986] + hwv1c[D[500987]] + D[500988] + hwv1c[D[500989]] + D[500990] + hwv1c[D[500946]] + D[500991] + hwv1c[D[500992]], console[D[500222]](window[D[500935]]), console[D[500222]](D[500993] + hwv1c[D[500994]] + D[500995] + hwv1c[D[500996]] + D[500997] + hwv1c[D[500998]] + D[500999] + hwv1c[D[501000]] + D[501001] + hwv1c[D[501002]] + D[501003] + hwv1c[D[501004]] + D[501005] + (hwv1c[D[501006]] ? hwv1c[D[501006]][D[501007]] + ',' + hwv1c[D[501006]][D[501008]] + ',' + hwv1c[D[501006]][D[501009]] + ',' + hwv1c[D[501006]][D[501010]] : ''));var im0uy = hwv1c[D[500987]] ? hwv1c[D[500987]][D[500099]]() : '',
        mu0i = hwv1c[D[500983]] ? hwv1c[D[500983]][D[500099]]()[D[500240]]('\x20', '') : '';window['b1P1'][D[501011]] = im0uy[D[500142]](D[501012]) != -0x1, window['b1P1'][D[501013]] = im0uy[D[500142]](D[501014]) != -0x1, window['b1P1'][D[501015]] = im0uy[D[500142]](D[501012]) != -0x1 || im0uy[D[500142]](D[501014]) != -0x1, window['b1P1'][D[501016]] = im0uy[D[500142]](D[501017]) != -0x1 || im0uy[D[500142]](D[501018]) != -0x1, window['b1P1'][D[501019]] = hwv1c[D[500989]] ? hwv1c[D[500989]][D[500099]]() : '', window['b1P1']['b17ST1P'] = ![], window['b1P1']['b17SPT1'] = 0x2;if (im0uy[D[500142]](D[501014]) != -0x1) {
      if (hwv1c[D[500992]] >= 0x18) window['b1P1']['b17SPT1'] = 0x3;else window['b1P1']['b17SPT1'] = 0x2;
    } else {
      if (im0uy[D[500142]](D[501012]) != -0x1) {
        if (hwv1c[D[500992]] && hwv1c[D[500992]] >= 0x14) window['b1P1']['b17SPT1'] = 0x3;else {
          if (mu0i[D[500142]](D[501020]) != -0x1 || mu0i[D[500142]](D[501021]) != -0x1 || mu0i[D[500142]](D[501022]) != -0x1 || mu0i[D[500142]](D[501023]) != -0x1 || mu0i[D[500142]](D[501024]) != -0x1) window['b1P1']['b17SPT1'] = 0x2;else window['b1P1']['b17SPT1'] = 0x3;
        }
      } else window['b1P1']['b17SPT1'] = 0x2;
    }console[D[500222]](D[501025] + window['b1P1']['b17ST1P'] + D[501026] + window['b1P1']['b17SPT1']);
  } }), wx[D[501027]]({ 'success': function (phwv_) {
    console[D[500222]](D[501028] + phwv_[D[501029]] + D[501030] + phwv_[D[501031]]);
  } }), wx[D[501032]]({ 'success': function (wcpmt) {
    console[D[500222]](D[501033] + wcpmt[D[501034]]);
  } }), wx[D[501035]]({ 'keepScreenOn': !![] }), wx[D[501036]](function (cmyuzt) {
  console[D[500222]](D[501033] + cmyuzt[D[501034]] + D[501037] + cmyuzt[D[501038]]);
}), wx[D[501039]](function (afj) {
  window['b1TS'] = afj, window['b11ST'] && window['b1TS'] && (console[D[500915]](D[501040] + window['b1TS'][D[501041]]), window['b11ST'](window['b1TS']), window['b1TS'] = null);
}), window[D[501042]] = 0x0, window['b17PT1S'] = 0x0, window[D[501043]] = null, wx[D[501044]](function () {
  window['b17PT1S']++;var imztu = Date[D[501045]]();(window[D[501042]] == 0x0 || imztu - window[D[501042]] > 0x1d4c0) && (console[D[500381]](D[501046]), wx[D[501047]]());if (window['b17PT1S'] >= 0x2) {
    window['b17PT1S'] = 0x0, console[D[500330]](D[501048]), wx[D[501049]]('0', 0x1);if (window['b1P1'] && window['b1P1'][D[501011]]) window['b1P1S'](D[501050], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});