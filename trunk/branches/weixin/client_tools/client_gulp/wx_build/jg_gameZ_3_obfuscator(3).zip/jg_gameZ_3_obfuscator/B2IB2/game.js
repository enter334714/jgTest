var D = wx.$b;
require(D[501701]);