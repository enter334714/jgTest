var D = wx.$b;
require('BBFBB.js'), window[D[500401]][D[500379]][D[500015]] = null, window['client_pb'] = require('BBIENBB.js'), window[D[500914]] = window[D[500401]][D[500216]][D[500076]](client_pb);