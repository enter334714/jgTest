var a = wx.$y;
import yfoh4wj from '../yyabyysdk/y7sdky.js';window[a[420001]] = { 'wxVersion': window[a[420002]][a[420003]] }, window[a[420004]] = ![], window['y20S'] = 0x1, window[a[420005]] = 0x1, window['y25S0'] = !![], window[a[420006]] = !![], window['y29$5S0'] = '', window['y2S0'] = { 'base_cdn': a[420007], 'cdn': a[420007] }, y2S0[a[420008]] = {}, y2S0[a[420009]] = '0', y2S0[a[420010]] = window[a[420001]][a[420011]], y2S0[a[420012]] = '', y2S0['os'] = '1', y2S0[a[420013]] = a[420014], y2S0[a[420015]] = a[420016], y2S0[a[420017]] = a[420018], y2S0[a[420019]] = a[420020], y2S0[a[420021]] = a[420022], y2S0[a[420023]] = '1', y2S0[a[420024]] = '', y2S0[a[420025]] = '', y2S0[a[420026]] = 0x0, y2S0[a[420027]] = {}, y2S0[a[420028]] = parseInt(y2S0[a[420023]]), y2S0[a[420029]] = y2S0[a[420023]], y2S0[a[420030]] = {}, y2S0['y2$S'] = a[420031], y2S0[a[420032]] = ![], y2S0[a[420033]] = a[420034], y2S0[a[420035]] = Date[a[420036]](), y2S0[a[420037]] = a[420038], y2S0[a[420039]] = '_a', y2S0[a[420040]] = 0x2, y2S0[a[420041]] = 0x7c1, y2S0[a[420011]] = window[a[420001]][a[420011]], y2S0[a[420042]] = ![], y2S0[a[420043]] = ![], y2S0[a[420044]] = ![], y2S0[a[420045]] = ![], window['y250S'] = 0x5, window['y250'] = ![], window['y205'] = ![], window['y2S50'] = ![], window[a[420046]] = ![], window[a[420047]] = ![], window['y2S05'] = ![], window['y25S'] = ![], window['y2S5'] = ![], window['y205S'] = ![], window[a[420048]] = function (pginq$) {
  console[a[420049]](a[420048], pginq$), wx[a[420050]]({}), wx[a[420051]]({ 'title': a[420052], 'content': pginq$, 'success'(i$pngq) {
      if (i$pngq[a[420053]]) console[a[420049]](a[420054]);else i$pngq[a[420055]] && console[a[420049]](a[420056]);
    } });
}, window['y2$5S0'] = function (fo_4hj) {
  console[a[420049]](a[420057], fo_4hj), y2$S05(), wx[a[420051]]({ 'title': a[420052], 'content': fo_4hj, 'confirmText': a[420058], 'cancelText': a[420059], 'success'(s7lf_) {
      if (s7lf_[a[420053]]) window['y2S$']();else s7lf_[a[420055]] && (console[a[420049]](a[420060]), wx[a[420061]]({}));
    } });
}, window[a[420062]] = function (woj4f) {
  console[a[420049]](a[420062], woj4f), wx[a[420051]]({ 'title': a[420052], 'content': woj4f, 'confirmText': a[420063], 'showCancel': ![], 'complete'(m3u65) {
      console[a[420049]](a[420060]), wx[a[420061]]({});
    } });
}, window['y2$50S'] = ![], window['y2$S50'] = function (y0zxer) {
  window['y2$50S'] = !![], wx[a[420064]](y0zxer);
}, window['y2$S05'] = function () {
  window['y2$50S'] && (window['y2$50S'] = ![], wx[a[420050]]({}));
}, window['y2$05S'] = function (thdw4j) {
  window[a[420065]][a[420066]]['y2$05S'](thdw4j);
}, window[a[420067]] = function (nk$g2, skl98c) {
  yfoh4wj[a[420067]](nk$g2, function (y0ze) {
    y0ze && y0ze[a[420068]] ? y0ze[a[420068]][a[420069]] == 0x1 ? skl98c(!![]) : (skl98c(![]), console[a[420070]](a[420071] + y0ze[a[420068]][a[420072]])) : console[a[420049]](a[420067], y0ze);
  });
}, window['y2$0S5'] = function (nc$9) {
  console[a[420049]](a[420073], nc$9);
}, window['y2$S0'] = function (dtmwu1) {}, window['y2$0S'] = function (dmtu15, y63vr, j7_of8) {}, window['y2$0'] = function (j_78f) {
  console[a[420049]](a[420074], j_78f), window[a[420065]][a[420066]][a[420075]](), window[a[420065]][a[420066]][a[420076]](), window[a[420065]][a[420066]][a[420077]]();
}, window['y20$'] = function (dmu15) {
  window['y2$5S0'](a[420078]);var du1ma = { 'id': window['y2S0'][a[420079]], 'role': window['y2S0'][a[420080]], 'level': window['y2S0'][a[420081]], 'account': window['y2S0'][a[420082]], 'version': window['y2S0'][a[420041]], 'cdn': window['y2S0'][a[420083]], 'pkgName': window['y2S0'][a[420024]], 'gamever': window[a[420002]][a[420003]], 'serverid': window['y2S0'][a[420030]] ? window['y2S0'][a[420030]][a[420084]] : 0x0, 'systemInfo': window[a[420085]], 'error': a[420086], 'stack': dmu15 ? dmu15 : a[420078] },
      fjoh7_ = JSON[a[420087]](du1ma);console[a[420088]](a[420089] + fjoh7_), window['y2$S'](fjoh7_);
}, window['y2S$0'] = function (csl9) {
  var _h = JSON[a[420090]](csl9);_h[a[420091]] = window[a[420002]][a[420003]], _h[a[420092]] = window['y2S0'][a[420030]] ? window['y2S0'][a[420030]][a[420084]] : 0x0, _h[a[420085]] = window[a[420085]];var ohjtw = JSON[a[420087]](_h);console[a[420088]](a[420093] + ohjtw), window['y2$S'](ohjtw);
}, window['y2S0$'] = function (d4tjw, yr3vz) {
  var n2k9g = { 'id': window['y2S0'][a[420079]], 'role': window['y2S0'][a[420080]], 'level': window['y2S0'][a[420081]], 'account': window['y2S0'][a[420082]], 'version': window['y2S0'][a[420041]], 'cdn': window['y2S0'][a[420083]], 'pkgName': window['y2S0'][a[420024]], 'gamever': window[a[420002]][a[420003]], 'serverid': window['y2S0'][a[420030]] ? window['y2S0'][a[420030]][a[420084]] : 0x0, 'systemInfo': window[a[420085]], 'error': d4tjw, 'stack': yr3vz },
      $2kgni = JSON[a[420087]](n2k9g);console[a[420094]](a[420095] + $2kgni), window['y2$S']($2kgni);
}, window['y2$S'] = function (xzye) {
  if (window['y2S0'][a[420096]] == a[420097]) return;var clsk98 = y2S0['y2$S'] + a[420098] + y2S0[a[420082]];wx[a[420099]]({ 'url': clsk98, 'method': a[420100], 'data': xzye, 'header': { 'content-type': a[420101], 'cache-control': a[420102] }, 'success': function (sl8ck9) {
      DEBUG && console[a[420049]](a[420103], clsk98, xzye, sl8ck9);
    }, 'fail': function (m5a63u) {
      DEBUG && console[a[420049]](a[420103], clsk98, xzye, m5a63u);
    }, 'complete': function () {} });
}, window[a[420104]] = function () {
  function d1m5t() {
    return ((0x1 + Math[a[420105]]()) * 0x10000 | 0x0)[a[420106]](0x10)[a[420107]](0x1);
  }return d1m5t() + d1m5t() + '-' + d1m5t() + '-' + d1m5t() + '-' + d1m5t() + '+' + d1m5t() + d1m5t() + d1m5t();
}, window['y2S$'] = function () {
  console[a[420049]](a[420108]);var v56ma = yfoh4wj[a[420109]]();y2S0[a[420029]] = v56ma[a[420110]], y2S0[a[420028]] = v56ma[a[420110]], y2S0[a[420023]] = v56ma[a[420110]], y2S0[a[420024]] = v56ma[a[420111]];var udw14t = { 'game_ver': y2S0[a[420010]] };y2S0[a[420025]] = this[a[420104]](), y2$S50({ 'title': a[420112] }), yfoh4wj[a[420113]](udw14t, this['y20$S'][a[420114]](this));
}, window['y20$S'] = function (d4ut1) {
  var fwoh4j = d4ut1[a[420115]];console[a[420049]](a[420116] + fwoh4j + a[420117] + (fwoh4j == 0x1) + a[420118] + d4ut1[a[420003]] + a[420119] + window[a[420001]][a[420011]]);if (!d4ut1[a[420003]] || window['y2950$S'](window[a[420001]][a[420011]], d4ut1[a[420003]]) < 0x0) console[a[420049]](a[420120]), y2S0[a[420015]] = a[420121], y2S0[a[420017]] = a[420122], y2S0[a[420019]] = a[420123], y2S0[a[420083]] = a[420124], y2S0[a[420125]] = a[420126], y2S0[a[420127]] = 'yy', y2S0[a[420042]] = ![];else window['y2950$S'](window[a[420001]][a[420011]], d4ut1[a[420003]]) == 0x0 ? (console[a[420049]](a[420128]), y2S0[a[420015]] = a[420016], y2S0[a[420017]] = a[420018], y2S0[a[420019]] = a[420020], y2S0[a[420083]] = a[420129], y2S0[a[420125]] = a[420126], y2S0[a[420127]] = a[420130], y2S0[a[420042]] = !![]) : (console[a[420049]](a[420131]), y2S0[a[420015]] = a[420016], y2S0[a[420017]] = a[420018], y2S0[a[420019]] = a[420020], y2S0[a[420083]] = a[420129], y2S0[a[420125]] = a[420126], y2S0[a[420127]] = a[420130], y2S0[a[420042]] = ![]);y2S0[a[420026]] = config[a[420132]] ? config[a[420132]] : 0x0, this['y25S$0'](), this['y25S0$'](), window[a[420133]] = 0x5, y2$S50({ 'title': a[420134] }), yfoh4wj[a[420135]](this['y20S$'][a[420114]](this));
}, window[a[420133]] = 0x5, window['y20S$'] = function (i2$kn, au15md) {
  if (i2$kn == 0x0 && au15md && au15md[a[420136]]) {
    y2S0[a[420137]] = au15md[a[420136]];var u653am = this;y2$S50({ 'title': a[420138] }), sendApi(y2S0[a[420015]], a[420139], { 'platform': y2S0[a[420013]], 'partner_id': y2S0[a[420023]], 'token': au15md[a[420136]], 'game_pkg': y2S0[a[420024]], 'deviceId': y2S0[a[420025]], 'scene': a[420140] + y2S0[a[420026]] }, this['y25$S0'][a[420114]](this), y250S, y20$);
  } else au15md && au15md[a[420141]] && window[a[420133]] > 0x0 && (au15md[a[420141]][a[420142]](a[420143]) != -0x1 || au15md[a[420141]][a[420142]](a[420144]) != -0x1 || au15md[a[420141]][a[420142]](a[420145]) != -0x1 || au15md[a[420141]][a[420142]](a[420146]) != -0x1 || au15md[a[420141]][a[420142]](a[420147]) != -0x1 || au15md[a[420141]][a[420142]](a[420148]) != -0x1) ? (window[a[420133]]--, yfoh4wj[a[420135]](this['y20S$'][a[420114]](this))) : (window['y2S0$'](a[420149], JSON[a[420087]]({ 'status': i2$kn, 'data': au15md })), window['y2$5S0'](a[420150] + (au15md && au15md[a[420141]] ? '，' + au15md[a[420141]] : '')));
}, window['y25$S0'] = function (c$29k) {
  if (!c$29k) {
    window['y2S0$'](a[420151], a[420152]), window['y2$5S0'](a[420153]);return;
  }if (c$29k[a[420069]] != a[420154]) {
    window['y2S0$'](a[420151], JSON[a[420087]](c$29k)), window['y2$5S0'](a[420155] + c$29k[a[420069]]);return;
  }y2S0[a[420156]] = String(c$29k[a[420082]]), y2S0[a[420082]] = String(c$29k[a[420082]]), y2S0[a[420157]] = String(c$29k[a[420157]]), y2S0[a[420029]] = String(c$29k[a[420157]]), y2S0[a[420158]] = String(c$29k[a[420158]]), y2S0[a[420159]] = String(c$29k[a[420160]]), y2S0[a[420161]] = String(c$29k[a[420162]]), y2S0[a[420160]] = '';var j7of8 = this;y2$S50({ 'title': a[420163] }), sendApi(y2S0[a[420015]], a[420164], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, j7of8['y25$0S'][a[420114]](j7of8), y250S, y20$);
}, window['y25$0S'] = function (fl) {
  if (!fl) {
    window['y2$5S0'](a[420165]);return;
  }if (fl[a[420069]] != a[420154]) {
    window['y2$5S0'](a[420166] + fl[a[420069]]);return;
  }if (!fl[a[420068]] || fl[a[420068]][a[420167]] == 0x0) {
    window['y2$5S0'](a[420168]);return;
  }y2S0[a[420169]] = fl[a[420170]], y2S0[a[420030]] = { 'server_id': String(fl[a[420068]][0x0][a[420084]]), 'server_name': String(fl[a[420068]][0x0][a[420171]]), 'entry_ip': fl[a[420068]][0x0][a[420172]], 'entry_port': parseInt(fl[a[420068]][0x0][a[420173]]), 'status': y2S5$(fl[a[420068]][0x0]), 'start_time': fl[a[420068]][0x0][a[420174]], 'cdn': y2S0[a[420083]] }, this['y20S5$']();
}, window['y20S5$'] = function () {
  if (y2S0[a[420169]] == 0x1) {
    var va36y0 = y2S0[a[420030]][a[420175]];if (va36y0 === -0x1 || va36y0 === 0x0) {
      window['y2$5S0'](va36y0 === -0x1 ? a[420176] : a[420177]);return;
    }y20$5S(0x0, y2S0[a[420030]][a[420084]]), window[a[420065]][a[420066]][a[420178]](y2S0[a[420169]]);
  } else window[a[420065]][a[420066]][a[420179]](), y2$S05();window['y2S5'] = !![], window['y205S$'](), window['y20S$5']();
}, window['y25S$0'] = function () {
  sendApi(y2S0[a[420015]], a[420180], { 'game_pkg': y2S0[a[420024]], 'version_name': y2S0[a[420127]] }, this[a[420181]][a[420114]](this), y250S, y20$);
}, window[a[420181]] = function (o78jf_) {
  if (!o78jf_) {
    window['y2$5S0'](a[420182]);return;
  }if (o78jf_[a[420069]] != a[420154]) {
    window['y2$5S0'](a[420183] + o78jf_[a[420069]]);return;
  }if (!o78jf_[a[420068]] || !o78jf_[a[420068]][a[420010]]) {
    window['y2$5S0'](a[420184] + (o78jf_[a[420068]] && o78jf_[a[420068]][a[420010]]));return;
  }o78jf_[a[420068]][a[420185]] && o78jf_[a[420068]][a[420185]][a[420167]] > 0xa && (y2S0[a[420186]] = o78jf_[a[420068]][a[420185]], y2S0[a[420083]] = o78jf_[a[420068]][a[420185]]), o78jf_[a[420068]][a[420010]] && (y2S0[a[420041]] = o78jf_[a[420068]][a[420010]]), console[a[420070]](a[420187] + y2S0[a[420041]] + a[420188] + y2S0[a[420127]]), window['y2S05'] = !![], window['y205S$'](), window['y20S$5']();
}, window[a[420189]], window['y25S0$'] = function () {
  sendApi(y2S0[a[420015]], a[420190], { 'game_pkg': y2S0[a[420024]] }, this['y250$S'][a[420114]](this), y250S, y20$);
}, window['y250$S'] = function (owj4f) {
  if (owj4f[a[420069]] === a[420154] && owj4f[a[420068]]) {
    window[a[420189]] = owj4f[a[420068]];for (var ck29 in owj4f[a[420068]]) {
      y2S0[ck29] = owj4f[a[420068]][ck29];
    }
  } else console[a[420070]](a[420191] + owj4f[a[420069]]);window['y25S'] = !![], window['y20S$5']();
}, window[a[420192]] = function (npg$iq, l2csk9, s8l, erzxy, hwfjo4, re0xy, jwho4, twjd4h, n$9kc2) {
  hwfjo4 = String(hwfjo4);var yvrz30 = jwho4,
      m5ua16 = twjd4h;y2S0[a[420008]][hwfjo4] = { 'productid': hwfjo4, 'productname': yvrz30, 'productdesc': m5ua16, 'roleid': npg$iq, 'rolename': l2csk9, 'rolelevel': s8l, 'price': re0xy, 'callback': n$9kc2 }, sendApi(y2S0[a[420019]], a[420193], { 'game_pkg': y2S0[a[420024]], 'server_id': y2S0[a[420030]][a[420084]], 'server_name': y2S0[a[420030]][a[420171]], 'level': s8l, 'uid': y2S0[a[420082]], 'role_id': npg$iq, 'role_name': l2csk9, 'product_id': hwfjo4, 'product_name': yvrz30, 'product_desc': m5ua16, 'money': re0xy, 'partner_id': y2S0[a[420023]] }, toPayCallBack, y250S, y20$);
}, window[a[420194]] = function (wdm1ut) {
  if (wdm1ut) {
    if (wdm1ut[a[420195]] === 0xc8 || wdm1ut[a[420069]] == a[420154]) {
      var a653u = y2S0[a[420008]][String(wdm1ut[a[420196]])];if (a653u[a[420197]]) a653u[a[420197]](wdm1ut[a[420196]], wdm1ut[a[420198]], -0x1);yfoh4wj[a[420199]]({ 'cpbill': wdm1ut[a[420198]], 'productid': wdm1ut[a[420196]], 'productname': a653u[a[420200]], 'productdesc': a653u[a[420201]], 'serverid': y2S0[a[420030]][a[420084]], 'servername': y2S0[a[420030]][a[420171]], 'roleid': a653u[a[420202]], 'rolename': a653u[a[420203]], 'rolelevel': a653u[a[420204]], 'price': a653u[a[420205]], 'extension': JSON[a[420087]]({ 'cp_order_id': wdm1ut[a[420198]] }) }, function (qi$2g, y6a30v) {
        a653u[a[420197]] && qi$2g == 0x0 && a653u[a[420197]](wdm1ut[a[420196]], wdm1ut[a[420198]], qi$2g);console[a[420070]](JSON[a[420087]]({ 'type': a[420206], 'status': qi$2g, 'data': wdm1ut, 'role_name': a653u[a[420203]] }));if (qi$2g === 0x0) {} else {
          if (qi$2g === 0x1) {} else {
            if (qi$2g === 0x2) {}
          }
        }
      });
    } else alert(wdm1ut[a[420070]]);
  }
}, window['y250S$'] = function () {}, window['y2$50'] = function (owjf4, s92cnk, jh4f_o, t1muwd, klc9) {
  yfoh4wj[a[420207]](y2S0[a[420030]][a[420084]], y2S0[a[420030]][a[420171]] || y2S0[a[420030]][a[420084]], owjf4, s92cnk, jh4f_o), sendApi(y2S0[a[420015]], a[420208], { 'game_pkg': y2S0[a[420024]], 'server_id': y2S0[a[420030]][a[420084]], 'role_id': owjf4, 'uid': y2S0[a[420082]], 'role_name': s92cnk, 'role_type': t1muwd, 'level': jh4f_o });
}, window['y2$05'] = function (g$q, _7s8, fo_78j, k$9c2n, _7lfo8, h4d, _f78ls, cs8l7, ojwt4, d15am) {
  y2S0[a[420079]] = g$q, y2S0[a[420080]] = _7s8, y2S0[a[420081]] = fo_78j, yfoh4wj[a[420209]](y2S0[a[420030]][a[420084]], y2S0[a[420030]][a[420171]] || y2S0[a[420030]][a[420084]], g$q, _7s8, fo_78j), sendApi(y2S0[a[420015]], a[420210], { 'game_pkg': y2S0[a[420024]], 'server_id': y2S0[a[420030]][a[420084]], 'role_id': g$q, 'uid': y2S0[a[420082]], 'role_name': _7s8, 'role_type': k$9c2n, 'level': fo_78j, 'evolution': _7lfo8 });
}, window['y25$0'] = function (dut4, skc8l, s7_c8l, dwtm, admu1, _lo7, rxez0y, k9g2n$, yr63v0, mau3) {
  y2S0[a[420079]] = dut4, y2S0[a[420080]] = skc8l, y2S0[a[420081]] = s7_c8l, yfoh4wj[a[420211]](y2S0[a[420030]][a[420084]], y2S0[a[420030]][a[420171]] || y2S0[a[420030]][a[420084]], dut4, skc8l, s7_c8l), sendApi(y2S0[a[420015]], a[420210], { 'game_pkg': y2S0[a[420024]], 'server_id': y2S0[a[420030]][a[420084]], 'role_id': dut4, 'uid': y2S0[a[420082]], 'role_name': skc8l, 'role_type': dwtm, 'level': s7_c8l, 'evolution': admu1 });
}, window['y250$'] = function (m1au5) {}, window['y2$5'] = function (kcn92$) {
  yfoh4wj[a[420212]](a[420212], function (hf_7jo) {
    kcn92$ && kcn92$(hf_7jo);
  });
}, window[a[420213]] = function () {
  yfoh4wj[a[420213]]();
}, window[a[420214]] = function () {
  yfoh4wj[a[420215]]();
}, window[a[420216]] = function (vz30ry, l_sf87, lf, _fho4j, k9csn, n2qi$g, cskn29, vyr0z3) {
  vyr0z3 = vyr0z3 || y2S0[a[420030]][a[420084]], sendApi(y2S0[a[420015]], a[420217], { 'phone': vz30ry, 'role_id': l_sf87, 'uid': y2S0[a[420082]], 'game_pkg': y2S0[a[420024]], 'partner_id': y2S0[a[420023]], 'server_id': vyr0z3 }, cskn29);
}, window[a[420218]] = function (hj4o_) {
  window['y20$5'] = hj4o_, window['y20$5'] && window['y25$'] && (console[a[420070]](a[420219] + window['y25$'][a[420220]]), window['y20$5'](window['y25$']), window['y25$'] = null);
}, window['y205$'] = function (fjohw4, gik$n2, l_f78o, to4hjw) {
  window[a[420221]](a[420222], { 'game_pkg': window['y2S0'][a[420024]], 'role_id': gik$n2, 'server_id': l_f78o }, to4hjw);
}, window['y2S$50'] = function (qg$npi, k9$n) {
  function l8fs_(lcsk89) {
    var ginp$ = [],
        ohwfj = [],
        $q2ng = window[a[420002]][a[420223]];for (var _of4hj in $q2ng) {
      var rv03 = Number(_of4hj);(!qg$npi || !qg$npi[a[420167]] || qg$npi[a[420142]](rv03) != -0x1) && (ohwfj[a[420224]]($q2ng[_of4hj]), ginp$[a[420224]]([rv03, 0x3]));
    }window['y2950$S'](window[a[420225]], a[420226]) >= 0x0 ? (console[a[420049]](a[420227]), yfoh4wj[a[420228]] && yfoh4wj[a[420228]](ohwfj, function (hfj4wo) {
      console[a[420049]](a[420229]), console[a[420049]](hfj4wo);if (hfj4wo && hfj4wo[a[420141]] == a[420230]) for (var dau51 in $q2ng) {
        if (hfj4wo[$q2ng[dau51]] == a[420231]) {
          var ojwh4 = Number(dau51);for (var oth4j = 0x0; oth4j < ginp$[a[420167]]; oth4j++) {
            if (ginp$[oth4j][0x0] == ojwh4) {
              ginp$[oth4j][0x1] = 0x1;break;
            }
          }
        }
      }window['y2950$S'](window[a[420225]], a[420232]) >= 0x0 ? wx[a[420233]]({ 'withSubscriptions': !![], 'success': function (whjt4d) {
          var $knc = whjt4d[a[420234]][a[420235]];if ($knc) {
            console[a[420049]](a[420236]), console[a[420049]]($knc);for (var y3r6 in $q2ng) {
              if ($knc[$q2ng[y3r6]] == a[420231]) {
                var f_78ls = Number(y3r6);for (var a3v56m = 0x0; a3v56m < ginp$[a[420167]]; a3v56m++) {
                  if (ginp$[a3v56m][0x0] == f_78ls) {
                    ginp$[a3v56m][0x1] = 0x2;break;
                  }
                }
              }
            }console[a[420049]](ginp$), k9$n && k9$n(ginp$);
          } else console[a[420049]](a[420237]), console[a[420049]](whjt4d), console[a[420049]](ginp$), k9$n && k9$n(ginp$);
        }, 'fail': function () {
          console[a[420049]](a[420238]), console[a[420049]](ginp$), k9$n && k9$n(ginp$);
        } }) : (console[a[420049]](a[420239] + window[a[420225]]), console[a[420049]](ginp$), k9$n && k9$n(ginp$));
    })) : (console[a[420049]](a[420240] + window[a[420225]]), console[a[420049]](ginp$), k9$n && k9$n(ginp$)), wx[a[420241]](l8fs_);
  }wx[a[420242]](l8fs_);
}, window['y2S$05'] = { 'isSuccess': ![], 'level': a[420243], 'isCharging': ![] }, window['y2S5$0'] = function (jt4hd) {
  wx[a[420244]]({ 'success': function (c79sl8) {
      var o7_j8f = window['y2S$05'];o7_j8f[a[420245]] = !![], o7_j8f[a[420246]] = Number(c79sl8[a[420246]])[a[420247]](0x0), o7_j8f[a[420248]] = c79sl8[a[420248]], jt4hd && jt4hd(o7_j8f[a[420245]], o7_j8f[a[420246]], o7_j8f[a[420248]]);
    }, 'fail': function (h7_fjo) {
      console[a[420049]](a[420249], h7_fjo[a[420141]]);var jwh4dt = window['y2S$05'];jt4hd && jt4hd(jwh4dt[a[420245]], jwh4dt[a[420246]], jwh4dt[a[420248]]);
    } });
}, window[a[420221]] = function (dmua1, wdu1t4, jwto, xvry0z, d4jhtw, hdt41w, f7_8ol, tw1u) {
  if (xvry0z == undefined) xvry0z = 0x1;wx[a[420099]]({ 'url': dmua1, 'method': f7_8ol || a[420250], 'responseType': a[420251], 'data': wdu1t4, 'header': { 'content-type': tw1u || a[420101] }, 'success': function (p$qgin) {
      DEBUG && console[a[420049]](a[420252], dmua1, info, p$qgin);if (p$qgin && p$qgin[a[420253]] == 0xc8) {
        var h_7fjo = p$qgin[a[420068]];!hdt41w || hdt41w(h_7fjo) ? jwto && jwto(h_7fjo) : window[a[420254]](dmua1, wdu1t4, jwto, xvry0z, d4jhtw, hdt41w, p$qgin);
      } else window[a[420254]](dmua1, wdu1t4, jwto, xvry0z, d4jhtw, hdt41w, p$qgin);
    }, 'fail': function (jho4) {
      DEBUG && console[a[420049]](a[420255], dmua1, info, jho4), window[a[420254]](dmua1, wdu1t4, jwto, xvry0z, d4jhtw, hdt41w, jho4);
    }, 'complete': function () {} });
}, window[a[420254]] = function ($ipqn, _hj4f, w1t4hd, w4th, m51dut, yx0r, j_foh7) {
  w4th - 0x1 > 0x0 ? setTimeout(function () {
    window[a[420221]]($ipqn, _hj4f, w1t4hd, w4th - 0x1, m51dut, yx0r);
  }, 0x3e8) : m51dut && m51dut(JSON[a[420087]]({ 'url': $ipqn, 'response': j_foh7 }));
}, window[a[420256]] = function (c9k8ls, qgn$2, wudmt1, d1u4tw, a15, vxryz0, _j78o) {
  !wudmt1 && (wudmt1 = {});var v360ry = Math[a[420257]](Date[a[420036]]() / 0x3e8);wudmt1[a[420162]] = v360ry, wudmt1[a[420258]] = qgn$2;var s98cl = Object[a[420259]](wudmt1)[a[420260]](),
      zyrxv0 = '',
      ohjw = '';for (var jtwd4 = 0x0; jtwd4 < s98cl[a[420167]]; jtwd4++) {
    zyrxv0 = zyrxv0 + (jtwd4 == 0x0 ? '' : '&') + s98cl[jtwd4] + wudmt1[s98cl[jtwd4]], ohjw = ohjw + (jtwd4 == 0x0 ? '' : '&') + s98cl[jtwd4] + '=' + encodeURIComponent(wudmt1[s98cl[jtwd4]]);
  }zyrxv0 = zyrxv0 + y2S0[a[420021]];var r0yzv3 = a[420261] + md5(zyrxv0);send(c9k8ls + '?' + ohjw + (ohjw == '' ? '' : '&') + r0yzv3, null, d1u4tw, a15, vxryz0, _j78o || function (s_87lc) {
    return s_87lc[a[420069]] == a[420154];
  }, null, a[420262]);
}, window['y2S50$'] = function (xvy0zr, ry0ezx) {
  var fjho4w = 0x0;y2S0[a[420030]] && (fjho4w = y2S0[a[420030]][a[420084]]), sendApi(y2S0[a[420017]], a[420263], { 'partnerId': y2S0[a[420023]], 'gamePkg': y2S0[a[420024]], 'logTime': Math[a[420257]](Date[a[420036]]() / 0x3e8), 'platformUid': y2S0[a[420158]], 'type': xvy0zr, 'serverId': fjho4w }, null, 0x2, null, function () {
    return !![];
  });
}, window['y2S0$5'] = function (cl29k) {
  sendApi(y2S0[a[420015]], a[420264], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, y2S05$, y250S, y20$);
}, window['y2S05$'] = function (wt14ud) {
  if (wt14ud[a[420069]] === a[420154] && wt14ud[a[420068]]) {
    wt14ud[a[420068]][a[420265]]({ 'id': -0x2, 'name': a[420266] }), wt14ud[a[420068]][a[420265]]({ 'id': -0x1, 'name': a[420267] }), y2S0[a[420268]] = wt14ud[a[420068]];if (window[a[420269]]) window[a[420269]][a[420270]]();
  } else y2S0[a[420271]] = ![], window['y2$5S0'](a[420272] + wt14ud[a[420069]]);
}, window['y2$5S'] = function (ud1t5) {
  sendApi(y2S0[a[420015]], a[420273], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, y2$S5, y250S, y20$);
}, window['y2$S5'] = function (w4u1td) {
  y2S0[a[420274]] = ![];if (w4u1td[a[420069]] === a[420154] && w4u1td[a[420068]]) {
    for (var av65m3 = 0x0; av65m3 < w4u1td[a[420068]][a[420167]]; av65m3++) {
      w4u1td[a[420068]][av65m3][a[420175]] = y2S5$(w4u1td[a[420068]][av65m3]);
    }y2S0[a[420027]][-0x1] = window[a[420275]](w4u1td[a[420068]]), window[a[420269]][a[420276]](-0x1);
  } else window['y2$5S0'](a[420277] + w4u1td[a[420069]]);
}, window[a[420278]] = function (md1tu) {
  sendApi(y2S0[a[420015]], a[420273], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, md1tu, y250S, y20$);
}, window['y25$S'] = function (rvzxy0, _h4jo) {
  sendApi(y2S0[a[420015]], a[420279], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]], 'server_group_id': _h4jo }, y25S$, y250S, y20$);
}, window['y25S$'] = function (l8_s7c) {
  y2S0[a[420274]] = ![];if (l8_s7c[a[420069]] === a[420154] && l8_s7c[a[420068]] && l8_s7c[a[420068]][a[420068]]) {
    var wt4ojh = l8_s7c[a[420068]][a[420280]],
        hdwj4 = [];for (var owjth4 = 0x0; owjth4 < l8_s7c[a[420068]][a[420068]][a[420167]]; owjth4++) {
      l8_s7c[a[420068]][a[420068]][owjth4][a[420175]] = y2S5$(l8_s7c[a[420068]][a[420068]][owjth4]), (hdwj4[a[420167]] == 0x0 || l8_s7c[a[420068]][a[420068]][owjth4][a[420175]] != 0x0) && (hdwj4[hdwj4[a[420167]]] = l8_s7c[a[420068]][a[420068]][owjth4]);
    }y2S0[a[420027]][wt4ojh] = window[a[420275]](hdwj4), window[a[420269]][a[420276]](wt4ojh);
  } else window['y2$5S0'](a[420281] + l8_s7c[a[420069]]);
}, window['y2950S'] = function (n$g) {
  sendApi(y2S0[a[420015]], a[420282], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, reqServerRecommendCallBack, y250S, y20$);
}, window[a[420283]] = function (w14th) {
  y2S0[a[420274]] = ![];if (w14th[a[420069]] === a[420154] && w14th[a[420068]]) {
    for (var dh1t = 0x0; dh1t < w14th[a[420068]][a[420167]]; dh1t++) {
      w14th[a[420068]][dh1t][a[420175]] = y2S5$(w14th[a[420068]][dh1t]);
    }y2S0[a[420027]][-0x2] = window[a[420275]](w14th[a[420068]]), window[a[420269]][a[420276]](-0x2);
  } else alert(a[420284] + w14th[a[420069]]);
}, window[a[420275]] = function (v3y56) {
  if (!v3y56 && v3y56[a[420167]] <= 0x0) return v3y56;for (let r03vy6 = 0x0; r03vy6 < v3y56[a[420167]]; r03vy6++) {
    v3y56[r03vy6][a[420285]] && v3y56[r03vy6][a[420285]] == 0x1 && (v3y56[r03vy6][a[420171]] += a[420286]);
  }return v3y56;
}, window['y2S$5'] = function (ojwh4t, mu165) {
  ojwh4t = ojwh4t || y2S0[a[420030]][a[420084]], sendApi(y2S0[a[420015]], a[420287], { 'type': '4', 'game_pkg': y2S0[a[420024]], 'server_id': ojwh4t }, mu165);
}, window[a[420288]] = function (u1wd, j_o8f, xyez0, fhj4) {
  xyez0 = xyez0 || y2S0[a[420030]][a[420084]], sendApi(y2S0[a[420015]], a[420289], { 'type': u1wd, 'game_pkg': j_o8f, 'server_id': xyez0 }, fhj4);
}, window['y2S5$'] = function (o7l8f) {
  if (o7l8f) {
    if (o7l8f[a[420175]] == 0x1) {
      if (o7l8f[a[420290]] == 0x1) return 0x2;else return 0x1;
    } else return o7l8f[a[420175]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['y20$5S'] = function (vzr3y, ma563) {
  y2S0[a[420291]] = { 'step': vzr3y, 'server_id': ma563 };var l7_cs8 = this;y2$S50({ 'title': a[420292] }), sendApi(y2S0[a[420015]], a[420293], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'game_pkg': y2S0[a[420024]], 'server_id': ma563, 'platform': y2S0[a[420157]], 'platform_uid': y2S0[a[420158]], 'check_login_time': y2S0[a[420161]], 'check_login_sign': y2S0[a[420159]], 'version_name': y2S0[a[420127]] }, y20$S5, y250S, y20$, function (umd) {
    return umd[a[420069]] == a[420154] || umd[a[420070]] == a[420294] || umd[a[420070]] == a[420295];
  });
}, window['y20$S5'] = function (k9scl) {
  var ipn$qg = this;if (k9scl[a[420069]] === a[420154] && k9scl[a[420068]]) {
    var l8ks9c = y2S0[a[420030]];l8ks9c[a[420296]] = y2S0[a[420028]], l8ks9c[a[420160]] = String(k9scl[a[420068]][a[420297]]), l8ks9c[a[420035]] = parseInt(k9scl[a[420068]][a[420162]]);if (k9scl[a[420068]][a[420298]]) l8ks9c[a[420298]] = parseInt(k9scl[a[420068]][a[420298]]);else l8ks9c[a[420298]] = parseInt(k9scl[a[420068]][a[420084]]);l8ks9c[a[420299]] = 0x0, l8ks9c[a[420083]] = y2S0[a[420186]], l8ks9c[a[420300]] = k9scl[a[420068]][a[420301]], l8ks9c[a[420302]] = k9scl[a[420068]][a[420302]], console[a[420049]](a[420303] + JSON[a[420087]](l8ks9c[a[420302]])), y2S0[a[420169]] == 0x1 && l8ks9c[a[420302]] && l8ks9c[a[420302]][a[420304]] == 0x1 && (y2S0[a[420305]] = 0x1, window[a[420065]][a[420066]]['y290S']()), y205$S();
  } else y2S0[a[420291]][a[420306]] >= 0x3 ? (y20$(JSON[a[420087]](k9scl)), window['y2$5S0'](a[420307] + k9scl[a[420069]])) : sendApi(y2S0[a[420015]], a[420139], { 'platform': y2S0[a[420013]], 'partner_id': y2S0[a[420023]], 'token': y2S0[a[420137]], 'game_pkg': y2S0[a[420024]], 'deviceId': y2S0[a[420025]], 'scene': a[420140] + y2S0[a[420026]] }, function (kc9l2) {
    if (!kc9l2 || kc9l2[a[420069]] != a[420154]) {
      window['y2$5S0'](a[420155] + kc9l2 && kc9l2[a[420069]]);return;
    }y2S0[a[420159]] = String(kc9l2[a[420160]]), y2S0[a[420161]] = String(kc9l2[a[420162]]), setTimeout(function () {
      y20$5S(y2S0[a[420291]][a[420306]] + 0x1, y2S0[a[420291]][a[420084]]);
    }, 0x5dc);
  }, y250S, y20$, function (z3y0r) {
    return z3y0r[a[420069]] == a[420154] || z3y0r[a[420069]] == a[420308];
  });
}, window['y205$S'] = function () {
  ServerLoading[a[420066]][a[420178]](y2S0[a[420169]]), window['y250'] = !![], window['y20S$5']();
}, window['y205S$'] = function () {
  if (window['y205'] && window['y2S50'] && window[a[420046]] && window[a[420047]] && window['y2S05'] && window['y2S5']) {
    if (!window[a[420309]][a[420066]]) {
      console[a[420049]](a[420310] + window[a[420309]][a[420066]]);var s7c98 = wx[a[420311]](),
          wjt4d = s7c98[a[420220]] ? s7c98[a[420220]] : 0x0,
          _joh4 = { 'cdn': window['y2S0'][a[420083]], 'spareCdn': window['y2S0'][a[420125]], 'newRegister': window['y2S0'][a[420169]], 'wxPC': window['y2S0'][a[420045]], 'wxIOS': window['y2S0'][a[420043]], 'wxAndroid': window['y2S0'][a[420044]], 'wxParam': { 'limitLoad': window['y2S0']['y29$50S'], 'benchmarkLevel': window['y2S0']['y29$S50'], 'wxFrom': window[a[420002]][a[420132]] == a[420312] ? 0x1 : 0x0, 'wxSDKVersion': window[a[420225]] }, 'configType': window['y2S0'][a[420037]], 'exposeType': window['y2S0'][a[420039]], 'scene': wjt4d };new window[a[420309]](_joh4, window['y2S0'][a[420041]], window['y29$5S0']);
    }
  }
}, window['y20S$5'] = function () {
  if (window['y205'] && window['y2S50'] && window[a[420046]] && window[a[420047]] && window['y2S05'] && window['y2S5'] && window['y250'] && window['y25S']) {
    y2$S05();if (!y205S) {
      y205S = !![];if (!window[a[420309]][a[420066]]) window['y205S$']();var hfoj4w = 0x0,
          sc29kl = wx[a[420313]]();sc29kl && (window['y2S0'][a[420314]] && (hfoj4w = sc29kl[a[420315]]), console[a[420070]](a[420316] + sc29kl[a[420315]] + a[420317] + sc29kl[a[420318]] + a[420319] + sc29kl[a[420320]] + a[420321] + sc29kl[a[420322]] + a[420323] + sc29kl[a[420324]] + a[420325] + sc29kl[a[420326]]));var k$2c9 = {};for (const l89csk in y2S0[a[420030]]) {
        k$2c9[l89csk] = y2S0[a[420030]][l89csk];
      }var nk$ig2 = { 'channel': window['y2S0'][a[420029]], 'account': window['y2S0'][a[420082]], 'userId': window['y2S0'][a[420156]], 'cdn': window['y2S0'][a[420083]], 'data': window['y2S0'][a[420068]], 'package': window['y2S0'][a[420009]], 'newRegister': window['y2S0'][a[420169]], 'pkgName': window['y2S0'][a[420024]], 'partnerId': window['y2S0'][a[420023]], 'platform_uid': window['y2S0'][a[420158]], 'deviceId': window['y2S0'][a[420025]], 'selectedServer': k$2c9, 'configType': window['y2S0'][a[420037]], 'exposeType': window['y2S0'][a[420039]], 'debugUsers': window['y2S0'][a[420033]], 'wxMenuTop': hfoj4w, 'wxShield': window['y2S0'][a[420042]] };if (window[a[420189]]) for (var $ingq in window[a[420189]]) {
        nk$ig2[$ingq] = window[a[420189]][$ingq];
      }window[a[420309]][a[420066]]['y20S9'](nk$ig2);
    }
  } else console[a[420070]](a[420327] + window['y205'] + a[420328] + window['y2S50'] + a[420329] + window[a[420046]] + a[420330] + window[a[420047]] + a[420331] + window['y2S05'] + a[420332] + window['y2S5'] + a[420333] + window['y250'] + a[420334] + window['y25S']);
};