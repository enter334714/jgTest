var a = wx.$y;
console[a[420070]](a[420335]), window[a[420336]], wx[a[420337]](function (_7lcs) {
  if (_7lcs) {
    if (_7lcs[a[420338]]) {
      var _h4 = window[a[420002]][a[420003]][a[420339]](new RegExp(/\./, 'g'), '_'),
          wmdut = _7lcs[a[420338]],
          u4d1wt = wmdut[a[420340]](/(yyyyy\/yyGAMEy.js:)[0-9]{1,60}(:)/g);if (u4d1wt) for (var a5u63m = 0x0; a5u63m < u4d1wt[a[420167]]; a5u63m++) {
        if (u4d1wt[a5u63m] && u4d1wt[a5u63m][a[420167]] > 0x0) {
          var xyre0z = parseInt(u4d1wt[a5u63m][a[420339]](a[420341], '')[a[420339]](':', ''));wmdut = wmdut[a[420339]](u4d1wt[a5u63m], u4d1wt[a5u63m][a[420339]](':' + xyre0z + ':', ':' + (xyre0z - 0x2) + ':'));
        }
      }wmdut = wmdut[a[420339]](new RegExp(a[420342], 'g'), a[420343] + _h4 + a[420344]), wmdut = wmdut[a[420339]](new RegExp(a[420345], 'g'), a[420343] + _h4 + a[420344]), _7lcs[a[420338]] = wmdut;
    }var t4dwu = { 'id': window['y2S0'][a[420079]], 'role': window['y2S0'][a[420080]], 'level': window['y2S0'][a[420081]], 'user': window['y2S0'][a[420082]], 'version': window['y2S0'][a[420041]], 'cdn': window['y2S0'][a[420083]], 'pkgName': window['y2S0'][a[420024]], 'gamever': window[a[420002]][a[420003]], 'serverid': window['y2S0'][a[420030]] ? window['y2S0'][a[420030]][a[420084]] : 0x0, 'systemInfo': window[a[420085]], 'error': a[420346], 'stack': _7lcs ? _7lcs[a[420338]] : '' },
        g$k2n9 = JSON[a[420087]](t4dwu);console[a[420088]](a[420347] + g$k2n9), (!window[a[420336]] || window[a[420336]] != t4dwu[a[420088]]) && (window[a[420336]] = t4dwu[a[420088]], window['y2$S'](t4dwu));
  }
});import 'yybfyy.js';import 'yy11yy.js';window[a[420348]] = require(a[420349]);import 'yINDyy.js';import 'yyIB1yy.js';import 'yyMtadyy.js';import 'yyINIyy.js';console[a[420070]](a[420350]), console[a[420070]](a[420351]), y2$S50({ 'title': a[420352] });var y$ik2g = { 'y29$0S5': !![] };new window[a[420065]](y$ik2g), window[a[420065]][a[420066]]['y295S0$']();if (window['y29$S05']) clearInterval(window['y29$S05']);window['y29$S05'] = null, window['y2950$S'] = function (wd14ut, k2cn$9) {
  if (!wd14ut || !k2cn$9) return 0x0;wd14ut = wd14ut[a[420353]]('.'), k2cn$9 = k2cn$9[a[420353]]('.');const a61u5m = Math[a[420354]](wd14ut[a[420167]], k2cn$9[a[420167]]);while (wd14ut[a[420167]] < a61u5m) {
    wd14ut[a[420224]]('0');
  }while (k2cn$9[a[420167]] < a61u5m) {
    k2cn$9[a[420224]]('0');
  }for (var gpqi$ = 0x0; gpqi$ < a61u5m; gpqi$++) {
    const d5a1u = parseInt(wd14ut[gpqi$]),
          _h7fj = parseInt(k2cn$9[gpqi$]);if (d5a1u > _h7fj) return 0x1;else {
      if (d5a1u < _h7fj) return -0x1;
    }
  }return 0x0;
}, window[a[420225]] = wx[a[420355]]()[a[420225]], console[a[420049]](a[420356] + window[a[420225]]);var yudma = wx[a[420357]]();yudma[a[420358]](function (f8o_j7) {
  console[a[420049]](a[420359] + f8o_j7[a[420360]]);
}), yudma[a[420361]](function () {
  wx[a[420051]]({ 'title': a[420362], 'content': a[420363], 'showCancel': ![], 'success': function (s_l7f) {
      yudma[a[420364]]();
    } });
}), yudma[a[420365]](function () {
  console[a[420049]](a[420366]);
}), window['y2950S$'] = function () {
  console[a[420049]](a[420367]);var a63v0y = wx[a[420368]]({ 'name': a[420369], 'success': function (nk$g) {
      console[a[420049]](a[420370]), console[a[420049]](nk$g), nk$g && nk$g[a[420141]] == a[420371] ? (window['y205'] = !![], window['y205S$'](), window['y20S$5']()) : setTimeout(function () {
        window['y2950S$']();
      }, 0x1f4);
    }, 'fail': function ($ping) {
      console[a[420049]](a[420372]), console[a[420049]]($ping), setTimeout(function () {
        window['y2950S$']();
      }, 0x1f4);
    } });a63v0y && a63v0y[a[420373]](v6y30 => {});
}, window['y29S$05'] = function () {
  console[a[420049]](a[420374]);var $kni = wx[a[420368]]({ 'name': a[420375], 'success': function (ofj4_h) {
      console[a[420049]](a[420376]), console[a[420049]](ofj4_h), ofj4_h && ofj4_h[a[420141]] == a[420371] ? (window['y2S50'] = !![], window['y205S$'](), window['y20S$5']()) : setTimeout(function () {
        window['y29S$05']();
      }, 0x1f4);
    }, 'fail': function (n29k$c) {
      console[a[420049]](a[420377]), console[a[420049]](n29k$c), setTimeout(function () {
        window['y29S$05']();
      }, 0x1f4);
    } });$kni && $kni[a[420373]](gqn$p => {});
}, window[a[420378]] = function () {
  window['y2950$S'](window[a[420225]], a[420379]) >= 0x0 ? (console[a[420049]](a[420380] + window[a[420225]] + a[420381]), window['y2S$'](), window['y2950S$'](), window['y29S$05']()) : (window['y2S0$'](a[420382], window[a[420225]]), wx[a[420051]]({ 'title': a[420052], 'content': a[420383] }));
}, window[a[420085]] = '', wx[a[420384]]({ 'success'(dh4w) {
    window[a[420085]] = a[420385] + dh4w[a[420386]] + a[420387] + dh4w[a[420388]] + a[420389] + dh4w[a[420010]] + a[420390] + dh4w[a[420391]] + a[420392] + dh4w[a[420157]] + a[420393] + dh4w[a[420225]] + a[420394] + dh4w[a[420395]], console[a[420049]](window[a[420085]]), console[a[420049]](a[420396] + dh4w[a[420397]] + a[420398] + dh4w[a[420399]] + a[420400] + dh4w[a[420401]] + a[420402] + dh4w[a[420403]] + a[420404] + dh4w[a[420405]] + a[420406] + dh4w[a[420407]] + a[420408] + (dh4w[a[420409]] ? dh4w[a[420409]][a[420315]] + ',' + dh4w[a[420409]][a[420318]] + ',' + dh4w[a[420409]][a[420320]] + ',' + dh4w[a[420409]][a[420322]] : ''));var fs_ = dh4w[a[420391]] ? dh4w[a[420391]][a[420410]]() : '',
        kn$c29 = dh4w[a[420388]] ? dh4w[a[420388]][a[420410]]()[a[420339]]('\x20', '') : '';window['y2S0'][a[420043]] = fs_[a[420142]](a[420411]) != -0x1, window['y2S0'][a[420044]] = fs_[a[420142]](a[420412]) != -0x1, window['y2S0'][a[420314]] = fs_[a[420142]](a[420411]) != -0x1 || fs_[a[420142]](a[420412]) != -0x1, window['y2S0'][a[420045]] = fs_[a[420142]](a[420413]) != -0x1 || fs_[a[420142]](a[420012]) != -0x1, window['y2S0'][a[420096]] = dh4w[a[420157]] ? dh4w[a[420157]][a[420410]]() : '', window['y2S0']['y29$50S'] = ![], window['y2S0']['y29$S50'] = 0x2;if (fs_[a[420142]](a[420412]) != -0x1) {
      if (dh4w[a[420395]] >= 0x18) window['y2S0']['y29$S50'] = 0x3;else window['y2S0']['y29$S50'] = 0x2;
    } else {
      if (fs_[a[420142]](a[420411]) != -0x1) {
        if (dh4w[a[420395]] && dh4w[a[420395]] >= 0x14) window['y2S0']['y29$S50'] = 0x3;else {
          if (kn$c29[a[420142]](a[420414]) != -0x1 || kn$c29[a[420142]](a[420415]) != -0x1 || kn$c29[a[420142]](a[420416]) != -0x1 || kn$c29[a[420142]](a[420417]) != -0x1 || kn$c29[a[420142]](a[420418]) != -0x1) window['y2S0']['y29$S50'] = 0x2;else window['y2S0']['y29$S50'] = 0x3;
        }
      } else window['y2S0']['y29$S50'] = 0x2;
    }console[a[420049]](a[420419] + window['y2S0']['y29$50S'] + a[420420] + window['y2S0']['y29$S50']);
  } }), wx[a[420244]]({ 'success': function (dt4w1) {
    console[a[420049]](a[420421] + dt4w1[a[420246]] + a[420422] + dt4w1[a[420248]]);
  } }), wx[a[420423]]({ 'success': function (p$qgi) {
    console[a[420049]](a[420424] + p$qgi[a[420425]]);
  } }), wx[a[420426]]({ 'keepScreenOn': !![] }), wx[a[420427]](function (_4oj) {
  console[a[420049]](a[420424] + _4oj[a[420425]] + a[420428] + _4oj[a[420429]]);
}), wx[a[420218]](function (th4wjo) {
  window['y25$'] = th4wjo, window['y20$5'] && window['y25$'] && (console[a[420070]](a[420219] + window['y25$'][a[420220]]), window['y20$5'](window['y25$']), window['y25$'] = null);
}), window[a[420430]] = 0x0, window['y29S50$'] = 0x0, window[a[420431]] = null, wx[a[420432]](function () {
  window['y29S50$']++;var o7fhj = Date[a[420036]]();(window[a[420430]] == 0x0 || o7fhj - window[a[420430]] > 0x1d4c0) && (console[a[420094]](a[420433]), wx[a[420434]]());if (window['y29S50$'] >= 0x2) {
    window['y29S50$'] = 0x0, console[a[420088]](a[420435]), wx[a[420436]]('0', 0x1);if (window['y2S0'] && window['y2S0'][a[420043]]) window['y2S0$'](a[420437], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});