var O = wx.$C;
import h_g43f17 from '../hhhhsdk/hhhsdk.js';window[O[129091]] = { 'wxVersion': window[O[100555]][O[128989]] }, window[O[129092]] = ![], window['$hR6'] = 0x1, window[O[129093]] = 0x1, window['$hU6R'] = !![], window[O[129094]] = !![], window['$hXYU6R'] = '', window['$h6R'] = { 'base_cdn': O[129095], 'cdn': O[129095] }, $h6R[O[129096]] = {}, $h6R[O[124902]] = '0', $h6R[O[104716]] = window[O[129091]][O[129097]], $h6R[O[129063]] = '', $h6R['os'] = '1', $h6R[O[129098]] = O[129099], $h6R[O[129100]] = O[129101], $h6R[O[129102]] = O[129103], $h6R[O[129104]] = O[129105], $h6R[O[129106]] = O[129107], $h6R[O[123637]] = '1', $h6R[O[125216]] = '', $h6R[O[125218]] = '', $h6R[O[129108]] = 0x0, $h6R[O[129109]] = {}, $h6R[O[129110]] = parseInt($h6R[O[123637]]), $h6R[O[125214]] = $h6R[O[123637]], $h6R[O[125210]] = {}, $h6R['$hY6'] = O[129111], $h6R[O[129112]] = ![], $h6R[O[112240]] = O[129113], $h6R[O[125187]] = Date[O[100083]](), $h6R[O[111847]] = O[129114], $h6R[O[100712]] = '_a', $h6R[O[129115]] = 0x2, $h6R[O[100101]] = 0x7c1, $h6R[O[129097]] = window[O[129091]][O[129097]], $h6R[O[100736]] = ![], $h6R[O[101072]] = ![], $h6R[O[111328]] = ![], $h6R[O[124904]] = ![], window['$hUR6'] = 0x5, window['$hUR'] = ![], window['$hRU'] = ![], window['$h6UR'] = ![], window[O[129116]] = ![], window[O[129117]] = ![], window['$h6RU'] = ![], window['$hU6'] = ![], window['$h6U'] = ![], window['$hRU6'] = ![], window[O[104185]] = function (coup) {
  console[O[100480]](O[104185], coup), wx[O[104995]]({}), wx[O[129013]]({ 'title': O[106357], 'content': coup, 'success'(u$zr9) {
      if (u$zr9[O[129118]]) console[O[100480]](O[129119]);else u$zr9[O[100551]] && console[O[100480]](O[129120]);
    } });
}, window['$hYU6R'] = function (_sfgn) {
  console[O[100480]](O[129121], _sfgn), $hY6RU(), wx[O[129013]]({ 'title': O[106357], 'content': _sfgn, 'confirmText': O[129122], 'cancelText': O[118495], 'success'($uzr9) {
      if ($uzr9[O[129118]]) window['$h6Y']();else $uzr9[O[100551]] && (console[O[100480]](O[129123]), wx[O[125374]]({}));
    } });
}, window['$h6X'] = function (plu5) {
  console[O[100480]](O[129124], plu5), wx[O[129013]]({ 'title': O[106357], 'content': plu5, 'confirmText': O[125346], 'showCancel': ![], 'complete'(dwhj9) {
      console[O[100480]](O[129123]), wx[O[125374]]({});
    } });
}, window['$hYUR6'] = ![], window['$hY6UR'] = function (v_4gf3) {
  window['$hYUR6'] = !![], wx[O[104994]](v_4gf3);
}, window['$hY6RU'] = function () {
  window['$hYUR6'] && (window['$hYUR6'] = ![], wx[O[104995]]({}));
}, window['$hYRU6'] = function (rdjh9z) {
  window[O[129004]][O[100148]]['$hYRU6'](rdjh9z);
}, window[O[112121]] = function (wq17, nasy62) {
  h_g43f17[O[112121]](wq17, function (cp8ul) {
    cp8ul && cp8ul[O[100011]] ? cp8ul[O[100011]][O[104118]] == 0x1 ? nasy62(!![]) : (nasy62(![]), console[O[100078]](O[129125] + cp8ul[O[100011]][O[129126]])) : console[O[100480]](O[112121], cp8ul);
  });
}, window['$hYR6U'] = function (d09jh) {
  console[O[100480]](O[129127], d09jh);
}, window['$hY6R'] = function (jz9drh) {}, window['$hYR6'] = function (hxdjw, f473q, i6by2) {}, window['$hYR'] = function (dx0qwh) {
  console[O[100480]](O[129128], dx0qwh), window[O[129004]][O[100148]][O[129129]](), window[O[129004]][O[100148]][O[129130]](), window[O[129004]][O[100148]][O[129131]]();
}, window['$hRY'] = function (upol5) {
  window['$hYU6R'](O[129132]);var p$lu = { 'id': window['$h6R'][O[128994]], 'role': window['$h6R'][O[104645]], 'level': window['$h6R'][O[128995]], 'account': window['$h6R'][O[125215]], 'version': window['$h6R'][O[100101]], 'cdn': window['$h6R'][O[104524]], 'pkgName': window['$h6R'][O[125216]], 'gamever': window[O[100555]][O[128989]], 'serverid': window['$h6R'][O[125210]] ? window['$h6R'][O[125210]][O[111506]] : 0x0, 'systemInfo': window[O[128996]], 'error': O[129133], 'stack': upol5 ? upol5 : O[129132] },
      t5lcm = JSON[O[104510]](p$lu);console[O[100125]](O[129134] + t5lcm), window['$hY6'](t5lcm);
}, window['$h6YR'] = function (g3fv_4) {
  var q1xw = JSON[O[100525]](g3fv_4);q1xw[O[129135]] = window[O[100555]][O[128989]], q1xw[O[129136]] = window['$h6R'][O[125210]] ? window['$h6R'][O[125210]][O[111506]] : 0x0, q1xw[O[128996]] = window[O[128996]];var prz$ = JSON[O[104510]](q1xw);console[O[100125]](O[129137] + prz$), window['$hY6'](prz$);
}, window['$h6RY'] = function (rc8$p, ia2s) {
  var j98$zr = { 'id': window['$h6R'][O[128994]], 'role': window['$h6R'][O[104645]], 'level': window['$h6R'][O[128995]], 'account': window['$h6R'][O[125215]], 'version': window['$h6R'][O[100101]], 'cdn': window['$h6R'][O[104524]], 'pkgName': window['$h6R'][O[125216]], 'gamever': window[O[100555]][O[128989]], 'serverid': window['$h6R'][O[125210]] ? window['$h6R'][O[125210]][O[111506]] : 0x0, 'systemInfo': window[O[128996]], 'error': rc8$p, 'stack': ia2s },
      as_6ny = JSON[O[104510]](j98$zr);console[O[100096]](O[129138] + as_6ny), window['$hY6'](as_6ny);
}, window['$hY6'] = function (gvnys) {
  if (window['$h6R'][O[129064]] == O[128846]) return;var puz8r$ = $h6R['$hY6'] + O[129139] + $h6R[O[125215]];wx[O[100475]]({ 'url': puz8r$, 'method': O[128852], 'data': gvnys, 'header': { 'content-type': O[129140], 'cache-control': O[129141] }, 'success': function (nv_gys) {
      DEBUG && console[O[100480]](O[129142], puz8r$, gvnys, nv_gys);
    }, 'fail': function (z$r8) {
      DEBUG && console[O[100480]](O[129142], puz8r$, gvnys, z$r8);
    }, 'complete': function () {} });
}, window[O[129143]] = function () {
  function _gysnv() {
    return ((0x1 + Math[O[100119]]()) * 0x10000 | 0x0)[O[100272]](0x10)[O[100498]](0x1);
  }return _gysnv() + _gysnv() + '-' + _gysnv() + '-' + _gysnv() + '-' + _gysnv() + '+' + _gysnv() + _gysnv() + _gysnv();
}, window['$h6Y'] = function () {
  console[O[100480]](O[129144]);var _g3f4v = h_g43f17[O[129145]]();$h6R[O[125214]] = _g3f4v[O[129146]], $h6R[O[129110]] = _g3f4v[O[129146]], $h6R[O[123637]] = _g3f4v[O[129146]], $h6R[O[125216]] = _g3f4v[O[129147]];var tplo = { 'game_ver': $h6R[O[104716]] };$h6R[O[125218]] = this[O[129143]](), $hY6UR({ 'title': O[129148] }), h_g43f17[O[100366]](tplo, this['$hRY6'][O[100074]](this));
}, window['$hRY6'] = function (_4vfgn) {
  var pz8$u = _4vfgn[O[129149]];console[O[100480]](O[129150] + pz8$u + O[129151] + (pz8$u == 0x1) + O[129152] + _4vfgn[O[128989]] + O[129153] + window[O[129091]][O[129097]]);if (!_4vfgn[O[128989]] || window['$hXURY6'](window[O[129091]][O[129097]], _4vfgn[O[128989]]) < 0x0) console[O[100480]](O[129154]), $h6R[O[129100]] = O[129155], $h6R[O[129102]] = O[129156], $h6R[O[129104]] = O[129157], $h6R[O[104524]] = O[129158], $h6R[O[124901]] = O[129159], $h6R[O[129160]] = 'wd', $h6R[O[100736]] = ![];else window['$hXURY6'](window[O[129091]][O[129097]], _4vfgn[O[128989]]) == 0x0 ? (console[O[100480]](O[129161]), $h6R[O[129100]] = O[129101], $h6R[O[129102]] = O[129103], $h6R[O[129104]] = O[129105], $h6R[O[104524]] = O[129162], $h6R[O[124901]] = O[129159], $h6R[O[129160]] = O[129163], $h6R[O[100736]] = !![]) : (console[O[100480]](O[129164]), $h6R[O[129100]] = O[129101], $h6R[O[129102]] = O[129103], $h6R[O[129104]] = O[129105], $h6R[O[104524]] = O[129162], $h6R[O[124901]] = O[129159], $h6R[O[129160]] = O[129163], $h6R[O[100736]] = ![]);$h6R[O[129108]] = config[O[128462]] ? config[O[128462]] : 0x0, this['$hU6YR'](), this['$hU6RY'](), window[O[129165]] = 0x5, $hY6UR({ 'title': O[129166] }), h_g43f17[O[128923]](this['$hR6Y'][O[100074]](this));
}, window[O[129165]] = 0x5, window['$hR6Y'] = function (q3f417, _nv4gf) {
  if (q3f417 == 0x0 && _nv4gf && _nv4gf[O[128553]]) {
    $h6R[O[129167]] = _nv4gf[O[128553]];var x7hwq = this;$hY6UR({ 'title': O[129168] }), sendApi($h6R[O[129100]], O[129169], { 'platform': $h6R[O[129098]], 'partner_id': $h6R[O[123637]], 'token': _nv4gf[O[128553]], 'game_pkg': $h6R[O[125216]], 'deviceId': $h6R[O[125218]], 'scene': O[129170] + $h6R[O[129108]] }, this['$hUY6R'][O[100074]](this), $hUR6, $hRY);
  } else _nv4gf && _nv4gf[O[125401]] && window[O[129165]] > 0x0 && (_nv4gf[O[125401]][O[100115]](O[129171]) != -0x1 || _nv4gf[O[125401]][O[100115]](O[129172]) != -0x1 || _nv4gf[O[125401]][O[100115]](O[129173]) != -0x1 || _nv4gf[O[125401]][O[100115]](O[129174]) != -0x1 || _nv4gf[O[125401]][O[100115]](O[129175]) != -0x1 || _nv4gf[O[125401]][O[100115]](O[129176]) != -0x1) ? (window[O[129165]]--, h_g43f17[O[128923]](this['$hR6Y'][O[100074]](this))) : (window['$h6RY'](O[129177], JSON[O[104510]]({ 'status': q3f417, 'data': _nv4gf })), window['$hYU6R'](O[129178] + (_nv4gf && _nv4gf[O[125401]] ? '，' + _nv4gf[O[125401]] : '')));
}, window['$hUY6R'] = function (r8$ucp) {
  if (!r8$ucp) {
    window['$h6RY'](O[129179], O[129180]), window['$hYU6R'](O[129181]);return;
  }if (r8$ucp[O[104118]] != O[109918]) {
    window['$h6RY'](O[129179], JSON[O[104510]](r8$ucp)), window['$hYU6R'](O[129182] + r8$ucp[O[104118]]);return;
  }$h6R[O[123636]] = String(r8$ucp[O[125215]]), $h6R[O[125215]] = String(r8$ucp[O[125215]]), $h6R[O[125185]] = String(r8$ucp[O[125185]]), $h6R[O[125214]] = String(r8$ucp[O[125185]]), $h6R[O[125217]] = String(r8$ucp[O[125217]]), $h6R[O[129183]] = String(r8$ucp[O[111489]]), $h6R[O[129184]] = String(r8$ucp[O[100849]]), $h6R[O[111489]] = '';var jrh9d = this;$hY6UR({ 'title': O[129185] }), sendApi($h6R[O[129100]], O[129186], { 'partner_id': $h6R[O[123637]], 'uid': $h6R[O[125215]], 'version': $h6R[O[104716]], 'game_pkg': $h6R[O[125216]], 'device': $h6R[O[125218]] }, jrh9d['$hUYR6'][O[100074]](jrh9d), $hUR6, $hRY);
}, window['$hUYR6'] = function (rdh9jz) {
  if (!rdh9jz) {
    window['$hYU6R'](O[129187]);return;
  }if (rdh9jz[O[104118]] != O[109918]) {
    window['$hYU6R'](O[129188] + rdh9jz[O[104118]]);return;
  }if (!rdh9jz[O[100011]] || rdh9jz[O[100011]][O[100013]] == 0x0) {
    window['$hYU6R'](O[129189]);return;
  }$h6R[O[100628]] = rdh9jz[O[129190]], $h6R[O[125210]] = { 'server_id': String(rdh9jz[O[100011]][0x0][O[111506]]), 'server_name': String(rdh9jz[O[100011]][0x0][O[129191]]), 'entry_ip': rdh9jz[O[100011]][0x0][O[125238]], 'entry_port': parseInt(rdh9jz[O[100011]][0x0][O[125239]]), 'status': $h6UY(rdh9jz[O[100011]][0x0]), 'start_time': rdh9jz[O[100011]][0x0][O[129192]], 'cdn': $h6R[O[104524]] }, this['$hR6UY']();
}, window['$hR6UY'] = function () {
  if ($h6R[O[100628]] == 0x1) {
    var _n4gf = $h6R[O[125210]][O[100106]];if (_n4gf === -0x1 || _n4gf === 0x0) {
      window['$hYU6R'](_n4gf === -0x1 ? O[129193] : O[129194]);return;
    }$hRYU6(0x0, $h6R[O[125210]][O[111506]]), window[O[129004]][O[100148]][O[129195]]($h6R[O[100628]]);
  } else window[O[129004]][O[100148]][O[129196]](), $hY6RU();window['$h6U'] = !![], window['$hRU6Y'](), window['$hR6YU']();
}, window['$hU6YR'] = function () {
  sendApi($h6R[O[129100]], O[129197], { 'game_pkg': $h6R[O[125216]], 'version_name': $h6R[O[129160]] }, this[O[129198]][O[100074]](this), $hUR6, $hRY);
}, window[O[129198]] = function (_fgsn) {
  if (!_fgsn) {
    window['$hYU6R'](O[129199]);return;
  }if (_fgsn[O[104118]] != O[109918]) {
    window['$hYU6R'](O[129200] + _fgsn[O[104118]]);return;
  }if (!_fgsn[O[100011]] || !_fgsn[O[100011]][O[104716]]) {
    window['$hYU6R'](O[129201] + (_fgsn[O[100011]] && _fgsn[O[100011]][O[104716]]));return;
  }_fgsn[O[100011]][O[129202]] && _fgsn[O[100011]][O[129202]][O[100013]] > 0xa && ($h6R[O[129203]] = _fgsn[O[100011]][O[129202]], $h6R[O[104524]] = _fgsn[O[100011]][O[129202]]), _fgsn[O[100011]][O[104716]] && ($h6R[O[100101]] = _fgsn[O[100011]][O[104716]]), console[O[100078]](O[125352] + $h6R[O[100101]] + O[129204] + $h6R[O[129160]]), window['$h6RU'] = !![], window['$hRU6Y'](), window['$hR6YU']();
}, window[O[129205]], window['$hU6RY'] = function () {
  sendApi($h6R[O[129100]], O[129206], { 'game_pkg': $h6R[O[125216]] }, this['$hURY6'][O[100074]](this), $hUR6, $hRY);
}, window['$hURY6'] = function (f47g13) {
  if (f47g13[O[104118]] === O[109918] && f47g13[O[100011]]) {
    window[O[129205]] = f47g13[O[100011]];for (var z8jr9d in f47g13[O[100011]]) {
      $h6R[z8jr9d] = f47g13[O[100011]][z8jr9d];
    }
  } else console[O[100078]](O[129207] + f47g13[O[104118]]);window['$hU6'] = !![], window['$hR6YU']();
}, window[O[129208]] = function (q34f71, vsnya_, vg_4nf, u8lp$, oucl, xj0dhw, vsg_fn, x710qw, zjw9d) {
  oucl = String(oucl);var svf_g = vsg_fn,
      r$8pcu = x710qw;$h6R[O[129096]][oucl] = { 'productid': oucl, 'productname': svf_g, 'productdesc': r$8pcu, 'roleid': q34f71, 'rolename': vsnya_, 'rolelevel': vg_4nf, 'price': xj0dhw, 'callback': zjw9d }, sendApi($h6R[O[129104]], O[129209], { 'game_pkg': $h6R[O[125216]], 'server_id': $h6R[O[125210]][O[111506]], 'server_name': $h6R[O[125210]][O[129191]], 'level': vg_4nf, 'uid': $h6R[O[125215]], 'role_id': q34f71, 'role_name': vsnya_, 'product_id': oucl, 'product_name': svf_g, 'product_desc': r$8pcu, 'money': xj0dhw, 'partner_id': $h6R[O[123637]] }, toPayCallBack, $hUR6, $hRY);
}, window[O[129210]] = function (dhxqw) {
  if (dhxqw) {
    if (dhxqw[O[129211]] === 0xc8 || dhxqw[O[104118]] == O[109918]) {
      var sya62 = $h6R[O[129096]][String(dhxqw[O[129212]])];if (sya62[O[100332]]) sya62[O[100332]](dhxqw[O[129212]], dhxqw[O[129213]], -0x1);h_g43f17[O[128961]]({ 'cpbill': dhxqw[O[129213]], 'productid': dhxqw[O[129212]], 'productname': sya62[O[129214]], 'productdesc': sya62[O[129215]], 'serverid': $h6R[O[125210]][O[111506]], 'servername': $h6R[O[125210]][O[129191]], 'roleid': sya62[O[129216]], 'rolename': sya62[O[129217]], 'rolelevel': sya62[O[129218]], 'price': sya62[O[126909]], 'extension': JSON[O[104510]]({ 'cp_order_id': dhxqw[O[129213]] }) }, function (qw7x10, vyg_s) {
        sya62[O[100332]] && qw7x10 == 0x0 && sya62[O[100332]](dhxqw[O[129212]], dhxqw[O[129213]], qw7x10);console[O[100078]](JSON[O[104510]]({ 'type': O[129219], 'status': qw7x10, 'data': dhxqw, 'role_name': sya62[O[129217]] }));if (qw7x10 === 0x0) {} else {
          if (qw7x10 === 0x1) {} else {
            if (qw7x10 === 0x2) {}
          }
        }
      });
    } else alert(dhxqw[O[100078]]);
  }
}, window['$hUR6Y'] = function () {}, window['$hYUR'] = function (v314g, jwhd09, pzu8r, upr$8z, clopu) {
  h_g43f17[O[128979]]($h6R[O[125210]][O[111506]], $h6R[O[125210]][O[129191]] || $h6R[O[125210]][O[111506]], v314g, jwhd09, pzu8r), sendApi($h6R[O[129100]], O[129220], { 'game_pkg': $h6R[O[125216]], 'server_id': $h6R[O[125210]][O[111506]], 'role_id': v314g, 'uid': $h6R[O[125215]], 'role_name': jwhd09, 'role_type': upr$8z, 'level': pzu8r });
}, window['$hYRU'] = function (g31vf4, up$8zr, jx0w, qf7314, tklom5, lucp8$, x0jh, tok5m, $rz9j, v4f_ng) {
  $h6R[O[128994]] = g31vf4, $h6R[O[104645]] = up$8zr, $h6R[O[128995]] = jx0w, h_g43f17[O[128980]]($h6R[O[125210]][O[111506]], $h6R[O[125210]][O[129191]] || $h6R[O[125210]][O[111506]], g31vf4, up$8zr, jx0w), sendApi($h6R[O[129100]], O[129221], { 'game_pkg': $h6R[O[125216]], 'server_id': $h6R[O[125210]][O[111506]], 'role_id': g31vf4, 'uid': $h6R[O[125215]], 'role_name': up$8zr, 'role_type': qf7314, 'level': jx0w, 'evolution': tklom5 });
}, window['$hUYR'] = function (nv_sgf, cl8$pu, pcl$8, _n6ys, hdxw0, xj0hwd, cltp, h0dxw, d0jxhw, q0x7) {
  $h6R[O[128994]] = nv_sgf, $h6R[O[104645]] = cl8$pu, $h6R[O[128995]] = pcl$8, h_g43f17[O[128981]]($h6R[O[125210]][O[111506]], $h6R[O[125210]][O[129191]] || $h6R[O[125210]][O[111506]], nv_sgf, cl8$pu, pcl$8), sendApi($h6R[O[129100]], O[129221], { 'game_pkg': $h6R[O[125216]], 'server_id': $h6R[O[125210]][O[111506]], 'role_id': nv_sgf, 'uid': $h6R[O[125215]], 'role_name': cl8$pu, 'role_type': _n6ys, 'level': pcl$8, 'evolution': hdxw0 });
}, window['$hURY'] = function (x0qwh) {}, window['$hYU'] = function (com) {
  h_g43f17[O[128941]](O[128941], function (q471f3) {
    com && com(q471f3);
  });
}, window[O[124885]] = function () {
  h_g43f17[O[124885]]();
}, window[O[129222]] = function () {
  h_g43f17[O[123530]]();
}, window[O[110839]] = function (lk5ot) {
  window['$hRYU'] = lk5ot, window['$hRYU'] && window['$hUY'] && (console[O[100078]](O[129083] + window['$hUY'][O[100774]]), window['$hRYU'](window['$hUY']), window['$hUY'] = null);
}, window['$hRUY'] = function (lc5u$p, s_ynva, ns_ya, u$8clp) {
  window[O[100022]](O[129223], { 'game_pkg': window['$h6R'][O[125216]], 'role_id': s_ynva, 'server_id': ns_ya }, u$8clp);
}, window['$h6YUR'] = function (w07xq1, fq37) {
  function xdwjh(s62ai) {
    var _nv4 = [],
        n_syva = [],
        a62ib = window[O[100555]][O[129224]];for (var $p5ul in a62ib) {
      var ae6b2i = Number($p5ul);(!w07xq1 || !w07xq1[O[100013]] || w07xq1[O[100115]](ae6b2i) != -0x1) && (n_syva[O[100029]](a62ib[$p5ul]), _nv4[O[100029]]([ae6b2i, 0x3]));
    }window['$hXURY6'](window[O[129005]], O[129225]) >= 0x0 ? (console[O[100480]](O[129226]), h_g43f17[O[129227]] && h_g43f17[O[129227]](n_syva, function (y6sia2) {
      console[O[100480]](O[129228]), console[O[100480]](y6sia2);if (y6sia2 && y6sia2[O[125401]] == O[129229]) for (var vys_ in a62ib) {
        if (y6sia2[a62ib[vys_]] == O[129230]) {
          var dxj0 = Number(vys_);for (var pzur = 0x0; pzur < _nv4[O[100013]]; pzur++) {
            if (_nv4[pzur][0x0] == dxj0) {
              _nv4[pzur][0x1] = 0x1;break;
            }
          }
        }
      }window['$hXURY6'](window[O[129005]], O[129231]) >= 0x0 ? wx[O[129232]]({ 'withSubscriptions': !![], 'success': function (_4nf) {
          var djh9zr = _4nf[O[129233]][O[129234]];if (djh9zr) {
            console[O[100480]](O[129235]), console[O[100480]](djh9zr);for (var b6e2 in a62ib) {
              if (djh9zr[a62ib[b6e2]] == O[129230]) {
                var s_nyg = Number(b6e2);for (var rj98z = 0x0; rj98z < _nv4[O[100013]]; rj98z++) {
                  if (_nv4[rj98z][0x0] == s_nyg) {
                    _nv4[rj98z][0x1] = 0x2;break;
                  }
                }
              }
            }console[O[100480]](_nv4), fq37 && fq37(_nv4);
          } else console[O[100480]](O[129236]), console[O[100480]](_4nf), console[O[100480]](_nv4), fq37 && fq37(_nv4);
        }, 'fail': function () {
          console[O[100480]](O[129237]), console[O[100480]](_nv4), fq37 && fq37(_nv4);
        } }) : (console[O[100480]](O[129238] + window[O[129005]]), console[O[100480]](_nv4), fq37 && fq37(_nv4));
    })) : (console[O[100480]](O[129239] + window[O[129005]]), console[O[100480]](_nv4), fq37 && fq37(_nv4)), wx[O[129240]](xdwjh);
  }wx[O[129241]](xdwjh);
}, window['$h6YRU'] = { 'isSuccess': ![], 'level': O[129242], 'isCharging': ![] }, window['$h6UYR'] = function (pu5lc) {
  wx[O[129072]]({ 'success': function (y_sa) {
      var s_anvy = window['$h6YRU'];s_anvy[O[129243]] = !![], s_anvy[O[104621]] = Number(y_sa[O[104621]])[O[104233]](0x0), s_anvy[O[129075]] = y_sa[O[129075]], pu5lc && pu5lc(s_anvy[O[129243]], s_anvy[O[104621]], s_anvy[O[129075]]);
    }, 'fail': function (ru9z$) {
      console[O[100480]](O[129244], ru9z$[O[125401]]);var sgv_nf = window['$h6YRU'];pu5lc && pu5lc(sgv_nf[O[129243]], sgv_nf[O[104621]], sgv_nf[O[129075]]);
    } });
}, window[O[100022]] = function (iyb26, fngsv_, qdhx0, gv341f, hjd9r, xhd0w, drj9h, a_6syn) {
  if (gv341f == undefined) gv341f = 0x1;wx[O[100475]]({ 'url': iyb26, 'method': drj9h || O[125104], 'responseType': O[104430], 'data': fngsv_, 'header': { 'content-type': a_6syn || O[129140] }, 'success': function (dq0xhw) {
      DEBUG && console[O[100480]](O[129245], iyb26, info, dq0xhw);if (dq0xhw && dq0xhw[O[125467]] == 0xc8) {
        var xq70w1 = dq0xhw[O[100011]];!xhd0w || xhd0w(xq70w1) ? qdhx0 && qdhx0(xq70w1) : window[O[129246]](iyb26, fngsv_, qdhx0, gv341f, hjd9r, xhd0w, dq0xhw);
      } else window[O[129246]](iyb26, fngsv_, qdhx0, gv341f, hjd9r, xhd0w, dq0xhw);
    }, 'fail': function (zr9jh) {
      DEBUG && console[O[100480]](O[129247], iyb26, info, zr9jh), window[O[129246]](iyb26, fngsv_, qdhx0, gv341f, hjd9r, xhd0w, zr9jh);
    }, 'complete': function () {} });
}, window[O[129246]] = function (ru8p$c, cpolt, rzup8, v31fg, z9rd8, ais2y, w9jh0d) {
  v31fg - 0x1 > 0x0 ? setTimeout(function () {
    window[O[100022]](ru8p$c, cpolt, rzup8, v31fg - 0x1, z9rd8, ais2y);
  }, 0x3e8) : z9rd8 && z9rd8(JSON[O[104510]]({ 'url': ru8p$c, 'response': w9jh0d }));
}, window[O[129248]] = function (jx0, rz8u$p, j9dzwh, h9jdw, ng_yvs, gvf43, wdjh0x) {
  !j9dzwh && (j9dzwh = {});var l$8cu = Math[O[100118]](Date[O[100083]]() / 0x3e8);j9dzwh[O[100849]] = l$8cu, j9dzwh[O[125025]] = rz8u$p;var xhw0q7 = Object[O[100264]](j9dzwh)[O[101076]](),
      cu$l5p = '',
      gnv_f4 = '';for (var j8r9$z = 0x0; j8r9$z < xhw0q7[O[100013]]; j8r9$z++) {
    cu$l5p = cu$l5p + (j8r9$z == 0x0 ? '' : '&') + xhw0q7[j8r9$z] + j9dzwh[xhw0q7[j8r9$z]], gnv_f4 = gnv_f4 + (j8r9$z == 0x0 ? '' : '&') + xhw0q7[j8r9$z] + '=' + encodeURIComponent(j9dzwh[xhw0q7[j8r9$z]]);
  }cu$l5p = cu$l5p + $h6R[O[129106]];var $8rz = O[129249] + md5(cu$l5p);send(jx0 + '?' + gnv_f4 + (gnv_f4 == '' ? '' : '&') + $8rz, null, h9jdw, ng_yvs, gvf43, wdjh0x || function (m5ctlo) {
    return m5ctlo[O[104118]] == O[109918];
  }, null, O[128853]);
}, window['$h6URY'] = function (rzp8u$, o5clu) {
  var pco5ul = 0x0;$h6R[O[125210]] && (pco5ul = $h6R[O[125210]][O[111506]]), sendApi($h6R[O[129102]], O[129250], { 'partnerId': $h6R[O[123637]], 'gamePkg': $h6R[O[125216]], 'logTime': Math[O[100118]](Date[O[100083]]() / 0x3e8), 'platformUid': $h6R[O[125217]], 'type': rzp8u$, 'serverId': pco5ul }, null, 0x2, null, function () {
    return !![];
  });
}, window['$h6RYU'] = function (x0jhdw) {
  sendApi($h6R[O[129100]], O[129251], { 'partner_id': $h6R[O[123637]], 'uid': $h6R[O[125215]], 'version': $h6R[O[104716]], 'game_pkg': $h6R[O[125216]], 'device': $h6R[O[125218]] }, $h6RUY, $hUR6, $hRY);
}, window['$h6RUY'] = function (ul5) {
  if (ul5[O[104118]] === O[109918] && ul5[O[100011]]) {
    ul5[O[100011]][O[105598]]({ 'id': -0x2, 'name': O[129252] }), ul5[O[100011]][O[105598]]({ 'id': -0x1, 'name': O[129253] }), $h6R[O[129254]] = ul5[O[100011]];if (window[O[112286]]) window[O[112286]][O[129255]]();
  } else $h6R[O[129256]] = ![], window['$hYU6R'](O[129257] + ul5[O[104118]]);
}, window['$hYU6'] = function (p$ucl) {
  sendApi($h6R[O[129100]], O[129258], { 'partner_id': $h6R[O[123637]], 'uid': $h6R[O[125215]], 'version': $h6R[O[104716]], 'game_pkg': $h6R[O[125216]], 'device': $h6R[O[125218]] }, $hY6U, $hUR6, $hRY);
}, window['$hY6U'] = function (s2nya) {
  $h6R[O[129259]] = ![];if (s2nya[O[104118]] === O[109918] && s2nya[O[100011]]) {
    for (var n4f = 0x0; n4f < s2nya[O[100011]][O[100013]]; n4f++) {
      s2nya[O[100011]][n4f][O[100106]] = $h6UY(s2nya[O[100011]][n4f]);
    }$h6R[O[129109]][-0x1] = window[O[129260]](s2nya[O[100011]]), window[O[112286]][O[129261]](-0x1);
  } else window['$hYU6R'](O[129262] + s2nya[O[104118]]);
}, window[O[129263]] = function ($l8cpu) {
  sendApi($h6R[O[129100]], O[129258], { 'partner_id': $h6R[O[123637]], 'uid': $h6R[O[125215]], 'version': $h6R[O[104716]], 'game_pkg': $h6R[O[125216]], 'device': $h6R[O[125218]] }, $l8cpu, $hUR6, $hRY);
}, window['$hUY6'] = function (s62iay, c8$ru) {
  sendApi($h6R[O[129100]], O[129264], { 'partner_id': $h6R[O[123637]], 'uid': $h6R[O[125215]], 'version': $h6R[O[104716]], 'game_pkg': $h6R[O[125216]], 'device': $h6R[O[125218]], 'server_group_id': c8$ru }, $hU6Y, $hUR6, $hRY);
}, window['$hU6Y'] = function (ru8z$) {
  $h6R[O[129259]] = ![];if (ru8z$[O[104118]] === O[109918] && ru8z$[O[100011]] && ru8z$[O[100011]][O[100011]]) {
    var bya26 = ru8z$[O[100011]][O[129265]],
        _fv3 = [];for (var z8r9u$ = 0x0; z8r9u$ < ru8z$[O[100011]][O[100011]][O[100013]]; z8r9u$++) {
      ru8z$[O[100011]][O[100011]][z8r9u$][O[100106]] = $h6UY(ru8z$[O[100011]][O[100011]][z8r9u$]), (_fv3[O[100013]] == 0x0 || ru8z$[O[100011]][O[100011]][z8r9u$][O[100106]] != 0x0) && (_fv3[_fv3[O[100013]]] = ru8z$[O[100011]][O[100011]][z8r9u$]);
    }$h6R[O[129109]][bya26] = window[O[129260]](_fv3), window[O[112286]][O[129261]](bya26);
  } else window['$hYU6R'](O[129266] + ru8z$[O[104118]]);
}, window['$hXUR6'] = function (fnv_sg) {
  sendApi($h6R[O[129100]], O[129267], { 'partner_id': $h6R[O[123637]], 'uid': $h6R[O[125215]], 'version': $h6R[O[104716]], 'game_pkg': $h6R[O[125216]], 'device': $h6R[O[125218]] }, reqServerRecommendCallBack, $hUR6, $hRY);
}, window[O[129268]] = function (hdjx0) {
  $h6R[O[129259]] = ![];if (hdjx0[O[104118]] === O[109918] && hdjx0[O[100011]]) {
    for (var nf_ = 0x0; nf_ < hdjx0[O[100011]][O[100013]]; nf_++) {
      hdjx0[O[100011]][nf_][O[100106]] = $h6UY(hdjx0[O[100011]][nf_]);
    }$h6R[O[129109]][-0x2] = window[O[129260]](hdjx0[O[100011]]), window[O[112286]][O[129261]](-0x2);
  } else alert(O[129269] + hdjx0[O[104118]]);
}, window[O[129260]] = function (cmt5lo) {
  if (!cmt5lo && cmt5lo[O[100013]] <= 0x0) return cmt5lo;for (let fg371 = 0x0; fg371 < cmt5lo[O[100013]]; fg371++) {
    cmt5lo[fg371][O[129270]] && cmt5lo[fg371][O[129270]] == 0x1 && (cmt5lo[fg371][O[129191]] += O[129271]);
  }return cmt5lo;
}, window['$h6YU'] = function (z98dj, jzh9r) {
  z98dj = z98dj || $h6R[O[125210]][O[111506]], sendApi($h6R[O[129100]], O[129272], { 'type': '4', 'game_pkg': $h6R[O[125216]], 'server_id': z98dj }, jzh9r);
}, window[O[129273]] = function (cupr$, fgn4, ay_s6, mco5tl) {
  ay_s6 = ay_s6 || $h6R[O[125210]][O[111506]], sendApi($h6R[O[129100]], O[129274], { 'type': cupr$, 'game_pkg': fgn4, 'server_id': ay_s6 }, mco5tl);
}, window['$h6UY'] = function (c8$urp) {
  if (c8$urp) {
    if (c8$urp[O[100106]] == 0x1) {
      if (c8$urp[O[129275]] == 0x1) return 0x2;else return 0x1;
    } else return c8$urp[O[100106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$hRYU6'] = function (rj8z9$, motl5) {
  $h6R[O[129276]] = { 'step': rj8z9$, 'server_id': motl5 };var ba6y2 = this;$hY6UR({ 'title': O[129277] }), sendApi($h6R[O[129100]], O[129278], { 'partner_id': $h6R[O[123637]], 'uid': $h6R[O[125215]], 'game_pkg': $h6R[O[125216]], 'server_id': motl5, 'platform': $h6R[O[125185]], 'platform_uid': $h6R[O[125217]], 'check_login_time': $h6R[O[129184]], 'check_login_sign': $h6R[O[129183]], 'version_name': $h6R[O[129160]] }, $hRY6U, $hUR6, $hRY, function (u8r9) {
    return u8r9[O[104118]] == O[109918] || u8r9[O[100078]] == O[129279] || u8r9[O[100078]] == O[129280];
  });
}, window['$hRY6U'] = function (x3147q) {
  var vysna = this;if (x3147q[O[104118]] === O[109918] && x3147q[O[100011]]) {
    var ie2ba = $h6R[O[125210]];ie2ba[O[129281]] = $h6R[O[129110]], ie2ba[O[111489]] = String(x3147q[O[100011]][O[129282]]), ie2ba[O[125187]] = parseInt(x3147q[O[100011]][O[100849]]);if (x3147q[O[100011]][O[125186]]) ie2ba[O[125186]] = parseInt(x3147q[O[100011]][O[125186]]);else ie2ba[O[125186]] = parseInt(x3147q[O[100011]][O[111506]]);ie2ba[O[129283]] = 0x0, ie2ba[O[104524]] = $h6R[O[129203]], ie2ba[O[129284]] = x3147q[O[100011]][O[129285]], ie2ba[O[129286]] = x3147q[O[100011]][O[129286]], console[O[100480]](O[129287] + JSON[O[104510]](ie2ba[O[129286]])), $h6R[O[100628]] == 0x1 && ie2ba[O[129286]] && ie2ba[O[129286]][O[129288]] == 0x1 && ($h6R[O[129289]] = 0x1, window[O[129004]][O[100148]]['$hXR6']()), $hRUY6();
  } else $h6R[O[129276]][O[107114]] >= 0x3 ? ($hRY(JSON[O[104510]](x3147q)), window['$hYU6R'](O[129290] + x3147q[O[104118]])) : sendApi($h6R[O[129100]], O[129169], { 'platform': $h6R[O[129098]], 'partner_id': $h6R[O[123637]], 'token': $h6R[O[129167]], 'game_pkg': $h6R[O[125216]], 'deviceId': $h6R[O[125218]], 'scene': O[129170] + $h6R[O[129108]] }, function (c5tmlo) {
    if (!c5tmlo || c5tmlo[O[104118]] != O[109918]) {
      window['$hYU6R'](O[129182] + c5tmlo && c5tmlo[O[104118]]);return;
    }$h6R[O[129183]] = String(c5tmlo[O[111489]]), $h6R[O[129184]] = String(c5tmlo[O[100849]]), setTimeout(function () {
      $hRYU6($h6R[O[129276]][O[107114]] + 0x1, $h6R[O[129276]][O[111506]]);
    }, 0x5dc);
  }, $hUR6, $hRY, function (fg713) {
    return fg713[O[104118]] == O[109918] || fg713[O[104118]] == O[125545];
  });
}, window['$hRUY6'] = function () {
  ServerLoading[O[100148]][O[129195]]($h6R[O[100628]]), window['$hUR'] = !![], window['$hR6YU']();
}, window['$hRU6Y'] = function () {
  if (window['$hRU'] && window['$h6UR'] && window[O[129116]] && window[O[129117]] && window['$h6RU'] && window['$h6U']) {
    if (!window[O[128441]][O[100148]]) {
      console[O[100480]](O[129291] + window[O[128441]][O[100148]]);var yia6 = wx[O[129292]](),
          jh9d = yia6[O[100774]] ? yia6[O[100774]] : 0x0,
          km5ol = { 'cdn': window['$h6R'][O[104524]], 'spareCdn': window['$h6R'][O[124901]], 'newRegister': window['$h6R'][O[100628]], 'wxPC': window['$h6R'][O[124904]], 'wxIOS': window['$h6R'][O[101072]], 'wxAndroid': window['$h6R'][O[111328]], 'wxParam': { 'limitLoad': window['$h6R']['$hXYUR6'], 'benchmarkLevel': window['$h6R']['$hXY6UR'], 'wxFrom': window[O[100555]][O[128462]] == O[129293] ? 0x1 : 0x0, 'wxSDKVersion': window[O[129005]] }, 'configType': window['$h6R'][O[111847]], 'exposeType': window['$h6R'][O[100712]], 'scene': jh9d };new window[O[128441]](km5ol, window['$h6R'][O[100101]], window['$hXYU6R']);
    }
  }
}, window['$hR6YU'] = function () {
  if (window['$hRU'] && window['$h6UR'] && window[O[129116]] && window[O[129117]] && window['$h6RU'] && window['$h6U'] && window['$hUR'] && window['$hU6']) {
    $hY6RU();if (!$hRU6) {
      $hRU6 = !![];if (!window[O[128441]][O[100148]]) window['$hRU6Y']();var f4q3 = 0x0,
          hjdzw = wx[O[129294]]();hjdzw && (window['$h6R'][O[129061]] && (f4q3 = hjdzw[O[100320]]), console[O[100078]](O[129295] + hjdzw[O[100320]] + O[129296] + hjdzw[O[101213]] + O[129297] + hjdzw[O[101215]] + O[129298] + hjdzw[O[101214]] + O[129299] + hjdzw[O[100176]] + O[129300] + hjdzw[O[100177]]));var q174f3 = {};for (const yis6a in $h6R[O[125210]]) {
        q174f3[yis6a] = $h6R[O[125210]][yis6a];
      }var v31f4g = { 'channel': window['$h6R'][O[125214]], 'account': window['$h6R'][O[125215]], 'userId': window['$h6R'][O[123636]], 'cdn': window['$h6R'][O[104524]], 'data': window['$h6R'][O[100011]], 'package': window['$h6R'][O[124902]], 'newRegister': window['$h6R'][O[100628]], 'pkgName': window['$h6R'][O[125216]], 'partnerId': window['$h6R'][O[123637]], 'platform_uid': window['$h6R'][O[125217]], 'deviceId': window['$h6R'][O[125218]], 'selectedServer': q174f3, 'configType': window['$h6R'][O[111847]], 'exposeType': window['$h6R'][O[100712]], 'debugUsers': window['$h6R'][O[112240]], 'wxMenuTop': f4q3, 'wxShield': window['$h6R'][O[100736]] };if (window[O[129205]]) for (var z$rup8 in window[O[129205]]) {
        v31f4g[z$rup8] = window[O[129205]][z$rup8];
      }window[O[128441]][O[100148]]['$hUX6R'](v31f4g);
    }
  } else console[O[100078]](O[129301] + window['$hRU'] + O[129302] + window['$h6UR'] + O[129303] + window[O[129116]] + O[129304] + window[O[129117]] + O[129305] + window['$h6RU'] + O[129306] + window['$h6U'] + O[129307] + window['$hUR'] + O[129308] + window['$hU6']);
};