var Y = wx.$M;
import M_ukx3 from '../mmmmmSDK/mmmSDDK.js';window[Y[180567]] = { 'wxVersion': window[Y[180006]][Y[180007]] }, window[Y[180568]] = ![], window['$m21'] = 0x1, window[Y[180569]] = 0x1, window['$m012'] = !![], window[Y[180570]] = !![], window['$m54012'] = '', window['$m12'] = { 'base_cdn': Y[180571], 'cdn': Y[180571] }, $m12[Y[180572]] = {}, $m12[Y[180573]] = '0', $m12[Y[180080]] = window[Y[180567]][Y[180349]], $m12[Y[180115]] = '', $m12['os'] = '1', $m12[Y[180574]] = Y[180575], $m12[Y[180576]] = Y[180577], $m12[Y[180578]] = Y[180579], $m12[Y[180580]] = Y[180581], $m12[Y[180582]] = Y[180583], $m12[Y[180584]] = '1', $m12[Y[180022]] = '', $m12[Y[180585]] = '', $m12[Y[180586]] = 0x0, $m12[Y[180440]] = {}, $m12[Y[180587]] = parseInt($m12[Y[180584]]), $m12[Y[180588]] = $m12[Y[180584]], $m12[Y[180023]] = {}, $m12['$m41'] = Y[180589], $m12[Y[180590]] = ![], $m12[Y[180591]] = Y[180592], $m12[Y[180593]] = Date[Y[180142]](), $m12[Y[180594]] = Y[180595], $m12[Y[180596]] = '_a', $m12[Y[180335]] = 0x2, $m12[Y[180020]] = 0x7c1, $m12[Y[180349]] = window[Y[180567]][Y[180349]], $m12[Y[180597]] = ![], $m12[Y[180107]] = ![], $m12[Y[180110]] = ![], $m12[Y[180113]] = ![], window['$m021'] = 0x5, window['$m02'] = ![], window['$m20'] = ![], window['$m102'] = ![], window[Y[180518]] = ![], window[Y[180521]] = ![], window['$m120'] = ![], window['$m01'] = ![], window['$m10'] = ![], window['$m201'] = ![], window[Y[180598]] = function (ml5nih) {
  console[Y[180042]](Y[180598], ml5nih), wx[Y[180599]]({}), wx[Y[180049]]({ 'title': Y[180072], 'content': ml5nih, 'success'(lnmi5) {
      if (lnmi5[Y[180600]]) console[Y[180042]](Y[180601]);else lnmi5[Y[180602]] && console[Y[180042]](Y[180603]);
    } });
}, window['$m4012'] = function (r9x1ku) {
  console[Y[180042]](Y[180604], r9x1ku), $m4120(), wx[Y[180049]]({ 'title': Y[180072], 'content': r9x1ku, 'confirmText': Y[180605], 'cancelText': Y[180606], 'success'(bvw$d) {
      if (bvw$d[Y[180600]]) window['$m14']();else bvw$d[Y[180602]] && (console[Y[180042]](Y[180607]), wx[Y[180608]]({}));
    } });
}, window[Y[180609]] = function (u1qxky) {
  console[Y[180042]](Y[180609], u1qxky), wx[Y[180049]]({ 'title': Y[180072], 'content': u1qxky, 'confirmText': Y[180610], 'showCancel': ![], 'complete'(a8ec2t) {
      console[Y[180042]](Y[180607]), wx[Y[180608]]({});
    } });
}, window['$m4021'] = ![], window['$m4102'] = function ($li50n) {
  window['$m4021'] = !![], wx[Y[180611]]($li50n);
}, window['$m4120'] = function () {
  window['$m4021'] && (window['$m4021'] = ![], wx[Y[180599]]({}));
}, window['$m4201'] = function (kuyq1) {
  window[Y[180035]][Y[180036]]['$m4201'](kuyq1);
}, window[Y[180612]] = function (qyux1, kqu) {
  M_ukx3[Y[180612]](qyux1, function (ceog8a) {
    ceog8a && ceog8a[Y[180450]] ? ceog8a[Y[180450]][Y[180449]] == 0x1 ? kqu(!![]) : (kqu(![]), console[Y[180001]](Y[180613] + ceog8a[Y[180450]][Y[180614]])) : console[Y[180042]](Y[180612], ceog8a);
  });
}, window['$m4210'] = function (b5l$0d) {
  console[Y[180042]](Y[180615], b5l$0d);
}, window['$m412'] = function (ihl0n) {}, window['$m421'] = function (u3xqky, aog6s, ca68o) {}, window['$m42'] = function (qykx1) {
  console[Y[180042]](Y[180616], qykx1), window[Y[180035]][Y[180036]][Y[180339]](), window[Y[180035]][Y[180036]][Y[180340]](), window[Y[180035]][Y[180036]][Y[180353]]();
}, window['$m24'] = function (fbvwdr) {
  window['$m4012'](Y[180617]);var m7jh4 = { 'id': window['$m12'][Y[180016]], 'role': window['$m12'][Y[180017]], 'level': window['$m12'][Y[180018]], 'account': window['$m12'][Y[180019]], 'version': window['$m12'][Y[180020]], 'cdn': window['$m12'][Y[180021]], 'pkgName': window['$m12'][Y[180022]], 'gamever': window[Y[180006]][Y[180007]], 'serverid': window['$m12'][Y[180023]] ? window['$m12'][Y[180023]][Y[180024]] : 0x0, 'systemInfo': window[Y[180025]], 'error': Y[180618], 'stack': fbvwdr ? fbvwdr : Y[180617] },
      wvrb = JSON[Y[180027]](m7jh4);console[Y[180028]](Y[180619] + wvrb), window['$m41'](wvrb);
}, window['$m142'] = function (go6cs) {
  var f$dv = JSON[Y[180620]](go6cs);f$dv[Y[180621]] = window[Y[180006]][Y[180007]], f$dv[Y[180622]] = window['$m12'][Y[180023]] ? window['$m12'][Y[180023]][Y[180024]] : 0x0, f$dv[Y[180025]] = window[Y[180025]];var coae = JSON[Y[180027]](f$dv);console[Y[180028]](Y[180623] + coae), window['$m41'](coae);
}, window['$m124'] = function ($ln5i0, ru9x1) {
  var yukq3x = { 'id': window['$m12'][Y[180016]], 'role': window['$m12'][Y[180017]], 'level': window['$m12'][Y[180018]], 'account': window['$m12'][Y[180019]], 'version': window['$m12'][Y[180020]], 'cdn': window['$m12'][Y[180021]], 'pkgName': window['$m12'][Y[180022]], 'gamever': window[Y[180006]][Y[180007]], 'serverid': window['$m12'][Y[180023]] ? window['$m12'][Y[180023]][Y[180024]] : 0x0, 'systemInfo': window[Y[180025]], 'error': $ln5i0, 'stack': ru9x1 },
      j_mh = JSON[Y[180027]](yukq3x);console[Y[180143]](Y[180624] + j_mh), window['$m41'](j_mh);
}, window['$m41'] = function (vb9wfr) {
  if (window['$m12'][Y[180116]] == Y[180625]) return;var l5nhi = $m12['$m41'] + Y[180626] + $m12[Y[180019]];wx[Y[180627]]({ 'url': l5nhi, 'method': Y[180628], 'data': vb9wfr, 'header': { 'content-type': Y[180629], 'cache-control': Y[180630] }, 'success': function (a8g6oc) {
      DEBUG && console[Y[180042]](Y[180631], l5nhi, vb9wfr, a8g6oc);
    }, 'fail': function (rfw9v1) {
      DEBUG && console[Y[180042]](Y[180631], l5nhi, vb9wfr, rfw9v1);
    }, 'complete': function () {} });
}, window[Y[180632]] = function () {
  function _74msj() {
    return ((0x1 + Math[Y[180342]]()) * 0x10000 | 0x0)[Y[180633]](0x10)[Y[180634]](0x1);
  }return _74msj() + _74msj() + '-' + _74msj() + '-' + _74msj() + '-' + _74msj() + '+' + _74msj() + _74msj() + _74msj();
}, window['$m14'] = function () {
  console[Y[180042]](Y[180635]);var e8aog = M_ukx3[Y[180636]]();$m12[Y[180588]] = e8aog[Y[180637]], $m12[Y[180587]] = e8aog[Y[180637]], $m12[Y[180584]] = e8aog[Y[180637]], $m12[Y[180022]] = e8aog[Y[180638]];var vf$bdw = { 'game_ver': $m12[Y[180080]] };$m12[Y[180585]] = this[Y[180632]](), $m4102({ 'title': Y[180639] }), M_ukx3[Y[180483]](vf$bdw, this['$m241'][Y[180346]](this));
}, window['$m241'] = function (y1xqu) {
  var gc8o6 = y1xqu[Y[180640]];console[Y[180042]](Y[180641] + gc8o6 + Y[180642] + (gc8o6 == 0x1) + Y[180643] + y1xqu[Y[180007]] + Y[180644] + window[Y[180567]][Y[180349]]);if (!y1xqu[Y[180007]] || window['$m50241'](window[Y[180567]][Y[180349]], y1xqu[Y[180007]]) < 0x0) console[Y[180042]](Y[180645]), $m12[Y[180576]] = Y[180646], $m12[Y[180578]] = Y[180647], $m12[Y[180580]] = Y[180648], $m12[Y[180021]] = Y[180649], $m12[Y[180650]] = Y[180651], $m12[Y[180652]] = 'ts', $m12[Y[180597]] = ![];else window['$m50241'](window[Y[180567]][Y[180349]], y1xqu[Y[180007]]) == 0x0 ? (console[Y[180042]](Y[180653]), $m12[Y[180576]] = Y[180577], $m12[Y[180578]] = Y[180579], $m12[Y[180580]] = Y[180581], $m12[Y[180021]] = Y[180654], $m12[Y[180650]] = Y[180651], $m12[Y[180652]] = Y[180655], $m12[Y[180597]] = !![]) : (console[Y[180042]](Y[180656]), $m12[Y[180576]] = Y[180577], $m12[Y[180578]] = Y[180579], $m12[Y[180580]] = Y[180581], $m12[Y[180021]] = Y[180654], $m12[Y[180650]] = Y[180651], $m12[Y[180652]] = Y[180655], $m12[Y[180597]] = ![]);$m12[Y[180586]] = config[Y[180657]] ? config[Y[180657]] : 0x0, this['$m0142'](), this['$m0124'](), window[Y[180658]] = 0x5, $m4102({ 'title': Y[180659] }), M_ukx3[Y[180660]](this['$m214'][Y[180346]](this));
}, window[Y[180658]] = 0x5, window['$m214'] = function (z8pte, $d0i) {
  if (z8pte == 0x0 && $d0i && $d0i[Y[180661]]) {
    $m12[Y[180662]] = $d0i[Y[180661]];var pt28z = this;$m4102({ 'title': Y[180663] }), sendApi($m12[Y[180576]], Y[180664], { 'platform': $m12[Y[180574]], 'partner_id': $m12[Y[180584]], 'token': $d0i[Y[180661]], 'game_pkg': $m12[Y[180022]], 'deviceId': $m12[Y[180585]], 'scene': Y[180665] + $m12[Y[180586]] }, this['$m0412'][Y[180346]](this), $m021, $m24);
  } else $d0i && $d0i[Y[180059]] && window[Y[180658]] > 0x0 && ($d0i[Y[180059]][Y[180108]](Y[180666]) != -0x1 || $d0i[Y[180059]][Y[180108]](Y[180667]) != -0x1 || $d0i[Y[180059]][Y[180108]](Y[180668]) != -0x1 || $d0i[Y[180059]][Y[180108]](Y[180669]) != -0x1 || $d0i[Y[180059]][Y[180108]](Y[180670]) != -0x1 || $d0i[Y[180059]][Y[180108]](Y[180671]) != -0x1) ? (window[Y[180658]]--, M_ukx3[Y[180660]](this['$m214'][Y[180346]](this))) : (window['$m124'](Y[180672], JSON[Y[180027]]({ 'status': z8pte, 'data': $d0i })), window['$m4012'](Y[180673] + ($d0i && $d0i[Y[180059]] ? '，' + $d0i[Y[180059]] : '')));
}, window['$m0412'] = function (c2z8t) {
  if (!c2z8t) {
    window['$m124'](Y[180674], Y[180675]), window['$m4012'](Y[180676]);return;
  }if (c2z8t[Y[180449]] != Y[180448]) {
    window['$m124'](Y[180674], JSON[Y[180027]](c2z8t)), window['$m4012'](Y[180677] + c2z8t[Y[180449]]);return;
  }$m12[Y[180678]] = String(c2z8t[Y[180019]]), $m12[Y[180019]] = String(c2z8t[Y[180019]]), $m12[Y[180084]] = String(c2z8t[Y[180084]]), $m12[Y[180588]] = String(c2z8t[Y[180084]]), $m12[Y[180679]] = String(c2z8t[Y[180679]]), $m12[Y[180680]] = String(c2z8t[Y[180681]]), $m12[Y[180682]] = String(c2z8t[Y[180683]]), $m12[Y[180681]] = '';var n0$5li = this;$m4102({ 'title': Y[180684] }), sendApi($m12[Y[180576]], Y[180685], { 'partner_id': $m12[Y[180584]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180585]] }, n0$5li['$m0421'][Y[180346]](n0$5li), $m021, $m24);
}, window['$m0421'] = function (v1frw9) {
  if (!v1frw9) {
    window['$m4012'](Y[180686]);return;
  }if (v1frw9[Y[180449]] != Y[180448]) {
    window['$m4012'](Y[180687] + v1frw9[Y[180449]]);return;
  }if (!v1frw9[Y[180450]] || v1frw9[Y[180450]][Y[180010]] == 0x0) {
    window['$m4012'](Y[180688]);return;
  }$m12[Y[180527]] = v1frw9[Y[180689]], $m12[Y[180023]] = { 'server_id': String(v1frw9[Y[180450]][0x0][Y[180024]]), 'server_name': String(v1frw9[Y[180450]][0x0][Y[180428]]), 'entry_ip': v1frw9[Y[180450]][0x0][Y[180690]], 'entry_port': parseInt(v1frw9[Y[180450]][0x0][Y[180691]]), 'status': $m104(v1frw9[Y[180450]][0x0]), 'start_time': v1frw9[Y[180450]][0x0][Y[180692]], 'cdn': $m12[Y[180021]] }, this['$m2104']();
}, window['$m2104'] = function () {
  if ($m12[Y[180527]] == 0x1) {
    var rvkf91 = $m12[Y[180023]][Y[180427]];if (rvkf91 === -0x1 || rvkf91 === 0x0) {
      window['$m4012'](rvkf91 === -0x1 ? Y[180693] : Y[180694]);return;
    }$m2401(0x0, $m12[Y[180023]][Y[180024]]), window[Y[180035]][Y[180036]][Y[180522]]($m12[Y[180527]]);
  } else window[Y[180035]][Y[180036]][Y[180519]](), $m4120();window['$m10'] = !![], window['$m2014'](), window['$m2140']();
}, window['$m0142'] = function () {
  sendApi($m12[Y[180576]], Y[180695], { 'game_pkg': $m12[Y[180022]], 'version_name': $m12[Y[180652]] }, this[Y[180696]][Y[180346]](this), $m021, $m24);
}, window[Y[180696]] = function (wv$bdf) {
  if (!wv$bdf) {
    window['$m4012'](Y[180697]);return;
  }if (wv$bdf[Y[180449]] != Y[180448]) {
    window['$m4012'](Y[180698] + wv$bdf[Y[180449]]);return;
  }if (!wv$bdf[Y[180450]] || !wv$bdf[Y[180450]][Y[180080]]) {
    window['$m4012'](Y[180699] + (wv$bdf[Y[180450]] && wv$bdf[Y[180450]][Y[180080]]));return;
  }wv$bdf[Y[180450]][Y[180700]] && wv$bdf[Y[180450]][Y[180700]][Y[180010]] > 0xa && ($m12[Y[180701]] = wv$bdf[Y[180450]][Y[180700]], $m12[Y[180021]] = wv$bdf[Y[180450]][Y[180700]]), wv$bdf[Y[180450]][Y[180080]] && ($m12[Y[180020]] = wv$bdf[Y[180450]][Y[180080]]), console[Y[180001]](Y[180702] + $m12[Y[180020]] + Y[180703] + $m12[Y[180652]]), window['$m120'] = !![], window['$m2014'](), window['$m2140']();
}, window[Y[180704]], window['$m0124'] = function () {
  sendApi($m12[Y[180576]], Y[180705], { 'game_pkg': $m12[Y[180022]] }, this['$m0241'][Y[180346]](this), $m021, $m24);
}, window['$m0241'] = function (_74so6) {
  if (_74so6[Y[180449]] === Y[180448] && _74so6[Y[180450]]) {
    window[Y[180704]] = _74so6[Y[180450]];for (var a6os4 in _74so6[Y[180450]]) {
      $m12[a6os4] = _74so6[Y[180450]][a6os4];
    }
  } else console[Y[180001]](Y[180706] + _74so6[Y[180449]]);window['$m01'] = !![], window['$m2140']();
}, window[Y[180707]] = function (v1kfr, h7imnj, _6s4og, vf19r, v91f, lnm5hi, jh7_4m, vrbw9, e28gac) {
  v91f = String(v91f);var n50h = jh7_4m,
      w1fv9r = vrbw9;$m12[Y[180572]][v91f] = { 'productid': v91f, 'productname': n50h, 'productdesc': w1fv9r, 'roleid': v1kfr, 'rolename': h7imnj, 'rolelevel': _6s4og, 'price': lnm5hi, 'callback': e28gac }, sendApi($m12[Y[180580]], Y[180708], { 'game_pkg': $m12[Y[180022]], 'server_id': $m12[Y[180023]][Y[180024]], 'server_name': $m12[Y[180023]][Y[180428]], 'level': _6s4og, 'uid': $m12[Y[180019]], 'role_id': v1kfr, 'role_name': h7imnj, 'product_id': v91f, 'product_name': n50h, 'product_desc': w1fv9r, 'money': lnm5hi, 'partner_id': $m12[Y[180584]] }, toPayCallBack, $m021, $m24);
}, window[Y[180709]] = function (lb0dw$) {
  if (lb0dw$) {
    if (lb0dw$[Y[180710]] === 0xc8 || lb0dw$[Y[180449]] == Y[180448]) {
      var dw$ = $m12[Y[180572]][String(lb0dw$[Y[180711]])];if (dw$[Y[180712]]) dw$[Y[180712]](lb0dw$[Y[180711]], lb0dw$[Y[180713]], -0x1);M_ukx3[Y[180714]]({ 'cpbill': lb0dw$[Y[180713]], 'productid': lb0dw$[Y[180711]], 'productname': dw$[Y[180715]], 'productdesc': dw$[Y[180716]], 'serverid': $m12[Y[180023]][Y[180024]], 'servername': $m12[Y[180023]][Y[180428]], 'roleid': dw$[Y[180717]], 'rolename': dw$[Y[180718]], 'rolelevel': dw$[Y[180719]], 'price': dw$[Y[180720]], 'extension': JSON[Y[180027]]({ 'cp_order_id': lb0dw$[Y[180713]] }) }, function (nh5lim, a28ec) {
        dw$[Y[180712]] && nh5lim == 0x0 && dw$[Y[180712]](lb0dw$[Y[180711]], lb0dw$[Y[180713]], nh5lim);console[Y[180001]](JSON[Y[180027]]({ 'type': Y[180721], 'status': nh5lim, 'data': lb0dw$, 'role_name': dw$[Y[180718]] }));if (nh5lim === 0x0) {} else {
          if (nh5lim === 0x1) {} else {
            if (nh5lim === 0x2) {}
          }
        }
      });
    } else alert(lb0dw$[Y[180001]]);
  }
}, window['$m0214'] = function () {}, window['$m402'] = function (aegco, yqxu, frbd, tzp8, di50$) {
  M_ukx3[Y[180722]]($m12[Y[180023]][Y[180024]], $m12[Y[180023]][Y[180428]] || $m12[Y[180023]][Y[180024]], aegco, yqxu, frbd), sendApi($m12[Y[180576]], Y[180723], { 'game_pkg': $m12[Y[180022]], 'server_id': $m12[Y[180023]][Y[180024]], 'role_id': aegco, 'uid': $m12[Y[180019]], 'role_name': yqxu, 'role_type': tzp8, 'level': frbd });
}, window['$m420'] = function (kv9xr, im5nlh, tpe8z, tc82e, sa64go, d$fb, n$li0, m_nh, njmi5h, fv9rb) {
  $m12[Y[180016]] = kv9xr, $m12[Y[180017]] = im5nlh, $m12[Y[180018]] = tpe8z, M_ukx3[Y[180724]]($m12[Y[180023]][Y[180024]], $m12[Y[180023]][Y[180428]] || $m12[Y[180023]][Y[180024]], kv9xr, im5nlh, tpe8z), sendApi($m12[Y[180576]], Y[180725], { 'game_pkg': $m12[Y[180022]], 'server_id': $m12[Y[180023]][Y[180024]], 'role_id': kv9xr, 'uid': $m12[Y[180019]], 'role_name': im5nlh, 'role_type': tc82e, 'level': tpe8z, 'evolution': sa64go });
}, window['$m042'] = function (w$db, hm5i, _njm, a6gocs, pezt28, h7_jnm, xq1yku, im5lh, _jhm74, t8c2ea) {
  $m12[Y[180016]] = w$db, $m12[Y[180017]] = hm5i, $m12[Y[180018]] = _njm, M_ukx3[Y[180726]]($m12[Y[180023]][Y[180024]], $m12[Y[180023]][Y[180428]] || $m12[Y[180023]][Y[180024]], w$db, hm5i, _njm), sendApi($m12[Y[180576]], Y[180725], { 'game_pkg': $m12[Y[180022]], 'server_id': $m12[Y[180023]][Y[180024]], 'role_id': w$db, 'uid': $m12[Y[180019]], 'role_name': hm5i, 'role_type': a6gocs, 'level': _njm, 'evolution': pezt28 });
}, window['$m024'] = function (k1rxu) {}, window['$m40'] = function (z2et) {
  M_ukx3[Y[180727]](Y[180727], function (gao86) {
    z2et && z2et(gao86);
  });
}, window[Y[180728]] = function () {
  M_ukx3[Y[180728]]();
}, window[Y[180729]] = function () {
  M_ukx3[Y[180730]]();
}, window[Y[180136]] = function (g4s6o_) {
  window['$m240'] = g4s6o_, window['$m240'] && window['$m04'] && (console[Y[180001]](Y[180137] + window['$m04'][Y[180138]]), window['$m240'](window['$m04']), window['$m04'] = null);
}, window['$m204'] = function (eo8gca, os6_g4, i0$, vfrb) {
  window[Y[180731]](Y[180732], { 'game_pkg': window['$m12'][Y[180022]], 'role_id': os6_g4, 'server_id': i0$ }, vfrb);
}, window['$m1402'] = function (xur1k9, fdrwv) {
  function age2c8(xyu1qk) {
    var rkx9v1 = [],
        ky9xu = [],
        zep8t2 = window[Y[180006]][Y[180733]];for (var lb0wd$ in zep8t2) {
      var g8a2e = Number(lb0wd$);(!xur1k9 || !xur1k9[Y[180010]] || xur1k9[Y[180108]](g8a2e) != -0x1) && (ky9xu[Y[180039]](zep8t2[lb0wd$]), rkx9v1[Y[180039]]([g8a2e, 0x3]));
    }window['$m50241'](window[Y[180040]], Y[180734]) >= 0x0 ? (console[Y[180042]](Y[180735]), M_ukx3[Y[180736]] && M_ukx3[Y[180736]](ky9xu, function (_o4s6) {
      console[Y[180042]](Y[180737]), console[Y[180042]](_o4s6);if (_o4s6 && _o4s6[Y[180059]] == Y[180738]) for (var l5mnih in zep8t2) {
        if (_o4s6[zep8t2[l5mnih]] == Y[180739]) {
          var zp2e8 = Number(l5mnih);for (var rx91vk = 0x0; rx91vk < rkx9v1[Y[180010]]; rx91vk++) {
            if (rkx9v1[rx91vk][0x0] == zp2e8) {
              rkx9v1[rx91vk][0x1] = 0x1;break;
            }
          }
        }
      }window['$m50241'](window[Y[180040]], Y[180740]) >= 0x0 ? wx[Y[180741]]({ 'withSubscriptions': !![], 'success': function (s6g) {
          var ez28tp = s6g[Y[180742]][Y[180743]];if (ez28tp) {
            console[Y[180042]](Y[180744]), console[Y[180042]](ez28tp);for (var dbvf in zep8t2) {
              if (ez28tp[zep8t2[dbvf]] == Y[180739]) {
                var yu91kx = Number(dbvf);for (var fwvr9b = 0x0; fwvr9b < rkx9v1[Y[180010]]; fwvr9b++) {
                  if (rkx9v1[fwvr9b][0x0] == yu91kx) {
                    rkx9v1[fwvr9b][0x1] = 0x2;break;
                  }
                }
              }
            }console[Y[180042]](rkx9v1), fdrwv && fdrwv(rkx9v1);
          } else console[Y[180042]](Y[180745]), console[Y[180042]](s6g), console[Y[180042]](rkx9v1), fdrwv && fdrwv(rkx9v1);
        }, 'fail': function () {
          console[Y[180042]](Y[180746]), console[Y[180042]](rkx9v1), fdrwv && fdrwv(rkx9v1);
        } }) : (console[Y[180042]](Y[180747] + window[Y[180040]]), console[Y[180042]](rkx9v1), fdrwv && fdrwv(rkx9v1));
    })) : (console[Y[180042]](Y[180748] + window[Y[180040]]), console[Y[180042]](rkx9v1), fdrwv && fdrwv(rkx9v1)), wx[Y[180749]](age2c8);
  }wx[Y[180750]](age2c8);
}, window['$m1420'] = { 'isSuccess': ![], 'level': Y[180751], 'isCharging': ![] }, window['$m1042'] = function (hj5nmi) {
  wx[Y[180124]]({ 'success': function (eczt2) {
      var mli5hn = window['$m1420'];mli5hn[Y[180752]] = !![], mli5hn[Y[180126]] = Number(eczt2[Y[180126]])[Y[180753]](0x0), mli5hn[Y[180128]] = eczt2[Y[180128]], hj5nmi && hj5nmi(mli5hn[Y[180752]], mli5hn[Y[180126]], mli5hn[Y[180128]]);
    }, 'fail': function ($d0i5) {
      console[Y[180042]](Y[180754], $d0i5[Y[180059]]);var hinmj7 = window['$m1420'];hj5nmi && hj5nmi(hinmj7[Y[180752]], hinmj7[Y[180126]], hinmj7[Y[180128]]);
    } });
}, window[Y[180731]] = function (tp28ze, h5ml, jhm7_4, yx1ku, d5li, b$wld0, kyxu91, vfd$w) {
  if (yx1ku == undefined) yx1ku = 0x1;wx[Y[180627]]({ 'url': tp28ze, 'method': kyxu91 || Y[180755], 'responseType': Y[180344], 'data': h5ml, 'header': { 'content-type': vfd$w || Y[180629] }, 'success': function (wb$0ld) {
      DEBUG && console[Y[180042]](Y[180756], tp28ze, info, wb$0ld);if (wb$0ld && wb$0ld[Y[180757]] == 0xc8) {
        var rxu1k = wb$0ld[Y[180450]];!b$wld0 || b$wld0(rxu1k) ? jhm7_4 && jhm7_4(rxu1k) : window[Y[180758]](tp28ze, h5ml, jhm7_4, yx1ku, d5li, b$wld0, wb$0ld);
      } else window[Y[180758]](tp28ze, h5ml, jhm7_4, yx1ku, d5li, b$wld0, wb$0ld);
    }, 'fail': function (j_s7m) {
      DEBUG && console[Y[180042]](Y[180759], tp28ze, info, j_s7m), window[Y[180758]](tp28ze, h5ml, jhm7_4, yx1ku, d5li, b$wld0, j_s7m);
    }, 'complete': function () {} });
}, window[Y[180758]] = function (lb05$d, ld$05, g4_so6, fd0$bw, uk1x, c6o8ga, z8pet) {
  fd0$bw - 0x1 > 0x0 ? setTimeout(function () {
    window[Y[180731]](lb05$d, ld$05, g4_so6, fd0$bw - 0x1, uk1x, c6o8ga);
  }, 0x3e8) : uk1x && uk1x(JSON[Y[180027]]({ 'url': lb05$d, 'response': z8pet }));
}, window[Y[180760]] = function (fvdrwb, dli0, m74_s, rbvwfd, z8ep2t, ijhm7, _so76) {
  !m74_s && (m74_s = {});var cet8a = Math[Y[180539]](Date[Y[180142]]() / 0x3e8);m74_s[Y[180683]] = cet8a, m74_s[Y[180761]] = dli0;var cea2g = Object[Y[180762]](m74_s)[Y[180454]](),
      ca8te2 = '',
      go6s_ = '';for (var $bwv = 0x0; $bwv < cea2g[Y[180010]]; $bwv++) {
    ca8te2 = ca8te2 + ($bwv == 0x0 ? '' : '&') + cea2g[$bwv] + m74_s[cea2g[$bwv]], go6s_ = go6s_ + ($bwv == 0x0 ? '' : '&') + cea2g[$bwv] + '=' + encodeURIComponent(m74_s[cea2g[$bwv]]);
  }ca8te2 = ca8te2 + $m12[Y[180582]];var $li05d = Y[180763] + md5(ca8te2);send(fvdrwb + '?' + go6s_ + (go6s_ == '' ? '' : '&') + $li05d, null, rbvwfd, z8ep2t, ijhm7, _so76 || function (m4jh_) {
    return m4jh_[Y[180449]] == Y[180448];
  }, null, Y[180764]);
}, window['$m1024'] = function (j4sm_7, _hmn7) {
  var dfbwvr = 0x0;$m12[Y[180023]] && (dfbwvr = $m12[Y[180023]][Y[180024]]), sendApi($m12[Y[180578]], Y[180765], { 'partnerId': $m12[Y[180584]], 'gamePkg': $m12[Y[180022]], 'logTime': Math[Y[180539]](Date[Y[180142]]() / 0x3e8), 'platformUid': $m12[Y[180679]], 'type': j4sm_7, 'serverId': dfbwvr }, null, 0x2, null, function () {
    return !![];
  });
}, window['$m1240'] = function (a8gc2) {
  sendApi($m12[Y[180576]], Y[180766], { 'partner_id': $m12[Y[180584]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180585]] }, $m1204, $m021, $m24);
}, window['$m1204'] = function (cag86o) {
  if (cag86o[Y[180449]] === Y[180448] && cag86o[Y[180450]]) {
    cag86o[Y[180450]][Y[180767]]({ 'id': -0x2, 'name': Y[180768] }), cag86o[Y[180450]][Y[180767]]({ 'id': -0x1, 'name': Y[180769] }), $m12[Y[180401]] = cag86o[Y[180450]];if (window[Y[180393]]) window[Y[180393]][Y[180434]]();
  } else $m12[Y[180411]] = ![], window['$m4012'](Y[180770] + cag86o[Y[180449]]);
}, window['$m401'] = function (hmi5jn) {
  sendApi($m12[Y[180576]], Y[180771], { 'partner_id': $m12[Y[180584]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180585]] }, $m410, $m021, $m24);
}, window['$m410'] = function (u9kxr1) {
  $m12[Y[180442]] = ![];if (u9kxr1[Y[180449]] === Y[180448] && u9kxr1[Y[180450]]) {
    for (var c8aet2 = 0x0; c8aet2 < u9kxr1[Y[180450]][Y[180010]]; c8aet2++) {
      u9kxr1[Y[180450]][c8aet2][Y[180427]] = $m104(u9kxr1[Y[180450]][c8aet2]);
    }$m12[Y[180440]][-0x1] = window[Y[180772]](u9kxr1[Y[180450]]), window[Y[180393]][Y[180441]](-0x1);
  } else window['$m4012'](Y[180773] + u9kxr1[Y[180449]]);
}, window[Y[180774]] = function (js_m7) {
  sendApi($m12[Y[180576]], Y[180771], { 'partner_id': $m12[Y[180584]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180585]] }, js_m7, $m021, $m24);
}, window['$m041'] = function (id50l$, etac) {
  sendApi($m12[Y[180576]], Y[180775], { 'partner_id': $m12[Y[180584]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180585]], 'server_group_id': etac }, $m014, $m021, $m24);
}, window['$m014'] = function (frwbv9) {
  $m12[Y[180442]] = ![];if (frwbv9[Y[180449]] === Y[180448] && frwbv9[Y[180450]] && frwbv9[Y[180450]][Y[180450]]) {
    var sog46 = frwbv9[Y[180450]][Y[180776]],
        j_74 = [];for (var wbdf$ = 0x0; wbdf$ < frwbv9[Y[180450]][Y[180450]][Y[180010]]; wbdf$++) {
      frwbv9[Y[180450]][Y[180450]][wbdf$][Y[180427]] = $m104(frwbv9[Y[180450]][Y[180450]][wbdf$]), (j_74[Y[180010]] == 0x0 || frwbv9[Y[180450]][Y[180450]][wbdf$][Y[180427]] != 0x0) && (j_74[j_74[Y[180010]]] = frwbv9[Y[180450]][Y[180450]][wbdf$]);
    }$m12[Y[180440]][sog46] = window[Y[180772]](j_74), window[Y[180393]][Y[180441]](sog46);
  } else window['$m4012'](Y[180777] + frwbv9[Y[180449]]);
}, window['$m5021'] = function (brvwd) {
  sendApi($m12[Y[180576]], Y[180778], { 'partner_id': $m12[Y[180584]], 'uid': $m12[Y[180019]], 'version': $m12[Y[180080]], 'game_pkg': $m12[Y[180022]], 'device': $m12[Y[180585]] }, reqServerRecommendCallBack, $m021, $m24);
}, window[Y[180779]] = function (sg6c) {
  $m12[Y[180442]] = ![];if (sg6c[Y[180449]] === Y[180448] && sg6c[Y[180450]]) {
    for (var ihnmj7 = 0x0; ihnmj7 < sg6c[Y[180450]][Y[180010]]; ihnmj7++) {
      sg6c[Y[180450]][ihnmj7][Y[180427]] = $m104(sg6c[Y[180450]][ihnmj7]);
    }$m12[Y[180440]][-0x2] = window[Y[180772]](sg6c[Y[180450]]), window[Y[180393]][Y[180441]](-0x2);
  } else alert(Y[180780] + sg6c[Y[180449]]);
}, window[Y[180772]] = function (e8a2g) {
  if (!e8a2g && e8a2g[Y[180010]] <= 0x0) return e8a2g;for (let y9x = 0x0; y9x < e8a2g[Y[180010]]; y9x++) {
    e8a2g[y9x][Y[180781]] && e8a2g[y9x][Y[180781]] == 0x1 && (e8a2g[y9x][Y[180428]] += Y[180782]);
  }return e8a2g;
}, window['$m140'] = function (jh_7, ageoc8) {
  jh_7 = jh_7 || $m12[Y[180023]][Y[180024]], sendApi($m12[Y[180576]], Y[180783], { 'type': '4', 'game_pkg': $m12[Y[180022]], 'server_id': jh_7 }, ageoc8);
}, window[Y[180784]] = function (qxky1u, u1x, ae8ogc, ku1yqx) {
  ae8ogc = ae8ogc || $m12[Y[180023]][Y[180024]], sendApi($m12[Y[180576]], Y[180785], { 'type': qxky1u, 'game_pkg': u1x, 'server_id': ae8ogc }, ku1yqx);
}, window['$m104'] = function (kqxu) {
  if (kqxu) {
    if (kqxu[Y[180427]] == 0x1) {
      if (kqxu[Y[180786]] == 0x1) return 0x2;else return 0x1;
    } else return kqxu[Y[180427]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$m2401'] = function (g6ocs, ijn5m) {
  $m12[Y[180787]] = { 'step': g6ocs, 'server_id': ijn5m };var fr9k = this;$m4102({ 'title': Y[180788] }), sendApi($m12[Y[180576]], Y[180789], { 'partner_id': $m12[Y[180584]], 'uid': $m12[Y[180019]], 'game_pkg': $m12[Y[180022]], 'server_id': ijn5m, 'platform': $m12[Y[180084]], 'platform_uid': $m12[Y[180679]], 'check_login_time': $m12[Y[180682]], 'check_login_sign': $m12[Y[180680]], 'version_name': $m12[Y[180652]] }, $m2410, $m021, $m24, function (sgoc) {
    return sgoc[Y[180449]] == Y[180448] || sgoc[Y[180001]] == Y[180790] || sgoc[Y[180001]] == Y[180791];
  });
}, window['$m2410'] = function (sm_7) {
  var di$05l = this;if (sm_7[Y[180449]] === Y[180448] && sm_7[Y[180450]]) {
    var uk1xr = $m12[Y[180023]];uk1xr[Y[180792]] = $m12[Y[180587]], uk1xr[Y[180681]] = String(sm_7[Y[180450]][Y[180793]]), uk1xr[Y[180593]] = parseInt(sm_7[Y[180450]][Y[180683]]);if (sm_7[Y[180450]][Y[180794]]) uk1xr[Y[180794]] = parseInt(sm_7[Y[180450]][Y[180794]]);else uk1xr[Y[180794]] = parseInt(sm_7[Y[180450]][Y[180024]]);uk1xr[Y[180795]] = 0x0, uk1xr[Y[180021]] = $m12[Y[180701]], uk1xr[Y[180796]] = sm_7[Y[180450]][Y[180797]], uk1xr[Y[180798]] = sm_7[Y[180450]][Y[180798]], console[Y[180042]](Y[180799] + JSON[Y[180027]](uk1xr[Y[180798]])), $m12[Y[180527]] == 0x1 && uk1xr[Y[180798]] && uk1xr[Y[180798]][Y[180800]] == 0x1 && ($m12[Y[180350]] = 0x1, window[Y[180035]][Y[180036]]['$m521']()), $m2041();
  } else $m12[Y[180787]][Y[180801]] >= 0x3 ? ($m24(JSON[Y[180027]](sm_7)), window['$m4012'](Y[180802] + sm_7[Y[180449]])) : sendApi($m12[Y[180576]], Y[180664], { 'platform': $m12[Y[180574]], 'partner_id': $m12[Y[180584]], 'token': $m12[Y[180662]], 'game_pkg': $m12[Y[180022]], 'deviceId': $m12[Y[180585]], 'scene': Y[180665] + $m12[Y[180586]] }, function ($lb0w) {
    if (!$lb0w || $lb0w[Y[180449]] != Y[180448]) {
      window['$m4012'](Y[180677] + $lb0w && $lb0w[Y[180449]]);return;
    }$m12[Y[180680]] = String($lb0w[Y[180681]]), $m12[Y[180682]] = String($lb0w[Y[180683]]), setTimeout(function () {
      $m2401($m12[Y[180787]][Y[180801]] + 0x1, $m12[Y[180787]][Y[180024]]);
    }, 0x5dc);
  }, $m021, $m24, function (goac8e) {
    return goac8e[Y[180449]] == Y[180448] || goac8e[Y[180449]] == Y[180803];
  });
}, window['$m2041'] = function () {
  ServerLoading[Y[180036]][Y[180522]]($m12[Y[180527]]), window['$m02'] = !![], window['$m2140']();
}, window['$m2014'] = function () {
  if (window['$m20'] && window['$m102'] && window[Y[180518]] && window[Y[180521]] && window['$m120'] && window['$m10']) {
    if (!window[Y[180804]][Y[180036]]) {
      console[Y[180042]](Y[180805] + window[Y[180804]][Y[180036]]);var sg64 = wx[Y[180806]](),
          e8coga = sg64[Y[180138]] ? sg64[Y[180138]] : 0x0,
          a6cosg = { 'cdn': window['$m12'][Y[180021]], 'spareCdn': window['$m12'][Y[180650]], 'newRegister': window['$m12'][Y[180527]], 'wxPC': window['$m12'][Y[180113]], 'wxIOS': window['$m12'][Y[180107]], 'wxAndroid': window['$m12'][Y[180110]], 'wxParam': { 'limitLoad': window['$m12']['$m54021'], 'benchmarkLevel': window['$m12']['$m54102'], 'wxFrom': window[Y[180006]][Y[180657]] == Y[180807] ? 0x1 : 0x0, 'wxSDKVersion': window[Y[180040]] }, 'configType': window['$m12'][Y[180594]], 'exposeType': window['$m12'][Y[180596]], 'scene': e8coga };new window[Y[180804]](a6cosg, window['$m12'][Y[180020]], window['$m54012']);
    }
  }
}, window['$m2140'] = function () {
  if (window['$m20'] && window['$m102'] && window[Y[180518]] && window[Y[180521]] && window['$m120'] && window['$m10'] && window['$m02'] && window['$m01']) {
    $m4120();if (!$m201) {
      $m201 = !![];if (!window[Y[180804]][Y[180036]]) window['$m2014']();var ztc2e = 0x0,
          a2ec = wx[Y[180808]]();a2ec && (window['$m12'][Y[180112]] && (ztc2e = a2ec[Y[180102]]), console[Y[180001]](Y[180809] + a2ec[Y[180102]] + Y[180810] + a2ec[Y[180103]] + Y[180811] + a2ec[Y[180104]] + Y[180812] + a2ec[Y[180105]] + Y[180813] + a2ec[Y[180313]] + Y[180814] + a2ec[Y[180315]]));var t2ce = {};for (const lh in $m12[Y[180023]]) {
        t2ce[lh] = $m12[Y[180023]][lh];
      }var m5hnj = { 'channel': window['$m12'][Y[180588]], 'account': window['$m12'][Y[180019]], 'userId': window['$m12'][Y[180678]], 'cdn': window['$m12'][Y[180021]], 'data': window['$m12'][Y[180450]], 'package': window['$m12'][Y[180573]], 'newRegister': window['$m12'][Y[180527]], 'pkgName': window['$m12'][Y[180022]], 'partnerId': window['$m12'][Y[180584]], 'platform_uid': window['$m12'][Y[180679]], 'deviceId': window['$m12'][Y[180585]], 'selectedServer': t2ce, 'configType': window['$m12'][Y[180594]], 'exposeType': window['$m12'][Y[180596]], 'debugUsers': window['$m12'][Y[180591]], 'wxMenuTop': ztc2e, 'wxShield': window['$m12'][Y[180597]] };if (window[Y[180704]]) for (var bw0$l in window[Y[180704]]) {
        m5hnj[bw0$l] = window[Y[180704]][bw0$l];
      }window[Y[180804]][Y[180036]]['$m215'](m5hnj);
    }
  } else console[Y[180001]](Y[180815] + window['$m20'] + Y[180816] + window['$m102'] + Y[180817] + window[Y[180518]] + Y[180818] + window[Y[180521]] + Y[180819] + window['$m120'] + Y[180820] + window['$m10'] + Y[180821] + window['$m02'] + Y[180822] + window['$m01']);
};