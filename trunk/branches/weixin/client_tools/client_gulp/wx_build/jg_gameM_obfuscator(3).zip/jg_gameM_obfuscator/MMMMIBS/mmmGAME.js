var Y = wx.$M;
console[Y[180001]](Y[180002]), window[Y[180003]], wx[Y[180004]](function (o64gs_) {
  if (o64gs_) {
    if (o64gs_[Y[180005]]) {
      var pzet8 = window[Y[180006]][Y[180007]][Y[180008]](new RegExp(/\./, 'g'), '_'),
          rxk91v = o64gs_[Y[180005]],
          oga46 = rxk91v[Y[180009]](/(MMMMMMMM\/mmmGAME.js:)[0-9]{1,60}(:)/g);if (oga46) for (var krvf1 = 0x0; krvf1 < oga46[Y[180010]]; krvf1++) {
        if (oga46[krvf1] && oga46[krvf1][Y[180010]] > 0x0) {
          var oa6gc8 = parseInt(oga46[krvf1][Y[180008]](Y[180011], '')[Y[180008]](':', ''));rxk91v = rxk91v[Y[180008]](oga46[krvf1], oga46[krvf1][Y[180008]](':' + oa6gc8 + ':', ':' + (oa6gc8 - 0x2) + ':'));
        }
      }rxk91v = rxk91v[Y[180008]](new RegExp(Y[180012], 'g'), Y[180013] + pzet8 + Y[180014]), rxk91v = rxk91v[Y[180008]](new RegExp(Y[180015], 'g'), Y[180013] + pzet8 + Y[180014]), o64gs_[Y[180005]] = rxk91v;
    }var fkvr = { 'id': window['$m12'][Y[180016]], 'role': window['$m12'][Y[180017]], 'level': window['$m12'][Y[180018]], 'user': window['$m12'][Y[180019]], 'version': window['$m12'][Y[180020]], 'cdn': window['$m12'][Y[180021]], 'pkgName': window['$m12'][Y[180022]], 'gamever': window[Y[180006]][Y[180007]], 'serverid': window['$m12'][Y[180023]] ? window['$m12'][Y[180023]][Y[180024]] : 0x0, 'systemInfo': window[Y[180025]], 'error': Y[180026], 'stack': o64gs_ ? o64gs_[Y[180005]] : '' },
        h7m_ = JSON[Y[180027]](fkvr);console[Y[180028]](Y[180029] + h7m_), (!window[Y[180003]] || window[Y[180003]] != fkvr[Y[180028]]) && (window[Y[180003]] = fkvr[Y[180028]], window['$m41'](fkvr));
  }
});import 'mmmmmmmmMDFIVEMIN.js';import 'mmmZLIBS.js';window[Y[180030]] = require(Y[180031]);import 'mmmmINDEX.js';import 'mmmmmmmLIBSMIN.js';import 'mmmmWXMINI.js';import 'mmmINITMIN.js';console[Y[180001]](Y[180032]), console[Y[180001]](Y[180033]), $m4102({ 'title': Y[180034] });var M_mlhi5n = { '$m54210': !![] };new window[Y[180035]](M_mlhi5n), window[Y[180035]][Y[180036]]['$m50124']();if (window['$m54120']) clearInterval(window['$m54120']);window['$m54120'] = null, window['$m50241'] = function (vrxk1, o4ag) {
  if (!vrxk1 || !o4ag) return 0x0;vrxk1 = vrxk1[Y[180037]]('.'), o4ag = o4ag[Y[180037]]('.');const $wv = Math[Y[180038]](vrxk1[Y[180010]], o4ag[Y[180010]]);while (vrxk1[Y[180010]] < $wv) {
    vrxk1[Y[180039]]('0');
  }while (o4ag[Y[180010]] < $wv) {
    o4ag[Y[180039]]('0');
  }for (var acg6 = 0x0; acg6 < $wv; acg6++) {
    const kyqxu = parseInt(vrxk1[acg6]),
          nmh_j = parseInt(o4ag[acg6]);if (kyqxu > nmh_j) return 0x1;else {
      if (kyqxu < nmh_j) return -0x1;
    }
  }return 0x0;
}, window[Y[180040]] = wx[Y[180041]]()[Y[180040]], console[Y[180042]](Y[180043] + window[Y[180040]]);var M_brwf9v = wx[Y[180044]]();M_brwf9v[Y[180045]](function (mh74j_) {
  console[Y[180042]](Y[180046] + mh74j_[Y[180047]]);
}), M_brwf9v[Y[180048]](function () {
  wx[Y[180049]]({ 'title': Y[180050], 'content': Y[180051], 'showCancel': ![], 'success': function (c2ze8t) {
      M_brwf9v[Y[180052]]();
    } });
}), M_brwf9v[Y[180053]](function () {
  console[Y[180042]](Y[180054]);
}), window['$m50214'] = function () {
  console[Y[180042]](Y[180055]);var n5l$0 = wx[Y[180056]]({ 'name': Y[180057], 'success': function (xurk1) {
      console[Y[180042]](Y[180058]), console[Y[180042]](xurk1), xurk1 && xurk1[Y[180059]] == Y[180060] ? (window['$m20'] = !![], window['$m2014'](), window['$m2140']()) : setTimeout(function () {
        window['$m50214']();
      }, 0x1f4);
    }, 'fail': function (ild0$) {
      console[Y[180042]](Y[180061]), console[Y[180042]](ild0$), setTimeout(function () {
        window['$m50214']();
      }, 0x1f4);
    } });n5l$0 && n5l$0[Y[180062]](bwvfr9 => {});
}, window['$m51420'] = function () {
  console[Y[180042]](Y[180063]);var uk9yx1 = wx[Y[180056]]({ 'name': Y[180064], 'success': function (e8tz) {
      console[Y[180042]](Y[180065]), console[Y[180042]](e8tz), e8tz && e8tz[Y[180059]] == Y[180060] ? (window['$m102'] = !![], window['$m2014'](), window['$m2140']()) : setTimeout(function () {
        window['$m51420']();
      }, 0x1f4);
    }, 'fail': function (mj7_4) {
      console[Y[180042]](Y[180066]), console[Y[180042]](mj7_4), setTimeout(function () {
        window['$m51420']();
      }, 0x1f4);
    } });uk9yx1 && uk9yx1[Y[180062]](ogc6s => {});
}, window[Y[180067]] = function () {
  window['$m50241'](window[Y[180040]], Y[180068]) >= 0x0 ? (console[Y[180042]](Y[180069] + window[Y[180040]] + Y[180070]), window['$m14'](), window['$m50214'](), window['$m51420']()) : (window['$m124'](Y[180071], window[Y[180040]]), wx[Y[180049]]({ 'title': Y[180072], 'content': Y[180073] }));
}, window[Y[180025]] = '', wx[Y[180074]]({ 'success'(vrk19f) {
    window[Y[180025]] = Y[180075] + vrk19f[Y[180076]] + Y[180077] + vrk19f[Y[180078]] + Y[180079] + vrk19f[Y[180080]] + Y[180081] + vrk19f[Y[180082]] + Y[180083] + vrk19f[Y[180084]] + Y[180085] + vrk19f[Y[180040]] + Y[180086] + vrk19f[Y[180087]], console[Y[180042]](window[Y[180025]]), console[Y[180042]](Y[180088] + vrk19f[Y[180089]] + Y[180090] + vrk19f[Y[180091]] + Y[180092] + vrk19f[Y[180093]] + Y[180094] + vrk19f[Y[180095]] + Y[180096] + vrk19f[Y[180097]] + Y[180098] + vrk19f[Y[180099]] + Y[180100] + (vrk19f[Y[180101]] ? vrk19f[Y[180101]][Y[180102]] + ',' + vrk19f[Y[180101]][Y[180103]] + ',' + vrk19f[Y[180101]][Y[180104]] + ',' + vrk19f[Y[180101]][Y[180105]] : ''));var brvfd = vrk19f[Y[180082]] ? vrk19f[Y[180082]][Y[180106]]() : '',
        krx1 = vrk19f[Y[180078]] ? vrk19f[Y[180078]][Y[180106]]()[Y[180008]]('\x20', '') : '';window['$m12'][Y[180107]] = brvfd[Y[180108]](Y[180109]) != -0x1, window['$m12'][Y[180110]] = brvfd[Y[180108]](Y[180111]) != -0x1, window['$m12'][Y[180112]] = brvfd[Y[180108]](Y[180109]) != -0x1 || brvfd[Y[180108]](Y[180111]) != -0x1, window['$m12'][Y[180113]] = brvfd[Y[180108]](Y[180114]) != -0x1 || brvfd[Y[180108]](Y[180115]) != -0x1, window['$m12'][Y[180116]] = vrk19f[Y[180084]] ? vrk19f[Y[180084]][Y[180106]]() : '', window['$m12']['$m54021'] = ![], window['$m12']['$m54102'] = 0x2;if (brvfd[Y[180108]](Y[180111]) != -0x1) {
      if (vrk19f[Y[180087]] >= 0x18) window['$m12']['$m54102'] = 0x3;else window['$m12']['$m54102'] = 0x2;
    } else {
      if (brvfd[Y[180108]](Y[180109]) != -0x1) {
        if (vrk19f[Y[180087]] && vrk19f[Y[180087]] >= 0x14) window['$m12']['$m54102'] = 0x3;else {
          if (krx1[Y[180108]](Y[180117]) != -0x1 || krx1[Y[180108]](Y[180118]) != -0x1 || krx1[Y[180108]](Y[180119]) != -0x1 || krx1[Y[180108]](Y[180120]) != -0x1 || krx1[Y[180108]](Y[180121]) != -0x1) window['$m12']['$m54102'] = 0x2;else window['$m12']['$m54102'] = 0x3;
        }
      } else window['$m12']['$m54102'] = 0x2;
    }console[Y[180042]](Y[180122] + window['$m12']['$m54021'] + Y[180123] + window['$m12']['$m54102']);
  } }), wx[Y[180124]]({ 'success': function (rvwbf) {
    console[Y[180042]](Y[180125] + rvwbf[Y[180126]] + Y[180127] + rvwbf[Y[180128]]);
  } }), wx[Y[180129]]({ 'success': function (_6sj) {
    console[Y[180042]](Y[180130] + _6sj[Y[180131]]);
  } }), wx[Y[180132]]({ 'keepScreenOn': !![] }), wx[Y[180133]](function (rf9vw) {
  console[Y[180042]](Y[180130] + rf9vw[Y[180131]] + Y[180134] + rf9vw[Y[180135]]);
}), wx[Y[180136]](function (krfv91) {
  window['$m04'] = krfv91, window['$m240'] && window['$m04'] && (console[Y[180001]](Y[180137] + window['$m04'][Y[180138]]), window['$m240'](window['$m04']), window['$m04'] = null);
}), window[Y[180139]] = 0x0, window['$m51024'] = 0x0, window[Y[180140]] = null, wx[Y[180141]](function () {
  window['$m51024']++;var m7_j4s = Date[Y[180142]]();(window[Y[180139]] == 0x0 || m7_j4s - window[Y[180139]] > 0x1d4c0) && (console[Y[180143]](Y[180144]), wx[Y[180145]]());if (window['$m51024'] >= 0x2) {
    window['$m51024'] = 0x0, console[Y[180028]](Y[180146]), wx[Y[180147]]('0', 0x1);if (window['$m12'] && window['$m12'][Y[180107]]) window['$m124'](Y[180148], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});