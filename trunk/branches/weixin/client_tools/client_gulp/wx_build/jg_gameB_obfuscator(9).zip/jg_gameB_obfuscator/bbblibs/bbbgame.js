var _ = wx.y$;
console[_[78]](_[28976]), window[_[28977]], wx[_[28978]](function (hjifgk) {
  if (hjifgk) {
    if (hjifgk[_[4525]]) {
      var aebf = window[_[555]][_[28979]][_[4703]](new RegExp(/\./, 'g'), '_'),
          baefd = hjifgk[_[4525]],
          npqr = baefd[_[12054]](/(bbbbbbbbb\/bbbgame.js:)[0-9]{1,60}(:)/g);if (npqr) for (var qosrn = 0x0; qosrn < npqr[_[13]]; qosrn++) {
        if (npqr[qosrn] && npqr[qosrn][_[13]] > 0x0) {
          var wutxvs = parseInt(npqr[qosrn][_[4703]](_[28980], '')[_[4703]](':', ''));baefd = baefd[_[4703]](npqr[qosrn], npqr[qosrn][_[4703]](':' + wutxvs + ':', ':' + (wutxvs - 0x2) + ':'));
        }
      }baefd = baefd[_[4703]](new RegExp(_[28981], 'g'), _[28982] + aebf + _[25319]), baefd = baefd[_[4703]](new RegExp(_[28983], 'g'), _[28982] + aebf + _[25319]), hjifgk[_[4525]] = baefd;
    }var qustv = { 'id': window['p$DE'][_[28984]], 'role': window['p$DE'][_[4645]], 'level': window['p$DE'][_[28985]], 'user': window['p$DE'][_[25219]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4524]], 'pkgName': window['p$DE'][_[25220]], 'gamever': window[_[555]][_[28979]], 'serverid': window['p$DE'][_[25214]] ? window['p$DE'][_[25214]][_[11510]] : 0x0, 'systemInfo': window[_[28986]], 'error': _[28987], 'stack': hjifgk ? hjifgk[_[4525]] : '' },
        wvstru = JSON[_[4510]](qustv);console[_[125]](_[28988] + wvstru), (!window[_[28977]] || window[_[28977]] != qustv[_[125]]) && (window[_[28977]] = qustv[_[125]], window['p$BD'](qustv));
  }
});import 'bbbmd5min.js';import 'bbbzlibs.js';window[_[28989]] = require(_[28990]);import 'bbbindex.js';import 'bbblibsmin.js';import 'bbbwxmini.js';import 'bbbinitmin.js';console[_[78]](_[28991]), console[_[78]](_[28992]), p$BDCE({ 'title': _[28993] });var _dknolpm = { 'p$ABEDC': !![] };new window[_[28994]](_dknolpm), window[_[28994]][_[148]]['p$ACDEB']();if (window['p$ABDEC']) clearInterval(window['p$ABDEC']);window['p$ABDEC'] = null, window['p$ACEBD'] = function (uwtvsr, gcfebd) {
  if (!uwtvsr || !gcfebd) return 0x0;uwtvsr = uwtvsr[_[15]]('.'), gcfebd = gcfebd[_[15]]('.');const npqlo = Math[_[851]](uwtvsr[_[13]], gcfebd[_[13]]);while (uwtvsr[_[13]] < npqlo) {
    uwtvsr[_[29]]('0');
  }while (gcfebd[_[13]] < npqlo) {
    gcfebd[_[29]]('0');
  }for (var xywutv = 0x0; xywutv < npqlo; xywutv++) {
    const wvtu = parseInt(uwtvsr[xywutv]),
          _y$xz0 = parseInt(gcfebd[xywutv]);if (wvtu > _y$xz0) return 0x1;else {
      if (wvtu < _y$xz0) return -0x1;
    }
  }return 0x0;
}, window[_[28995]] = wx[_[28996]]()[_[28995]], console[_[480]](_[28997] + window[_[28995]]);var _d$x_zw = wx[_[28998]]();_d$x_zw[_[28999]](function (oqlpmn) {
  console[_[480]](_[29000] + oqlpmn[_[29001]]);
}), _d$x_zw[_[29002]](function () {
  wx[_[29003]]({ 'title': _[29004], 'content': _[29005], 'showCancel': ![], 'success': function (txvuwy) {
      _d$x_zw[_[29006]]();
    } });
}), _d$x_zw[_[29007]](function () {
  console[_[480]](_[29008]);
}), window['p$ACEDB'] = function () {
  console[_[480]](_[29009]);var $_xz = wx[_[29010]]({ 'name': _[29011], 'success': function (mnjlo) {
      console[_[480]](_[29012]), console[_[480]](mnjlo), mnjlo && mnjlo[_[25405]] == _[29013] ? (window['p$EC'] = !![], window['p$ECDB'](), window['p$EDBC']()) : setTimeout(function () {
        window['p$ACEDB']();
      }, 0x1f4);
    }, 'fail': function (onq) {
      console[_[480]](_[29014]), console[_[480]](onq), setTimeout(function () {
        window['p$ACEDB']();
      }, 0x1f4);
    } });$_xz && $_xz[_[29015]](fgh => {});
}, window['p$ADBEC'] = function () {
  console[_[480]](_[29016]);var pomnk = wx[_[29010]]({ 'name': _[29017], 'success': function (pustq) {
      console[_[480]](_[29018]), console[_[480]](pustq), pustq && pustq[_[25405]] == _[29013] ? (window['p$DCE'] = !![], window['p$ECDB'](), window['p$EDBC']()) : setTimeout(function () {
        window['p$ADBEC']();
      }, 0x1f4);
    }, 'fail': function (uwrvts) {
      console[_[480]](_[29019]), console[_[480]](uwrvts), setTimeout(function () {
        window['p$ADBEC']();
      }, 0x1f4);
    } });pomnk && pomnk[_[29015]](ljinmk => {});
}, window[_[29020]] = function () {
  window['p$ACEBD'](window[_[28995]], _[29021]) >= 0x0 ? (console[_[480]](_[29022] + window[_[28995]] + _[29023]), window['p$DB'](), window['p$ACEDB'](), window['p$ADBEC']()) : (window['p$DEB'](_[29024], window[_[28995]]), wx[_[29003]]({ 'title': _[6361], 'content': _[29025] }));
}, window[_[28986]] = '', wx[_[29026]]({ 'success'(tvrswu) {
    window[_[28986]] = _[29027] + tvrswu[_[29028]] + _[29029] + tvrswu[_[29030]] + _[29031] + tvrswu[_[4716]] + _[29032] + tvrswu[_[473]] + _[29033] + tvrswu[_[25189]] + _[29034] + tvrswu[_[28995]] + _[29035] + tvrswu[_[9309]], console[_[480]](window[_[28986]]), console[_[480]](_[29036] + tvrswu[_[29037]] + _[29038] + tvrswu[_[29039]] + _[29040] + tvrswu[_[29041]] + _[29042] + tvrswu[_[29043]] + _[29044] + tvrswu[_[29045]] + _[29046] + tvrswu[_[29047]] + _[29048] + (tvrswu[_[29049]] ? tvrswu[_[29049]][_[320]] + ',' + tvrswu[_[29049]][_[1213]] + ',' + tvrswu[_[29049]][_[1215]] + ',' + tvrswu[_[29049]][_[1214]] : ''));var xvtswu = tvrswu[_[473]] ? tvrswu[_[473]][_[12339]]() : '',
        jighfe = tvrswu[_[29030]] ? tvrswu[_[29030]][_[12339]]()[_[4703]]('\x20', '') : '';window['p$DE'][_[1072]] = xvtswu[_[115]](_[29050]) != -0x1, window['p$DE'][_[11332]] = xvtswu[_[115]](_[28930]) != -0x1, window['p$DE'][_[29051]] = xvtswu[_[115]](_[29050]) != -0x1 || xvtswu[_[115]](_[28930]) != -0x1, window['p$DE'][_[24908]] = xvtswu[_[115]](_[28931]) != -0x1 || xvtswu[_[115]](_[29052]) != -0x1, window['p$DE'][_[29053]] = tvrswu[_[25189]] ? tvrswu[_[25189]][_[12339]]() : '', window['p$DE']['p$ABCED'] = ![], window['p$DE']['p$ABDCE'] = 0x2;if (xvtswu[_[115]](_[28930]) != -0x1) {
      if (tvrswu[_[9309]] >= 0x18) window['p$DE']['p$ABDCE'] = 0x3;else window['p$DE']['p$ABDCE'] = 0x2;
    } else {
      if (xvtswu[_[115]](_[29050]) != -0x1) {
        if (tvrswu[_[9309]] && tvrswu[_[9309]] >= 0x14) window['p$DE']['p$ABDCE'] = 0x3;else {
          if (jighfe[_[115]](_[29054]) != -0x1 || jighfe[_[115]](_[29055]) != -0x1 || jighfe[_[115]](_[29056]) != -0x1 || jighfe[_[115]](_[29057]) != -0x1 || jighfe[_[115]](_[29058]) != -0x1) window['p$DE']['p$ABDCE'] = 0x2;else window['p$DE']['p$ABDCE'] = 0x3;
        }
      } else window['p$DE']['p$ABDCE'] = 0x2;
    }console[_[480]](_[29059] + window['p$DE']['p$ABCED'] + _[29060] + window['p$DE']['p$ABDCE']);
  } }), wx[_[29061]]({ 'success': function (monkjl) {
    console[_[480]](_[29062] + monkjl[_[4621]] + _[29063] + monkjl[_[29064]]);
  } }), wx[_[29065]]({ 'success': function (qolm) {
    console[_[480]](_[29066] + qolm[_[29067]]);
  } }), wx[_[29068]]({ 'keepScreenOn': !![] }), wx[_[29069]](function (spuqt) {
  console[_[480]](_[29066] + spuqt[_[29067]] + _[29070] + spuqt[_[29071]]);
}), wx[_[10843]](function (wturv) {
  window['p$CB'] = wturv, window['p$EBC'] && window['p$CB'] && (console[_[78]](_[29072] + window['p$CB'][_[774]]), window['p$EBC'](window['p$CB']), window['p$CB'] = null);
}), window[_[29073]] = 0x0, window['p$ADCEB'] = 0x0, window[_[29074]] = null, wx[_[29075]](function () {
  window['p$ADCEB']++;var baedf = Date[_[83]]();(window[_[29073]] == 0x0 || baedf - window[_[29073]] > 0x1d4c0) && (console[_[96]](_[29076]), wx[_[11908]]());if (window['p$ADCEB'] >= 0x2) {
    window['p$ADCEB'] = 0x0, console[_[125]](_[29077]), wx[_[29078]]('0', 0x1);if (window['p$DE'] && window['p$DE'][_[1072]]) window['p$DEB'](_[29079], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});