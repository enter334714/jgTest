var _ = wx.y$;
import _dspqu from '../bbbk/bbbsdk.js';window[_[29080]] = { 'wxVersion': window[_[555]][_[28979]] }, window[_[29081]] = ![], window['p$ED'] = 0x1, window[_[29082]] = 0x1, window['p$CDE'] = !![], window[_[29083]] = !![], window['p$ABCDE'] = '', window['p$DE'] = { 'base_cdn': _[29084], 'cdn': _[29084] }, p$DE[_[29085]] = {}, p$DE[_[24906]] = '0', p$DE[_[4716]] = window[_[29080]][_[29086]], p$DE[_[29052]] = '', p$DE['os'] = '1', p$DE[_[29087]] = _[29088], p$DE[_[29089]] = _[29090], p$DE[_[29091]] = _[29092], p$DE[_[29093]] = _[29094], p$DE[_[29095]] = _[29096], p$DE[_[23641]] = '1', p$DE[_[25220]] = '', p$DE[_[25222]] = '', p$DE[_[29097]] = 0x0, p$DE[_[29098]] = {}, p$DE[_[29099]] = parseInt(p$DE[_[23641]]), p$DE[_[25218]] = p$DE[_[23641]], p$DE[_[25214]] = {}, p$DE['p$BD'] = _[29100], p$DE[_[29101]] = ![], p$DE[_[12244]] = _[29102], p$DE[_[25191]] = Date[_[83]](), p$DE[_[11854]] = _[29103], p$DE[_[712]] = '_a', p$DE[_[29104]] = 0x2, p$DE[_[101]] = 0x7c1, p$DE[_[29086]] = window[_[29080]][_[29086]], p$DE[_[736]] = ![], p$DE[_[1072]] = ![], p$DE[_[11332]] = ![], p$DE[_[24908]] = ![], window['p$CED'] = 0x5, window['p$CE'] = ![], window['p$EC'] = ![], window['p$DCE'] = ![], window[_[29105]] = ![], window[_[29106]] = ![], window['p$DEC'] = ![], window['p$CD'] = ![], window['p$DC'] = ![], window['p$ECD'] = ![], window[_[4185]] = function (hfgcd) {
  console[_[480]](_[4185], hfgcd), wx[_[4995]]({}), wx[_[29003]]({ 'title': _[6361], 'content': hfgcd, 'success'(qurstv) {
      if (qurstv[_[29107]]) console[_[480]](_[29108]);else qurstv[_[551]] && console[_[480]](_[29109]);
    } });
}, window['p$BCDE'] = function (txuwy) {
  console[_[480]](_[29110], txuwy), p$BDEC(), wx[_[29003]]({ 'title': _[6361], 'content': txuwy, 'confirmText': _[29111], 'cancelText': _[18499], 'success'(rupst) {
      if (rupst[_[29107]]) window['p$DB']();else rupst[_[551]] && (console[_[480]](_[29112]), wx[_[25378]]({}));
    } });
}, window[_[29113]] = function (hefcdg) {
  console[_[480]](_[29113], hefcdg), wx[_[29003]]({ 'title': _[6361], 'content': hefcdg, 'confirmText': _[25350], 'showCancel': ![], 'complete'(utsvxw) {
      console[_[480]](_[29112]), wx[_[25378]]({});
    } });
}, window['p$BCED'] = ![], window['p$BDCE'] = function (psnr) {
  window['p$BCED'] = !![], wx[_[4994]](psnr);
}, window['p$BDEC'] = function () {
  window['p$BCED'] && (window['p$BCED'] = ![], wx[_[4995]]({}));
}, window['p$BECD'] = function (upst) {
  window[_[28994]][_[148]]['p$BECD'](upst);
}, window[_[12127]] = function (sutvw, gfed) {
  _dspqu[_[12127]](sutvw, function (gjefih) {
    gjefih && gjefih[_[11]] ? gjefih[_[11]][_[4118]] == 0x1 ? gfed(!![]) : (gfed(![]), console[_[78]](_[29114] + gjefih[_[11]][_[29115]])) : console[_[480]](_[12127], gjefih);
  });
}, window['p$BEDC'] = function (gijhkf) {
  console[_[480]](_[29116], gijhkf);
}, window['p$BDE'] = function (xvzy$w) {}, window['p$BED'] = function (nmkji, jgfhei, xzuy) {}, window['p$BE'] = function (otpq) {
  console[_[480]](_[29117], otpq), window[_[28994]][_[148]][_[29118]](), window[_[28994]][_[148]][_[29119]](), window[_[28994]][_[148]][_[29120]]();
}, window['p$EB'] = function (kjoln) {
  window['p$BCDE'](_[29121]);var ikjnml = { 'id': window['p$DE'][_[28984]], 'role': window['p$DE'][_[4645]], 'level': window['p$DE'][_[28985]], 'account': window['p$DE'][_[25219]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4524]], 'pkgName': window['p$DE'][_[25220]], 'gamever': window[_[555]][_[28979]], 'serverid': window['p$DE'][_[25214]] ? window['p$DE'][_[25214]][_[11510]] : 0x0, 'systemInfo': window[_[28986]], 'error': _[29122], 'stack': kjoln ? kjoln : _[29121] },
      $_wyxz = JSON[_[4510]](ikjnml);console[_[125]](_[29123] + $_wyxz), window['p$BD']($_wyxz);
}, window['p$DBE'] = function (gilkjh) {
  var cdfabe = JSON[_[525]](gilkjh);cdfabe[_[29124]] = window[_[555]][_[28979]], cdfabe[_[29125]] = window['p$DE'][_[25214]] ? window['p$DE'][_[25214]][_[11510]] : 0x0, cdfabe[_[28986]] = window[_[28986]];var fie = JSON[_[4510]](cdfabe);console[_[125]](_[29126] + fie), window['p$BD'](fie);
}, window['p$DEB'] = function (dfecbg, _02z1) {
  var gklhji = { 'id': window['p$DE'][_[28984]], 'role': window['p$DE'][_[4645]], 'level': window['p$DE'][_[28985]], 'account': window['p$DE'][_[25219]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4524]], 'pkgName': window['p$DE'][_[25220]], 'gamever': window[_[555]][_[28979]], 'serverid': window['p$DE'][_[25214]] ? window['p$DE'][_[25214]][_[11510]] : 0x0, 'systemInfo': window[_[28986]], 'error': dfecbg, 'stack': _02z1 },
      rqupt = JSON[_[4510]](gklhji);console[_[96]](_[29127] + rqupt), window['p$BD'](rqupt);
}, window['p$BD'] = function (surtvw) {
  if (window['p$DE'][_[29053]] == _[29128]) return;var gjieh = p$DE['p$BD'] + _[29129] + p$DE[_[25219]];wx[_[475]]({ 'url': gjieh, 'method': _[28844], 'data': surtvw, 'header': { 'content-type': _[29130], 'cache-control': _[29131] }, 'success': function (dfehi) {
      DEBUG && console[_[480]](_[29132], gjieh, surtvw, dfehi);
    }, 'fail': function (upqts) {
      DEBUG && console[_[480]](_[29132], gjieh, surtvw, upqts);
    }, 'complete': function () {} });
}, window[_[29133]] = function () {
  function romp() {
    return ((0x1 + Math[_[119]]()) * 0x10000 | 0x0)[_[272]](0x10)[_[498]](0x1);
  }return romp() + romp() + '-' + romp() + '-' + romp() + '-' + romp() + '+' + romp() + romp() + romp();
}, window['p$DB'] = function () {
  console[_[480]](_[29134]);var qorns = _dspqu[_[29135]]();p$DE[_[25218]] = qorns[_[29136]], p$DE[_[29099]] = qorns[_[29136]], p$DE[_[23641]] = qorns[_[29136]], p$DE[_[25220]] = qorns[_[29137]];var efigj = { 'game_ver': p$DE[_[4716]] };p$DE[_[25222]] = this[_[29133]](), p$BDCE({ 'title': _[29138] }), _dspqu[_[366]](efigj, this['p$EBD'][_[74]](this));
}, window['p$EBD'] = function (xyz$w) {
  var ihjglk = xyz$w[_[29139]];console[_[480]](_[29140] + ihjglk + _[29141] + (ihjglk == 0x1) + _[29142] + xyz$w[_[28979]] + _[29143] + window[_[29080]][_[29086]]);if (!xyz$w[_[28979]] || window['p$ACEBD'](window[_[29080]][_[29086]], xyz$w[_[28979]]) < 0x0) console[_[480]](_[29144]), p$DE[_[29089]] = _[29145], p$DE[_[29091]] = _[29146], p$DE[_[29093]] = _[29147], p$DE[_[4524]] = _[29148], p$DE[_[24905]] = _[29149], p$DE[_[29150]] = _[29151], p$DE[_[736]] = ![];else window['p$ACEBD'](window[_[29080]][_[29086]], xyz$w[_[28979]]) == 0x0 ? (console[_[480]](_[29152]), p$DE[_[29089]] = _[29090], p$DE[_[29091]] = _[29092], p$DE[_[29093]] = _[29094], p$DE[_[4524]] = _[29084], p$DE[_[24905]] = _[29149], p$DE[_[29150]] = _[29151], p$DE[_[736]] = !![]) : (console[_[480]](_[29153]), p$DE[_[29089]] = _[29090], p$DE[_[29091]] = _[29092], p$DE[_[29093]] = _[29094], p$DE[_[4524]] = _[29084], p$DE[_[24905]] = _[29149], p$DE[_[29150]] = _[29151], p$DE[_[736]] = ![]);p$DE[_[29097]] = config[_[28462]] ? config[_[28462]] : 0x0, this['p$CDBE'](), this['p$CDEB'](), window[_[29154]] = 0x5, p$BDCE({ 'title': _[29155] }), _dspqu[_[28867]](this['p$EDB'][_[74]](this));
}, window[_[29154]] = 0x5, window['p$EDB'] = function (vwsrt, upqtsr) {
  if (vwsrt == 0x0 && upqtsr && upqtsr[_[28553]]) {
    p$DE[_[29156]] = upqtsr[_[28553]];var yxwut = this;p$BDCE({ 'title': _[29157] }), sendApi(p$DE[_[29089]], _[29158], { 'platform': p$DE[_[29087]], 'partner_id': p$DE[_[23641]], 'token': upqtsr[_[28553]], 'game_pkg': p$DE[_[25220]], 'deviceId': p$DE[_[25222]], 'scene': _[29159] + p$DE[_[29097]] }, this['p$CBDE'][_[74]](this), p$CED, p$EB);
  } else upqtsr && upqtsr[_[25405]] && window[_[29154]] > 0x0 && (upqtsr[_[25405]][_[115]](_[29160]) != -0x1 || upqtsr[_[25405]][_[115]](_[29161]) != -0x1 || upqtsr[_[25405]][_[115]](_[29162]) != -0x1 || upqtsr[_[25405]][_[115]](_[29163]) != -0x1 || upqtsr[_[25405]][_[115]](_[29164]) != -0x1 || upqtsr[_[25405]][_[115]](_[29165]) != -0x1) ? (window[_[29154]]--, _dspqu[_[28867]](this['p$EDB'][_[74]](this))) : (window['p$DEB'](_[29166], JSON[_[4510]]({ 'status': vwsrt, 'data': upqtsr })), window['p$BCDE'](_[29167] + (upqtsr && upqtsr[_[25405]] ? '，' + upqtsr[_[25405]] : '')));
}, window['p$CBDE'] = function (_z1y0$) {
  if (!_z1y0$) {
    window['p$DEB'](_[29168], _[29169]), window['p$BCDE'](_[29170]);return;
  }if (_z1y0$[_[4118]] != _[9922]) {
    window['p$DEB'](_[29168], JSON[_[4510]](_z1y0$)), window['p$BCDE'](_[29171] + _z1y0$[_[4118]]);return;
  }p$DE[_[23640]] = String(_z1y0$[_[25219]]), p$DE[_[25219]] = String(_z1y0$[_[25219]]), p$DE[_[25189]] = String(_z1y0$[_[25189]]), p$DE[_[25218]] = String(_z1y0$[_[25189]]), p$DE[_[25221]] = String(_z1y0$[_[25221]]), p$DE[_[29172]] = String(_z1y0$[_[11493]]), p$DE[_[29173]] = String(_z1y0$[_[849]]), p$DE[_[11493]] = '';var wuvstx = this;p$BDCE({ 'title': _[29174] }), sendApi(p$DE[_[29089]], _[29175], { 'partner_id': p$DE[_[23641]], 'uid': p$DE[_[25219]], 'version': p$DE[_[4716]], 'game_pkg': p$DE[_[25220]], 'device': p$DE[_[25222]] }, wuvstx['p$CBED'][_[74]](wuvstx), p$CED, p$EB);
}, window['p$CBED'] = function (qnpro) {
  if (!qnpro) {
    window['p$BCDE'](_[29176]);return;
  }if (qnpro[_[4118]] != _[9922]) {
    window['p$BCDE'](_[29177] + qnpro[_[4118]]);return;
  }if (!qnpro[_[11]] || qnpro[_[11]][_[13]] == 0x0) {
    window['p$BCDE'](_[29178]);return;
  }p$DE[_[628]] = qnpro[_[29179]], p$DE[_[25214]] = { 'server_id': String(qnpro[_[11]][0x0][_[11510]]), 'server_name': String(qnpro[_[11]][0x0][_[29180]]), 'entry_ip': qnpro[_[11]][0x0][_[25242]], 'entry_port': parseInt(qnpro[_[11]][0x0][_[25243]]), 'status': p$DCB(qnpro[_[11]][0x0]), 'start_time': qnpro[_[11]][0x0][_[29181]], 'cdn': p$DE[_[4524]] }, this['p$EDCB']();
}, window['p$EDCB'] = function () {
  if (p$DE[_[628]] == 0x1) {
    var tqrosp = p$DE[_[25214]][_[106]];if (tqrosp === -0x1 || tqrosp === 0x0) {
      window['p$BCDE'](tqrosp === -0x1 ? _[29182] : _[29183]);return;
    }p$EBCD(0x0, p$DE[_[25214]][_[11510]]), window[_[28994]][_[148]][_[29184]](p$DE[_[628]]);
  } else window[_[28994]][_[148]][_[29185]](), p$BDEC();window['p$DC'] = !![], window['p$ECDB'](), window['p$EDBC']();
}, window['p$CDBE'] = function () {
  sendApi(p$DE[_[29089]], _[29186], { 'game_pkg': p$DE[_[25220]], 'version_name': p$DE[_[29150]] }, this[_[29187]][_[74]](this), p$CED, p$EB);
}, window[_[29187]] = function (norpsq) {
  if (!norpsq) {
    window['p$BCDE'](_[29188]);return;
  }if (norpsq[_[4118]] != _[9922]) {
    window['p$BCDE'](_[29189] + norpsq[_[4118]]);return;
  }if (!norpsq[_[11]] || !norpsq[_[11]][_[4716]]) {
    window['p$BCDE'](_[29190] + (norpsq[_[11]] && norpsq[_[11]][_[4716]]));return;
  }norpsq[_[11]][_[29191]] && norpsq[_[11]][_[29191]][_[13]] > 0xa && (p$DE[_[29192]] = norpsq[_[11]][_[29191]], p$DE[_[4524]] = norpsq[_[11]][_[29191]]), norpsq[_[11]][_[4716]] && (p$DE[_[101]] = norpsq[_[11]][_[4716]]), console[_[78]](_[25356] + p$DE[_[101]] + _[29193] + p$DE[_[29150]]), window['p$DEC'] = !![], window['p$ECDB'](), window['p$EDBC']();
}, window[_[29194]], window['p$CDEB'] = function () {
  sendApi(p$DE[_[29089]], _[29195], { 'game_pkg': p$DE[_[25220]] }, this['p$CEBD'][_[74]](this), p$CED, p$EB);
}, window['p$CEBD'] = function (trvw) {
  if (trvw[_[4118]] === _[9922] && trvw[_[11]]) {
    window[_[29194]] = trvw[_[11]];for (var bdcefg in trvw[_[11]]) {
      p$DE[bdcefg] = trvw[_[11]][bdcefg];
    }
  } else console[_[78]](_[29196] + trvw[_[4118]]);window['p$CD'] = !![], window['p$EDBC']();
}, window[_[29197]] = function (hfd, yz01$_, lonqpm, qnrsop, y_w$, tswvu, ebfg, qrtusv, wv$yzx) {
  y_w$ = String(y_w$);var imhlj = ebfg,
      ikgjfh = qrtusv;p$DE[_[29085]][y_w$] = { 'productid': y_w$, 'productname': imhlj, 'productdesc': ikgjfh, 'roleid': hfd, 'rolename': yz01$_, 'rolelevel': lonqpm, 'price': tswvu, 'callback': wv$yzx }, sendApi(p$DE[_[29093]], _[29198], { 'game_pkg': p$DE[_[25220]], 'server_id': p$DE[_[25214]][_[11510]], 'server_name': p$DE[_[25214]][_[29180]], 'level': lonqpm, 'uid': p$DE[_[25219]], 'role_id': hfd, 'role_name': yz01$_, 'product_id': y_w$, 'product_name': imhlj, 'product_desc': ikgjfh, 'money': tswvu, 'partner_id': p$DE[_[23641]] }, toPayCallBack, p$CED, p$EB);
}, window[_[29199]] = function (kmlihj) {
  if (kmlihj) {
    if (kmlihj[_[29200]] === 0xc8 || kmlihj[_[4118]] == _[9922]) {
      var $0zx_ = p$DE[_[29085]][String(kmlihj[_[29201]])];if ($0zx_[_[332]]) $0zx_[_[332]](kmlihj[_[29201]], kmlihj[_[29202]], -0x1);_dspqu[_[28925]]({ 'cpbill': kmlihj[_[29202]], 'productid': kmlihj[_[29201]], 'productname': $0zx_[_[29203]], 'productdesc': $0zx_[_[29204]], 'serverid': p$DE[_[25214]][_[11510]], 'servername': p$DE[_[25214]][_[29180]], 'roleid': $0zx_[_[29205]], 'rolename': $0zx_[_[29206]], 'rolelevel': $0zx_[_[29207]], 'price': $0zx_[_[26913]], 'extension': JSON[_[4510]]({ 'cp_order_id': kmlihj[_[29202]] }) }, function (kgilj, swvutr) {
        $0zx_[_[332]] && kgilj == 0x0 && $0zx_[_[332]](kmlihj[_[29201]], kmlihj[_[29202]], kgilj);console[_[78]](JSON[_[4510]]({ 'type': _[29208], 'status': kgilj, 'data': kmlihj, 'role_name': $0zx_[_[29206]] }));if (kgilj === 0x0) {} else {
          if (kgilj === 0x1) {} else {
            if (kgilj === 0x2) {}
          }
        }
      });
    } else alert(kmlihj[_[78]]);
  }
}, window['p$CEDB'] = function () {}, window['p$BCE'] = function (yutvxw, klpom, usqv, mpknlo, defgih) {
  _dspqu[_[28971]](p$DE[_[25214]][_[11510]], p$DE[_[25214]][_[29180]] || p$DE[_[25214]][_[11510]], yutvxw, klpom, usqv), sendApi(p$DE[_[29089]], _[29209], { 'game_pkg': p$DE[_[25220]], 'server_id': p$DE[_[25214]][_[11510]], 'role_id': yutvxw, 'uid': p$DE[_[25219]], 'role_name': klpom, 'role_type': mpknlo, 'level': usqv });
}, window['p$BEC'] = function (kljnm, yxvwz$, ustvwr, $0z_12, hcde, hlijkm, egcdf, suvtqr, fcedhg, hljkg) {
  p$DE[_[28984]] = kljnm, p$DE[_[4645]] = yxvwz$, p$DE[_[28985]] = ustvwr, _dspqu[_[28972]](p$DE[_[25214]][_[11510]], p$DE[_[25214]][_[29180]] || p$DE[_[25214]][_[11510]], kljnm, yxvwz$, ustvwr), sendApi(p$DE[_[29089]], _[29210], { 'game_pkg': p$DE[_[25220]], 'server_id': p$DE[_[25214]][_[11510]], 'role_id': kljnm, 'uid': p$DE[_[25219]], 'role_name': yxvwz$, 'role_type': $0z_12, 'level': ustvwr, 'evolution': hcde });
}, window['p$CBE'] = function (mijhl, fkhg, _$wzxy, swvtu, onrpm, jgfhi, molknp, lji, yxvzu, jimnl) {
  p$DE[_[28984]] = mijhl, p$DE[_[4645]] = fkhg, p$DE[_[28985]] = _$wzxy, _dspqu[_[28973]](p$DE[_[25214]][_[11510]], p$DE[_[25214]][_[29180]] || p$DE[_[25214]][_[11510]], mijhl, fkhg, _$wzxy), sendApi(p$DE[_[29089]], _[29210], { 'game_pkg': p$DE[_[25220]], 'server_id': p$DE[_[25214]][_[11510]], 'role_id': mijhl, 'uid': p$DE[_[25219]], 'role_name': fkhg, 'role_type': swvtu, 'level': _$wzxy, 'evolution': onrpm });
}, window['p$CEB'] = function (zyuxwv) {}, window['p$BC'] = function (ebfcg) {
  _dspqu[_[28904]](_[28904], function (_zy$0) {
    ebfcg && ebfcg(_zy$0);
  });
}, window[_[24889]] = function () {
  _dspqu[_[24889]]();
}, window[_[29211]] = function () {
  _dspqu[_[23534]]();
}, window[_[10843]] = function (sptorq) {
  window['p$EBC'] = sptorq, window['p$EBC'] && window['p$CB'] && (console[_[78]](_[29072] + window['p$CB'][_[774]]), window['p$EBC'](window['p$CB']), window['p$CB'] = null);
}, window['p$ECB'] = function (gechfd, moqnpl, _0xyz$, _3240) {
  window[_[22]](_[29212], { 'game_pkg': window['p$DE'][_[25220]], 'role_id': moqnpl, 'server_id': _0xyz$ }, _3240);
}, window['p$DBCE'] = function (wzyuxv, hgkilj) {
  function ijhmkl(afcdb) {
    var rutwv = [],
        nmoqp = [],
        onpq = window[_[555]][_[29213]];for (var nlmkji in onpq) {
      var becfdg = Number(nlmkji);(!wzyuxv || !wzyuxv[_[13]] || wzyuxv[_[115]](becfdg) != -0x1) && (nmoqp[_[29]](onpq[nlmkji]), rutwv[_[29]]([becfdg, 0x3]));
    }window['p$ACEBD'](window[_[28995]], _[29214]) >= 0x0 ? (console[_[480]](_[29215]), _dspqu[_[28968]](nmoqp, function (vqrtu) {
      console[_[480]](_[29216]), console[_[480]](vqrtu);if (vqrtu && vqrtu[_[25405]] == _[29217]) for (var mkjol in onpq) {
        if (vqrtu[onpq[mkjol]] == _[29218]) {
          var wutsv = Number(mkjol);for (var nqospr = 0x0; nqospr < rutwv[_[13]]; nqospr++) {
            if (rutwv[nqospr][0x0] == wutsv) {
              rutwv[nqospr][0x1] = 0x1;break;
            }
          }
        }
      }window['p$ACEBD'](window[_[28995]], _[29219]) >= 0x0 ? wx[_[29220]]({ 'withSubscriptions': !![], 'success': function (z0x_$y) {
          var xvzy$ = z0x_$y[_[29221]][_[29222]];if (xvzy$) {
            console[_[480]](_[29223]), console[_[480]](xvzy$);for (var kljm in onpq) {
              if (xvzy$[onpq[kljm]] == _[29218]) {
                var egdfch = Number(kljm);for (var mjikn = 0x0; mjikn < rutwv[_[13]]; mjikn++) {
                  if (rutwv[mjikn][0x0] == egdfch) {
                    rutwv[mjikn][0x1] = 0x2;break;
                  }
                }
              }
            }console[_[480]](rutwv), hgkilj && hgkilj(rutwv);
          } else console[_[480]](_[29224]), console[_[480]](z0x_$y), console[_[480]](rutwv), hgkilj && hgkilj(rutwv);
        }, 'fail': function () {
          console[_[480]](_[29225]), console[_[480]](rutwv), hgkilj && hgkilj(rutwv);
        } }) : (console[_[480]](_[29226] + window[_[28995]]), console[_[480]](rutwv), hgkilj && hgkilj(rutwv));
    })) : (console[_[480]](_[29227] + window[_[28995]]), console[_[480]](rutwv), hgkilj && hgkilj(rutwv)), wx[_[29228]](ijhmkl);
  }wx[_[29229]](ijhmkl);
}, window['p$DBEC'] = { 'isSuccess': ![], 'level': _[29230], 'isCharging': ![] }, window['p$DCBE'] = function ($10z_2) {
  wx[_[29061]]({ 'success': function (mkjlhi) {
      var ploknm = window['p$DBEC'];ploknm[_[29231]] = !![], ploknm[_[4621]] = Number(mkjlhi[_[4621]])[_[4233]](0x0), ploknm[_[29064]] = mkjlhi[_[29064]], $10z_2 && $10z_2(ploknm[_[29231]], ploknm[_[4621]], ploknm[_[29064]]);
    }, 'fail': function (sruv) {
      console[_[480]](_[29232], sruv[_[25405]]);var ptors = window['p$DBEC'];$10z_2 && $10z_2(ptors[_[29231]], ptors[_[4621]], ptors[_[29064]]);
    } });
}, window[_[22]] = function (vtwyu, hjig, gfjk, efdabc, z_$y0x, heifgd, z10$_y, cdbefg) {
  if (efdabc == undefined) efdabc = 0x1;wx[_[475]]({ 'url': vtwyu, 'method': z10$_y || _[25108], 'responseType': _[4430], 'data': hjig, 'header': { 'content-type': cdbefg || _[29130] }, 'success': function (utwvrs) {
      DEBUG && console[_[480]](_[29233], vtwyu, info, utwvrs);if (utwvrs && utwvrs[_[25471]] == 0xc8) {
        var khgijf = utwvrs[_[11]];!heifgd || heifgd(khgijf) ? gfjk && gfjk(khgijf) : window[_[29234]](vtwyu, hjig, gfjk, efdabc, z_$y0x, heifgd, utwvrs);
      } else window[_[29234]](vtwyu, hjig, gfjk, efdabc, z_$y0x, heifgd, utwvrs);
    }, 'fail': function (nmk) {
      DEBUG && console[_[480]](_[29235], vtwyu, info, nmk), window[_[29234]](vtwyu, hjig, gfjk, efdabc, z_$y0x, heifgd, nmk);
    }, 'complete': function () {} });
}, window[_[29234]] = function (ljihkg, snoqrp, _132$0, nqormp, wtrvsu, dcebgf, tqruv) {
  nqormp - 0x1 > 0x0 ? setTimeout(function () {
    window[_[22]](ljihkg, snoqrp, _132$0, nqormp - 0x1, wtrvsu, dcebgf);
  }, 0x3e8) : wtrvsu && wtrvsu(JSON[_[4510]]({ 'url': ljihkg, 'response': tqruv }));
}, window[_[29236]] = function (proqmn, oknpl, z$_xyw, gedfhc, tuxs, wvty, dcefbg) {
  !z$_xyw && (z$_xyw = {});var ebcfa = Math[_[118]](Date[_[83]]() / 0x3e8);z$_xyw[_[849]] = ebcfa, z$_xyw[_[25029]] = oknpl;var xwzyv = Object[_[264]](z$_xyw)[_[1076]](),
      prns = '',
      _03412 = '';for (var lqomn = 0x0; lqomn < xwzyv[_[13]]; lqomn++) {
    prns = prns + (lqomn == 0x0 ? '' : '&') + xwzyv[lqomn] + z$_xyw[xwzyv[lqomn]], _03412 = _03412 + (lqomn == 0x0 ? '' : '&') + xwzyv[lqomn] + '=' + encodeURIComponent(z$_xyw[xwzyv[lqomn]]);
  }prns = prns + p$DE[_[29095]];var edcf = _[29237] + md5(prns);send(proqmn + '?' + _03412 + (_03412 == '' ? '' : '&') + edcf, null, gedfhc, tuxs, wvty, dcefbg || function (sqvur) {
    return sqvur[_[4118]] == _[9922];
  }, null, _[28845]);
}, window['p$DCEB'] = function (kjmhl, hijkg) {
  var _z$yw = 0x0;p$DE[_[25214]] && (_z$yw = p$DE[_[25214]][_[11510]]), sendApi(p$DE[_[29091]], _[29238], { 'partnerId': p$DE[_[23641]], 'gamePkg': p$DE[_[25220]], 'logTime': Math[_[118]](Date[_[83]]() / 0x3e8), 'platformUid': p$DE[_[25221]], 'type': kjmhl, 'serverId': _z$yw }, null, 0x2, null, function () {
    return !![];
  });
}, window['p$DEBC'] = function (ihgjkf) {
  sendApi(p$DE[_[29089]], _[29239], { 'partner_id': p$DE[_[23641]], 'uid': p$DE[_[25219]], 'version': p$DE[_[4716]], 'game_pkg': p$DE[_[25220]], 'device': p$DE[_[25222]] }, p$DECB, p$CED, p$EB);
}, window['p$DECB'] = function (xyz_$w) {
  if (xyz_$w[_[4118]] === _[9922] && xyz_$w[_[11]]) {
    xyz_$w[_[11]][_[5598]]({ 'id': -0x2, 'name': _[29240] }), xyz_$w[_[11]][_[5598]]({ 'id': -0x1, 'name': _[29241] }), p$DE[_[29242]] = xyz_$w[_[11]];if (window[_[12290]]) window[_[12290]][_[29243]]();
  } else p$DE[_[29244]] = ![], window['p$BCDE'](_[29245] + xyz_$w[_[4118]]);
}, window['p$BCD'] = function (lpqnmo) {
  sendApi(p$DE[_[29089]], _[29246], { 'partner_id': p$DE[_[23641]], 'uid': p$DE[_[25219]], 'version': p$DE[_[4716]], 'game_pkg': p$DE[_[25220]], 'device': p$DE[_[25222]] }, p$BDC, p$CED, p$EB);
}, window['p$BDC'] = function (fihge) {
  p$DE[_[29247]] = ![];if (fihge[_[4118]] === _[9922] && fihge[_[11]]) {
    for (var wtsxuv = 0x0; wtsxuv < fihge[_[11]][_[13]]; wtsxuv++) {
      fihge[_[11]][wtsxuv][_[106]] = p$DCB(fihge[_[11]][wtsxuv]);
    }p$DE[_[29098]][-0x1] = window[_[29248]](fihge[_[11]]), window[_[12290]][_[29249]](-0x1);
  } else window['p$BCDE'](_[29250] + fihge[_[4118]]);
}, window[_[29251]] = function (jhigf) {
  sendApi(p$DE[_[29089]], _[29246], { 'partner_id': p$DE[_[23641]], 'uid': p$DE[_[25219]], 'version': p$DE[_[4716]], 'game_pkg': p$DE[_[25220]], 'device': p$DE[_[25222]] }, jhigf, p$CED, p$EB);
}, window['p$CBD'] = function (hefgi, $_xwy) {
  sendApi(p$DE[_[29089]], _[29252], { 'partner_id': p$DE[_[23641]], 'uid': p$DE[_[25219]], 'version': p$DE[_[4716]], 'game_pkg': p$DE[_[25220]], 'device': p$DE[_[25222]], 'server_group_id': $_xwy }, p$CDB, p$CED, p$EB);
}, window['p$CDB'] = function (cedbg) {
  p$DE[_[29247]] = ![];if (cedbg[_[4118]] === _[9922] && cedbg[_[11]] && cedbg[_[11]][_[11]]) {
    var qoprmn = cedbg[_[11]][_[29253]],
        qrstop = [];for (var lin = 0x0; lin < cedbg[_[11]][_[11]][_[13]]; lin++) {
      cedbg[_[11]][_[11]][lin][_[106]] = p$DCB(cedbg[_[11]][_[11]][lin]), (qrstop[_[13]] == 0x0 || cedbg[_[11]][_[11]][lin][_[106]] != 0x0) && (qrstop[qrstop[_[13]]] = cedbg[_[11]][_[11]][lin]);
    }p$DE[_[29098]][qoprmn] = window[_[29248]](qrstop), window[_[12290]][_[29249]](qoprmn);
  } else window['p$BCDE'](_[29254] + cedbg[_[4118]]);
}, window['p$ACED'] = function (mlhik) {
  sendApi(p$DE[_[29089]], _[29255], { 'partner_id': p$DE[_[23641]], 'uid': p$DE[_[25219]], 'version': p$DE[_[4716]], 'game_pkg': p$DE[_[25220]], 'device': p$DE[_[25222]] }, reqServerRecommendCallBack, p$CED, p$EB);
}, window[_[29256]] = function (_xyz0$) {
  p$DE[_[29247]] = ![];if (_xyz0$[_[4118]] === _[9922] && _xyz0$[_[11]]) {
    for (var jfigh = 0x0; jfigh < _xyz0$[_[11]][_[13]]; jfigh++) {
      _xyz0$[_[11]][jfigh][_[106]] = p$DCB(_xyz0$[_[11]][jfigh]);
    }p$DE[_[29098]][-0x2] = window[_[29248]](_xyz0$[_[11]]), window[_[12290]][_[29249]](-0x2);
  } else alert(_[29257] + _xyz0$[_[4118]]);
}, window[_[29248]] = function (wuyxtv) {
  if (!wuyxtv && wuyxtv[_[13]] <= 0x0) return wuyxtv;for (let hfgijk = 0x0; hfgijk < wuyxtv[_[13]]; hfgijk++) {
    wuyxtv[hfgijk][_[29258]] && wuyxtv[hfgijk][_[29258]] == 0x1 && (wuyxtv[hfgijk][_[29180]] += _[29259]);
  }return wuyxtv;
}, window['p$DBC'] = function (lqpnm, chefd) {
  lqpnm = lqpnm || p$DE[_[25214]][_[11510]], sendApi(p$DE[_[29089]], _[29260], { 'type': '4', 'game_pkg': p$DE[_[25220]], 'server_id': lqpnm }, chefd);
}, window[_[29261]] = function (klmhji, y$1_, kilmjh, efgji) {
  kilmjh = kilmjh || p$DE[_[25214]][_[11510]], sendApi(p$DE[_[29089]], _[29262], { 'type': klmhji, 'game_pkg': y$1_, 'server_id': kilmjh }, efgji);
}, window['p$DCB'] = function ($0_yz1) {
  if ($0_yz1) {
    if ($0_yz1[_[106]] == 0x1) {
      if ($0_yz1[_[29263]] == 0x1) return 0x2;else return 0x1;
    } else return $0_yz1[_[106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['p$EBCD'] = function (_02413, pqmlon) {
  p$DE[_[29264]] = { 'step': _02413, 'server_id': pqmlon };var zy$_ = this;p$BDCE({ 'title': _[29265] }), sendApi(p$DE[_[29089]], _[29266], { 'partner_id': p$DE[_[23641]], 'uid': p$DE[_[25219]], 'game_pkg': p$DE[_[25220]], 'server_id': pqmlon, 'platform': p$DE[_[25189]], 'platform_uid': p$DE[_[25221]], 'check_login_time': p$DE[_[29173]], 'check_login_sign': p$DE[_[29172]], 'version_name': p$DE[_[29150]] }, p$EBDC, p$CED, p$EB, function (bcfd) {
    return bcfd[_[4118]] == _[9922] || bcfd[_[78]] == _[29267] || bcfd[_[78]] == _[29268];
  });
}, window['p$EBDC'] = function (mhlki) {
  var ejh = this;if (mhlki[_[4118]] === _[9922] && mhlki[_[11]]) {
    var dghief = p$DE[_[25214]];dghief[_[29269]] = p$DE[_[29099]], dghief[_[11493]] = String(mhlki[_[11]][_[29270]]), dghief[_[25191]] = parseInt(mhlki[_[11]][_[849]]);if (mhlki[_[11]][_[25190]]) dghief[_[25190]] = parseInt(mhlki[_[11]][_[25190]]);else dghief[_[25190]] = parseInt(mhlki[_[11]][_[11510]]);dghief[_[29271]] = 0x0, dghief[_[4524]] = p$DE[_[29192]], dghief[_[29272]] = mhlki[_[11]][_[29273]], dghief[_[29274]] = mhlki[_[11]][_[29274]], console[_[480]](_[29275] + JSON[_[4510]](dghief[_[29274]])), p$DE[_[628]] == 0x1 && dghief[_[29274]] && dghief[_[29274]][_[29276]] == 0x1 && (p$DE[_[29277]] = 0x1, window[_[28994]][_[148]]['p$AED']()), p$ECBD();
  } else p$DE[_[29264]][_[7118]] >= 0x3 ? (p$EB(JSON[_[4510]](mhlki)), window['p$BCDE'](_[29278] + mhlki[_[4118]])) : sendApi(p$DE[_[29089]], _[29158], { 'platform': p$DE[_[29087]], 'partner_id': p$DE[_[23641]], 'token': p$DE[_[29156]], 'game_pkg': p$DE[_[25220]], 'deviceId': p$DE[_[25222]], 'scene': _[29159] + p$DE[_[29097]] }, function (ijlnkm) {
    if (!ijlnkm || ijlnkm[_[4118]] != _[9922]) {
      window['p$BCDE'](_[29171] + ijlnkm && ijlnkm[_[4118]]);return;
    }p$DE[_[29172]] = String(ijlnkm[_[11493]]), p$DE[_[29173]] = String(ijlnkm[_[849]]), setTimeout(function () {
      p$EBCD(p$DE[_[29264]][_[7118]] + 0x1, p$DE[_[29264]][_[11510]]);
    }, 0x5dc);
  }, p$CED, p$EB, function (iegfdh) {
    return iegfdh[_[4118]] == _[9922] || iegfdh[_[4118]] == _[25549];
  });
}, window['p$ECBD'] = function () {
  ServerLoading[_[148]][_[29184]](p$DE[_[628]]), window['p$CE'] = !![], window['p$EDBC']();
}, window['p$ECDB'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[29105]] && window[_[29106]] && window['p$DEC'] && window['p$DC']) {
    if (!window[_[28445]][_[148]]) {
      console[_[480]](_[29279] + window[_[28445]][_[148]]);var vrustq = wx[_[29280]](),
          $z_xwy = vrustq[_[774]] ? vrustq[_[774]] : 0x0,
          dgfi = { 'cdn': window['p$DE'][_[4524]], 'spareCdn': window['p$DE'][_[24905]], 'newRegister': window['p$DE'][_[628]], 'wxPC': window['p$DE'][_[24908]], 'wxIOS': window['p$DE'][_[1072]], 'wxAndroid': window['p$DE'][_[11332]], 'wxParam': { 'limitLoad': window['p$DE']['p$ABCED'], 'benchmarkLevel': window['p$DE']['p$ABDCE'], 'wxFrom': window[_[555]][_[28462]] == _[29281] ? 0x1 : 0x0, 'wxSDKVersion': window[_[28995]] }, 'configType': window['p$DE'][_[11854]], 'exposeType': window['p$DE'][_[712]], 'scene': $z_xwy };new window[_[28445]](dgfi, window['p$DE'][_[101]], window['p$ABCDE']);
    }
  }
}, window['p$EDBC'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[29105]] && window[_[29106]] && window['p$DEC'] && window['p$DC'] && window['p$CE'] && window['p$CD']) {
    p$BDEC();if (!p$ECD) {
      p$ECD = !![];if (!window[_[28445]][_[148]]) window['p$ECDB']();var onk = 0x0,
          ilghjk = wx[_[29282]]();ilghjk && (window['p$DE'][_[29051]] && (onk = ilghjk[_[320]]), console[_[78]](_[29283] + ilghjk[_[320]] + _[29284] + ilghjk[_[1213]] + _[29285] + ilghjk[_[1215]] + _[29286] + ilghjk[_[1214]] + _[29287] + ilghjk[_[176]] + _[29288] + ilghjk[_[177]]));var $12_0 = {};for (const pkn in p$DE[_[25214]]) {
        $12_0[pkn] = p$DE[_[25214]][pkn];
      }var ursqv = { 'channel': window['p$DE'][_[25218]], 'account': window['p$DE'][_[25219]], 'userId': window['p$DE'][_[23640]], 'cdn': window['p$DE'][_[4524]], 'data': window['p$DE'][_[11]], 'package': window['p$DE'][_[24906]], 'newRegister': window['p$DE'][_[628]], 'pkgName': window['p$DE'][_[25220]], 'partnerId': window['p$DE'][_[23641]], 'platform_uid': window['p$DE'][_[25221]], 'deviceId': window['p$DE'][_[25222]], 'selectedServer': $12_0, 'configType': window['p$DE'][_[11854]], 'exposeType': window['p$DE'][_[712]], 'debugUsers': window['p$DE'][_[12244]], 'wxMenuTop': onk, 'wxShield': window['p$DE'][_[736]] };if (window[_[29194]]) for (var jifgk in window[_[29194]]) {
        ursqv[jifgk] = window[_[29194]][jifgk];
      }window[_[28445]][_[148]]['p$EDA'](ursqv);
    }
  } else console[_[78]](_[29289] + window['p$EC'] + _[29290] + window['p$DCE'] + _[29291] + window[_[29105]] + _[29292] + window[_[29106]] + _[29293] + window['p$DEC'] + _[29294] + window['p$DC'] + _[29295] + window['p$CE'] + _[29296] + window['p$CD']);
};