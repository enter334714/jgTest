var _ = wx.y$;
require('bbbbBuff.js'), window[_[28569]][_[28559]][_[28449]] = null, window['client_pb'] = require('bbbcleintpb.js'), window[_[25360]] = window[_[28569]][_[25248]][_[25249]](client_pb);