var U = wx.$k;
console[U[140078]](U[169344]), window[U[169345]], wx[U[169346]](function (ob1wn) {
  if (ob1wn) {
    if (ob1wn[U[144525]]) {
      var onbwv1 = window[U[140555]][U[168920]][U[144703]](new RegExp(/\./, 'g'), '_'),
          r$ld_p = ob1wn[U[144525]],
          _5grp = r$ld_p[U[152052]](/(kkkkkkkkkk\/kkkkGAME.js:)[0-9]{1,60}(:)/g);if (_5grp) for (var gpr5_3 = 0x0; gpr5_3 < _5grp[U[140013]]; gpr5_3++) {
        if (_5grp[gpr5_3] && _5grp[gpr5_3][U[140013]] > 0x0) {
          var s2k89 = parseInt(_5grp[gpr5_3][U[144703]](U[169347], '')[U[144703]](':', ''));r$ld_p = r$ld_p[U[144703]](_5grp[gpr5_3], _5grp[gpr5_3][U[144703]](':' + s2k89 + ':', ':' + (s2k89 - 0x2) + ':'));
        }
      }r$ld_p = r$ld_p[U[144703]](new RegExp(U[169348], 'g'), U[169349] + onbwv1 + U[165319]), r$ld_p = r$ld_p[U[144703]](new RegExp(U[169350], 'g'), U[169349] + onbwv1 + U[165319]), ob1wn[U[144525]] = r$ld_p;
    }var nbv1o = { 'id': window['$KE2'][U[168966]], 'role': window['$KE2'][U[144645]], 'level': window['$KE2'][U[168967]], 'user': window['$KE2'][U[165219]], 'version': window['$KE2'][U[140101]], 'cdn': window['$KE2'][U[144524]], 'pkgName': window['$KE2'][U[165220]], 'gamever': window[U[140555]][U[168920]], 'serverid': window['$KE2'][U[165214]] ? window['$KE2'][U[165214]][U[151510]] : 0x0, 'systemInfo': window[U[168968]], 'error': U[169351], 'stack': ob1wn ? ob1wn[U[144525]] : '' },
        al$d_ = JSON[U[144510]](nbv1o);console[U[140125]](U[169352] + al$d_), (!window[U[169345]] || window[U[169345]] != nbv1o[U[140125]]) && (window[U[169345]] = nbv1o[U[140125]], window['$KPE'](nbv1o));
  }
});import 'kkkMDFIVEMIN.js';import 'kkkZLIBS.js';window[U[169353]] = require(U[169354]);import 'kkkINDEX.js';import 'KKKLIBSMIN.js';import 'kkkWXMINI.js';import 'kkkINITMIN.js';console[U[140078]](U[169355]), console[U[140078]](U[169356]), $KPE72({ 'title': U[169357] });var K1_r53_pg = { '$KTP2E7': !![] };new window[U[168956]](K1_r53_pg), window[U[168956]][U[140148]]['$KT7E2P']();if (window['$KTPE27']) clearInterval(window['$KTPE27']);window['$KTPE27'] = null, window['$KT72PE'] = function ($d_lp, i47jm) {
  if (!$d_lp || !i47jm) return 0x0;$d_lp = $d_lp[U[140015]]('.'), i47jm = i47jm[U[140015]]('.');const hit7je = Math[U[140851]]($d_lp[U[140013]], i47jm[U[140013]]);while ($d_lp[U[140013]] < hit7je) {
    $d_lp[U[140029]]('0');
  }while (i47jm[U[140013]] < hit7je) {
    i47jm[U[140029]]('0');
  }for (var $p5_d = 0x0; $p5_d < hit7je; $p5_d++) {
    const ldu$r_ = parseInt($d_lp[$p5_d]),
          eik6 = parseInt(i47jm[$p5_d]);if (ldu$r_ > eik6) return 0x1;else {
      if (ldu$r_ < eik6) return -0x1;
    }
  }return 0x0;
}, window[U[169064]] = wx[U[169358]]()[U[169064]], console[U[140480]](U[169359] + window[U[169064]]);var K1__luad = wx[U[169360]]();K1__luad[U[169361]](function (drp_3) {
  console[U[140480]](U[169362] + drp_3[U[169363]]);
}), K1__luad[U[169364]](function () {
  wx[U[168948]]({ 'title': U[169365], 'content': U[169366], 'showCancel': ![], 'success': function (x$aud) {
      K1__luad[U[169367]]();
    } });
}), K1__luad[U[169368]](function () {
  console[U[140480]](U[169369]);
}), window['$KT72EP'] = function () {
  console[U[140480]](U[169370]);var tiem = wx[U[169371]]({ 'name': U[169372], 'success': function (_$rld) {
      console[U[140480]](U[169373]), console[U[140480]](_$rld), _$rld && _$rld[U[165405]] == U[169374] ? (window['$K27'] = !![], window['$K27EP'](), window['$K2EP7']()) : setTimeout(function () {
        window['$KT72EP']();
      }, 0x1f4);
    }, 'fail': function (bwaoxz) {
      console[U[140480]](U[169375]), console[U[140480]](bwaoxz), setTimeout(function () {
        window['$KT72EP']();
      }, 0x1f4);
    } });tiem && tiem[U[169376]](gcy53 => {});
}, window['$KTEP27'] = function () {
  console[U[140480]](U[169377]);var ud$ax = wx[U[169371]]({ 'name': U[169378], 'success': function (w1vno) {
      console[U[140480]](U[169379]), console[U[140480]](w1vno), w1vno && w1vno[U[165405]] == U[169374] ? (window['$KE72'] = !![], window['$K27EP'](), window['$K2EP7']()) : setTimeout(function () {
        window['$KTEP27']();
      }, 0x1f4);
    }, 'fail': function (_$5p) {
      console[U[140480]](U[169380]), console[U[140480]](_$5p), setTimeout(function () {
        window['$KTEP27']();
      }, 0x1f4);
    } });ud$ax && ud$ax[U[169376]](ks920 => {});
}, window[U[169381]] = function () {
  window['$KT72PE'](window[U[169064]], U[169382]) >= 0x0 ? (console[U[140480]](U[169383] + window[U[169064]] + U[169384]), window['$KEP'](), window['$KT72EP'](), window['$KTEP27']()) : (window['$KE2P'](U[169385], window[U[169064]]), wx[U[168948]]({ 'title': U[146361], 'content': U[169386] }));
}, window[U[168968]] = '', wx[U[169387]]({ 'success'(esh9) {
    window[U[168968]] = U[169388] + esh9[U[169389]] + U[169390] + esh9[U[169391]] + U[169392] + esh9[U[144716]] + U[169393] + esh9[U[140473]] + U[169394] + esh9[U[165189]] + U[169395] + esh9[U[169064]] + U[169396] + esh9[U[149309]], console[U[140480]](window[U[168968]]), console[U[140480]](U[169397] + esh9[U[169398]] + U[169399] + esh9[U[169400]] + U[169401] + esh9[U[169402]] + U[169403] + esh9[U[169404]] + U[169405] + esh9[U[169406]] + U[169407] + esh9[U[169408]] + U[169409] + (esh9[U[169410]] ? esh9[U[169410]][U[140320]] + ',' + esh9[U[169410]][U[141213]] + ',' + esh9[U[169410]][U[141215]] + ',' + esh9[U[169410]][U[141214]] : ''));var e6sk = esh9[U[140473]] ? esh9[U[140473]][U[152339]]() : '',
        qv018n = esh9[U[169391]] ? esh9[U[169391]][U[152339]]()[U[144703]]('\x20', '') : '';window['$KE2'][U[141072]] = e6sk[U[140115]](U[169411]) != -0x1, window['$KE2'][U[151332]] = e6sk[U[140115]](U[168894]) != -0x1, window['$KE2'][U[169137]] = e6sk[U[140115]](U[169411]) != -0x1 || e6sk[U[140115]](U[168894]) != -0x1, window['$KE2'][U[164906]] = e6sk[U[140115]](U[168895]) != -0x1 || e6sk[U[140115]](U[168927]) != -0x1, window['$KE2'][U[168975]] = esh9[U[165189]] ? esh9[U[165189]][U[152339]]() : '', window['$KE2']['$KTP72E'] = ![], window['$KE2']['$KTPE72'] = 0x2;if (e6sk[U[140115]](U[168894]) != -0x1) {
      if (esh9[U[149309]] >= 0x18) window['$KE2']['$KTPE72'] = 0x3;else window['$KE2']['$KTPE72'] = 0x2;
    } else {
      if (e6sk[U[140115]](U[169411]) != -0x1) {
        if (esh9[U[149309]] && esh9[U[149309]] >= 0x14) window['$KE2']['$KTPE72'] = 0x3;else {
          if (qv018n[U[140115]](U[169412]) != -0x1 || qv018n[U[140115]](U[169413]) != -0x1 || qv018n[U[140115]](U[169414]) != -0x1 || qv018n[U[140115]](U[169415]) != -0x1 || qv018n[U[140115]](U[169416]) != -0x1) window['$KE2']['$KTPE72'] = 0x2;else window['$KE2']['$KTPE72'] = 0x3;
        }
      } else window['$KE2']['$KTPE72'] = 0x2;
    }console[U[140480]](U[169417] + window['$KE2']['$KTP72E'] + U[169418] + window['$KE2']['$KTPE72']);
  } }), wx[U[169083]]({ 'success': function (h6ktei) {
    console[U[140480]](U[169419] + h6ktei[U[144621]] + U[169420] + h6ktei[U[169085]]);
  } }), wx[U[169421]]({ 'success': function (k6eish) {
    console[U[140480]](U[169422] + k6eish[U[169423]]);
  } }), wx[U[169424]]({ 'keepScreenOn': !![] }), wx[U[169425]](function (v1nq0o) {
  console[U[140480]](U[169422] + v1nq0o[U[169423]] + U[169426] + v1nq0o[U[169427]]);
}), wx[U[150843]](function (ldua$x) {
  window['$K7P'] = ldua$x, window['$K2P7'] && window['$K7P'] && (console[U[140078]](U[169061] + window['$K7P'][U[140774]]), window['$K2P7'](window['$K7P']), window['$K7P'] = null);
}), window[U[169428]] = 0x0, window['$KTE72P'] = 0x0, window[U[169429]] = null, wx[U[169430]](function () {
  window['$KTE72P']++;var r5dp_ = Date[U[140083]]();(window[U[169428]] == 0x0 || r5dp_ - window[U[169428]] > 0x1d4c0) && (console[U[140096]](U[169431]), wx[U[151905]]());if (window['$KTE72P'] >= 0x2) {
    window['$KTE72P'] = 0x0, console[U[140125]](U[169432]), wx[U[169433]]('0', 0x1);if (window['$KE2'] && window['$KE2'][U[141072]]) window['$KE2P'](U[169434], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});