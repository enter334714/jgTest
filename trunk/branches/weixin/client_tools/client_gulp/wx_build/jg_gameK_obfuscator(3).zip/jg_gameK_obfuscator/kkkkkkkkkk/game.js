var U = wx.$k;
import 'KKKMAIN.js';