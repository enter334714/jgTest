var U = wx.$k;
import K1_e6s9 from '../kkkkSDK/kkkSDDK.js';window[U[168919]] = { 'wxVersion': window[U[140555]][U[168920]] }, window[U[168921]] = ![], window['$K2E'] = 0x1, window[U[168922]] = 0x1, window['$K7E2'] = !![], window[U[168923]] = !![], window['$KTP7E2'] = '', window['$KE2'] = { 'base_cdn': U[168924], 'cdn': U[168924] }, $KE2[U[168925]] = {}, $KE2[U[164904]] = '0', $KE2[U[144716]] = window[U[168919]][U[168926]], $KE2[U[168927]] = '', $KE2['os'] = '1', $KE2[U[168928]] = U[168929], $KE2[U[168930]] = U[168931], $KE2[U[168932]] = U[168933], $KE2[U[168934]] = U[168935], $KE2[U[168936]] = U[168937], $KE2[U[163641]] = '1', $KE2[U[165220]] = '', $KE2[U[165222]] = '', $KE2[U[168938]] = 0x0, $KE2[U[168939]] = {}, $KE2[U[168940]] = parseInt($KE2[U[163641]]), $KE2[U[165218]] = $KE2[U[163641]], $KE2[U[165214]] = {}, $KE2['$KPE'] = U[168941], $KE2[U[168942]] = ![], $KE2[U[152244]] = U[168943], $KE2[U[165191]] = Date[U[140083]](), $KE2[U[151851]] = U[168944], $KE2[U[140712]] = '_a', $KE2[U[168945]] = 0x2, $KE2[U[140101]] = 0x7c1, $KE2[U[168926]] = window[U[168919]][U[168926]], $KE2[U[140736]] = ![], $KE2[U[141072]] = ![], $KE2[U[151332]] = ![], $KE2[U[164906]] = ![], window['$K72E'] = 0x5, window['$K72'] = ![], window['$K27'] = ![], window['$KE72'] = ![], window[U[168946]] = ![], window[U[168947]] = ![], window['$KE27'] = ![], window['$K7E'] = ![], window['$KE7'] = ![], window['$K27E'] = ![], window[U[144185]] = function (q0v18) {
  console[U[140480]](U[144185], q0v18), wx[U[144995]]({}), wx[U[168948]]({ 'title': U[146361], 'content': q0v18, 'success'(dp$5r_) {
      if (dp$5r_[U[168949]]) console[U[140480]](U[168950]);else dp$5r_[U[140551]] && console[U[140480]](U[168951]);
    } });
}, window['$KP7E2'] = function (ua$_) {
  console[U[140480]](U[168952], ua$_), $KPE27(), wx[U[168948]]({ 'title': U[146361], 'content': ua$_, 'confirmText': U[168953], 'cancelText': U[158499], 'success'(g3cp5f) {
      if (g3cp5f[U[168949]]) window['$KEP']();else g3cp5f[U[140551]] && (console[U[140480]](U[168954]), wx[U[165378]]({}));
    } });
}, window[U[168955]] = function (ethi) {
  console[U[140480]](U[168955], ethi), wx[U[168948]]({ 'title': U[146361], 'content': ethi, 'confirmText': U[165350], 'showCancel': ![], 'complete'(cg3fy5) {
      console[U[140480]](U[168954]), wx[U[165378]]({});
    } });
}, window['$KP72E'] = ![], window['$KPE72'] = function (r3pf5) {
  window['$KP72E'] = !![], wx[U[144994]](r3pf5);
}, window['$KPE27'] = function () {
  window['$KP72E'] && (window['$KP72E'] = ![], wx[U[144995]]({}));
}, window['$KP27E'] = function (sk9he) {
  window[U[168956]][U[140148]]['$KP27E'](sk9he);
}, window[U[152125]] = function (he69sk, q80n21) {
  K1_e6s9[U[168913]](he69sk, function (n10oq) {
    n10oq && n10oq[U[140011]] ? n10oq[U[140011]][U[168957]] == 0x0 ? q80n21(!![]) : (q80n21(![]), console[U[140078]](U[168958] + n10oq[U[140011]][U[168959]])) : console[U[140480]](U[152125], n10oq);
  });
}, window['$KP2E7'] = function (wn1voq) {
  console[U[140480]](U[168960], wn1voq);
}, window['$KPE2'] = function (k68s9) {}, window['$KP2E'] = function (sq902, c3fgy5, rdl$_p) {}, window['$KP2'] = function (qs09) {
  console[U[140480]](U[168961], qs09), window[U[168956]][U[140148]][U[168962]](), window[U[168956]][U[140148]][U[168963]](), window[U[168956]][U[140148]][U[168964]]();
}, window['$K2P'] = function (woq1n) {
  window['$KP7E2'](U[168965]);var axu$d = { 'id': window['$KE2'][U[168966]], 'role': window['$KE2'][U[144645]], 'level': window['$KE2'][U[168967]], 'account': window['$KE2'][U[165219]], 'version': window['$KE2'][U[140101]], 'cdn': window['$KE2'][U[144524]], 'pkgName': window['$KE2'][U[165220]], 'gamever': window[U[140555]][U[168920]], 'serverid': window['$KE2'][U[165214]] ? window['$KE2'][U[165214]][U[151510]] : 0x0, 'systemInfo': window[U[168968]], 'error': U[168969], 'stack': woq1n ? woq1n : U[168965] },
      etk = JSON[U[144510]](axu$d);console[U[140125]](U[168970] + etk), window['$KPE'](etk);
}, window['$KEP2'] = function (dlua$x) {
  var owvbz1 = JSON[U[140525]](dlua$x);owvbz1[U[168971]] = window[U[140555]][U[168920]], owvbz1[U[168972]] = window['$KE2'][U[165214]] ? window['$KE2'][U[165214]][U[151510]] : 0x0, owvbz1[U[168968]] = window[U[168968]];var r_g35p = JSON[U[144510]](owvbz1);console[U[140125]](U[168973] + r_g35p), window['$KPE'](r_g35p);
}, window['$KE2P'] = function (q18v, h6sk92) {
  var aux$ = { 'id': window['$KE2'][U[168966]], 'role': window['$KE2'][U[144645]], 'level': window['$KE2'][U[168967]], 'account': window['$KE2'][U[165219]], 'version': window['$KE2'][U[140101]], 'cdn': window['$KE2'][U[144524]], 'pkgName': window['$KE2'][U[165220]], 'gamever': window[U[140555]][U[168920]], 'serverid': window['$KE2'][U[165214]] ? window['$KE2'][U[165214]][U[151510]] : 0x0, 'systemInfo': window[U[168968]], 'error': q18v, 'stack': h6sk92 },
      t6hike = JSON[U[144510]](aux$);console[U[140096]](U[168974] + t6hike), window['$KPE'](t6hike);
}, window['$KPE'] = function (f3gcp) {
  if (window['$KE2'][U[168975]] == U[168976]) return;var vn1wq = $KE2['$KPE'] + U[168977] + $KE2[U[165219]];wx[U[140475]]({ 'url': vn1wq, 'method': U[168853], 'data': f3gcp, 'header': { 'content-type': U[168978], 'cache-control': U[168979] }, 'success': function (bzwovx) {
      DEBUG && console[U[140480]](U[168980], vn1wq, f3gcp, bzwovx);
    }, 'fail': function (r$d5) {
      DEBUG && console[U[140480]](U[168980], vn1wq, f3gcp, r$d5);
    }, 'complete': function () {} });
}, window[U[168981]] = function () {
  function _pg53r() {
    return ((0x1 + Math[U[140119]]()) * 0x10000 | 0x0)[U[140272]](0x10)[U[140498]](0x1);
  }return _pg53r() + _pg53r() + '-' + _pg53r() + '-' + _pg53r() + '-' + _pg53r() + '+' + _pg53r() + _pg53r() + _pg53r();
}, window['$KEP'] = function () {
  console[U[140480]](U[168982]);var dl$xua = K1_e6s9[U[168983]]();$KE2[U[165218]] = dl$xua[U[168984]], $KE2[U[168940]] = dl$xua[U[168984]], $KE2[U[163641]] = dl$xua[U[168984]], $KE2[U[165220]] = dl$xua[U[168985]];var d$r_ = { 'game_ver': $KE2[U[144716]] };$KE2[U[165222]] = this[U[168981]](), $KPE72({ 'title': U[168986] }), K1_e6s9[U[140366]](d$r_, this['$K2PE'][U[140074]](this));
}, window['$K2PE'] = function (t7eh) {
  var $pr_ld = t7eh[U[168987]];console[U[140480]](U[168988] + $pr_ld + U[168989] + ($pr_ld == 0x1) + U[168990] + t7eh[U[168920]] + U[168991] + window[U[168919]][U[168926]]);if (!t7eh[U[168920]] || window['$KT72PE'](window[U[168919]][U[168926]], t7eh[U[168920]]) < 0x0) console[U[140480]](U[168992]), $KE2[U[168930]] = U[168993], $KE2[U[168932]] = U[168994], $KE2[U[168934]] = U[168995], $KE2[U[144524]] = U[168996], $KE2[U[164903]] = U[168997], $KE2[U[168998]] = 'hy', $KE2[U[140736]] = ![];else window['$KT72PE'](window[U[168919]][U[168926]], t7eh[U[168920]]) == 0x0 ? (console[U[140480]](U[168999]), $KE2[U[168930]] = U[168931], $KE2[U[168932]] = U[168933], $KE2[U[168934]] = U[168935], $KE2[U[144524]] = U[169000], $KE2[U[164903]] = U[168997], $KE2[U[168998]] = U[169001], $KE2[U[140736]] = !![]) : (console[U[140480]](U[169002]), $KE2[U[168930]] = U[168931], $KE2[U[168932]] = U[168933], $KE2[U[168934]] = U[168935], $KE2[U[144524]] = U[169000], $KE2[U[164903]] = U[168997], $KE2[U[168998]] = U[169001], $KE2[U[140736]] = ![]);$KE2[U[168938]] = config[U[168464]] ? config[U[168464]] : 0x0, this['$K7EP2'](), this['$K7E2P'](), window[U[169003]] = 0x5, $KPE72({ 'title': U[169004] }), K1_e6s9[U[168850]](this['$K2EP'][U[140074]](this));
}, window[U[169003]] = 0x5, window['$K2EP'] = function (zxlb, rp53d_) {
  if (zxlb == 0x0 && rp53d_ && rp53d_[U[168555]]) {
    $KE2[U[169005]] = rp53d_[U[168555]];var mei7jt = this;$KPE72({ 'title': U[169006] }), sendApi($KE2[U[168930]], U[169007], { 'platform': $KE2[U[168928]], 'partner_id': $KE2[U[163641]], 'token': rp53d_[U[168555]], 'game_pkg': $KE2[U[165220]], 'deviceId': $KE2[U[165222]], 'scene': U[169008] + $KE2[U[168938]] }, this['$K7PE2'][U[140074]](this), $K72E, $K2P);
  } else rp53d_ && rp53d_[U[165405]] && window[U[169003]] > 0x0 && (rp53d_[U[165405]][U[140115]](U[169009]) != -0x1 || rp53d_[U[165405]][U[140115]](U[169010]) != -0x1 || rp53d_[U[165405]][U[140115]](U[169011]) != -0x1 || rp53d_[U[165405]][U[140115]](U[169012]) != -0x1 || rp53d_[U[165405]][U[140115]](U[169013]) != -0x1 || rp53d_[U[165405]][U[140115]](U[169014]) != -0x1) ? (window[U[169003]]--, K1_e6s9[U[168850]](this['$K2EP'][U[140074]](this))) : (window['$KE2P'](U[169015], JSON[U[144510]]({ 'status': zxlb, 'data': rp53d_ })), window['$KP7E2'](U[169016] + (rp53d_ && rp53d_[U[165405]] ? '，' + rp53d_[U[165405]] : '')));
}, window['$K7PE2'] = function (ldu$_a) {
  if (!ldu$_a) {
    window['$KE2P'](U[169017], U[169018]), window['$KP7E2'](U[169019]);return;
  }if (ldu$_a[U[144118]] != U[149922]) {
    window['$KE2P'](U[169017], JSON[U[144510]](ldu$_a)), window['$KP7E2'](U[169020] + ldu$_a[U[144118]]);return;
  }$KE2[U[163640]] = String(ldu$_a[U[165219]]), $KE2[U[165219]] = String(ldu$_a[U[165219]]), $KE2[U[165189]] = String(ldu$_a[U[165189]]), $KE2[U[165218]] = String(ldu$_a[U[165189]]), $KE2[U[165221]] = String(ldu$_a[U[165221]]), $KE2[U[169021]] = String(ldu$_a[U[151493]]), $KE2[U[169022]] = String(ldu$_a[U[140849]]), $KE2[U[151493]] = '';var p3d5_r = this;$KPE72({ 'title': U[169023] }), sendApi($KE2[U[168930]], U[169024], { 'partner_id': $KE2[U[163641]], 'uid': $KE2[U[165219]], 'version': $KE2[U[144716]], 'game_pkg': $KE2[U[165220]], 'device': $KE2[U[165222]] }, p3d5_r['$K7P2E'][U[140074]](p3d5_r), $K72E, $K2P);
}, window['$K7P2E'] = function (v1zwo) {
  if (!v1zwo) {
    window['$KP7E2'](U[169025]);return;
  }if (v1zwo[U[144118]] != U[149922]) {
    window['$KP7E2'](U[169026] + v1zwo[U[144118]]);return;
  }if (!v1zwo[U[140011]] || v1zwo[U[140011]][U[140013]] == 0x0) {
    window['$KP7E2'](U[169027]);return;
  }$KE2[U[140628]] = v1zwo[U[169028]], $KE2[U[165214]] = { 'server_id': String(v1zwo[U[140011]][0x0][U[151510]]), 'server_name': String(v1zwo[U[140011]][0x0][U[169029]]), 'entry_ip': v1zwo[U[140011]][0x0][U[165242]], 'entry_port': parseInt(v1zwo[U[140011]][0x0][U[165243]]), 'status': $KE7P(v1zwo[U[140011]][0x0]), 'start_time': v1zwo[U[140011]][0x0][U[169030]], 'cdn': $KE2[U[144524]] }, this['$K2E7P']();
}, window['$K2E7P'] = function () {
  if ($KE2[U[140628]] == 0x1) {
    var obxvw = $KE2[U[165214]][U[140106]];if (obxvw === -0x1 || obxvw === 0x0) {
      window['$KP7E2'](obxvw === -0x1 ? U[169031] : U[169032]);return;
    }$K2P7E(0x0, $KE2[U[165214]][U[151510]]), window[U[168956]][U[140148]][U[169033]]($KE2[U[140628]]);
  } else window[U[168956]][U[140148]][U[169034]](), $KPE27();window['$KE7'] = !![], window['$K27EP'](), window['$K2EP7']();
}, window['$K7EP2'] = function () {
  sendApi($KE2[U[168930]], U[169035], { 'game_pkg': $KE2[U[165220]], 'version_name': $KE2[U[168998]] }, this[U[169036]][U[140074]](this), $K72E, $K2P);
}, window[U[169036]] = function (k9es) {
  if (!k9es) {
    window['$KP7E2'](U[169037]);return;
  }if (k9es[U[144118]] != U[149922]) {
    window['$KP7E2'](U[169038] + k9es[U[144118]]);return;
  }if (!k9es[U[140011]] || !k9es[U[140011]][U[144716]]) {
    window['$KP7E2'](U[169039] + (k9es[U[140011]] && k9es[U[140011]][U[144716]]));return;
  }k9es[U[140011]][U[169040]] && k9es[U[140011]][U[169040]][U[140013]] > 0xa && ($KE2[U[169041]] = k9es[U[140011]][U[169040]], $KE2[U[144524]] = k9es[U[140011]][U[169040]]), k9es[U[140011]][U[144716]] && ($KE2[U[140101]] = k9es[U[140011]][U[144716]]), console[U[140078]](U[165356] + $KE2[U[140101]] + U[169042] + $KE2[U[168998]]), window['$KE27'] = !![], window['$K27EP'](), window['$K2EP7']();
}, window[U[169043]], window['$K7E2P'] = function () {
  sendApi($KE2[U[168930]], U[169044], { 'game_pkg': $KE2[U[165220]] }, this['$K72PE'][U[140074]](this), $K72E, $K2P);
}, window['$K72PE'] = function (w1bvzo) {
  if (w1bvzo[U[144118]] === U[149922] && w1bvzo[U[140011]]) {
    window[U[169043]] = w1bvzo[U[140011]];for (var xal$zu in w1bvzo[U[140011]]) {
      $KE2[xal$zu] = w1bvzo[U[140011]][xal$zu];
    }
  } else console[U[140078]](U[169045] + w1bvzo[U[144118]]);window['$K7E'] = !![], window['$K2EP7']();
}, window[U[169046]] = function (ruld_, ke96hs, q289, jm7, _35rgp, s82k90, pr5_$d, _prd$5, v0n1o) {
  _35rgp = String(_35rgp);var r5dp$ = pr5_$d,
      hek6 = _prd$5;$KE2[U[168925]][_35rgp] = { 'productid': _35rgp, 'productname': r5dp$, 'productdesc': hek6, 'roleid': ruld_, 'rolename': ke96hs, 'rolelevel': q289, 'price': s82k90, 'callback': v0n1o }, sendApi($KE2[U[168934]], U[169047], { 'game_pkg': $KE2[U[165220]], 'server_id': $KE2[U[165214]][U[151510]], 'server_name': $KE2[U[165214]][U[169029]], 'level': q289, 'uid': $KE2[U[165219]], 'role_id': ruld_, 'role_name': ke96hs, 'product_id': _35rgp, 'product_name': r5dp$, 'product_desc': hek6, 'money': s82k90, 'partner_id': $KE2[U[163641]] }, toPayCallBack, $K72E, $K2P);
}, window[U[169048]] = function (n982) {
  if (n982) {
    if (n982[U[169049]] === 0xc8 || n982[U[144118]] == U[149922]) {
      var m7i4tj = $KE2[U[168925]][String(n982[U[169050]])];if (m7i4tj[U[140332]]) m7i4tj[U[140332]](n982[U[169050]], n982[U[169051]], -0x1);K1_e6s9[U[168888]]({ 'cpbill': n982[U[169051]], 'productid': n982[U[169050]], 'productname': m7i4tj[U[169052]], 'productdesc': m7i4tj[U[169053]], 'serverid': $KE2[U[165214]][U[151510]], 'servername': $KE2[U[165214]][U[169029]], 'roleid': m7i4tj[U[169054]], 'rolename': m7i4tj[U[169055]], 'rolelevel': m7i4tj[U[169056]], 'price': m7i4tj[U[166913]], 'extension': JSON[U[144510]]({ 'cp_order_id': n982[U[169051]] }) }, function (uwzbxa, f3cpg5) {
        m7i4tj[U[140332]] && uwzbxa == 0x0 && m7i4tj[U[140332]](n982[U[169050]], n982[U[169051]], uwzbxa);console[U[140078]](JSON[U[144510]]({ 'type': U[169057], 'status': uwzbxa, 'data': n982, 'role_name': m7i4tj[U[169055]] }));if (uwzbxa === 0x0) {} else {
          if (uwzbxa === 0x1) {} else {
            if (uwzbxa === 0x2) {}
          }
        }
      });
    } else alert(n982[U[140078]]);
  }
}, window['$K72EP'] = function () {}, window['$KP72'] = function (lu$_, tj7m4i, zxwoba, w1nbo, cg53fy) {
  K1_e6s9[U[168907]]($KE2[U[165214]][U[151510]], $KE2[U[165214]][U[169029]] || $KE2[U[165214]][U[151510]], lu$_, tj7m4i, zxwoba), sendApi($KE2[U[168930]], U[169058], { 'game_pkg': $KE2[U[165220]], 'server_id': $KE2[U[165214]][U[151510]], 'role_id': lu$_, 'uid': $KE2[U[165219]], 'role_name': tj7m4i, 'role_type': w1nbo, 'level': zxwoba });
}, window['$KP27'] = function (xzvobw, n1wob, $_rpd, n182, hseki, wovxbz, bazo, rpd_3, l$_dp, _35pd) {
  $KE2[U[168966]] = xzvobw, $KE2[U[144645]] = n1wob, $KE2[U[168967]] = $_rpd, K1_e6s9[U[168908]]($KE2[U[165214]][U[151510]], $KE2[U[165214]][U[169029]] || $KE2[U[165214]][U[151510]], xzvobw, n1wob, $_rpd), sendApi($KE2[U[168930]], U[169059], { 'game_pkg': $KE2[U[165220]], 'server_id': $KE2[U[165214]][U[151510]], 'role_id': xzvobw, 'uid': $KE2[U[165219]], 'role_name': n1wob, 'role_type': n182, 'level': $_rpd, 'evolution': hseki });
}, window['$K7P2'] = function (f5cgy, _ldrp$, htie6, lr$pd, qvw1on, sk9826, ejm7, i4t7jm, n1owb, p3g5_) {
  $KE2[U[168966]] = f5cgy, $KE2[U[144645]] = _ldrp$, $KE2[U[168967]] = htie6, K1_e6s9[U[168909]]($KE2[U[165214]][U[151510]], $KE2[U[165214]][U[169029]] || $KE2[U[165214]][U[151510]], f5cgy, _ldrp$, htie6), sendApi($KE2[U[168930]], U[169059], { 'game_pkg': $KE2[U[165220]], 'server_id': $KE2[U[165214]][U[151510]], 'role_id': f5cgy, 'uid': $KE2[U[165219]], 'role_name': _ldrp$, 'role_type': lr$pd, 'level': htie6, 'evolution': qvw1on });
}, window['$K72P'] = function (kh6ie) {}, window['$KP7'] = function (r$d_lu) {
  K1_e6s9[U[168869]](U[168869], function (yg5c3f) {
    r$d_lu && r$d_lu(yg5c3f);
  });
}, window[U[164889]] = function () {
  K1_e6s9[U[164889]]();
}, window[U[169060]] = function () {
  K1_e6s9[U[163534]]();
}, window[U[150843]] = function (r$p_dl) {
  window['$K2P7'] = r$p_dl, window['$K2P7'] && window['$K7P'] && (console[U[140078]](U[169061] + window['$K7P'][U[140774]]), window['$K2P7'](window['$K7P']), window['$K7P'] = null);
}, window['$K27P'] = function ($udrl_, vbzo1, m7i4t, vwbzx) {
  window[U[140022]](U[169062], { 'game_pkg': window['$KE2'][U[165220]], 'role_id': vbzo1, 'server_id': m7i4t }, vwbzx);
}, window['$KEP72'] = function (d$_aul, jem7i) {
  function fr5g3(k6thie) {
    var vq0 = [],
        hk2s = [],
        ul$xd = window[U[140555]][U[169063]];for (var ti7mje in ul$xd) {
      var ozxbvw = Number(ti7mje);(!d$_aul || !d$_aul[U[140013]] || d$_aul[U[140115]](ozxbvw) != -0x1) && (hk2s[U[140029]](ul$xd[ti7mje]), vq0[U[140029]]([ozxbvw, 0x3]));
    }window['$KT72PE'](window[U[169064]], U[169065]) >= 0x0 ? (console[U[140480]](U[169066]), K1_e6s9[U[169067]] && K1_e6s9[U[169067]](hk2s, function (_d35pr) {
      console[U[140480]](U[169068]), console[U[140480]](_d35pr);if (_d35pr && _d35pr[U[165405]] == U[169069]) for (var bxulaz in ul$xd) {
        if (_d35pr[ul$xd[bxulaz]] == U[169070]) {
          var $l_pd = Number(bxulaz);for (var t6ekh = 0x0; t6ekh < vq0[U[140013]]; t6ekh++) {
            if (vq0[t6ekh][0x0] == $l_pd) {
              vq0[t6ekh][0x1] = 0x1;break;
            }
          }
        }
      }window['$KT72PE'](window[U[169064]], U[169071]) >= 0x0 ? wx[U[169072]]({ 'withSubscriptions': !![], 'success': function (_dp$r) {
          var me7itj = _dp$r[U[169073]][U[169074]];if (me7itj) {
            console[U[140480]](U[169075]), console[U[140480]](me7itj);for (var aow in ul$xd) {
              if (me7itj[ul$xd[aow]] == U[169070]) {
                var ul$az = Number(aow);for (var e67ith = 0x0; e67ith < vq0[U[140013]]; e67ith++) {
                  if (vq0[e67ith][0x0] == ul$az) {
                    vq0[e67ith][0x1] = 0x2;break;
                  }
                }
              }
            }console[U[140480]](vq0), jem7i && jem7i(vq0);
          } else console[U[140480]](U[169076]), console[U[140480]](_dp$r), console[U[140480]](vq0), jem7i && jem7i(vq0);
        }, 'fail': function () {
          console[U[140480]](U[169077]), console[U[140480]](vq0), jem7i && jem7i(vq0);
        } }) : (console[U[140480]](U[169078] + window[U[169064]]), console[U[140480]](vq0), jem7i && jem7i(vq0));
    })) : (console[U[140480]](U[169079] + window[U[169064]]), console[U[140480]](vq0), jem7i && jem7i(vq0)), wx[U[169080]](fr5g3);
  }wx[U[169081]](fr5g3);
}, window['$KEP27'] = { 'isSuccess': ![], 'level': U[169082], 'isCharging': ![] }, window['$KE7P2'] = function (_dplr$) {
  wx[U[169083]]({ 'success': function (k6s9h2) {
      var lu$dax = window['$KEP27'];lu$dax[U[169084]] = !![], lu$dax[U[144621]] = Number(k6s9h2[U[144621]])[U[144233]](0x0), lu$dax[U[169085]] = k6s9h2[U[169085]], _dplr$ && _dplr$(lu$dax[U[169084]], lu$dax[U[144621]], lu$dax[U[169085]]);
    }, 'fail': function (bozxa) {
      console[U[140480]](U[169086], bozxa[U[165405]]);var jtim7e = window['$KEP27'];_dplr$ && _dplr$(jtim7e[U[169084]], jtim7e[U[144621]], jtim7e[U[169085]]);
    } });
}, window[U[140022]] = function (yg35cf, mij7te, q08n29, $d_alu, p5dr3_, eijt, zbuxwa, ihks6) {
  if ($d_alu == undefined) $d_alu = 0x1;wx[U[140475]]({ 'url': yg35cf, 'method': zbuxwa || U[165107], 'responseType': U[144430], 'data': mij7te, 'header': { 'content-type': ihks6 || U[168978] }, 'success': function ($5rpd_) {
      DEBUG && console[U[140480]](U[169087], yg35cf, info, $5rpd_);if ($5rpd_ && $5rpd_[U[165471]] == 0xc8) {
        var prd_53 = $5rpd_[U[140011]];!eijt || eijt(prd_53) ? q08n29 && q08n29(prd_53) : window[U[169088]](yg35cf, mij7te, q08n29, $d_alu, p5dr3_, eijt, $5rpd_);
      } else window[U[169088]](yg35cf, mij7te, q08n29, $d_alu, p5dr3_, eijt, $5rpd_);
    }, 'fail': function (zobaw) {
      DEBUG && console[U[140480]](U[169089], yg35cf, info, zobaw), window[U[169088]](yg35cf, mij7te, q08n29, $d_alu, p5dr3_, eijt, zobaw);
    }, 'complete': function () {} });
}, window[U[169088]] = function (jie7mt, ikhe6t, eti6, bzwo1, ozxabw, $dlaxu, n1vwqo) {
  bzwo1 - 0x1 > 0x0 ? setTimeout(function () {
    window[U[140022]](jie7mt, ikhe6t, eti6, bzwo1 - 0x1, ozxabw, $dlaxu);
  }, 0x3e8) : ozxabw && ozxabw(JSON[U[144510]]({ 'url': jie7mt, 'response': n1vwqo }));
}, window[U[169090]] = function (u_rd, s82k6, k9028s, qs028, tih6, ux$ald, ldau_$) {
  !k9028s && (k9028s = {});var ji4m7t = Math[U[140118]](Date[U[140083]]() / 0x3e8);k9028s[U[140849]] = ji4m7t, k9028s[U[165028]] = s82k6;var bzoxw = Object[U[140264]](k9028s)[U[141076]](),
      h76i = '',
      la$zux = '';for (var zoawb = 0x0; zoawb < bzoxw[U[140013]]; zoawb++) {
    h76i = h76i + (zoawb == 0x0 ? '' : '&') + bzoxw[zoawb] + k9028s[bzoxw[zoawb]], la$zux = la$zux + (zoawb == 0x0 ? '' : '&') + bzoxw[zoawb] + '=' + encodeURIComponent(k9028s[bzoxw[zoawb]]);
  }h76i = h76i + $KE2[U[168936]];var i47jmt = U[169091] + md5(h76i);send(u_rd + '?' + la$zux + (la$zux == '' ? '' : '&') + i47jmt, null, qs028, tih6, ux$ald, ldau_$ || function (dl_a$) {
    return dl_a$[U[144118]] == U[149922];
  }, null, U[168854]);
}, window['$KE72P'] = function (cf35p, k6h9s) {
  var h6e7ti = 0x0;$KE2[U[165214]] && (h6e7ti = $KE2[U[165214]][U[151510]]), sendApi($KE2[U[168932]], U[169092], { 'partnerId': $KE2[U[163641]], 'gamePkg': $KE2[U[165220]], 'logTime': Math[U[140118]](Date[U[140083]]() / 0x3e8), 'platformUid': $KE2[U[165221]], 'type': cf35p, 'serverId': h6e7ti }, null, 0x2, null, function () {
    return !![];
  });
}, window['$KE2P7'] = function (ad$u) {
  sendApi($KE2[U[168930]], U[169093], { 'partner_id': $KE2[U[163641]], 'uid': $KE2[U[165219]], 'version': $KE2[U[144716]], 'game_pkg': $KE2[U[165220]], 'device': $KE2[U[165222]] }, $KE27P, $K72E, $K2P);
}, window['$KE27P'] = function (_pl$rd) {
  if (_pl$rd[U[144118]] === U[149922] && _pl$rd[U[140011]]) {
    _pl$rd[U[140011]][U[145598]]({ 'id': -0x2, 'name': U[169094] }), _pl$rd[U[140011]][U[145598]]({ 'id': -0x1, 'name': U[169095] }), $KE2[U[169096]] = _pl$rd[U[140011]];if (window[U[152290]]) window[U[152290]][U[169097]]();
  } else $KE2[U[169098]] = ![], window['$KP7E2'](U[169099] + _pl$rd[U[144118]]);
}, window['$KP7E'] = function ($ldau) {
  sendApi($KE2[U[168930]], U[169100], { 'partner_id': $KE2[U[163641]], 'uid': $KE2[U[165219]], 'version': $KE2[U[144716]], 'game_pkg': $KE2[U[165220]], 'device': $KE2[U[165222]] }, $KPE7, $K72E, $K2P);
}, window['$KPE7'] = function (f5c3pg) {
  $KE2[U[169101]] = ![];if (f5c3pg[U[144118]] === U[149922] && f5c3pg[U[140011]]) {
    for (var e96h = 0x0; e96h < f5c3pg[U[140011]][U[140013]]; e96h++) {
      f5c3pg[U[140011]][e96h][U[140106]] = $KE7P(f5c3pg[U[140011]][e96h]);
    }$KE2[U[168939]][-0x1] = window[U[169102]](f5c3pg[U[140011]]), window[U[152290]][U[169103]](-0x1);
  } else window['$KP7E2'](U[169104] + f5c3pg[U[144118]]);
}, window[U[169105]] = function (bxzau) {
  sendApi($KE2[U[168930]], U[169100], { 'partner_id': $KE2[U[163641]], 'uid': $KE2[U[165219]], 'version': $KE2[U[144716]], 'game_pkg': $KE2[U[165220]], 'device': $KE2[U[165222]] }, bxzau, $K72E, $K2P);
}, window['$K7PE'] = function (ldpr_, alxuz$) {
  sendApi($KE2[U[168930]], U[169106], { 'partner_id': $KE2[U[163641]], 'uid': $KE2[U[165219]], 'version': $KE2[U[144716]], 'game_pkg': $KE2[U[165220]], 'device': $KE2[U[165222]], 'server_group_id': alxuz$ }, $K7EP, $K72E, $K2P);
}, window['$K7EP'] = function (vwqn) {
  $KE2[U[169101]] = ![];if (vwqn[U[144118]] === U[149922] && vwqn[U[140011]] && vwqn[U[140011]][U[140011]]) {
    var $r_dlp = vwqn[U[140011]][U[169107]],
        zlxabu = [];for (var $udl_a = 0x0; $udl_a < vwqn[U[140011]][U[140011]][U[140013]]; $udl_a++) {
      vwqn[U[140011]][U[140011]][$udl_a][U[140106]] = $KE7P(vwqn[U[140011]][U[140011]][$udl_a]), (zlxabu[U[140013]] == 0x0 || vwqn[U[140011]][U[140011]][$udl_a][U[140106]] != 0x0) && (zlxabu[zlxabu[U[140013]]] = vwqn[U[140011]][U[140011]][$udl_a]);
    }$KE2[U[168939]][$r_dlp] = window[U[169102]](zlxabu), window[U[152290]][U[169103]]($r_dlp);
  } else window['$KP7E2'](U[169108] + vwqn[U[144118]]);
}, window['$KT72E'] = function (eiks6h) {
  sendApi($KE2[U[168930]], U[169109], { 'partner_id': $KE2[U[163641]], 'uid': $KE2[U[165219]], 'version': $KE2[U[144716]], 'game_pkg': $KE2[U[165220]], 'device': $KE2[U[165222]] }, reqServerRecommendCallBack, $K72E, $K2P);
}, window[U[169110]] = function (_r53pg) {
  $KE2[U[169101]] = ![];if (_r53pg[U[144118]] === U[149922] && _r53pg[U[140011]]) {
    for (var o1zvw = 0x0; o1zvw < _r53pg[U[140011]][U[140013]]; o1zvw++) {
      _r53pg[U[140011]][o1zvw][U[140106]] = $KE7P(_r53pg[U[140011]][o1zvw]);
    }$KE2[U[168939]][-0x2] = window[U[169102]](_r53pg[U[140011]]), window[U[152290]][U[169103]](-0x2);
  } else alert(U[169111] + _r53pg[U[144118]]);
}, window[U[169102]] = function (f5ygc3) {
  if (!f5ygc3 && f5ygc3[U[140013]] <= 0x0) return f5ygc3;for (let hs6ike = 0x0; hs6ike < f5ygc3[U[140013]]; hs6ike++) {
    f5ygc3[hs6ike][U[169112]] && f5ygc3[hs6ike][U[169112]] == 0x1 && (f5ygc3[hs6ike][U[169029]] += U[169113]);
  }return f5ygc3;
}, window['$KEP7'] = function ($ualdx, xul) {
  $ualdx = $ualdx || $KE2[U[165214]][U[151510]], sendApi($KE2[U[168930]], U[169114], { 'type': '4', 'game_pkg': $KE2[U[165220]], 'server_id': $ualdx }, xul);
}, window[U[169115]] = function (gc35p, s0k82, zxbw, k9hse6) {
  zxbw = zxbw || $KE2[U[165214]][U[151510]], sendApi($KE2[U[168930]], U[169116], { 'type': gc35p, 'game_pkg': s0k82, 'server_id': zxbw }, k9hse6);
}, window['$KE7P'] = function (nvqw) {
  if (nvqw) {
    if (nvqw[U[140106]] == 0x1) {
      if (nvqw[U[169117]] == 0x1) return 0x2;else return 0x1;
    } else return nvqw[U[140106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$K2P7E'] = function (k829s6, ovzw) {
  $KE2[U[169118]] = { 'step': k829s6, 'server_id': ovzw };var ke6hi = this;$KPE72({ 'title': U[169119] }), sendApi($KE2[U[168930]], U[169120], { 'partner_id': $KE2[U[163641]], 'uid': $KE2[U[165219]], 'game_pkg': $KE2[U[165220]], 'server_id': ovzw, 'platform': $KE2[U[165189]], 'platform_uid': $KE2[U[165221]], 'check_login_time': $KE2[U[169022]], 'check_login_sign': $KE2[U[169021]], 'version_name': $KE2[U[168998]] }, $K2PE7, $K72E, $K2P, function (d$xalu) {
    return d$xalu[U[144118]] == U[149922] || d$xalu[U[140078]] == U[169121] || d$xalu[U[140078]] == U[169122];
  });
}, window['$K2PE7'] = function (sk8902) {
  var ski6e = this;if (sk8902[U[144118]] === U[149922] && sk8902[U[140011]]) {
    var s6k2 = $KE2[U[165214]];s6k2[U[169123]] = $KE2[U[168940]], s6k2[U[151493]] = String(sk8902[U[140011]][U[169124]]), s6k2[U[165191]] = parseInt(sk8902[U[140011]][U[140849]]);if (sk8902[U[140011]][U[165190]]) s6k2[U[165190]] = parseInt(sk8902[U[140011]][U[165190]]);else s6k2[U[165190]] = parseInt(sk8902[U[140011]][U[151510]]);s6k2[U[169125]] = 0x0, s6k2[U[144524]] = $KE2[U[169041]], s6k2[U[169126]] = sk8902[U[140011]][U[169127]], s6k2[U[169128]] = sk8902[U[140011]][U[169128]], console[U[140480]](U[169129] + JSON[U[144510]](s6k2[U[169128]])), $KE2[U[140628]] == 0x1 && s6k2[U[169128]] && s6k2[U[169128]][U[169130]] == 0x1 && ($KE2[U[169131]] = 0x1, window[U[168956]][U[140148]]['$KT2E']()), $K27PE();
  } else $KE2[U[169118]][U[147118]] >= 0x3 ? ($K2P(JSON[U[144510]](sk8902)), window['$KP7E2'](U[169132] + sk8902[U[144118]])) : sendApi($KE2[U[168930]], U[169007], { 'platform': $KE2[U[168928]], 'partner_id': $KE2[U[163641]], 'token': $KE2[U[169005]], 'game_pkg': $KE2[U[165220]], 'deviceId': $KE2[U[165222]], 'scene': U[169008] + $KE2[U[168938]] }, function (uda_l$) {
    if (!uda_l$ || uda_l$[U[144118]] != U[149922]) {
      window['$KP7E2'](U[169020] + uda_l$ && uda_l$[U[144118]]);return;
    }$KE2[U[169021]] = String(uda_l$[U[151493]]), $KE2[U[169022]] = String(uda_l$[U[140849]]), setTimeout(function () {
      $K2P7E($KE2[U[169118]][U[147118]] + 0x1, $KE2[U[169118]][U[151510]]);
    }, 0x5dc);
  }, $K72E, $K2P, function (n1q820) {
    return n1q820[U[144118]] == U[149922] || n1q820[U[144118]] == U[165549];
  });
}, window['$K27PE'] = function () {
  ServerLoading[U[140148]][U[169033]]($KE2[U[140628]]), window['$K72'] = !![], window['$K2EP7']();
}, window['$K27EP'] = function () {
  if (window['$K27'] && window['$KE72'] && window[U[168946]] && window[U[168947]] && window['$KE27'] && window['$KE7']) {
    if (!window[U[168445]][U[140148]]) {
      console[U[140480]](U[169133] + window[U[168445]][U[140148]]);var dla$ux = wx[U[169134]](),
          t7ihe = dla$ux[U[140774]] ? dla$ux[U[140774]] : 0x0,
          q9n2 = { 'cdn': window['$KE2'][U[144524]], 'spareCdn': window['$KE2'][U[164903]], 'newRegister': window['$KE2'][U[140628]], 'wxPC': window['$KE2'][U[164906]], 'wxIOS': window['$KE2'][U[141072]], 'wxAndroid': window['$KE2'][U[151332]], 'wxParam': { 'limitLoad': window['$KE2']['$KTP72E'], 'benchmarkLevel': window['$KE2']['$KTPE72'], 'wxFrom': window[U[140555]][U[168464]] == U[169135] ? 0x1 : 0x0, 'wxSDKVersion': window[U[169064]] }, 'configType': window['$KE2'][U[151851]], 'exposeType': window['$KE2'][U[140712]], 'scene': t7ihe };new window[U[168445]](q9n2, window['$KE2'][U[140101]], window['$KTP7E2']);
    }
  }
}, window['$K2EP7'] = function () {
  if (window['$K27'] && window['$KE72'] && window[U[168946]] && window[U[168947]] && window['$KE27'] && window['$KE7'] && window['$K72'] && window['$K7E']) {
    $KPE27();if (!$K27E) {
      $K27E = !![];if (!window[U[168445]][U[140148]]) window['$K27EP']();var pd$5_ = 0x0,
          hs296k = wx[U[169136]]();hs296k && (window['$KE2'][U[169137]] && (pd$5_ = hs296k[U[140320]]), console[U[140078]](U[169138] + hs296k[U[140320]] + U[169139] + hs296k[U[141213]] + U[169140] + hs296k[U[141215]] + U[169141] + hs296k[U[141214]] + U[169142] + hs296k[U[140176]] + U[169143] + hs296k[U[140177]]));var bxzu = {};for (const j4m7t in $KE2[U[165214]]) {
        bxzu[j4m7t] = $KE2[U[165214]][j4m7t];
      }var qwn1v = { 'channel': window['$KE2'][U[165218]], 'account': window['$KE2'][U[165219]], 'userId': window['$KE2'][U[163640]], 'cdn': window['$KE2'][U[144524]], 'data': window['$KE2'][U[140011]], 'package': window['$KE2'][U[164904]], 'newRegister': window['$KE2'][U[140628]], 'pkgName': window['$KE2'][U[165220]], 'partnerId': window['$KE2'][U[163641]], 'platform_uid': window['$KE2'][U[165221]], 'deviceId': window['$KE2'][U[165222]], 'selectedServer': bxzu, 'configType': window['$KE2'][U[151851]], 'exposeType': window['$KE2'][U[140712]], 'debugUsers': window['$KE2'][U[152244]], 'wxMenuTop': pd$5_, 'wxShield': window['$KE2'][U[140736]] };if (window[U[169043]]) for (var g_r5 in window[U[169043]]) {
        qwn1v[g_r5] = window[U[169043]][g_r5];
      }window[U[168445]][U[140148]]['$K2ET'](qwn1v);
    }
  } else console[U[140078]](U[169144] + window['$K27'] + U[169145] + window['$KE72'] + U[169146] + window[U[168946]] + U[169147] + window[U[168947]] + U[169148] + window['$KE27'] + U[169149] + window['$KE7'] + U[169150] + window['$K72'] + U[169151] + window['$K7E']);
};