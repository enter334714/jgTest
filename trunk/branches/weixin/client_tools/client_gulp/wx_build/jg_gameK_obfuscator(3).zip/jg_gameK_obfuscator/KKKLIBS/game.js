var U = wx.$k;
require(U[168918]);