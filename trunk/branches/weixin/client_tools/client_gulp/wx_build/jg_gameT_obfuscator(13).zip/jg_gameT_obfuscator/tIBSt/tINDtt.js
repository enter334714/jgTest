var M = wx.$T;
import trgajb from '../ttkttt/t6ktgt.js';window[M[149]] = { 'wxVersion': window[M[6]][M[7]] }, window[M[150]] = ![], window['t_KZ'] = 0x1, window[M[151]] = 0x1, window['t_6ZK'] = !![], window[M[152]] = !![], window['t_FM6ZK'] = '', window['t_ZK'] = { 'base_cdn': M[153], 'cdn': M[153] }, t_ZK[M[154]] = {}, t_ZK[M[155]] = '0', t_ZK[M[80]] = window[M[149]][M[156]], t_ZK[M[115]] = '', t_ZK['os'] = '1', t_ZK[M[157]] = M[158], t_ZK[M[159]] = M[160], t_ZK[M[161]] = M[162], t_ZK[M[163]] = M[164], t_ZK[M[165]] = M[166], t_ZK[M[167]] = '1', t_ZK[M[22]] = '', t_ZK[M[168]] = '', t_ZK[M[169]] = 0x0, t_ZK[M[170]] = {}, t_ZK[M[171]] = parseInt(t_ZK[M[167]]), t_ZK[M[172]] = t_ZK[M[167]], t_ZK[M[23]] = {}, t_ZK['t_MZ'] = M[173], t_ZK[M[174]] = ![], t_ZK[M[175]] = M[176], t_ZK[M[177]] = Date[M[142]](), t_ZK[M[178]] = M[179], t_ZK[M[180]] = '_a', t_ZK[M[181]] = 0x1, t_ZK[M[20]] = 0x7c1, t_ZK[M[156]] = window[M[149]][M[156]], t_ZK[M[182]] = ![], t_ZK[M[107]] = ![], t_ZK[M[110]] = ![], t_ZK[M[113]] = ![], window['t_6KZ'] = 0x5, window['t_6K'] = ![], window['t_K6'] = ![], window['t_Z6K'] = ![], window[M[183]] = ![], window[M[184]] = ![], window['t_ZK6'] = ![], window['t_6Z'] = ![], window['t_Z6'] = ![], window['t_K6Z'] = ![], window[M[185]] = function (g1836n) {
  console[M[42]](M[185], g1836n), wx[M[186]]({}), wx[M[49]]({ 'title': M[72], 'content': g1836n, 'success'($pfvz) {
      if ($pfvz[M[187]]) console[M[42]](M[188]);else $pfvz[M[189]] && console[M[42]](M[190]);
    } });
}, window['t_M6ZK'] = function (ozfdp7) {
  console[M[42]](M[191], ozfdp7), t_MZK6(), wx[M[49]]({ 'title': M[72], 'content': ozfdp7, 'confirmText': M[192], 'cancelText': M[193], 'success'(id$pv9) {
      if (id$pv9[M[187]]) window['t_ZM']();else id$pv9[M[189]] && (console[M[42]](M[194]), wx[M[195]]({}));
    } });
}, window[M[196]] = function (gnj8) {
  console[M[42]](M[196], gnj8), wx[M[49]]({ 'title': M[72], 'content': gnj8, 'confirmText': M[197], 'showCancel': ![], 'complete'(jrgbk) {
      console[M[42]](M[194]), wx[M[195]]({});
    } });
}, window['t_M6KZ'] = ![], window['t_MZ6K'] = function (grnaj) {
  window['t_M6KZ'] = !![], wx[M[198]](grnaj);
}, window['t_MZK6'] = function () {
  window['t_M6KZ'] && (window['t_M6KZ'] = ![], wx[M[186]]({}));
}, window['t_MK6Z'] = function (sakjb) {
  window[M[35]][M[36]]['t_MK6Z'](sakjb);
}, window[M[199]] = function (m_w5h6, rjbag) {
  trgajb[M[199]](m_w5h6, function (q7zfo) {
    q7zfo && q7zfo[M[200]] ? q7zfo[M[200]][M[201]] == 0x1 ? rjbag(!![]) : (rjbag(![]), console[M[1]](M[202] + q7zfo[M[200]][M[203]])) : console[M[42]](M[199], q7zfo);
  });
}, window['t_MKZ6'] = function (hmw_x) {
  console[M[42]](M[204], hmw_x);
}, window['t_MZK'] = function (ajrbks) {}, window['t_MKZ'] = function (i$c9t, oe7fzq, ci$d9v) {}, window['t_MK'] = function (z$pd) {
  console[M[42]](M[205], z$pd), window[M[35]][M[36]][M[206]](), window[M[35]][M[36]][M[207]](), window[M[35]][M[36]][M[208]]();
}, window['t_KM'] = function (pd$vzf) {
  window['t_M6ZK'](M[209]);var d9fv = { 'id': window['t_ZK'][M[16]], 'role': window['t_ZK'][M[17]], 'level': window['t_ZK'][M[18]], 'account': window['t_ZK'][M[19]], 'version': window['t_ZK'][M[20]], 'cdn': window['t_ZK'][M[21]], 'pkgName': window['t_ZK'][M[22]], 'gamever': window[M[6]][M[7]], 'serverid': window['t_ZK'][M[23]] ? window['t_ZK'][M[23]][M[24]] : 0x0, 'systemInfo': window[M[25]], 'error': M[210], 'stack': pd$vzf ? pd$vzf : M[209] },
      o7e0 = JSON[M[27]](d9fv);console[M[28]](M[211] + o7e0), window['t_MZ'](o7e0);
}, window['t_ZMK'] = function (w6m5h_) {
  var g861n3 = JSON[M[212]](w6m5h_);g861n3[M[213]] = window[M[6]][M[7]], g861n3[M[214]] = window['t_ZK'][M[23]] ? window['t_ZK'][M[23]][M[24]] : 0x0, g861n3[M[25]] = window[M[25]];var n86g13 = JSON[M[27]](g861n3);console[M[28]](M[215] + n86g13), window['t_MZ'](n86g13);
}, window['t_ZKM'] = function (gn8136, eo0x) {
  var oeq0y = { 'id': window['t_ZK'][M[16]], 'role': window['t_ZK'][M[17]], 'level': window['t_ZK'][M[18]], 'account': window['t_ZK'][M[19]], 'version': window['t_ZK'][M[20]], 'cdn': window['t_ZK'][M[21]], 'pkgName': window['t_ZK'][M[22]], 'gamever': window[M[6]][M[7]], 'serverid': window['t_ZK'][M[23]] ? window['t_ZK'][M[23]][M[24]] : 0x0, 'systemInfo': window[M[25]], 'error': gn8136, 'stack': eo0x },
      c9t$vi = JSON[M[27]](oeq0y);console[M[143]](M[216] + c9t$vi), window['t_MZ'](c9t$vi);
}, window['t_MZ'] = function (mwhxy_) {
  if (window['t_ZK'][M[116]] == M[217]) return;var _0qxy = t_ZK['t_MZ'] + M[218] + t_ZK[M[19]];wx[M[219]]({ 'url': _0qxy, 'method': M[220], 'data': mwhxy_, 'header': { 'content-type': M[221], 'cache-control': M[222] }, 'success': function (rgj38) {
      DEBUG && console[M[42]](M[223], _0qxy, mwhxy_, rgj38);
    }, 'fail': function (oey) {
      DEBUG && console[M[42]](M[223], _0qxy, mwhxy_, oey);
    }, 'complete': function () {} });
}, window[M[224]] = function () {
  function mhyx() {
    return ((0x1 + Math[M[225]]()) * 0x10000 | 0x0)[M[226]](0x10)[M[227]](0x1);
  }return mhyx() + mhyx() + '-' + mhyx() + '-' + mhyx() + '-' + mhyx() + '+' + mhyx() + mhyx() + mhyx();
}, window['t_ZM'] = function () {
  console[M[42]](M[228]);var pz7oe = trgajb[M[229]]();t_ZK[M[172]] = pz7oe[M[230]], t_ZK[M[171]] = pz7oe[M[230]], t_ZK[M[167]] = pz7oe[M[230]], t_ZK[M[22]] = pz7oe[M[231]];var wyh5m = { 'game_ver': t_ZK[M[80]] };t_ZK[M[168]] = this[M[224]](), t_MZ6K({ 'title': M[232] }), trgajb[M[233]](wyh5m, this['t_KMZ'][M[234]](this));
}, window['t_KMZ'] = function (wh1) {
  var v9i2c = wh1[M[235]];console[M[42]](M[236] + v9i2c + M[237] + (v9i2c == 0x1) + M[238] + wh1[M[7]] + M[239] + window[M[149]][M[156]]);if (!wh1[M[7]] || window['t_F6KMZ'](window[M[149]][M[156]], wh1[M[7]]) < 0x0) console[M[42]](M[240]), t_ZK[M[159]] = M[241], t_ZK[M[161]] = M[242], t_ZK[M[163]] = M[243], t_ZK[M[21]] = M[244], t_ZK[M[245]] = M[246], t_ZK[M[247]] = M[248], t_ZK[M[182]] = ![];else window['t_F6KMZ'](window[M[149]][M[156]], wh1[M[7]]) == 0x0 ? (console[M[42]](M[249]), t_ZK[M[159]] = M[160], t_ZK[M[161]] = M[162], t_ZK[M[163]] = M[164], t_ZK[M[21]] = M[153], t_ZK[M[245]] = M[246], t_ZK[M[247]] = M[248], t_ZK[M[182]] = !![]) : (console[M[42]](M[250]), t_ZK[M[159]] = M[160], t_ZK[M[161]] = M[162], t_ZK[M[163]] = M[164], t_ZK[M[21]] = M[153], t_ZK[M[245]] = M[246], t_ZK[M[247]] = M[248], t_ZK[M[182]] = ![]);t_ZK[M[169]] = config[M[251]] ? config[M[251]] : 0x0, this['t_6ZMK'](), this['t_6ZKM'](), window[M[252]] = 0x5, t_MZ6K({ 'title': M[253] }), trgajb[M[254]](this['t_KZM'][M[234]](this));
}, window[M[252]] = 0x5, window['t_KZM'] = function (aksbu, ksbjar) {
  if (aksbu == 0x0 && ksbjar && ksbjar[M[255]]) {
    t_ZK[M[256]] = ksbjar[M[255]];var e0_q = this;t_MZ6K({ 'title': M[257] }), sendApi(t_ZK[M[159]], M[258], { 'platform': t_ZK[M[157]], 'partner_id': t_ZK[M[167]], 'token': ksbjar[M[255]], 'game_pkg': t_ZK[M[22]], 'deviceId': t_ZK[M[168]], 'scene': M[259] + t_ZK[M[169]] }, this['t_6MZK'][M[234]](this), t_6KZ, t_KM);
  } else ksbjar && ksbjar[M[59]] && window[M[252]] > 0x0 && (ksbjar[M[59]][M[108]](M[260]) != -0x1 || ksbjar[M[59]][M[108]](M[261]) != -0x1 || ksbjar[M[59]][M[108]](M[262]) != -0x1 || ksbjar[M[59]][M[108]](M[263]) != -0x1 || ksbjar[M[59]][M[108]](M[264]) != -0x1 || ksbjar[M[59]][M[108]](M[265]) != -0x1) ? (window[M[252]]--, trgajb[M[254]](this['t_KZM'][M[234]](this))) : (window['t_ZKM'](M[266], JSON[M[27]]({ 'status': aksbu, 'data': ksbjar })), window['t_M6ZK'](M[267] + (ksbjar && ksbjar[M[59]] ? '，' + ksbjar[M[59]] : '')));
}, window['t_6MZK'] = function (fpv$9) {
  if (!fpv$9) {
    window['t_ZKM'](M[268], M[269]), window['t_M6ZK'](M[270]);return;
  }if (fpv$9[M[201]] != M[271]) {
    window['t_ZKM'](M[268], JSON[M[27]](fpv$9)), window['t_M6ZK'](M[272] + fpv$9[M[201]]);return;
  }t_ZK[M[273]] = String(fpv$9[M[19]]), t_ZK[M[19]] = String(fpv$9[M[19]]), t_ZK[M[84]] = String(fpv$9[M[84]]), t_ZK[M[172]] = String(fpv$9[M[84]]), t_ZK[M[274]] = String(fpv$9[M[274]]), t_ZK[M[275]] = String(fpv$9[M[276]]), t_ZK[M[277]] = String(fpv$9[M[278]]), t_ZK[M[276]] = '';var f7zo = this;t_MZ6K({ 'title': M[279] }), sendApi(t_ZK[M[159]], M[280], { 'partner_id': t_ZK[M[167]], 'uid': t_ZK[M[19]], 'version': t_ZK[M[80]], 'game_pkg': t_ZK[M[22]], 'device': t_ZK[M[168]] }, f7zo['t_6MKZ'][M[234]](f7zo), t_6KZ, t_KM);
}, window['t_6MKZ'] = function (oxqe70) {
  if (!oxqe70) {
    window['t_M6ZK'](M[281]);return;
  }if (oxqe70[M[201]] != M[271]) {
    window['t_M6ZK'](M[282] + oxqe70[M[201]]);return;
  }if (!oxqe70[M[200]] || oxqe70[M[200]][M[10]] == 0x0) {
    window['t_M6ZK'](M[283]);return;
  }t_ZK[M[284]] = oxqe70[M[285]], t_ZK[M[23]] = { 'server_id': String(oxqe70[M[200]][0x0][M[24]]), 'server_name': String(oxqe70[M[200]][0x0][M[286]]), 'entry_ip': oxqe70[M[200]][0x0][M[287]], 'entry_port': parseInt(oxqe70[M[200]][0x0][M[288]]), 'status': t_Z6M(oxqe70[M[200]][0x0]), 'start_time': oxqe70[M[200]][0x0]['start_time'], 'cdn': t_ZK[M[21]] }, this['t_KZ6M']();
}, window['t_KZ6M'] = function () {
  if (t_ZK[M[284]] == 0x1) {
    var fz$7d = t_ZK[M[23]][M[289]];if (fz$7d === -0x1 || fz$7d === 0x0) {
      window['t_M6ZK'](fz$7d === -0x1 ? M[290] : M[291]);return;
    }t_KM6Z(0x0, t_ZK[M[23]][M[24]]), window[M[35]][M[36]][M[292]](t_ZK[M[284]]);
  } else window[M[35]][M[36]][M[293]](), t_MZK6();window['t_Z6'] = !![], window['t_K6ZM'](), window['t_KZM6']();
}, window['t_6ZMK'] = function () {
  sendApi(t_ZK[M[159]], M[294], { 'game_pkg': t_ZK[M[22]], 'version_name': t_ZK[M[247]] }, this[M[295]][M[234]](this), t_6KZ, t_KM);
}, window[M[295]] = function (hw61m5) {
  if (!hw61m5) {
    window['t_M6ZK'](M[296]);return;
  }if (hw61m5[M[201]] != M[271]) {
    window['t_M6ZK'](M[297] + hw61m5[M[201]]);return;
  }if (!hw61m5[M[200]] || !hw61m5[M[200]][M[80]]) {
    window['t_M6ZK'](M[298] + (hw61m5[M[200]] && hw61m5[M[200]][M[80]]));return;
  }hw61m5[M[200]][M[299]] && hw61m5[M[200]][M[299]][M[10]] > 0xa && (t_ZK[M[300]] = hw61m5[M[200]][M[299]], t_ZK[M[21]] = hw61m5[M[200]][M[299]]), hw61m5[M[200]][M[80]] && (t_ZK[M[20]] = hw61m5[M[200]][M[80]]), console[M[1]](M[301] + t_ZK[M[20]] + M[302] + t_ZK[M[247]]), window['t_ZK6'] = !![], window['t_K6ZM'](), window['t_KZM6']();
}, window[M[303]], window['t_6ZKM'] = function () {
  sendApi(t_ZK[M[159]], 'Common.get_option_pkg', { 'game_pkg': t_ZK[M[22]] }, this['t_6KMZ'][M[234]](this), t_6KZ, t_KM);
}, window['t_6KMZ'] = function (c9t4) {
  if (c9t4[M[201]] === M[271] && c9t4[M[200]]) {
    window[M[303]] = c9t4[M[200]];for (var o7x0eq in c9t4[M[200]]) {
      t_ZK[o7x0eq] = c9t4[M[200]][o7x0eq];
    }
  } else console[M[1]](M[304] + c9t4[M[201]]);window['t_6Z'] = !![], window['t_KZM6']();
}, window[M[305]] = function (kjgra, arjgn, y0_hxm, m_0, m_5h6w, skajb, d$civ, o0z7e, _yqxm0) {
  m_5h6w = String(m_5h6w);var sjubka = d$civ,
      w5_m6h = o0z7e;t_ZK[M[154]][m_5h6w] = { 'productid': m_5h6w, 'productname': sjubka, 'productdesc': w5_m6h, 'roleid': kjgra, 'rolename': arjgn, 'rolelevel': y0_hxm, 'price': skajb, 'callback': _yqxm0 }, sendApi(t_ZK[M[163]], M[306], { 'game_pkg': t_ZK[M[22]], 'server_id': t_ZK[M[23]][M[24]], 'server_name': t_ZK[M[23]][M[286]], 'level': y0_hxm, 'uid': t_ZK[M[19]], 'role_id': kjgra, 'role_name': arjgn, 'product_id': m_5h6w, 'product_name': sjubka, 'product_desc': w5_m6h, 'money': skajb, 'partner_id': t_ZK[M[167]] }, toPayCallBack, t_6KZ, t_KM);
}, window[M[307]] = function (ozqe) {
  if (ozqe) {
    if (ozqe[M[308]] === 0xc8 || ozqe[M[201]] == M[271]) {
      var p7zoef = t_ZK[M[154]][String(ozqe['product_id'])];if (p7zoef[M[309]]) p7zoef[M[309]](ozqe['product_id'], ozqe[M[310]], -0x1);trgajb[M[311]]({ 'cpbill': ozqe[M[310]], 'productid': ozqe['product_id'], 'productname': p7zoef[M[312]], 'productdesc': p7zoef[M[313]], 'serverid': t_ZK[M[23]][M[24]], 'servername': t_ZK[M[23]][M[286]], 'roleid': p7zoef[M[314]], 'rolename': p7zoef[M[315]], 'rolelevel': p7zoef[M[316]], 'price': p7zoef[M[317]], 'extension': JSON[M[27]]({ 'cp_order_id': ozqe[M[310]] }) }, function (z7d, fdv9p$) {
        p7zoef[M[309]] && z7d == 0x0 && p7zoef[M[309]](ozqe['product_id'], ozqe[M[310]], z7d);console[M[1]](JSON[M[27]]({ 'type': M[318], 'status': z7d, 'data': ozqe, 'role_name': p7zoef[M[315]] }));if (z7d === 0x0) {} else {
          if (z7d === 0x1) {} else {
            if (z7d === 0x2) {}
          }
        }
      });
    } else alert(ozqe[M[1]]);
  }
}, window['t_6KZM'] = function () {}, window['t_M6K'] = function (v9$dic, dz$fp7, eoyx, pdz$fv, x0qoye) {
  trgajb[M[319]](t_ZK[M[23]][M[24]], t_ZK[M[23]][M[286]] || t_ZK[M[23]][M[24]], v9$dic, dz$fp7, eoyx), sendApi(t_ZK[M[159]], M[320], { 'game_pkg': t_ZK[M[22]], 'server_id': t_ZK[M[23]][M[24]], 'role_id': v9$dic, 'uid': t_ZK[M[19]], 'role_name': dz$fp7, 'role_type': pdz$fv, 'level': eoyx });
}, window['t_MK6'] = function (eox07q, jrbak, anjgr, xqy0e_, xyq0oe, z$pf, iv9p, i29vc, e0o, b3gj) {
  t_ZK[M[16]] = eox07q, t_ZK[M[17]] = jrbak, t_ZK[M[18]] = anjgr, trgajb[M[321]](t_ZK[M[23]][M[24]], t_ZK[M[23]][M[286]] || t_ZK[M[23]][M[24]], eox07q, jrbak, anjgr), sendApi(t_ZK[M[159]], M[322], { 'game_pkg': t_ZK[M[22]], 'server_id': t_ZK[M[23]][M[24]], 'role_id': eox07q, 'uid': t_ZK[M[19]], 'role_name': jrbak, 'role_type': xqy0e_, 'level': anjgr, 'evolution': xyq0oe });
}, window['t_6MK'] = function (gnjb3, p7d$z, z70qeo, t9cv2, h6w85, cvdi$, pe7fo, xmhy_0, dv$9ip, xyhw_m) {
  t_ZK[M[16]] = gnjb3, t_ZK[M[17]] = p7d$z, t_ZK[M[18]] = z70qeo, trgajb[M[323]](t_ZK[M[23]][M[24]], t_ZK[M[23]][M[286]] || t_ZK[M[23]][M[24]], gnjb3, p7d$z, z70qeo), sendApi(t_ZK[M[159]], M[322], { 'game_pkg': t_ZK[M[22]], 'server_id': t_ZK[M[23]][M[24]], 'role_id': gnjb3, 'uid': t_ZK[M[19]], 'role_name': p7d$z, 'role_type': t9cv2, 'level': z70qeo, 'evolution': h6w85 });
}, window['t_6KM'] = function (y0xqe) {}, window['t_M6'] = function (d9v$fp) {
  trgajb[M[324]](M[324], function (oz7feq) {
    d9v$fp && d9v$fp(oz7feq);
  });
}, window[M[325]] = function () {
  trgajb[M[325]]();
}, window[M[326]] = function () {
  trgajb[M[327]]();
}, window[M[328]] = function (kubaj, ti$cv, v9itc2, tv, kbgaj, kbjras, jabrg, mw61h5) {
  mw61h5 = mw61h5 || t_ZK[M[23]][M[24]], sendApi(t_ZK[M[159]], 'User.get_code', { 'phone': kubaj, 'role_id': ti$cv, 'uid': t_ZK[M[19]], 'game_pkg': t_ZK[M[22]], 'partner_id': t_ZK[M[167]], 'server_id': mw61h5 }, jabrg);
}, window[M[136]] = function (n8g1) {
  window['t_KM6'] = n8g1, window['t_KM6'] && window['t_6M'] && (console[M[1]](M[137] + window['t_6M'][M[138]]), window['t_KM6'](window['t_6M']), window['t_6M'] = null);
}, window['t_K6M'] = function (t9$ic, ozd7f, my5wh_, abrgj) {
  window[M[329]](M[330], { 'game_pkg': window['t_ZK'][M[22]], 'role_id': ozd7f, 'server_id': my5wh_ }, abrgj);
}, window['t_ZM6K'] = function (mh6_5, m_hwy) {
  function _0ex(kuja) {
    var w_xmh = [],
        o07xq = [],
        gnrb3j = window[M[6]][M[331]];for (var w56_h in gnrb3j) {
      var ezfoq = Number(w56_h);(!mh6_5 || !mh6_5[M[10]] || mh6_5[M[108]](ezfoq) != -0x1) && (o07xq[M[39]](gnrb3j[w56_h]), w_xmh[M[39]]([ezfoq, 0x3]));
    }window['t_F6KMZ'](window[M[40]], M[332]) >= 0x0 ? (console[M[42]](M[333]), trgajb[M[334]](o07xq, function (wh1m6) {
      console[M[42]](M[335]), console[M[42]](wh1m6);if (wh1m6 && wh1m6[M[59]] == M[336]) for (var gbkrja in gnrb3j) {
        if (wh1m6[gnrb3j[gbkrja]] == M[337]) {
          var xwh_m = Number(gbkrja);for (var epfzo = 0x0; epfzo < w_xmh[M[10]]; epfzo++) {
            if (w_xmh[epfzo][0x0] == xwh_m) {
              w_xmh[epfzo][0x1] = 0x1;break;
            }
          }
        }
      }window['t_F6KMZ'](window[M[40]], M[338]) >= 0x0 ? wx[M[339]]({ 'withSubscriptions': !![], 'success': function (r8ng13) {
          var bgj3r = r8ng13[M[340]][M[341]];if (bgj3r) {
            console[M[42]](M[342]), console[M[42]](bgj3r);for (var pdvi$ in gnrb3j) {
              if (bgj3r[gnrb3j[pdvi$]] == M[337]) {
                var h16m5w = Number(pdvi$);for (var mqxy_0 = 0x0; mqxy_0 < w_xmh[M[10]]; mqxy_0++) {
                  if (w_xmh[mqxy_0][0x0] == h16m5w) {
                    w_xmh[mqxy_0][0x1] = 0x2;break;
                  }
                }
              }
            }console[M[42]](w_xmh), m_hwy && m_hwy(w_xmh);
          } else console[M[42]](M[343]), console[M[42]](r8ng13), console[M[42]](w_xmh), m_hwy && m_hwy(w_xmh);
        }, 'fail': function () {
          console[M[42]](M[344]), console[M[42]](w_xmh), m_hwy && m_hwy(w_xmh);
        } }) : (console[M[42]](M[345] + window[M[40]]), console[M[42]](w_xmh), m_hwy && m_hwy(w_xmh));
    })) : (console[M[42]](M[346] + window[M[40]]), console[M[42]](w_xmh), m_hwy && m_hwy(w_xmh)), wx[M[347]](_0ex);
  }wx[M[348]](_0ex);
}, window['t_ZMK6'] = { 'isSuccess': ![], 'level': M[349], 'isCharging': ![] }, window['t_Z6MK'] = function (w5mhy) {
  wx[M[124]]({ 'success': function (jks) {
      var df7oz = window['t_ZMK6'];df7oz[M[350]] = !![], df7oz[M[126]] = Number(jks[M[126]])[M[351]](0x0), df7oz[M[128]] = jks[M[128]], w5mhy && w5mhy(df7oz[M[350]], df7oz[M[126]], df7oz[M[128]]);
    }, 'fail': function (v92i) {
      console[M[42]](M[352], v92i[M[59]]);var $p9d = window['t_ZMK6'];w5mhy && w5mhy($p9d[M[350]], $p9d[M[126]], $p9d[M[128]]);
    } });
}, window[M[329]] = function (c$v9ti, vdpi$9, f9d$vp, bjrga, _yexq0, arkjb, n3518, p9d$i) {
  if (bjrga == undefined) bjrga = 0x1;wx[M[219]]({ 'url': c$v9ti, 'method': n3518 || M[353], 'responseType': M[354], 'data': vdpi$9, 'header': { 'content-type': p9d$i || M[221] }, 'success': function (qe70o) {
      DEBUG && console[M[42]](M[355], c$v9ti, info, qe70o);if (qe70o && qe70o[M[356]] == 0xc8) {
        var _qey = qe70o[M[200]];!arkjb || arkjb(_qey) ? f9d$vp && f9d$vp(_qey) : window[M[357]](c$v9ti, vdpi$9, f9d$vp, bjrga, _yexq0, arkjb, qe70o);
      } else window[M[357]](c$v9ti, vdpi$9, f9d$vp, bjrga, _yexq0, arkjb, qe70o);
    }, 'fail': function (pfd$z7) {
      DEBUG && console[M[42]](M[358], c$v9ti, info, pfd$z7), window[M[357]](c$v9ti, vdpi$9, f9d$vp, bjrga, _yexq0, arkjb, pfd$z7);
    }, 'complete': function () {} });
}, window[M[357]] = function (hmw_yx, jbarks, ezofq7, rgbk, $9ivdc, baj, yhwm_5) {
  rgbk - 0x1 > 0x0 ? setTimeout(function () {
    window[M[329]](hmw_yx, jbarks, ezofq7, rgbk - 0x1, $9ivdc, baj);
  }, 0x3e8) : $9ivdc && $9ivdc(JSON[M[27]]({ 'url': hmw_yx, 'response': yhwm_5 }));
}, window[M[359]] = function (abjkrg, o7qxe, ti9v$c, zqfo7, rng8, pd$vfz, f7p$z) {
  !ti9v$c && (ti9v$c = {});var fzep = Math[M[360]](Date[M[142]]() / 0x3e8);ti9v$c[M[278]] = fzep, ti9v$c[M[361]] = o7qxe;var fpdv$ = Object[M[362]](ti9v$c)[M[363]](),
      t9iv = '',
      nr38g1 = '';for (var jngar = 0x0; jngar < fpdv$[M[10]]; jngar++) {
    t9iv = t9iv + (jngar == 0x0 ? '' : '&') + fpdv$[jngar] + ti9v$c[fpdv$[jngar]], nr38g1 = nr38g1 + (jngar == 0x0 ? '' : '&') + fpdv$[jngar] + '=' + encodeURIComponent(ti9v$c[fpdv$[jngar]]);
  }t9iv = t9iv + t_ZK[M[165]];var g831rn = M[364] + md5(t9iv);send(abjkrg + '?' + nr38g1 + (nr38g1 == '' ? '' : '&') + g831rn, null, zqfo7, rng8, pd$vfz, f7p$z || function (x0qy_) {
    return x0qy_[M[201]] == M[271];
  }, null, M[365]);
}, window['t_Z6KM'] = function (rgajnb, w6m_) {
  var w38651 = 0x0;t_ZK[M[23]] && (w38651 = t_ZK[M[23]][M[24]]), sendApi(t_ZK[M[161]], M[366], { 'partnerId': t_ZK[M[167]], 'gamePkg': t_ZK[M[22]], 'logTime': Math[M[360]](Date[M[142]]() / 0x3e8), 'platformUid': t_ZK[M[274]], 'type': rgajnb, 'serverId': w38651 }, null, 0x2, null, function () {
    return !![];
  });
}, window['t_ZKM6'] = function (w56h1m) {
  sendApi(t_ZK[M[159]], M[367], { 'partner_id': t_ZK[M[167]], 'uid': t_ZK[M[19]], 'version': t_ZK[M[80]], 'game_pkg': t_ZK[M[22]], 'device': t_ZK[M[168]] }, t_ZK6M, t_6KZ, t_KM);
}, window['t_ZK6M'] = function (i$cv9t) {
  if (i$cv9t[M[201]] === M[271] && i$cv9t[M[200]]) {
    i$cv9t[M[200]][M[368]]({ 'id': -0x2, 'name': M[369] }), i$cv9t[M[200]][M[368]]({ 'id': -0x1, 'name': M[370] }), t_ZK[M[371]] = i$cv9t[M[200]];if (window[M[372]]) window[M[372]][M[373]]();
  } else t_ZK[M[374]] = ![], window['t_M6ZK'](M[375] + i$cv9t[M[201]]);
}, window['t_M6Z'] = function ($vpfd) {
  sendApi(t_ZK[M[159]], M[376], { 'partner_id': t_ZK[M[167]], 'uid': t_ZK[M[19]], 'version': t_ZK[M[80]], 'game_pkg': t_ZK[M[22]], 'device': t_ZK[M[168]] }, t_MZ6, t_6KZ, t_KM);
}, window['t_MZ6'] = function (vi9tc2) {
  t_ZK[M[377]] = ![];if (vi9tc2[M[201]] === M[271] && vi9tc2[M[200]]) {
    for (var yhmx0 = 0x0; yhmx0 < vi9tc2[M[200]][M[10]]; yhmx0++) {
      vi9tc2[M[200]][yhmx0][M[289]] = t_Z6M(vi9tc2[M[200]][yhmx0]);
    }t_ZK[M[170]][-0x1] = window[M[378]](vi9tc2[M[200]]), window[M[372]][M[379]](-0x1);
  } else window['t_M6ZK'](M[380] + vi9tc2[M[201]]);
}, window[M[381]] = function (lc4t2) {
  sendApi(t_ZK[M[159]], M[376], { 'partner_id': t_ZK[M[167]], 'uid': t_ZK[M[19]], 'version': t_ZK[M[80]], 'game_pkg': t_ZK[M[22]], 'device': t_ZK[M[168]] }, lc4t2, t_6KZ, t_KM);
}, window['t_6MZ'] = function (wh_5, pz7dfo) {
  sendApi(t_ZK[M[159]], M[382], { 'partner_id': t_ZK[M[167]], 'uid': t_ZK[M[19]], 'version': t_ZK[M[80]], 'game_pkg': t_ZK[M[22]], 'device': t_ZK[M[168]], 'server_group_id': pz7dfo }, t_6ZM, t_6KZ, t_KM);
}, window['t_6ZM'] = function (iv9tc$) {
  t_ZK[M[377]] = ![];if (iv9tc$[M[201]] === M[271] && iv9tc$[M[200]] && iv9tc$[M[200]][M[200]]) {
    var uskjb = iv9tc$[M[200]][M[383]],
        ng3jrb = [];for (var rj3ng = 0x0; rj3ng < iv9tc$[M[200]][M[200]][M[10]]; rj3ng++) {
      iv9tc$[M[200]][M[200]][rj3ng][M[289]] = t_Z6M(iv9tc$[M[200]][M[200]][rj3ng]), (ng3jrb[M[10]] == 0x0 || iv9tc$[M[200]][M[200]][rj3ng][M[289]] != 0x0) && (ng3jrb[ng3jrb[M[10]]] = iv9tc$[M[200]][M[200]][rj3ng]);
    }t_ZK[M[170]][uskjb] = window[M[378]](ng3jrb), window[M[372]][M[379]](uskjb);
  } else window['t_M6ZK'](M[384] + iv9tc$[M[201]]);
}, window['t_F6KZ'] = function (v9pd$) {
  sendApi(t_ZK[M[159]], M[385], { 'partner_id': t_ZK[M[167]], 'uid': t_ZK[M[19]], 'version': t_ZK[M[80]], 'game_pkg': t_ZK[M[22]], 'device': t_ZK[M[168]] }, reqServerRecommendCallBack, t_6KZ, t_KM);
}, window[M[386]] = function (nab) {
  t_ZK[M[377]] = ![];if (nab[M[201]] === M[271] && nab[M[200]]) {
    for (var kjga = 0x0; kjga < nab[M[200]][M[10]]; kjga++) {
      nab[M[200]][kjga][M[289]] = t_Z6M(nab[M[200]][kjga]);
    }t_ZK[M[170]][-0x2] = window[M[378]](nab[M[200]]), window[M[372]][M[379]](-0x2);
  } else alert(M[387] + nab[M[201]]);
}, window[M[378]] = function (jbargn) {
  if (!jbargn && jbargn[M[10]] <= 0x0) return jbargn;for (let eqyx_ = 0x0; eqyx_ < jbargn[M[10]]; eqyx_++) {
    jbargn[eqyx_][M[388]] && jbargn[eqyx_][M[388]] == 0x1 && (jbargn[eqyx_][M[286]] += M[389]);
  }return jbargn;
}, window['t_ZM6'] = function (dfzo7p, dc9i$) {
  dfzo7p = dfzo7p || t_ZK[M[23]][M[24]], sendApi(t_ZK[M[159]], 'Common.get_anno', { 'type': '4', 'game_pkg': t_ZK[M[22]], 'server_id': dfzo7p }, dc9i$);
}, window[M[390]] = function (_hyxmw, hyw_mx, v9$idc, hxm_y) {
  v9$idc = v9$idc || t_ZK[M[23]][M[24]], sendApi(t_ZK[M[159]], 'Common.get_new_anno', { 'type': _hyxmw, 'game_pkg': hyw_mx, 'server_id': v9$idc }, hxm_y);
}, window['t_Z6M'] = function (xq0eo7) {
  if (xq0eo7) {
    if (xq0eo7[M[289]] == 0x1) {
      if (xq0eo7[M[391]] == 0x1) return 0x2;else return 0x1;
    } else return xq0eo7[M[289]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['t_KM6Z'] = function ($9vtc, eo7fq) {
  t_ZK['last_check_ban'] = { 'step': $9vtc, 'server_id': eo7fq };var e0_x = this;t_MZ6K({ 'title': M[392] }), sendApi(t_ZK[M[159]], M[393], { 'partner_id': t_ZK[M[167]], 'uid': t_ZK[M[19]], 'game_pkg': t_ZK[M[22]], 'server_id': eo7fq, 'platform': t_ZK[M[84]], 'platform_uid': t_ZK[M[274]], 'check_login_time': t_ZK[M[277]], 'check_login_sign': t_ZK[M[275]], 'version_name': t_ZK[M[247]] }, t_KMZ6, t_6KZ, t_KM, function (d9f$pv) {
    return d9f$pv[M[201]] == M[271] || d9f$pv[M[1]] == M[394] || d9f$pv[M[1]] == M[395];
  });
}, window['t_KMZ6'] = function (ctiv9) {
  var yeqo0x = this;if (ctiv9[M[201]] === M[271] && ctiv9[M[200]]) {
    var _0my = t_ZK[M[23]];_0my[M[396]] = t_ZK[M[171]], _0my[M[276]] = String(ctiv9[M[200]][M[397]]), _0my[M[177]] = parseInt(ctiv9[M[200]][M[278]]);if (ctiv9[M[200]][M[398]]) _0my[M[398]] = parseInt(ctiv9[M[200]][M[398]]);else _0my[M[398]] = parseInt(ctiv9[M[200]][M[24]]);_0my[M[399]] = 0x0, _0my[M[21]] = t_ZK[M[300]], _0my[M[400]] = ctiv9[M[200]][M[401]], _0my[M[402]] = ctiv9[M[200]][M[402]], console[M[42]](M[403] + JSON[M[27]](_0my[M[402]])), t_ZK[M[284]] == 0x1 && _0my[M[402]] && _0my[M[402]][M[404]] == 0x1 && (t_ZK[M[405]] = 0x1, window[M[35]][M[36]]['t_FKZ']()), t_K6MZ();
  } else t_ZK['last_check_ban'][M[406]] >= 0x3 ? (t_KM(JSON[M[27]](ctiv9)), window['t_M6ZK'](M[407] + ctiv9[M[201]])) : sendApi(t_ZK[M[159]], M[258], { 'platform': t_ZK[M[157]], 'partner_id': t_ZK[M[167]], 'token': t_ZK[M[256]], 'game_pkg': t_ZK[M[22]], 'deviceId': t_ZK[M[168]], 'scene': M[259] + t_ZK[M[169]] }, function (z$f7pd) {
    if (!z$f7pd || z$f7pd[M[201]] != M[271]) {
      window['t_M6ZK'](M[272] + z$f7pd && z$f7pd[M[201]]);return;
    }t_ZK[M[275]] = String(z$f7pd[M[276]]), t_ZK[M[277]] = String(z$f7pd[M[278]]), setTimeout(function () {
      t_KM6Z(t_ZK['last_check_ban'][M[406]] + 0x1, t_ZK['last_check_ban'][M[24]]);
    }, 0x5dc);
  }, t_6KZ, t_KM, function (po) {
    return po[M[201]] == M[271] || po[M[201]] == M[408];
  });
}, window['t_K6MZ'] = function () {
  ServerLoading[M[36]][M[292]](t_ZK[M[284]]), window['t_6K'] = !![], window['t_KZM6']();
}, window['t_K6ZM'] = function () {
  if (window['t_K6'] && window['t_Z6K'] && window[M[183]] && window[M[184]] && window['t_ZK6'] && window['t_Z6']) {
    if (!window[M[409]][M[36]]) {
      console[M[42]](M[410] + window[M[409]][M[36]]);var g1n83r = wx[M[411]](),
          jrgbn3 = g1n83r[M[138]] ? g1n83r[M[138]] : 0x0,
          sarjb = { 'cdn': window['t_ZK'][M[21]], 'spareCdn': window['t_ZK'][M[245]], 'newRegister': window['t_ZK'][M[284]], 'wxPC': window['t_ZK'][M[113]], 'wxIOS': window['t_ZK'][M[107]], 'wxAndroid': window['t_ZK'][M[110]], 'wxParam': { 'limitLoad': window['t_ZK']['t_FM6KZ'], 'benchmarkLevel': window['t_ZK']['t_FMZ6K'], 'wxFrom': window[M[6]][M[251]] == M[412] ? 0x1 : 0x0, 'wxSDKVersion': window[M[40]] }, 'configType': window['t_ZK'][M[178]], 'exposeType': window['t_ZK'][M[180]], 'scene': jrgbn3 };new window[M[409]](sarjb, window['t_ZK'][M[20]], window['t_FM6ZK']);
    }
  }
}, window['t_KZM6'] = function () {
  if (window['t_K6'] && window['t_Z6K'] && window[M[183]] && window[M[184]] && window['t_ZK6'] && window['t_Z6'] && window['t_6K'] && window['t_6Z']) {
    t_MZK6();if (!t_K6Z) {
      t_K6Z = !![];if (!window[M[409]][M[36]]) window['t_K6ZM']();var fzqoe = 0x0,
          $7f = wx[M[413]]();$7f && (window['t_ZK'][M[112]] && (fzqoe = $7f[M[102]]), console[M[1]](M[414] + $7f[M[102]] + M[415] + $7f[M[103]] + M[416] + $7f[M[104]] + M[417] + $7f[M[105]] + M[418] + $7f[M[419]] + M[420] + $7f[M[421]]));var abgrkj = {};for (const c42lti in t_ZK[M[23]]) {
        abgrkj[c42lti] = t_ZK[M[23]][c42lti];
      }var o0qyx = { 'channel': window['t_ZK'][M[172]], 'account': window['t_ZK'][M[19]], 'userId': window['t_ZK'][M[273]], 'cdn': window['t_ZK'][M[21]], 'data': window['t_ZK'][M[200]], 'package': window['t_ZK'][M[155]], 'newRegister': window['t_ZK'][M[284]], 'pkgName': window['t_ZK'][M[22]], 'partnerId': window['t_ZK'][M[167]], 'platform_uid': window['t_ZK'][M[274]], 'deviceId': window['t_ZK'][M[168]], 'selectedServer': abgrkj, 'configType': window['t_ZK'][M[178]], 'exposeType': window['t_ZK'][M[180]], 'debugUsers': window['t_ZK'][M[175]], 'wxMenuTop': fzqoe, 'wxShield': window['t_ZK'][M[182]] };if (window[M[303]]) for (var i2v9t in window[M[303]]) {
        o0qyx[i2v9t] = window[M[303]][i2v9t];
      }window[M[409]][M[36]]['t_KZF'](o0qyx);
    }
  } else console[M[1]](M[422] + window['t_K6'] + M[423] + window['t_Z6K'] + M[424] + window[M[183]] + M[425] + window[M[184]] + M[426] + window['t_ZK6'] + M[427] + window['t_Z6'] + M[428] + window['t_6K'] + M[429] + window['t_6Z']);
};