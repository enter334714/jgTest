var M = wx.$T;
require('tBFtt.js'), window[M[814]][M[815]][M[816]] = null, window['client_pb'] = require('tCLIENTtt.js'), window[M[817]] = window[M[814]][M[818]][M[819]](client_pb);