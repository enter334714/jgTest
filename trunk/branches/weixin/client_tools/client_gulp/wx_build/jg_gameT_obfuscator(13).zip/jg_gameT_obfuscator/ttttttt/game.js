var M = wx.$T;
import 'ttMAItttt.js';