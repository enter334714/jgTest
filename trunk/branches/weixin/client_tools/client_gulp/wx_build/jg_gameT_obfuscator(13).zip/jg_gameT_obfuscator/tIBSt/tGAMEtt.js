var M = wx.$T;
console[M[1]](M[2]), window[M[3]], wx[M[4]](function (sjkrba) {
  if (sjkrba) {
    if (sjkrba[M[5]]) {
      var i$cvt = window[M[6]][M[7]][M[8]](new RegExp(/\./, 'g'), '_'),
          y0_mhx = sjkrba[M[5]],
          rkb = y0_mhx[M[9]](/(ttttttt\/tGAMEtt.js:)[0-9]{1,60}(:)/g);if (rkb) for (var eq70ox = 0x0; eq70ox < rkb[M[10]]; eq70ox++) {
        if (rkb[eq70ox] && rkb[eq70ox][M[10]] > 0x0) {
          var il2c4t = parseInt(rkb[eq70ox][M[8]](M[11], '')[M[8]](':', ''));y0_mhx = y0_mhx[M[8]](rkb[eq70ox], rkb[eq70ox][M[8]](':' + il2c4t + ':', ':' + (il2c4t - 0x2) + ':'));
        }
      }y0_mhx = y0_mhx[M[8]](new RegExp(M[12], 'g'), M[13] + i$cvt + M[14]), y0_mhx = y0_mhx[M[8]](new RegExp(M[15], 'g'), M[13] + i$cvt + M[14]), sjkrba[M[5]] = y0_mhx;
    }var juabsk = { 'id': window['t_ZK'][M[16]], 'role': window['t_ZK'][M[17]], 'level': window['t_ZK'][M[18]], 'user': window['t_ZK'][M[19]], 'version': window['t_ZK'][M[20]], 'cdn': window['t_ZK'][M[21]], 'pkgName': window['t_ZK'][M[22]], 'gamever': window[M[6]][M[7]], 'serverid': window['t_ZK'][M[23]] ? window['t_ZK'][M[23]][M[24]] : 0x0, 'systemInfo': window[M[25]], 'error': M[26], 'stack': sjkrba ? sjkrba[M[5]] : '' },
        wm_hy5 = JSON[M[27]](juabsk);console[M[28]](M[29] + wm_hy5), (!window[M[3]] || window[M[3]] != juabsk[M[28]]) && (window[M[3]] = juabsk[M[28]], window['t_MZ'](juabsk));
  }
});import 'ttfttt.js';import 'tt112tt.js';window[M[30]] = require(M[31]);import 'tINDtt.js';import 'ttLIB23tt.js';import 'tWXMtadtt.js';import 'ttINItt.js';console[M[1]](M[32]), console[M[1]](M[33]), t_MZ6K({ 'title': M[34] });var t$icv9 = { 't_FMKZ6': !![] };new window[M[35]](t$icv9), window[M[35]][M[36]]['t_F6ZKM']();if (window['t_FMZK6']) clearInterval(window['t_FMZK6']);window['t_FMZK6'] = null, window['t_F6KMZ'] = function (opdz7f, ymx0_h) {
  if (!opdz7f || !ymx0_h) return 0x0;opdz7f = opdz7f[M[37]]('.'), ymx0_h = ymx0_h[M[37]]('.');const f7dzp$ = Math[M[38]](opdz7f[M[10]], ymx0_h[M[10]]);while (opdz7f[M[10]] < f7dzp$) {
    opdz7f[M[39]]('0');
  }while (ymx0_h[M[10]] < f7dzp$) {
    ymx0_h[M[39]]('0');
  }for (var pze7f = 0x0; pze7f < f7dzp$; pze7f++) {
    const hm0x_y = parseInt(opdz7f[pze7f]),
          p7ozf = parseInt(ymx0_h[pze7f]);if (hm0x_y > p7ozf) return 0x1;else {
      if (hm0x_y < p7ozf) return -0x1;
    }
  }return 0x0;
}, window[M[40]] = wx[M[41]]()[M[40]], console[M[42]](M[43] + window[M[40]]);var tr3gnj = wx[M[44]]();tr3gnj[M[45]](function (dpofz7) {
  console[M[42]](M[46] + dpofz7[M[47]]);
}), tr3gnj[M[48]](function () {
  wx[M[49]]({ 'title': M[50], 'content': M[51], 'showCancel': ![], 'success': function (kbargj) {
      tr3gnj[M[52]]();
    } });
}), tr3gnj[M[53]](function () {
  console[M[42]](M[54]);
}), window['t_F6KZM'] = function () {
  console[M[42]](M[55]);var qo7fe = wx[M[56]]({ 'name': M[57], 'success': function (ti94c) {
      console[M[42]](M[58]), console[M[42]](ti94c), ti94c && ti94c[M[59]] == M[60] ? (window['t_K6'] = !![], window['t_K6ZM'](), window['t_KZM6']()) : setTimeout(function () {
        window['t_F6KZM']();
      }, 0x1f4);
    }, 'fail': function (m6h1w) {
      console[M[42]](M[61]), console[M[42]](m6h1w), setTimeout(function () {
        window['t_F6KZM']();
      }, 0x1f4);
    } });qo7fe && qo7fe[M[62]](i4tcl2 => {});
}, window['t_FZMK6'] = function () {
  console[M[42]](M[63]);var ye0qx_ = wx[M[56]]({ 'name': M[64], 'success': function (w61mh5) {
      console[M[42]](M[65]), console[M[42]](w61mh5), w61mh5 && w61mh5[M[59]] == M[60] ? (window['t_Z6K'] = !![], window['t_K6ZM'](), window['t_KZM6']()) : setTimeout(function () {
        window['t_FZMK6']();
      }, 0x1f4);
    }, 'fail': function (ezpf7) {
      console[M[42]](M[66]), console[M[42]](ezpf7), setTimeout(function () {
        window['t_FZMK6']();
      }, 0x1f4);
    } });ye0qx_ && ye0qx_[M[62]](h86w => {});
}, window[M[67]] = function () {
  window['t_F6KMZ'](window[M[40]], M[68]) >= 0x0 ? (console[M[42]](M[69] + window[M[40]] + M[70]), window['t_ZM'](), window['t_F6KZM'](), window['t_FZMK6']()) : (window['t_ZKM'](M[71], window[M[40]]), wx[M[49]]({ 'title': M[72], 'content': M[73] }));
}, window[M[25]] = '', wx[M[74]]({ 'success'(t9v2) {
    window[M[25]] = M[75] + t9v2[M[76]] + M[77] + t9v2[M[78]] + M[79] + t9v2[M[80]] + M[81] + t9v2[M[82]] + M[83] + t9v2[M[84]] + M[85] + t9v2[M[40]] + M[86] + t9v2[M[87]], console[M[42]](window[M[25]]), console[M[42]](M[88] + t9v2[M[89]] + M[90] + t9v2[M[91]] + M[92] + t9v2[M[93]] + M[94] + t9v2[M[95]] + M[96] + t9v2[M[97]] + M[98] + t9v2[M[99]] + M[100] + (t9v2[M[101]] ? t9v2[M[101]][M[102]] + ',' + t9v2[M[101]][M[103]] + ',' + t9v2[M[101]][M[104]] + ',' + t9v2[M[101]][M[105]] : ''));var q7ozf = t9v2[M[82]] ? t9v2[M[82]][M[106]]() : '',
        c94t2 = t9v2[M[78]] ? t9v2[M[78]][M[106]]()[M[8]]('\x20', '') : '';window['t_ZK'][M[107]] = q7ozf[M[108]](M[109]) != -0x1, window['t_ZK'][M[110]] = q7ozf[M[108]](M[111]) != -0x1, window['t_ZK'][M[112]] = q7ozf[M[108]](M[109]) != -0x1 || q7ozf[M[108]](M[111]) != -0x1, window['t_ZK'][M[113]] = q7ozf[M[108]](M[114]) != -0x1 || q7ozf[M[108]](M[115]) != -0x1, window['t_ZK'][M[116]] = t9v2[M[84]] ? t9v2[M[84]][M[106]]() : '', window['t_ZK']['t_FM6KZ'] = ![], window['t_ZK']['t_FMZ6K'] = 0x2;if (q7ozf[M[108]](M[111]) != -0x1) {
      if (t9v2[M[87]] >= 0x18) window['t_ZK']['t_FMZ6K'] = 0x3;else window['t_ZK']['t_FMZ6K'] = 0x2;
    } else {
      if (q7ozf[M[108]](M[109]) != -0x1) {
        if (t9v2[M[87]] && t9v2[M[87]] >= 0x14) window['t_ZK']['t_FMZ6K'] = 0x3;else {
          if (c94t2[M[108]](M[117]) != -0x1 || c94t2[M[108]](M[118]) != -0x1 || c94t2[M[108]](M[119]) != -0x1 || c94t2[M[108]](M[120]) != -0x1 || c94t2[M[108]](M[121]) != -0x1) window['t_ZK']['t_FMZ6K'] = 0x2;else window['t_ZK']['t_FMZ6K'] = 0x3;
        }
      } else window['t_ZK']['t_FMZ6K'] = 0x2;
    }console[M[42]](M[122] + window['t_ZK']['t_FM6KZ'] + M[123] + window['t_ZK']['t_FMZ6K']);
  } }), wx[M[124]]({ 'success': function (sbaju) {
    console[M[42]](M[125] + sbaju[M[126]] + M[127] + sbaju[M[128]]);
  } }), wx[M[129]]({ 'success': function (qeyo) {
    console[M[42]](M[130] + qeyo[M[131]]);
  } }), wx[M[132]]({ 'keepScreenOn': !![] }), wx[M[133]](function (uabs) {
  console[M[42]](M[130] + uabs[M[131]] + M[134] + uabs[M[135]]);
}), wx[M[136]](function (q7eofz) {
  window['t_6M'] = q7eofz, window['t_KM6'] && window['t_6M'] && (console[M[1]](M[137] + window['t_6M'][M[138]]), window['t_KM6'](window['t_6M']), window['t_6M'] = null);
}), window[M[139]] = 0x0, window['t_FZ6KM'] = 0x0, window[M[140]] = null, wx[M[141]](function () {
  window['t_FZ6KM']++;var bnagjr = Date[M[142]]();(window[M[139]] == 0x0 || bnagjr - window[M[139]] > 0x1d4c0) && (console[M[143]](M[144]), wx[M[145]]());if (window['t_FZ6KM'] >= 0x2) {
    window['t_FZ6KM'] = 0x0, console[M[28]](M[146]), wx[M[147]]('0', 0x1);if (window['t_ZK'] && window['t_ZK'][M[107]]) window['t_ZKM'](M[148], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});