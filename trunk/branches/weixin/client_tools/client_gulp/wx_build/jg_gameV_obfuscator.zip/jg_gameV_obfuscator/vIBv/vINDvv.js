var Q = wx.$v;
import vqxpgvw from '../vvavvv/v7tvv.js';window[Q[360148]] = { 'wxVersion': window[Q[360006]]['game_ver'] }, window[Q[360149]] = ![], window['_vDK'] = 0x1, window[Q[360150]] = 0x1, window['_v$KD'] = !![], window[Q[360151]] = !![], window['_v6O$KD'] = '', window['_vKD'] = { 'base_cdn': Q[360152], 'cdn': Q[360152] }, _vKD[Q[360153]] = {}, _vKD[Q[360154]] = '0', _vKD[Q[360079]] = window[Q[360148]][Q[360155]], _vKD[Q[360114]] = '', _vKD['os'] = '1', _vKD[Q[360156]] = Q[360157], _vKD[Q[360158]] = Q[360159], _vKD[Q[360160]] = Q[360161], _vKD[Q[360162]] = Q[360163], _vKD[Q[360164]] = Q[360165], _vKD[Q[360166]] = '1', _vKD[Q[360021]] = '', _vKD[Q[360167]] = '', _vKD[Q[360168]] = 0x0, _vKD[Q[360169]] = {}, _vKD[Q[360170]] = parseInt(_vKD[Q[360166]]), _vKD[Q[360171]] = _vKD[Q[360166]], _vKD[Q[360022]] = {}, _vKD['_vOK'] = Q[360172], _vKD[Q[360173]] = ![], _vKD[Q[360174]] = Q[360175], _vKD[Q[360176]] = Date[Q[360141]](), _vKD[Q[360177]] = Q[360178], _vKD[Q[360179]] = '_a', _vKD[Q[360180]] = 0x2, _vKD[Q[360019]] = 0x7c1, _vKD[Q[360155]] = window[Q[360148]][Q[360155]], _vKD[Q[360181]] = ![], _vKD[Q[360106]] = ![], _vKD[Q[360109]] = ![], _vKD[Q[360112]] = ![], window['_v$DK'] = 0x5, window['_v$D'] = ![], window['_vD$'] = ![], window['_vK$D'] = ![], window[Q[360182]] = ![], window[Q[360183]] = ![], window['_vKD$'] = ![], window['_v$K'] = ![], window['_vK$'] = ![], window['_vD$K'] = ![], window[Q[360184]] = function (of$is9) {
  console[Q[360041]](Q[360184], of$is9), wx[Q[360185]]({}), wx[Q[360048]]({ 'title': Q[360071], 'content': of$is9, 'success'(pxg5vw) {
      if (pxg5vw[Q[360186]]) console[Q[360041]](Q[360187]);else pxg5vw[Q[360188]] && console[Q[360041]](Q[360189]);
    } });
}, window['_vO$KD'] = function (d0ma) {
  console[Q[360041]](Q[360190], d0ma), _vOKD$(), wx[Q[360048]]({ 'title': Q[360071], 'content': d0ma, 'confirmText': Q[360191], 'cancelText': Q[360192], 'success'(_24t3) {
      if (_24t3[Q[360186]]) window['_vKO']();else _24t3[Q[360188]] && (console[Q[360041]](Q[360193]), wx[Q[360194]]({}));
    } });
}, window[Q[360195]] = function (xgvp5w) {
  console[Q[360041]](Q[360195], xgvp5w), wx[Q[360048]]({ 'title': Q[360071], 'content': xgvp5w, 'confirmText': Q[360196], 'showCancel': ![], 'complete'(z16_hy) {
      console[Q[360041]](Q[360193]), wx[Q[360194]]({});
    } });
}, window['_vO$DK'] = ![], window['_vOK$D'] = function (c0ad) {
  window['_vO$DK'] = !![], wx[Q[360197]](c0ad);
}, window['_vOKD$'] = function () {
  window['_vO$DK'] && (window['_vO$DK'] = ![], wx[Q[360185]]({}));
}, window['_vOD$K'] = function (lqeu8) {
  window[Q[360034]][Q[360035]]['_vOD$K'](lqeu8);
}, window[Q[360198]] = function (mdjck, $nt4o) {
  vqxpgvw[Q[360198]](mdjck, function (y1_th2) {
    y1_th2 && y1_th2[Q[360199]] ? y1_th2[Q[360199]][Q[360200]] == 0x1 ? $nt4o(!![]) : ($nt4o(![]), console[Q[360001]](Q[360201] + y1_th2[Q[360199]][Q[360202]])) : console[Q[360041]](Q[360198], y1_th2);
  });
}, window['_vODK$'] = function (r9$fs) {
  console[Q[360041]](Q[360203], r9$fs);
}, window['_vOKD'] = function (km57c) {}, window['_vODK'] = function (bqel8u, z68bu, tno234) {}, window['_vOD'] = function (xwv5p) {
  console[Q[360041]](Q[360204], xwv5p), window[Q[360034]][Q[360035]][Q[360205]](), window[Q[360034]][Q[360035]][Q[360206]](), window[Q[360034]][Q[360035]][Q[360207]]();
}, window['_vDO'] = function (vp7g) {
  window['_vO$KD'](Q[360208]);var yh1_t2 = { 'id': window['_vKD'][Q[360015]], 'role': window['_vKD'][Q[360016]], 'level': window['_vKD'][Q[360017]], 'account': window['_vKD'][Q[360018]], 'version': window['_vKD'][Q[360019]], 'cdn': window['_vKD'][Q[360020]], 'pkgName': window['_vKD'][Q[360021]], 'gamever': window[Q[360006]]['game_ver'], 'serverid': window['_vKD'][Q[360022]] ? window['_vKD'][Q[360022]][Q[360023]] : 0x0, 'systemInfo': window[Q[360024]], 'error': Q[360209], 'stack': vp7g ? vp7g : Q[360208] },
      adm0cj = JSON[Q[360026]](yh1_t2);console[Q[360027]](Q[360210] + adm0cj), window['_vOK'](adm0cj);
}, window['_vKOD'] = function (x7vpk) {
  var pwgeq = JSON[Q[360211]](x7vpk);pwgeq[Q[360212]] = window[Q[360006]]['game_ver'], pwgeq[Q[360213]] = window['_vKD'][Q[360022]] ? window['_vKD'][Q[360022]][Q[360023]] : 0x0, pwgeq[Q[360024]] = window[Q[360024]];var wgb8 = JSON[Q[360026]](pwgeq);console[Q[360027]](Q[360214] + wgb8), window['_vOK'](wgb8);
}, window['_vKDO'] = function (u8lbz6, ebq8u) {
  var cda0j = { 'id': window['_vKD'][Q[360015]], 'role': window['_vKD'][Q[360016]], 'level': window['_vKD'][Q[360017]], 'account': window['_vKD'][Q[360018]], 'version': window['_vKD'][Q[360019]], 'cdn': window['_vKD'][Q[360020]], 'pkgName': window['_vKD'][Q[360021]], 'gamever': window[Q[360006]]['game_ver'], 'serverid': window['_vKD'][Q[360022]] ? window['_vKD'][Q[360022]][Q[360023]] : 0x0, 'systemInfo': window[Q[360024]], 'error': u8lbz6, 'stack': ebq8u },
      mcjd0k = JSON[Q[360026]](cda0j);console[Q[360142]](Q[360215] + mcjd0k), window['_vOK'](mcjd0k);
}, window['_vOK'] = function (pxqew) {
  if (window['_vKD'][Q[360115]] == Q[360216]) return;var x5gvw = _vKD['_vOK'] + Q[360217] + _vKD[Q[360018]];wx[Q[360218]]({ 'url': x5gvw, 'method': Q[360219], 'data': pxqew, 'header': { 'content-type': Q[360220], 'cache-control': Q[360221] }, 'success': function (i$fs9) {
      DEBUG && console[Q[360041]](Q[360222], x5gvw, pxqew, i$fs9);
    }, 'fail': function (wgp5v) {
      DEBUG && console[Q[360041]](Q[360222], x5gvw, pxqew, wgp5v);
    }, 'complete': function () {} });
}, window[Q[360223]] = function () {
  function zl1() {
    return ((0x1 + Math[Q[360224]]()) * 0x10000 | 0x0)[Q[360225]](0x10)[Q[360226]](0x1);
  }return zl1() + zl1() + '-' + zl1() + '-' + zl1() + '-' + zl1() + '+' + zl1() + zl1() + zl1();
}, window['_vKO'] = function () {
  console[Q[360041]](Q[360227]);var gpv57x = vqxpgvw[Q[360228]]();_vKD[Q[360171]] = gpv57x[Q[360229]], _vKD[Q[360170]] = gpv57x[Q[360229]], _vKD[Q[360166]] = gpv57x[Q[360229]], _vKD[Q[360021]] = gpv57x[Q[360230]];var hu6 = { 'game_ver': _vKD[Q[360079]] };_vKD[Q[360167]] = this[Q[360223]](), _vOK$D({ 'title': Q[360231] }), vqxpgvw[Q[360232]](hu6, this['_vDOK'][Q[360233]](this));
}, window['_vDOK'] = function (z6y_1) {
  var l8u6 = z6y_1[Q[360234]];console[Q[360041]](Q[360235] + l8u6 + Q[360236] + (l8u6 == 0x1) + Q[360237] + z6y_1['game_ver'] + Q[360238] + window[Q[360148]][Q[360155]]);if (!z6y_1['game_ver'] || window['_v6$DOK'](window[Q[360148]][Q[360155]], z6y_1['game_ver']) < 0x0) console[Q[360041]](Q[360239]), _vKD[Q[360158]] = Q[360240], _vKD[Q[360160]] = Q[360241], _vKD[Q[360162]] = Q[360242], _vKD[Q[360020]] = Q[360243], _vKD[Q[360244]] = Q[360245], _vKD[Q[360246]] = 'qy', _vKD[Q[360181]] = ![];else window['_v6$DOK'](window[Q[360148]][Q[360155]], z6y_1['game_ver']) == 0x0 ? (console[Q[360041]](Q[360247]), _vKD[Q[360158]] = Q[360159], _vKD[Q[360160]] = Q[360161], _vKD[Q[360162]] = Q[360163], _vKD[Q[360020]] = Q[360248], _vKD[Q[360244]] = Q[360245], _vKD[Q[360246]] = Q[360249], _vKD[Q[360181]] = !![]) : (console[Q[360041]](Q[360250]), _vKD[Q[360158]] = Q[360159], _vKD[Q[360160]] = Q[360161], _vKD[Q[360162]] = Q[360163], _vKD[Q[360020]] = Q[360248], _vKD[Q[360244]] = Q[360245], _vKD[Q[360246]] = Q[360249], _vKD[Q[360181]] = ![]);_vKD[Q[360168]] = config[Q[360251]] ? config[Q[360251]] : 0x0, this['_v$KOD'](), this['_v$KDO'](), window[Q[360252]] = 0x5, _vOK$D({ 'title': Q[360253] }), vqxpgvw[Q[360254]](this['_vDKO'][Q[360233]](this));
}, window[Q[360252]] = 0x5, window['_vDKO'] = function (p05k, vwpx5) {
  if (p05k == 0x0 && vwpx5 && vwpx5[Q[360255]]) {
    _vKD[Q[360256]] = vwpx5[Q[360255]];var h_yz6 = this;_vOK$D({ 'title': Q[360257] }), sendApi(_vKD[Q[360158]], Q[360258], { 'platform': _vKD[Q[360156]], 'partner_id': _vKD[Q[360166]], 'token': vwpx5[Q[360255]], 'game_pkg': _vKD[Q[360021]], 'deviceId': _vKD[Q[360167]], 'scene': Q[360259] + _vKD[Q[360168]] }, this['_v$OKD'][Q[360233]](this), _v$DK, _vDO);
  } else vwpx5 && vwpx5[Q[360058]] && window[Q[360252]] > 0x0 && (vwpx5[Q[360058]][Q[360107]](Q[360260]) != -0x1 || vwpx5[Q[360058]][Q[360107]](Q[360261]) != -0x1 || vwpx5[Q[360058]][Q[360107]](Q[360262]) != -0x1 || vwpx5[Q[360058]][Q[360107]](Q[360263]) != -0x1 || vwpx5[Q[360058]][Q[360107]](Q[360264]) != -0x1 || vwpx5[Q[360058]][Q[360107]](Q[360265]) != -0x1) ? (window[Q[360252]]--, vqxpgvw[Q[360254]](this['_vDKO'][Q[360233]](this))) : (window['_vKDO'](Q[360266], JSON[Q[360026]]({ 'status': p05k, 'data': vwpx5 })), window['_vO$KD'](Q[360267] + (vwpx5 && vwpx5[Q[360058]] ? '，' + vwpx5[Q[360058]] : '')));
}, window['_v$OKD'] = function (bqgew) {
  if (!bqgew) {
    window['_vKDO'](Q[360268], Q[360269]), window['_vO$KD'](Q[360270]);return;
  }if (bqgew[Q[360200]] != Q[360271]) {
    window['_vKDO'](Q[360268], JSON[Q[360026]](bqgew)), window['_vO$KD'](Q[360272] + bqgew[Q[360200]]);return;
  }_vKD[Q[360273]] = String(bqgew[Q[360018]]), _vKD[Q[360018]] = String(bqgew[Q[360018]]), _vKD[Q[360083]] = String(bqgew[Q[360083]]), _vKD[Q[360171]] = String(bqgew[Q[360083]]), _vKD[Q[360274]] = String(bqgew[Q[360274]]), _vKD[Q[360275]] = String(bqgew[Q[360276]]), _vKD[Q[360277]] = String(bqgew[Q[360278]]), _vKD[Q[360276]] = '';var fis$ = this;_vOK$D({ 'title': Q[360279] }), sendApi(_vKD[Q[360158]], Q[360280], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, fis$['_v$ODK'][Q[360233]](fis$), _v$DK, _vDO);
}, window['_v$ODK'] = function (ajmc0d) {
  if (!ajmc0d) {
    window['_vO$KD'](Q[360281]);return;
  }if (ajmc0d[Q[360200]] != Q[360271]) {
    window['_vO$KD'](Q[360282] + ajmc0d[Q[360200]]);return;
  }if (!ajmc0d[Q[360199]] || ajmc0d[Q[360199]][Q[360009]] == 0x0) {
    window['_vO$KD'](Q[360283]);return;
  }_vKD[Q[360284]] = ajmc0d[Q[360285]], _vKD[Q[360022]] = { 'server_id': String(ajmc0d[Q[360199]][0x0][Q[360023]]), 'server_name': String(ajmc0d[Q[360199]][0x0][Q[360286]]), 'entry_ip': ajmc0d[Q[360199]][0x0][Q[360287]], 'entry_port': parseInt(ajmc0d[Q[360199]][0x0][Q[360288]]), 'status': _vK$O(ajmc0d[Q[360199]][0x0]), 'start_time': ajmc0d[Q[360199]][0x0][Q[360289]], 'cdn': _vKD[Q[360020]] }, this['_vDK$O']();
}, window['_vDK$O'] = function () {
  if (_vKD[Q[360284]] == 0x1) {
    var rif9s = _vKD[Q[360022]][Q[360290]];if (rif9s === -0x1 || rif9s === 0x0) {
      window['_vO$KD'](rif9s === -0x1 ? Q[360291] : Q[360292]);return;
    }_vDO$K(0x0, _vKD[Q[360022]][Q[360023]]), window[Q[360034]][Q[360035]][Q[360293]](_vKD[Q[360284]]);
  } else window[Q[360034]][Q[360035]][Q[360294]](), _vOKD$();window['_vK$'] = !![], window['_vD$KO'](), window['_vDKO$']();
}, window['_v$KOD'] = function () {
  sendApi(_vKD[Q[360158]], Q[360295], { 'game_pkg': _vKD[Q[360021]], 'version_name': _vKD[Q[360246]] }, this[Q[360296]][Q[360233]](this), _v$DK, _vDO);
}, window[Q[360296]] = function (ebxqgw) {
  if (!ebxqgw) {
    window['_vO$KD'](Q[360297]);return;
  }if (ebxqgw[Q[360200]] != Q[360271]) {
    window['_vO$KD'](Q[360298] + ebxqgw[Q[360200]]);return;
  }if (!ebxqgw[Q[360199]] || !ebxqgw[Q[360199]][Q[360079]]) {
    window['_vO$KD'](Q[360299] + (ebxqgw[Q[360199]] && ebxqgw[Q[360199]][Q[360079]]));return;
  }ebxqgw[Q[360199]][Q[360300]] && ebxqgw[Q[360199]][Q[360300]][Q[360009]] > 0xa && (_vKD[Q[360301]] = ebxqgw[Q[360199]][Q[360300]], _vKD[Q[360020]] = ebxqgw[Q[360199]][Q[360300]]), ebxqgw[Q[360199]][Q[360079]] && (_vKD[Q[360019]] = ebxqgw[Q[360199]][Q[360079]]), console[Q[360001]](Q[360302] + _vKD[Q[360019]] + Q[360303] + _vKD[Q[360246]]), window['_vKD$'] = !![], window['_vD$KO'](), window['_vDKO$']();
}, window[Q[360304]], window['_v$KDO'] = function () {
  sendApi(_vKD[Q[360158]], Q[360305], { 'game_pkg': _vKD[Q[360021]] }, this['_v$DOK'][Q[360233]](this), _v$DK, _vDO);
}, window['_v$DOK'] = function (qel) {
  if (qel[Q[360200]] === Q[360271] && qel[Q[360199]]) {
    window[Q[360304]] = qel[Q[360199]];for (var zleub in qel[Q[360199]]) {
      _vKD[zleub] = qel[Q[360199]][zleub];
    }
  } else console[Q[360001]](Q[360306] + qel[Q[360200]]);window['_v$K'] = !![], window['_vDKO$']();
}, window[Q[360307]] = function (v750p, weg, z8lu, eqwb, $os4n, zyhlu6, lzbu86, ckdm07, wbgqe8) {
  $os4n = String($os4n);var hty_12 = lzbu86,
      ck0m57 = ckdm07;_vKD[Q[360153]][$os4n] = { 'productid': $os4n, 'productname': hty_12, 'productdesc': ck0m57, 'roleid': v750p, 'rolename': weg, 'rolelevel': z8lu, 'price': zyhlu6, 'callback': wbgqe8 }, sendApi(_vKD[Q[360162]], Q[360308], { 'game_pkg': _vKD[Q[360021]], 'server_id': _vKD[Q[360022]][Q[360023]], 'server_name': _vKD[Q[360022]][Q[360286]], 'level': z8lu, 'uid': _vKD[Q[360018]], 'role_id': v750p, 'role_name': weg, 'product_id': $os4n, 'product_name': hty_12, 'product_desc': ck0m57, 'money': zyhlu6, 'partner_id': _vKD[Q[360166]] }, toPayCallBack, _v$DK, _vDO);
}, window[Q[360309]] = function (vqxpwg) {
  if (vqxpwg) {
    if (vqxpwg[Q[360310]] === 0xc8 || vqxpwg[Q[360200]] == Q[360271]) {
      var f4 = _vKD[Q[360153]][String(vqxpwg[Q[360311]])];if (f4[Q[360312]]) f4[Q[360312]](vqxpwg[Q[360311]], vqxpwg[Q[360313]], -0x1);vqxpgvw[Q[360314]]({ 'cpbill': vqxpwg[Q[360313]], 'productid': vqxpwg[Q[360311]], 'productname': f4[Q[360315]], 'productdesc': f4[Q[360316]], 'serverid': _vKD[Q[360022]][Q[360023]], 'servername': _vKD[Q[360022]][Q[360286]], 'roleid': f4[Q[360317]], 'rolename': f4[Q[360318]], 'rolelevel': f4[Q[360319]], 'price': f4[Q[360320]], 'extension': JSON[Q[360026]]({ 'cp_order_id': vqxpwg[Q[360313]] }) }, function (bul8ze, m0kcd7) {
        f4[Q[360312]] && bul8ze == 0x0 && f4[Q[360312]](vqxpwg[Q[360311]], vqxpwg[Q[360313]], bul8ze);console[Q[360001]](JSON[Q[360026]]({ 'type': Q[360321], 'status': bul8ze, 'data': vqxpwg, 'role_name': f4[Q[360318]] }));if (bul8ze === 0x0) {} else {
          if (bul8ze === 0x1) {} else {
            if (bul8ze === 0x2) {}
          }
        }
      });
    } else alert(vqxpwg[Q[360001]]);
  }
}, window['_v$DKO'] = function () {}, window['_vO$D'] = function (bulz8, h_y6z1, amcd, pgqxw, wqexb) {
  vqxpgvw[Q[360322]](_vKD[Q[360022]][Q[360023]], _vKD[Q[360022]][Q[360286]] || _vKD[Q[360022]][Q[360023]], bulz8, h_y6z1, amcd), sendApi(_vKD[Q[360158]], Q[360323], { 'game_pkg': _vKD[Q[360021]], 'server_id': _vKD[Q[360022]][Q[360023]], 'role_id': bulz8, 'uid': _vKD[Q[360018]], 'role_name': h_y6z1, 'role_type': pgqxw, 'level': amcd });
}, window['_vOD$'] = function (m0caj, bqewg8, vck57, v75gpx, dcm07, v7c5, hz61ly, gwpx5v, yuz, e8wgq) {
  _vKD[Q[360015]] = m0caj, _vKD[Q[360016]] = bqewg8, _vKD[Q[360017]] = vck57, vqxpgvw[Q[360324]](_vKD[Q[360022]][Q[360023]], _vKD[Q[360022]][Q[360286]] || _vKD[Q[360022]][Q[360023]], m0caj, bqewg8, vck57), sendApi(_vKD[Q[360158]], Q[360325], { 'game_pkg': _vKD[Q[360021]], 'server_id': _vKD[Q[360022]][Q[360023]], 'role_id': m0caj, 'uid': _vKD[Q[360018]], 'role_name': bqewg8, 'role_type': v75gpx, 'level': vck57, 'evolution': dcm07 });
}, window['_v$OD'] = function (l1yh, $sif, z_1hy, y1h2, z8blu6, iosf4$, cdmk70, t2_h1y, ois3$4, hn21t) {
  _vKD[Q[360015]] = l1yh, _vKD[Q[360016]] = $sif, _vKD[Q[360017]] = z_1hy, vqxpgvw[Q[360326]](_vKD[Q[360022]][Q[360023]], _vKD[Q[360022]][Q[360286]] || _vKD[Q[360022]][Q[360023]], l1yh, $sif, z_1hy), sendApi(_vKD[Q[360158]], Q[360325], { 'game_pkg': _vKD[Q[360021]], 'server_id': _vKD[Q[360022]][Q[360023]], 'role_id': l1yh, 'uid': _vKD[Q[360018]], 'role_name': $sif, 'role_type': y1h2, 'level': z_1hy, 'evolution': z8blu6 });
}, window['_v$DO'] = function (gv5px7) {}, window['_vO$'] = function (kmc7d) {
  vqxpgvw[Q[360327]](Q[360327], function (cadm) {
    kmc7d && kmc7d(cadm);
  });
}, window[Q[360328]] = function () {
  vqxpgvw[Q[360328]]();
}, window[Q[360329]] = function () {
  vqxpgvw[Q[360330]]();
}, window[Q[360331]] = function (zbu6l, sno3, xqpgew, hn21t_, sn$o34, siof4$, io43s, ze8lbu) {
  ze8lbu = ze8lbu || _vKD[Q[360022]][Q[360023]], sendApi(_vKD[Q[360158]], Q[360332], { 'phone': zbu6l, 'role_id': sno3, 'uid': _vKD[Q[360018]], 'game_pkg': _vKD[Q[360021]], 'partner_id': _vKD[Q[360166]], 'server_id': ze8lbu }, io43s);
}, window[Q[360135]] = function (dmjk0c) {
  window['_vDO$'] = dmjk0c, window['_vDO$'] && window['_v$O'] && (console[Q[360001]](Q[360136] + window['_v$O'][Q[360137]]), window['_vDO$'](window['_v$O']), window['_v$O'] = null);
}, window['_vD$O'] = function (gpxvq, kjdmc, $o4s3, vc750) {
  window[Q[360333]](Q[360334], { 'game_pkg': window['_vKD'][Q[360021]], 'role_id': kjdmc, 'server_id': $o4s3 }, vc750);
}, window['_vKO$D'] = function (ri$s9f, lz8bu6) {
  function eb8uz(z1_h6) {
    var b8qlue = [],
        e8gbwq = [],
        y_h6z1 = window[Q[360006]][Q[360335]];for (var vw5xg in y_h6z1) {
      var i4sfo = Number(vw5xg);(!ri$s9f || !ri$s9f[Q[360009]] || ri$s9f[Q[360107]](i4sfo) != -0x1) && (e8gbwq[Q[360038]](y_h6z1[vw5xg]), b8qlue[Q[360038]]([i4sfo, 0x3]));
    }window['_v6$DOK'](window[Q[360039]], Q[360336]) >= 0x0 ? (console[Q[360041]](Q[360337]), vqxpgvw[Q[360338]] && vqxpgvw[Q[360338]](e8gbwq, function (vpgw5) {
      console[Q[360041]](Q[360339]), console[Q[360041]](vpgw5);if (vpgw5 && vpgw5[Q[360058]] == Q[360340]) for (var v05kc7 in y_h6z1) {
        if (vpgw5[y_h6z1[v05kc7]] == Q[360341]) {
          var l6zy = Number(v05kc7);for (var _43t2n = 0x0; _43t2n < b8qlue[Q[360009]]; _43t2n++) {
            if (b8qlue[_43t2n][0x0] == l6zy) {
              b8qlue[_43t2n][0x1] = 0x1;break;
            }
          }
        }
      }window['_v6$DOK'](window[Q[360039]], Q[360342]) >= 0x0 ? wx[Q[360343]]({ 'withSubscriptions': !![], 'success': function ($no3s) {
          var _nt2h = $no3s[Q[360344]][Q[360345]];if (_nt2h) {
            console[Q[360041]](Q[360346]), console[Q[360041]](_nt2h);for (var blq8u in y_h6z1) {
              if (_nt2h[y_h6z1[blq8u]] == Q[360341]) {
                var fsr9$i = Number(blq8u);for (var daj0mc = 0x0; daj0mc < b8qlue[Q[360009]]; daj0mc++) {
                  if (b8qlue[daj0mc][0x0] == fsr9$i) {
                    b8qlue[daj0mc][0x1] = 0x2;break;
                  }
                }
              }
            }console[Q[360041]](b8qlue), lz8bu6 && lz8bu6(b8qlue);
          } else console[Q[360041]](Q[360347]), console[Q[360041]]($no3s), console[Q[360041]](b8qlue), lz8bu6 && lz8bu6(b8qlue);
        }, 'fail': function () {
          console[Q[360041]](Q[360348]), console[Q[360041]](b8qlue), lz8bu6 && lz8bu6(b8qlue);
        } }) : (console[Q[360041]](Q[360349] + window[Q[360039]]), console[Q[360041]](b8qlue), lz8bu6 && lz8bu6(b8qlue));
    })) : (console[Q[360041]](Q[360350] + window[Q[360039]]), console[Q[360041]](b8qlue), lz8bu6 && lz8bu6(b8qlue)), wx[Q[360351]](eb8uz);
  }wx[Q[360352]](eb8uz);
}, window['_vKOD$'] = { 'isSuccess': ![], 'level': Q[360353], 'isCharging': ![] }, window['_vK$OD'] = function (xqgvpw) {
  wx[Q[360123]]({ 'success': function (p7gx5) {
      var kd70cm = window['_vKOD$'];kd70cm[Q[360354]] = !![], kd70cm[Q[360125]] = Number(p7gx5[Q[360125]])[Q[360355]](0x0), kd70cm[Q[360127]] = p7gx5[Q[360127]], xqgvpw && xqgvpw(kd70cm[Q[360354]], kd70cm[Q[360125]], kd70cm[Q[360127]]);
    }, 'fail': function (qvgxp) {
      console[Q[360041]](Q[360356], qvgxp[Q[360058]]);var e8ubql = window['_vKOD$'];xqgvpw && xqgvpw(e8ubql[Q[360354]], e8ubql[Q[360125]], e8ubql[Q[360127]]);
    } });
}, window[Q[360333]] = function (_t1hn2, n24_t, $n34os, y1h_z6, c7k0m, bzlue, s$oi9f, m0adc) {
  if (y1h_z6 == undefined) y1h_z6 = 0x1;wx[Q[360218]]({ 'url': _t1hn2, 'method': s$oi9f || Q[360357], 'responseType': Q[360358], 'data': n24_t, 'header': { 'content-type': m0adc || Q[360220] }, 'success': function (dkcm0j) {
      DEBUG && console[Q[360041]](Q[360359], _t1hn2, info, dkcm0j);if (dkcm0j && dkcm0j[Q[360360]] == 0xc8) {
        var n34o$ = dkcm0j[Q[360199]];!bzlue || bzlue(n34o$) ? $n34os && $n34os(n34o$) : window[Q[360361]](_t1hn2, n24_t, $n34os, y1h_z6, c7k0m, bzlue, dkcm0j);
      } else window[Q[360361]](_t1hn2, n24_t, $n34os, y1h_z6, c7k0m, bzlue, dkcm0j);
    }, 'fail': function (os34$) {
      DEBUG && console[Q[360041]](Q[360362], _t1hn2, info, os34$), window[Q[360361]](_t1hn2, n24_t, $n34os, y1h_z6, c7k0m, bzlue, os34$);
    }, 'complete': function () {} });
}, window[Q[360361]] = function (k50vc, yl61hz, $s4i3, x75vk, bw8qu, _2t3, wp5vxg) {
  x75vk - 0x1 > 0x0 ? setTimeout(function () {
    window[Q[360333]](k50vc, yl61hz, $s4i3, x75vk - 0x1, bw8qu, _2t3);
  }, 0x3e8) : bw8qu && bw8qu(JSON[Q[360026]]({ 'url': k50vc, 'response': wp5vxg }));
}, window[Q[360363]] = function (s$9oif, wpqexg, vxpg5, h2_yt1, o4$si, ubweq8, zy8l6u) {
  !vxpg5 && (vxpg5 = {});var ot23n4 = Math[Q[360364]](Date[Q[360141]]() / 0x3e8);vxpg5[Q[360278]] = ot23n4, vxpg5[Q[360365]] = wpqexg;var zl8ebu = Object[Q[360366]](vxpg5)[Q[360367]](),
      quwb8 = '',
      no3t$4 = '';for (var gv57x = 0x0; gv57x < zl8ebu[Q[360009]]; gv57x++) {
    quwb8 = quwb8 + (gv57x == 0x0 ? '' : '&') + zl8ebu[gv57x] + vxpg5[zl8ebu[gv57x]], no3t$4 = no3t$4 + (gv57x == 0x0 ? '' : '&') + zl8ebu[gv57x] + '=' + encodeURIComponent(vxpg5[zl8ebu[gv57x]]);
  }quwb8 = quwb8 + _vKD[Q[360164]];var fr$si = Q[360368] + md5(quwb8);send(s$9oif + '?' + no3t$4 + (no3t$4 == '' ? '' : '&') + fr$si, null, h2_yt1, o4$si, ubweq8, zy8l6u || function (cmk057) {
    return cmk057[Q[360200]] == Q[360271];
  }, null, Q[360369]);
}, window['_vK$DO'] = function (u6yhl, vpxgw) {
  var i$fos9 = 0x0;_vKD[Q[360022]] && (i$fos9 = _vKD[Q[360022]][Q[360023]]), sendApi(_vKD[Q[360160]], Q[360370], { 'partnerId': _vKD[Q[360166]], 'gamePkg': _vKD[Q[360021]], 'logTime': Math[Q[360364]](Date[Q[360141]]() / 0x3e8), 'platformUid': _vKD[Q[360274]], 'type': u6yhl, 'serverId': i$fos9 }, null, 0x2, null, function () {
    return !![];
  });
}, window['_vKDO$'] = function (y_t12) {
  sendApi(_vKD[Q[360158]], Q[360371], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, _vKD$O, _v$DK, _vDO);
}, window['_vKD$O'] = function (kjdc) {
  if (kjdc[Q[360200]] === Q[360271] && kjdc[Q[360199]]) {
    kjdc[Q[360199]][Q[360372]]({ 'id': -0x2, 'name': Q[360373] }), kjdc[Q[360199]][Q[360372]]({ 'id': -0x1, 'name': Q[360374] }), _vKD[Q[360375]] = kjdc[Q[360199]];if (window[Q[360376]]) window[Q[360376]][Q[360377]]();
  } else _vKD[Q[360378]] = ![], window['_vO$KD'](Q[360379] + kjdc[Q[360200]]);
}, window['_vO$K'] = function (n$o3) {
  sendApi(_vKD[Q[360158]], Q[360380], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, _vOK$, _v$DK, _vDO);
}, window['_vOK$'] = function (t34$) {
  _vKD[Q[360381]] = ![];if (t34$[Q[360200]] === Q[360271] && t34$[Q[360199]]) {
    for (var jca0m = 0x0; jca0m < t34$[Q[360199]][Q[360009]]; jca0m++) {
      t34$[Q[360199]][jca0m][Q[360290]] = _vK$O(t34$[Q[360199]][jca0m]);
    }_vKD[Q[360169]][-0x1] = window[Q[360382]](t34$[Q[360199]]), window[Q[360376]][Q[360383]](-0x1);
  } else window['_vO$KD'](Q[360384] + t34$[Q[360200]]);
}, window[Q[360385]] = function (i$3) {
  sendApi(_vKD[Q[360158]], Q[360380], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, i$3, _v$DK, _vDO);
}, window['_v$OK'] = function (t34$on, so4$3) {
  sendApi(_vKD[Q[360158]], Q[360386], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]], 'server_group_id': so4$3 }, _v$KO, _v$DK, _vDO);
}, window['_v$KO'] = function (md0jck) {
  _vKD[Q[360381]] = ![];if (md0jck[Q[360200]] === Q[360271] && md0jck[Q[360199]] && md0jck[Q[360199]][Q[360199]]) {
    var gewpq = md0jck[Q[360199]][Q[360387]],
        h1y6_2 = [];for (var not3$ = 0x0; not3$ < md0jck[Q[360199]][Q[360199]][Q[360009]]; not3$++) {
      md0jck[Q[360199]][Q[360199]][not3$][Q[360290]] = _vK$O(md0jck[Q[360199]][Q[360199]][not3$]), (h1y6_2[Q[360009]] == 0x0 || md0jck[Q[360199]][Q[360199]][not3$][Q[360290]] != 0x0) && (h1y6_2[h1y6_2[Q[360009]]] = md0jck[Q[360199]][Q[360199]][not3$]);
    }_vKD[Q[360169]][gewpq] = window[Q[360382]](h1y6_2), window[Q[360376]][Q[360383]](gewpq);
  } else window['_vO$KD'](Q[360388] + md0jck[Q[360200]]);
}, window['_v6$DK'] = function ($sfri) {
  sendApi(_vKD[Q[360158]], Q[360389], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, reqServerRecommendCallBack, _v$DK, _vDO);
}, window[Q[360390]] = function (xegpwq) {
  _vKD[Q[360381]] = ![];if (xegpwq[Q[360200]] === Q[360271] && xegpwq[Q[360199]]) {
    for (var y216h_ = 0x0; y216h_ < xegpwq[Q[360199]][Q[360009]]; y216h_++) {
      xegpwq[Q[360199]][y216h_][Q[360290]] = _vK$O(xegpwq[Q[360199]][y216h_]);
    }_vKD[Q[360169]][-0x2] = window[Q[360382]](xegpwq[Q[360199]]), window[Q[360376]][Q[360383]](-0x2);
  } else alert(Q[360391] + xegpwq[Q[360200]]);
}, window[Q[360382]] = function (hzyl6) {
  if (!hzyl6 && hzyl6[Q[360009]] <= 0x0) return hzyl6;for (let $tn4o3 = 0x0; $tn4o3 < hzyl6[Q[360009]]; $tn4o3++) {
    hzyl6[$tn4o3][Q[360392]] && hzyl6[$tn4o3][Q[360392]] == 0x1 && (hzyl6[$tn4o3][Q[360286]] += Q[360393]);
  }return hzyl6;
}, window['_vKO$'] = function (i9os$f, mkc570) {
  i9os$f = i9os$f || _vKD[Q[360022]][Q[360023]], sendApi(_vKD[Q[360158]], Q[360394], { 'type': '4', 'game_pkg': _vKD[Q[360021]], 'server_id': i9os$f }, mkc570);
}, window[Q[360395]] = function (o$s43i, ebwuq, n_12h, h2_y61) {
  n_12h = n_12h || _vKD[Q[360022]][Q[360023]], sendApi(_vKD[Q[360158]], Q[360396], { 'type': o$s43i, 'game_pkg': ebwuq, 'server_id': n_12h }, h2_y61);
}, window['_vK$O'] = function (yth2_1) {
  if (yth2_1) {
    if (yth2_1[Q[360290]] == 0x1) {
      if (yth2_1[Q[360397]] == 0x1) return 0x2;else return 0x1;
    } else return yth2_1[Q[360290]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_vDO$K'] = function (e8bz, k5vp7x) {
  _vKD[Q[360398]] = { 'step': e8bz, 'server_id': k5vp7x };var m0k57 = this;_vOK$D({ 'title': Q[360399] }), sendApi(_vKD[Q[360158]], Q[360400], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'game_pkg': _vKD[Q[360021]], 'server_id': k5vp7x, 'platform': _vKD[Q[360083]], 'platform_uid': _vKD[Q[360274]], 'check_login_time': _vKD[Q[360277]], 'check_login_sign': _vKD[Q[360275]], 'version_name': _vKD[Q[360246]] }, _vDOK$, _v$DK, _vDO, function (dk0jcm) {
    return dk0jcm[Q[360200]] == Q[360271] || dk0jcm[Q[360001]] == Q[360401] || dk0jcm[Q[360001]] == Q[360402];
  });
}, window['_vDOK$'] = function (wuqe8) {
  var zlu8y6 = this;if (wuqe8[Q[360200]] === Q[360271] && wuqe8[Q[360199]]) {
    var h_12nt = _vKD[Q[360022]];h_12nt[Q[360403]] = _vKD[Q[360170]], h_12nt[Q[360276]] = String(wuqe8[Q[360199]][Q[360404]]), h_12nt[Q[360176]] = parseInt(wuqe8[Q[360199]][Q[360278]]);if (wuqe8[Q[360199]][Q[360405]]) h_12nt[Q[360405]] = parseInt(wuqe8[Q[360199]][Q[360405]]);else h_12nt[Q[360405]] = parseInt(wuqe8[Q[360199]][Q[360023]]);h_12nt[Q[360406]] = 0x0, h_12nt[Q[360020]] = _vKD[Q[360301]], h_12nt[Q[360407]] = wuqe8[Q[360199]]['cdn_version'], h_12nt[Q[360408]] = wuqe8[Q[360199]][Q[360408]], console[Q[360041]](Q[360409] + JSON[Q[360026]](h_12nt[Q[360408]])), _vKD[Q[360284]] == 0x1 && h_12nt[Q[360408]] && h_12nt[Q[360408]][Q[360410]] == 0x1 && (_vKD[Q[360411]] = 0x1, window[Q[360034]][Q[360035]]['_v6DK']()), _vD$OK();
  } else _vKD[Q[360398]][Q[360412]] >= 0x3 ? (_vDO(JSON[Q[360026]](wuqe8)), window['_vO$KD'](Q[360413] + wuqe8[Q[360200]])) : sendApi(_vKD[Q[360158]], Q[360258], { 'platform': _vKD[Q[360156]], 'partner_id': _vKD[Q[360166]], 'token': _vKD[Q[360256]], 'game_pkg': _vKD[Q[360021]], 'deviceId': _vKD[Q[360167]], 'scene': Q[360259] + _vKD[Q[360168]] }, function (s$rf) {
    if (!s$rf || s$rf[Q[360200]] != Q[360271]) {
      window['_vO$KD'](Q[360272] + s$rf && s$rf[Q[360200]]);return;
    }_vKD[Q[360275]] = String(s$rf[Q[360276]]), _vKD[Q[360277]] = String(s$rf[Q[360278]]), setTimeout(function () {
      _vDO$K(_vKD[Q[360398]][Q[360412]] + 0x1, _vKD[Q[360398]][Q[360023]]);
    }, 0x5dc);
  }, _v$DK, _vDO, function (v05kc) {
    return v05kc[Q[360200]] == Q[360271] || v05kc[Q[360200]] == Q[360414];
  });
}, window['_vD$OK'] = function () {
  ServerLoading[Q[360035]][Q[360293]](_vKD[Q[360284]]), window['_v$D'] = !![], window['_vDKO$']();
}, window['_vD$KO'] = function () {
  if (window['_vD$'] && window['_vK$D'] && window[Q[360182]] && window[Q[360183]] && window['_vKD$'] && window['_vK$']) {
    if (!window[Q[360415]][Q[360035]]) {
      console[Q[360041]](Q[360416] + window[Q[360415]][Q[360035]]);var _21hyt = wx[Q[360417]](),
          nt43 = _21hyt[Q[360137]] ? _21hyt[Q[360137]] : 0x0,
          i4os3$ = { 'cdn': window['_vKD'][Q[360020]], 'spareCdn': window['_vKD'][Q[360244]], 'newRegister': window['_vKD'][Q[360284]], 'wxPC': window['_vKD'][Q[360112]], 'wxIOS': window['_vKD'][Q[360106]], 'wxAndroid': window['_vKD'][Q[360109]], 'wxParam': { 'limitLoad': window['_vKD']['_v6O$DK'], 'benchmarkLevel': window['_vKD']['_v6OK$D'], 'wxFrom': window[Q[360006]][Q[360251]] == Q[360418] ? 0x1 : 0x0, 'wxSDKVersion': window[Q[360039]] }, 'configType': window['_vKD'][Q[360177]], 'exposeType': window['_vKD'][Q[360179]], 'scene': nt43 };new window[Q[360415]](i4os3$, window['_vKD'][Q[360019]], window['_v6O$KD']);
    }
  }
}, window['_vDKO$'] = function () {
  if (window['_vD$'] && window['_vK$D'] && window[Q[360182]] && window[Q[360183]] && window['_vKD$'] && window['_vK$'] && window['_v$D'] && window['_v$K']) {
    _vOKD$();if (!_vD$K) {
      _vD$K = !![];if (!window[Q[360415]][Q[360035]]) window['_vD$KO']();var t43on2 = 0x0,
          _21y = wx[Q[360419]]();_21y && (window['_vKD'][Q[360111]] && (t43on2 = _21y[Q[360101]]), console[Q[360001]](Q[360420] + _21y[Q[360101]] + Q[360421] + _21y[Q[360102]] + Q[360422] + _21y[Q[360103]] + Q[360423] + _21y[Q[360104]] + Q[360424] + _21y[Q[360425]] + Q[360426] + _21y[Q[360427]]));var zulh6y = {};for (const gqpxvw in _vKD[Q[360022]]) {
        zulh6y[gqpxvw] = _vKD[Q[360022]][gqpxvw];
      }var _21 = { 'channel': window['_vKD'][Q[360171]], 'account': window['_vKD'][Q[360018]], 'userId': window['_vKD'][Q[360273]], 'cdn': window['_vKD'][Q[360020]], 'data': window['_vKD'][Q[360199]], 'package': window['_vKD'][Q[360154]], 'newRegister': window['_vKD'][Q[360284]], 'pkgName': window['_vKD'][Q[360021]], 'partnerId': window['_vKD'][Q[360166]], 'platform_uid': window['_vKD'][Q[360274]], 'deviceId': window['_vKD'][Q[360167]], 'selectedServer': zulh6y, 'configType': window['_vKD'][Q[360177]], 'exposeType': window['_vKD'][Q[360179]], 'debugUsers': window['_vKD'][Q[360174]], 'wxMenuTop': t43on2, 'wxShield': window['_vKD'][Q[360181]] };if (window[Q[360304]]) for (var _12y in window[Q[360304]]) {
        _21[_12y] = window[Q[360304]][_12y];
      }window[Q[360415]][Q[360035]]['_vDK6'](_21);
    }
  } else console[Q[360001]](Q[360428] + window['_vD$'] + Q[360429] + window['_vK$D'] + Q[360430] + window[Q[360182]] + Q[360431] + window[Q[360183]] + Q[360432] + window['_vKD$'] + Q[360433] + window['_vK$'] + Q[360434] + window['_v$D'] + Q[360435] + window['_v$K']);
};