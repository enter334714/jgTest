var Q = wx.$v;
import 'vvMAIv.js';