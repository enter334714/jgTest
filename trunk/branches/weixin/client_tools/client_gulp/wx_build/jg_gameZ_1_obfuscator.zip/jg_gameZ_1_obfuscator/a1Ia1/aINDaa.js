var C = wx.$a;
import abnxp28 from '../aaabasdk/a5sdka.js';window[C[460537]] = { 'wxVersion': window[C[460005]][C[460006]] }, window[C[460538]] = ![], window['a1M4'] = 0x1, window[C[460539]] = 0x1, window['a184M'] = !![], window[C[460540]] = !![], window['a1CJ84M'] = '', window['a14M'] = { 'base_cdn': C[460541], 'cdn': C[460541] }, a14M[C[460542]] = {}, a14M[C[460543]] = '0', a14M[C[460075]] = window[C[460537]][C[460325]], a14M[C[460110]] = '', a14M['os'] = '1', a14M[C[460544]] = C[460545], a14M[C[460546]] = C[460547], a14M[C[460548]] = C[460549], a14M[C[460550]] = C[460551], a14M[C[460552]] = C[460553], a14M[C[460554]] = '1', a14M[C[460018]] = '', a14M[C[460555]] = '', a14M[C[460556]] = 0x0, a14M[C[460416]] = {}, a14M[C[460557]] = parseInt(a14M[C[460554]]), a14M[C[460558]] = a14M[C[460554]], a14M[C[460019]] = {}, a14M['a1J4'] = C[460559], a14M[C[460560]] = ![], a14M[C[460561]] = C[460562], a14M[C[460563]] = Date[C[460137]](), a14M[C[460564]] = C[460565], a14M[C[460566]] = '_a', a14M[C[460311]] = 0x2, a14M[C[460016]] = 0x7c1, a14M[C[460325]] = window[C[460537]][C[460325]], a14M[C[460567]] = ![], a14M[C[460102]] = ![], a14M[C[460105]] = ![], a14M[C[460108]] = ![], window['a18M4'] = 0x5, window['a18M'] = ![], window['a1M8'] = ![], window['a148M'] = ![], window[C[460488]] = ![], window[C[460491]] = ![], window['a14M8'] = ![], window['a184'] = ![], window['a148'] = ![], window['a1M84'] = ![], window[C[460568]] = function (ithxb) {
  console[C[460038]](C[460568], ithxb), wx[C[460569]]({}), wx[C[460045]]({ 'title': C[460067], 'content': ithxb, 'success'(rczs_) {
      if (rczs_[C[460570]]) console[C[460038]](C[460571]);else rczs_[C[460572]] && console[C[460038]](C[460573]);
    } });
}, window['a1J84M'] = function (cjz) {
  console[C[460038]](C[460574], cjz), a1J4M8(), wx[C[460045]]({ 'title': C[460067], 'content': cjz, 'confirmText': C[460575], 'cancelText': C[460576], 'success'(ob82x) {
      if (ob82x[C[460570]]) window['a14J']();else ob82x[C[460572]] && (console[C[460038]](C[460577]), wx[C[460578]]({}));
    } });
}, window[C[460579]] = function (xh5oti) {
  console[C[460038]](C[460579], xh5oti), wx[C[460045]]({ 'title': C[460067], 'content': xh5oti, 'confirmText': C[460580], 'showCancel': ![], 'complete'(nepb2) {
      console[C[460038]](C[460577]), wx[C[460578]]({});
    } });
}, window['a1J8M4'] = ![], window['a1J48M'] = function (vcrs$) {
  window['a1J8M4'] = !![], wx[C[460581]](vcrs$);
}, window['a1J4M8'] = function () {
  window['a1J8M4'] && (window['a1J8M4'] = ![], wx[C[460569]]({}));
}, window['a1JM84'] = function (ixoth) {
  window[C[460031]][C[460032]]['a1JM84'](ixoth);
}, window[C[460582]] = function (j_mz94, tohibx) {
  abnxp28[C[460582]](j_mz94, function (tbhpox) {
    tbhpox && tbhpox[C[460425]] ? tbhpox[C[460425]][C[460424]] == 0x1 ? tohibx(!![]) : (tohibx(![]), console[C[460000]](C[460583] + tbhpox[C[460425]][C[460584]])) : console[C[460038]](C[460582], tbhpox);
  });
}, window['a1JM48'] = function (lsv) {
  console[C[460038]](C[460585], lsv);
}, window['a1J4M'] = function (yfl0k6) {}, window['a1JM4'] = function (fy06l, x2h, jm9zd4) {}, window['a1JM'] = function (yf6k7) {
  console[C[460038]](C[460586], yf6k7), window[C[460031]][C[460032]][C[460315]](), window[C[460031]][C[460032]][C[460316]](), window[C[460031]][C[460032]][C[460329]]();
}, window['a1MJ'] = function (_9rzsc) {
  window['a1J84M'](C[460587]);var e3p82n = { 'id': window['a14M'][C[460012]], 'role': window['a14M'][C[460013]], 'level': window['a14M'][C[460014]], 'account': window['a14M'][C[460015]], 'version': window['a14M'][C[460016]], 'cdn': window['a14M'][C[460017]], 'pkgName': window['a14M'][C[460018]], 'gamever': window[C[460005]][C[460006]], 'serverid': window['a14M'][C[460019]] ? window['a14M'][C[460019]][C[460020]] : 0x0, 'systemInfo': window[C[460021]], 'error': C[460588], 'stack': _9rzsc ? _9rzsc : C[460587] },
      hxti5o = JSON[C[460023]](e3p82n);console[C[460024]](C[460589] + hxti5o), window['a1J4'](hxti5o);
}, window['a14JM'] = function (hidt5) {
  var s9crq_ = JSON[C[460590]](hidt5);s9crq_[C[460591]] = window[C[460005]][C[460006]], s9crq_[C[460592]] = window['a14M'][C[460019]] ? window['a14M'][C[460019]][C[460020]] : 0x0, s9crq_[C[460021]] = window[C[460021]];var f0y6k7 = JSON[C[460023]](s9crq_);console[C[460024]](C[460593] + f0y6k7), window['a1J4'](f0y6k7);
}, window['a14MJ'] = function ($0vrql, fyk60) {
  var y$lf0 = { 'id': window['a14M'][C[460012]], 'role': window['a14M'][C[460013]], 'level': window['a14M'][C[460014]], 'account': window['a14M'][C[460015]], 'version': window['a14M'][C[460016]], 'cdn': window['a14M'][C[460017]], 'pkgName': window['a14M'][C[460018]], 'gamever': window[C[460005]][C[460006]], 'serverid': window['a14M'][C[460019]] ? window['a14M'][C[460019]][C[460020]] : 0x0, 'systemInfo': window[C[460021]], 'error': $0vrql, 'stack': fyk60 },
      p8xo2b = JSON[C[460023]](y$lf0);console[C[460138]](C[460594] + p8xo2b), window['a1J4'](p8xo2b);
}, window['a1J4'] = function (ihobxt) {
  if (window['a14M'][C[460111]] == C[460595]) return;var c$vsrq = a14M['a1J4'] + C[460596] + a14M[C[460015]];wx[C[460597]]({ 'url': c$vsrq, 'method': C[460598], 'data': ihobxt, 'header': { 'content-type': C[460599], 'cache-control': C[460600] }, 'success': function (_cz9m) {
      DEBUG && console[C[460038]](C[460601], c$vsrq, ihobxt, _cz9m);
    }, 'fail': function (m4j9dz) {
      DEBUG && console[C[460038]](C[460601], c$vsrq, ihobxt, m4j9dz);
    }, 'complete': function () {} });
}, window[C[460602]] = function () {
  function _mz9s() {
    return ((0x1 + Math[C[460318]]()) * 0x10000 | 0x0)[C[460603]](0x10)[C[460604]](0x1);
  }return _mz9s() + _mz9s() + '-' + _mz9s() + '-' + _mz9s() + '-' + _mz9s() + '+' + _mz9s() + _mz9s() + _mz9s();
}, window['a14J'] = function () {
  console[C[460038]](C[460605]);var tpxbh = abnxp28[C[460606]]();a14M[C[460558]] = tpxbh[C[460607]], a14M[C[460557]] = tpxbh[C[460607]], a14M[C[460554]] = tpxbh[C[460607]], a14M[C[460018]] = tpxbh[C[460608]];var y6k0l = { 'game_ver': a14M[C[460075]] };a14M[C[460555]] = this[C[460602]](), a1J48M({ 'title': C[460609] }), abnxp28[C[460453]](y6k0l, this['a1MJ4'][C[460322]](this));
}, window['a1MJ4'] = function (pe28) {
  var lk0$v = pe28[C[460610]];console[C[460038]](C[460611] + lk0$v + C[460612] + (lk0$v == 0x1) + C[460613] + pe28[C[460006]] + C[460614] + window[C[460537]][C[460325]]);if (!pe28[C[460006]] || window['a1C8MJ4'](window[C[460537]][C[460325]], pe28[C[460006]]) < 0x0) console[C[460038]](C[460615]), a14M[C[460546]] = C[460616], a14M[C[460548]] = C[460617], a14M[C[460550]] = C[460618], a14M[C[460017]] = C[460619], a14M[C[460620]] = C[460621], a14M[C[460622]] = 'jy', a14M[C[460567]] = ![];else window['a1C8MJ4'](window[C[460537]][C[460325]], pe28[C[460006]]) == 0x0 ? (console[C[460038]](C[460623]), a14M[C[460546]] = C[460547], a14M[C[460548]] = C[460549], a14M[C[460550]] = C[460551], a14M[C[460017]] = C[460624], a14M[C[460620]] = C[460621], a14M[C[460622]] = C[460625], a14M[C[460567]] = !![]) : (console[C[460038]](C[460626]), a14M[C[460546]] = C[460547], a14M[C[460548]] = C[460549], a14M[C[460550]] = C[460551], a14M[C[460017]] = C[460624], a14M[C[460620]] = C[460621], a14M[C[460622]] = C[460625], a14M[C[460567]] = ![]);a14M[C[460556]] = config[C[460627]] ? config[C[460627]] : 0x0, this['a184JM'](), this['a184MJ'](), window[C[460628]] = 0x5, a1J48M({ 'title': C[460629] }), abnxp28[C[460630]](this['a1M4J'][C[460322]](this));
}, window[C[460628]] = 0x5, window['a1M4J'] = function ($f0klv, q$vlr0) {
  if ($f0klv == 0x0 && q$vlr0 && q$vlr0[C[460631]]) {
    a14M[C[460632]] = q$vlr0[C[460631]];var _z49j = this;a1J48M({ 'title': C[460633] }), sendApi(a14M[C[460546]], C[460634], { 'platform': a14M[C[460544]], 'partner_id': a14M[C[460554]], 'token': q$vlr0[C[460631]], 'game_pkg': a14M[C[460018]], 'deviceId': a14M[C[460555]], 'scene': C[460635] + a14M[C[460556]] }, this['a18J4M'][C[460322]](this), a18M4, a1MJ);
  } else q$vlr0 && q$vlr0[C[460054]] && window[C[460628]] > 0x0 && (q$vlr0[C[460054]][C[460103]](C[460636]) != -0x1 || q$vlr0[C[460054]][C[460103]](C[460637]) != -0x1 || q$vlr0[C[460054]][C[460103]](C[460638]) != -0x1 || q$vlr0[C[460054]][C[460103]](C[460639]) != -0x1 || q$vlr0[C[460054]][C[460103]](C[460640]) != -0x1 || q$vlr0[C[460054]][C[460103]](C[460641]) != -0x1) ? (window[C[460628]]--, abnxp28[C[460630]](this['a1M4J'][C[460322]](this))) : (window['a14MJ'](C[460642], JSON[C[460023]]({ 'status': $f0klv, 'data': q$vlr0 })), window['a1J84M'](C[460643] + (q$vlr0 && q$vlr0[C[460054]] ? '，' + q$vlr0[C[460054]] : '')));
}, window['a18J4M'] = function (_c9zrs) {
  if (!_c9zrs) {
    window['a14MJ'](C[460644], C[460645]), window['a1J84M'](C[460646]);return;
  }if (_c9zrs[C[460424]] != C[460423]) {
    window['a14MJ'](C[460644], JSON[C[460023]](_c9zrs)), window['a1J84M'](C[460647] + _c9zrs[C[460424]]);return;
  }a14M[C[460648]] = String(_c9zrs[C[460015]]), a14M[C[460015]] = String(_c9zrs[C[460015]]), a14M[C[460079]] = String(_c9zrs[C[460079]]), a14M[C[460558]] = String(_c9zrs[C[460079]]), a14M[C[460649]] = String(_c9zrs[C[460649]]), a14M[C[460650]] = String(_c9zrs[C[460651]]), a14M[C[460652]] = String(_c9zrs[C[460653]]), a14M[C[460651]] = '';var s_cvrq = this;a1J48M({ 'title': C[460654] }), sendApi(a14M[C[460546]], C[460655], { 'partner_id': a14M[C[460554]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460555]] }, s_cvrq['a18JM4'][C[460322]](s_cvrq), a18M4, a1MJ);
}, window['a18JM4'] = function (sc_rvq) {
  if (!sc_rvq) {
    window['a1J84M'](C[460656]);return;
  }if (sc_rvq[C[460424]] != C[460423]) {
    window['a1J84M'](C[460657] + sc_rvq[C[460424]]);return;
  }if (!sc_rvq[C[460425]] || sc_rvq[C[460425]][C[460009]] == 0x0) {
    window['a1J84M'](C[460658]);return;
  }a14M[C[460497]] = sc_rvq[C[460659]], a14M[C[460019]] = { 'server_id': String(sc_rvq[C[460425]][0x0][C[460020]]), 'server_name': String(sc_rvq[C[460425]][0x0][C[460404]]), 'entry_ip': sc_rvq[C[460425]][0x0][C[460660]], 'entry_port': parseInt(sc_rvq[C[460425]][0x0][C[460661]]), 'status': a148J(sc_rvq[C[460425]][0x0]), 'start_time': sc_rvq[C[460425]][0x0][C[460662]], 'cdn': a14M[C[460017]] }, this['a1M48J']();
}, window['a1M48J'] = function () {
  if (a14M[C[460497]] == 0x1) {
    var bn = a14M[C[460019]][C[460403]];if (bn === -0x1 || bn === 0x0) {
      window['a1J84M'](bn === -0x1 ? C[460663] : C[460664]);return;
    }a1MJ84(0x0, a14M[C[460019]][C[460020]]), window[C[460031]][C[460032]][C[460492]](a14M[C[460497]]);
  } else window[C[460031]][C[460032]][C[460489]](), a1J4M8();window['a148'] = !![], window['a1M84J'](), window['a1M4J8']();
}, window['a184JM'] = function () {
  sendApi(a14M[C[460546]], C[460665], { 'game_pkg': a14M[C[460018]], 'version_name': a14M[C[460622]] }, this[C[460666]][C[460322]](this), a18M4, a1MJ);
}, window[C[460666]] = function (fkv0$) {
  if (!fkv0$) {
    window['a1J84M'](C[460667]);return;
  }if (fkv0$[C[460424]] != C[460423]) {
    window['a1J84M'](C[460668] + fkv0$[C[460424]]);return;
  }if (!fkv0$[C[460425]] || !fkv0$[C[460425]][C[460075]]) {
    window['a1J84M'](C[460669] + (fkv0$[C[460425]] && fkv0$[C[460425]][C[460075]]));return;
  }fkv0$[C[460425]][C[460670]] && fkv0$[C[460425]][C[460670]][C[460009]] > 0xa && (a14M[C[460671]] = fkv0$[C[460425]][C[460670]], a14M[C[460017]] = fkv0$[C[460425]][C[460670]]), fkv0$[C[460425]][C[460075]] && (a14M[C[460016]] = fkv0$[C[460425]][C[460075]]), console[C[460000]](C[460672] + a14M[C[460016]] + C[460673] + a14M[C[460622]]), window['a14M8'] = !![], window['a1M84J'](), window['a1M4J8']();
}, window[C[460674]], window['a184MJ'] = function () {
  sendApi(a14M[C[460546]], C[460675], { 'game_pkg': a14M[C[460018]] }, this['a18MJ4'][C[460322]](this), a18M4, a1MJ);
}, window['a18MJ4'] = function (fl0y$) {
  if (fl0y$[C[460424]] === C[460423] && fl0y$[C[460425]]) {
    window[C[460674]] = fl0y$[C[460425]];for (var qrl$0v in fl0y$[C[460425]]) {
      a14M[qrl$0v] = fl0y$[C[460425]][qrl$0v];
    }
  } else console[C[460000]](C[460676] + fl0y$[C[460424]]);window['a184'] = !![], window['a1M4J8']();
}, window[C[460677]] = function (htbixo, v_scq, rscqv$, xbph2, _zcm9, jtid, bhox, vlq0k$, hbx2p) {
  _zcm9 = String(_zcm9);var s$rcv = bhox,
      nxb2p8 = vlq0k$;a14M[C[460542]][_zcm9] = { 'productid': _zcm9, 'productname': s$rcv, 'productdesc': nxb2p8, 'roleid': htbixo, 'rolename': v_scq, 'rolelevel': rscqv$, 'price': jtid, 'callback': hbx2p }, sendApi(a14M[C[460550]], C[460678], { 'game_pkg': a14M[C[460018]], 'server_id': a14M[C[460019]][C[460020]], 'server_name': a14M[C[460019]][C[460404]], 'level': rscqv$, 'uid': a14M[C[460015]], 'role_id': htbixo, 'role_name': v_scq, 'product_id': _zcm9, 'product_name': s$rcv, 'product_desc': nxb2p8, 'money': jtid, 'partner_id': a14M[C[460554]] }, toPayCallBack, a18M4, a1MJ);
}, window[C[460679]] = function (ls$qvr) {
  if (ls$qvr) {
    if (ls$qvr[C[460680]] === 0xc8 || ls$qvr[C[460424]] == C[460423]) {
      var cmjz_ = a14M[C[460542]][String(ls$qvr[C[460681]])];if (cmjz_[C[460682]]) cmjz_[C[460682]](ls$qvr[C[460681]], ls$qvr[C[460683]], -0x1);abnxp28[C[460684]]({ 'cpbill': ls$qvr[C[460683]], 'productid': ls$qvr[C[460681]], 'productname': cmjz_[C[460685]], 'productdesc': cmjz_[C[460686]], 'serverid': a14M[C[460019]][C[460020]], 'servername': a14M[C[460019]][C[460404]], 'roleid': cmjz_[C[460687]], 'rolename': cmjz_[C[460688]], 'rolelevel': cmjz_[C[460689]], 'price': cmjz_[C[460690]], 'extension': JSON[C[460023]]({ 'cp_order_id': ls$qvr[C[460683]] }) }, function (pbho, toxhp) {
        cmjz_[C[460682]] && pbho == 0x0 && cmjz_[C[460682]](ls$qvr[C[460681]], ls$qvr[C[460683]], pbho);console[C[460000]](JSON[C[460023]]({ 'type': C[460691], 'status': pbho, 'data': ls$qvr, 'role_name': cmjz_[C[460688]] }));if (pbho === 0x0) {} else {
          if (pbho === 0x1) {} else {
            if (pbho === 0x2) {}
          }
        }
      });
    } else alert(ls$qvr[C[460000]]);
  }
}, window['a18M4J'] = function () {}, window['a1J8M'] = function (box2, hp2x, _mz49, ylkf0$, f7yk6) {
  abnxp28[C[460692]](a14M[C[460019]][C[460020]], a14M[C[460019]][C[460404]] || a14M[C[460019]][C[460020]], box2, hp2x, _mz49), sendApi(a14M[C[460546]], C[460693], { 'game_pkg': a14M[C[460018]], 'server_id': a14M[C[460019]][C[460020]], 'role_id': box2, 'uid': a14M[C[460015]], 'role_name': hp2x, 'role_type': ylkf0$, 'level': _mz49 });
}, window['a1JM8'] = function (p2o8, xp2bo, tio5xh, toihd, xoh2, zr9sc, jczm, idt54h, cszr_9, j49mdz) {
  a14M[C[460012]] = p2o8, a14M[C[460013]] = xp2bo, a14M[C[460014]] = tio5xh, abnxp28[C[460694]](a14M[C[460019]][C[460020]], a14M[C[460019]][C[460404]] || a14M[C[460019]][C[460020]], p2o8, xp2bo, tio5xh), sendApi(a14M[C[460546]], C[460695], { 'game_pkg': a14M[C[460018]], 'server_id': a14M[C[460019]][C[460020]], 'role_id': p2o8, 'uid': a14M[C[460015]], 'role_name': xp2bo, 'role_type': toihd, 'level': tio5xh, 'evolution': xoh2 });
}, window['a18JM'] = function (zm9sc, px8ob, b8oxp2, ufy61, tobxi, xbn8, _49zm, dt5ih, zm4dj9, ohtd5i) {
  a14M[C[460012]] = zm9sc, a14M[C[460013]] = px8ob, a14M[C[460014]] = b8oxp2, abnxp28[C[460696]](a14M[C[460019]][C[460020]], a14M[C[460019]][C[460404]] || a14M[C[460019]][C[460020]], zm9sc, px8ob, b8oxp2), sendApi(a14M[C[460546]], C[460695], { 'game_pkg': a14M[C[460018]], 'server_id': a14M[C[460019]][C[460020]], 'role_id': zm9sc, 'uid': a14M[C[460015]], 'role_name': px8ob, 'role_type': ufy61, 'level': b8oxp2, 'evolution': tobxi });
}, window['a18MJ'] = function (_smcz9) {}, window['a1J8'] = function (x5tih) {
  abnxp28[C[460697]](C[460697], function (m4z9d) {
    x5tih && x5tih(m4z9d);
  });
}, window[C[460698]] = function () {
  abnxp28[C[460698]]();
}, window[C[460699]] = function () {
  abnxp28[C[460700]]();
}, window[C[460701]] = function (yf17u, phx2o, u7yw1, cvsq, zjm9_c, hdt45, qr$vsc, svlrq$) {
  svlrq$ = svlrq$ || a14M[C[460019]][C[460020]], sendApi(a14M[C[460546]], C[460702], { 'phone': yf17u, 'role_id': phx2o, 'uid': a14M[C[460015]], 'game_pkg': a14M[C[460018]], 'partner_id': a14M[C[460554]], 'server_id': svlrq$ }, qr$vsc);
}, window[C[460131]] = function (otxbhi) {
  window['a1MJ8'] = otxbhi, window['a1MJ8'] && window['a18J'] && (console[C[460000]](C[460132] + window['a18J'][C[460133]]), window['a1MJ8'](window['a18J']), window['a18J'] = null);
}, window['a1M8J'] = function ($sqc, rc9z_s, qs9, thoix) {
  window[C[460703]](C[460704], { 'game_pkg': window['a14M'][C[460018]], 'role_id': rc9z_s, 'server_id': qs9 }, thoix);
}, window['a14J8M'] = function (vsc$qr, bp8x2o) {
  function opxh2b(oihx5t) {
    var oiht5x = [],
        cz9ms_ = [],
        en83g = window[C[460005]][C[460705]];for (var l0$fv in en83g) {
      var vrs_qc = Number(l0$fv);(!vsc$qr || !vsc$qr[C[460009]] || vsc$qr[C[460103]](vrs_qc) != -0x1) && (cz9ms_[C[460035]](en83g[l0$fv]), oiht5x[C[460035]]([vrs_qc, 0x3]));
    }window['a1C8MJ4'](window[C[460036]], C[460706]) >= 0x0 ? (console[C[460038]](C[460707]), abnxp28[C[460708]] && abnxp28[C[460708]](cz9ms_, function (e3gn2) {
      console[C[460038]](C[460709]), console[C[460038]](e3gn2);if (e3gn2 && e3gn2[C[460054]] == C[460710]) for (var hx2b in en83g) {
        if (e3gn2[en83g[hx2b]] == C[460711]) {
          var smzc = Number(hx2b);for (var bthx = 0x0; bthx < oiht5x[C[460009]]; bthx++) {
            if (oiht5x[bthx][0x0] == smzc) {
              oiht5x[bthx][0x1] = 0x1;break;
            }
          }
        }
      }window['a1C8MJ4'](window[C[460036]], C[460712]) >= 0x0 ? wx[C[460713]]({ 'withSubscriptions': !![], 'success': function (kly6f) {
          var y17u = kly6f[C[460714]][C[460715]];if (y17u) {
            console[C[460038]](C[460716]), console[C[460038]](y17u);for (var lqvsr$ in en83g) {
              if (y17u[en83g[lqvsr$]] == C[460711]) {
                var zmj49_ = Number(lqvsr$);for (var oitxb = 0x0; oitxb < oiht5x[C[460009]]; oitxb++) {
                  if (oiht5x[oitxb][0x0] == zmj49_) {
                    oiht5x[oitxb][0x1] = 0x2;break;
                  }
                }
              }
            }console[C[460038]](oiht5x), bp8x2o && bp8x2o(oiht5x);
          } else console[C[460038]](C[460717]), console[C[460038]](kly6f), console[C[460038]](oiht5x), bp8x2o && bp8x2o(oiht5x);
        }, 'fail': function () {
          console[C[460038]](C[460718]), console[C[460038]](oiht5x), bp8x2o && bp8x2o(oiht5x);
        } }) : (console[C[460038]](C[460719] + window[C[460036]]), console[C[460038]](oiht5x), bp8x2o && bp8x2o(oiht5x));
    })) : (console[C[460038]](C[460720] + window[C[460036]]), console[C[460038]](oiht5x), bp8x2o && bp8x2o(oiht5x)), wx[C[460721]](opxh2b);
  }wx[C[460722]](opxh2b);
}, window['a14JM8'] = { 'isSuccess': ![], 'level': C[460723], 'isCharging': ![] }, window['a148JM'] = function (en82g3) {
  wx[C[460119]]({ 'success': function (id4jm) {
      var _4zm9 = window['a14JM8'];_4zm9[C[460724]] = !![], _4zm9[C[460121]] = Number(id4jm[C[460121]])[C[460725]](0x0), _4zm9[C[460123]] = id4jm[C[460123]], en82g3 && en82g3(_4zm9[C[460724]], _4zm9[C[460121]], _4zm9[C[460123]]);
    }, 'fail': function (kf0v) {
      console[C[460038]](C[460726], kf0v[C[460054]]);var csq = window['a14JM8'];en82g3 && en82g3(csq[C[460724]], csq[C[460121]], csq[C[460123]]);
    } });
}, window[C[460703]] = function (bihxo, htido5, idjm4, _vqsr, ky0$f, oibh, m9_zcs, ixbho) {
  if (_vqsr == undefined) _vqsr = 0x1;wx[C[460597]]({ 'url': bihxo, 'method': m9_zcs || C[460727], 'responseType': C[460320], 'data': htido5, 'header': { 'content-type': ixbho || C[460599] }, 'success': function (_scr9z) {
      DEBUG && console[C[460038]](C[460728], bihxo, info, _scr9z);if (_scr9z && _scr9z[C[460729]] == 0xc8) {
        var pthob = _scr9z[C[460425]];!oibh || oibh(pthob) ? idjm4 && idjm4(pthob) : window[C[460730]](bihxo, htido5, idjm4, _vqsr, ky0$f, oibh, _scr9z);
      } else window[C[460730]](bihxo, htido5, idjm4, _vqsr, ky0$f, oibh, _scr9z);
    }, 'fail': function (j_z9m4) {
      DEBUG && console[C[460038]](C[460731], bihxo, info, j_z9m4), window[C[460730]](bihxo, htido5, idjm4, _vqsr, ky0$f, oibh, j_z9m4);
    }, 'complete': function () {} });
}, window[C[460730]] = function (pothbx, k076yf, vfl0$k, lfyk, e8b2np, bihxt, _s9z) {
  lfyk - 0x1 > 0x0 ? setTimeout(function () {
    window[C[460703]](pothbx, k076yf, vfl0$k, lfyk - 0x1, e8b2np, bihxt);
  }, 0x3e8) : e8b2np && e8b2np(JSON[C[460023]]({ 'url': pothbx, 'response': _s9z }));
}, window[C[460732]] = function (y671, obhtix, cm9z_s, pxn2b, txio, q$svc, m4id5j) {
  !cm9z_s && (cm9z_s = {});var rvcs_ = Math[C[460509]](Date[C[460137]]() / 0x3e8);cm9z_s[C[460653]] = rvcs_, cm9z_s[C[460733]] = obhtix;var s9zcr_ = Object[C[460734]](cm9z_s)[C[460429]](),
      p82nx = '',
      _4m9j = '';for (var ep283n = 0x0; ep283n < s9zcr_[C[460009]]; ep283n++) {
    p82nx = p82nx + (ep283n == 0x0 ? '' : '&') + s9zcr_[ep283n] + cm9z_s[s9zcr_[ep283n]], _4m9j = _4m9j + (ep283n == 0x0 ? '' : '&') + s9zcr_[ep283n] + '=' + encodeURIComponent(cm9z_s[s9zcr_[ep283n]]);
  }p82nx = p82nx + a14M[C[460552]];var idjm54 = C[460735] + md5(p82nx);send(y671 + '?' + _4m9j + (_4m9j == '' ? '' : '&') + idjm54, null, pxn2b, txio, q$svc, m4id5j || function (tx5hoi) {
    return tx5hoi[C[460424]] == C[460423];
  }, null, C[460736]);
}, window['a148MJ'] = function (d5m4, j5dzm4) {
  var z9msc_ = 0x0;a14M[C[460019]] && (z9msc_ = a14M[C[460019]][C[460020]]), sendApi(a14M[C[460548]], C[460737], { 'partnerId': a14M[C[460554]], 'gamePkg': a14M[C[460018]], 'logTime': Math[C[460509]](Date[C[460137]]() / 0x3e8), 'platformUid': a14M[C[460649]], 'type': d5m4, 'serverId': z9msc_ }, null, 0x2, null, function () {
    return !![];
  });
}, window['a14MJ8'] = function (svrqc$) {
  sendApi(a14M[C[460546]], C[460738], { 'partner_id': a14M[C[460554]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460555]] }, a14M8J, a18M4, a1MJ);
}, window['a14M8J'] = function (t45ij) {
  if (t45ij[C[460424]] === C[460423] && t45ij[C[460425]]) {
    t45ij[C[460425]][C[460739]]({ 'id': -0x2, 'name': C[460740] }), t45ij[C[460425]][C[460739]]({ 'id': -0x1, 'name': C[460741] }), a14M[C[460377]] = t45ij[C[460425]];if (window[C[460369]]) window[C[460369]][C[460410]]();
  } else a14M[C[460387]] = ![], window['a1J84M'](C[460742] + t45ij[C[460424]]);
}, window['a1J84'] = function (n8b) {
  sendApi(a14M[C[460546]], C[460743], { 'partner_id': a14M[C[460554]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460555]] }, a1J48, a18M4, a1MJ);
}, window['a1J48'] = function (ohixb) {
  a14M[C[460418]] = ![];if (ohixb[C[460424]] === C[460423] && ohixb[C[460425]]) {
    for (var np28xb = 0x0; np28xb < ohixb[C[460425]][C[460009]]; np28xb++) {
      ohixb[C[460425]][np28xb][C[460403]] = a148J(ohixb[C[460425]][np28xb]);
    }a14M[C[460416]][-0x1] = window[C[460744]](ohixb[C[460425]]), window[C[460369]][C[460417]](-0x1);
  } else window['a1J84M'](C[460745] + ohixb[C[460424]]);
}, window[C[460746]] = function (_m9jz4) {
  sendApi(a14M[C[460546]], C[460743], { 'partner_id': a14M[C[460554]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460555]] }, _m9jz4, a18M4, a1MJ);
}, window['a18J4'] = function (ijdm45, oxpt) {
  sendApi(a14M[C[460546]], C[460747], { 'partner_id': a14M[C[460554]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460555]], 'server_group_id': oxpt }, a184J, a18M4, a1MJ);
}, window['a184J'] = function ($qcrs) {
  a14M[C[460418]] = ![];if ($qcrs[C[460424]] === C[460423] && $qcrs[C[460425]] && $qcrs[C[460425]][C[460425]]) {
    var qcr_9s = $qcrs[C[460425]][C[460748]],
        u1w6y7 = [];for (var rsqcv = 0x0; rsqcv < $qcrs[C[460425]][C[460425]][C[460009]]; rsqcv++) {
      $qcrs[C[460425]][C[460425]][rsqcv][C[460403]] = a148J($qcrs[C[460425]][C[460425]][rsqcv]), (u1w6y7[C[460009]] == 0x0 || $qcrs[C[460425]][C[460425]][rsqcv][C[460403]] != 0x0) && (u1w6y7[u1w6y7[C[460009]]] = $qcrs[C[460425]][C[460425]][rsqcv]);
    }a14M[C[460416]][qcr_9s] = window[C[460744]](u1w6y7), window[C[460369]][C[460417]](qcr_9s);
  } else window['a1J84M'](C[460749] + $qcrs[C[460424]]);
}, window['a1C8M4'] = function (bixt) {
  sendApi(a14M[C[460546]], C[460750], { 'partner_id': a14M[C[460554]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460555]] }, reqServerRecommendCallBack, a18M4, a1MJ);
}, window[C[460751]] = function (ibth) {
  a14M[C[460418]] = ![];if (ibth[C[460424]] === C[460423] && ibth[C[460425]]) {
    for (var ti5hdo = 0x0; ti5hdo < ibth[C[460425]][C[460009]]; ti5hdo++) {
      ibth[C[460425]][ti5hdo][C[460403]] = a148J(ibth[C[460425]][ti5hdo]);
    }a14M[C[460416]][-0x2] = window[C[460744]](ibth[C[460425]]), window[C[460369]][C[460417]](-0x2);
  } else alert(C[460752] + ibth[C[460424]]);
}, window[C[460744]] = function (fy1k76) {
  if (!fy1k76 && fy1k76[C[460009]] <= 0x0) return fy1k76;for (let p82xbo = 0x0; p82xbo < fy1k76[C[460009]]; p82xbo++) {
    fy1k76[p82xbo][C[460753]] && fy1k76[p82xbo][C[460753]] == 0x1 && (fy1k76[p82xbo][C[460404]] += C[460754]);
  }return fy1k76;
}, window['a14J8'] = function (m49jd, sr) {
  m49jd = m49jd || a14M[C[460019]][C[460020]], sendApi(a14M[C[460546]], C[460755], { 'type': '4', 'game_pkg': a14M[C[460018]], 'server_id': m49jd }, sr);
}, window[C[460756]] = function (bohxpt, c$srq, svqr_, r$0vql) {
  svqr_ = svqr_ || a14M[C[460019]][C[460020]], sendApi(a14M[C[460546]], C[460757], { 'type': bohxpt, 'game_pkg': c$srq, 'server_id': svqr_ }, r$0vql);
}, window['a148J'] = function (pxn82) {
  if (pxn82) {
    if (pxn82[C[460403]] == 0x1) {
      if (pxn82[C[460758]] == 0x1) return 0x2;else return 0x1;
    } else return pxn82[C[460403]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['a1MJ84'] = function (xh2po, djim5) {
  a14M[C[460759]] = { 'step': xh2po, 'server_id': djim5 };var zr_s = this;a1J48M({ 'title': C[460760] }), sendApi(a14M[C[460546]], C[460761], { 'partner_id': a14M[C[460554]], 'uid': a14M[C[460015]], 'game_pkg': a14M[C[460018]], 'server_id': djim5, 'platform': a14M[C[460079]], 'platform_uid': a14M[C[460649]], 'check_login_time': a14M[C[460652]], 'check_login_sign': a14M[C[460650]], 'version_name': a14M[C[460622]] }, a1MJ48, a18M4, a1MJ, function (hxbp2) {
    return hxbp2[C[460424]] == C[460423] || hxbp2[C[460000]] == C[460762] || hxbp2[C[460000]] == C[460763];
  });
}, window['a1MJ48'] = function (dt54i) {
  var j5md = this;if (dt54i[C[460424]] === C[460423] && dt54i[C[460425]]) {
    var k6f7y0 = a14M[C[460019]];k6f7y0[C[460764]] = a14M[C[460557]], k6f7y0[C[460651]] = String(dt54i[C[460425]][C[460765]]), k6f7y0[C[460563]] = parseInt(dt54i[C[460425]][C[460653]]);if (dt54i[C[460425]][C[460766]]) k6f7y0[C[460766]] = parseInt(dt54i[C[460425]][C[460766]]);else k6f7y0[C[460766]] = parseInt(dt54i[C[460425]][C[460020]]);k6f7y0[C[460767]] = 0x0, k6f7y0[C[460017]] = a14M[C[460671]], k6f7y0[C[460768]] = dt54i[C[460425]][C[460769]], k6f7y0[C[460770]] = dt54i[C[460425]][C[460770]], console[C[460038]](C[460771] + JSON[C[460023]](k6f7y0[C[460770]])), a14M[C[460497]] == 0x1 && k6f7y0[C[460770]] && k6f7y0[C[460770]][C[460772]] == 0x1 && (a14M[C[460326]] = 0x1, window[C[460031]][C[460032]]['a1CM4']()), a1M8J4();
  } else a14M[C[460759]][C[460773]] >= 0x3 ? (a1MJ(JSON[C[460023]](dt54i)), window['a1J84M'](C[460774] + dt54i[C[460424]])) : sendApi(a14M[C[460546]], C[460634], { 'platform': a14M[C[460544]], 'partner_id': a14M[C[460554]], 'token': a14M[C[460632]], 'game_pkg': a14M[C[460018]], 'deviceId': a14M[C[460555]], 'scene': C[460635] + a14M[C[460556]] }, function (txohib) {
    if (!txohib || txohib[C[460424]] != C[460423]) {
      window['a1J84M'](C[460647] + txohib && txohib[C[460424]]);return;
    }a14M[C[460650]] = String(txohib[C[460651]]), a14M[C[460652]] = String(txohib[C[460653]]), setTimeout(function () {
      a1MJ84(a14M[C[460759]][C[460773]] + 0x1, a14M[C[460759]][C[460020]]);
    }, 0x5dc);
  }, a18M4, a1MJ, function (t5ihd) {
    return t5ihd[C[460424]] == C[460423] || t5ihd[C[460424]] == C[460775];
  });
}, window['a1M8J4'] = function () {
  ServerLoading[C[460032]][C[460492]](a14M[C[460497]]), window['a18M'] = !![], window['a1M4J8']();
}, window['a1M84J'] = function () {
  if (window['a1M8'] && window['a148M'] && window[C[460488]] && window[C[460491]] && window['a14M8'] && window['a148']) {
    if (!window[C[460776]][C[460032]]) {
      console[C[460038]](C[460777] + window[C[460776]][C[460032]]);var f0lk$ = wx[C[460778]](),
          csz_9m = f0lk$[C[460133]] ? f0lk$[C[460133]] : 0x0,
          n2e83p = { 'cdn': window['a14M'][C[460017]], 'spareCdn': window['a14M'][C[460620]], 'newRegister': window['a14M'][C[460497]], 'wxPC': window['a14M'][C[460108]], 'wxIOS': window['a14M'][C[460102]], 'wxAndroid': window['a14M'][C[460105]], 'wxParam': { 'limitLoad': window['a14M']['a1CJ8M4'], 'benchmarkLevel': window['a14M']['a1CJ48M'], 'wxFrom': window[C[460005]][C[460627]] == C[460779] ? 0x1 : 0x0, 'wxSDKVersion': window[C[460036]] }, 'configType': window['a14M'][C[460564]], 'exposeType': window['a14M'][C[460566]], 'scene': csz_9m };new window[C[460776]](n2e83p, window['a14M'][C[460016]], window['a1CJ84M']);
    }
  }
}, window['a1M4J8'] = function () {
  if (window['a1M8'] && window['a148M'] && window[C[460488]] && window[C[460491]] && window['a14M8'] && window['a148'] && window['a18M'] && window['a184']) {
    a1J4M8();if (!a1M84) {
      a1M84 = !![];if (!window[C[460776]][C[460032]]) window['a1M84J']();var dhti4 = 0x0,
          lqk0 = wx[C[460780]]();lqk0 && (window['a14M'][C[460107]] && (dhti4 = lqk0[C[460097]]), console[C[460000]](C[460781] + lqk0[C[460097]] + C[460782] + lqk0[C[460098]] + C[460783] + lqk0[C[460099]] + C[460784] + lqk0[C[460100]] + C[460785] + lqk0[C[460293]] + C[460786] + lqk0[C[460295]]));var tboih = {};for (const kq0$vl in a14M[C[460019]]) {
        tboih[kq0$vl] = a14M[C[460019]][kq0$vl];
      }var k71yf = { 'channel': window['a14M'][C[460558]], 'account': window['a14M'][C[460015]], 'userId': window['a14M'][C[460648]], 'serverId': tboih[C[460020]], 'cdn': window['a14M'][C[460017]], 'data': window['a14M'][C[460425]], 'package': window['a14M'][C[460543]], 'newRegister': window['a14M'][C[460497]], 'pkgName': window['a14M'][C[460018]], 'partnerId': window['a14M'][C[460554]], 'platform_uid': window['a14M'][C[460649]], 'deviceId': window['a14M'][C[460555]], 'selectedServer': tboih, 'configType': window['a14M'][C[460564]], 'exposeType': window['a14M'][C[460566]], 'debugUsers': window['a14M'][C[460561]], 'wxMenuTop': dhti4, 'wxShield': window['a14M'][C[460567]] };if (window[C[460674]]) for (var vrs_cq in window[C[460674]]) {
        k71yf[vrs_cq] = window[C[460674]][vrs_cq];
      }window[C[460776]][C[460032]]['a1M4C'](k71yf);
    }
  } else console[C[460000]](C[460787] + window['a1M8'] + C[460788] + window['a148M'] + C[460789] + window[C[460488]] + C[460790] + window[C[460491]] + C[460791] + window['a14M8'] + C[460792] + window['a148'] + C[460793] + window['a18M'] + C[460794] + window['a184']);
};