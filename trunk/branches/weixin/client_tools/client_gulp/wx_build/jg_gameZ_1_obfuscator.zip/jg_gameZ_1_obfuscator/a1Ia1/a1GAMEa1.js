var C = wx.$a;
console[C[460000]](C[460001]), window[C[460002]], wx[C[460003]](function (ql0r) {
  if (ql0r) {
    if (ql0r[C[460004]]) {
      var e3gn = window[C[460005]][C[460006]][C[460007]](new RegExp(/\./, 'g'), '_'),
          uw7y = ql0r[C[460004]],
          f1y6 = uw7y[C[460008]](/(aaaaa\/a1GAMEa1.js:)[0-9]{1,60}(:)/g);if (f1y6) for (var srq_9 = 0x0; srq_9 < f1y6[C[460009]]; srq_9++) {
        if (f1y6[srq_9] && f1y6[srq_9][C[460009]] > 0x0) {
          var $slrqv = parseInt(f1y6[srq_9][C[460007]]('aaaaa/a1GAMEa1.js:', '')[C[460007]](':', ''));uw7y = uw7y[C[460007]](f1y6[srq_9], f1y6[srq_9][C[460007]](':' + $slrqv + ':', ':' + ($slrqv - 0x2) + ':'));
        }
      }uw7y = uw7y[C[460007]](new RegExp('aaaaa/a1GAMEa1.js', 'g'), C[460010] + e3gn + C[460011]), uw7y = uw7y[C[460007]](new RegExp('aaaaa/a1MAIa1.js', 'g'), C[460010] + e3gn + C[460011]), ql0r[C[460004]] = uw7y;
    }var m5dzj = { 'id': window['a14M'][C[460012]], 'role': window['a14M'][C[460013]], 'level': window['a14M'][C[460014]], 'user': window['a14M'][C[460015]], 'version': window['a14M'][C[460016]], 'cdn': window['a14M'][C[460017]], 'pkgName': window['a14M'][C[460018]], 'gamever': window[C[460005]][C[460006]], 'serverid': window['a14M'][C[460019]] ? window['a14M'][C[460019]][C[460020]] : 0x0, 'systemInfo': window[C[460021]], 'error': C[460022], 'stack': ql0r ? ql0r[C[460004]] : '' },
        xptbo = JSON[C[460023]](m5dzj);console[C[460024]](C[460025] + xptbo), (!window[C[460002]] || window[C[460002]] != m5dzj[C[460024]]) && (window[C[460002]] = m5dzj[C[460024]], window['a1J4'](m5dzj));
  }
});import 'aabfaa.js';import 'aa11aa.js';window[C[460026]] = require(C[460027]);import 'aINDaa.js';import 'aaIB1aa.js';import 'aaMtadaa.js';import 'aaINIaa.js';console[C[460000]](C[460028]), console[C[460000]](C[460029]), a1J48M({ 'title': C[460030] });var alqr0$v = { 'a1CJM48': !![] };new window[C[460031]](alqr0$v), window[C[460031]][C[460032]]['a1C84MJ']();if (window['a1CJ4M8']) clearInterval(window['a1CJ4M8']);window['a1CJ4M8'] = null, window['a1C8MJ4'] = function (xbho2, pnb8x2) {
  if (!xbho2 || !pnb8x2) return 0x0;xbho2 = xbho2[C[460033]]('.'), pnb8x2 = pnb8x2[C[460033]]('.');const m_9zj = Math[C[460034]](xbho2[C[460009]], pnb8x2[C[460009]]);while (xbho2[C[460009]] < m_9zj) {
    xbho2[C[460035]]('0');
  }while (pnb8x2[C[460009]] < m_9zj) {
    pnb8x2[C[460035]]('0');
  }for (var t5d4i = 0x0; t5d4i < m_9zj; t5d4i++) {
    const htx5 = parseInt(xbho2[t5d4i]),
          qs_r9c = parseInt(pnb8x2[t5d4i]);if (htx5 > qs_r9c) return 0x1;else {
      if (htx5 < qs_r9c) return -0x1;
    }
  }return 0x0;
}, window[C[460036]] = wx[C[460037]]()[C[460036]], console[C[460038]](C[460039] + window[C[460036]]);var a_szm9c = wx[C[460040]]();a_szm9c[C[460041]](function (v$lqsr) {
  console[C[460038]](C[460042] + v$lqsr[C[460043]]);
}), a_szm9c[C[460044]](function () {
  wx[C[460045]]({ 'title': C[460046], 'content': C[460047], 'showCancel': ![], 'success': function (ixbht) {
      a_szm9c[C[460048]]();
    } });
}), a_szm9c[C[460049]](function () {
  console[C[460038]](C[460050]);
}), window['a1C8M4J'] = function () {
  console[C[460038]](C[460051]);var yf76k0 = wx[C[460052]]({ 'name': 'a1pfta1', 'success': function (it5hd4) {
      console[C[460038]](C[460053]), console[C[460038]](it5hd4), it5hd4 && it5hd4[C[460054]] == C[460055] ? (window['a1M8'] = !![], window['a1M84J'](), window['a1M4J8']()) : setTimeout(function () {
        window['a1C8M4J']();
      }, 0x1f4);
    }, 'fail': function (_srcq9) {
      console[C[460038]](C[460056]), console[C[460038]](_srcq9), setTimeout(function () {
        window['a1C8M4J']();
      }, 0x1f4);
    } });yf76k0 && yf76k0[C[460057]](rsq9_ => {});
}, window['a1C4JM8'] = function () {
  console[C[460038]](C[460058]);var cs_q9r = wx[C[460052]]({ 'name': C[460059], 'success': function (tid4j5) {
      console[C[460038]](C[460060]), console[C[460038]](tid4j5), tid4j5 && tid4j5[C[460054]] == C[460055] ? (window['a148M'] = !![], window['a1M84J'](), window['a1M4J8']()) : setTimeout(function () {
        window['a1C4JM8']();
      }, 0x1f4);
    }, 'fail': function (jczm) {
      console[C[460038]](C[460061]), console[C[460038]](jczm), setTimeout(function () {
        window['a1C4JM8']();
      }, 0x1f4);
    } });cs_q9r && cs_q9r[C[460057]](vcqr$s => {});
}, window[C[460062]] = function () {
  window['a1C8MJ4'](window[C[460036]], C[460063]) >= 0x0 ? (console[C[460038]](C[460064] + window[C[460036]] + C[460065]), window['a14J'](), window['a1C8M4J'](), window['a1C4JM8']()) : (window['a14MJ'](C[460066], window[C[460036]]), wx[C[460045]]({ 'title': C[460067], 'content': C[460068] }));
}, window[C[460021]] = '', wx[C[460069]]({ 'success'(flky0) {
    window[C[460021]] = C[460070] + flky0[C[460071]] + C[460072] + flky0[C[460073]] + C[460074] + flky0[C[460075]] + C[460076] + flky0[C[460077]] + C[460078] + flky0[C[460079]] + C[460080] + flky0[C[460036]] + C[460081] + flky0[C[460082]], console[C[460038]](window[C[460021]]), console[C[460038]](C[460083] + flky0[C[460084]] + C[460085] + flky0[C[460086]] + C[460087] + flky0[C[460088]] + C[460089] + flky0[C[460090]] + C[460091] + flky0[C[460092]] + C[460093] + flky0[C[460094]] + C[460095] + (flky0[C[460096]] ? flky0[C[460096]][C[460097]] + ',' + flky0[C[460096]][C[460098]] + ',' + flky0[C[460096]][C[460099]] + ',' + flky0[C[460096]][C[460100]] : ''));var fvl0k = flky0[C[460077]] ? flky0[C[460077]][C[460101]]() : '',
        $f0lvk = flky0[C[460073]] ? flky0[C[460073]][C[460101]]()[C[460007]]('\x20', '') : '';window['a14M'][C[460102]] = fvl0k[C[460103]](C[460104]) != -0x1, window['a14M'][C[460105]] = fvl0k[C[460103]](C[460106]) != -0x1, window['a14M'][C[460107]] = fvl0k[C[460103]](C[460104]) != -0x1 || fvl0k[C[460103]](C[460106]) != -0x1, window['a14M'][C[460108]] = fvl0k[C[460103]](C[460109]) != -0x1 || fvl0k[C[460103]](C[460110]) != -0x1, window['a14M'][C[460111]] = flky0[C[460079]] ? flky0[C[460079]][C[460101]]() : '', window['a14M']['a1CJ8M4'] = ![], window['a14M']['a1CJ48M'] = 0x2;if (fvl0k[C[460103]](C[460106]) != -0x1) {
      if (flky0[C[460082]] >= 0x18) window['a14M']['a1CJ48M'] = 0x3;else window['a14M']['a1CJ48M'] = 0x2;
    } else {
      if (fvl0k[C[460103]](C[460104]) != -0x1) {
        if (flky0[C[460082]] && flky0[C[460082]] >= 0x14) window['a14M']['a1CJ48M'] = 0x3;else {
          if ($f0lvk[C[460103]](C[460112]) != -0x1 || $f0lvk[C[460103]](C[460113]) != -0x1 || $f0lvk[C[460103]](C[460114]) != -0x1 || $f0lvk[C[460103]](C[460115]) != -0x1 || $f0lvk[C[460103]](C[460116]) != -0x1) window['a14M']['a1CJ48M'] = 0x2;else window['a14M']['a1CJ48M'] = 0x3;
        }
      } else window['a14M']['a1CJ48M'] = 0x2;
    }console[C[460038]](C[460117] + window['a14M']['a1CJ8M4'] + C[460118] + window['a14M']['a1CJ48M']);
  } }), wx[C[460119]]({ 'success': function (px8bn) {
    console[C[460038]](C[460120] + px8bn[C[460121]] + C[460122] + px8bn[C[460123]]);
  } }), wx[C[460124]]({ 'success': function (bioht) {
    console[C[460038]](C[460125] + bioht[C[460126]]);
  } }), wx[C[460127]]({ 'keepScreenOn': !![] }), wx[C[460128]](function (b82oxp) {
  console[C[460038]](C[460125] + b82oxp[C[460126]] + C[460129] + b82oxp[C[460130]]);
}), wx[C[460131]](function (vq$0lr) {
  window['a18J'] = vq$0lr, window['a1MJ8'] && window['a18J'] && (console[C[460000]](C[460132] + window['a18J'][C[460133]]), window['a1MJ8'](window['a18J']), window['a18J'] = null);
}), window[C[460134]] = 0x0, window['a1C48MJ'] = 0x0, window[C[460135]] = null, wx[C[460136]](function () {
  window['a1C48MJ']++;var z9j_c = Date[C[460137]]();(window[C[460134]] == 0x0 || z9j_c - window[C[460134]] > 0x1d4c0) && (console[C[460138]](C[460139]), wx[C[460140]]());if (window['a1C48MJ'] >= 0x2) {
    window['a1C48MJ'] = 0x0, console[C[460024]](C[460141]), wx[C[460142]]('0', 0x1);if (window['a14M'] && window['a14M'][C[460102]]) window['a14MJ'](C[460143], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});