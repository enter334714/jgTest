var b = wx.$e;
require(b[31106]);