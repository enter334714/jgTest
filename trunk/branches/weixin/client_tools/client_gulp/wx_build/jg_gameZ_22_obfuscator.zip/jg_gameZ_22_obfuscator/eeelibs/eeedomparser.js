var b = wx.$e;
function e_7av(x$ghl) {
  this['options'] = x$ghl || { 'locator': {} };
}function eflyrz(a7_fv, htzgrl, mpo7c) {
  function i$jgxt(am_7c4) {
    var hl$txg = a7_fv[am_7c4];!hl$txg && u69skb && (hl$txg = 0x2 == a7_fv['length'] ? function (n3u9q) {
      a7_fv(am_7c4, n3u9q);
    } : a7_fv), bku9s6[am_7c4] = hl$txg && function (q39nu) {
      hl$txg('[xmldom ' + am_7c4 + ']\t' + q39nu + equ39n(mpo7c));
    } || function () {};
  }if (!a7_fv) {
    if (htzgrl instanceof evfyh) return htzgrl;a7_fv = htzgrl;
  }var bku9s6 = {},
      u69skb = a7_fv instanceof Function;return mpo7c = mpo7c || {}, i$jgxt('warning'), i$jgxt('error'), i$jgxt('fatalError'), bku9s6;
}function evfyh() {
  this['cdata'] = !0x1;
}function emocape(x3jq, v_zyf) {
  v_zyf['lineNumber'] = x3jq['lineNumber'], v_zyf['columnNumber'] = x3jq['columnNumber'];
}function equ39n(aepm) {
  return aepm ? '\x0a@' + (aepm['systemId'] || '') + '#[line:' + aepm['lineNumber'] + ',col:' + aepm['columnNumber'] + ']' : void 0x0;
}function emoape(ocap7m, j$3iq, q9nks) {
  return 'string' == typeof ocap7m ? ocap7m['substr'](j$3iq, q9nks) : ocap7m['length'] >= j$3iq + q9nks || j$3iq ? new java['lang']['String'](ocap7m, j$3iq, q9nks) + '' : ocap7m;
}function ey_fv4z(capm7o, s9u6bk) {
  capm7o['currentElement'] ? capm7o['currentElement']['appendChild'](s9u6bk) : capm7o['doc']['appendChild'](s9u6bk);
}e_7av['prototype']['parseFromString'] = function (v_7f4y, sunqk9) {
  var jg$ix3 = this['options'],
      fzh = new emca_7(),
      bk605 = jg$ix3['domBuilder'] || new evfyh(),
      juq3 = jg$ix3['errorHandler'],
      $gtlh = jg$ix3['locator'],
      zhtylr = jg$ix3['xmlns'] || {},
      nsjqu3 = { 'lt': '<', 'gt': '>', 'amp': '&', 'quot': '\x22', 'apos': '\x27' };return $gtlh && bk605['setDocumentLocator']($gtlh), fzh['errorHandler'] = eflyrz(juq3, bk605, $gtlh), fzh['domBuilder'] = jg$ix3['domBuilder'] || bk605, /\/x?html?$/['test'](sunqk9) && (nsjqu3['nbsp'] = '\u00a0', nsjqu3['copy'] = '©', zhtylr[''] = 'http://www.w3.org/1999/xhtml'), zhtylr['xml'] = zhtylr['xml'] || 'http://www.w3.org/XML/1998/namespace', v_7f4y ? fzh['parse'](v_7f4y, zhtylr, nsjqu3) : fzh['errorHandler']['error']('invalid doc source'), bk605['doc'];
}, evfyh['prototype'] = { 'startDocument': function () {
    this['doc'] = new ezhfyvr()['createDocument'](null, null, null), this['locator'] && (this['doc']['documentURI'] = this['locator']['systemId']);
  }, 'startElement': function (d5bw80, hyzrvf, v_4yzf, gx$til) {
    var tli = this['doc'],
        ryhzv = tli['createElementNS'](d5bw80, v_4yzf || hyzrvf),
        f_47y = gx$til['length'];ey_fv4z(this, ryhzv), this['currentElement'] = ryhzv, this['locator'] && emocape(this['locator'], ryhzv);for (var buk = 0x0; f_47y > buk; buk++) {
      var d5bw80 = gx$til['getURI'](buk),
          _4vfa = gx$til['getValue'](buk),
          v_4yzf = gx$til['getQName'](buk),
          h$txg = tli['createAttributeNS'](d5bw80, v_4yzf);this['locator'] && emocape(gx$til['getLocator'](buk), h$txg), h$txg['value'] = h$txg['nodeValue'] = _4vfa, ryhzv['setAttributeNode'](h$txg);
    }
  }, 'endElement': function () {
    {
      var xlthrg = this['currentElement'];xlthrg['tagName'];
    }this['currentElement'] = xlthrg['parentNode'];
  }, 'startPrefixMapping': function () {}, 'endPrefixMapping': function () {}, 'processingInstruction': function (v7_4, d69k0b) {
    var ji$nq = this['doc']['createProcessingInstruction'](v7_4, d69k0b);this['locator'] && emocape(this['locator'], ji$nq), ey_fv4z(this, ji$nq);
  }, 'ignorableWhitespace': function () {}, 'characters': function (_acm4) {
    if (_acm4 = emoape['apply'](this, arguments)) {
      if (this['cdata']) var thzrlg = this['doc']['createCDATASection'](_acm4);else var thzrlg = this['doc']['createTextNode'](_acm4);this['currentElement'] ? this['currentElement']['appendChild'](thzrlg) : /^\s*$/['test'](_acm4) && this['doc']['appendChild'](thzrlg), this['locator'] && emocape(this['locator'], thzrlg);
    }
  }, 'skippedEntity': function () {}, 'endDocument': function () {
    this['doc']['normalize']();
  }, 'setDocumentLocator': function (tl$x) {
    (this['locator'] = tl$x) && (tl$x['lineNumber'] = 0x0);
  }, 'comment': function (xtlg$) {
    xtlg$ = emoape['apply'](this, arguments);var dk96 = this['doc']['createComment'](xtlg$);this['locator'] && emocape(this['locator'], dk96), ey_fv4z(this, dk96);
  }, 'startCDATA': function () {
    this['cdata'] = !0x0;
  }, 'endCDATA': function () {
    this['cdata'] = !0x1;
  }, 'startDTD': function (rzgl, jgitx, _o7mca) {
    var k9bd0 = this['doc']['implementation'];if (k9bd0 && k9bd0['createDocumentType']) {
      var xgi$l = k9bd0['createDocumentType'](rzgl, jgitx, _o7mca);this['locator'] && emocape(this['locator'], xgi$l), ey_fv4z(this, xgi$l);
    }
  }, 'warning': function (opec) {
    console['warn']('[xmldom warning]\t' + opec, equ39n(this['locator']));
  }, 'error': function (a7m4v_) {
    console['error']('[xmldom error]\t' + a7m4v_, equ39n(this['locator']));
  }, 'fatalError': function ($qjn) {
    throw console['error']('[xmldom fatalError]\t' + $qjn, equ39n(this['locator'])), $qjn;
  } }, 'endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl'['replace'](/\w+/g, function (rhgzl) {
  evfyh['prototype'][rhgzl] = function () {
    return null;
  };
});var emca_7 = require('./eeesax')['XMLReader'],
    ezhfyvr = exports['DOMImplementation'] = require('./eeedom')['DOMImplementation'];exports['XMLSerializer'] = require('./eeedom')['XMLSerializer'], exports['DOMParser'] = e_7av;