var b = wx.$e;
import e_4yvf from '../eeeesdk/eeesdk.js';window[b[30561]] = { 'wxVersion': window[b[588]][b[30444]] }, window[b[30562]] = ![], window[b[30563]] = 0x1, window[b[30564]] = 0x1, window[b[30565]] = !![], window[b[30566]] = !![], window[b[30567]] = '', window[b[30568]] = ![], window[b[30449]] = { 'base_cdn': b[30569], 'cdn': b[30569] }, e1U0[b[30570]] = {}, e1U0[b[25865]] = '0', e1U0[b[5056]] = window[b[30561]][b[30571]], e1U0[b[30531]] = '', e1U0['os'] = '1', e1U0[b[30572]] = b[30573], e1U0[b[30574]] = b[30575], e1U0[b[30576]] = b[30577], e1U0[b[30578]] = b[30579], e1U0[b[30580]] = b[30581], e1U0[b[24473]] = '1', e1U0[b[26173]] = '', e1U0[b[26175]] = '', e1U0[b[30582]] = 0x0, e1U0[b[30583]] = {}, e1U0[b[30584]] = parseInt(e1U0[b[24473]]), e1U0[b[26171]] = e1U0[b[24473]], e1U0[b[26167]] = {}, e1U0[b[30455]] = b[30585], e1U0[b[30586]] = ![], e1U0[b[12776]] = b[30587], e1U0[b[26139]] = Date[b[87]](), e1U0[b[12372]] = b[30588], e1U0[b[768]] = '_a', e1U0[b[30589]] = 0x2, e1U0[b[109]] = 0x7c1, e1U0[b[30571]] = window[b[30561]][b[30571]], e1U0[b[792]] = ![], e1U0[b[1132]] = ![], e1U0[b[11762]] = ![], e1U0[b[25867]] = ![], window[b[30590]] = 0x5, window[b[30591]] = ![], window[b[30485]] = ![], window[b[30493]] = ![], window[b[30592]] = ![], window[b[30593]] = ![], window[b[30594]] = ![], window[b[30595]] = ![], window[b[30596]] = ![], window[b[30597]] = ![], window[b[30598]] = null, window[b[670]] = function (cepm) {
  console[b[511]](b[670], cepm), wx[b[5337]]({}), wx[b[30473]]({ 'title': b[6726], 'content': cepm, 'success'(gxrl) {
      if (gxrl[b[30599]]) console[b[511]](b[30600]);else gxrl[b[584]] && console[b[511]](b[30601]);
    } });
}, window[b[30602]] = function (js3qnu) {
  console[b[511]](b[30603], js3qnu), e11U0G(), wx[b[30473]]({ 'title': b[6726], 'content': js3qnu, 'confirmText': b[30604], 'cancelText': b[19253], 'success'(u9sbk) {
      if (u9sbk[b[30599]]) window[b[30499]]();else u9sbk[b[584]] && (console[b[511]](b[30605]), wx[b[25863]]({}));
    } });
}, window[b[30606]] = function (zvr4yf) {
  console[b[511]](b[30606], zvr4yf), wx[b[30473]]({ 'title': b[6726], 'content': zvr4yf, 'confirmText': b[26304], 'showCancel': ![], 'complete'(_7ma4) {
      console[b[511]](b[30605]), wx[b[25863]]({});
    } });
}, window[b[30607]] = ![], window[b[30608]] = function (af4_v) {
  window[b[30607]] = !![], wx[b[5336]](af4_v);
}, window[b[30609]] = function () {
  window[b[30607]] && (window[b[30607]] = ![], wx[b[5337]]({}));
}, window[b[30610]] = function (bd06k9) {
  window[b[30461]][b[166]][b[30610]](bd06k9);
}, window[b[12646]] = function (ghlx$t, u6nk9s) {
  e_4yvf[b[12646]](ghlx$t, function (k6b09d) {
    k6b09d && k6b09d[b[14]] ? k6b09d[b[14]][b[1318]] == 0x1 ? u6nk9s(!![]) : (u6nk9s(![]), console[b[82]](b[30611] + k6b09d[b[14]][b[30612]])) : console[b[511]](b[12646], k6b09d);
  });
}, window[b[30613]] = function (vf47a_) {
  console[b[511]](b[30614], vf47a_);
}, window[b[30615]] = function (mc47_a) {}, window[b[30616]] = function (v_f74, ijqu, sub69k) {}, window[b[30617]] = function (qnusj3) {
  console[b[511]](b[30618], qnusj3), window[b[30461]][b[166]][b[30619]](), window[b[30461]][b[166]][b[30620]](), window[b[30461]][b[166]][b[30621]]();
}, window[b[30622]] = function (n6suk9) {
  window[b[30623]](0xe, b[30624] + n6suk9), window[b[30602]](b[30625]);var mc_ao7 = { 'id': window[b[30449]][b[30450]], 'role': window[b[30449]][b[4984]], 'level': window[b[30449]][b[30451]], 'account': window[b[30449]][b[26172]], 'version': window[b[30449]][b[109]], 'cdn': window[b[30449]][b[4861]], 'pkgName': window[b[30449]][b[26173]], 'gamever': window[b[588]][b[30444]], 'serverid': window[b[30449]][b[26167]] ? window[b[30449]][b[26167]][b[11940]] : 0x0, 'systemInfo': window[b[30452]], 'error': b[30626], 'stack': n6suk9 ? n6suk9 : b[30625] },
      zgthr = JSON[b[4847]](mc_ao7);console[b[143]](b[30627] + zgthr), window[b[30455]](zgthr);
}, window[b[30623]] = function (_fv4, aocpm) {
  sendApi(e1U0[b[30576]], b[30628], { 'game_pkg': e1U0[b[26173]], 'partner_id': e1U0[b[24473]], 'server_id': e1U0[b[26167]] && e1U0[b[26167]][b[11940]] > 0x0 ? e1U0[b[26167]][b[11940]] : 0x0, 'uid': e1U0[b[26172]] > 0x0 ? e1U0[b[26172]] : 0x0, 'type': _fv4, 'info': aocpm });
}, window[b[30629]] = function (v_m7a4) {
  var rhvzf = JSON[b[556]](v_m7a4);rhvzf[b[30630]] = window[b[588]][b[30444]], rhvzf[b[30631]] = window[b[30449]][b[26167]] ? window[b[30449]][b[26167]][b[11940]] : 0x0, rhvzf[b[30452]] = window[b[30452]];var tg$j = JSON[b[4847]](rhvzf);console[b[143]](b[30632] + tg$j), window[b[30455]](tg$j);
}, window[b[30500]] = function (flyrz, bsu96k) {
  var mca47_ = { 'id': window[b[30449]][b[30450]], 'role': window[b[30449]][b[4984]], 'level': window[b[30449]][b[30451]], 'account': window[b[30449]][b[26172]], 'version': window[b[30449]][b[109]], 'cdn': window[b[30449]][b[4861]], 'pkgName': window[b[30449]][b[26173]], 'gamever': window[b[588]][b[30444]], 'serverid': window[b[30449]][b[26167]] ? window[b[30449]][b[26167]][b[11940]] : 0x0, 'systemInfo': window[b[30452]], 'error': flyrz, 'stack': bsu96k },
      vyrh = JSON[b[4847]](mca47_);console[b[102]](b[30633] + vyrh), window[b[30455]](vyrh);
}, window[b[30455]] = function (trz) {
  if (window[b[30449]][b[30532]] == b[30634]) return;var ght$x = e1U0[b[30455]] + b[30635] + e1U0[b[26172]];wx[b[506]]({ 'url': ght$x, 'method': b[30636], 'data': trz, 'header': { 'content-type': b[30637], 'cache-control': b[30638] }, 'success': function (a47fv_) {
      DEBUG && console[b[511]](b[30639], ght$x, trz, a47fv_);
    }, 'fail': function (vrh) {
      DEBUG && console[b[511]](b[30639], ght$x, trz, vrh);
    }, 'complete': function () {} });
}, window[b[30640]] = function () {
  function uqj3sn() {
    return ((0x1 + Math[b[130]]()) * 0x10000 | 0x0)[b[288]](0x10)[b[526]](0x1);
  }return uqj3sn() + uqj3sn() + '-' + uqj3sn() + '-' + uqj3sn() + '-' + uqj3sn() + '+' + uqj3sn() + uqj3sn() + uqj3sn();
}, window[b[30499]] = function () {
  console[b[511]](b[30641]);var z4vr = e_4yvf[b[30642]]();e1U0[b[26171]] = z4vr[b[30643]], e1U0[b[30584]] = z4vr[b[30643]], e1U0[b[24473]] = z4vr[b[30643]], e1U0[b[26173]] = z4vr[b[30644]];var j$x3gi = { 'game_ver': e1U0[b[5056]] };e1U0[b[26175]] = this[b[30640]](), e11UG0({ 'title': b[30645] }), e_4yvf[b[392]](j$x3gi, this[b[30646]][b[78]](this));
}, window[b[30646]] = function (ocp7ma) {
  var qju = ocp7ma[b[30647]];sdkInitRes = ocp7ma, console[b[511]](b[30648] + qju + b[30649] + (qju == 0x1) + b[30650] + ocp7ma[b[30444]] + b[30651] + window[b[30561]][b[30571]]);if (!ocp7ma[b[30444]] || window[b[30464]](window[b[30561]][b[30571]], ocp7ma[b[30444]]) < 0x0) console[b[511]](b[30652]), e1U0[b[30574]] = b[30653], e1U0[b[30576]] = b[30654], e1U0[b[30578]] = b[30655], e1U0[b[4861]] = b[30656], e1U0[b[25864]] = b[30657], e1U0[b[30658]] = 'fj', e1U0[b[792]] = ![];else window[b[30464]](window[b[30561]][b[30571]], ocp7ma[b[30444]]) == 0x0 ? (console[b[511]](b[30659]), e1U0[b[30574]] = b[30575], e1U0[b[30576]] = b[30577], e1U0[b[30578]] = b[30579], e1U0[b[4861]] = b[30660], e1U0[b[25864]] = b[30657], e1U0[b[30658]] = b[30661], e1U0[b[792]] = !![]) : (console[b[511]](b[30662]), e1U0[b[30574]] = b[30575], e1U0[b[30576]] = b[30577], e1U0[b[30578]] = b[30579], e1U0[b[4861]] = b[30660], e1U0[b[25864]] = b[30657], e1U0[b[30658]] = b[30661], e1U0[b[792]] = ![]);e1U0[b[30582]] = config[b[30322]] ? config[b[30322]] : 0x0, this[b[30663]](), this[b[30664]](), window[b[30665]] = 0x5, e11UG0({ 'title': b[30666] }), e_4yvf[b[30667]](this[b[30668]][b[78]](this));
}, window[b[30665]] = 0x5, window[b[30668]] = function (d218w, kqs9u) {
  if (d218w == 0x0 && kqs9u && kqs9u[b[30414]]) {
    e1U0[b[30669]] = kqs9u[b[30414]];var $3nqji = this;e11UG0({ 'title': b[30670] }), sendApi(e1U0[b[30574]], b[30671], { 'platform': e1U0[b[30572]], 'partner_id': e1U0[b[24473]], 'token': kqs9u[b[30414]], 'game_pkg': e1U0[b[26173]], 'deviceId': e1U0[b[26175]], 'scene': b[30672] + e1U0[b[30582]] }, this[b[30673]][b[78]](this), e1G0U, e101);
  } else kqs9u && kqs9u[b[26370]] && window[b[30665]] > 0x0 && (kqs9u[b[26370]][b[124]](b[30674]) != -0x1 || kqs9u[b[26370]][b[124]](b[30675]) != -0x1 || kqs9u[b[26370]][b[124]](b[30676]) != -0x1 || kqs9u[b[26370]][b[124]](b[30677]) != -0x1 || kqs9u[b[26370]][b[124]](b[30678]) != -0x1 || kqs9u[b[26370]][b[124]](b[30679]) != -0x1) ? (window[b[30665]]--, e_4yvf[b[30667]](this[b[30668]][b[78]](this))) : (window[b[30623]](0x1, b[30680] + d218w + b[30681] + (kqs9u ? kqs9u[b[26370]] : '')), window[b[30500]](b[30682], JSON[b[4847]]({ 'status': d218w, 'data': kqs9u })), window[b[30602]](b[30683] + (kqs9u && kqs9u[b[26370]] ? '，' + kqs9u[b[26370]] : '')));
}, window[b[30673]] = function (ac7_om) {
  if (!ac7_om) {
    window[b[30623]](0x2, b[30684]), window[b[30500]](b[30685], b[30686]), window[b[30602]](b[30687]);return;
  }if (ac7_om[b[1318]] != b[10313]) {
    window[b[30623]](0x2, b[30688] + ac7_om[b[1318]]), window[b[30500]](b[30685], JSON[b[4847]](ac7_om)), window[b[30602]](b[30689] + ac7_om[b[1318]]);return;
  }e1U0[b[19632]] = String(ac7_om[b[26172]]), e1U0[b[26172]] = String(ac7_om[b[26172]]), e1U0[b[26137]] = String(ac7_om[b[26137]]), e1U0[b[26171]] = String(ac7_om[b[26137]]), e1U0[b[26174]] = String(ac7_om[b[26174]]), e1U0[b[30690]] = String(ac7_om[b[11923]]), e1U0[b[30691]] = String(ac7_om[b[905]]), e1U0[b[11923]] = '';var kqnus = this;e11UG0({ 'title': b[30692] });var u9kns6 = localStorage[b[509]](b[30693] + e1U0[b[26173]] + e1U0[b[26172]]);if (u9kns6 && u9kns6 != '') {
    var wd0b8 = Number(u9kns6);kqnus[b[30694]](wd0b8);
  } else kqnus[b[30695]]();
}, window[b[30695]] = function () {
  var hrfyvz = this;sendApi(e1U0[b[30574]], b[30696], { 'partner_id': e1U0[b[24473]], 'uid': e1U0[b[26172]], 'version': e1U0[b[5056]], 'game_pkg': e1U0[b[26173]], 'device': e1U0[b[26175]] }, hrfyvz[b[30697]][b[78]](hrfyvz), e1G0U, e101);
}, window[b[30697]] = function (txglhr) {
  if (!txglhr) {
    window[b[30623]](0x3, b[30698]), window[b[30602]](b[30698]);return;
  }if (txglhr[b[1318]] != b[10313]) {
    window[b[30623]](0x3, b[30699] + txglhr[b[1318]]), window[b[30602]](b[30699] + txglhr[b[1318]]);return;
  }if (!txglhr[b[14]] || txglhr[b[14]][b[16]] == 0x0) {
    window[b[30623]](0x3, b[30700]), window[b[30602]](b[30701]);return;
  }this[b[30702]](txglhr);
}, window[b[30694]] = function (yflz) {
  var fv4_7a = this;sendApi(e1U0[b[30574]], b[30703], { 'server_id': yflz, 'time': Date[b[87]]() / 0x3e8 }, fv4_7a[b[30704]][b[78]](fv4_7a), e1G0U, e101);
}, window[b[30704]] = function (db058w) {
  if (!db058w) {
    window[b[30623]](0x4, b[30705]), this[b[30695]]();return;
  }if (db058w[b[1318]] != b[10313]) {
    window[b[30623]](0x4, b[30706] + db058w[b[1318]]), this[b[30695]]();return;
  }if (!db058w[b[14]] || db058w[b[14]][b[16]] == 0x0) {
    window[b[30623]](0x4, b[30707]), this[b[30695]]();return;
  }this[b[30702]](db058w), window[b[30461]] && window[b[30461]][b[166]][b[30708]] && window[b[30461]][b[166]][b[30708]](sdkInitRes[b[30709]], sdkInitRes[b[30710]], sdkInitRes[b[30711]], sdkInitRes[b[30712]], sdkInitRes[b[30713]]);
}, window[b[30702]] = function (tzglr) {
  e1U0[b[680]] = tzglr[b[30714]] != undefined ? tzglr[b[30714]] : 0x0, e1U0[b[26167]] = { 'server_id': String(tzglr[b[14]][0x0][b[11940]]), 'server_name': String(tzglr[b[14]][0x0][b[30715]]), 'entry_ip': tzglr[b[14]][0x0][b[26197]], 'entry_port': parseInt(tzglr[b[14]][0x0][b[26198]]), 'status': e1UG1(tzglr[b[14]][0x0]), 'start_time': tzglr[b[14]][0x0][b[30716]], 'cdn': e1U0[b[4861]] }, this[b[30717]]();
}, window[b[30718]] = null, window[b[30717]] = function () {
  var b9ks = this;e_4yvf[b[30719]](function (a4m7_v) {
    console[b[511]](b[30720] + JSON[b[4847]](a4m7_v)), youYiCofig = a4m7_v;window[b[30718]][b[30721]] == 0x1 && (e1U0[b[680]] = 0x0);if (e1U0[b[680]] == 0x1) {
      var $xjig3 = e1U0[b[26167]][b[115]];if ($xjig3 === -0x1 || $xjig3 === 0x0) {
        window[b[30623]](0xf, b[30722] + e1U0[b[26167]]['id'] + b[30723] + e1U0[b[26167]][b[115]]), window[b[30602]]($xjig3 === -0x1 ? b[30724] : b[30725]);return;
      }e101GU(0x0, e1U0[b[26167]][b[11940]]), window[b[30461]][b[166]][b[30726]](e1U0[b[680]]);
    } else window[b[30461]][b[166]][b[30727]](() => {
      var j$xiq3 = window[b[30718]][b[30728]],
          ma7pco = window[b[30718]][b[30721]] == 0x1;ma7pco && window[b[30461]][b[166]][b[30729]](b[30730], j$xiq3, b[30731]);
    }, b9ks), e11U0G();window[b[30596]] = !![], window[b[30486]](), window[b[30487]]();
  });
}, window[b[30732]] = function () {
  e_4yvf[b[30733]](function (b8d50w) {
    console[b[511]](b[30734] + JSON[b[4847]](b8d50w));
  });
}, window[b[30663]] = function () {
  sendApi(e1U0[b[30574]], b[30735], { 'game_pkg': e1U0[b[26173]], 'version_name': e1U0[b[30658]] }, this[b[30736]][b[78]](this), e1G0U, e101);
}, window[b[30736]] = function (d5k60b) {
  if (!d5k60b) {
    window[b[30623]](0x5, b[30737]), window[b[30602]](b[30737]);return;
  }if (d5k60b[b[1318]] != b[10313]) {
    window[b[30623]](0x5, b[30738] + d5k60b[b[1318]]), window[b[30602]](b[30738] + d5k60b[b[1318]]);return;
  }if (!d5k60b[b[14]] || !d5k60b[b[14]][b[5056]]) {
    window[b[30623]](0x5, b[30739] + (d5k60b[b[14]] && d5k60b[b[14]][b[5056]])), window[b[30602]](b[30739] + (d5k60b[b[14]] && d5k60b[b[14]][b[5056]]));return;
  }d5k60b[b[14]][b[30740]] && d5k60b[b[14]][b[30740]][b[16]] > 0xa && (e1U0[b[30741]] = d5k60b[b[14]][b[30740]], e1U0[b[4861]] = d5k60b[b[14]][b[30740]]), d5k60b[b[14]][b[5056]] && (e1U0[b[109]] = d5k60b[b[14]][b[5056]]), console[b[82]](b[26311] + e1U0[b[109]] + b[30742] + e1U0[b[30658]]), window[b[30594]] = !![], window[b[30486]](), window[b[30487]]();
}, window[b[30743]], window[b[30664]] = function () {
  sendApi(e1U0[b[30574]], b[30744], { 'game_pkg': e1U0[b[26173]] }, this[b[30745]][b[78]](this), e1G0U, e101);
}, window[b[30745]] = function (zlrf) {
  if (zlrf && zlrf[b[1318]] === b[10313] && zlrf[b[14]]) {
    window[b[30743]] = zlrf[b[14]];for (var c7mao_ in zlrf[b[14]]) {
      e1U0[c7mao_] = zlrf[b[14]][c7mao_];
    }
  } else window[b[30623]](0xb, b[30746]), console[b[82]](b[30747] + zlrf[b[1318]]);window[b[30595]] = !![], window[b[30487]]();
}, window[b[30748]] = function (bkd065, lzght, d0528, aoecm, us9kn, c7ap, hrfzy, qn93su, fz4_y, y47fv) {
  us9kn = String(us9kn);var iqn3 = hrfzy,
      pmoc7a = qn93su;e1U0[b[30570]][us9kn] = { 'productid': us9kn, 'productname': iqn3, 'productdesc': pmoc7a, 'roleid': bkd065, 'rolename': lzght, 'rolelevel': d0528, 'price': c7ap, 'callback': fz4_y }, sendApi(e1U0[b[30578]], b[30749], { 'game_pkg': e1U0[b[26173]], 'server_id': e1U0[b[26167]][b[11940]], 'server_name': e1U0[b[26167]][b[30715]], 'level': d0528, 'uid': e1U0[b[26172]], 'role_id': bkd065, 'role_name': lzght, 'product_id': us9kn, 'product_name': iqn3, 'product_desc': pmoc7a, 'money': c7ap, 'partner_id': e1U0[b[24473]] }, toPayCallBack, e1G0U, e101);
}, window[b[30750]] = function (_47mv) {
  if (_47mv && (_47mv[b[30751]] === 0xc8 || _47mv[b[1318]] == b[10313])) {
    var w8d0b5 = e1U0[b[30570]][String(_47mv[b[30752]])];if (w8d0b5[b[358]]) w8d0b5[b[358]](_47mv[b[30752]], _47mv[b[30753]], -0x1);e_4yvf[b[30754]]({ 'cpbill': _47mv[b[30753]], 'productid': _47mv[b[30752]], 'productname': w8d0b5[b[30755]], 'productdesc': w8d0b5[b[30756]], 'serverid': e1U0[b[26167]][b[11940]], 'servername': e1U0[b[26167]][b[30715]], 'roleid': w8d0b5[b[30757]], 'rolename': w8d0b5[b[30758]], 'rolelevel': w8d0b5[b[30759]], 'price': w8d0b5[b[27960]], 'extension': JSON[b[4847]]({ 'cp_order_id': _47mv[b[30753]] }) }, function (nksq9u, qx3$ij) {
      w8d0b5[b[358]] && nksq9u == 0x0 && w8d0b5[b[358]](_47mv[b[30752]], _47mv[b[30753]], nksq9u);console[b[82]](JSON[b[4847]]({ 'type': b[30760], 'status': nksq9u, 'data': _47mv, 'role_name': w8d0b5[b[30758]] }));if (nksq9u === 0x0) {} else {
        if (nksq9u === 0x1) {} else {
          if (nksq9u === 0x2) {}
        }
      }
    });
  } else {
    var sj3nq = _47mv ? b[30761] + _47mv[b[30751]] + b[30762] + _47mv[b[1318]] + b[30763] + _47mv[b[82]] : b[30764];window[b[30623]](0xd, b[30765] + sj3nq), alert(sj3nq);
  }
}, window[b[30766]] = function () {}, window[b[30767]] = function (_f7vy4, tlyrhz, d8w251, v4_m, tlxh) {
  e_4yvf[b[30768]](e1U0[b[26167]][b[11940]], e1U0[b[26167]][b[30715]] || e1U0[b[26167]][b[11940]], _f7vy4, tlyrhz, d8w251), sendApi(e1U0[b[30574]], b[30769], { 'game_pkg': e1U0[b[26173]], 'server_id': e1U0[b[26167]][b[11940]], 'role_id': _f7vy4, 'uid': e1U0[b[26172]], 'role_name': tlyrhz, 'role_type': v4_m, 'level': d8w251 });
}, window[b[30770]] = function ($jtgi, j3iuq, ytlrh, bu69s, nsqku9, qs93n, q3$ix, htglrz, xi$tlg, k6b0) {
  e1U0[b[30450]] = $jtgi, e1U0[b[4984]] = j3iuq, e1U0[b[30451]] = ytlrh, e_4yvf[b[30771]](e1U0[b[26167]][b[11940]], e1U0[b[26167]][b[30715]] || e1U0[b[26167]][b[11940]], $jtgi, j3iuq, ytlrh), sendApi(e1U0[b[30574]], b[30772], { 'game_pkg': e1U0[b[26173]], 'server_id': e1U0[b[26167]][b[11940]], 'role_id': $jtgi, 'uid': e1U0[b[26172]], 'role_name': j3iuq, 'role_type': bu69s, 'level': ytlrh, 'evolution': nsqku9 });
}, window[b[30773]] = function (pmae, itj$g, v4ma_7, yvfz4_, w0b85d, grtlxh, c7a4_m, m47a, j3quin, g$ji3x) {
  e1U0[b[30450]] = pmae, e1U0[b[4984]] = itj$g, e1U0[b[30451]] = v4ma_7, e_4yvf[b[30774]](e1U0[b[26167]][b[11940]], e1U0[b[26167]][b[30715]] || e1U0[b[26167]][b[11940]], pmae, itj$g, v4ma_7), sendApi(e1U0[b[30574]], b[30772], { 'game_pkg': e1U0[b[26173]], 'server_id': e1U0[b[26167]][b[11940]], 'role_id': pmae, 'uid': e1U0[b[26172]], 'role_name': itj$g, 'role_type': yvfz4_, 'level': v4ma_7, 'evolution': w0b85d });
}, window[b[30775]] = function (th$) {}, window[b[30776]] = function (lgxth) {
  e_4yvf[b[30777]](b[30777], function (mpo7) {
    lgxth && lgxth(mpo7);
  });
}, window[b[24471]] = function () {
  e_4yvf[b[24471]]();
}, window[b[30778]] = function () {
  e_4yvf[b[24361]]();
}, window[b[30779]] = function (yf74_v, ryhzv, jxig$t, q3niu, qn39u, ij$x, ks9, _m7aoc) {
  _m7aoc = _m7aoc || e1U0[b[26167]][b[11940]], sendApi(e1U0[b[30574]], b[30780], { 'phone': yf74_v, 'role_id': ryhzv, 'uid': e1U0[b[26172]], 'game_pkg': e1U0[b[26173]], 'partner_id': e1U0[b[24473]], 'server_id': _m7aoc }, ks9, 0x2, null, function () {
    return !![];
  });
}, window[b[11268]] = function (lzyth) {
  window[b[30551]] = lzyth, window[b[30551]] && window[b[30550]] && (console[b[82]](b[30552] + window[b[30550]][b[830]]), window[b[30551]](window[b[30550]]), window[b[30550]] = null);
}, window[b[30781]] = function (tgx$, kb0d, tg$l, oc7pma) {
  window[b[26]](b[30782], { 'game_pkg': window[b[30449]][b[26173]], 'role_id': kb0d, 'server_id': tg$l }, oc7pma);
}, window[b[30783]] = function (f47av_, hgrlt, d251) {
  function fyv4z(d06kb9) {
    var afv74 = [],
        f_y4z = [],
        gjix$t = d251 || window[b[588]][b[30784]];for (var sk6ub9 in gjix$t) {
      var gtrxh = Number(sk6ub9);(!f47av_ || !f47av_[b[16]] || f47av_[b[124]](gtrxh) != -0x1) && (f_y4z[b[33]](gjix$t[sk6ub9]), afv74[b[33]]([gtrxh, 0x3]));
    }window[b[30464]](window[b[30465]], b[30785]) >= 0x0 ? (console[b[511]](b[30786]), e_4yvf[b[30787]] && e_4yvf[b[30787]](f_y4z, function (x$thgl) {
      console[b[511]](b[30788]), console[b[511]](x$thgl);if (x$thgl && x$thgl[b[26370]] == b[30789]) for (var uksq9 in gjix$t) {
        if (x$thgl[gjix$t[uksq9]] == b[30790]) {
          var rlgz = Number(uksq9);for (var frzhyv = 0x0; frzhyv < afv74[b[16]]; frzhyv++) {
            if (afv74[frzhyv][0x0] == rlgz) {
              afv74[frzhyv][0x1] = 0x1;break;
            }
          }
        }
      }window[b[30464]](window[b[30465]], b[30791]) >= 0x0 ? wx[b[30792]]({ 'withSubscriptions': !![], 'success': function (zrtylh) {
          var lhrtzy = zrtylh[b[30793]][b[30794]];if (lhrtzy) {
            console[b[511]](b[30795]), console[b[511]](lhrtzy);for (var ui3qn in gjix$t) {
              if (lhrtzy[gjix$t[ui3qn]] == b[30790]) {
                var _fyv4 = Number(ui3qn);for (var pocam = 0x0; pocam < afv74[b[16]]; pocam++) {
                  if (afv74[pocam][0x0] == _fyv4) {
                    afv74[pocam][0x1] = 0x2;break;
                  }
                }
              }
            }console[b[511]](afv74), hgrlt && hgrlt(afv74);
          } else console[b[511]](b[30796]), console[b[511]](zrtylh), console[b[511]](afv74), hgrlt && hgrlt(afv74);
        }, 'fail': function () {
          console[b[511]](b[30797]), console[b[511]](afv74), hgrlt && hgrlt(afv74);
        } }) : (console[b[511]](b[30798] + window[b[30465]]), console[b[511]](afv74), hgrlt && hgrlt(afv74));
    })) : (console[b[511]](b[30799] + window[b[30465]]), console[b[511]](afv74), hgrlt && hgrlt(afv74)), wx[b[30800]](fyv4z);
  }wx[b[30801]](fyv4z);
}, window[b[30802]] = { 'isSuccess': ![], 'level': b[30803], 'isCharging': ![] }, window[b[13668]] = function (b5kd0) {
  wx[b[30542]]({ 'success': function (rflzhy) {
      var yv4_f = window[b[30802]];yv4_f[b[30804]] = !![], yv4_f[b[4960]] = Number(rflzhy[b[4960]])[b[4581]](0x0), yv4_f[b[30545]] = rflzhy[b[30545]], b5kd0 && b5kd0(yv4_f[b[30804]], yv4_f[b[4960]], yv4_f[b[30545]]);
    }, 'fail': function (b5k6) {
      console[b[511]](b[30805], b5k6[b[26370]]);var fzyrhl = window[b[30802]];b5kd0 && b5kd0(fzyrhl[b[30804]], fzyrhl[b[4960]], fzyrhl[b[30545]]);
    } });
}, window[b[12342]] = function (fz_yv) {
  wx[b[12342]]({ 'success': function (tgx$li) {
      fz_yv && fz_yv(!![], tgx$li);
    }, 'fail': function (gtxr) {
      fz_yv && fz_yv(![], gtxr);
    } });
}, window[b[12344]] = function (tgz) {
  if (tgz) wx[b[12344]](tgz);
}, window[b[25859]] = function (amocp7) {
  wx[b[25859]](amocp7);
}, window[b[26]] = function (xgtlhr, epcm, x$qj, $gj, ytlh, apemco, rlgthx, $jqi) {
  if ($gj == undefined) $gj = 0x1;wx[b[506]]({ 'url': xgtlhr, 'method': rlgthx || b[26055], 'responseType': b[4765], 'data': epcm, 'header': { 'content-type': $jqi || b[30637] }, 'success': function (zhlryf) {
      DEBUG && console[b[511]](b[30806], xgtlhr, info, zhlryf);if (zhlryf && zhlryf[b[26440]] == 0xc8) {
        var $lthg = zhlryf[b[14]];!apemco || apemco($lthg) ? x$qj && x$qj($lthg) : window[b[30807]](xgtlhr, epcm, x$qj, $gj, ytlh, apemco, zhlryf);
      } else window[b[30807]](xgtlhr, epcm, x$qj, $gj, ytlh, apemco, zhlryf);
    }, 'fail': function (ghx$t) {
      DEBUG && console[b[511]](b[30808], xgtlhr, info, ghx$t), window[b[30807]](xgtlhr, epcm, x$qj, $gj, ytlh, apemco, ghx$t);
    }, 'complete': function () {} });
}, window[b[30807]] = function (av7, s6u9nk, zgrhlt, k6db9, l$tgix, ijx3q$, k50) {
  k6db9 - 0x1 > 0x0 ? setTimeout(function () {
    window[b[26]](av7, s6u9nk, zgrhlt, k6db9 - 0x1, l$tgix, ijx3q$);
  }, 0x3e8) : l$tgix && l$tgix(JSON[b[4847]]({ 'url': av7, 'response': k50 }));
}, window[b[30809]] = function (xtg$hl, lyfzhr, w5d028, vhrzyf, hrvzy, j3squn, skq) {
  !w5d028 && (w5d028 = {});var igt$j = Math[b[129]](Date[b[87]]() / 0x3e8);w5d028[b[905]] = igt$j, w5d028[b[30810]] = lyfzhr;var ksnq9u = Object[b[280]](w5d028)[b[1137]](),
      yr4vf = '',
      xh$ltg = '';for (var ji$xgt = 0x0; ji$xgt < ksnq9u[b[16]]; ji$xgt++) {
    yr4vf = yr4vf + (ji$xgt == 0x0 ? '' : '&') + ksnq9u[ji$xgt] + w5d028[ksnq9u[ji$xgt]], xh$ltg = xh$ltg + (ji$xgt == 0x0 ? '' : '&') + ksnq9u[ji$xgt] + '=' + encodeURIComponent(w5d028[ksnq9u[ji$xgt]]);
  }yr4vf = yr4vf + e1U0[b[30580]];var hlxt = b[30811] + md5(yr4vf);send(xtg$hl + '?' + xh$ltg + (xh$ltg == '' ? '' : '&') + hlxt, null, vhrzyf, hrvzy, j3squn, skq || function (fv_4) {
    return fv_4[b[1318]] == b[10313];
  }, null, b[30812]);
}, window[b[30813]] = function (ix, m7_a4) {
  var t$lxgi = 0x0;e1U0[b[26167]] && (t$lxgi = e1U0[b[26167]][b[11940]]), sendApi(e1U0[b[30576]], b[30814], { 'partnerId': e1U0[b[24473]], 'gamePkg': e1U0[b[26173]], 'logTime': Math[b[129]](Date[b[87]]() / 0x3e8), 'platformUid': e1U0[b[26174]], 'type': ix, 'serverId': t$lxgi }, null, 0x2, null, function () {
    return !![];
  });
}, window[b[30815]] = function (inj3u) {
  sendApi(e1U0[b[30574]], b[30816], { 'partner_id': e1U0[b[24473]], 'uid': e1U0[b[26172]], 'version': e1U0[b[5056]], 'game_pkg': e1U0[b[26173]], 'device': e1U0[b[26175]] }, e1U0G1, e1G0U, e101);
}, window[b[30817]] = function (c7oa) {
  if (c7oa && c7oa[b[1318]] === b[10313] && c7oa[b[14]]) {
    c7oa[b[14]][b[5942]]({ 'id': -0x2, 'name': b[30818] }), c7oa[b[14]][b[5942]]({ 'id': -0x1, 'name': b[30819] }), e1U0[b[30820]] = c7oa[b[14]];if (window[b[12827]]) window[b[12827]][b[30821]]();
  } else {
    e1U0[b[30822]] = ![];var bw5 = c7oa ? c7oa[b[1318]] : '';window[b[30623]](0x7, b[30823] + bw5), window[b[30602]](b[30824] + bw5);
  }
}, window[b[30825]] = function (fvry4) {
  sendApi(e1U0[b[30574]], b[30826], { 'partner_id': e1U0[b[24473]], 'uid': e1U0[b[26172]], 'version': e1U0[b[5056]], 'game_pkg': e1U0[b[26173]], 'device': e1U0[b[26175]] }, e11UG, e1G0U, e101);
}, window[b[30827]] = function (xtl$ig) {
  e1U0[b[30828]] = ![];if (xtl$ig && xtl$ig[b[1318]] === b[10313] && xtl$ig[b[14]]) {
    for (var xj$iq = 0x0; xj$iq < xtl$ig[b[14]][b[16]]; xj$iq++) {
      xtl$ig[b[14]][xj$iq][b[115]] = e1UG1(xtl$ig[b[14]][xj$iq]);
    }e1U0[b[30583]][-0x1] = window[b[30829]](xtl$ig[b[14]]), window[b[12827]][b[30830]](-0x1);
  } else {
    var b65d8 = xtl$ig ? xtl$ig[b[1318]] : '';window[b[30623]](0x8, b[30831] + b65d8), window[b[30602]](b[30832] + b65d8);
  }
}, window[b[30833]] = function (d521) {
  sendApi(e1U0[b[30574]], b[30826], { 'partner_id': e1U0[b[24473]], 'uid': e1U0[b[26172]], 'version': e1U0[b[5056]], 'game_pkg': e1U0[b[26173]], 'device': e1U0[b[26175]] }, d521, e1G0U, e101);
}, window[b[30834]] = function (gjxit, rtlhg) {
  sendApi(e1U0[b[30574]], b[30835], { 'partner_id': e1U0[b[24473]], 'uid': e1U0[b[26172]], 'version': e1U0[b[5056]], 'game_pkg': e1U0[b[26173]], 'device': e1U0[b[26175]], 'server_group_id': rtlhg }, e1GU1, e1G0U, e101);
}, window[b[30836]] = function (gtilx) {
  e1U0[b[30828]] = ![];if (gtilx && gtilx[b[1318]] === b[10313] && gtilx[b[14]] && gtilx[b[14]][b[14]]) {
    var yfrh = gtilx[b[14]][b[30837]],
        unsq3j = [];for (var maoce = 0x0; maoce < gtilx[b[14]][b[14]][b[16]]; maoce++) {
      gtilx[b[14]][b[14]][maoce][b[115]] = e1UG1(gtilx[b[14]][b[14]][maoce]), (unsq3j[b[16]] == 0x0 || gtilx[b[14]][b[14]][maoce][b[115]] != 0x0) && (unsq3j[unsq3j[b[16]]] = gtilx[b[14]][b[14]][maoce]);
    }e1U0[b[30583]][yfrh] = window[b[30829]](unsq3j), window[b[12827]][b[30830]](yfrh);
  } else {
    var bk06s = gtilx ? gtilx[b[1318]] : '';window[b[30623]](0x9, b[30838] + bk06s), window[b[30602]](b[30839] + bk06s);
  }
}, window[b[30840]] = function (vyzf4r) {
  sendApi(e1U0[b[30574]], b[30841], { 'partner_id': e1U0[b[24473]], 'uid': e1U0[b[26172]], 'version': e1U0[b[5056]], 'game_pkg': e1U0[b[26173]], 'device': e1U0[b[26175]] }, reqServerRecommendCallBack, e1G0U, e101);
}, window[b[30842]] = function (ca_o) {
  e1U0[b[30828]] = ![];if (ca_o && ca_o[b[1318]] === b[10313] && ca_o[b[14]]) {
    for (var uq9kns = 0x0; uq9kns < ca_o[b[14]][b[16]]; uq9kns++) {
      ca_o[b[14]][uq9kns][b[115]] = e1UG1(ca_o[b[14]][uq9kns]);
    }e1U0[b[30583]][-0x2] = window[b[30829]](ca_o[b[14]]), window[b[12827]][b[30830]](-0x2);
  } else {
    var tg$xl = ca_o ? ca_o[b[1318]] : '';window[b[30623]](0xa, b[30843] + tg$xl), alert(b[30844] + tg$xl);
  }
}, window[b[30829]] = function (vzfry) {
  return vzfry;
}, window[b[30845]] = function (xrlt, $jit) {
  xrlt = xrlt || e1U0[b[26167]][b[11940]], sendApi(e1U0[b[30574]], b[30846], { 'type': '4', 'game_pkg': e1U0[b[26173]], 'server_id': xrlt }, $jit);
}, window[b[30847]] = function (bw85, poa7mc, $jtxgi, fz4) {
  $jtxgi = $jtxgi || e1U0[b[26167]][b[11940]], sendApi(e1U0[b[30574]], b[30848], { 'type': bw85, 'game_pkg': poa7mc, 'server_id': $jtxgi }, fz4);
}, window[b[30849]] = function (ns9kuq, yhfzlr) {
  sendApi(e1U0[b[30574]], b[30850], { 'game_pkg': ns9kuq }, yhfzlr);
}, window[b[30851]] = function (j3i$qx) {
  if (j3i$qx) {
    if (j3i$qx[b[115]] == 0x1) {
      if (j3i$qx[b[30852]] == 0x1) return 0x2;else return 0x1;
    } else return j3i$qx[b[115]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window[b[30853]] = function (xlghtr, gxltrh) {
  var d906k = window[b[30718]][b[30721]] == 0x1;if (d906k) {
    var j$3n = window[b[30718]][b[30728]],
        d906k = window[b[30718]][b[30721]] == 0x1;window[b[30461]][b[166]][b[30729]](b[30730], j$3n, b[30731]);return;
  }e1U0[b[30854]] = { 'step': xlghtr, 'server_id': gxltrh };var amv7_ = this;e11UG0({ 'title': b[30855] }), sendApi(e1U0[b[30574]], b[30856], { 'partner_id': e1U0[b[24473]], 'uid': e1U0[b[26172]], 'game_pkg': e1U0[b[26173]], 'server_id': gxltrh, 'platform': e1U0[b[26137]], 'platform_uid': e1U0[b[26174]], 'check_login_time': e1U0[b[30691]], 'check_login_sign': e1U0[b[30690]], 'version_name': e1U0[b[30658]] }, e101UG, e1G0U, e101, function (tjxgi$) {
    return tjxgi$[b[1318]] == b[10313] || tjxgi$[b[82]] == b[30857] || tjxgi$[b[82]] == b[30858];
  });
}, window[b[30859]] = function (jg$x3i) {
  var zyf4_v = this;if (jg$x3i && jg$x3i[b[1318]] === b[10313] && jg$x3i[b[14]]) {
    var vhyfz = e1U0[b[26167]];vhyfz[b[30860]] = e1U0[b[30584]], vhyfz[b[11923]] = String(jg$x3i[b[14]][b[30861]]), vhyfz[b[26139]] = parseInt(jg$x3i[b[14]][b[905]]);if (jg$x3i[b[14]][b[26138]]) vhyfz[b[26138]] = parseInt(jg$x3i[b[14]][b[26138]]);else vhyfz[b[26138]] = parseInt(jg$x3i[b[14]][b[11940]]);vhyfz[b[30862]] = 0x0, vhyfz[b[4861]] = e1U0[b[30741]], vhyfz[b[30863]] = jg$x3i[b[14]][b[30864]], vhyfz[b[30865]] = jg$x3i[b[14]][b[30865]];if (jg$x3i[b[14]][b[26142]]) vhyfz[b[26142]] = parseInt(jg$x3i[b[14]][b[26142]]);console[b[511]](b[30866] + JSON[b[4847]](vhyfz[b[30865]])), e1U0[b[680]] == 0x1 && vhyfz[b[30865]] && vhyfz[b[30865]][b[30867]] == 0x1 && (e1U0[b[30868]] = 0x1, window[b[30461]][b[166]][b[30869]]()), e10G1U();
  } else {
    if (e1U0[b[30854]][b[7511]] >= 0x3) {
      var b8d5w = jg$x3i ? jg$x3i[b[1318]] : '';window[b[30623]](0xc, b[30870] + b8d5w), e101(JSON[b[4847]](jg$x3i)), window[b[30602]](b[30871] + b8d5w);
    } else sendApi(e1U0[b[30574]], b[30671], { 'platform': e1U0[b[30572]], 'partner_id': e1U0[b[24473]], 'token': e1U0[b[30669]], 'game_pkg': e1U0[b[26173]], 'deviceId': e1U0[b[26175]], 'scene': b[30672] + e1U0[b[30582]] }, function (pemcoa) {
      if (!pemcoa || pemcoa[b[1318]] != b[10313]) {
        window[b[30602]](b[30689] + pemcoa && pemcoa[b[1318]]);return;
      }e1U0[b[30690]] = String(pemcoa[b[11923]]), e1U0[b[30691]] = String(pemcoa[b[905]]), setTimeout(function () {
        e101GU(e1U0[b[30854]][b[7511]] + 0x1, e1U0[b[30854]][b[11940]]);
      }, 0x5dc);
    }, e1G0U, e101, function (qjx3i) {
      return qjx3i[b[1318]] == b[10313] || qjx3i[b[1318]] == b[26518];
    });
  }
}, window[b[30872]] = function () {
  ServerLoading[b[166]][b[30726]](e1U0[b[680]]), window[b[30591]] = !![], window[b[30487]]();
}, window[b[30486]] = function () {
  if (window[b[30485]] && window[b[30493]] && window[b[30592]] && window[b[30593]] && window[b[30594]] && window[b[30596]]) {
    if (!window[b[30019]][b[166]]) {
      console[b[511]](b[30873] + window[b[30019]][b[166]]);var hrtgxl = wx[b[30874]](),
          d8w21 = hrtgxl[b[830]] ? hrtgxl[b[830]] : 0x0,
          xlgt$ = { 'cdn': window[b[30449]][b[4861]], 'spareCdn': window[b[30449]][b[25864]], 'newRegister': window[b[30449]][b[680]], 'wxPC': window[b[30449]][b[25867]], 'wxIOS': window[b[30449]][b[1132]], 'wxAndroid': window[b[30449]][b[11762]], 'wxParam': { 'limitLoad': window[b[30449]][b[30533]], 'benchmarkLevel': window[b[30449]][b[30534]], 'wxFrom': window[b[588]][b[30322]] == b[30875] ? 0x1 : 0x0, 'wxSDKVersion': window[b[30465]] }, 'configType': window[b[30449]][b[12372]], 'exposeType': window[b[30449]][b[768]], 'scene': d8w21 };new window[b[30019]](xlgt$, window[b[30449]][b[109]], window[b[30567]]);
    }
  }
}, window[b[30487]] = function () {
  if (window[b[30485]] && window[b[30493]] && window[b[30592]] && window[b[30593]] && window[b[30594]] && window[b[30596]] && window[b[30591]] && window[b[30595]]) {
    e11U0G();if (!e10GU) {
      e10GU = !![];if (!window[b[30019]][b[166]]) window[b[30486]]();var a7copm = 0x0,
          k9sb = wx[b[30876]]();k9sb && (window[b[30449]][b[30529]] && (a7copm = k9sb[b[342]]), console[b[82]](b[30877] + k9sb[b[342]] + b[30878] + k9sb[b[1345]] + b[30879] + k9sb[b[1347]] + b[30880] + k9sb[b[1346]] + b[30881] + k9sb[b[196]] + b[30882] + k9sb[b[197]]));var q$xj3 = {};for (const k6d5b0 in e1U0[b[26167]]) {
        q$xj3[k6d5b0] = e1U0[b[26167]][k6d5b0];
      }var k9ns = { 'channel': window[b[30449]][b[26171]], 'account': window[b[30449]][b[26172]], 'userId': window[b[30449]][b[19632]], 'cdn': window[b[30449]][b[4861]], 'data': window[b[30449]][b[14]], 'package': window[b[30449]][b[25865]], 'newRegister': window[b[30449]][b[680]], 'pkgName': window[b[30449]][b[26173]], 'partnerId': window[b[30449]][b[24473]], 'platform_uid': window[b[30449]][b[26174]], 'deviceId': window[b[30449]][b[26175]], 'selectedServer': q$xj3, 'configType': window[b[30449]][b[12372]], 'exposeType': window[b[30449]][b[768]], 'debugUsers': window[b[30449]][b[12776]], 'wxMenuTop': a7copm, 'wxShield': window[b[30449]][b[792]] };if (window[b[30743]]) for (var _7cmao in window[b[30743]]) {
        k9ns[_7cmao] = window[b[30743]][_7cmao];
      }window[b[30019]][b[166]][b[26189]](k9ns);if (e1U0[b[26167]] && e1U0[b[26167]][b[11940]]) localStorage[b[514]](b[30693] + e1U0[b[26173]] + e1U0[b[26172]], e1U0[b[26167]][b[11940]]);
    }
  } else console[b[82]](b[30883] + window[b[30485]] + b[30884] + window[b[30493]] + b[30885] + window[b[30592]] + b[30886] + window[b[30593]] + b[30887] + window[b[30594]] + b[30888] + window[b[30596]] + b[30889] + window[b[30591]] + b[30890] + window[b[30595]]);
};