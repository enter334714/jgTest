var b = wx.$e;
function evrzyf() {}function ehxlt(n6u9, yvz_f4, rtyzh, njuq3, flzhy) {
  function d9kb0(yhrzlt) {
    if (yhrzlt > 0xffff) {
      yhrzlt -= 0x10000;var ksu6 = 0xd800 + (yhrzlt >> 0xa),
          ns9 = 0xdc00 + (0x3ff & yhrzlt);return String['fromCharCode'](ksu6, ns9);
    }return String['fromCharCode'](yhrzlt);
  }function fvyhr(tgl$xh) {
    var nus96 = tgl$xh['slice'](0x1, -0x1);return nus96 in rtyzh ? rtyzh[nus96] : '#' === nus96['charAt'](0x0) ? d9kb0(parseInt(nus96['substr'](0x1)['replace']('x', '0x'))) : (flzhy['error']('entity not found:' + tgl$xh), tgl$xh);
  }function ca4_7(vm4_a7) {
    if (vm4_a7 > i3jxq$) {
      var sq3u = n6u9['substring'](i3jxq$, vm4_a7)['replace'](/&#?\w+;/g, fvyhr);f_zvy4 && bd8560(i3jxq$), njuq3['characters'](sq3u, 0x0, vm4_a7 - i3jxq$), i3jxq$ = vm4_a7;
    }
  }function bd8560(v7y4_, nusqk9) {
    for (; v7y4_ >= oc7a && (nusqk9 = zlgtrh['exec'](n6u9));) a7f_v4 = nusqk9['index'], oc7a = a7f_v4 + nusqk9[0x0]['length'], f_zvy4['lineNumber']++;f_zvy4['columnNumber'] = v7y4_ - a7f_v4 + 0x1;
  }for (var a7f_v4 = 0x0, oc7a = 0x0, zlgtrh = /.*(?:\r\n?|\n)|.*$/g, f_zvy4 = njuq3['locator'], tlgix$ = [{ 'currentNSMap': yvz_f4 }], q$jx3i = {}, i3jxq$ = 0x0;;) {
    try {
      var qjx = n6u9['indexOf']('<', i3jxq$);if (0x0 > qjx) {
        if (!n6u9['substr'](i3jxq$)['match'](/^\s*$/)) {
          var unj3i = njuq3['doc'],
              mcop = unj3i['createTextNode'](n6u9['substr'](i3jxq$));unj3i['appendChild'](mcop), njuq3['currentElement'] = mcop;
        }return;
      }switch (qjx > i3jxq$ && ca4_7(qjx), n6u9['charAt'](qjx + 0x1)) {case '/':
          var vzr4 = n6u9['indexOf']('>', qjx + 0x3),
              hfzv = n6u9['substring'](qjx + 0x2, vzr4),
              fy74_v = tlgix$['pop']();0x0 > vzr4 ? (hfzv = n6u9['substring'](qjx + 0x2)['replace'](/[\s<].*/, ''), flzhy['error']('end tag name: ' + hfzv + ' is not complete:' + fy74_v['tagName']), vzr4 = qjx + 0x1 + hfzv['length']) : hfzv['match'](/\s</) && (hfzv = hfzv['replace'](/[\s<].*/, ''), flzhy['error']('end tag name: ' + hfzv + ' maybe not complete'), vzr4 = qjx + 0x1 + hfzv['length']);var mcoap = fy74_v['localNSMap'],
              $xgitl = fy74_v['tagName'] == hfzv,
              xlthgr = $xgitl || fy74_v['tagName'] && fy74_v['tagName']['toLowerCase']() == hfzv['toLowerCase']();if (xlthgr) {
            if (njuq3['endElement'](fy74_v['uri'], fy74_v['localName'], hfzv), mcoap) {
              for (var o7c in mcoap) njuq3['endPrefixMapping'](o7c);
            }$xgitl || flzhy['fatalError']('end tag name: ' + hfzv + ' is not match the current start tagName:' + fy74_v['tagName']);
          } else tlgix$['push'](fy74_v);vzr4++;break;case '?':
          f_zvy4 && bd8560(qjx), vzr4 = efv_y7(n6u9, qjx, njuq3);break;case '!':
          f_zvy4 && bd8560(qjx), vzr4 = eaecpmo(n6u9, qjx, njuq3, flzhy);break;default:
          f_zvy4 && bd8560(qjx);var z_vyf4 = new epamo7c(),
              _zv = tlgix$[tlgix$['length'] - 0x1]['currentNSMap'],
              vzr4 = ew51d28(n6u9, qjx, z_vyf4, _zv, fvyhr, flzhy),
              a_7 = z_vyf4['length'];if (!z_vyf4['closed'] && eb9s6(n6u9, vzr4, z_vyf4['tagName'], q$jx3i) && (z_vyf4['closed'] = !0x0, rtyzh['nbsp'] || flzhy['warning']('unclosed xml attribute')), f_zvy4 && a_7) {
            for (var j3$iqx = ehxt$l(f_zvy4, {}), bdw508 = 0x0; a_7 > bdw508; bdw508++) {
              var cam7 = z_vyf4[bdw508];bd8560(cam7['offset']), cam7['locator'] = ehxt$l(f_zvy4, {});
            }njuq3['locator'] = j3$iqx, eixl$(z_vyf4, njuq3, _zv) && tlgix$['push'](z_vyf4), njuq3['locator'] = f_zvy4;
          } else eixl$(z_vyf4, njuq3, _zv) && tlgix$['push'](z_vyf4);'http://www.w3.org/1999/xhtml' !== z_vyf4['uri'] || z_vyf4['closed'] ? vzr4++ : vzr4 = es9kub6(n6u9, vzr4, z_vyf4['tagName'], fvyhr, njuq3);}
    } catch (hlg) {
      flzhy['error']('element parse error: ' + hlg), vzr4 = -0x1;
    }vzr4 > i3jxq$ ? i3jxq$ = vzr4 : ca4_7(Math['max'](qjx, i3jxq$) + 0x1);
  }
}function ehxt$l($jn3i, pcoma) {
  return pcoma['lineNumber'] = $jn3i['lineNumber'], pcoma['columnNumber'] = $jn3i['columnNumber'], pcoma;
}function ew51d28(xi3, iqu, trlhy, _4vfa7, i$q3x, zhtly) {
  for (var q9kusn, nj$3iq, d580w2 = ++iqu, cm47 = emc7;;) {
    var grlhz = xi3['charAt'](d580w2);switch (grlhz) {case '=':
        if (cm47 === ed28w0) q9kusn = xi3['slice'](iqu, d580w2), cm47 = eaf7_v4;else {
          if (cm47 !== eixt) throw new Error('attribute equal must after attrName');cm47 = eaf7_v4;
        }break;case '\x27':case '\x22':
        if (cm47 === eaf7_v4 || cm47 === ed28w0) {
          if (cm47 === ed28w0 && (zhtly['warning']('attribute value must after "="'), q9kusn = xi3['slice'](iqu, d580w2)), iqu = d580w2 + 0x1, d580w2 = xi3['indexOf'](grlhz, iqu), !(d580w2 > 0x0)) throw new Error('attribute value no end \'' + grlhz + '\' match');nj$3iq = xi3['slice'](iqu, d580w2)['replace'](/&#?\w+;/g, i$q3x), trlhy['add'](q9kusn, nj$3iq, iqu - 0x1), cm47 = egxji;
        } else {
          if (cm47 != eva47f_) throw new Error('attribute value must after "="');nj$3iq = xi3['slice'](iqu, d580w2)['replace'](/&#?\w+;/g, i$q3x), trlhy['add'](q9kusn, nj$3iq, iqu), zhtly['warning']('attribute "' + q9kusn + '" missed start quot(' + grlhz + ')!!'), iqu = d580w2 + 0x1, cm47 = egxji;
        }break;case '/':
        switch (cm47) {case emc7:
            trlhy['setTagName'](xi3['slice'](iqu, d580w2));case egxji:case ecpmae:case etylhzr:
            cm47 = etylhzr, trlhy['closed'] = !0x0;case eva47f_:case ed28w0:case eixt:
            break;default:
            throw new Error('attribute invalid close char(\'/\')');}break;case '':
        return zhtly['error']('unexpected end of input'), cm47 == emc7 && trlhy['setTagName'](xi3['slice'](iqu, d580w2)), d580w2;case '>':
        switch (cm47) {case emc7:
            trlhy['setTagName'](xi3['slice'](iqu, d580w2));case egxji:case ecpmae:case etylhzr:
            break;case eva47f_:case ed28w0:
            nj$3iq = xi3['slice'](iqu, d580w2), '/' === nj$3iq['slice'](-0x1) && (trlhy['closed'] = !0x0, nj$3iq = nj$3iq['slice'](0x0, -0x1));case eixt:
            cm47 === eixt && (nj$3iq = q9kusn), cm47 == eva47f_ ? (zhtly['warning']('attribute "' + nj$3iq + '" missed quot(")!!'), trlhy['add'](q9kusn, nj$3iq['replace'](/&#?\w+;/g, i$q3x), iqu)) : ('http://www.w3.org/1999/xhtml' === _4vfa7[''] && nj$3iq['match'](/^(?:disabled|checked|selected)$/i) || zhtly['warning']('attribute "' + nj$3iq + '" missed value!! "' + nj$3iq + '" instead!!'), trlhy['add'](nj$3iq, nj$3iq, iqu));break;case eaf7_v4:
            throw new Error('attribute value missed!!');}return d580w2;case '\u0080':
        grlhz = '\x20';default:
        if ('\x20' >= grlhz) switch (cm47) {case emc7:
            trlhy['setTagName'](xi3['slice'](iqu, d580w2)), cm47 = ecpmae;break;case ed28w0:
            q9kusn = xi3['slice'](iqu, d580w2), cm47 = eixt;break;case eva47f_:
            var nj$3iq = xi3['slice'](iqu, d580w2)['replace'](/&#?\w+;/g, i$q3x);zhtly['warning']('attribute "' + nj$3iq + '" missed quot(")!!'), trlhy['add'](q9kusn, nj$3iq, iqu);case egxji:
            cm47 = ecpmae;} else switch (cm47) {case eixt:
            {
              trlhy['tagName'];
            }'http://www.w3.org/1999/xhtml' === _4vfa7[''] && q9kusn['match'](/^(?:disabled|checked|selected)$/i) || zhtly['warning']('attribute "' + q9kusn + '" missed value!! "' + q9kusn + '" instead2!!'), trlhy['add'](q9kusn, q9kusn, iqu), iqu = d580w2, cm47 = ed28w0;break;case egxji:
            zhtly['warning']('attribute space is required"' + q9kusn + '\x22!!');case ecpmae:
            cm47 = ed28w0, iqu = d580w2;break;case eaf7_v4:
            cm47 = eva47f_, iqu = d580w2;break;case etylhzr:
            throw new Error('elements closed character \'/\' and \'>\' must be connected to');}}d580w2++;
  }
}function eixl$(lhxgt$, k0bs9, k069) {
  for (var b6s09k = lhxgt$['tagName'], zv_fy = null, hyzrl = lhxgt$['length']; hyzrl--;) {
    var nu69s = lhxgt$[hyzrl],
        ksub9 = nu69s['qName'],
        v4yz = nu69s['value'],
        dw05 = ksub9['indexOf'](':');if (dw05 > 0x0) var i$gx3 = nu69s['prefix'] = ksub9['slice'](0x0, dw05),
        b069d = ksub9['slice'](dw05 + 0x1),
        _4m7ac = 'xmlns' === i$gx3 && b069d;else b069d = ksub9, i$gx3 = null, _4m7ac = 'xmlns' === ksub9 && '';nu69s['localName'] = b069d, _4m7ac !== !0x1 && (null == zv_fy && (zv_fy = {}, eji$3g(k069, k069 = {})), k069[_4m7ac] = zv_fy[_4m7ac] = v4yz, nu69s['uri'] = 'http://www.w3.org/2000/xmlns/', k0bs9['startPrefixMapping'](_4m7ac, v4yz));
  }for (var hyzrl = lhxgt$['length']; hyzrl--;) {
    nu69s = lhxgt$[hyzrl];var i$gx3 = nu69s['prefix'];i$gx3 && ('xml' === i$gx3 && (nu69s['uri'] = 'http://www.w3.org/XML/1998/namespace'), 'xmlns' !== i$gx3 && (nu69s['uri'] = k069[i$gx3 || '']));
  }var dw05 = b6s09k['indexOf'](':');dw05 > 0x0 ? (i$gx3 = lhxgt$['prefix'] = b6s09k['slice'](0x0, dw05), b069d = lhxgt$['localName'] = b6s09k['slice'](dw05 + 0x1)) : (i$gx3 = null, b069d = lhxgt$['localName'] = b6s09k);var hrglt = lhxgt$['uri'] = k069[i$gx3 || ''];if (k0bs9['startElement'](hrglt, b069d, b6s09k, lhxgt$), !lhxgt$['closed']) return lhxgt$['currentNSMap'] = k069, lhxgt$['localNSMap'] = zv_fy, !0x0;if (k0bs9['endElement'](hrglt, b069d, b6s09k), zv_fy) {
    for (i$gx3 in zv_fy) k0bs9['endPrefixMapping'](i$gx3);
  }
}function es9kub6(d0kb6, rhfzl, a_m74v, s09bk6, ubk9) {
  if (/^(?:script|textarea)$/i['test'](a_m74v)) {
    var lhrxt = d0kb6['indexOf']('</' + a_m74v + '>', rhfzl),
        vfzr = d0kb6['substring'](rhfzl + 0x1, lhrxt);if (/[&<]/['test'](vfzr)) return (/^script$/i['test'](a_m74v) ? (ubk9['characters'](vfzr, 0x0, vfzr['length']), lhrxt) : (vfzr = vfzr['replace'](/&#?\w+;/g, s09bk6), ubk9['characters'](vfzr, 0x0, vfzr['length']), lhrxt)
    );
  }return rhfzl + 0x1;
}function eb9s6($tgji, i$lg, qi3n$, a_com7) {
  var nj3iu = a_com7[qi3n$];return null == nj3iu && (nj3iu = $tgji['lastIndexOf']('</' + qi3n$ + '>'), i$lg > nj3iu && (nj3iu = $tgji['lastIndexOf']('</' + qi3n$)), a_com7[qi3n$] = nj3iu), i$lg > nj3iu;
}function eji$3g(a4f_v7, in$) {
  for (var tixgl$ in a4f_v7) in$[tixgl$] = a4f_v7[tixgl$];
}function eaecpmo(nq9us, n93q, oa7_, xjgt) {
  var kb5 = nq9us['charAt'](n93q + 0x2);switch (kb5) {case '-':
      if ('-' === nq9us['charAt'](n93q + 0x3)) {
        var hrlt = nq9us['indexOf']('-->', n93q + 0x4);return hrlt > n93q ? (oa7_['comment'](nq9us, n93q + 0x4, hrlt - n93q - 0x4), hrlt + 0x3) : (xjgt['error']('Unclosed comment'), -0x1);
      }return -0x1;default:
      if ('CDATA[' == nq9us['substr'](n93q + 0x3, 0x6)) {
        var hrlt = nq9us['indexOf'](']]>', n93q + 0x9);return oa7_['startCDATA'](), oa7_['characters'](nq9us, n93q + 0x9, hrlt - n93q - 0x9), oa7_['endCDATA'](), hrlt + 0x3;
      }var v4_f7a = eytzl(nq9us, n93q),
          opm7a = v4_f7a['length'];if (opm7a > 0x1 && /!doctype/i['test'](v4_f7a[0x0][0x0])) {
        var nqks9 = v4_f7a[0x1][0x0],
            _f4 = opm7a > 0x3 && /^public$/i['test'](v4_f7a[0x2][0x0]) && v4_f7a[0x3][0x0],
            ma_7c = opm7a > 0x4 && v4_f7a[0x4][0x0],
            fzvy4_ = v4_f7a[opm7a - 0x1];return oa7_['startDTD'](nqks9, _f4 && _f4['replace'](/^(['"])(.*?)\1$/, '$2'), ma_7c && ma_7c['replace'](/^(['"])(.*?)\1$/, '$2')), oa7_['endDTD'](), fzvy4_['index'] + fzvy4_[0x0]['length'];
      }}return -0x1;
}function efv_y7(rhztg, hyrfz, f4va_7) {
  var _4vy = rhztg['indexOf']('?>', hyrfz);if (_4vy) {
    var s9bk6u = rhztg['substring'](hyrfz, _4vy)['match'](/^<\?(\S*)\s*([\s\S]*?)\s*$/);if (s9bk6u) {
      {
        s9bk6u[0x0]['length'];
      }return f4va_7['processingInstruction'](s9bk6u[0x1], s9bk6u[0x2]), _4vy + 0x2;
    }return -0x1;
  }return -0x1;
}function epamo7c() {}function esuqk9n(d2850, gtr) {
  return d2850['__proto__'] = gtr, d2850;
}function eytzl(rhyzf, _fvyz4) {
  var frhyzl,
      juqi3n = [],
      n$3j = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;for (n$3j['lastIndex'] = _fvyz4, n$3j['exec'](rhyzf); frhyzl = n$3j['exec'](rhyzf);) if (juqi3n['push'](frhyzl), frhyzl[0x1]) return juqi3n;
}var ew08bd = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    eryvfhz = new RegExp('[\\-\\.0-9' + ew08bd['source']['slice'](0x1, -0x1) + '\\u00B7\\u0300-\\u036F\\u203F-\\u2040]'),
    ezhyt = new RegExp('^' + ew08bd['source'] + eryvfhz['source'] + '*(?::' + ew08bd['source'] + eryvfhz['source'] + '*)?$'),
    emc7 = 0x0,
    ed28w0 = 0x1,
    eixt = 0x2,
    eaf7_v4 = 0x3,
    eva47f_ = 0x4,
    egxji = 0x5,
    ecpmae = 0x6,
    etylhzr = 0x7;evrzyf['prototype'] = { 'parse': function (rlztyh, fyz4r, fvy7_) {
    var nku96 = this['domBuilder'];nku96['startDocument'](), eji$3g(fyz4r, fyz4r = {}), ehxlt(rlztyh, fyz4r, fvy7_, nku96, this['errorHandler']), nku96['endDocument']();
  } }, epamo7c['prototype'] = { 'setTagName': function (rzyfv) {
    if (!ezhyt['test'](rzyfv)) throw new Error('invalid tagName:' + rzyfv);this['tagName'] = rzyfv;
  }, 'add': function (tglhx$, v7f4_y, zrlth) {
    if (!ezhyt['test'](tglhx$)) throw new Error('invalid attribute:' + tglhx$);this[this['length']++] = { 'qName': tglhx$, 'value': v7f4_y, 'offset': zrlth };
  }, 'length': 0x0, 'getLocalName': function (li$tgx) {
    return this[li$tgx]['localName'];
  }, 'getLocator': function (ns3q9) {
    return this[ns3q9]['locator'];
  }, 'getQName': function (k9b06) {
    return this[k9b06]['qName'];
  }, 'getURI': function (uqni) {
    return this[uqni]['uri'];
  }, 'getValue': function (vma74) {
    return this[vma74]['value'];
  } }, esuqk9n({}, esuqk9n['prototype']) instanceof esuqk9n || (esuqk9n = function (i3njuq, mc7a_4) {
  function cam_74() {}cam_74['prototype'] = mc7a_4, cam_74 = new cam_74();for (mc7a_4 in i3njuq) cam_74[mc7a_4] = i3njuq[mc7a_4];return cam_74;
}), exports['XMLReader'] = evrzyf;