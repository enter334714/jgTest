var b = wx.$e;
(function (window, document, nqs9k) {
  var uk9qns = nqs9k['un'],
      yvrfzh = nqs9k['uns'],
      rytlzh = nqs9k['static'],
      $3jgix = nqs9k['class'],
      wd2815 = nqs9k['getset'],
      hzrfl = nqs9k['__newvec'],
      ks069b = laya['utils']['Browser'],
      hzfrl = laya['events']['Event'],
      _mc = laya['events']['EventDispatcher'],
      p7camo = laya['resource']['HTMLImage'],
      u9nsk6 = laya['utils']['Handler'],
      rthgl = laya['display']['Input'],
      uqin3j = laya['net']['Loader'],
      nqu93s = laya['maths']['Matrix'],
      pcoaem = laya['renders']['Render'],
      fa4_7 = laya['utils']['RunDriver'],
      lg$thx = laya['media']['Sound'],
      fhvryz = laya['media']['SoundChannel'],
      uqnj3s = laya['media']['SoundManager'],
      zhtrly = laya['display']['Stage'],
      wd521 = laya['net']['URL'],
      lgixt$ = laya['utils']['Utils'],
      f4yvrz = function () {
    function $jtxgi() {}return $3jgix($jtxgi, 'laya.wx.mini.MiniAdpter'), $jtxgi['getJson'] = function (rzyf) {
      return JSON['parse'](rzyf);
    }, $jtxgi['init'] = function (dw85b0, yrv) {
      dw85b0 === void 0x0 && (dw85b0 = ![]), yrv === void 0x0 && (yrv = ![]);if ($jtxgi['_inited']) return;$jtxgi['window'] = window;if ($jtxgi['window']['navigator']['userAgent']['indexOf']('MiniGame') < 0x0) return;$jtxgi['_inited'] = !![], $jtxgi['isZiYu'] = yrv, $jtxgi['isPosMsgYu'] = dw85b0, $jtxgi['EnvConfig'] = {}, !$jtxgi['isZiYu'] && (fz4vr['setNativeFileDir']('/layaairGame'), fz4vr['existDir'](fz4vr['fileNativeDir'], u9nsk6['create']($jtxgi, $jtxgi['onMkdirCallBack']))), $jtxgi['window']['focus'] = function () {}, nqs9k['getUrlPath'] = function () {}, $jtxgi['window']['logtime'] = function (zf_yv) {}, $jtxgi['window']['alertTimeLog'] = function (_a47f) {}, $jtxgi['window']['resetShareInfo'] = function () {}, $jtxgi['window']['CanvasRenderingContext2D'] = function () {}, $jtxgi['window']['CanvasRenderingContext2D']['prototype'] = $jtxgi['window']['wx']['createCanvas']()['getContext']('2d')['__proto__'], $jtxgi['window']['document']['body']['appendChild'] = function () {}, $jtxgi['EnvConfig']['pixelRatioInt'] = 0x0, fa4_7['getPixelRatio'] = $jtxgi['pixelRatio'], $jtxgi['_preCreateElement'] = ks069b['createElement'], ks069b['createElement'] = $jtxgi['createElement'], fa4_7['createShaderCondition'] = $jtxgi['createShaderCondition'], lgixt$['parseXMLFromString'] = $jtxgi['parseXMLFromString'], rthgl['_createInputElement'] = j3uiq['_createInputElement'], $jtxgi['EnvConfig']['load'] = uqin3j['prototype']['load'], uqin3j['prototype']['load'] = q3jus['prototype']['load'], $jtxgi['isZiYu'] && dw85b0 && wx['onMessage'](function (ig$tjx) {
        ig$tjx['isLoad'] && (fz4vr['ziyuFileData'][ig$tjx['url']] = ig$tjx['data']);
      });
    }, $jtxgi['onMkdirCallBack'] = function (zrfvy, rlhxgt) {
      if (!zrfvy) fz4vr['filesListObj'] = JSON['parse'](rlhxgt['data']);
    }, $jtxgi['pixelRatio'] = function () {
      if (!$jtxgi['EnvConfig']['pixelRatioInt']) try {
        var jn3ui = wx['getSystemInfoSync']();return $jtxgi['EnvConfig']['pixelRatioInt'] = jn3ui['pixelRatio'], jn3ui = jn3ui, jn3ui['pixelRatio'];
      } catch (bs9k6) {}return $jtxgi['EnvConfig']['pixelRatioInt'];
    }, $jtxgi['createElement'] = function (ryhv) {
      if (ryhv == 'canvas') {
        var l$hxtg;return $jtxgi['idx'] == 0x1 ? $jtxgi['isZiYu'] ? (l$hxtg = sharedCanvas, l$hxtg['style'] = {}) : l$hxtg = window['canvas'] : l$hxtg = window['wx']['createCanvas'](), $jtxgi['idx']++, l$hxtg;
      } else {
        if (ryhv == 'textarea' || ryhv == 'input') return $jtxgi['onCreateInput'](ryhv);else {
          if (ryhv == 'div') {
            var z4rfy = $jtxgi['_preCreateElement'](ryhv);return z4rfy['contains'] = function (nsujq3) {
              return null;
            }, z4rfy['removeChild'] = function (lxthg$) {}, z4rfy;
          } else return $jtxgi['_preCreateElement'](ryhv);
        }
      }
    }, $jtxgi['onCreateInput'] = function (v4m_7a) {
      var lrhyfz = $jtxgi['_preCreateElement'](v4m_7a);return lrhyfz['focus'] = j3uiq['wxinputFocus'], lrhyfz['blur'] = j3uiq['wxinputblur'], lrhyfz['style'] = {}, lrhyfz['value'] = 0x0, lrhyfz['parentElement'] = {}, lrhyfz['placeholder'] = {}, lrhyfz['type'] = {}, lrhyfz['setColor'] = function (t$h) {}, lrhyfz['setType'] = function (rghtx) {}, lrhyfz['setFontFace'] = function (iqnj3$) {}, lrhyfz['addEventListener'] = function (bd5860) {}, lrhyfz['contains'] = function (a74m_c) {
        return null;
      }, lrhyfz['removeChild'] = function (nq9us) {}, lrhyfz;
    }, $jtxgi['createShaderCondition'] = function (hytrlz) {
      var j3nsuq = this,
          _4cam7 = function () {
        var b6kd5 = hytrlz;return j3nsuq[hytrlz['replace']('this.', '')];
      };return _4cam7;
    }, $jtxgi['EnvConfig'] = null, $jtxgi['window'] = null, $jtxgi['_preCreateElement'] = null, $jtxgi['_inited'] = ![], $jtxgi['wxRequest'] = null, $jtxgi['systemInfo'] = null, $jtxgi['version'] = '0.0.1', $jtxgi['isZiYu'] = ![], $jtxgi['isPosMsgYu'] = ![], $jtxgi['parseXMLFromString'] = function (m7cap) {
      var rlhgxt, cepma;m7cap = m7cap['replace'](/>\s+</g, '><');try {
        rlhgxt = new window['Parser']['DOMParser']()['parseFromString'](m7cap, 'text/xml');
      } catch (y_v) {
        throw '需要引入xml解析库文件';
      }return rlhgxt;
    }, $jtxgi['idx'] = 0x1, $jtxgi;
  }(),
      q$i3n = function () {
    function ksb609() {}$3jgix(ksb609, 'laya.wx.mini.MiniImage');var aomc7_ = ksb609['prototype'];return aomc7_['_loadImage'] = function (vrzfh) {
      var lixtg = this,
          ix$3g = ![];vrzfh['indexOf']('layaNativeDir/') == -0x1 && (ix$3g = !![], vrzfh = wd521['formatURL'](vrzfh));if (!fz4vr['getFileInfo'](vrzfh)) {
        if (vrzfh['indexOf']('http://') != -0x1 || vrzfh['indexOf']('https://') != -0x1) fz4vr['downImg'](vrzfh, new u9nsk6(ksb609, ksb609['onDownImgCallBack'], [vrzfh, lixtg]), vrzfh);else ksb609['onCreateImage'](vrzfh, lixtg, !![]);
      } else ksb609['onCreateImage'](vrzfh, lixtg, !ix$3g);
    }, ksb609['onDownImgCallBack'] = function (yzlhrt, _vyzf4, su6n) {
      if (!su6n) ksb609['onCreateImage'](yzlhrt, _vyzf4);else _vyzf4['onError'](null);
    }, ksb609['onCreateImage'] = function (m47av_, _47vm, hlx$g) {
      hlx$g === void 0x0 && (hlx$g = ![]);var k096b;if (!hlx$g) {
        var _zf4vy = fz4vr['getFileInfo'](m47av_),
            dw8b05 = _zf4vy['md5'];k096b = fz4vr['getFileNativePath'](dw8b05);
      } else k096b = m47av_;if (_47vm['imgCache'] == null) _47vm['imgCache'] = {};var d805w;function $i3xq() {
        d805w['onload'] = null, d805w['onerror'] = null, delete _47vm['imgCache'][m47av_];
      };var rlyfhz = function () {
        $i3xq(), _47vm['onLoaded'](d805w);
      },
          d508b = function () {
        $i3xq(), _47vm['event']('error', 'Load image failed');
      };_47vm['_type'] == 'nativeimage' ? (d805w = new ks069b['window']['Image'](), d805w['crossOrigin'] = '', d805w['onload'] = rlyfhz, d805w['onerror'] = d508b, d805w['src'] = k096b, _47vm['imgCache'][m47av_] = d805w) : new p7camo['create'](k096b, { 'onload': rlyfhz, 'onerror': d508b, 'onCreate': function (sn3uqj) {
          d805w = sn3uqj, _47vm['imgCache'][m47av_] = sn3uqj;
        } });
    }, ksb609;
  }(),
      j3uiq = function () {
    function lxh$() {}return $3jgix(lxh$, 'laya.wx.mini.MiniInput'), lxh$['_createInputElement'] = function () {
      rthgl['_initInput'](rthgl['area'] = ks069b['createElement']('textarea')), rthgl['_initInput'](rthgl['input'] = ks069b['createElement']('input')), rthgl['inputContainer'] = ks069b['createElement']('div'), rthgl['inputContainer']['style']['position'] = 'absolute', rthgl['inputContainer']['style']['zIndex'] = 0x186a0, ks069b['container']['appendChild'](rthgl['inputContainer']), rthgl['inputContainer']['setPos'] = function (s9n3uq, u6bsk9) {
        rthgl['inputContainer']['style']['left'] = s9n3uq + 'px', rthgl['inputContainer']['style']['top'] = u6bsk9 + 'px';
      }, nqs9k['stage']['on']('resize', null, lxh$['_onStageResize']), wx['onWindowResize'] && wx['onWindowResize'](function (tg) {
        window['dispatchEvent'] && window['dispatchEvent']('resize');
      }), uqnj3s['_soundClass'] = omacpe, uqnj3s['_musicClass'] = omacpe, window['_videoClass'] = glrhtz;
    }, lxh$['_onStageResize'] = function () {
      var gt$xi = nqs9k['stage']['_canvasTransform']['identity']();gt$xi['scale'](ks069b['width'] / pcoaem['canvas']['width'] / fa4_7['getPixelRatio'](), ks069b['height'] / pcoaem['canvas']['height'] / fa4_7['getPixelRatio']());
    }, lxh$['wxinputFocus'] = function (f4yz_v) {
      var ghrztl = rthgl['inputElement']['target'];if (ghrztl && !ghrztl['editable']) return;f4yvrz['window']['wx']['offKeyboardConfirm'](), f4yvrz['window']['wx']['offKeyboardInput'](), f4yvrz['window']['wx']['showKeyboard']({ 'defaultValue': ghrztl['text'], 'maxLength': ghrztl['maxChars'], 'multiple': ghrztl['multiline'], 'confirmHold': !![], 'confirmType': 'done', 'success': function (bk9su) {}, 'fail': function (q3inj$) {} }), f4yvrz['window']['wx']['onKeyboardConfirm'](function (y7vf_) {
        var ijun3q = y7vf_ ? y7vf_['value'] : '';ghrztl['text'] = ijun3q, ghrztl['event']('input'), laya['wx']['mini']['MiniInput']['inputEnter']();
      }), f4yvrz['window']['wx']['onKeyboardInput'](function (gjti$x) {
        var mv74_a = gjti$x ? gjti$x['value'] : '';if (!ghrztl['multiline']) {
          if (mv74_a['indexOf']('\x0a') != -0x1) {
            laya['wx']['mini']['MiniInput']['inputEnter']();return;
          }
        }ghrztl['text'] = mv74_a, ghrztl['event']('input');
      });
    }, lxh$['inputEnter'] = function () {
      rthgl['inputElement']['target']['focus'] = ![];
    }, lxh$['wxinputblur'] = function () {
      lxh$['hideKeyboard']();
    }, lxh$['hideKeyboard'] = function () {
      f4yvrz['window']['wx']['offKeyboardConfirm'](), f4yvrz['window']['wx']['offKeyboardInput'](), f4yvrz['window']['wx']['hideKeyboard']({ 'success': function (nksu9) {
          console['log']('隐藏键盘');
        }, 'fail': function (f_4v7) {
          console['log']('隐藏键盘出错:' + (f_4v7 ? f_4v7['errMsg'] : ''));
        } });
    }, lxh$;
  }(),
      q3jus = function () {
    function yzf4r() {}$3jgix(yzf4r, 'laya.wx.mini.MiniLoader');var c_ao7m = yzf4r['prototype'];return c_ao7m['load'] = function (n6ku9s, f_a4v, _74v, k9suqn, xg$hl) {
      _74v === void 0x0 && (_74v = !![]), xg$hl === void 0x0 && (xg$hl = ![]);var $jixtg = this;$jixtg['_url'] = n6ku9s;if (n6ku9s['indexOf']('data:image') === 0x0) $jixtg['_type'] = f_a4v = 'image';else $jixtg['_type'] = f_a4v || (f_a4v = $jixtg['getTypeFromUrl'](n6ku9s));$jixtg['_cache'] = _74v, $jixtg['_data'] = null;var in3ju = 'ascii';if (n6ku9s['indexOf']('.fnt') != -0x1) in3ju = 'utf8';else f_a4v == 'arraybuffer' && (in3ju = '');;var lgthx = lgixt$['getFileExtension'](n6ku9s);if (yzf4r['_fileTypeArr']['indexOf'](lgthx) != -0x1) f4yvrz['EnvConfig']['load']['call'](this, n6ku9s, f_a4v, _74v, k9suqn, xg$hl);else {
        if (!fz4vr['getFileInfo'](n6ku9s)) {
          if (n6ku9s['indexOf']('layaNativeDir/') != -0x1) {
            if (f4yvrz['isZiYu']) {
              var hrzylf = fz4vr['ziyuFileData'][n6ku9s];$jixtg['onLoaded'](hrzylf);return;
            } else {
              cosnole['log']('read read'), fz4vr['read'](n6ku9s, in3ju, new u9nsk6(yzf4r, yzf4r['onReadNativeCallBack'], [in3ju, n6ku9s, f_a4v, _74v, k9suqn, xg$hl, $jixtg]));return;
            }
          }if (wd521['rootPath'] == '') var m7_ac = n6ku9s;else m7_ac = n6ku9s['split'](wd521['rootPath'])[0x0];n6ku9s['indexOf']('http://') != -0x1 || n6ku9s['indexOf']('https://') != -0x1 ? f4yvrz['EnvConfig']['load']['call']($jixtg, n6ku9s, f_a4v, _74v, k9suqn, xg$hl) : fz4vr['readFile'](m7_ac, in3ju, new u9nsk6(yzf4r, yzf4r['onReadNativeCallBack'], [in3ju, n6ku9s, f_a4v, _74v, k9suqn, xg$hl, $jixtg]), n6ku9s);
        } else f4yvrz['EnvConfig']['load']['call'](this, n6ku9s, f_a4v, _74v, k9suqn, xg$hl);
      }
    }, c_ao7m['resMgrLoad'] = function (yzrlh, nsju3q, b0k56, dk690, lgxhr, xgjit, zvfr4) {
      b0k56 === void 0x0 && (b0k56 = 0x0), dk690 === void 0x0 && (dk690 = ![]), lgxhr === void 0x0 && (lgxhr = ![]), xgjit === void 0x0 && (xgjit = 0x0), zvfr4 === void 0x0 && (zvfr4 = 0x3), yzrlh['indexOf']('mpack') != -0x1 && console['log']('=============resMgrLoad url:', yzrlh), f4yvrz['EnvConfig']['resMgrLoad'](yzrlh, (qi$j3n, zyhf, b056k) => {
        yzf4r['prototype']['resMgrLoadCallBack'](qi$j3n, zyhf, b056k, nsju3q);
      }, b0k56, dk690, lgxhr, xgjit, zvfr4);
    }, c_ao7m['resMgrLoadCallBack'] = function (jiq3, un39, db0k5, oeapc) {
      console['log']('buff:::', jiq3, db0k5, fz4vr['fileNativeDir'] + '///' + fz4vr['fileListName']), oeapc(jiq3, un39, db0k5);
    }, c_ao7m['clearRes'] = function (nk9us, m4) {
      m4 === void 0x0 && (m4 = ![]);var mocap7 = this;mocap7['clearRes'](nk9us, m4);var yvf4z = fz4vr['getFileInfo'](nk9us);if (yvf4z && (nk9us['indexOf']('http://') != -0x1 || nk9us['indexOf']('https://') != -0x1)) {
        var squ9n = yvf4z['md5'],
            zfy4r = fz4vr['getFileNativePath'](squ9n);fz4vr['remove'](zfy4r);
      }
    }, yzf4r['onReadNativeCallBack'] = function (pmaceo, sq93un, rhlz, a7p, cmoaep, _mcoa7, tlxg$, q$ij, c7ma) {
      a7p === void 0x0 && (a7p = !![]), _mcoa7 === void 0x0 && (_mcoa7 = ![]), q$ij === void 0x0 && (q$ij = 0x0);if (!q$ij) {
        var hgrzl;if (rhlz == 'json' || rhlz == 'atlas') hgrzl = f4yvrz['getJson'](c7ma['data']);else rhlz == 'xml' ? hgrzl = lgixt$['parseXMLFromString'](c7ma['data']) : hgrzl = c7ma['data'];tlxg$['onLoaded'](hgrzl), !f4yvrz['isZiYu'] && f4yvrz['isPosMsgYu'] && rhlz != 'arraybuffer' && wx['postMessage']({ 'url': sq93un, 'data': hgrzl, 'isLoad': !![] });
      } else q$ij == 0x1 && f4yvrz['EnvConfig']['load']['call'](tlxg$, sq93un, rhlz, a7p, cmoaep, _mcoa7);
    }, rytlzh(yzf4r, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['png', 'jpg', 'bmp', 'jpeg', 'gif'];
    }]), yzf4r;
  }(),
      fz4vr = function (w025d) {
    function w8215() {
      w8215['__super']['call'](this);;
    }return $3jgix(w8215, 'laya.wx.mini.MiniFileMgr', w025d), w8215['isLoadFile'] = function (d0856) {
      return w8215['_fileTypeArr']['indexOf'](d0856) != -0x1 ? !![] : ![];
    }, w8215['getFileInfo'] = function (gxit$) {
      var a7_4mv = gxit$['split']('?')[0x0],
          hryzt = w8215['filesListObj'][a7_4mv];if (hryzt == null) return null;else return hryzt;return null;
    }, w8215['onFileUpdate'] = function (v47f_, j3nqus) {
      var in3j$q = v47f_['split']('/'),
          w52d8 = in3j$q[in3j$q['length'] - 0x1],
          kus9 = w8215['getFileInfo'](j3nqus);if (kus9 == null) w8215['onSaveFile'](j3nqus, w52d8);else {
        if (kus9['readyUrl'] != j3nqus) w8215['remove'](w52d8, j3nqus);
      }
    }, w8215['exits'] = function (inqj3, jiqx$3) {
      var tlgrhx = w8215['getFileNativePath'](inqj3);w8215['fs']['getFileInfo']({ 'filePath': tlgrhx, 'success': function (ujqni) {
          jiqx$3 != null && jiqx$3['runWith']([0x0, ujqni]);
        }, 'fail': function (nujqs3) {
          jiqx$3 != null && jiqx$3['runWith']([0x1, nujqs3]);
        } });
    }, w8215['read'] = function (f74_, mocpae, $hlgtx, sj3uqn) {
      mocpae === void 0x0 && (mocpae = 'ascill'), sj3uqn === void 0x0 && (sj3uqn = '');var ixq$3;sj3uqn != '' ? ixq$3 = w8215['getFileNativePath'](f74_) : ixq$3 = f74_, w8215['fs']['readFile']({ 'filePath': ixq$3, 'encoding': mocpae, 'success': function (opemc) {
          $hlgtx != null && $hlgtx['runWith']([0x0, opemc]);
        }, 'fail': function (thlry) {
          if (thlry && sj3uqn != '') w8215['down'](sj3uqn, mocpae, $hlgtx, sj3uqn);else $hlgtx != null && $hlgtx['runWith']([0x1]);
        } });
    }, w8215['readNativeFile'] = function (rlzhf, u3qjns) {
      w8215['fs']['readFile']({ 'filePath': rlzhf, 'encoding': '', 'success': function (_4f) {
          u3qjns != null && u3qjns['runWith']([0x0]);
        }, 'fail': function (kb60s9) {
          u3qjns != null && u3qjns['runWith']([0x1]);
        } });
    }, w8215['down'] = function (pacem, q9sun, opcame, _a4v) {
      q9sun === void 0x0 && (q9sun = 'ascill'), _a4v === void 0x0 && (_a4v = '');var vm47a_ = w8215['getFileNativePath'](_a4v),
          yzfvr = w8215['wxdown']({ 'url': pacem, 'filePath': vm47a_, 'success': function (oc7_m) {
          if (oc7_m['statusCode'] === 0xc8) w8215['readFile'](oc7_m['filePath'], q9sun, opcame, _a4v);
        }, 'fail': function (v74_) {
          opcame != null && opcame['runWith']([0x1, v74_]);
        } });yzfvr['onProgressUpdate'](function (suqnj3) {
        opcame != null && opcame['runWith']([0x2, suqnj3['progress']]);
      });
    }, w8215['readFile'] = function (snquj, jnuq3i, fzlryh, fy7v_) {
      jnuq3i === void 0x0 && (jnuq3i = 'ascill'), fy7v_ === void 0x0 && (fy7v_ = ''), w8215['fs']['readFile']({ 'filePath': snquj, 'encoding': jnuq3i, 'success': function (ijn3uq) {
          if (snquj['indexOf']('http://') != -0x1 || snquj['indexOf']('https://') != -0x1) w8215['onFileUpdate'](snquj, fy7v_);fzlryh != null && fzlryh['runWith']([0x0, ijn3uq]);
        }, 'fail': function (sqju3n) {
          if (sqju3n) fzlryh != null && fzlryh['runWith']([0x1, sqju3n]);
        } });
    }, w8215['downImg'] = function (squn9, ztylrh, ijxg) {
      ijxg === void 0x0 && (ijxg = '');var fv_z = w8215['wxdown']({ 'url': squn9, 'success': function (m7c4) {
          m7c4['statusCode'] === 0xc8 && w8215['copyFile'](m7c4['tempFilePath'], ijxg, ztylrh);
        }, 'fail': function (apmoc7) {
          ztylrh != null && ztylrh['runWith']([0x1, apmoc7]);
        } });
    }, w8215['copyFile'] = function (a_7f4, trhzl, hlxrt) {
      var d2w81 = a_7f4['split']('/'),
          a7f4v = d2w81[d2w81['length'] - 0x1],
          qxj$3 = trhzl['split']('?')[0x0],
          xhtlg = w8215['getFileInfo'](trhzl),
          x$glh = w8215['getFileNativePath'](a7f4v);w8215['fs']['copyFile']({ 'srcPath': a_7f4, 'destPath': x$glh, 'success': function (thlyrz) {
          if (!xhtlg) w8215['onSaveFile'](trhzl, a7f4v), hlxrt != null && hlxrt['runWith']([0x0]);else {
            if (xhtlg['readyUrl'] != trhzl) w8215['remove'](a7f4v, trhzl, hlxrt);
          }
        }, 'fail': function (av_f47) {
          hlxrt != null && hlxrt['runWith']([0x1, av_f47]);
        } });
    }, w8215['getFileNativePath'] = function (qin3$) {
      return laya['wx']['mini']['MiniFileMgr']['fileNativeDir'] + '/' + qin3$;
    }, w8215['remove'] = function (pcoma7, rzltgh, gxt$h) {
      rzltgh === void 0x0 && (rzltgh = '');var q9ns3u = w8215['getFileInfo'](rzltgh),
          xlrhgt = w8215['getFileNativePath'](q9ns3u['md5']);nqs9k['loader']['clearRes'](q9ns3u['readyUrl']), w8215['fs']['unlink']({ 'filePath': xlrhgt, 'success': function (gxh$t) {
          if (rzltgh != '') w8215['onSaveFile'](rzltgh, pcoma7);gxt$h != null && gxt$h['runWith']([0x0]);
        }, 'fail': function (vh) {} });
    }, w8215['onSaveFile'] = function (ij$3qn, a_o7c) {
      var z_4 = ij$3qn['split']('?')[0x0];w8215['filesListObj'][z_4] = { 'md5': a_o7c, 'readyUrl': ij$3qn }, w8215['fs']['writeFile']({ 'filePath': w8215['fileNativeDir'] + '/' + w8215['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](w8215['filesListObj']), 'success': function (yrhlzt) {
          console['log']('写入测试测试成功：', yrhlzt);
        }, 'fail': function (a4m7_c) {
          console['log']('写入测试测试失败：', a4m7_c);
        } });
    }, w8215['existDir'] = function (n9uk6s, d80w52) {
      w8215['fs']['mkdir']({ 'dirPath': n9uk6s, 'success': function (db09k) {
          d80w52 != null && d80w52['runWith']([0x0, { 'data': JSON['stringify']({}) }]);
        }, 'fail': function (suk96) {
          if (suk96['errMsg']['indexOf']('file already exists') != -0x1) w8215['readSync'](w8215['fileListName'], 'utf8', d80w52);else d80w52 != null && d80w52['runWith']([0x1, suk96]);
        } });
    }, w8215['readSync'] = function (igjx$3, snku9q, k056d, ixl$tg) {
      snku9q === void 0x0 && (snku9q = 'ascill'), ixl$tg === void 0x0 && (ixl$tg = '');var a_mv = w8215['getFileNativePath'](igjx$3),
          snjqu;try {
        snjqu = w8215['fs']['readFileSync'](a_mv), k056d != null && k056d['runWith']([0x0, { 'data': snjqu }]);
      } catch (t$xhg) {
        k056d != null && k056d['runWith']([0x1]);
      }
    }, w8215['readCache'] = function () {}, w8215['writeCache'] = function (oem) {
      var rlzt = readyUrl['split']('?')[0x0];w8215['filesListObj'][rlzt] = { 'md5': md5Name, 'readyUrl': readyUrl }, w8215['fs']['writeFile']({ 'filePath': w8215['fileNativeDir'] + '/' + w8215['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](w8215['filesListObj']), 'success': function ($xgji3) {}, 'fail': function (eamop) {} });
    }, w8215['setNativeFileDir'] = function (k5d6b0) {
      w8215['fileNativeDir'] = wx['env']['USER_DATA_PATH'] + k5d6b0;
    }, w8215['filesListObj'] = {}, w8215['fileNativeDir'] = null, w8215['fileListName'] = 'layaairfiles.txt', w8215['ziyuFileData'] = {}, rytlzh(w8215, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['json', 'ani', 'xml', 'sk', 'txt', 'atlas', 'swf', 'part', 'fnt', 'proto', 'lh', 'lav', 'lani', 'lmat', 'lm', 'ltc'];
    }, 'fs', function () {
      return this['fs'] = wx['getFileSystemManager']();
    }, 'wxdown', function () {
      return this['wxdown'] = wx['downloadFile'];
    }]), w8215;
  }(_mc),
      omacpe = function (s9nq3u) {
    function kb5d06() {
      this['_sound'] = null, this['_chanell'] = null, this['url'] = null, this['loaded'] = ![], kb5d06['__super']['call'](this), this['_sound'] = kb5d06['_createSound'](), this['_chanell'] = new kn9u6(this['_sound']);
    }$3jgix(kb5d06, 'laya.wx.mini.MiniSound', s9nq3u);var copam = kb5d06['prototype'];return copam['load'] = function (k096s) {
      var ylrthz = this;k096s = wd521['formatURL'](k096s), this['url'] = k096s;if (kb5d06['_audioCache'][k096s]) {
        this['event']('complete');return;
      }function qj3us() {
        if (kb5d06['_null'] != undefined) ylrthz['_sound']['onCanplay'](kb5d06['_null']), ylrthz['_sound']['onError'](kb5d06['_null']);else try {
          ylrthz['_sound']['onCanplay'](null), ylrthz['_sound']['onError'](null), kb5d06['_null'] = null;
        } catch (v7af_4) {
          console['warn']('[wxmini] _clearSound:' + v7af_4), ylrthz['_sound']['onCanplay'](_am74), ylrthz['_sound']['onError'](_am74), kb5d06['_null'] = _am74;
        }
      }function kusqn9() {
        yr4fv['loaded'] = !![], yr4fv['event']('complete'), kb5d06['_audioCache'][yr4fv['url']] = yr4fv;
      }function v47y_f(q3ni) {
        console['error']('errCode=' + q3ni['errCode'] + '  errMsg=' + q3ni['errMsg']), yr4fv['event']('error');
      }function _am74() {}this['_sound']['onCanplay'](kusqn9), this['_sound']['onError'](v47y_f), this['_sound']['src'] = k096s;var yr4fv = this;
    }, copam['play'] = function (caeom, $gj3x) {
      caeom === void 0x0 && (caeom = 0x0), $gj3x === void 0x0 && ($gj3x = 0x0);var fv7y4_, kn6u;if (this['url'] == uqnj3s['_tMusic']) {
        if (!kb5d06['_musicAudio']) kb5d06['_musicAudio'] = this['_sound'];fv7y4_ = kb5d06['_musicAudio'], kn6u = this['_chanell'];
      } else fv7y4_ = this['_sound'], kn6u = this['_chanell'];return fv7y4_['src'] = this['url'], fv7y4_['startTime'] = 0x0, kn6u['isStopped'] && (kn6u['url'] = this['url'], kn6u['loops'] = $gj3x, kn6u['startTime'] = caeom, kn6u['play'](), uqnj3s['addChannel'](kn6u)), kn6u;
    }, copam['dispose'] = function () {
      var v4_7ma = kb5d06['_audioCache'][this['url']];v4_7ma && (v4_7ma['src'] = '', delete kb5d06['_audioCache'][this['url']]);
    }, wd2815(0x0, copam, 'duration', function () {
      return this['_sound']['duration'];
    }), kb5d06['_createSound'] = function () {
      kb5d06['_id']++;var $lhtg = f4yvrz['window']['wx']['createInnerAudioContext']({ 'useWebAudioImplement': ![] });return $lhtg;
    }, kb5d06['_musicAudio'] = null, kb5d06['_id'] = 0x0, kb5d06['_audioCache'] = {}, kb5d06['_null'] = undefined, kb5d06;
  }(_mc),
      kn9u6 = function (ijtg$x) {
    function $ixg(w85d0b) {
      this['_audio'] = null, this['_onEnd'] = null, $ixg['__super']['call'](this), this['isStopped'] = !![], this['_audio'] = w85d0b, this['_onEnd'] = lgixt$['bind'](this['__onEnd'], this), w85d0b['onEnded'](this['_onEnd']);
    }$3jgix($ixg, 'laya.wx.mini.MiniSoundChannel', ijtg$x);var yv4rzf = $ixg['prototype'];return yv4rzf['__onEnd'] = function () {
      if (this['loops'] == 0x1) {
        this['completeHandler'] && (nqs9k['timer']['once'](0xa, this, this['__runComplete'], [this['completeHandler']], ![]), this['completeHandler'] = null);this['stop'](), this['event']('complete');return;
      }this['loops'] > 0x0 && this['loops']--, this['startTime'] = 0x0, this['play']();
    }, yv4rzf['__onNull'] = function () {}, yv4rzf['play'] = function () {
      this['isStopped'] = ![], uqnj3s['addChannel'](this);if (this['_audio']) this['_audio']['play']();
    }, yv4rzf['stop'] = function () {
      this['isStopped'] = !![], uqnj3s['removeChannel'](this), this['completeHandler'] = null;if (!this['_audio']) return;this['_audio']['stop']();
    }, yv4rzf['pause'] = function () {
      this['isStopped'] = !![], this['_audio']['pause']();
    }, yv4rzf['resume'] = function () {
      if (!this['_audio']) return;this['isStopped'] = ![], uqnj3s['addChannel'](this), this['_audio']['play']();
    }, wd2815(0x0, yv4rzf, 'position', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['currentTime'];
    }), wd2815(0x0, yv4rzf, 'duration', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['duration'];
    }), wd2815(0x0, yv4rzf, 'volume', function () {
      return 0x1;
    }, function (nqsu9k) {}), $ixg['_null'] = undefined, $ixg;
  }(fhvryz),
      glrhtz = function () {
    function yr4vzf() {
      this['videoend'] = ![], this['videourl'] = '', this['videoElement'] = f4yvrz['window']['wx']['createVideo']({ 'showCenterPlayBtn': ![], 'showProgressInControlMode': ![], 'objectFit': 'fill' });
    }$3jgix(yr4vzf, 'laya.wx.mini.MiniVideo');var l$thx = yr4vzf['prototype'];return l$thx['on'] = function (opcae, snuqj3, qsku9n) {
      if (opcae == 'loadedmetadata') this['onPlayFunc'] = qsku9n['bind'](snuqj3), this['videoElement']['onPlay'] = this['onPlayFunction']['bind'](this);else opcae == 'ended' && (this['onEndedFunC'] = qsku9n['bind'](snuqj3), this['videoElement']['onEnded'] = this['onEndedFunction']['bind'](this));this['videoElement']['onTimeUpdate'] = this['onTimeUpdateFunc']['bind'](this);
    }, l$thx['onTimeUpdateFunc'] = function (rfyzl) {
      this['position'] = rfyzl['position'], this['_duration'] = rfyzl['duration'];
    }, l$thx['onPlayFunction'] = function () {
      if (this['videoElement']) this['videoElement']['readyState'] = 0xc8;console['log']('=====视频加载完成========'), this['onPlayFunc'] != null && this['onPlayFunc']();
    }, l$thx['onended'] = function (a4v_f7, k0sb6) {
      this['onEndedFunC'] = k0sb6['bind'](a4v_f7), this['videoElement']['onended'] = this['onEndedFunction']['bind'](this);
    }, l$thx['onEndedFunction'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], console['log']('=====视频播放完毕========'), this['onEndedFunC'] != null && this['onEndedFunC']();
    }, l$thx['off'] = function (vf_yz, qx$j3, c47_am) {
      if (vf_yz == 'loadedmetadata') this['onPlayFunc'] = c47_am['bind'](qx$j3), this['videoElement']['offPlay'] = this['onPlayFunction']['bind'](this);else vf_yz == 'ended' && (this['onEndedFunC'] = c47_am['bind'](qx$j3), this['videoElement']['offEnded'] = this['onEndedFunction']['bind'](this));
    }, l$thx['load'] = function (c_m) {
      if (!this['videoElement']) return;this['videoElement']['src'] = c_m;
    }, l$thx['play'] = function () {
      if (!this['videoElement']) return;this['videoend'] = ![], this['videoElement']['play']();
    }, l$thx['pause'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], this['videoElement']['pause']();
    }, l$thx['size'] = function (gt$, b08dw5) {
      if (!this['videoElement']) return;this['videoElement']['width'] = gt$, this['videoElement']['height'] = b08dw5;
    }, l$thx['destroy'] = function () {
      if (this['videoElement']) this['videoElement']['destroy']();this['videoElement'] = null, this['onEndedFunC'] = null, this['onPlayFunc'] = null, this['videoend'] = ![], this['videourl'] = null;
    }, l$thx['reload'] = function () {
      if (!this['videoElement']) return;this['videoElement']['src'] = this['videourl'];
    }, wd2815(0x0, l$thx, 'duration', function () {
      return this['_duration'];
    }), wd2815(0x0, l$thx, 'currentTime', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['initialTime'];
    }, function (qnu39) {
      if (!this['videoElement']) return;this['videoElement']['initialTime'] = qnu39;
    }), wd2815(0x0, l$thx, 'videoWidth', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['width'];
    }), wd2815(0x0, l$thx, 'videoHeight', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['height'];
    }), wd2815(0x0, l$thx, 'ended', function () {
      return this['videoend'];
    }), wd2815(0x0, l$thx, 'loop', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['loop'];
    }, function (_moac7) {
      if (!this['videoElement']) return;this['videoElement']['loop'] = _moac7;
    }), wd2815(0x0, l$thx, 'playbackRate', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['playbackRate'];
    }, function (zlth) {
      if (!this['videoElement']) return;this['videoElement']['playbackRate'] = zlth;
    }), wd2815(0x0, l$thx, 'muted', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['muted'];
    }, function (f47a) {
      if (!this['videoElement']) return;this['videoElement']['muted'] = f47a;
    }), wd2815(0x0, l$thx, 'paused', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['paused'];
    }), wd2815(0x0, l$thx, 'x', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['x'];
    }, function (d8w215) {
      if (!this['videoElement']) return;this['videoElement']['x'] = d8w215;
    }), wd2815(0x0, l$thx, 'y', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['y'];
    }, function (v_4f7) {
      if (!this['videoElement']) return;this['videoElement']['y'] = v_4f7;
    }), wd2815(0x0, l$thx, 'currentSrc', function () {
      return this['videoElement']['src'];
    }), wd2815(0x0, l$thx, 'src', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['src'];
    }, function (lhxt$) {
      if (!this['videoElement']) return;this['videoElement']['src'] = lhxt$;
    }), wd2815(0x0, l$thx, 'controls', function () {
      if (!this['videoElement']) return;return this['videoElement']['controls'];
    }, function (tilg$x) {
      if (!this['videoElement']) return;this['videoElement']['controls'] = tilg$x;
    }), wd2815(0x0, l$thx, 'autoplay', function () {
      if (!this['videoElement']) return;return this['videoElement']['autoplay'];
    }, function (bs9k0) {
      if (!this['videoElement']) return;this['videoElement']['autoplay'] = bs9k0;
    }), yr4vzf;
  }();
})(window, document, Laya);typeof define === 'function' && define['amd'] && define('laya.core', ['require', 'exports'], function (require, exports) {
  'use strict';
  Object['defineProperty'](exports, '__esModule', { 'value': !![] });for (var yz_f4v in Laya) {
    var x$tlh = Laya[yz_f4v];x$tlh && x$tlh['__isclass'] && (exports[yz_f4v] = x$tlh);
  }
});