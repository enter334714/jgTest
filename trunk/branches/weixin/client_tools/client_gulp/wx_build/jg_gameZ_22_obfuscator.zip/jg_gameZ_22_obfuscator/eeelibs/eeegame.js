var b = wx.$e;
console[b[82]](b[30441]), window[b[30442]], wx[b[30443]](function (fy_47v) {
  if (fy_47v) {
    if (fy_47v[b[4863]]) {
      var rhtgxl = window[b[588]][b[30444]][b[5043]](new RegExp(/\./, 'g'), '_'),
          u3ijq = fy_47v[b[4863]],
          pmeca = u3ijq[b[12570]](/(eeeeeeee\/eeegame.js:)[0-9]{1,60}(:)/g);if (pmeca) for (var u6b = 0x0; u6b < pmeca[b[16]]; u6b++) {
        if (pmeca[u6b] && pmeca[u6b][b[16]] > 0x0) {
          var ca7po = parseInt(pmeca[u6b][b[5043]](b[30445], '')[b[5043]](':', ''));u3ijq = u3ijq[b[5043]](pmeca[u6b], pmeca[u6b][b[5043]](':' + ca7po + ':', ':' + (ca7po - 0x2) + ':'));
        }
      }u3ijq = u3ijq[b[5043]](new RegExp(b[30446], 'g'), b[30447] + rhtgxl + b[26273]), u3ijq = u3ijq[b[5043]](new RegExp(b[30448], 'g'), b[30447] + rhtgxl + b[26273]), fy_47v[b[4863]] = u3ijq;
    }var y4vrzf = { 'id': window[b[30449]][b[30450]], 'role': window[b[30449]][b[4984]], 'level': window[b[30449]][b[30451]], 'user': window[b[30449]][b[26172]], 'version': window[b[30449]][b[109]], 'cdn': window[b[30449]][b[4861]], 'pkgName': window[b[30449]][b[26173]], 'gamever': window[b[588]][b[30444]], 'serverid': window[b[30449]][b[26167]] ? window[b[30449]][b[26167]][b[11940]] : 0x0, 'systemInfo': window[b[30452]], 'error': b[30453], 'stack': fy_47v ? fy_47v[b[4863]] : '' },
        k05b = JSON[b[4847]](y4vrzf);console[b[143]](b[30454] + k05b), (!window[b[30442]] || window[b[30442]] != y4vrzf[b[143]]) && (window[b[30442]] = y4vrzf[b[143]], window[b[30455]](y4vrzf));
  }
});import 'eeemd5min.js';import 'eeezlibs.js';window[b[30456]] = require(b[30457]);import 'eeeindex.js';import 'eeelibsmin.js';import 'eeewxmini.js';import 'eeeinitmin.js';console[b[82]](b[30458]), console[b[82]](b[30459]), e11UG0({ 'title': b[30460] });var eijtx = { 'e1I10UG': !![] };new window[b[30461]](eijtx), window[b[30461]][b[166]][b[30462]]();if (window[b[30463]]) clearInterval(window[b[30463]]);window[b[30463]] = null, window[b[30464]] = function (_fvy4z, ocempa) {
  if (!_fvy4z || !ocempa) return 0x0;_fvy4z = _fvy4z[b[18]]('.'), ocempa = ocempa[b[18]]('.');const k69s0 = Math[b[907]](_fvy4z[b[16]], ocempa[b[16]]);while (_fvy4z[b[16]] < k69s0) {
    _fvy4z[b[33]]('0');
  }while (ocempa[b[16]] < k69s0) {
    ocempa[b[33]]('0');
  }for (var ghxltr = 0x0; ghxltr < k69s0; ghxltr++) {
    const frzlh = parseInt(_fvy4z[ghxltr]),
          dw18 = parseInt(ocempa[ghxltr]);if (frzlh > dw18) return 0x1;else {
      if (frzlh < dw18) return -0x1;
    }
  }return 0x0;
}, window[b[30465]] = wx[b[30466]]()[b[30465]], console[b[511]](b[30467] + window[b[30465]]);var erly = wx[b[30468]]();erly[b[30469]](function (fzrhly) {
  console[b[511]](b[30470] + fzrhly[b[30471]]);
}), erly[b[30472]](function () {
  wx[b[30473]]({ 'title': b[30474], 'content': b[30475], 'showCancel': ![], 'success': function (n9ks6) {
      erly[b[30476]]();
    } });
}), erly[b[30477]](function () {
  console[b[511]](b[30478]);
}), window[b[30479]] = function () {
  console[b[511]](b[30480]);var sn6uk9 = wx[b[30481]]({ 'name': b[30482], 'success': function (uj3) {
      console[b[511]](b[30483]), console[b[511]](uj3), uj3 && uj3[b[26370]] == b[30484] ? (window[b[30485]] = !![], window[b[30486]](), window[b[30487]]()) : setTimeout(function () {
        window[b[30479]]();
      }, 0x1f4);
    }, 'fail': function (_7mco) {
      console[b[511]](b[30488]), console[b[511]](_7mco), setTimeout(function () {
        window[b[30479]]();
      }, 0x1f4);
    } });sn6uk9 && sn6uk9[b[29841]](mca_4 => {});
}, window[b[30489]] = function () {
  console[b[511]](b[30490]);var s9uk6 = wx[b[30481]]({ 'name': b[30491], 'success': function (us6k9b) {
      console[b[511]](b[30492]), console[b[511]](us6k9b), us6k9b && us6k9b[b[26370]] == b[30484] ? (window[b[30493]] = !![], window[b[30486]](), window[b[30487]]()) : setTimeout(function () {
        window[b[30489]]();
      }, 0x1f4);
    }, 'fail': function (gtxji$) {
      console[b[511]](b[30494]), console[b[511]](gtxji$), setTimeout(function () {
        window[b[30489]]();
      }, 0x1f4);
    } });s9uk6 && s9uk6[b[29841]](k6usn9 => {});
}, window[b[30495]] = function () {
  window[b[30464]](window[b[30465]], b[30496]) >= 0x0 ? (console[b[511]](b[30497] + window[b[30465]] + b[30498]), window[b[30499]](), window[b[30479]](), window[b[30489]]()) : (window[b[30500]](b[30501], window[b[30465]]), wx[b[30473]]({ 'title': b[6726], 'content': b[30502] }));
}, window[b[30452]] = '', wx[b[30503]]({ 'success'(niqju) {
    window[b[30452]] = b[30504] + niqju[b[30505]] + b[30506] + niqju[b[30507]] + b[30508] + niqju[b[5056]] + b[30509] + niqju[b[504]] + b[30510] + niqju[b[26137]] + b[30511] + niqju[b[30465]] + b[30512] + niqju[b[9701]], console[b[511]](window[b[30452]]), console[b[511]](b[30513] + niqju[b[30514]] + b[30515] + niqju[b[30516]] + b[30517] + niqju[b[30518]] + b[30519] + niqju[b[30520]] + b[30521] + niqju[b[30522]] + b[30523] + niqju[b[30524]] + b[30525] + (niqju[b[30526]] ? niqju[b[30526]][b[342]] + ',' + niqju[b[30526]][b[1345]] + ',' + niqju[b[30526]][b[1347]] + ',' + niqju[b[30526]][b[1346]] : ''));var hgtrl = niqju[b[504]] ? niqju[b[504]][b[12876]]() : '',
        d5w028 = niqju[b[30507]] ? niqju[b[30507]][b[12876]]()[b[5043]]('\x20', '') : '';window[b[30449]][b[1132]] = hgtrl[b[124]](b[30527]) != -0x1, window[b[30449]][b[11762]] = hgtrl[b[124]](b[30528]) != -0x1, window[b[30449]][b[30529]] = hgtrl[b[124]](b[30527]) != -0x1 || hgtrl[b[124]](b[30528]) != -0x1, window[b[30449]][b[25867]] = hgtrl[b[124]](b[30530]) != -0x1 || hgtrl[b[124]](b[30531]) != -0x1, window[b[30449]][b[30532]] = niqju[b[26137]] ? niqju[b[26137]][b[12876]]() : '', window[b[30449]][b[30533]] = ![], window[b[30449]][b[30534]] = 0x2;if (hgtrl[b[124]](b[30528]) != -0x1) {
      if (niqju[b[9701]] >= 0x18) window[b[30449]][b[30534]] = 0x3;else window[b[30449]][b[30534]] = 0x2;
    } else {
      if (hgtrl[b[124]](b[30527]) != -0x1) {
        if (niqju[b[9701]] && niqju[b[9701]] >= 0x14) window[b[30449]][b[30534]] = 0x3;else {
          if (d5w028[b[124]](b[30535]) != -0x1 || d5w028[b[124]](b[30536]) != -0x1 || d5w028[b[124]](b[30537]) != -0x1 || d5w028[b[124]](b[30538]) != -0x1 || d5w028[b[124]](b[30539]) != -0x1) window[b[30449]][b[30534]] = 0x2;else window[b[30449]][b[30534]] = 0x3;
        }
      } else window[b[30449]][b[30534]] = 0x2;
    }console[b[511]](b[30540] + window[b[30449]][b[30533]] + b[30541] + window[b[30449]][b[30534]]);
  } }), wx[b[30542]]({ 'success': function (w05bd8) {
    console[b[511]](b[30543] + w05bd8[b[4960]] + b[30544] + w05bd8[b[30545]]);
  } }), wx[b[12342]]({ 'success': function (s6bu9) {
    console[b[511]](b[30546] + s6bu9[b[13658]]);
  } }), wx[b[30547]]({ 'keepScreenOn': !![] }), wx[b[12344]](function (tgzh) {
  console[b[511]](b[30546] + tgzh[b[13658]] + b[30548] + tgzh[b[30549]]);
}), wx[b[11268]](function (pacm7) {
  window[b[30550]] = pacm7, window[b[30551]] && window[b[30550]] && (console[b[82]](b[30552] + window[b[30550]][b[830]]), window[b[30551]](window[b[30550]]), window[b[30550]] = null);
}), window[b[30553]] = 0x0, window[b[30554]] = 0x0, window[b[30555]] = null, wx[b[30556]](function () {
  window[b[30554]]++;var y4v_7 = Date[b[87]]();(window[b[30553]] == 0x0 || y4v_7 - window[b[30553]] > 0x1d4c0) && (console[b[102]](b[30557]), wx[b[12414]]());if (window[b[30554]] >= 0x2) {
    window[b[30554]] = 0x0, console[b[143]](b[30558]), wx[b[30559]]('0', 0x1);if (window[b[30449]] && window[b[30449]][b[1132]]) window[b[30500]](b[30560], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});