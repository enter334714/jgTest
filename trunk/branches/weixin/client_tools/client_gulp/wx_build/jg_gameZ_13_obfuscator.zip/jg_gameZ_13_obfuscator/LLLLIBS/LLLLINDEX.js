var Z = wx.$L;
import l1z6rtxw from '../llllSDK/llllSDDK.js';window[Z[603]] = { 'wxVersion': window[Z[480]][Z[481]] }, window[Z[604]] = ![], window['$lMN'] = 0x1, window[Z[605]] = 0x1, window['$lONM'] = !![], window[Z[606]] = !![], window['$lTZONM'] = '', window[Z[607]] = ![], window['$lNM'] = { 'base_cdn': Z[608], 'cdn': Z[608] }, $lNM[Z[609]] = {}, $lNM[Z[610]] = '0', $lNM[Z[540]] = window[Z[603]][Z[216]], $lNM[Z[571]] = '', $lNM['os'] = '1', $lNM[Z[611]] = Z[612], $lNM[Z[613]] = Z[614], $lNM[Z[615]] = Z[616], $lNM[Z[617]] = Z[618], $lNM[Z[619]] = Z[620], $lNM[Z[621]] = '1', $lNM[Z[271]] = '', $lNM[Z[622]] = '', $lNM[Z[623]] = 0x0, $lNM[Z[312]] = {}, $lNM[Z[624]] = parseInt($lNM[Z[621]]), $lNM[Z[625]] = $lNM[Z[621]], $lNM[Z[157]] = {}, $lNM['$lZN'] = Z[626], $lNM[Z[627]] = ![], $lNM[Z[628]] = Z[629], $lNM[Z[630]] = Date[Z[152]](), $lNM[Z[631]] = Z[632], $lNM[Z[633]] = '_a', $lNM[Z[201]] = 0x2, $lNM[Z[214]] = 0x7c1, $lNM[Z[216]] = window[Z[603]][Z[216]], $lNM[Z[634]] = ![], $lNM[Z[564]] = ![], $lNM[Z[566]] = ![], $lNM[Z[569]] = ![], window['$lOMN'] = 0x5, window['$lOM'] = ![], window['$lMO'] = ![], window['$lNOM'] = ![], window[Z[406]] = ![], window[Z[415]] = ![], window['$lNMO'] = ![], window['$lON'] = ![], window['$lNO'] = ![], window['$lMON'] = ![], window[Z[410]] = null, window[Z[635]] = function (sqag5) {
  console[Z[323]](Z[635], sqag5), wx[Z[636]]({}), wx[Z[509]]({ 'title': Z[532], 'content': sqag5, 'success'(_y1j2) {
      if (_y1j2[Z[637]]) console[Z[323]](Z[638]);else _y1j2[Z[639]] && console[Z[323]](Z[640]);
    } });
}, window['$lZONM'] = function (r6z9) {
  console[Z[323]](Z[641], r6z9), $lZNMO(), wx[Z[509]]({ 'title': Z[532], 'content': r6z9, 'confirmText': Z[642], 'cancelText': Z[643], 'success'(c8y2) {
      if (c8y2[Z[637]]) window['$lNZ']();else c8y2[Z[639]] && (console[Z[323]](Z[644]), wx[Z[645]]({}));
    } });
}, window[Z[646]] = function (pib1m) {
  console[Z[323]](Z[646], pib1m), wx[Z[509]]({ 'title': Z[532], 'content': pib1m, 'confirmText': Z[647], 'showCancel': ![], 'complete'(d7lk) {
      console[Z[323]](Z[644]), wx[Z[645]]({});
    } });
}, window['$lZOMN'] = ![], window['$lZNOM'] = function (a$7klg) {
  window['$lZOMN'] = !![], wx[Z[648]](a$7klg);
}, window['$lZNMO'] = function () {
  window['$lZOMN'] && (window['$lZOMN'] = ![], wx[Z[636]]({}));
}, window['$lZMON'] = function (fzxtw) {
  window[Z[474]][Z[153]]['$lZMON'](fzxtw);
}, window[Z[649]] = function (yj1o2, uwz6t) {
  l1z6rtxw[Z[649]](yj1o2, function (ipr960) {
    ipr960 && ipr960[Z[327]] ? ipr960[Z[327]][Z[326]] == 0x1 ? uwz6t(!![]) : (uwz6t(![]), console[Z[475]](Z[650] + ipr960[Z[327]][Z[651]])) : console[Z[323]](Z[649], ipr960);
  });
}, window['$lZMNO'] = function (dceh8y) {
  console[Z[323]](Z[652], dceh8y);
}, window['$lZNM'] = function (r6z90x) {}, window['$lZMN'] = function (p_m1ib, gs5anq, uwt3) {}, window['$lZM'] = function (ng5sv) {
  console[Z[323]](Z[653], ng5sv), window[Z[474]][Z[153]][Z[205]](), window[Z[474]][Z[153]][Z[206]](), window[Z[474]][Z[153]][Z[220]]();
}, window['$lMZ'] = function (l7$ake) {
  window[Z[654]](0xe, Z[655] + l7$ake), window['$lZONM'](Z[656]);var o_yj21 = { 'id': window['$lNM'][Z[487]], 'role': window['$lNM'][Z[488]], 'level': window['$lNM'][Z[489]], 'account': window['$lNM'][Z[490]], 'version': window['$lNM'][Z[214]], 'cdn': window['$lNM'][Z[305]], 'pkgName': window['$lNM'][Z[271]], 'gamever': window[Z[480]][Z[481]], 'serverid': window['$lNM'][Z[157]] ? window['$lNM'][Z[157]][Z[158]] : 0x0, 'systemInfo': window[Z[491]], 'error': Z[657], 'stack': l7$ake ? l7$ake : Z[656] },
      o_2h = JSON[Z[432]](o_yj21);console[Z[434]](Z[658] + o_2h), window['$lZN'](o_2h);
}, window[Z[654]] = function ($gq, jy2ho8) {
  sendApi($lNM[Z[615]], Z[659], { 'game_pkg': $lNM[Z[271]], 'partner_id': $lNM[Z[621]], 'server_id': $lNM[Z[157]] && $lNM[Z[157]][Z[158]] > 0x0 ? $lNM[Z[157]][Z[158]] : 0x0, 'uid': $lNM[Z[490]] > 0x0 ? $lNM[Z[490]] : 0x0, 'type': $gq, 'info': jy2ho8 });
}, window['$lNZM'] = function (wz3u) {
  var rm9pi0 = JSON[Z[660]](wz3u);rm9pi0[Z[661]] = window[Z[480]][Z[481]], rm9pi0[Z[662]] = window['$lNM'][Z[157]] ? window['$lNM'][Z[157]][Z[158]] : 0x0, rm9pi0[Z[491]] = window[Z[491]];var sgvq5n = JSON[Z[432]](rm9pi0);console[Z[434]](Z[663] + sgvq5n), window['$lZN'](sgvq5n);
}, window['$lNMZ'] = function (g$7ka5, omi_b1) {
  var $a7g = { 'id': window['$lNM'][Z[487]], 'role': window['$lNM'][Z[488]], 'level': window['$lNM'][Z[489]], 'account': window['$lNM'][Z[490]], 'version': window['$lNM'][Z[214]], 'cdn': window['$lNM'][Z[305]], 'pkgName': window['$lNM'][Z[271]], 'gamever': window[Z[480]][Z[481]], 'serverid': window['$lNM'][Z[157]] ? window['$lNM'][Z[157]][Z[158]] : 0x0, 'systemInfo': window[Z[491]], 'error': g$7ka5, 'stack': omi_b1 },
      qnvs = JSON[Z[432]]($a7g);console[Z[451]](Z[664] + qnvs), window['$lZN'](qnvs);
}, window['$lZN'] = function (zt0x6) {
  if (window['$lNM'][Z[572]] == Z[665]) return;var w3ut = $lNM['$lZN'] + Z[666] + $lNM[Z[490]];wx[Z[667]]({ 'url': w3ut, 'method': Z[668], 'data': zt0x6, 'header': { 'content-type': Z[669], 'cache-control': Z[670] }, 'success': function (j21_y) {
      DEBUG && console[Z[323]](Z[671], w3ut, zt0x6, j21_y);
    }, 'fail': function (b19pm) {
      DEBUG && console[Z[323]](Z[671], w3ut, zt0x6, b19pm);
    }, 'complete': function () {} });
}, window[Z[672]] = function () {
  function m1_io() {
    return ((0x1 + Math[Z[208]]()) * 0x10000 | 0x0)[Z[673]](0x10)[Z[674]](0x1);
  }return m1_io() + m1_io() + '-' + m1_io() + '-' + m1_io() + '-' + m1_io() + '+' + m1_io() + m1_io() + m1_io();
}, window['$lNZ'] = function () {
  console[Z[323]](Z[675]);var y_o1j = l1z6rtxw[Z[676]]();$lNM[Z[625]] = y_o1j[Z[677]], $lNM[Z[624]] = y_o1j[Z[677]], $lNM[Z[621]] = y_o1j[Z[677]], $lNM[Z[271]] = y_o1j[Z[678]];var de8hcy = { 'game_ver': $lNM[Z[540]] };$lNM[Z[622]] = this[Z[672]](), $lZNOM({ 'title': Z[679] }), l1z6rtxw[Z[371]](de8hcy, this['$lMZN'][Z[212]](this));
}, window['$lMZN'] = function (ldck7e) {
  var oh8y = ldck7e[Z[411]];sdkInitRes = ldck7e, console[Z[323]](Z[680] + oh8y + Z[681] + (oh8y == 0x1) + Z[682] + ldck7e[Z[481]] + Z[683] + window[Z[603]][Z[216]]);if (!ldck7e[Z[481]] || window['$lTOMZN'](window[Z[603]][Z[216]], ldck7e[Z[481]]) < 0x0) console[Z[323]](Z[684]), $lNM[Z[613]] = Z[685], $lNM[Z[615]] = Z[686], $lNM[Z[617]] = Z[687], $lNM[Z[305]] = Z[688], $lNM[Z[689]] = Z[690], $lNM[Z[691]] = 'md', $lNM[Z[634]] = ![];else window['$lTOMZN'](window[Z[603]][Z[216]], ldck7e[Z[481]]) == 0x0 ? (console[Z[323]](Z[692]), $lNM[Z[613]] = Z[614], $lNM[Z[615]] = Z[616], $lNM[Z[617]] = Z[618], $lNM[Z[305]] = Z[693], $lNM[Z[689]] = Z[690], $lNM[Z[691]] = Z[694], $lNM[Z[634]] = !![]) : (console[Z[323]](Z[695]), $lNM[Z[613]] = Z[614], $lNM[Z[615]] = Z[616], $lNM[Z[617]] = Z[618], $lNM[Z[305]] = Z[696], $lNM[Z[689]] = Z[690], $lNM[Z[691]] = Z[694], $lNM[Z[634]] = ![]);$lNM[Z[623]] = config[Z[697]] ? config[Z[697]] : 0x0, this['$lONZM'](), this['$lONMZ'](), window[Z[698]] = 0x5, $lZNOM({ 'title': Z[699] }), l1z6rtxw[Z[700]](this['$lMNZ'][Z[212]](this));
}, window[Z[698]] = 0x5, window['$lMNZ'] = function (z6xrtw, ohyj_2) {
  if (z6xrtw == 0x0 && ohyj_2 && ohyj_2[Z[701]]) {
    $lNM[Z[702]] = ohyj_2[Z[701]];var $5aqg = this;$lZNOM({ 'title': Z[703] }), sendApi($lNM[Z[613]], Z[704], { 'platform': $lNM[Z[611]], 'partner_id': $lNM[Z[621]], 'token': ohyj_2[Z[701]], 'game_pkg': $lNM[Z[271]], 'deviceId': $lNM[Z[622]], 'scene': Z[705] + $lNM[Z[623]] }, this['$lOZNM'][Z[212]](this), $lOMN, $lMZ);
  } else ohyj_2 && ohyj_2[Z[519]] && window[Z[698]] > 0x0 && (ohyj_2[Z[519]][Z[454]](Z[706]) != -0x1 || ohyj_2[Z[519]][Z[454]](Z[707]) != -0x1 || ohyj_2[Z[519]][Z[454]](Z[708]) != -0x1 || ohyj_2[Z[519]][Z[454]](Z[709]) != -0x1 || ohyj_2[Z[519]][Z[454]](Z[710]) != -0x1 || ohyj_2[Z[519]][Z[454]](Z[711]) != -0x1) ? (window[Z[698]]--, l1z6rtxw[Z[700]](this['$lMNZ'][Z[212]](this))) : (window[Z[654]](0x1, Z[712] + z6xrtw + Z[713] + (ohyj_2 ? ohyj_2[Z[519]] : '')), window['$lNMZ'](Z[714], JSON[Z[432]]({ 'status': z6xrtw, 'data': ohyj_2 })), window['$lZONM'](Z[715] + (ohyj_2 && ohyj_2[Z[519]] ? '，' + ohyj_2[Z[519]] : '')));
}, window['$lOZNM'] = function (hc8eld) {
  if (!hc8eld) {
    window[Z[654]](0x2, Z[716]), window['$lNMZ'](Z[717], Z[718]), window['$lZONM'](Z[719]);return;
  }if (hc8eld[Z[326]] != Z[325]) {
    window[Z[654]](0x2, Z[720] + hc8eld[Z[326]]), window['$lNMZ'](Z[717], JSON[Z[432]](hc8eld)), window['$lZONM'](Z[721] + hc8eld[Z[326]]);return;
  }$lNM[Z[722]] = String(hc8eld[Z[490]]), $lNM[Z[490]] = String(hc8eld[Z[490]]), $lNM[Z[544]] = String(hc8eld[Z[544]]), $lNM[Z[625]] = String(hc8eld[Z[544]]), $lNM[Z[723]] = String(hc8eld[Z[723]]), $lNM[Z[724]] = String(hc8eld[Z[725]]), $lNM[Z[726]] = String(hc8eld[Z[727]]), $lNM[Z[725]] = '';var gakl7$ = this;$lZNOM({ 'title': Z[728] });var pimr90 = localStorage[Z[276]](Z[729] + $lNM[Z[271]] + $lNM[Z[490]]);if (pimr90 && pimr90 != '') {
    var cjhy28 = Number(pimr90);gakl7$[Z[730]](cjhy28);
  } else gakl7$[Z[731]]();
}, window[Z[731]] = function () {
  var gqs5nv = this;sendApi($lNM[Z[613]], Z[732], { 'partner_id': $lNM[Z[621]], 'uid': $lNM[Z[490]], 'version': $lNM[Z[540]], 'game_pkg': $lNM[Z[271]], 'device': $lNM[Z[622]] }, gqs5nv['$lOZMN'][Z[212]](gqs5nv), $lOMN, $lMZ);
}, window['$lOZMN'] = function (y12oj_) {
  if (!y12oj_) {
    window[Z[654]](0x3, Z[733]), window['$lZONM'](Z[733]);return;
  }if (y12oj_[Z[326]] != Z[325]) {
    window[Z[654]](0x3, Z[734] + y12oj_[Z[326]]), window['$lZONM'](Z[734] + y12oj_[Z[326]]);return;
  }if (!y12oj_[Z[327]] || y12oj_[Z[327]][Z[186]] == 0x0) {
    window[Z[654]](0x3, Z[735]), window['$lZONM'](Z[736]);return;
  }this[Z[737]](y12oj_);
}, window[Z[730]] = function (dle$7) {
  var b_omi1 = this;sendApi($lNM[Z[613]], Z[738], { 'server_id': dle$7, 'time': Date[Z[152]]() / 0x3e8 }, b_omi1[Z[739]][Z[212]](b_omi1), $lOMN, $lMZ);
}, window[Z[739]] = function (kag75) {
  if (!kag75) {
    window[Z[654]](0x4, Z[740]), this[Z[731]]();return;
  }if (kag75[Z[326]] != Z[325]) {
    window[Z[654]](0x4, Z[741] + kag75[Z[326]]), this[Z[731]]();return;
  }if (!kag75[Z[327]] || kag75[Z[327]][Z[186]] == 0x0) {
    window[Z[654]](0x4, Z[742]), this[Z[731]]();return;
  }this[Z[737]](kag75), window[Z[474]] && window[Z[474]][Z[153]][Z[408]] && window[Z[474]][Z[153]][Z[408]](sdkInitRes[Z[743]], sdkInitRes[Z[744]], sdkInitRes[Z[745]], sdkInitRes[Z[746]], sdkInitRes[Z[747]]);
}, window[Z[737]] = function (g5qans) {
  $lNM[Z[421]] = g5qans[Z[748]] != undefined ? g5qans[Z[748]] : 0x0, $lNM[Z[157]] = { 'server_id': String(g5qans[Z[327]][0x0][Z[158]]), 'server_name': String(g5qans[Z[327]][0x0][Z[301]]), 'entry_ip': g5qans[Z[327]][0x0][Z[749]], 'entry_port': parseInt(g5qans[Z[327]][0x0][Z[750]]), 'status': $lNOZ(g5qans[Z[327]][0x0]), 'start_time': g5qans[Z[327]][0x0][Z[751]], 'cdn': $lNM[Z[305]] }, this['$lMNOZ']();
}, window['$lMNOZ'] = function () {
  if ($lNM[Z[421]] == 0x1) {
    var tzwux6 = $lNM[Z[157]][Z[302]];if (tzwux6 === -0x1 || tzwux6 === 0x0) {
      window[Z[654]](0xf, Z[752] + $lNM[Z[157]]['id'] + Z[753] + $lNM[Z[157]][Z[302]]), window['$lZONM'](tzwux6 === -0x1 ? Z[754] : Z[755]);return;
    }$lMZON(0x0, $lNM[Z[157]][Z[158]]), window[Z[474]][Z[153]][Z[416]]($lNM[Z[421]]);
  } else window[Z[474]][Z[153]][Z[414]](), $lZNMO();window['$lNO'] = !![], window['$lMONZ'](), window['$lMNZO']();
}, window['$lONZM'] = function () {
  sendApi($lNM[Z[613]], Z[756], { 'game_pkg': $lNM[Z[271]], 'version_name': $lNM[Z[691]] }, this[Z[757]][Z[212]](this), $lOMN, $lMZ);
}, window[Z[757]] = function (pb0mi9) {
  if (!pb0mi9) {
    window[Z[654]](0x5, Z[758]), window['$lZONM'](Z[758]);return;
  }if (pb0mi9[Z[326]] != Z[325]) {
    window[Z[654]](0x5, Z[759] + pb0mi9[Z[326]]), window['$lZONM'](Z[759] + pb0mi9[Z[326]]);return;
  }if (!pb0mi9[Z[327]] || !pb0mi9[Z[327]][Z[540]]) {
    window[Z[654]](0x5, Z[760] + (pb0mi9[Z[327]] && pb0mi9[Z[327]][Z[540]])), window['$lZONM'](Z[760] + (pb0mi9[Z[327]] && pb0mi9[Z[327]][Z[540]]));return;
  }pb0mi9[Z[327]][Z[761]] && pb0mi9[Z[327]][Z[761]][Z[186]] > 0xa && ($lNM[Z[762]] = pb0mi9[Z[327]][Z[761]], $lNM[Z[305]] = pb0mi9[Z[327]][Z[761]]), pb0mi9[Z[327]][Z[540]] && ($lNM[Z[214]] = pb0mi9[Z[327]][Z[540]]), console[Z[475]](Z[763] + $lNM[Z[214]] + Z[764] + $lNM[Z[691]]), window['$lNMO'] = !![], window['$lMONZ'](), window['$lMNZO']();
}, window[Z[765]], window['$lONMZ'] = function () {
  sendApi($lNM[Z[613]], Z[766], { 'game_pkg': $lNM[Z[271]] }, this['$lOMZN'][Z[212]](this), $lOMN, $lMZ);
}, window['$lOMZN'] = function (qv5gsn) {
  if (qv5gsn && qv5gsn[Z[326]] === Z[325] && qv5gsn[Z[327]]) {
    window[Z[765]] = qv5gsn[Z[327]];for (var bp0mi in qv5gsn[Z[327]]) {
      $lNM[bp0mi] = qv5gsn[Z[327]][bp0mi];
    }
  } else window[Z[654]](0xb, Z[767]), console[Z[475]](Z[768] + qv5gsn[Z[326]]);window['$lON'] = !![], window['$lMNZO']();
}, window[Z[769]] = function (vqs5ng, a$g5sk, keld$7, yh8cj, fxz, hcl8d, $sa5gk, fzt, e$kld7, futzw) {
  fxz = String(fxz);var q5a$ = $sa5gk,
      a5g7$ = fzt;$lNM[Z[609]][fxz] = { 'productid': fxz, 'productname': q5a$, 'productdesc': a5g7$, 'roleid': vqs5ng, 'rolename': a$g5sk, 'rolelevel': keld$7, 'price': hcl8d, 'callback': e$kld7 }, sendApi($lNM[Z[617]], Z[770], { 'game_pkg': $lNM[Z[271]], 'server_id': $lNM[Z[157]][Z[158]], 'server_name': $lNM[Z[157]][Z[301]], 'level': keld$7, 'uid': $lNM[Z[490]], 'role_id': vqs5ng, 'role_name': a$g5sk, 'product_id': fxz, 'product_name': q5a$, 'product_desc': a5g7$, 'money': hcl8d, 'partner_id': $lNM[Z[621]] }, toPayCallBack, $lOMN, $lMZ);
}, window[Z[771]] = function (f3zutw) {
  if (f3zutw && (f3zutw[Z[772]] === 0xc8 || f3zutw[Z[326]] == Z[325])) {
    var ehycd = $lNM[Z[609]][String(f3zutw[Z[773]])];if (ehycd[Z[774]]) ehycd[Z[774]](f3zutw[Z[773]], f3zutw[Z[775]], -0x1);l1z6rtxw[Z[776]]({ 'cpbill': f3zutw[Z[775]], 'productid': f3zutw[Z[773]], 'productname': ehycd[Z[777]], 'productdesc': ehycd[Z[778]], 'serverid': $lNM[Z[157]][Z[158]], 'servername': $lNM[Z[157]][Z[301]], 'roleid': ehycd[Z[779]], 'rolename': ehycd[Z[780]], 'rolelevel': ehycd[Z[781]], 'price': ehycd[Z[782]], 'extension': JSON[Z[432]]({ 'cp_order_id': f3zutw[Z[775]] }) }, function (w6rxtz, lka7g$) {
      ehycd[Z[774]] && w6rxtz == 0x0 && ehycd[Z[774]](f3zutw[Z[773]], f3zutw[Z[775]], w6rxtz);console[Z[475]](JSON[Z[432]]({ 'type': Z[783], 'status': w6rxtz, 'data': f3zutw, 'role_name': ehycd[Z[780]] }));if (w6rxtz === 0x0) {} else {
        if (w6rxtz === 0x1) {} else {
          if (w6rxtz === 0x2) {}
        }
      }
    });
  } else {
    var oj2_y = f3zutw ? Z[784] + f3zutw[Z[772]] + Z[785] + f3zutw[Z[326]] + Z[786] + f3zutw[Z[475]] : Z[787];window[Z[654]](0xd, Z[788] + oj2_y), alert(oj2_y);
  }
}, window['$lOMNZ'] = function () {}, window['$lZOM'] = function (l$eak, mjo_1b, xftwuz, p1imb9, zxr90) {
  l1z6rtxw[Z[789]]($lNM[Z[157]][Z[158]], $lNM[Z[157]][Z[301]] || $lNM[Z[157]][Z[158]], l$eak, mjo_1b, xftwuz), sendApi($lNM[Z[613]], Z[790], { 'game_pkg': $lNM[Z[271]], 'server_id': $lNM[Z[157]][Z[158]], 'role_id': l$eak, 'uid': $lNM[Z[490]], 'role_name': mjo_1b, 'role_type': p1imb9, 'level': xftwuz });
}, window['$lZMO'] = function (h2jyo_, txz0r6, aqs5n, r09x, _oi1bm, qs5v4n, m1_bo, boj_m1, b_1mio, m9ibp1) {
  $lNM[Z[487]] = h2jyo_, $lNM[Z[488]] = txz0r6, $lNM[Z[489]] = aqs5n, l1z6rtxw[Z[791]]($lNM[Z[157]][Z[158]], $lNM[Z[157]][Z[301]] || $lNM[Z[157]][Z[158]], h2jyo_, txz0r6, aqs5n), sendApi($lNM[Z[613]], Z[792], { 'game_pkg': $lNM[Z[271]], 'server_id': $lNM[Z[157]][Z[158]], 'role_id': h2jyo_, 'uid': $lNM[Z[490]], 'role_name': txz0r6, 'role_type': r09x, 'level': aqs5n, 'evolution': _oi1bm });
}, window['$lOZM'] = function (h8dlec, i6rp9, wuzx, jy2h8c, c7ledk, kal$e7, kgl, sqvn, qs45vn, dyech) {
  $lNM[Z[487]] = h8dlec, $lNM[Z[488]] = i6rp9, $lNM[Z[489]] = wuzx, l1z6rtxw[Z[793]]($lNM[Z[157]][Z[158]], $lNM[Z[157]][Z[301]] || $lNM[Z[157]][Z[158]], h8dlec, i6rp9, wuzx), sendApi($lNM[Z[613]], Z[792], { 'game_pkg': $lNM[Z[271]], 'server_id': $lNM[Z[157]][Z[158]], 'role_id': h8dlec, 'uid': $lNM[Z[490]], 'role_name': i6rp9, 'role_type': jy2h8c, 'level': wuzx, 'evolution': c7ledk });
}, window['$lOMZ'] = function (vgq) {}, window['$lZO'] = function ($kdl7) {
  l1z6rtxw[Z[794]](Z[794], function (g$7ak5) {
    $kdl7 && $kdl7(g$7ak5);
  });
}, window[Z[795]] = function () {
  l1z6rtxw[Z[795]]();
}, window[Z[796]] = function () {
  l1z6rtxw[Z[797]]();
}, window[Z[798]] = function (wzt6, c8hed, mpi9r, b_21oj, ekl$7, j2o1y, k5a7$, chle8d) {
  chle8d = chle8d || $lNM[Z[157]][Z[158]], sendApi($lNM[Z[613]], Z[799], { 'phone': wzt6, 'role_id': c8hed, 'uid': $lNM[Z[490]], 'game_pkg': $lNM[Z[271]], 'partner_id': $lNM[Z[621]], 'server_id': chle8d }, k5a7$, 0x2, null, function () {
    return !![];
  });
}, window[Z[592]] = function (trxw6) {
  window['$lMZO'] = trxw6, window['$lMZO'] && window['$lOZ'] && (console[Z[475]](Z[593] + window['$lOZ'][Z[594]]), window['$lMZO'](window['$lOZ']), window['$lOZ'] = null);
}, window['$lMOZ'] = function (kga75$, fzwt3u, yjo_21, ns5v4q) {
  window[Z[800]](Z[801], { 'game_pkg': window['$lNM'][Z[271]], 'role_id': fzwt3u, 'server_id': yjo_21 }, ns5v4q);
}, window['$lNZOM'] = function (_imp, p6r0, p09xr) {
  function m1oj_b(cel7dk) {
    var _o1y2 = [],
        i0b9mp = [],
        _j1bo = p09xr || window[Z[480]][Z[802]];for (var xwtufz in _j1bo) {
      var lehd = Number(xwtufz);(!_imp || !_imp[Z[186]] || _imp[Z[454]](lehd) != -0x1) && (i0b9mp[Z[331]](_j1bo[xwtufz]), _o1y2[Z[331]]([lehd, 0x3]));
    }window['$lTOMZN'](window[Z[501]], Z[803]) >= 0x0 ? (console[Z[323]](Z[804]), l1z6rtxw[Z[805]] && l1z6rtxw[Z[805]](i0b9mp, function (ri09pm) {
      console[Z[323]](Z[806]), console[Z[323]](ri09pm);if (ri09pm && ri09pm[Z[519]] == Z[807]) for (var pm19i in _j1bo) {
        if (ri09pm[_j1bo[pm19i]] == Z[808]) {
          var ipr = Number(pm19i);for (var m1p9i = 0x0; m1p9i < _o1y2[Z[186]]; m1p9i++) {
            if (_o1y2[m1p9i][0x0] == ipr) {
              _o1y2[m1p9i][0x1] = 0x1;break;
            }
          }
        }
      }window['$lTOMZN'](window[Z[501]], Z[809]) >= 0x0 ? wx[Z[810]]({ 'withSubscriptions': !![], 'success': function (_2jyh) {
          var a5gk$ = _2jyh[Z[811]][Z[812]];if (a5gk$) {
            console[Z[323]](Z[813]), console[Z[323]](a5gk$);for (var hlced in _j1bo) {
              if (a5gk$[_j1bo[hlced]] == Z[808]) {
                var zt6xwu = Number(hlced);for (var txwfz = 0x0; txwfz < _o1y2[Z[186]]; txwfz++) {
                  if (_o1y2[txwfz][0x0] == zt6xwu) {
                    _o1y2[txwfz][0x1] = 0x2;break;
                  }
                }
              }
            }console[Z[323]](_o1y2), p6r0 && p6r0(_o1y2);
          } else console[Z[323]](Z[814]), console[Z[323]](_2jyh), console[Z[323]](_o1y2), p6r0 && p6r0(_o1y2);
        }, 'fail': function () {
          console[Z[323]](Z[815]), console[Z[323]](_o1y2), p6r0 && p6r0(_o1y2);
        } }) : (console[Z[323]](Z[816] + window[Z[501]]), console[Z[323]](_o1y2), p6r0 && p6r0(_o1y2));
    })) : (console[Z[323]](Z[817] + window[Z[501]]), console[Z[323]](_o1y2), p6r0 && p6r0(_o1y2)), wx[Z[818]](m1oj_b);
  }wx[Z[819]](m1oj_b);
}, window['$lNZMO'] = { 'isSuccess': ![], 'level': Z[820], 'isCharging': ![] }, window['$lNOZM'] = function (r0zx6t) {
  wx[Z[580]]({ 'success': function (prm9i0) {
      var y82hjo = window['$lNZMO'];y82hjo[Z[821]] = !![], y82hjo[Z[582]] = Number(prm9i0[Z[582]])[Z[822]](0x0), y82hjo[Z[584]] = prm9i0[Z[584]], r0zx6t && r0zx6t(y82hjo[Z[821]], y82hjo[Z[582]], y82hjo[Z[584]]);
    }, 'fail': function (dl$e7) {
      console[Z[323]](Z[823], dl$e7[Z[519]]);var hy2d8 = window['$lNZMO'];r0zx6t && r0zx6t(hy2d8[Z[821]], hy2d8[Z[582]], hy2d8[Z[584]]);
    } });
}, window[Z[585]] = function (elk$a7) {
  wx[Z[585]]({ 'success': function (wtzxuf) {
      elk$a7 && elk$a7(!![], wtzxuf);
    }, 'fail': function (t3fzuw) {
      elk$a7 && elk$a7(![], t3fzuw);
    } });
}, window[Z[589]] = function (jbo) {
  if (jbo) wx[Z[589]](jbo);
}, window[Z[824]] = function (r09m) {
  wx[Z[824]](r09m);
}, window[Z[800]] = function (gs5a$q, sv54qn, mip9b1, imb09, n54v, ldck, om_b1i, xtzu6) {
  if (imb09 == undefined) imb09 = 0x1;wx[Z[667]]({ 'url': gs5a$q, 'method': om_b1i || Z[825], 'responseType': Z[210], 'data': sv54qn, 'header': { 'content-type': xtzu6 || Z[669] }, 'success': function ($sg5k) {
      DEBUG && console[Z[323]](Z[826], gs5a$q, info, $sg5k);if ($sg5k && $sg5k[Z[827]] == 0xc8) {
        var fwuzx = $sg5k[Z[327]];!ldck || ldck(fwuzx) ? mip9b1 && mip9b1(fwuzx) : window[Z[828]](gs5a$q, sv54qn, mip9b1, imb09, n54v, ldck, $sg5k);
      } else window[Z[828]](gs5a$q, sv54qn, mip9b1, imb09, n54v, ldck, $sg5k);
    }, 'fail': function (dcel7k) {
      DEBUG && console[Z[323]](Z[829], gs5a$q, info, dcel7k), window[Z[828]](gs5a$q, sv54qn, mip9b1, imb09, n54v, ldck, dcel7k);
    }, 'complete': function () {} });
}, window[Z[828]] = function (b9i1p, q4svn, gk7la$, ae$l7, a5gns, ztr0, i96rp0) {
  ae$l7 - 0x1 > 0x0 ? setTimeout(function () {
    window[Z[800]](b9i1p, q4svn, gk7la$, ae$l7 - 0x1, a5gns, ztr0);
  }, 0x3e8) : a5gns && a5gns(JSON[Z[432]]({ 'url': b9i1p, 'response': i96rp0 }));
}, window[Z[830]] = function (n5q4, g$ak7l, ld$7, e8dych, z6x0t, _1ibpm, j_yo2h) {
  !ld$7 && (ld$7 = {});var g$5aks = Math[Z[435]](Date[Z[152]]() / 0x3e8);ld$7[Z[727]] = g$5aks, ld$7[Z[831]] = g$ak7l;var gnvq5 = Object[Z[832]](ld$7)[Z[332]](),
      hoy8j2 = '',
      aqg5ns = '';for (var gqsv = 0x0; gqsv < gnvq5[Z[186]]; gqsv++) {
    hoy8j2 = hoy8j2 + (gqsv == 0x0 ? '' : '&') + gnvq5[gqsv] + ld$7[gnvq5[gqsv]], aqg5ns = aqg5ns + (gqsv == 0x0 ? '' : '&') + gnvq5[gqsv] + '=' + encodeURIComponent(ld$7[gnvq5[gqsv]]);
  }hoy8j2 = hoy8j2 + $lNM[Z[619]];var ek7ld$ = Z[833] + md5(hoy8j2);send(n5q4 + '?' + aqg5ns + (aqg5ns == '' ? '' : '&') + ek7ld$, null, e8dych, z6x0t, _1ibpm, j_yo2h || function (b2jo1_) {
    return b2jo1_[Z[326]] == Z[325];
  }, null, Z[834]);
}, window['$lNOMZ'] = function (_h2oy, j1y_o) {
  var ecldk = 0x0;$lNM[Z[157]] && (ecldk = $lNM[Z[157]][Z[158]]), sendApi($lNM[Z[615]], Z[835], { 'partnerId': $lNM[Z[621]], 'gamePkg': $lNM[Z[271]], 'logTime': Math[Z[435]](Date[Z[152]]() / 0x3e8), 'platformUid': $lNM[Z[723]], 'type': _h2oy, 'serverId': ecldk }, null, 0x2, null, function () {
    return !![];
  });
}, window['$lNMZO'] = function (hy8ce) {
  sendApi($lNM[Z[613]], Z[836], { 'partner_id': $lNM[Z[621]], 'uid': $lNM[Z[490]], 'version': $lNM[Z[540]], 'game_pkg': $lNM[Z[271]], 'device': $lNM[Z[622]] }, $lNMOZ, $lOMN, $lMZ);
}, window['$lNMOZ'] = function (b_1om) {
  if (b_1om && b_1om[Z[326]] === Z[325] && b_1om[Z[327]]) {
    b_1om[Z[327]][Z[837]]({ 'id': -0x2, 'name': Z[838] }), b_1om[Z[327]][Z[837]]({ 'id': -0x1, 'name': Z[839] }), $lNM[Z[270]] = b_1om[Z[327]];if (window[Z[261]]) window[Z[261]][Z[306]]();
  } else {
    $lNM[Z[281]] = ![];var xz6tu = b_1om ? b_1om[Z[326]] : '';window[Z[654]](0x7, Z[840] + xz6tu), window['$lZONM'](Z[841] + xz6tu);
  }
}, window['$lZON'] = function (ska5$g) {
  sendApi($lNM[Z[613]], Z[842], { 'partner_id': $lNM[Z[621]], 'uid': $lNM[Z[490]], 'version': $lNM[Z[540]], 'game_pkg': $lNM[Z[271]], 'device': $lNM[Z[622]] }, $lZNO, $lOMN, $lMZ);
}, window['$lZNO'] = function (ehycd8) {
  $lNM[Z[314]] = ![];if (ehycd8 && ehycd8[Z[326]] === Z[325] && ehycd8[Z[327]]) {
    for (var o2hyj8 = 0x0; o2hyj8 < ehycd8[Z[327]][Z[186]]; o2hyj8++) {
      ehycd8[Z[327]][o2hyj8][Z[302]] = $lNOZ(ehycd8[Z[327]][o2hyj8]);
    }$lNM[Z[312]][-0x1] = window[Z[843]](ehycd8[Z[327]]), window[Z[261]][Z[313]](-0x1);
  } else {
    var sq4nv = ehycd8 ? ehycd8[Z[326]] : '';window[Z[654]](0x8, Z[844] + sq4nv), window['$lZONM'](Z[845] + sq4nv);
  }
}, window[Z[846]] = function (w6rxzt) {
  sendApi($lNM[Z[613]], Z[842], { 'partner_id': $lNM[Z[621]], 'uid': $lNM[Z[490]], 'version': $lNM[Z[540]], 'game_pkg': $lNM[Z[271]], 'device': $lNM[Z[622]] }, w6rxzt, $lOMN, $lMZ);
}, window['$lOZN'] = function (gsqan, dl7cek) {
  sendApi($lNM[Z[613]], Z[847], { 'partner_id': $lNM[Z[621]], 'uid': $lNM[Z[490]], 'version': $lNM[Z[540]], 'game_pkg': $lNM[Z[271]], 'device': $lNM[Z[622]], 'server_group_id': dl7cek }, $lONZ, $lOMN, $lMZ);
}, window['$lONZ'] = function (hjy2o8) {
  $lNM[Z[314]] = ![];if (hjy2o8 && hjy2o8[Z[326]] === Z[325] && hjy2o8[Z[327]] && hjy2o8[Z[327]][Z[327]]) {
    var i1omb_ = hjy2o8[Z[327]][Z[848]],
        boj1m = [];for (var t3fwu = 0x0; t3fwu < hjy2o8[Z[327]][Z[327]][Z[186]]; t3fwu++) {
      hjy2o8[Z[327]][Z[327]][t3fwu][Z[302]] = $lNOZ(hjy2o8[Z[327]][Z[327]][t3fwu]), (boj1m[Z[186]] == 0x0 || hjy2o8[Z[327]][Z[327]][t3fwu][Z[302]] != 0x0) && (boj1m[boj1m[Z[186]]] = hjy2o8[Z[327]][Z[327]][t3fwu]);
    }$lNM[Z[312]][i1omb_] = window[Z[843]](boj1m), window[Z[261]][Z[313]](i1omb_);
  } else {
    var d8cy2 = hjy2o8 ? hjy2o8[Z[326]] : '';window[Z[654]](0x9, Z[849] + d8cy2), window['$lZONM'](Z[850] + d8cy2);
  }
}, window['$lTOMN'] = function (aqs$g) {
  sendApi($lNM[Z[613]], Z[851], { 'partner_id': $lNM[Z[621]], 'uid': $lNM[Z[490]], 'version': $lNM[Z[540]], 'game_pkg': $lNM[Z[271]], 'device': $lNM[Z[622]] }, reqServerRecommendCallBack, $lOMN, $lMZ);
}, window[Z[852]] = function (tuwzx) {
  $lNM[Z[314]] = ![];if (tuwzx && tuwzx[Z[326]] === Z[325] && tuwzx[Z[327]]) {
    for (var z6t0rx = 0x0; z6t0rx < tuwzx[Z[327]][Z[186]]; z6t0rx++) {
      tuwzx[Z[327]][z6t0rx][Z[302]] = $lNOZ(tuwzx[Z[327]][z6t0rx]);
    }$lNM[Z[312]][-0x2] = window[Z[843]](tuwzx[Z[327]]), window[Z[261]][Z[313]](-0x2);
  } else {
    var akg5$7 = tuwzx ? tuwzx[Z[326]] : '';window[Z[654]](0xa, Z[853] + akg5$7), alert(Z[854] + akg5$7);
  }
}, window[Z[843]] = function (jo12b) {
  return jo12b;
}, window['$lNZO'] = function (asq5n, nsgq5v) {
  asq5n = asq5n || $lNM[Z[157]][Z[158]], sendApi($lNM[Z[613]], Z[855], { 'type': '4', 'game_pkg': $lNM[Z[271]], 'server_id': asq5n }, nsgq5v);
}, window[Z[856]] = function (e7klcd, _jyh2o, _2b1o, cydhe8) {
  _2b1o = _2b1o || $lNM[Z[157]][Z[158]], sendApi($lNM[Z[613]], Z[857], { 'type': e7klcd, 'game_pkg': _jyh2o, 'server_id': _2b1o }, cydhe8);
}, window[Z[858]] = function (ib1m9, e$k7ld) {
  sendApi($lNM[Z[613]], Z[859], { 'game_pkg': ib1m9 }, e$k7ld);
}, window['$lNOZ'] = function (wuzt6x) {
  if (wuzt6x) {
    if (wuzt6x[Z[302]] == 0x1) {
      if (wuzt6x[Z[860]] == 0x1) return 0x2;else return 0x1;
    } else return wuzt6x[Z[302]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$lMZON'] = function (b12_, tuwf3) {
  $lNM[Z[861]] = { 'step': b12_, 'server_id': tuwf3 };var imbo = this;$lZNOM({ 'title': Z[862] }), sendApi($lNM[Z[613]], Z[863], { 'partner_id': $lNM[Z[621]], 'uid': $lNM[Z[490]], 'game_pkg': $lNM[Z[271]], 'server_id': tuwf3, 'platform': $lNM[Z[544]], 'platform_uid': $lNM[Z[723]], 'check_login_time': $lNM[Z[726]], 'check_login_sign': $lNM[Z[724]], 'version_name': $lNM[Z[691]] }, $lMZNO, $lOMN, $lMZ, function ($7glka) {
    return $7glka[Z[326]] == Z[325] || $7glka[Z[475]] == Z[864] || $7glka[Z[475]] == Z[865];
  });
}, window['$lMZNO'] = function (uwzxt6) {
  var hoy_2 = this;if (uwzxt6 && uwzxt6[Z[326]] === Z[325] && uwzxt6[Z[327]]) {
    var _oh2jy = $lNM[Z[157]];_oh2jy[Z[866]] = $lNM[Z[624]], _oh2jy[Z[725]] = String(uwzxt6[Z[327]][Z[867]]), _oh2jy[Z[630]] = parseInt(uwzxt6[Z[327]][Z[727]]);if (uwzxt6[Z[327]][Z[868]]) _oh2jy[Z[868]] = parseInt(uwzxt6[Z[327]][Z[868]]);else _oh2jy[Z[868]] = parseInt(uwzxt6[Z[327]][Z[158]]);_oh2jy[Z[869]] = 0x0, _oh2jy[Z[305]] = $lNM[Z[762]], _oh2jy[Z[870]] = uwzxt6[Z[327]][Z[871]], _oh2jy[Z[872]] = uwzxt6[Z[327]][Z[872]];if (uwzxt6[Z[327]][Z[873]]) _oh2jy[Z[873]] = parseInt(uwzxt6[Z[327]][Z[873]]);console[Z[323]](Z[874] + JSON[Z[432]](_oh2jy[Z[872]])), $lNM[Z[421]] == 0x1 && _oh2jy[Z[872]] && _oh2jy[Z[872]][Z[875]] == 0x1 && ($lNM[Z[217]] = 0x1, window[Z[474]][Z[153]]['$lTMN']()), $lMOZN();
  } else {
    if ($lNM[Z[861]][Z[876]] >= 0x3) {
      var y8cdh2 = uwzxt6 ? uwzxt6[Z[326]] : '';window[Z[654]](0xc, Z[877] + y8cdh2), $lMZ(JSON[Z[432]](uwzxt6)), window['$lZONM'](Z[878] + y8cdh2);
    } else sendApi($lNM[Z[613]], Z[704], { 'platform': $lNM[Z[611]], 'partner_id': $lNM[Z[621]], 'token': $lNM[Z[702]], 'game_pkg': $lNM[Z[271]], 'deviceId': $lNM[Z[622]], 'scene': Z[705] + $lNM[Z[623]] }, function (tuwz6x) {
      if (!tuwz6x || tuwz6x[Z[326]] != Z[325]) {
        window['$lZONM'](Z[721] + tuwz6x && tuwz6x[Z[326]]);return;
      }$lNM[Z[724]] = String(tuwz6x[Z[725]]), $lNM[Z[726]] = String(tuwz6x[Z[727]]), setTimeout(function () {
        $lMZON($lNM[Z[861]][Z[876]] + 0x1, $lNM[Z[861]][Z[158]]);
      }, 0x5dc);
    }, $lOMN, $lMZ, function (lk7$ga) {
      return lk7$ga[Z[326]] == Z[325] || lk7$ga[Z[326]] == Z[879];
    });
  }
}, window['$lMOZN'] = function () {
  ServerLoading[Z[153]][Z[416]]($lNM[Z[421]]), window['$lOM'] = !![], window['$lMNZO']();
}, window['$lMONZ'] = function () {
  if (window['$lMO'] && window['$lNOM'] && window[Z[406]] && window[Z[415]] && window['$lNMO'] && window['$lNO']) {
    if (!window[Z[880]][Z[153]]) {
      console[Z[323]](Z[881] + window[Z[880]][Z[153]]);var m1bo_i = wx[Z[882]](),
          klag$7 = m1bo_i[Z[594]] ? m1bo_i[Z[594]] : 0x0,
          i609p = { 'cdn': window['$lNM'][Z[305]], 'spareCdn': window['$lNM'][Z[689]], 'newRegister': window['$lNM'][Z[421]], 'wxPC': window['$lNM'][Z[569]], 'wxIOS': window['$lNM'][Z[564]], 'wxAndroid': window['$lNM'][Z[566]], 'wxParam': { 'limitLoad': window['$lNM']['$lTZOMN'], 'benchmarkLevel': window['$lNM']['$lTZNOM'], 'wxFrom': window[Z[480]][Z[697]] == Z[883] ? 0x1 : 0x0, 'wxSDKVersion': window[Z[501]] }, 'configType': window['$lNM'][Z[631]], 'exposeType': window['$lNM'][Z[633]], 'scene': klag$7 };new window[Z[880]](i609p, window['$lNM'][Z[214]], window['$lTZONM']);
    }
  }
}, window['$lMNZO'] = function () {
  if (window['$lMO'] && window['$lNOM'] && window[Z[406]] && window[Z[415]] && window['$lNMO'] && window['$lNO'] && window['$lOM'] && window['$lON']) {
    $lZNMO();if (!$lMON) {
      $lMON = !![];if (!window[Z[880]][Z[153]]) window['$lMONZ']();var qg5ns = 0x0,
          yh28oj = wx[Z[884]]();yh28oj && (window['$lNM'][Z[568]] && (qg5ns = yh28oj[Z[109]]), console[Z[475]](Z[885] + yh28oj[Z[109]] + Z[886] + yh28oj[Z[228]] + Z[887] + yh28oj[Z[562]] + Z[888] + yh28oj[Z[69]] + Z[889] + yh28oj[Z[178]] + Z[890] + yh28oj[Z[180]]));var y2oj8 = {};for (const dlkc7 in $lNM[Z[157]]) {
        y2oj8[dlkc7] = $lNM[Z[157]][dlkc7];
      }var cl8hde = { 'channel': window['$lNM'][Z[625]], 'account': window['$lNM'][Z[490]], 'userId': window['$lNM'][Z[722]], 'cdn': window['$lNM'][Z[305]], 'data': window['$lNM'][Z[327]], 'package': window['$lNM'][Z[610]], 'newRegister': window['$lNM'][Z[421]], 'pkgName': window['$lNM'][Z[271]], 'partnerId': window['$lNM'][Z[621]], 'platform_uid': window['$lNM'][Z[723]], 'deviceId': window['$lNM'][Z[622]], 'selectedServer': y2oj8, 'configType': window['$lNM'][Z[631]], 'exposeType': window['$lNM'][Z[633]], 'debugUsers': window['$lNM'][Z[628]], 'wxMenuTop': qg5ns, 'wxShield': window['$lNM'][Z[634]] };if (window[Z[765]]) for (var mi90bp in window[Z[765]]) {
        cl8hde[mi90bp] = window[Z[765]][mi90bp];
      }window[Z[880]][Z[153]]['$lMNT'](cl8hde);if ($lNM[Z[157]] && $lNM[Z[157]][Z[158]]) localStorage[Z[282]](Z[729] + $lNM[Z[271]] + $lNM[Z[490]], $lNM[Z[157]][Z[158]]);
    }
  } else console[Z[475]](Z[891] + window['$lMO'] + Z[892] + window['$lNOM'] + Z[893] + window[Z[406]] + Z[894] + window[Z[415]] + Z[895] + window['$lNMO'] + Z[896] + window['$lNO'] + Z[897] + window['$lOM'] + Z[898] + window['$lON']);
};