var Z = wx.$L;
require(Z[0]);