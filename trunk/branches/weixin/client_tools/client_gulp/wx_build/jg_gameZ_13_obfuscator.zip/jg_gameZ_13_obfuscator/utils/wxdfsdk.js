var Z = wx.$L;
import _0x67ba0 from './log';import _0x5c147c from './sdkhttp';;(function () {
  'use strict';

  var _0x1cd60c = function () {
    this['create'] = function (_0x44cf71) {
      if (!this['sdk']) {
        this['sdk'] = new _0x1385ca();this['sdk']['init'](_0x44cf71);
      }return this;
    };this['login'] = function (_0x1d8559 = null) {
      if (!this['checkInit']()) {
        return;
      }this['sdk']['login'](_0x1d8559);
    };this['submitData'] = function (_0x4d5c11, _0x263f1b = null) {
      if (!this['checkInit']()) {
        return;
      }this['sdk']['submitData'](_0x4d5c11, _0x263f1b);
    };this['pay'] = function (_0x4b79dc, _0x59b7fa = null) {
      if (!this['checkInit']()) {
        return;
      }this['sdk']['pay'](_0x4b79dc, _0x59b7fa);
    };this['messageCheck'] = function (_0x1e76d2, _0x65aba4 = null) {
      this['sdk']['msgSecCheck'](_0x1e76d2, _0x65aba4);
    };this['openCustomerService'] = function (_0x5ba10d = null, _0x1f67a1 = null) {
      this['sdk']['openCustomerService'](_0x5ba10d, _0x1f67a1);
    };this['onShareAppMessage'] = function () {
      this['sdk']['onShareAppMessage']();
    };this['shareAppMessage'] = function (_0x3b4a88 = null) {
      this['sdk']['shareAppMessage'](_0x3b4a88);
    };this['onShareTimeline'] = function () {
      this['sdk']['onShareTimeline']();
    };this['gotoSpecificPage'] = function (_0x43fb19) {
      this['sdk']['gotoSpecificPage'](_0x43fb19);
    };this['requestSubscribe'] = function (_0x1d92f4, _0x4e8746 = null) {
      this['sdk']['requestSubscribe'](_0x1d92f4, _0x4e8746);
    };this['showAd'] = function (_0x147316, _0x5dbbb4 = null) {
      this['sdk']['showAd'](_0x147316, _0x5dbbb4);
    };_0x1cd60c['prototype']['checkInit'] = function () {
      if (!this['sdk']) {
        console['error']('请先使用create方法初始化');return ![];
      }return !![];
    };function _0x1385ca() {
      this['prefix'] = 'df_wxgame_';this['log'] = new _0x67ba0(0x1);
    }_0x1385ca['prototype']['init'] = function (_0x117e3b) {
      var _0x4d15c4 = { 'gameId': 0x0, 'release': !![] };this['opts'] = this['extend']({}, _0x4d15c4, _0x117e3b);this['log']['info']('初始化完成，当前游戏为：' + this['opts']['gameId']);this['cache'] = {};var _0x372476 = this;wx['onShow'](_0x3960be => {
        let _0x157820 = _0x3960be['query'];let _0x124822 = wx['getLaunchOptionsSync']();if (_0x124822['query']) {
          _0x157820 = Object['assign']({}, _0x124822['query'], _0x157820);
        }_0x372476['log']['info']('wx\x20onShow');console['log'](_0x157820);let _0x409be7 = _0x157820['gdt_vid'];if (_0x409be7) {
          _0x372476['cache']['gdt_vid'] = _0x409be7;
        }let _0x2dee9e = _0x157820['weixinadinfo'];if (_0x2dee9e) {
          let _0x470945 = _0x2dee9e['split']('.');let _0x23de1d = _0x470945[0x0];_0x372476['cache']['gdt_aid'] = _0x23de1d;
        }if (_0x157820) {
          _0x372476['cache']['game_query'] = _0x157820;
        }
      });wx['showShareMenu']();_0x5c147c['init']({ 'data': { 'game_id': _0x372476['opts']['gameId'] } })['then'](_0x4cedb8 => {
        if (_0x4cedb8['code'] == 0x0) {
          if (_0x4cedb8['data']['share_info']) {
            _0x372476['cache']['share_info'] = _0x4cedb8['data']['share_info'];
          }var _0x4e9bce = _0x4cedb8['data']['template_ids'];if (_0x4e9bce && Object['keys'](_0x4e9bce)['length'] > 0x0) {
            var _0x30a676 = {};Object['keys'](_0x4e9bce)['forEach'](_0x3408a0 => {
              let _0x37866a = _0x4e9bce[_0x3408a0];if (_0x37866a && _0x37866a['hasOwnProperty']('template_id')) {
                _0x30a676[_0x3408a0] = _0x37866a['template_id'];
              }
            });_0x372476['cache']['template_ids'] = _0x30a676;
          }
        }
      }, _0x96b904 => {
        _0x372476['log']['error'](_0x96b904);
      });return this;
    };_0x1385ca['prototype']['extend'] = function () {
      var _0x4e2bfa = arguments;var _0x201fbd = function (_0x299ae6) {
        if (typeof _0x299ae6 != 'object') return _0x299ae6;if (_0x299ae6 == null) return _0x299ae6;var _0x4f2a2e = new Object();for (var _0x1efe8a in _0x299ae6) {
          _0x4f2a2e[_0x1efe8a] = _0x201fbd(_0x299ae6[_0x1efe8a]);
        }return _0x4f2a2e;
      };if (_0x4e2bfa['length'] < 0x1) return;if (_0x4e2bfa['length'] < 0x2) return _0x4e2bfa[0x0];var _0x4f0fda = _0x201fbd(_0x4e2bfa[0x0]);for (var _0x3baf73 = 0x1; _0x3baf73 < _0x4e2bfa['length']; _0x3baf73++) {
        for (var _0x143766 in _0x4e2bfa[_0x3baf73]) {
          _0x4f0fda[_0x143766] = _0x4e2bfa[_0x3baf73][_0x143766];
        }
      }return _0x4f0fda;
    };_0x1385ca['prototype']['buildResult'] = function (_0x52d60a, _0xcfffd3 = '', _0x321e1d = null) {
      var _0x7df778 = { 'status': _0x52d60a, 'msg': _0xcfffd3 };if (_0x321e1d) {
        _0x7df778['data'] = _0x321e1d;
      }return _0x7df778;
    };_0x1385ca['prototype']['onCallback'] = function (_0x54c7cc, _0x5d5532 = 0x0, _0x5bd1b4 = '', _0x33ecda = null) {
      if (_0x54c7cc && typeof _0x54c7cc == 'function') {
        _0x54c7cc(this['buildResult'](_0x5d5532, _0x5bd1b4, _0x33ecda));
      }
    };_0x1385ca['prototype']['showMessage'] = function (_0x189017, _0xa694e3 = 'none') {
      wx['showToast']({ 'title': _0x189017, 'icon': _0xa694e3, 'duration': 0x7d0 });
    };_0x1385ca['prototype']['showSuccess'] = function (_0x3ef228) {
      this['showMessage'](_0x3ef228, 'success');
    };_0x1385ca['prototype']['showError'] = function (_0x29d8df) {
      this['showMessage'](_0x29d8df, 'error');
    };_0x1385ca['prototype']['saveStorage'] = function (_0x2725f4, _0x2ad810) {
      try {
        wx['setStorageSync'](this['prefix'] + _0x2725f4 + this['opts']['gameId'], _0x2ad810);
      } catch (_0x3fd766) {
        console['error']('save\x20' + _0x2725f4 + '\x20error');
      }
    };_0x1385ca['prototype']['getStorage'] = function (_0x4f14bb, _0x41759d = '') {
      try {
        var _0x155a03 = wx['getStorageSync'](this['prefix'] + _0x4f14bb + this['opts']['gameId']);return _0x155a03;
      } catch (_0x97c571) {
        console['error']('get\x20' + _0x4f14bb + '\x20error');
      }return _0x41759d;
    };_0x1385ca['prototype']['showLoading'] = function (_0x1d4855) {
      wx['showLoading']({ 'title': _0x1d4855 });
    };_0x1385ca['prototype']['hideLoading'] = function () {
      wx['hideLoading']();
    };_0x1385ca['prototype']['getOS'] = function () {
      var _0xf352bf = 0x2;try {
        const _0x49b2f9 = wx['getSystemInfoSync']();var _0x231240 = _0x49b2f9['system'];if (_0x231240['toLowerCase']()['indexOf']('android') > -0x1) {
          _0xf352bf = 0x3;
        }
      } catch (_0x5e41d5) {}return _0xf352bf;
    };_0x1385ca['prototype']['login'] = function (_0x414e89 = null) {
      var _0x498faa = this;_0x498faa['log']['debug']('发起登录');wx['login']({ 'success'(_0x3c24ee) {
          if (_0x3c24ee['code']) {
            var _0x5f1c58 = {};if (_0x498faa['cache']['game_query']) {
              _0x5f1c58 = _0x498faa['cache']['game_query'];
            }if (_0x498faa['cache']['gdt_vid']) {
              _0x5f1c58['gdt_vid'] = _0x498faa['cache']['gdt_vid'];
            }if (_0x498faa['cache']['gdt_aid']) {
              _0x5f1c58['gdt_aid'] = _0x498faa['cache']['gdt_aid'];
            }_0x5f1c58['js_code'] = _0x3c24ee['code'];_0x5f1c58['game_id'] = _0x498faa['opts']['gameId'];_0x5f1c58['os'] = _0x498faa['getOS']();_0x5c147c['auth']({ 'data': _0x5f1c58 })['then'](_0x3fa548 => {
              if (_0x3fa548['code'] == 0x0) {
                var _0x190a14 = _0x3fa548['data'];_0x498faa['userInfo'] = _0x190a14;var _0x3dffa6 = _0x498faa['cache']['template_ids'] ? Object['keys'](_0x498faa['cache']['template_ids']) : [];if (_0x190a14['template_ids']) {
                  _0x3dffa6 = _0x190a14['template_ids'];
                }_0x498faa['onCallback'](_0x414e89, 0x1, 'success', { 'user_id': _0x190a14['userID'], 'user_name': _0x190a14['username'], 'session_id': _0x190a14['token'], 'open_id': _0x190a14['openid'], 'sign': _0x190a14['sign'], 'support_subscribe': _0x3dffa6 });
              } else {
                _0x498faa['showError']('登录失败');_0x498faa['onCallback'](_0x414e89, 0x0, '(' + _0x3fa548['code'] + ')' + _0x3fa548['msg']);
              }
            }, _0x2b2a20 => {
              _0x498faa['showError']('请求登录失败');_0x498faa['onCallback'](_0x414e89, 0x0, '请求登录失败！' + _0x2b2a20);
            });
          } else {
            _0x498faa['showError']('登录失败');_0x498faa['onCallback'](_0x414e89, 0x0, _0x3c24ee['errMsg']);_0x498faa['log']['info']('登录失败！' + _0x3c24ee['errMsg']);
          }
        }, 'fail'(_0x422e72) {
          _0x498faa['showError']('登录失败');_0x498faa['onCallback'](_0x414e89, 0x0, _0x422e72['errMsg']);_0x498faa['log']['error'](_0x422e72['errMsg']);
        } });
    };_0x1385ca['prototype']['submitData'] = function (_0x393135, _0x470fbe = null) {
      var _0x1a75c5 = this;_0x393135['game_id'] = this['opts']['gameId'];_0x393135['uid'] = this['userInfo']['userID'];_0x393135['server_id'] = !_0x393135['server_id'] ? 0x1 : _0x393135['server_id'];_0x393135['type'] = _0x393135['data_type'];_0x393135['os'] = this['getOS']();_0x1a75c5['saveStorage']('server_id', _0x393135['server_id']);_0x1a75c5['saveStorage']('role_id', _0x393135['role_id']);_0x5c147c['report']({ 'data': _0x393135 })['then'](_0x1b8d2d => {
        _0x1a75c5['onCallback'](_0x470fbe, 0x1, '数据上报成功');
      }, _0x15e37b => {
        _0x1a75c5['onCallback'](_0x470fbe, 0x0, '数据上报失败');
      });
    };_0x1385ca['prototype']['pay'] = function (_0x1b9b0f, _0x59d9fc = null) {
      var _0x1354c4 = this;if (!this['userInfo']) {
        console['error']('当前未登录，请登录后重新发起支付');return;
      }_0x1354c4['log']['debug']('发起支付');var _0x27e78f = this['getOS']();var _0x5a0bf1 = { 'game_id': _0x1354c4['opts']['gameId'], 'os': _0x27e78f, 'openid': _0x1354c4['userInfo']['openid'], 'user_id': _0x1354c4['userInfo']['userID'], 'role_id': _0x1354c4['getStorage']('role_id'), 'server_id': _0x1354c4['getStorage']('server_id') };_0x5c147c['examineVerify']({ 'data': _0x5a0bf1 })['then'](_0x306c92 => {
        if (_0x306c92['code'] != 0x0) {
          _0x1354c4['onCallback'](_0x59d9fc, 0x0, '下单失败请重试！' + _0x306c92['msg']);return;
        }var _0xc00e41 = _0x306c92['data']['verify'];var _0x5dd11d = _0x306c92['data']['release'];_0x1354c4['saveStorage']('offer_id', _0x306c92['data']['offer_id']);if (!_0x5dd11d) {
          _0xc00e41 = 0x0;
        }_0x1b9b0f['os'] = _0x27e78f;_0x1354c4['createOrder'](_0xc00e41, _0x1b9b0f, _0x59d9fc);
      }, _0x2d95f1 => {
        _0x1354c4['onCallback'](_0x59d9fc, 0x0, '发起支付失败！' + _0x2d95f1);
      });
    };_0x1385ca['prototype']['createOrder'] = function (_0x40d5fb, _0x54f123, _0x19a24a) {
      var _0x4bb33f = this;if (_0x40d5fb == 0x0 && _0x54f123['os'] == 0x2) {
        _0x4bb33f['showMessage']('IOS暂不支持支付');_0x4bb33f['onCallback'](_0x19a24a, 0x64, 'IOS暂不支持支付功能');return;
      }_0x54f123['game_id'] = _0x4bb33f['opts']['gameId'];_0x54f123['openid'] = _0x4bb33f['userInfo']['openid'];_0x54f123['user_id'] = _0x4bb33f['userInfo']['userID'];var _0x2372e0 = { 'game_id': _0x54f123['game_id'], 'userID': _0x54f123['user_id'], 'user_name': _0x4bb33f['userInfo']['username'], 'openid': _0x54f123['openid'], 'server_id': !_0x54f123['server_id'] ? 0x1 : _0x54f123['server_id'], 'roleId': _0x54f123['role_id'], 'role_name': _0x54f123['role_name'], 'ext': _0x54f123['ext'], 'money': _0x54f123['money'], 'game_gold': !_0x54f123['game_gold'] ? _0x54f123['money'] * 0x64 : _0x54f123['game_gold'], 'os': _0x54f123['os'] };_0x5c147c['createOrder']({ 'data': _0x2372e0 })['then'](_0x517c16 => {
        if (_0x517c16['code'] != 0x0) {
          _0x4bb33f['onCallback'](_0x19a24a, 0x0, '创建订单失败！' + _0x517c16['msg']);return;
        }_0x54f123['orderid'] = _0x517c16['data']['orderID'];if (_0x517c16['data']['pay_url']) {
          _0x54f123['pay_url'] = _0x517c16['data']['pay_url'];
        }if (_0x40d5fb == 0x0) {
          _0x4bb33f['payByMidas'](_0x54f123, _0x19a24a);
        } else if (_0x40d5fb == 0x1) {
          if (_0x517c16['data']['icon_url']) {
            _0x54f123['icon_url'] = _0x517c16['data']['icon_url'];
          }_0x4bb33f['payByCustomerService'](_0x54f123, _0x19a24a);
        } else if (_0x40d5fb == 0x2) {
          _0x54f123['mp_appid'] = _0x517c16['data']['mp_appid'];if (_0x517c16['data']['app_path']) {
            _0x54f123['app_path'] = _0x517c16['data']['app_path'];
          }if (_0x517c16['data']['env_version']) {
            _0x54f123['env_version'] = _0x517c16['data']['env_version'];
          }_0x4bb33f['payByMiniProgram'](_0x54f123, _0x19a24a);
        } else {
          _0x4bb33f['payByBrowser'](_0x54f123, _0x19a24a);
        }
      }, _0x2cbfcc => {
        _0x4bb33f['onCallback'](_0x19a24a, 0x0, '创建订单失败！' + _0x2cbfcc);
      });
    };_0x1385ca['prototype']['payByMidas'] = function (_0x327823, _0x59d064 = null) {
      var _0x2dba3e = this;var _0x7266e7 = 0x64;var _0x7b047c = function () {
        _0x5c147c['payMidas']({ 'data': _0x327823 })['then'](_0x1e6f9c => {
          if (_0x1e6f9c['errcode'] && _0x1e6f9c['errcode'] != 0x0) {
            _0x2dba3e['showMessage']('支付未完成');_0x2dba3e['onCallback'](_0x59d064, 0x0, '支付失败！' + _0x1e6f9c['errcode']);return;
          }_0x2dba3e['showMessage']('支付完成');_0x2dba3e['onCallback'](_0x59d064, 0x1, '支付完成', { 'order_id': _0x327823['orderid'] });
        }, _0xcacff3 => {
          _0x2dba3e['showMessage']('支付未完成');_0x2dba3e['onCallback'](_0x59d064, 0x0, '支付失败！' + _0xcacff3);
        });
      };_0x5c147c['balance']({ 'data': { 'game_id': this['opts']['gameId'], 'openid': this['userInfo']['openid'] } })['then'](_0x4d29b8 => {
        if (_0x4d29b8['errcode'] == 0x0) {
          _0x2dba3e['log']['debug'](_0x4d29b8);if (_0x4d29b8['balance'] >= _0x327823['money'] * _0x7266e7) {
            _0x7b047c();
          } else {
            _0x2dba3e['log']['debug'](_0x327823);wx['requestMidasPayment']({ 'mode': 'game', 'env': _0x4d29b8['env'], 'offerId': _0x2dba3e['getStorage']('offer_id'), 'currencyType': 'CNY', 'buyQuantity': _0x327823['money'] * _0x7266e7, 'platform': 'android', 'zoneId': 0x1, 'success'(_0x504244) {
                _0x7b047c();
              }, 'fail'(_0x5a6434) {
                _0x2dba3e['onCallback'](_0x59d064, 0x0, '(' + _0x5a6434['errCode'] + ')' + _0x5a6434['errMsg']);
              } });
          }
        } else {
          _0x2dba3e['onCallback'](_0x59d064, 0x0, '(' + _0x4d29b8['errcode'] + ')' + _0x4d29b8['errmsg']);
        }
      }, _0x5d3ade => {
        _0x2dba3e['showError']('支付失败请重试');_0x2dba3e['onCallback'](_0x59d064, 0x0, '支付失败请重试！' + _0x5d3ade);
      });
    };_0x1385ca['prototype']['payByCustomerService'] = function (_0x1f4297, _0x31e658 = null) {
      var _0x487c12 = this;if (!_0x1f4297['pay_url']) {
        _0x487c12['showMessage']('获取支付链接有误');_0x487c12['onCallback'](_0x31e658, 0x0, '支付链接有误');return;
      }var _0x5a7f8e = _0x1f4297['pay_url'];wx['setClipboardData']({ 'data': '订单号:\x20' + _0x1f4297['orderid'] + '\x0a充值链接:\x20' + _0x5a7f8e + '\x0a\x0a点击以上链接即可充值，若遇到充值问题，请及时联系客服。', 'success'(_0xb3e4fa) {
          wx['showModal']({ 'title': '充值教程', 'content': '充值链接已经复制，请点击确定前往客服中心，如果没有自动收到订单入口，请粘贴并发送内容获取支付链接入口', 'showCancel': ![], 'success'(_0x2c1fc8) {
              if (_0x2c1fc8['confirm']) {
                wx['openCustomerServiceConversation']({ 'sessionFrom': '', 'showMessageCard': !![], 'sendMessageTitle': '获取充值地址', 'sendMessagePath': 'wxgamepay/orderid/' + _0x1f4297['orderid'], 'sendMessageImg': _0x1f4297['icon_url'] ? _0x1f4297['icon_url'] : 'https://image.dfkj8.com/pic/concect_kf.png', 'success'(_0x16242b) {}, 'fail'(_0xdc6285) {
                    _0x487c12['log']['debug'](_0xdc6285['errMsg']);_0x487c12['onCallback'](_0x31e658, 0x0, _0xdc6285['errMsg']);
                  } });
              }
            } });
        } });
    };_0x1385ca['prototype']['payByMiniProgram'] = function (_0x1ebc05, _0x40dd8e = null) {
      var _0x51fac4 = this;if (!_0x1ebc05['mp_appid']) {
        _0x51fac4['showMessage']('支付跳转失败');_0x51fac4['onCallback'](_0x40dd8e, 0x0, '支付跳转失败');return;
      }wx['navigateToMiniProgram']({ 'appId': _0x1ebc05['mp_appid'], 'path': _0x1ebc05['app_path'] ? _0x1ebc05['app_path'] : 'pages/pay/index', 'envVersion': _0x1ebc05['env_version'] ? _0x1ebc05['env_version'] : 'release', 'extraData': _0x1ebc05, 'success'(_0x4d097e) {
          _0x51fac4['log']['debug']('跳转小程序成功:' + _0x4d097e);
        }, 'fail'(_0x20a2e5) {
          _0x51fac4['log']['debug']('跳转小程序失败:' + _0x20a2e5);_0x51fac4['onCallback'](_0x40dd8e, 0x0, _0x20a2e5['errMsg']);
        } });
    };_0x1385ca['prototype']['payByBrowser'] = function (_0x275bca, _0x15f65a) {
      var _0x7ae4aa = this;if (!_0x275bca['pay_url']) {
        _0x7ae4aa['showMessage']('获取支付链接有误');_0x7ae4aa['onCallback'](_0x15f65a, 0x0, '支付链接有误');return;
      }wx['setClipboardData']({ 'data': _0x275bca['pay_url'], 'success'(_0x47d7a7) {
          wx['showModal']({ 'title': '充值链接已复制', 'content': '请在外部浏览器粘贴充值链接后支付', 'showCancel': ![], 'success'(_0xa90af4) {} });
        } });
    };_0x1385ca['prototype']['msgSecCheck'] = function (_0x24e32b, _0x106963) {
      var _0x3638be = this;var _0x422ac0 = { 'game_id': _0x3638be['opts']['gameId'], 'content': _0x24e32b['content'], 'openid': _0x3638be['userInfo'] && _0x3638be['userInfo']['openid'] ? _0x3638be['userInfo']['openid'] : '' };_0x5c147c['msgSecCheck']({ 'data': _0x422ac0 })['then'](_0x13a8bb => {
        var _0x3e476e = _0x13a8bb['errcode'] == 0x0 ? !![] : ![];_0x3638be['onCallback'](_0x106963, 0x1, _0x13a8bb['errmsg'], { 'passed': _0x3e476e });
      }, _0x13ab27 => {
        _0x3638be['onCallback'](_0x106963, 0x0, '请求失败请重试！' + _0x13ab27);
      });
    };_0x1385ca['prototype']['openCustomerService'] = function (_0x2af8e0 = null, _0x950cba = null) {
      var _0x4ddc91 = this;wx['openCustomerServiceConversation']({ 'sessionFrom': '', 'showMessageCard': ![], 'sendMessageTitle': '', 'sendMessagePath': '', 'sendMessageImg': '', 'success'(_0xba98b5) {
          _0x4ddc91['log']['debug'](_0xba98b5);
        }, 'fail'(_0x4974e0) {
          _0x4ddc91['log']['debug'](_0x4974e0['errMsg']);_0x4ddc91['onCallback'](_0x950cba, 0x0, _0x4974e0['errMsg']);
        } });
    };_0x1385ca['prototype']['getDefaultShareInfo'] = function () {
      var _0x4f4d40 = this;var _0x5c4310 = { 'share_title': '', 'share_img_url': '', 'share_img_id': '', 'share_query': '', 'share_img_preview_url': '', 'share_img_preview_id': '' };var _0x56ad5e = this['extend']({}, _0x5c4310, this['cache']['share_info'] ? this['cache']['share_info'] : {});return _0x56ad5e;
    };_0x1385ca['prototype']['onShareAppMessage'] = function () {
      var _0x46c28b = this;var _0xda9c42 = this['getDefaultShareInfo']();wx['onShareAppMessage'](function () {
        _0x46c28b['log']['debug']('onShareAppMessage');return { 'title': _0xda9c42['share_title'] ? _0xda9c42['share_title'] : '', 'imageUrl': _0xda9c42['share_img_url'] ? _0xda9c42['share_img_url'] : '', 'query': _0xda9c42['share_query'] ? _0xda9c42['share_query'] : '', 'imageUrlId': _0xda9c42['share_img_id'] ? _0xda9c42['share_img_id'] : '' };
      });
    };_0x1385ca['prototype']['shareAppMessage'] = function (_0x3a8606 = null) {
      var _0x380bb1 = this;var _0x26c1be = this['getDefaultShareInfo']();_0x26c1be = this['extend']({}, _0x26c1be, _0x3a8606 ? _0x3a8606 : {});wx['shareAppMessage'](function () {
        _0x380bb1['log']['debug']('shareAppMessage');return { 'title': _0x26c1be['share_title'] ? _0x26c1be['share_title'] : '', 'imageUrl': _0x26c1be['share_img_url'] ? _0x26c1be['share_img_url'] : '', 'query': _0x26c1be['share_query'] ? _0x26c1be['share_query'] : '', 'imageUrlId': _0x26c1be['share_img_id'] ? _0x26c1be['share_img_id'] : '' };
      });
    };_0x1385ca['prototype']['onShareTimeline'] = function () {
      var _0x57f4c4 = this;var _0x21169e = this['getDefaultShareInfo']();wx['onShareTimeline'](function () {
        _0x57f4c4['log']['debug']('onShareTimeline');return { 'title': _0x21169e['share_title'] ? _0x21169e['share_title'] : '', 'imageUrl': _0x21169e['share_img_url'] ? _0x21169e['share_img_url'] : '', 'query': _0x21169e['share_query'] ? _0x21169e['share_query'] : '', 'imageUrlId': _0x21169e['share_img_id'] ? _0x21169e['share_img_id'] : '', 'imagePreviewUrl': _0x21169e['share_img_preview_url'] ? _0x21169e['share_img_preview_url'] : '', 'imagePreviewUrlId': _0x21169e['share_img_preview_id'] ? _0x21169e['share_img_preview_id'] : '' };
      });
    };_0x1385ca['prototype']['gotoSpecificPage'] = function (_0x1e8159) {
      var _0x1e147d = this;if (!_0x1e8159) {
        _0x1e147d['log']['error']('请传入action');return;
      }var _0x55490a = { 'game_id': _0x1e147d['opts']['gameId'], 'user_id': _0x1e147d['userInfo'] && _0x1e147d['userInfo']['userID'] ? _0x1e147d['userInfo']['userID'] : '', 'user_name': _0x1e147d['userInfo'] && _0x1e147d['userInfo']['username'] ? _0x1e147d['userInfo']['username'] : '', 'openid': _0x1e147d['userInfo'] && _0x1e147d['userInfo']['openid'] ? _0x1e147d['userInfo']['openid'] : '', 'os': _0x1e147d['getOS'](), 'action': _0x1e8159 };_0x5c147c['specificPage']({ 'data': _0x55490a })['then'](_0xe455e1 => {
        if (_0xe455e1['code'] == 0x0) {
          if (_0xe455e1['data']) {
            if (_0xe455e1['data']['copyData']) {
              wx['setClipboardData']({ 'data': _0xe455e1['data']['copyData'], 'success'(_0x537ba6) {} });
            }wx['openCustomerServiceConversation']({ 'sessionFrom': _0xe455e1['data']['sessionFrom'], 'showMessageCard': _0xe455e1['data']['showMessageCard'], 'sendMessageTitle': _0xe455e1['data']['sendMessageTitle'], 'sendMessagePath': _0xe455e1['data']['sendMessagePath'], 'sendMessageImg': _0xe455e1['data']['sendMessageImg'], 'success'(_0x261429) {}, 'fail'(_0x2e83b0) {
                _0x1e147d['showMessage']('跳转失败');_0x1e147d['log']['error'](_0x2e83b0['errMsg']);
              } });
          }
        } else {
          _0x1e147d['showMessage'](_0xe455e1['msg'] ? _0xe455e1['msg'] : '不支持的方式');
        }
      }, _0x511326 => {
        _0x1e147d['showMessage']('跳转失败');_0x1e147d['log']['error'](_0x511326);
      });
    };_0x1385ca['prototype']['requestSubscribe'] = function (_0x2c1d87, _0x403e99 = null) {
      var _0x1df0a9 = this;var _0x5579f9 = {};if (_0x2c1d87 && _0x2c1d87['length'] > 0x0 && _0x1df0a9['cache']['template_ids'] && Object['keys'](_0x1df0a9['cache']['template_ids'])['length'] > 0x0) {
        _0x2c1d87['forEach'](_0x51cca1 => {
          if (_0x1df0a9['cache']['template_ids']['hasOwnProperty'](_0x51cca1)) {
            _0x5579f9[_0x1df0a9['cache']['template_ids'][_0x51cca1]] = _0x51cca1;
          }
        });
      }if (!_0x5579f9 || Object['keys'](_0x5579f9)['length'] == 0x0) {
        _0x1df0a9['onCallback'](_0x403e99, 0x0, '订阅模板为空');return;
      }wx['onTouchEnd'](function (_0x2e0ce3, _0x55d948, _0x1ff0a9) {
        wx['requestSubscribeMessage']({ 'tmplIds': Object['keys'](_0x5579f9), 'success'(_0x3883d9) {
            var _0x5f2db3 = [];Object['keys'](_0x3883d9)['forEach'](_0x3b66f8 => {
              if (_0x5579f9['hasOwnProperty'](_0x3b66f8) && _0x3883d9[_0x3b66f8] == 'accept') {
                _0x5f2db3['push'](_0x5579f9[_0x3b66f8]);
              }
            });_0x1df0a9['onCallback'](_0x403e99, 0x1, 'success', _0x5f2db3);
          }, 'fail'(_0x11a47) {
            _0x1df0a9['onCallback'](_0x403e99, 0x0, '订阅失败(' + _0x11a47['errCode'] + ')' + _0x11a47['errMsg']);
          } });
      });
    };_0x1385ca['prototype']['showAd'] = function (_0x1af681, _0x21a27f = null) {
      var _0x58d19d = this;let _0x41f0c2 = function (_0x294846, _0x12b33d = '广告加载失败') {
        _0x21a27f['callback'] && _0x21a27f['callback']['onError'] && _0x21a27f['callback']['onError'](_0x294846, _0x12b33d);
      };if (!_0x21a27f || !_0x21a27f['adUnitId']) {
        _0x58d19d['log']['error']('广告参数有误，请检查您的广告位id');_0x41f0c2(-0x1);return;
      }var _0x4ca5de = null;switch (_0x1af681) {case 0x65:
          if (wx['createRewardedVideoAd']) {
            _0x4ca5de = wx['createRewardedVideoAd']({ 'adUnitId': _0x21a27f['adUnitId'] });
          }break;default:
          _0x58d19d['log']['error']('暂不支持的广告类型');_0x41f0c2(-0x2, '暂不支持的广告类型');break;};if (_0x4ca5de) {
        _0x4ca5de['onLoad'](() => {
          _0x21a27f['callback'] && _0x21a27f['callback']['onLoad'] && _0x21a27f['callback']['onLoad']();_0x4ca5de['show']()['catch'](() => {
            _0x4ca5de['load']()['then'](() => _0x4ca5de['show']())['catch'](_0x428ccb => {
              _0x41f0c2(_0x428ccb ? _0x428ccb['errCode'] : -0x64, _0x428ccb ? _0x428ccb['errMsg'] : '广告显示失败');
            });
          });
        });_0x4ca5de['onError'](_0x2d5b35 => {
          _0x41f0c2(_0x2d5b35 ? _0x2d5b35['errCode'] : -0x64, _0x2d5b35 ? _0x2d5b35['errMsg'] : '广告加载失败');
        });_0x4ca5de['onClose'](_0x24d97f => {
          if (_0x1af681 == 0x64) {
            if (_0x24d97f && _0x24d97f['isEnded']) {
              _0x21a27f['callback'] && _0x21a27f['callback']['onReward'] && _0x21a27f['callback']['onReward']();
            }
          }_0x21a27f['callback'] && _0x21a27f['callback']['onClose'] && _0x21a27f['callback']['onClose']();
        });
      } else {
        _0x41f0c2(-0x3);
      }
    };
  };var _0x11d404 = new _0x1cd60c();module['exports']['dfSDK'] = _0x11d404;
})();