var Z = wx.$L;
require('llllllBF.js'), window[Z[30476]][Z[30477]][Z[30478]] = null, window['client_pb'] = require('LLLCLIENTPB.js'), window[Z[26785]] = window[Z[30476]][Z[26698]][Z[26699]](client_pb);