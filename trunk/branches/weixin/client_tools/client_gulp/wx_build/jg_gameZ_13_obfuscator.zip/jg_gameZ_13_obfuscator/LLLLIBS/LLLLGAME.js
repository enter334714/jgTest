var Z = wx.$L;
console[Z[475]](Z[476]), window[Z[477]], wx[Z[478]](function (boj12_) {
  if (boj12_) {
    if (boj12_[Z[479]]) {
      var $kl = window[Z[480]][Z[481]][Z[298]](new RegExp(/\./, 'g'), '_'),
          bm_p1 = boj12_[Z[479]],
          yhcd28 = bm_p1[Z[461]](/(LLLLLLLL\/LLLLGAME.js:)[0-9]{1,60}(:)/g);if (yhcd28) for (var xrz906 = 0x0; xrz906 < yhcd28[Z[186]]; xrz906++) {
        if (yhcd28[xrz906] && yhcd28[xrz906][Z[186]] > 0x0) {
          var v54n = parseInt(yhcd28[xrz906][Z[298]](Z[482], '')[Z[298]](':', ''));bm_p1 = bm_p1[Z[298]](yhcd28[xrz906], yhcd28[xrz906][Z[298]](':' + v54n + ':', ':' + (v54n - 0x2) + ':'));
        }
      }bm_p1 = bm_p1[Z[298]](new RegExp(Z[483], 'g'), Z[484] + $kl + Z[485]), bm_p1 = bm_p1[Z[298]](new RegExp(Z[486], 'g'), Z[484] + $kl + Z[485]), boj12_[Z[479]] = bm_p1;
    }var oyj_2h = { 'id': window['$lNM'][Z[487]], 'role': window['$lNM'][Z[488]], 'level': window['$lNM'][Z[489]], 'user': window['$lNM'][Z[490]], 'version': window['$lNM'][Z[214]], 'cdn': window['$lNM'][Z[305]], 'pkgName': window['$lNM'][Z[271]], 'gamever': window[Z[480]][Z[481]], 'serverid': window['$lNM'][Z[157]] ? window['$lNM'][Z[157]][Z[158]] : 0x0, 'systemInfo': window[Z[491]], 'error': Z[492], 'stack': boj12_ ? boj12_[Z[479]] : '' },
        wrxz = JSON[Z[432]](oyj_2h);console[Z[434]](Z[493] + wrxz), (!window[Z[477]] || window[Z[477]] != oyj_2h[Z[434]]) && (window[Z[477]] = oyj_2h[Z[434]], window['$lZN'](oyj_2h));
  }
});import 'lllMDFIVEMIN.js';import 'lllZLIBS.js';window[Z[494]] = require(Z[495]);import 'LLLLINDEX.js';import 'llllLIBSMIN.js';import 'LLLLWXMINI.js';import 'LLLINITMIN.js';console[Z[475]](Z[496]), console[Z[475]](Z[497]), $lZNOM({ 'title': Z[498] });var l1m9i0b = { '$lTZMNO': !![] };new window[Z[474]](l1m9i0b), window[Z[474]][Z[153]]['$lTONMZ']();if (window['$lTZNMO']) clearInterval(window['$lTZNMO']);window['$lTZNMO'] = null, window['$lTOMZN'] = function (dyc, c8lhde) {
  if (!dyc || !c8lhde) return 0x0;dyc = dyc[Z[499]]('.'), c8lhde = c8lhde[Z[499]]('.');const ch8del = Math[Z[500]](dyc[Z[186]], c8lhde[Z[186]]);while (dyc[Z[186]] < ch8del) {
    dyc[Z[331]]('0');
  }while (c8lhde[Z[186]] < ch8del) {
    c8lhde[Z[331]]('0');
  }for (var ng5vs = 0x0; ng5vs < ch8del; ng5vs++) {
    const dc8el = parseInt(dyc[ng5vs]),
          sqgan5 = parseInt(c8lhde[ng5vs]);if (dc8el > sqgan5) return 0x1;else {
      if (dc8el < sqgan5) return -0x1;
    }
  }return 0x0;
}, window[Z[501]] = wx[Z[502]]()[Z[501]], console[Z[323]](Z[503] + window[Z[501]]);var l1pir069 = wx[Z[504]]();l1pir069[Z[505]](function (l7k$d) {
  console[Z[323]](Z[506] + l7k$d[Z[507]]);
}), l1pir069[Z[508]](function () {
  wx[Z[509]]({ 'title': Z[510], 'content': Z[511], 'showCancel': ![], 'success': function (dekc7) {
      l1pir069[Z[512]]();
    } });
}), l1pir069[Z[513]](function () {
  console[Z[323]](Z[514]);
}), window['$lTOMNZ'] = function () {
  console[Z[323]](Z[515]);var cd2h8 = wx[Z[516]]({ 'name': Z[517], 'success': function (l7k$) {
      console[Z[323]](Z[518]), console[Z[323]](l7k$), l7k$ && l7k$[Z[519]] == Z[520] ? (window['$lMO'] = !![], window['$lMONZ'](), window['$lMNZO']()) : setTimeout(function () {
        window['$lTOMNZ']();
      }, 0x1f4);
    }, 'fail': function ($l7e) {
      console[Z[323]](Z[521]), console[Z[323]]($l7e), setTimeout(function () {
        window['$lTOMNZ']();
      }, 0x1f4);
    } });cd2h8 && cd2h8[Z[522]](ohj28 => {});
}, window['$lTNZMO'] = function () {
  console[Z[323]](Z[523]);var y2_ohj = wx[Z[516]]({ 'name': Z[524], 'success': function (he8lcd) {
      console[Z[323]](Z[525]), console[Z[323]](he8lcd), he8lcd && he8lcd[Z[519]] == Z[520] ? (window['$lNOM'] = !![], window['$lMONZ'](), window['$lMNZO']()) : setTimeout(function () {
        window['$lTNZMO']();
      }, 0x1f4);
    }, 'fail': function (fuwt3) {
      console[Z[323]](Z[526]), console[Z[323]](fuwt3), setTimeout(function () {
        window['$lTNZMO']();
      }, 0x1f4);
    } });y2_ohj && y2_ohj[Z[522]](ztx06r => {});
}, window[Z[527]] = function () {
  window['$lTOMZN'](window[Z[501]], Z[528]) >= 0x0 ? (console[Z[323]](Z[529] + window[Z[501]] + Z[530]), window['$lNZ'](), window['$lTOMNZ'](), window['$lTNZMO']()) : (window['$lNMZ'](Z[531], window[Z[501]]), wx[Z[509]]({ 'title': Z[532], 'content': Z[533] }));
}, window[Z[491]] = '', wx[Z[534]]({ 'success'(sn4q) {
    window[Z[491]] = Z[535] + sn4q[Z[536]] + Z[537] + sn4q[Z[538]] + Z[539] + sn4q[Z[540]] + Z[541] + sn4q[Z[542]] + Z[543] + sn4q[Z[544]] + Z[545] + sn4q[Z[501]] + Z[546] + sn4q[Z[547]], console[Z[323]](window[Z[491]]), console[Z[323]](Z[548] + sn4q[Z[549]] + Z[550] + sn4q[Z[551]] + Z[552] + sn4q[Z[553]] + Z[554] + sn4q[Z[555]] + Z[556] + sn4q[Z[557]] + Z[558] + sn4q[Z[559]] + Z[560] + (sn4q[Z[561]] ? sn4q[Z[561]][Z[109]] + ',' + sn4q[Z[561]][Z[228]] + ',' + sn4q[Z[561]][Z[562]] + ',' + sn4q[Z[561]][Z[69]] : ''));var bim09p = sn4q[Z[542]] ? sn4q[Z[542]][Z[563]]() : '',
        _21ojb = sn4q[Z[538]] ? sn4q[Z[538]][Z[563]]()[Z[298]]('\x20', '') : '';window['$lNM'][Z[564]] = bim09p[Z[454]](Z[565]) != -0x1, window['$lNM'][Z[566]] = bim09p[Z[454]](Z[567]) != -0x1, window['$lNM'][Z[568]] = bim09p[Z[454]](Z[565]) != -0x1 || bim09p[Z[454]](Z[567]) != -0x1, window['$lNM'][Z[569]] = bim09p[Z[454]](Z[570]) != -0x1 || bim09p[Z[454]](Z[571]) != -0x1, window['$lNM'][Z[572]] = sn4q[Z[544]] ? sn4q[Z[544]][Z[563]]() : '', window['$lNM']['$lTZOMN'] = ![], window['$lNM']['$lTZNOM'] = 0x2;if (bim09p[Z[454]](Z[567]) != -0x1) {
      if (sn4q[Z[547]] >= 0x18) window['$lNM']['$lTZNOM'] = 0x3;else window['$lNM']['$lTZNOM'] = 0x2;
    } else {
      if (bim09p[Z[454]](Z[565]) != -0x1) {
        if (sn4q[Z[547]] && sn4q[Z[547]] >= 0x14) window['$lNM']['$lTZNOM'] = 0x3;else {
          if (_21ojb[Z[454]](Z[573]) != -0x1 || _21ojb[Z[454]](Z[574]) != -0x1 || _21ojb[Z[454]](Z[575]) != -0x1 || _21ojb[Z[454]](Z[576]) != -0x1 || _21ojb[Z[454]](Z[577]) != -0x1) window['$lNM']['$lTZNOM'] = 0x2;else window['$lNM']['$lTZNOM'] = 0x3;
        }
      } else window['$lNM']['$lTZNOM'] = 0x2;
    }console[Z[323]](Z[578] + window['$lNM']['$lTZOMN'] + Z[579] + window['$lNM']['$lTZNOM']);
  } }), wx[Z[580]]({ 'success': function (g7$kl) {
    console[Z[323]](Z[581] + g7$kl[Z[582]] + Z[583] + g7$kl[Z[584]]);
  } }), wx[Z[585]]({ 'success': function (r6x09) {
    console[Z[323]](Z[586] + r6x09[Z[587]]);
  } }), wx[Z[588]]({ 'keepScreenOn': !![] }), wx[Z[589]](function (jo_hy) {
  console[Z[323]](Z[586] + jo_hy[Z[587]] + Z[590] + jo_hy[Z[591]]);
}), wx[Z[592]](function (m0p9r) {
  window['$lOZ'] = m0p9r, window['$lMZO'] && window['$lOZ'] && (console[Z[475]](Z[593] + window['$lOZ'][Z[594]]), window['$lMZO'](window['$lOZ']), window['$lOZ'] = null);
}), window[Z[595]] = 0x0, window['$lTNOMZ'] = 0x0, window[Z[596]] = null, wx[Z[597]](function () {
  window['$lTNOMZ']++;var $lkd7 = Date[Z[152]]();(window[Z[595]] == 0x0 || $lkd7 - window[Z[595]] > 0x1d4c0) && (console[Z[451]](Z[598]), wx[Z[599]]());if (window['$lTNOMZ'] >= 0x2) {
    window['$lTNOMZ'] = 0x0, console[Z[434]](Z[600]), wx[Z[601]]('0', 0x1);if (window['$lNM'] && window['$lNM'][Z[564]]) window['$lNMZ'](Z[602], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});