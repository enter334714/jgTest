var Z = wx.$L;
import _0x396cde from './request.js';const md5 = require('./md5');const HOST = 'https://wxapi.dfkj8.com';const API_LIST = { 'init': { 'method': 'GET', 'url': '/web/xcx/init' }, 'auth': { 'method': 'GET', 'url': '/web/xcx/author', 'showLoading': !![], 'loadingText': '正在登录' }, 'report': { 'method': 'GET', 'url': '/web/xcx/reportRoleInfo' }, 'examineVerify': { 'method': 'GET', 'url': '/web/xcx/examineVerify', 'needSign': !![] }, 'createOrder': { 'method': 'POST', 'url': '/web/xcx/createOrder', 'showLoading': !![] }, 'balance': { 'method': 'GET', 'url': '/web/xcx/getBalance' }, 'payMidas': { 'method': 'POST', 'url': '/web/xcx/deduction', 'showLoading': !![], 'loadingText': '支付中', 'needSign': !![] }, 'msgSecCheck': { 'method': 'POST', 'url': '/web/xcx/msgSecCheck' }, 'specificPage': { 'method': 'GET', 'url': '/web/xcx/getPageInfo' } };function HttpRequest(_0x24d61e, _0xdecb56) {
  var _0x16c696 = this;let _0x21f5d5 = HOST;let _0x5adfda = {};for (let _0x160268 in _0xdecb56) {
    let _0x301888 = _0xdecb56[_0x160268];_0x5adfda[_0x160268] = _0x209adb => {
      let _0x459de1 = _0x209adb && _0x209adb['data'] ? _0x209adb['data'] : null;let _0x191ce2 = _0x301888['showLoading'] ? _0x301888['showLoading'] : ![];let _0x1636a0 = _0x301888['loadingText'] ? _0x301888['loadingText'] : '';let _0x574a0f = _0x301888['needSign'] ? _0x301888['needSign'] : ![];if (_0x574a0f && _0x459de1) {
        _0x459de1 = _0x16c696['signParmas'](_0x459de1);
      }return _0x396cde(_0x21f5d5 + _0x301888['url'], _0x301888['method'], _0x459de1, { 'content-type': 'application/x-www-form-urlencoded;charset=utf-8;Authorization;' }, _0x191ce2, _0x1636a0);
    };
  }return _0x5adfda;
};HttpRequest['prototype']['signParmas'] = function (_0x1d335b) {
  const _0x592dd8 = 'B055a52beb92940b15e29e0019d8d89d';let _0x100df1 = new Date();_0x100df1 = parseInt(_0x100df1['getTime']() / 0x3e8);let _0x5b6835 = md5(_0x1d335b['game_id'] + '' + _0x100df1 + _0x592dd8);_0x1d335b['time'] = _0x100df1;_0x1d335b['sign'] = _0x5b6835;return _0x1d335b;
};const Api = new HttpRequest({}, API_LIST);export default Api;