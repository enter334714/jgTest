var Z = wx.$L;
(function (window, document, k7g$5a) {
  var zx6wrt = k7g$5a['un'],
      x0z6r9 = k7g$5a['uns'],
      ohj8y = k7g$5a['static'],
      held8 = k7g$5a['class'],
      y2_jh = k7g$5a['getset'],
      z6r0x9 = k7g$5a['__newvec'],
      _21 = laya['utils']['Browser'],
      p09rm = laya['events']['Event'],
      qs$5a = laya['events']['EventDispatcher'],
      ke$l = laya['resource']['HTMLImage'],
      a$gq = laya['utils']['Handler'],
      ed7l$k = laya['display']['Input'],
      x0p96r = laya['net']['Loader'],
      g$l7k = laya['maths']['Matrix'],
      y8chde = laya['renders']['Render'],
      ae7$k = laya['utils']['RunDriver'],
      mpri90 = laya['media']['Sound'],
      sq5gvn = laya['media']['SoundChannel'],
      yc28dh = laya['media']['SoundManager'],
      ch8jy2 = laya['display']['Stage'],
      o_hjy = laya['net']['URL'],
      y2h8cd = laya['utils']['Utils'],
      saqng5 = function () {
    function job_1() {}return held8(job_1, 'laya.wx.mini.MiniAdpter'), job_1['getJson'] = function (kga75) {
      return JSON['parse'](kga75);
    }, job_1['init'] = function (boim, m9ri0) {
      boim === void 0x0 && (boim = ![]), m9ri0 === void 0x0 && (m9ri0 = ![]);if (job_1['_inited']) return;job_1['window'] = window;if (job_1['window']['navigator']['userAgent']['indexOf']('MiniGame') < 0x0) return;job_1['_inited'] = !![], job_1['isZiYu'] = m9ri0, job_1['isPosMsgYu'] = boim, job_1['EnvConfig'] = {}, !job_1['isZiYu'] && (bi_pm1['setNativeFileDir']('/layaairGame'), bi_pm1['existDir'](bi_pm1['fileNativeDir'], a$gq['create'](job_1, job_1['onMkdirCallBack']))), job_1['window']['focus'] = function () {}, k7g$5a['getUrlPath'] = function () {}, job_1['window']['logtime'] = function (el$k7) {}, job_1['window']['alertTimeLog'] = function (c2dyh) {}, job_1['window']['resetShareInfo'] = function () {}, job_1['window']['CanvasRenderingContext2D'] = function () {}, job_1['window']['CanvasRenderingContext2D']['prototype'] = job_1['window']['wx']['createCanvas']()['getContext']('2d')['__proto__'], job_1['window']['document']['body']['appendChild'] = function () {}, job_1['EnvConfig']['pixelRatioInt'] = 0x0, ae7$k['getPixelRatio'] = job_1['pixelRatio'], job_1['_preCreateElement'] = _21['createElement'], _21['createElement'] = job_1['createElement'], ae7$k['createShaderCondition'] = job_1['createShaderCondition'], y2h8cd['parseXMLFromString'] = job_1['parseXMLFromString'], ed7l$k['_createInputElement'] = j2o8['_createInputElement'], job_1['EnvConfig']['load'] = x0p96r['prototype']['load'], x0p96r['prototype']['load'] = mo_b1['prototype']['load'], job_1['isZiYu'] && boim && wx['onMessage'](function (txufz) {
        txufz['isLoad'] && (bi_pm1['ziyuFileData'][txufz['url']] = txufz['data']);
      });
    }, job_1['onMkdirCallBack'] = function (p_bim1, pm1bi) {
      if (!p_bim1) bi_pm1['filesListObj'] = JSON['parse'](pm1bi['data']);
    }, job_1['pixelRatio'] = function () {
      if (!job_1['EnvConfig']['pixelRatioInt']) try {
        var r90mp = wx['getSystemInfoSync']();return job_1['EnvConfig']['pixelRatioInt'] = r90mp['pixelRatio'], r90mp = r90mp, r90mp['pixelRatio'];
      } catch (_mb1) {}return job_1['EnvConfig']['pixelRatioInt'];
    }, job_1['createElement'] = function (h28d) {
      if (h28d == 'canvas') {
        var bipm19;return job_1['idx'] == 0x1 ? job_1['isZiYu'] ? (bipm19 = sharedCanvas, bipm19['style'] = {}) : bipm19 = window['canvas'] : bipm19 = window['wx']['createCanvas'](), job_1['idx']++, bipm19;
      } else {
        if (h28d == 'textarea' || h28d == 'input') return job_1['onCreateInput'](h28d);else {
          if (h28d == 'div') {
            var kdlec7 = job_1['_preCreateElement'](h28d);return kdlec7['contains'] = function (r069) {
              return null;
            }, kdlec7['removeChild'] = function (nsg5vq) {}, kdlec7;
          } else return job_1['_preCreateElement'](h28d);
        }
      }
    }, job_1['onCreateInput'] = function (fwztx) {
      var tuxfzw = job_1['_preCreateElement'](fwztx);return tuxfzw['focus'] = j2o8['wxinputFocus'], tuxfzw['blur'] = j2o8['wxinputblur'], tuxfzw['style'] = {}, tuxfzw['value'] = 0x0, tuxfzw['parentElement'] = {}, tuxfzw['placeholder'] = {}, tuxfzw['type'] = {}, tuxfzw['setColor'] = function (hyj_o2) {}, tuxfzw['setType'] = function (ztr06) {}, tuxfzw['setFontFace'] = function (x6z9r0) {}, tuxfzw['addEventListener'] = function (v4n5q) {}, tuxfzw['contains'] = function (yjch28) {
        return null;
      }, tuxfzw['removeChild'] = function (qas5$) {}, tuxfzw;
    }, job_1['createShaderCondition'] = function (f3tuw) {
      var q$gs = this,
          _2ojy = function () {
        var m09 = f3tuw;return q$gs[f3tuw['replace']('this.', '')];
      };return _2ojy;
    }, job_1['EnvConfig'] = null, job_1['window'] = null, job_1['_preCreateElement'] = null, job_1['_inited'] = ![], job_1['wxRequest'] = null, job_1['systemInfo'] = null, job_1['version'] = '0.0.1', job_1['isZiYu'] = ![], job_1['isPosMsgYu'] = ![], job_1['parseXMLFromString'] = function (y_2joh) {
      var b0pm9, ngsq5v;y_2joh = y_2joh['replace'](/>\s+</g, '><');try {
        b0pm9 = new window['Parser']['DOMParser']()['parseFromString'](y_2joh, 'text/xml');
      } catch (dl7ek$) {
        throw '需要引入xml解析库文件';
      }return b0pm9;
    }, job_1['idx'] = 0x1, job_1;
  }(),
      qagn5s = function () {
    function e7$() {}held8(e7$, 'laya.wx.mini.MiniImage');var t6uzx = e7$['prototype'];return t6uzx['_loadImage'] = function (wutxf) {
      var y_jh2o = this,
          $a7kg = ![];wutxf['indexOf']('layaNativeDir/') == -0x1 && ($a7kg = !![], wutxf = o_hjy['formatURL'](wutxf));if (!bi_pm1['getFileInfo'](wutxf)) {
        if (wutxf['indexOf']('http://') != -0x1 || wutxf['indexOf']('https://') != -0x1) bi_pm1['downImg'](wutxf, new a$gq(e7$, e7$['onDownImgCallBack'], [wutxf, y_jh2o]), wutxf);else e7$['onCreateImage'](wutxf, y_jh2o, !![]);
      } else e7$['onCreateImage'](wutxf, y_jh2o, !$a7kg);
    }, e7$['onDownImgCallBack'] = function (lhed8c, chj8, sk$a5) {
      if (!sk$a5) e7$['onCreateImage'](lhed8c, chj8);else chj8['onError'](null);
    }, e7$['onCreateImage'] = function (wz6xt, l$, yj12o_) {
      yj12o_ === void 0x0 && (yj12o_ = ![]);var _j21;if (!yj12o_) {
        var jb2o1 = bi_pm1['getFileInfo'](wz6xt),
            jh2yc8 = jb2o1['md5'];_j21 = bi_pm1['getFileNativePath'](jh2yc8);
      } else _j21 = wz6xt;if (l$['imgCache'] == null) l$['imgCache'] = {};var agl7k$;function la$kg() {
        agl7k$['onload'] = null, agl7k$['onerror'] = null, delete l$['imgCache'][wz6xt];
      };var l7dk$ = function () {
        la$kg(), l$['onLoaded'](agl7k$);
      },
          txzfw = function () {
        la$kg(), l$['event']('error', 'Load image failed');
      };l$['_type'] == 'nativeimage' ? (agl7k$ = new _21['window']['Image'](), agl7k$['crossOrigin'] = '', agl7k$['onload'] = l7dk$, agl7k$['onerror'] = txzfw, agl7k$['src'] = _j21, l$['imgCache'][wz6xt] = agl7k$) : new ke$l['create'](_j21, { 'onload': l7dk$, 'onerror': txzfw, 'onCreate': function (ob1m_) {
          agl7k$ = ob1m_, l$['imgCache'][wz6xt] = ob1m_;
        } });
    }, e7$;
  }(),
      j2o8 = function () {
    function ngsaq() {}return held8(ngsaq, 'laya.wx.mini.MiniInput'), ngsaq['_createInputElement'] = function () {
      ed7l$k['_initInput'](ed7l$k['area'] = _21['createElement']('textarea')), ed7l$k['_initInput'](ed7l$k['input'] = _21['createElement']('input')), ed7l$k['inputContainer'] = _21['createElement']('div'), ed7l$k['inputContainer']['style']['position'] = 'absolute', ed7l$k['inputContainer']['style']['zIndex'] = 0x186a0, _21['container']['appendChild'](ed7l$k['inputContainer']), ed7l$k['inputContainer']['setPos'] = function (oy2hj8, hecdl8) {
        ed7l$k['inputContainer']['style']['left'] = oy2hj8 + 'px', ed7l$k['inputContainer']['style']['top'] = hecdl8 + 'px';
      }, k7g$5a['stage']['on']('resize', null, ngsaq['_onStageResize']), wx['onWindowResize'] && wx['onWindowResize'](function (l8ehdc) {
        window['dispatchEvent'] && window['dispatchEvent']('resize');
      }), yc28dh['_soundClass'] = wtf3zu, yc28dh['_musicClass'] = wtf3zu, window['_videoClass'] = b_21o;
    }, ngsaq['_onStageResize'] = function () {
      var qs45v = k7g$5a['stage']['_canvasTransform']['identity']();qs45v['scale'](_21['width'] / y8chde['canvas']['width'] / ae7$k['getPixelRatio'](), _21['height'] / y8chde['canvas']['height'] / ae7$k['getPixelRatio']());
    }, ngsaq['wxinputFocus'] = function (i9pm1) {
      var pbmi90 = ed7l$k['inputElement']['target'];if (pbmi90 && !pbmi90['editable']) return;saqng5['window']['wx']['offKeyboardConfirm'](), saqng5['window']['wx']['offKeyboardInput'](), saqng5['window']['wx']['showKeyboard']({ 'defaultValue': pbmi90['text'], 'maxLength': pbmi90['maxChars'], 'multiple': pbmi90['multiline'], 'confirmHold': !![], 'confirmType': 'done', 'success': function (_bo2j1) {}, 'fail': function (o_i) {} }), saqng5['window']['wx']['onKeyboardConfirm'](function ($5gks) {
        var zxuw6 = $5gks ? $5gks['value'] : '';pbmi90['text'] = zxuw6, pbmi90['event']('input'), laya['wx']['mini']['MiniInput']['inputEnter']();
      }), saqng5['window']['wx']['onKeyboardInput'](function (l7agk$) {
        var twz6x = l7agk$ ? l7agk$['value'] : '';if (!pbmi90['multiline']) {
          if (twz6x['indexOf']('\x0a') != -0x1) {
            laya['wx']['mini']['MiniInput']['inputEnter']();return;
          }
        }pbmi90['text'] = twz6x, pbmi90['event']('input');
      });
    }, ngsaq['inputEnter'] = function () {
      ed7l$k['inputElement']['target']['focus'] = ![];
    }, ngsaq['wxinputblur'] = function () {
      ngsaq['hideKeyboard']();
    }, ngsaq['hideKeyboard'] = function () {
      saqng5['window']['wx']['offKeyboardConfirm'](), saqng5['window']['wx']['offKeyboardInput'](), saqng5['window']['wx']['hideKeyboard']({ 'success': function (de8l7) {
          console['log']('隐藏键盘');
        }, 'fail': function (mb19) {
          console['log']('隐藏键盘出错:' + (mb19 ? mb19['errMsg'] : ''));
        } });
    }, ngsaq;
  }(),
      mo_b1 = function () {
    function xtzrw6() {}held8(xtzrw6, 'laya.wx.mini.MiniLoader');var jh82yo = xtzrw6['prototype'];return jh82yo['load'] = function ($k7ag5, a7ekl$, im_1bo, imb_1p, fuz3tw) {
      im_1bo === void 0x0 && (im_1bo = !![]), fuz3tw === void 0x0 && (fuz3tw = ![]);var s5gq$ = this;s5gq$['_url'] = $k7ag5;if ($k7ag5['indexOf']('data:image') === 0x0) s5gq$['_type'] = a7ekl$ = 'image';else s5gq$['_type'] = a7ekl$ || (a7ekl$ = s5gq$['getTypeFromUrl']($k7ag5));s5gq$['_cache'] = im_1bo, s5gq$['_data'] = null;var bmi90 = 'ascii';if ($k7ag5['indexOf']('.fnt') != -0x1) bmi90 = 'utf8';else a7ekl$ == 'arraybuffer' && (bmi90 = '');;var bp90im = y2h8cd['getFileExtension']($k7ag5);if (xtzrw6['_fileTypeArr']['indexOf'](bp90im) != -0x1) saqng5['EnvConfig']['load']['call'](this, $k7ag5, a7ekl$, im_1bo, imb_1p, fuz3tw);else {
        if (!bi_pm1['getFileInfo']($k7ag5)) {
          if ($k7ag5['indexOf']('layaNativeDir/') != -0x1) {
            if (saqng5['isZiYu']) {
              var lka$ = bi_pm1['ziyuFileData'][$k7ag5];s5gq$['onLoaded'](lka$);return;
            } else {
              cosnole['log']('read read'), bi_pm1['read']($k7ag5, bmi90, new a$gq(xtzrw6, xtzrw6['onReadNativeCallBack'], [bmi90, $k7ag5, a7ekl$, im_1bo, imb_1p, fuz3tw, s5gq$]));return;
            }
          }if (o_hjy['rootPath'] == '') var echd8y = $k7ag5;else echd8y = $k7ag5['split'](o_hjy['rootPath'])[0x0];$k7ag5['indexOf']('http://') != -0x1 || $k7ag5['indexOf']('https://') != -0x1 ? saqng5['EnvConfig']['load']['call'](s5gq$, $k7ag5, a7ekl$, im_1bo, imb_1p, fuz3tw) : bi_pm1['readFile'](echd8y, bmi90, new a$gq(xtzrw6, xtzrw6['onReadNativeCallBack'], [bmi90, $k7ag5, a7ekl$, im_1bo, imb_1p, fuz3tw, s5gq$]), $k7ag5);
        } else saqng5['EnvConfig']['load']['call'](this, $k7ag5, a7ekl$, im_1bo, imb_1p, fuz3tw);
      }
    }, jh82yo['resMgrLoad'] = function (ke7la, x9z06r, sak$5, q$asg5, _1ibpm, _1objm, a$5ksg) {
      sak$5 === void 0x0 && (sak$5 = 0x0), q$asg5 === void 0x0 && (q$asg5 = ![]), _1ibpm === void 0x0 && (_1ibpm = ![]), _1objm === void 0x0 && (_1objm = 0x0), a$5ksg === void 0x0 && (a$5ksg = 0x3), ke7la['indexOf']('mpack') != -0x1 && console['log']('=============resMgrLoad url:', ke7la), saqng5['EnvConfig']['resMgrLoad'](ke7la, (clk, yjo82, d87elc) => {
        xtzrw6['prototype']['resMgrLoadCallBack'](clk, yjo82, d87elc, x9z06r);
      }, sak$5, q$asg5, _1ibpm, _1objm, a$5ksg);
    }, jh82yo['resMgrLoadCallBack'] = function (alke$, u6zw, a$7gkl, _b1mo) {
      console['log']('buff:::', alke$, a$7gkl, bi_pm1['fileNativeDir'] + '///' + bi_pm1['fileListName']), _b1mo(alke$, u6zw, a$7gkl);
    }, jh82yo['clearRes'] = function (b2o_1j, z96) {
      z96 === void 0x0 && (z96 = ![]);var echd = this;echd['clearRes'](b2o_1j, z96);var ycdh2 = bi_pm1['getFileInfo'](b2o_1j);if (ycdh2 && (b2o_1j['indexOf']('http://') != -0x1 || b2o_1j['indexOf']('https://') != -0x1)) {
        var yhcd8 = ycdh2['md5'],
            yh2d8c = bi_pm1['getFileNativePath'](yhcd8);bi_pm1['remove'](yh2d8c);
      }
    }, xtzrw6['onReadNativeCallBack'] = function (u3wzf, xz69r0, ld8c, tufw3z, t3fw, g$s5, i9rm, o8y2hj, joh2) {
      tufw3z === void 0x0 && (tufw3z = !![]), g$s5 === void 0x0 && (g$s5 = ![]), o8y2hj === void 0x0 && (o8y2hj = 0x0);if (!o8y2hj) {
        var zt6xrw;if (ld8c == 'json' || ld8c == 'atlas') zt6xrw = saqng5['getJson'](joh2['data']);else ld8c == 'xml' ? zt6xrw = y2h8cd['parseXMLFromString'](joh2['data']) : zt6xrw = joh2['data'];i9rm['onLoaded'](zt6xrw), !saqng5['isZiYu'] && saqng5['isPosMsgYu'] && ld8c != 'arraybuffer' && wx['postMessage']({ 'url': xz69r0, 'data': zt6xrw, 'isLoad': !![] });
      } else o8y2hj == 0x1 && saqng5['EnvConfig']['load']['call'](i9rm, xz69r0, ld8c, tufw3z, t3fw, g$s5);
    }, ohj8y(xtzrw6, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['png', 'jpg', 'bmp', 'jpeg', 'gif'];
    }]), xtzrw6;
  }(),
      bi_pm1 = function (jo1b2_) {
    function im1o_() {
      im1o_['__super']['call'](this);;
    }return held8(im1o_, 'laya.wx.mini.MiniFileMgr', jo1b2_), im1o_['isLoadFile'] = function (x6tuwz) {
      return im1o_['_fileTypeArr']['indexOf'](x6tuwz) != -0x1 ? !![] : ![];
    }, im1o_['getFileInfo'] = function (bm1p_i) {
      var u3tzfw = bm1p_i['split']('?')[0x0],
          m_1ojb = im1o_['filesListObj'][u3tzfw];if (m_1ojb == null) return null;else return m_1ojb;return null;
    }, im1o_['onFileUpdate'] = function (wzr6tx, ek$al) {
      var fwtuxz = wzr6tx['split']('/'),
          y82jo = fwtuxz[fwtuxz['length'] - 0x1],
          cy2h8d = im1o_['getFileInfo'](ek$al);if (cy2h8d == null) im1o_['onSaveFile'](ek$al, y82jo);else {
        if (cy2h8d['readyUrl'] != ek$al) im1o_['remove'](y82jo, ek$al);
      }
    }, im1o_['exits'] = function (delck7, ga$) {
      var _21joy = im1o_['getFileNativePath'](delck7);im1o_['fs']['getFileInfo']({ 'filePath': _21joy, 'success': function (nsq5a) {
          ga$ != null && ga$['runWith']([0x0, nsq5a]);
        }, 'fail': function (rt06zx) {
          ga$ != null && ga$['runWith']([0x1, rt06zx]);
        } });
    }, im1o_['read'] = function (rm0p9, cy8hj, g57ak$, y2_j) {
      cy8hj === void 0x0 && (cy8hj = 'ascill'), y2_j === void 0x0 && (y2_j = '');var _oyh;y2_j != '' ? _oyh = im1o_['getFileNativePath'](rm0p9) : _oyh = rm0p9, im1o_['fs']['readFile']({ 'filePath': _oyh, 'encoding': cy8hj, 'success': function (o1jy) {
          g57ak$ != null && g57ak$['runWith']([0x0, o1jy]);
        }, 'fail': function (c8eyhd) {
          if (c8eyhd && y2_j != '') im1o_['down'](y2_j, cy8hj, g57ak$, y2_j);else g57ak$ != null && g57ak$['runWith']([0x1]);
        } });
    }, im1o_['readNativeFile'] = function ($g5qsa, $gas5q) {
      im1o_['fs']['readFile']({ 'filePath': $g5qsa, 'encoding': '', 'success': function (hjo_) {
          $gas5q != null && $gas5q['runWith']([0x0]);
        }, 'fail': function (bmi9p1) {
          $gas5q != null && $gas5q['runWith']([0x1]);
        } });
    }, im1o_['down'] = function (tw3f, ft3zu, gsnq, kags) {
      ft3zu === void 0x0 && (ft3zu = 'ascill'), kags === void 0x0 && (kags = '');var j82oyh = im1o_['getFileNativePath'](kags),
          m1o = im1o_['wxdown']({ 'url': tw3f, 'filePath': j82oyh, 'success': function (cd8elh) {
          if (cd8elh['statusCode'] === 0xc8) im1o_['readFile'](cd8elh['filePath'], ft3zu, gsnq, kags);
        }, 'fail': function ($aqg5) {
          gsnq != null && gsnq['runWith']([0x1, $aqg5]);
        } });m1o['onProgressUpdate'](function (ho2y_) {
        gsnq != null && gsnq['runWith']([0x2, ho2y_['progress']]);
      });
    }, im1o_['readFile'] = function (ho2_, lg$7, pm_b, twfxuz) {
      lg$7 === void 0x0 && (lg$7 = 'ascill'), twfxuz === void 0x0 && (twfxuz = ''), im1o_['fs']['readFile']({ 'filePath': ho2_, 'encoding': lg$7, 'success': function (tw3) {
          if (ho2_['indexOf']('http://') != -0x1 || ho2_['indexOf']('https://') != -0x1) im1o_['onFileUpdate'](ho2_, twfxuz);pm_b != null && pm_b['runWith']([0x0, tw3]);
        }, 'fail': function (rtz06) {
          if (rtz06) pm_b != null && pm_b['runWith']([0x1, rtz06]);
        } });
    }, im1o_['downImg'] = function (tx6zw, lkec7d, lg7ak) {
      lg7ak === void 0x0 && (lg7ak = '');var k7ag$ = im1o_['wxdown']({ 'url': tx6zw, 'success': function (gv5nqs) {
          gv5nqs['statusCode'] === 0xc8 && im1o_['copyFile'](gv5nqs['tempFilePath'], lg7ak, lkec7d);
        }, 'fail': function (j8hcy) {
          lkec7d != null && lkec7d['runWith']([0x1, j8hcy]);
        } });
    }, im1o_['copyFile'] = function (a75$g, qgvns5, bim_1o) {
      var kcd7l = a75$g['split']('/'),
          gk$57a = kcd7l[kcd7l['length'] - 0x1],
          ipbm19 = qgvns5['split']('?')[0x0],
          x9rp60 = im1o_['getFileInfo'](qgvns5),
          dl7ec8 = im1o_['getFileNativePath'](gk$57a);im1o_['fs']['copyFile']({ 'srcPath': a75$g, 'destPath': dl7ec8, 'success': function (k7ce) {
          if (!x9rp60) im1o_['onSaveFile'](qgvns5, gk$57a), bim_1o != null && bim_1o['runWith']([0x0]);else {
            if (x9rp60['readyUrl'] != qgvns5) im1o_['remove'](gk$57a, qgvns5, bim_1o);
          }
        }, 'fail': function (fwt3uz) {
          bim_1o != null && bim_1o['runWith']([0x1, fwt3uz]);
        } });
    }, im1o_['getFileNativePath'] = function (ip09mr) {
      return laya['wx']['mini']['MiniFileMgr']['fileNativeDir'] + '/' + ip09mr;
    }, im1o_['remove'] = function (oi1b_m, ae$lk7, wtfz3u) {
      ae$lk7 === void 0x0 && (ae$lk7 = '');var wtuz = im1o_['getFileInfo'](ae$lk7),
          sqv4 = im1o_['getFileNativePath'](wtuz['md5']);k7g$5a['loader']['clearRes'](wtuz['readyUrl']), im1o_['fs']['unlink']({ 'filePath': sqv4, 'success': function (o_jh) {
          if (ae$lk7 != '') im1o_['onSaveFile'](ae$lk7, oi1b_m);wtfz3u != null && wtfz3u['runWith']([0x0]);
        }, 'fail': function (l$kd) {} });
    }, im1o_['onSaveFile'] = function (rim9p0, ob_1im) {
      var c2y8hj = rim9p0['split']('?')[0x0];im1o_['filesListObj'][c2y8hj] = { 'md5': ob_1im, 'readyUrl': rim9p0 }, im1o_['fs']['writeFile']({ 'filePath': im1o_['fileNativeDir'] + '/' + im1o_['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](im1o_['filesListObj']), 'success': function (xtzwr6) {
          console['log']('写入测试测试成功：', xtzwr6);
        }, 'fail': function (led$) {
          console['log']('写入测试测试失败：', led$);
        } });
    }, im1o_['existDir'] = function (bo, ri06) {
      im1o_['fs']['mkdir']({ 'dirPath': bo, 'success': function (u6tzxw) {
          ri06 != null && ri06['runWith']([0x0, { 'data': JSON['stringify']({}) }]);
        }, 'fail': function (ibm_o1) {
          if (ibm_o1['errMsg']['indexOf']('file already exists') != -0x1) im1o_['readSync'](im1o_['fileListName'], 'utf8', ri06);else ri06 != null && ri06['runWith']([0x1, ibm_o1]);
        } });
    }, im1o_['readSync'] = function (p_mbi1, ehdcl8, b_pim, a$qgs5) {
      ehdcl8 === void 0x0 && (ehdcl8 = 'ascill'), a$qgs5 === void 0x0 && (a$qgs5 = '');var rwzt6 = im1o_['getFileNativePath'](p_mbi1),
          x0rt;try {
        x0rt = im1o_['fs']['readFileSync'](rwzt6), b_pim != null && b_pim['runWith']([0x0, { 'data': x0rt }]);
      } catch (zut6xw) {
        b_pim != null && b_pim['runWith']([0x1]);
      }
    }, im1o_['readCache'] = function () {}, im1o_['writeCache'] = function (ek$7) {
      var i9pr6 = readyUrl['split']('?')[0x0];im1o_['filesListObj'][i9pr6] = { 'md5': md5Name, 'readyUrl': readyUrl }, im1o_['fs']['writeFile']({ 'filePath': im1o_['fileNativeDir'] + '/' + im1o_['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](im1o_['filesListObj']), 'success': function (qvn54s) {}, 'fail': function (qn5sv) {} });
    }, im1o_['setNativeFileDir'] = function (hdc8l) {
      im1o_['fileNativeDir'] = wx['env']['USER_DATA_PATH'] + hdc8l;
    }, im1o_['filesListObj'] = {}, im1o_['fileNativeDir'] = null, im1o_['fileListName'] = 'layaairfiles.txt', im1o_['ziyuFileData'] = {}, ohj8y(im1o_, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['json', 'ani', 'xml', 'sk', 'txt', 'atlas', 'swf', 'part', 'fnt', 'proto', 'lh', 'lav', 'lani', 'lmat', 'lm', 'ltc'];
    }, 'fs', function () {
      return this['fs'] = wx['getFileSystemManager']();
    }, 'wxdown', function () {
      return this['wxdown'] = wx['downloadFile'];
    }]), im1o_;
  }(qs$5a),
      wtf3zu = function (imob_1) {
    function p1bm_i() {
      this['_sound'] = null, this['_chanell'] = null, this['url'] = null, this['loaded'] = ![], p1bm_i['__super']['call'](this), this['_sound'] = p1bm_i['_createSound'](), this['_chanell'] = new futzxw(this['_sound']);
    }held8(p1bm_i, 'laya.wx.mini.MiniSound', imob_1);var _omi = p1bm_i['prototype'];return _omi['load'] = function (mbi1o) {
      var rz6x0 = this;mbi1o = o_hjy['formatURL'](mbi1o), this['url'] = mbi1o;if (p1bm_i['_audioCache'][mbi1o]) {
        this['event']('complete');return;
      }function o1_jb() {
        if (p1bm_i['_null'] != undefined) rz6x0['_sound']['onCanplay'](p1bm_i['_null']), rz6x0['_sound']['onError'](p1bm_i['_null']);else try {
          rz6x0['_sound']['onCanplay'](null), rz6x0['_sound']['onError'](null), p1bm_i['_null'] = null;
        } catch (hoyj8) {
          console['warn']('[wxmini] _clearSound:' + hoyj8), rz6x0['_sound']['onCanplay'](yjc8h2), rz6x0['_sound']['onError'](yjc8h2), p1bm_i['_null'] = yjc8h2;
        }
      }function i9pm0b() {
        $5skg['loaded'] = !![], $5skg['event']('complete'), p1bm_i['_audioCache'][$5skg['url']] = $5skg;
      }function wuz6t(mi_p1) {
        console['error']('errCode=' + mi_p1['errCode'] + '  errMsg=' + mi_p1['errMsg']), $5skg['event']('error');
      }function yjc8h2() {}this['_sound']['onCanplay'](i9pm0b), this['_sound']['onError'](wuz6t), this['_sound']['src'] = mbi1o;var $5skg = this;
    }, _omi['play'] = function (xzr6t0, as5gnq) {
      xzr6t0 === void 0x0 && (xzr6t0 = 0x0), as5gnq === void 0x0 && (as5gnq = 0x0);var gasn, wtx6zr;if (this['url'] == yc28dh['_tMusic']) {
        if (!p1bm_i['_musicAudio']) p1bm_i['_musicAudio'] = this['_sound'];gasn = p1bm_i['_musicAudio'], wtx6zr = this['_chanell'];
      } else gasn = this['_sound'], wtx6zr = this['_chanell'];return gasn['src'] = this['url'], gasn['startTime'] = 0x0, wtx6zr['isStopped'] && (wtx6zr['url'] = this['url'], wtx6zr['loops'] = as5gnq, wtx6zr['startTime'] = xzr6t0, wtx6zr['play'](), yc28dh['addChannel'](wtx6zr)), wtx6zr;
    }, _omi['dispose'] = function () {
      var l7c8de = p1bm_i['_audioCache'][this['url']];l7c8de && (l7c8de['src'] = '', delete p1bm_i['_audioCache'][this['url']]);
    }, y2_jh(0x0, _omi, 'duration', function () {
      return this['_sound']['duration'];
    }), p1bm_i['_createSound'] = function () {
      p1bm_i['_id']++;var bm09p = saqng5['window']['wx']['createInnerAudioContext']({ 'useWebAudioImplement': ![] });return bm09p;
    }, p1bm_i['_musicAudio'] = null, p1bm_i['_id'] = 0x0, p1bm_i['_audioCache'] = {}, p1bm_i['_null'] = undefined, p1bm_i;
  }(qs$5a),
      futzxw = function (dcy8he) {
    function ut6x(jbmo_1) {
      this['_audio'] = null, this['_onEnd'] = null, ut6x['__super']['call'](this), this['isStopped'] = !![], this['_audio'] = jbmo_1, this['_onEnd'] = y2h8cd['bind'](this['__onEnd'], this), jbmo_1['onEnded'](this['_onEnd']);
    }held8(ut6x, 'laya.wx.mini.MiniSoundChannel', dcy8he);var gsa5$ = ut6x['prototype'];return gsa5$['__onEnd'] = function () {
      if (this['loops'] == 0x1) {
        this['completeHandler'] && (k7g$5a['timer']['once'](0xa, this, this['__runComplete'], [this['completeHandler']], ![]), this['completeHandler'] = null);this['stop'](), this['event']('complete');return;
      }this['loops'] > 0x0 && this['loops']--, this['startTime'] = 0x0, this['play']();
    }, gsa5$['__onNull'] = function () {}, gsa5$['play'] = function () {
      this['isStopped'] = ![], yc28dh['addChannel'](this);if (this['_audio']) this['_audio']['play']();
    }, gsa5$['stop'] = function () {
      this['isStopped'] = !![], yc28dh['removeChannel'](this), this['completeHandler'] = null;if (!this['_audio']) return;this['_audio']['stop']();
    }, gsa5$['pause'] = function () {
      this['isStopped'] = !![], this['_audio']['pause']();
    }, gsa5$['resume'] = function () {
      if (!this['_audio']) return;this['isStopped'] = ![], yc28dh['addChannel'](this), this['_audio']['play']();
    }, y2_jh(0x0, gsa5$, 'position', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['currentTime'];
    }), y2_jh(0x0, gsa5$, 'duration', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['duration'];
    }), y2_jh(0x0, gsa5$, 'volume', function () {
      return 0x1;
    }, function (xutfzw) {}), ut6x['_null'] = undefined, ut6x;
  }(sq5gvn),
      b_21o = function () {
    function e78cld() {
      this['videoend'] = ![], this['videourl'] = '', this['videoElement'] = saqng5['window']['wx']['createVideo']({ 'showCenterPlayBtn': ![], 'showProgressInControlMode': ![], 'objectFit': 'fill' });
    }held8(e78cld, 'laya.wx.mini.MiniVideo');var $7kdle = e78cld['prototype'];return $7kdle['on'] = function (pbi90, dhy8e, p6i0) {
      if (pbi90 == 'loadedmetadata') this['onPlayFunc'] = p6i0['bind'](dhy8e), this['videoElement']['onPlay'] = this['onPlayFunction']['bind'](this);else pbi90 == 'ended' && (this['onEndedFunC'] = p6i0['bind'](dhy8e), this['videoElement']['onEnded'] = this['onEndedFunction']['bind'](this));this['videoElement']['onTimeUpdate'] = this['onTimeUpdateFunc']['bind'](this);
    }, $7kdle['onTimeUpdateFunc'] = function (ojmb_) {
      this['position'] = ojmb_['position'], this['_duration'] = ojmb_['duration'];
    }, $7kdle['onPlayFunction'] = function () {
      if (this['videoElement']) this['videoElement']['readyState'] = 0xc8;console['log']('=====视频加载完成========'), this['onPlayFunc'] != null && this['onPlayFunc']();
    }, $7kdle['onended'] = function (bipm90, dehyc) {
      this['onEndedFunC'] = dehyc['bind'](bipm90), this['videoElement']['onended'] = this['onEndedFunction']['bind'](this);
    }, $7kdle['onEndedFunction'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], console['log']('=====视频播放完毕========'), this['onEndedFunC'] != null && this['onEndedFunC']();
    }, $7kdle['off'] = function (r0xz96, j2h8, c8dy2) {
      if (r0xz96 == 'loadedmetadata') this['onPlayFunc'] = c8dy2['bind'](j2h8), this['videoElement']['offPlay'] = this['onPlayFunction']['bind'](this);else r0xz96 == 'ended' && (this['onEndedFunC'] = c8dy2['bind'](j2h8), this['videoElement']['offEnded'] = this['onEndedFunction']['bind'](this));
    }, $7kdle['load'] = function (y2o_jh) {
      if (!this['videoElement']) return;this['videoElement']['src'] = y2o_jh;
    }, $7kdle['play'] = function () {
      if (!this['videoElement']) return;this['videoend'] = ![], this['videoElement']['play']();
    }, $7kdle['pause'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], this['videoElement']['pause']();
    }, $7kdle['size'] = function (b0pmi9, hc82j) {
      if (!this['videoElement']) return;this['videoElement']['width'] = b0pmi9, this['videoElement']['height'] = hc82j;
    }, $7kdle['destroy'] = function () {
      if (this['videoElement']) this['videoElement']['destroy']();this['videoElement'] = null, this['onEndedFunC'] = null, this['onPlayFunc'] = null, this['videoend'] = ![], this['videourl'] = null;
    }, $7kdle['reload'] = function () {
      if (!this['videoElement']) return;this['videoElement']['src'] = this['videourl'];
    }, y2_jh(0x0, $7kdle, 'duration', function () {
      return this['_duration'];
    }), y2_jh(0x0, $7kdle, 'currentTime', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['initialTime'];
    }, function (yedc8) {
      if (!this['videoElement']) return;this['videoElement']['initialTime'] = yedc8;
    }), y2_jh(0x0, $7kdle, 'videoWidth', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['width'];
    }), y2_jh(0x0, $7kdle, 'videoHeight', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['height'];
    }), y2_jh(0x0, $7kdle, 'ended', function () {
      return this['videoend'];
    }), y2_jh(0x0, $7kdle, 'loop', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['loop'];
    }, function (c8le7) {
      if (!this['videoElement']) return;this['videoElement']['loop'] = c8le7;
    }), y2_jh(0x0, $7kdle, 'playbackRate', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['playbackRate'];
    }, function (de$l) {
      if (!this['videoElement']) return;this['videoElement']['playbackRate'] = de$l;
    }), y2_jh(0x0, $7kdle, 'muted', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['muted'];
    }, function (qa5g) {
      if (!this['videoElement']) return;this['videoElement']['muted'] = qa5g;
    }), y2_jh(0x0, $7kdle, 'paused', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['paused'];
    }), y2_jh(0x0, $7kdle, 'x', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['x'];
    }, function (_y1) {
      if (!this['videoElement']) return;this['videoElement']['x'] = _y1;
    }), y2_jh(0x0, $7kdle, 'y', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['y'];
    }, function (mip_b) {
      if (!this['videoElement']) return;this['videoElement']['y'] = mip_b;
    }), y2_jh(0x0, $7kdle, 'currentSrc', function () {
      return this['videoElement']['src'];
    }), y2_jh(0x0, $7kdle, 'src', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['src'];
    }, function (t6xwu) {
      if (!this['videoElement']) return;this['videoElement']['src'] = t6xwu;
    }), y2_jh(0x0, $7kdle, 'controls', function () {
      if (!this['videoElement']) return;return this['videoElement']['controls'];
    }, function (lcedh8) {
      if (!this['videoElement']) return;this['videoElement']['controls'] = lcedh8;
    }), y2_jh(0x0, $7kdle, 'autoplay', function () {
      if (!this['videoElement']) return;return this['videoElement']['autoplay'];
    }, function (twuzf3) {
      if (!this['videoElement']) return;this['videoElement']['autoplay'] = twuzf3;
    }), e78cld;
  }();
})(window, document, Laya);typeof define === 'function' && define['amd'] && define('laya.core', ['require', 'exports'], function (require, exports) {
  'use strict';
  Object['defineProperty'](exports, '__esModule', { 'value': !![] });for (var zrtx06 in Laya) {
    var ib0pm = Laya[zrtx06];ib0pm && ib0pm['__isclass'] && (exports[zrtx06] = ib0pm);
  }
});