var Z = wx.$L;
import 'LLLMAIN.js';