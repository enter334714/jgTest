var Z = wx.$L;
function l1j2o_y() {}function l1b_2j(j2o8hy, s5nqag, w3u, rz6wt, x6z0t) {
  function jh8y2o(lhde8) {
    if (lhde8 > 0xffff) {
      lhde8 -= 0x10000;var kas = 0xd800 + (lhde8 >> 0xa),
          de8lhc = 0xdc00 + (0x3ff & lhde8);return String['fromCharCode'](kas, de8lhc);
    }return String['fromCharCode'](lhde8);
  }function $g7l($lke) {
    var wztfux = $lke['slice'](0x1, -0x1);return wztfux in w3u ? w3u[wztfux] : '#' === wztfux['charAt'](0x0) ? jh8y2o(parseInt(wztfux['substr'](0x1)['replace']('x', '0x'))) : (x6z0t['error']('entity not found:' + $lke), $lke);
  }function _1jb2o(ag7kl$) {
    if (ag7kl$ > cd28h) {
      var qng5sa = j2o8hy['substring'](cd28h, ag7kl$)['replace'](/&#?\w+;/g, $g7l);t3wuz && $ak5gs(cd28h), rz6wt['characters'](qng5sa, 0x0, ag7kl$ - cd28h), cd28h = ag7kl$;
    }
  }function $ak5gs(xr096, bi9) {
    for (; xr096 >= pi0m && (bi9 = q5s4nv['exec'](j2o8hy));) e8dy = bi9['index'], pi0m = e8dy + bi9[0x0]['length'], t3wuz['lineNumber']++;t3wuz['columnNumber'] = xr096 - e8dy + 0x1;
  }for (var e8dy = 0x0, pi0m = 0x0, q5s4nv = /.*(?:\r\n?|\n)|.*$/g, t3wuz = rz6wt['locator'], wzxrt = [{ 'currentNSMap': s5nqag }], j2_o1y = {}, cd28h = 0x0;;) {
    try {
      var ztxuf = j2o8hy['indexOf']('<', cd28h);if (0x0 > ztxuf) {
        if (!j2o8hy['substr'](cd28h)['match'](/^\s*$/)) {
          var kl$ag = rz6wt['doc'],
              b90mi = kl$ag['createTextNode'](j2o8hy['substr'](cd28h));kl$ag['appendChild'](b90mi), rz6wt['currentElement'] = b90mi;
        }return;
      }switch (ztxuf > cd28h && _1jb2o(ztxuf), j2o8hy['charAt'](ztxuf + 0x1)) {case '/':
          var cydh8 = j2o8hy['indexOf']('>', ztxuf + 0x3),
              chy2j = j2o8hy['substring'](ztxuf + 0x2, cydh8),
              hyo_ = wzxrt['pop']();0x0 > cydh8 ? (chy2j = j2o8hy['substring'](ztxuf + 0x2)['replace'](/[\s<].*/, ''), x6z0t['error']('end tag name: ' + chy2j + ' is not complete:' + hyo_['tagName']), cydh8 = ztxuf + 0x1 + chy2j['length']) : chy2j['match'](/\s</) && (chy2j = chy2j['replace'](/[\s<].*/, ''), x6z0t['error']('end tag name: ' + chy2j + ' maybe not complete'), cydh8 = ztxuf + 0x1 + chy2j['length']);var nvgqs = hyo_['localNSMap'],
              qa$5g = hyo_['tagName'] == chy2j,
              qv5sn4 = qa$5g || hyo_['tagName'] && hyo_['tagName']['toLowerCase']() == chy2j['toLowerCase']();if (qv5sn4) {
            if (rz6wt['endElement'](hyo_['uri'], hyo_['localName'], chy2j), nvgqs) {
              for (var snqg5a in nvgqs) rz6wt['endPrefixMapping'](snqg5a);
            }qa$5g || x6z0t['fatalError']('end tag name: ' + chy2j + ' is not match the current start tagName:' + hyo_['tagName']);
          } else wzxrt['push'](hyo_);cydh8++;break;case '?':
          t3wuz && $ak5gs(ztxuf), cydh8 = l1ael7k(j2o8hy, ztxuf, rz6wt);break;case '!':
          t3wuz && $ak5gs(ztxuf), cydh8 = l1elak7$(j2o8hy, ztxuf, rz6wt, x6z0t);break;default:
          t3wuz && $ak5gs(ztxuf);var chel8 = new l1hec8d(),
              v45nq = wzxrt[wzxrt['length'] - 0x1]['currentNSMap'],
              cydh8 = l1y_h2o(j2o8hy, ztxuf, chel8, v45nq, $g7l, x6z0t),
              q5ansg = chel8['length'];if (!chel8['closed'] && l1f3ztw(j2o8hy, cydh8, chel8['tagName'], j2_o1y) && (chel8['closed'] = !0x0, w3u['nbsp'] || x6z0t['warning']('unclosed xml attribute')), t3wuz && q5ansg) {
            for (var mobi1_ = l1_21bo(t3wuz, {}), x0rt6 = 0x0; q5ansg > x0rt6; x0rt6++) {
              var o_mbi = chel8[x0rt6];$ak5gs(o_mbi['offset']), o_mbi['locator'] = l1_21bo(t3wuz, {});
            }rz6wt['locator'] = mobi1_, l1n5sag(chel8, rz6wt, v45nq) && wzxrt['push'](chel8), rz6wt['locator'] = t3wuz;
          } else l1n5sag(chel8, rz6wt, v45nq) && wzxrt['push'](chel8);'http://www.w3.org/1999/xhtml' !== chel8['uri'] || chel8['closed'] ? cydh8++ : cydh8 = l1$7ag5(j2o8hy, cydh8, chel8['tagName'], $g7l, rz6wt);}
    } catch (sakg5) {
      x6z0t['error']('element parse error: ' + sakg5), cydh8 = -0x1;
    }cydh8 > cd28h ? cd28h = cydh8 : _1jb2o(Math['max'](ztxuf, cd28h) + 0x1);
  }
}function l1_21bo(m_b, p91) {
  return p91['lineNumber'] = m_b['lineNumber'], p91['columnNumber'] = m_b['columnNumber'], p91;
}function l1y_h2o(m1p9bi, l8c7d, imb0p9, vq5nsg, n5q4sv, rx6wtz) {
  for (var n5svgq, _yo2hj, y12o_ = ++l8c7d, $kgl7a = l1c28dhy;;) {
    var le7dk$ = m1p9bi['charAt'](y12o_);switch (le7dk$) {case '=':
        if ($kgl7a === l1pmib_) n5svgq = m1p9bi['slice'](l8c7d, y12o_), $kgl7a = l1jhy28;else {
          if ($kgl7a !== l1kecld7) throw new Error('attribute equal must after attrName');$kgl7a = l1jhy28;
        }break;case '\x27':case '\x22':
        if ($kgl7a === l1jhy28 || $kgl7a === l1pmib_) {
          if ($kgl7a === l1pmib_ && (rx6wtz['warning']('attribute value must after "="'), n5svgq = m1p9bi['slice'](l8c7d, y12o_)), l8c7d = y12o_ + 0x1, y12o_ = m1p9bi['indexOf'](le7dk$, l8c7d), !(y12o_ > 0x0)) throw new Error('attribute value no end \'' + le7dk$ + '\' match');_yo2hj = m1p9bi['slice'](l8c7d, y12o_)['replace'](/&#?\w+;/g, n5q4sv), imb0p9['add'](n5svgq, _yo2hj, l8c7d - 0x1), $kgl7a = l1$gq5;
        } else {
          if ($kgl7a != l1ledc87) throw new Error('attribute value must after "="');_yo2hj = m1p9bi['slice'](l8c7d, y12o_)['replace'](/&#?\w+;/g, n5q4sv), imb0p9['add'](n5svgq, _yo2hj, l8c7d), rx6wtz['warning']('attribute "' + n5svgq + '" missed start quot(' + le7dk$ + ')!!'), l8c7d = y12o_ + 0x1, $kgl7a = l1$gq5;
        }break;case '/':
        switch ($kgl7a) {case l1c28dhy:
            imb0p9['setTagName'](m1p9bi['slice'](l8c7d, y12o_));case l1$gq5:case l1i9pr60:case l1t3zf:
            $kgl7a = l1t3zf, imb0p9['closed'] = !0x0;case l1ledc87:case l1pmib_:case l1kecld7:
            break;default:
            throw new Error('attribute invalid close char(\'/\')');}break;case '':
        return rx6wtz['error']('unexpected end of input'), $kgl7a == l1c28dhy && imb0p9['setTagName'](m1p9bi['slice'](l8c7d, y12o_)), y12o_;case '>':
        switch ($kgl7a) {case l1c28dhy:
            imb0p9['setTagName'](m1p9bi['slice'](l8c7d, y12o_));case l1$gq5:case l1i9pr60:case l1t3zf:
            break;case l1ledc87:case l1pmib_:
            _yo2hj = m1p9bi['slice'](l8c7d, y12o_), '/' === _yo2hj['slice'](-0x1) && (imb0p9['closed'] = !0x0, _yo2hj = _yo2hj['slice'](0x0, -0x1));case l1kecld7:
            $kgl7a === l1kecld7 && (_yo2hj = n5svgq), $kgl7a == l1ledc87 ? (rx6wtz['warning']('attribute "' + _yo2hj + '" missed quot(")!!'), imb0p9['add'](n5svgq, _yo2hj['replace'](/&#?\w+;/g, n5q4sv), l8c7d)) : ('http://www.w3.org/1999/xhtml' === vq5nsg[''] && _yo2hj['match'](/^(?:disabled|checked|selected)$/i) || rx6wtz['warning']('attribute "' + _yo2hj + '" missed value!! "' + _yo2hj + '" instead!!'), imb0p9['add'](_yo2hj, _yo2hj, l8c7d));break;case l1jhy28:
            throw new Error('attribute value missed!!');}return y12o_;case '\u0080':
        le7dk$ = '\x20';default:
        if ('\x20' >= le7dk$) switch ($kgl7a) {case l1c28dhy:
            imb0p9['setTagName'](m1p9bi['slice'](l8c7d, y12o_)), $kgl7a = l1i9pr60;break;case l1pmib_:
            n5svgq = m1p9bi['slice'](l8c7d, y12o_), $kgl7a = l1kecld7;break;case l1ledc87:
            var _yo2hj = m1p9bi['slice'](l8c7d, y12o_)['replace'](/&#?\w+;/g, n5q4sv);rx6wtz['warning']('attribute "' + _yo2hj + '" missed quot(")!!'), imb0p9['add'](n5svgq, _yo2hj, l8c7d);case l1$gq5:
            $kgl7a = l1i9pr60;} else switch ($kgl7a) {case l1kecld7:
            {
              imb0p9['tagName'];
            }'http://www.w3.org/1999/xhtml' === vq5nsg[''] && n5svgq['match'](/^(?:disabled|checked|selected)$/i) || rx6wtz['warning']('attribute "' + n5svgq + '" missed value!! "' + n5svgq + '" instead2!!'), imb0p9['add'](n5svgq, n5svgq, l8c7d), l8c7d = y12o_, $kgl7a = l1pmib_;break;case l1$gq5:
            rx6wtz['warning']('attribute space is required"' + n5svgq + '\x22!!');case l1i9pr60:
            $kgl7a = l1pmib_, l8c7d = y12o_;break;case l1jhy28:
            $kgl7a = l1ledc87, l8c7d = y12o_;break;case l1t3zf:
            throw new Error('elements closed character \'/\' and \'>\' must be connected to');}}y12o_++;
  }
}function l1n5sag(k7$dl, eakl$, ng5vq) {
  for (var _1y2 = k7$dl['tagName'], ld8e = null, x0rp9 = k7$dl['length']; x0rp9--;) {
    var gk57$ = k7$dl[x0rp9],
        rz9 = gk57$['qName'],
        ecd8 = gk57$['value'],
        r906z = rz9['indexOf'](':');if (r906z > 0x0) var deyc = gk57$['prefix'] = rz9['slice'](0x0, r906z),
        lc87d = rz9['slice'](r906z + 0x1),
        rpx609 = 'xmlns' === deyc && lc87d;else lc87d = rz9, deyc = null, rpx609 = 'xmlns' === rz9 && '';gk57$['localName'] = lc87d, rpx609 !== !0x1 && (null == ld8e && (ld8e = {}, l1y8h2(ng5vq, ng5vq = {})), ng5vq[rpx609] = ld8e[rpx609] = ecd8, gk57$['uri'] = 'http://www.w3.org/2000/xmlns/', eakl$['startPrefixMapping'](rpx609, ecd8));
  }for (var x0rp9 = k7$dl['length']; x0rp9--;) {
    gk57$ = k7$dl[x0rp9];var deyc = gk57$['prefix'];deyc && ('xml' === deyc && (gk57$['uri'] = 'http://www.w3.org/XML/1998/namespace'), 'xmlns' !== deyc && (gk57$['uri'] = ng5vq[deyc || '']));
  }var r906z = _1y2['indexOf'](':');r906z > 0x0 ? (deyc = k7$dl['prefix'] = _1y2['slice'](0x0, r906z), lc87d = k7$dl['localName'] = _1y2['slice'](r906z + 0x1)) : (deyc = null, lc87d = k7$dl['localName'] = _1y2);var c2hy8d = k7$dl['uri'] = ng5vq[deyc || ''];if (eakl$['startElement'](c2hy8d, lc87d, _1y2, k7$dl), !k7$dl['closed']) return k7$dl['currentNSMap'] = ng5vq, k7$dl['localNSMap'] = ld8e, !0x0;if (eakl$['endElement'](c2hy8d, lc87d, _1y2), ld8e) {
    for (deyc in ld8e) eakl$['endPrefixMapping'](deyc);
  }
}function l1$7ag5(chled8, q5sng, hdlce8, i09pmb, z6rtxw) {
  if (/^(?:script|textarea)$/i['test'](hdlce8)) {
    var o_mb1j = chled8['indexOf']('</' + hdlce8 + '>', q5sng),
        imb1_o = chled8['substring'](q5sng + 0x1, o_mb1j);if (/[&<]/['test'](imb1_o)) return (/^script$/i['test'](hdlce8) ? (z6rtxw['characters'](imb1_o, 0x0, imb1_o['length']), o_mb1j) : (imb1_o = imb1_o['replace'](/&#?\w+;/g, i09pmb), z6rtxw['characters'](imb1_o, 0x0, imb1_o['length']), o_mb1j)
    );
  }return q5sng + 0x1;
}function l1f3ztw(jyo2h, fzxtw, x0tr6, zr096x) {
  var yc28hd = zr096x[x0tr6];return null == yc28hd && (yc28hd = jyo2h['lastIndexOf']('</' + x0tr6 + '>'), fzxtw > yc28hd && (yc28hd = jyo2h['lastIndexOf']('</' + x0tr6)), zr096x[x0tr6] = yc28hd), fzxtw > yc28hd;
}function l1y8h2(h8y2oj, bmoi_1) {
  for (var qv5ns4 in h8y2oj) bmoi_1[qv5ns4] = h8y2oj[qv5ns4];
}function l1elak7$(mb_1pi, _bip, ak$5s, d82hyc) {
  var _2jbo = mb_1pi['charAt'](_bip + 0x2);switch (_2jbo) {case '-':
      if ('-' === mb_1pi['charAt'](_bip + 0x3)) {
        var e$kdl7 = mb_1pi['indexOf']('-->', _bip + 0x4);return e$kdl7 > _bip ? (ak$5s['comment'](mb_1pi, _bip + 0x4, e$kdl7 - _bip - 0x4), e$kdl7 + 0x3) : (d82hyc['error']('Unclosed comment'), -0x1);
      }return -0x1;default:
      if ('CDATA[' == mb_1pi['substr'](_bip + 0x3, 0x6)) {
        var e$kdl7 = mb_1pi['indexOf'](']]>', _bip + 0x9);return ak$5s['startCDATA'](), ak$5s['characters'](mb_1pi, _bip + 0x9, e$kdl7 - _bip - 0x9), ak$5s['endCDATA'](), e$kdl7 + 0x3;
      }var ngqa = l1b_o1(mb_1pi, _bip),
          yd8hc = ngqa['length'];if (yd8hc > 0x1 && /!doctype/i['test'](ngqa[0x0][0x0])) {
        var z69r = ngqa[0x1][0x0],
            oh2yj_ = yd8hc > 0x3 && /^public$/i['test'](ngqa[0x2][0x0]) && ngqa[0x3][0x0],
            a$k5s = yd8hc > 0x4 && ngqa[0x4][0x0],
            r09p = ngqa[yd8hc - 0x1];return ak$5s['startDTD'](z69r, oh2yj_ && oh2yj_['replace'](/^(['"])(.*?)\1$/, '$2'), a$k5s && a$k5s['replace'](/^(['"])(.*?)\1$/, '$2')), ak$5s['endDTD'](), r09p['index'] + r09p[0x0]['length'];
      }}return -0x1;
}function l1ael7k(d87, ak$57, jy8ch2) {
  var le$7a = d87['indexOf']('?>', ak$57);if (le$7a) {
    var _bomj1 = d87['substring'](ak$57, le$7a)['match'](/^<\?(\S*)\s*([\s\S]*?)\s*$/);if (_bomj1) {
      {
        _bomj1[0x0]['length'];
      }return jy8ch2['processingInstruction'](_bomj1[0x1], _bomj1[0x2]), le$7a + 0x2;
    }return -0x1;
  }return -0x1;
}function l1hec8d() {}function l1yh28cd(gaks5, i9rm) {
  return gaks5['__proto__'] = i9rm, gaks5;
}function l1b_o1(e78cld, b91i) {
  var elc7k,
      x6t0z = [],
      z0xr = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;for (z0xr['lastIndex'] = b91i, z0xr['exec'](e78cld); elc7k = z0xr['exec'](e78cld);) if (x6t0z['push'](elc7k), elc7k[0x1]) return x6t0z;
}var l1z906 = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    l1rpm90 = new RegExp('[\\-\\.0-9' + l1z906['source']['slice'](0x1, -0x1) + '\\u00B7\\u0300-\\u036F\\u203F-\\u2040]'),
    l1m9ip0 = new RegExp('^' + l1z906['source'] + l1rpm90['source'] + '*(?::' + l1z906['source'] + l1rpm90['source'] + '*)?$'),
    l1c28dhy = 0x0,
    l1pmib_ = 0x1,
    l1kecld7 = 0x2,
    l1jhy28 = 0x3,
    l1ledc87 = 0x4,
    l1$gq5 = 0x5,
    l1i9pr60 = 0x6,
    l1t3zf = 0x7;l1j2o_y['prototype'] = { 'parse': function (z6trxw, rt60zx, clh8de) {
    var d$7l = this['domBuilder'];d$7l['startDocument'](), l1y8h2(rt60zx, rt60zx = {}), l1b_2j(z6trxw, rt60zx, clh8de, d$7l, this['errorHandler']), d$7l['endDocument']();
  } }, l1hec8d['prototype'] = { 'setTagName': function (hcdle) {
    if (!l1m9ip0['test'](hcdle)) throw new Error('invalid tagName:' + hcdle);this['tagName'] = hcdle;
  }, 'add': function (ydh8ec, ag$k5, hc8dy) {
    if (!l1m9ip0['test'](ydh8ec)) throw new Error('invalid attribute:' + ydh8ec);this[this['length']++] = { 'qName': ydh8ec, 'value': ag$k5, 'offset': hc8dy };
  }, 'length': 0x0, 'getLocalName': function (c2jy8) {
    return this[c2jy8]['localName'];
  }, 'getLocator': function (_1pmi) {
    return this[_1pmi]['locator'];
  }, 'getQName': function (_boj2) {
    return this[_boj2]['qName'];
  }, 'getURI': function (e7$ld) {
    return this[e7$ld]['uri'];
  }, 'getValue': function (hoj2y_) {
    return this[hoj2y_]['value'];
  } }, l1yh28cd({}, l1yh28cd['prototype']) instanceof l1yh28cd || (l1yh28cd = function ($lk7de, jbo1m_) {
  function a5sn() {}a5sn['prototype'] = jbo1m_, a5sn = new a5sn();for (jbo1m_ in $lk7de) a5sn[jbo1m_] = $lk7de[jbo1m_];return a5sn;
}), exports['XMLReader'] = l1j2o_y;