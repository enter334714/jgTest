var Z = wx.$L;
function l1i6pr0(irp096) {
  this['options'] = irp096 || { 'locator': {} };
}function l1ojy21(p19ibm, gqsa5$, wtzuf3) {
  function ydehc8(del8h) {
    var ye8hd = p19ibm[del8h];!ye8hd && kc7ld && (ye8hd = 0x2 == p19ibm['length'] ? function (b1imp_) {
      p19ibm(del8h, b1imp_);
    } : p19ibm), yh_oj[del8h] = ye8hd && function (y2ch8) {
      ye8hd('[xmldom ' + del8h + ']\t' + y2ch8 + l1bmpi_(wtzuf3));
    } || function () {};
  }if (!p19ibm) {
    if (gqsa5$ instanceof l1svqn54) return gqsa5$;p19ibm = gqsa5$;
  }var yh_oj = {},
      kc7ld = p19ibm instanceof Function;return wtzuf3 = wtzuf3 || {}, ydehc8('warning'), ydehc8('error'), ydehc8('fatalError'), yh_oj;
}function l1svqn54() {
  this['cdata'] = !0x1;
}function l1xr6zt(r9x0p, g$75a) {
  g$75a['lineNumber'] = r9x0p['lineNumber'], g$75a['columnNumber'] = r9x0p['columnNumber'];
}function l1bmpi_(r9x60) {
  return r9x60 ? '\x0a@' + (r9x60['systemId'] || '') + '#[line:' + r9x60['lineNumber'] + ',col:' + r9x60['columnNumber'] + ']' : void 0x0;
}function l1dcy2(aqs5$, sgak5$, gn5sq) {
  return 'string' == typeof aqs5$ ? aqs5$['substr'](sgak5$, gn5sq) : aqs5$['length'] >= sgak5$ + gn5sq || sgak5$ ? new java['lang']['String'](aqs5$, sgak5$, gn5sq) + '' : aqs5$;
}function l1j_mo(o8h2jy, pb9mi) {
  o8h2jy['currentElement'] ? o8h2jy['currentElement']['appendChild'](pb9mi) : o8h2jy['doc']['appendChild'](pb9mi);
}l1i6pr0['prototype']['parseFromString'] = function (mi9r0, angs5q) {
  var dy8c = this['options'],
      j21_o = new l1dhey(),
      e$a7l = dy8c['domBuilder'] || new l1svqn54(),
      bmpi1_ = dy8c['errorHandler'],
      sq4v5n = dy8c['locator'],
      rxz06 = dy8c['xmlns'] || {},
      san5q = { 'lt': '<', 'gt': '>', 'amp': '&', 'quot': '\x22', 'apos': '\x27' };return sq4v5n && e$a7l['setDocumentLocator'](sq4v5n), j21_o['errorHandler'] = l1ojy21(bmpi1_, e$a7l, sq4v5n), j21_o['domBuilder'] = dy8c['domBuilder'] || e$a7l, /\/x?html?$/['test'](angs5q) && (san5q['nbsp'] = '\u00a0', san5q['copy'] = '©', rxz06[''] = 'http://www.w3.org/1999/xhtml'), rxz06['xml'] = rxz06['xml'] || 'http://www.w3.org/XML/1998/namespace', mi9r0 ? j21_o['parse'](mi9r0, rxz06, san5q) : j21_o['errorHandler']['error']('invalid doc source'), e$a7l['doc'];
}, l1svqn54['prototype'] = { 'startDocument': function () {
    this['doc'] = new l1qv5ngs()['createDocument'](null, null, null), this['locator'] && (this['doc']['documentURI'] = this['locator']['systemId']);
  }, 'startElement': function (m1_ibo, v5, ed7lk, zwrx6) {
    var rx069 = this['doc'],
        ced7 = rx069['createElementNS'](m1_ibo, ed7lk || v5),
        qg$a = zwrx6['length'];l1j_mo(this, ced7), this['currentElement'] = ced7, this['locator'] && l1xr6zt(this['locator'], ced7);for (var gk$l7a = 0x0; qg$a > gk$l7a; gk$l7a++) {
      var m1_ibo = zwrx6['getURI'](gk$l7a),
          o21jy = zwrx6['getValue'](gk$l7a),
          ed7lk = zwrx6['getQName'](gk$l7a),
          bo21_j = rx069['createAttributeNS'](m1_ibo, ed7lk);this['locator'] && l1xr6zt(zwrx6['getLocator'](gk$l7a), bo21_j), bo21_j['value'] = bo21_j['nodeValue'] = o21jy, ced7['setAttributeNode'](bo21_j);
    }
  }, 'endElement': function () {
    {
      var im9pb1 = this['currentElement'];im9pb1['tagName'];
    }this['currentElement'] = im9pb1['parentNode'];
  }, 'startPrefixMapping': function () {}, 'endPrefixMapping': function () {}, 'processingInstruction': function (yhd8e, sqgvn) {
    var ztuxw = this['doc']['createProcessingInstruction'](yhd8e, sqgvn);this['locator'] && l1xr6zt(this['locator'], ztuxw), l1j_mo(this, ztuxw);
  }, 'ignorableWhitespace': function () {}, 'characters': function (c8hdy) {
    if (c8hdy = l1dcy2['apply'](this, arguments)) {
      if (this['cdata']) var l$k7ag = this['doc']['createCDATASection'](c8hdy);else var l$k7ag = this['doc']['createTextNode'](c8hdy);this['currentElement'] ? this['currentElement']['appendChild'](l$k7ag) : /^\s*$/['test'](c8hdy) && this['doc']['appendChild'](l$k7ag), this['locator'] && l1xr6zt(this['locator'], l$k7ag);
    }
  }, 'skippedEntity': function () {}, 'endDocument': function () {
    this['doc']['normalize']();
  }, 'setDocumentLocator': function (yce8h) {
    (this['locator'] = yce8h) && (yce8h['lineNumber'] = 0x0);
  }, 'comment': function (nvs4q5) {
    nvs4q5 = l1dcy2['apply'](this, arguments);var joh_2y = this['doc']['createComment'](nvs4q5);this['locator'] && l1xr6zt(this['locator'], joh_2y), l1j_mo(this, joh_2y);
  }, 'startCDATA': function () {
    this['cdata'] = !0x0;
  }, 'endCDATA': function () {
    this['cdata'] = !0x1;
  }, 'startDTD': function (ojy2_h, mo_1j, xztwu6) {
    var k7a$g = this['doc']['implementation'];if (k7a$g && k7a$g['createDocumentType']) {
      var gsna5 = k7a$g['createDocumentType'](ojy2_h, mo_1j, xztwu6);this['locator'] && l1xr6zt(this['locator'], gsna5), l1j_mo(this, gsna5);
    }
  }, 'warning': function (dyche8) {
    console['warn']('[xmldom warning]\t' + dyche8, l1bmpi_(this['locator']));
  }, 'error': function (b1_o2) {
    console['error']('[xmldom error]\t' + b1_o2, l1bmpi_(this['locator']));
  }, 'fatalError': function (svn5qg) {
    throw console['error']('[xmldom fatalError]\t' + svn5qg, l1bmpi_(this['locator'])), svn5qg;
  } }, 'endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl'['replace'](/\w+/g, function (kag5$) {
  l1svqn54['prototype'][kag5$] = function () {
    return null;
  };
});var l1dhey = require('./lllSAX')['XMLReader'],
    l1qv5ngs = exports['DOMImplementation'] = require('./LLLDOM')['DOMImplementation'];exports['XMLSerializer'] = require('./LLLDOM')['XMLSerializer'], exports['DOMParser'] = l1i6pr0;