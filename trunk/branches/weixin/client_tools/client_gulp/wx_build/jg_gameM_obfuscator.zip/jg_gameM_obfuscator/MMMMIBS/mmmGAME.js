var Y = wx.$M;
console[Y[180001]](Y[180002]), window[Y[180003]], wx[Y[180004]](function (hmni5) {
  if (hmni5) {
    if (hmni5[Y[180005]]) {
      var fwrvdb = window[Y[180006]][Y[180007]][Y[180008]](new RegExp(/\./, 'g'), '_'),
          p2tz8e = hmni5[Y[180005]],
          g8oae = p2tz8e[Y[180009]](/(MMMMMMMM\/mmmGAME.js:)[0-9]{1,60}(:)/g);if (g8oae) for (var zpe8t = 0x0; zpe8t < g8oae[Y[180010]]; zpe8t++) {
        if (g8oae[zpe8t] && g8oae[zpe8t][Y[180010]] > 0x0) {
          var s4og_ = parseInt(g8oae[zpe8t][Y[180008]](Y[180011], '')[Y[180008]](':', ''));p2tz8e = p2tz8e[Y[180008]](g8oae[zpe8t], g8oae[zpe8t][Y[180008]](':' + s4og_ + ':', ':' + (s4og_ - 0x2) + ':'));
        }
      }p2tz8e = p2tz8e[Y[180008]](new RegExp(Y[180012], 'g'), Y[180013] + fwrvdb + Y[180014]), p2tz8e = p2tz8e[Y[180008]](new RegExp(Y[180015], 'g'), Y[180013] + fwrvdb + Y[180014]), hmni5[Y[180005]] = p2tz8e;
    }var m5lnh = { 'id': window['$m12'][Y[180016]], 'role': window['$m12'][Y[180017]], 'level': window['$m12'][Y[180018]], 'user': window['$m12'][Y[180019]], 'version': window['$m12'][Y[180020]], 'cdn': window['$m12'][Y[180021]], 'pkgName': window['$m12'][Y[180022]], 'gamever': window[Y[180006]][Y[180007]], 'serverid': window['$m12'][Y[180023]] ? window['$m12'][Y[180023]][Y[180024]] : 0x0, 'systemInfo': window[Y[180025]], 'error': Y[180026], 'stack': hmni5 ? hmni5[Y[180005]] : '' },
        d$l50b = JSON[Y[180027]](m5lnh);console[Y[180028]](Y[180029] + d$l50b), (!window[Y[180003]] || window[Y[180003]] != m5lnh[Y[180028]]) && (window[Y[180003]] = m5lnh[Y[180028]], window['$m41'](m5lnh));
  }
});import 'mmmmmmmmMDFIVEMIN.js';import 'mmmZLIBS.js';window[Y[180030]] = require(Y[180031]);import 'mmmmINDEX.js';import 'mmmmmmmLIBSMIN.js';import 'mmmmWXMINI.js';import 'mmmINITMIN.js';console[Y[180001]](Y[180032]), console[Y[180001]](Y[180033]), $m4102({ 'title': Y[180034] });var M_jn5imh = { '$m54210': !![] };new window[Y[180035]](M_jn5imh), window[Y[180035]][Y[180036]]['$m50124']();if (window['$m54120']) clearInterval(window['$m54120']);window['$m54120'] = null, window['$m50241'] = function (aect82, kv9fr1) {
  if (!aect82 || !kv9fr1) return 0x0;aect82 = aect82[Y[180037]]('.'), kv9fr1 = kv9fr1[Y[180037]]('.');const mnj_ = Math[Y[180038]](aect82[Y[180010]], kv9fr1[Y[180010]]);while (aect82[Y[180010]] < mnj_) {
    aect82[Y[180039]]('0');
  }while (kv9fr1[Y[180010]] < mnj_) {
    kv9fr1[Y[180039]]('0');
  }for (var mhil = 0x0; mhil < mnj_; mhil++) {
    const s4m_7j = parseInt(aect82[mhil]),
          lh5n0 = parseInt(kv9fr1[mhil]);if (s4m_7j > lh5n0) return 0x1;else {
      if (s4m_7j < lh5n0) return -0x1;
    }
  }return 0x0;
}, window[Y[180040]] = wx[Y[180041]]()[Y[180040]], console[Y[180042]](Y[180043] + window[Y[180040]]);var M_g4o6s = wx[Y[180044]]();M_g4o6s[Y[180045]](function (v1k9rx) {
  console[Y[180042]](Y[180046] + v1k9rx[Y[180047]]);
}), M_g4o6s[Y[180048]](function () {
  wx[Y[180049]]({ 'title': Y[180050], 'content': Y[180051], 'showCancel': ![], 'success': function (vfw$) {
      M_g4o6s[Y[180052]]();
    } });
}), M_g4o6s[Y[180053]](function () {
  console[Y[180042]](Y[180054]);
}), window['$m50214'] = function () {
  console[Y[180042]](Y[180055]);var $n50 = wx[Y[180056]]({ 'name': Y[180057], 'success': function (xkyu1q) {
      console[Y[180042]](Y[180058]), console[Y[180042]](xkyu1q), xkyu1q && xkyu1q[Y[180059]] == Y[180060] ? (window['$m20'] = !![], window['$m2014'](), window['$m2140']()) : setTimeout(function () {
        window['$m50214']();
      }, 0x1f4);
    }, 'fail': function (_mj4h) {
      console[Y[180042]](Y[180061]), console[Y[180042]](_mj4h), setTimeout(function () {
        window['$m50214']();
      }, 0x1f4);
    } });$n50 && $n50[Y[180062]](dfwr => {});
}, window['$m51420'] = function () {
  console[Y[180042]](Y[180063]);var rdfwv = wx[Y[180056]]({ 'name': Y[180064], 'success': function (rv9w1) {
      console[Y[180042]](Y[180065]), console[Y[180042]](rv9w1), rv9w1 && rv9w1[Y[180059]] == Y[180060] ? (window['$m102'] = !![], window['$m2014'](), window['$m2140']()) : setTimeout(function () {
        window['$m51420']();
      }, 0x1f4);
    }, 'fail': function (qyx) {
      console[Y[180042]](Y[180066]), console[Y[180042]](qyx), setTimeout(function () {
        window['$m51420']();
      }, 0x1f4);
    } });rdfwv && rdfwv[Y[180062]](s4o_67 => {});
}, window[Y[180067]] = function () {
  window['$m50241'](window[Y[180040]], Y[180068]) >= 0x0 ? (console[Y[180042]](Y[180069] + window[Y[180040]] + Y[180070]), window['$m14'](), window['$m50214'](), window['$m51420']()) : (window['$m124'](Y[180071], window[Y[180040]]), wx[Y[180049]]({ 'title': Y[180072], 'content': Y[180073] }));
}, window[Y[180025]] = '', wx[Y[180074]]({ 'success'(wb$dv) {
    window[Y[180025]] = Y[180075] + wb$dv[Y[180076]] + Y[180077] + wb$dv[Y[180078]] + Y[180079] + wb$dv[Y[180080]] + Y[180081] + wb$dv[Y[180082]] + Y[180083] + wb$dv[Y[180084]] + Y[180085] + wb$dv[Y[180040]] + Y[180086] + wb$dv[Y[180087]], console[Y[180042]](window[Y[180025]]), console[Y[180042]](Y[180088] + wb$dv[Y[180089]] + Y[180090] + wb$dv[Y[180091]] + Y[180092] + wb$dv[Y[180093]] + Y[180094] + wb$dv[Y[180095]] + Y[180096] + wb$dv[Y[180097]] + Y[180098] + wb$dv[Y[180099]] + Y[180100] + (wb$dv[Y[180101]] ? wb$dv[Y[180101]][Y[180102]] + ',' + wb$dv[Y[180101]][Y[180103]] + ',' + wb$dv[Y[180101]][Y[180104]] + ',' + wb$dv[Y[180101]][Y[180105]] : ''));var e2gc = wb$dv[Y[180082]] ? wb$dv[Y[180082]][Y[180106]]() : '',
        l05i = wb$dv[Y[180078]] ? wb$dv[Y[180078]][Y[180106]]()[Y[180008]]('\x20', '') : '';window['$m12'][Y[180107]] = e2gc[Y[180108]](Y[180109]) != -0x1, window['$m12'][Y[180110]] = e2gc[Y[180108]](Y[180111]) != -0x1, window['$m12'][Y[180112]] = e2gc[Y[180108]](Y[180109]) != -0x1 || e2gc[Y[180108]](Y[180111]) != -0x1, window['$m12'][Y[180113]] = e2gc[Y[180108]](Y[180114]) != -0x1 || e2gc[Y[180108]](Y[180115]) != -0x1, window['$m12'][Y[180116]] = wb$dv[Y[180084]] ? wb$dv[Y[180084]][Y[180106]]() : '', window['$m12']['$m54021'] = ![], window['$m12']['$m54102'] = 0x2;if (e2gc[Y[180108]](Y[180111]) != -0x1) {
      if (wb$dv[Y[180087]] >= 0x18) window['$m12']['$m54102'] = 0x3;else window['$m12']['$m54102'] = 0x2;
    } else {
      if (e2gc[Y[180108]](Y[180109]) != -0x1) {
        if (wb$dv[Y[180087]] && wb$dv[Y[180087]] >= 0x14) window['$m12']['$m54102'] = 0x3;else {
          if (l05i[Y[180108]](Y[180117]) != -0x1 || l05i[Y[180108]](Y[180118]) != -0x1 || l05i[Y[180108]](Y[180119]) != -0x1 || l05i[Y[180108]](Y[180120]) != -0x1 || l05i[Y[180108]](Y[180121]) != -0x1) window['$m12']['$m54102'] = 0x2;else window['$m12']['$m54102'] = 0x3;
        }
      } else window['$m12']['$m54102'] = 0x2;
    }console[Y[180042]](Y[180122] + window['$m12']['$m54021'] + Y[180123] + window['$m12']['$m54102']);
  } }), wx[Y[180124]]({ 'success': function (gea8co) {
    console[Y[180042]](Y[180125] + gea8co[Y[180126]] + Y[180127] + gea8co[Y[180128]]);
  } }), wx[Y[180129]]({ 'success': function (ep28zt) {
    console[Y[180042]](Y[180130] + ep28zt[Y[180131]]);
  } }), wx[Y[180132]]({ 'keepScreenOn': !![] }), wx[Y[180133]](function (x19ky) {
  console[Y[180042]](Y[180130] + x19ky[Y[180131]] + Y[180134] + x19ky[Y[180135]]);
}), wx[Y[180136]](function (b5$0d) {
  window['$m04'] = b5$0d, window['$m240'] && window['$m04'] && (console[Y[180001]](Y[180137] + window['$m04'][Y[180138]]), window['$m240'](window['$m04']), window['$m04'] = null);
}), window[Y[180139]] = 0x0, window['$m51024'] = 0x0, window[Y[180140]] = null, wx[Y[180141]](function () {
  window['$m51024']++;var j6_74 = Date[Y[180142]]();(window[Y[180139]] == 0x0 || j6_74 - window[Y[180139]] > 0x1d4c0) && (console[Y[180143]](Y[180144]), wx[Y[180145]]());if (window['$m51024'] >= 0x2) {
    window['$m51024'] = 0x0, console[Y[180028]](Y[180146]), wx[Y[180147]]('0', 0x1);if (window['$m12'] && window['$m12'][Y[180107]]) window['$m124'](Y[180148], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});