var Y = wx.$M;
require(Y[180000]);