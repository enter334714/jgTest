var Y = wx.$M;
import 'MMMMAIN.js';