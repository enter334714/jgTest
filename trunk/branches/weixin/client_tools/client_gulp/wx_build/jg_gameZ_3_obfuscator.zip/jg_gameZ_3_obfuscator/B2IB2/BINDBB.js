var D = wx.$b;
import btw1c from '../BBbasdB/B5sdkB.js';window[D[500564]] = { 'wxVersion': window[D[500005]][D[500006]] }, window[D[500565]] = ![], window['b11P'] = 0x1, window[D[500566]] = 0x1, window['b1TP1'] = !![], window[D[500567]] = !![], window['b17STP1'] = '', window['b1P1'] = { 'base_cdn': D[500568], 'cdn': D[500568] }, b1P1[D[500569]] = {}, b1P1[D[500570]] = '0', b1P1[D[500079]] = window[D[500564]][D[500347]], b1P1[D[500114]] = '', b1P1['os'] = '1', b1P1[D[500571]] = D[500572], b1P1[D[500573]] = D[500574], b1P1[D[500575]] = D[500576], b1P1[D[500577]] = D[500578], b1P1[D[500579]] = D[500580], b1P1[D[500581]] = '1', b1P1[D[500021]] = '', b1P1[D[500582]] = '', b1P1[D[500583]] = 0x0, b1P1[D[500438]] = {}, b1P1[D[500584]] = parseInt(b1P1[D[500581]]), b1P1[D[500585]] = b1P1[D[500581]], b1P1[D[500022]] = {}, b1P1['b1SP'] = D[500586], b1P1[D[500587]] = ![], b1P1[D[500588]] = D[500589], b1P1[D[500590]] = Date[D[500141]](), b1P1[D[500591]] = D[500592], b1P1[D[500593]] = '_a', b1P1[D[500333]] = 0x2, b1P1[D[500019]] = 0x7c1, b1P1[D[500347]] = window[D[500564]][D[500347]], b1P1[D[500594]] = ![], b1P1[D[500106]] = ![], b1P1[D[500109]] = ![], b1P1[D[500112]] = ![], window['b1T1P'] = 0x5, window['b1T1'] = ![], window['b11T'] = ![], window['b1PT1'] = ![], window[D[500515]] = ![], window[D[500518]] = ![], window['b1P1T'] = ![], window['b1TP'] = ![], window['b1PT'] = ![], window['b11TP'] = ![], window[D[500595]] = function (r_h9s) {
  console[D[500041]](D[500595], r_h9s), wx[D[500596]]({}), wx[D[500048]]({ 'title': D[500071], 'content': r_h9s, 'success'(lo8d6s) {
      if (lo8d6s[D[500597]]) console[D[500041]](D[500598]);else lo8d6s[D[500599]] && console[D[500041]](D[500600]);
    } });
}, window['b1STP1'] = function (cwzmt) {
  console[D[500041]](D[500601], cwzmt), b1SP1T(), wx[D[500048]]({ 'title': D[500071], 'content': cwzmt, 'confirmText': D[500602], 'cancelText': D[500603], 'success'(twzm1c) {
      if (twzm1c[D[500597]]) window['b1PS']();else twzm1c[D[500599]] && (console[D[500041]](D[500604]), wx[D[500605]]({}));
    } });
}, window[D[500606]] = function (njui4) {
  console[D[500041]](D[500606], njui4), wx[D[500048]]({ 'title': D[500071], 'content': njui4, 'confirmText': D[500607], 'showCancel': ![], 'complete'(mzy1) {
      console[D[500041]](D[500604]), wx[D[500605]]({});
    } });
}, window['b1ST1P'] = ![], window['b1SPT1'] = function (s69dr8) {
  window['b1ST1P'] = !![], wx[D[500608]](s69dr8);
}, window['b1SP1T'] = function () {
  window['b1ST1P'] && (window['b1ST1P'] = ![], wx[D[500596]]({}));
}, window['b1S1TP'] = function (zyuni) {
  window[D[500034]][D[500035]]['b1S1TP'](zyuni);
}, window[D[500609]] = function (ij504n, l86ok) {
  btw1c[D[500609]](ij504n, function (d69r8s) {
    d69r8s && d69r8s[D[500448]] ? d69r8s[D[500448]][D[500447]] == 0x1 ? l86ok(!![]) : (l86ok(![]), console[D[500000]](D[500610] + d69r8s[D[500448]][D[500611]])) : console[D[500041]](D[500609], d69r8s);
  });
}, window['b1S1PT'] = function (w1ztm) {
  console[D[500041]](D[500612], w1ztm);
}, window['b1SP1'] = function (tcz1wm) {}, window['b1S1P'] = function (ujyn0, ni0uy, an5j4) {}, window['b1S1'] = function (nj54a) {
  console[D[500041]](D[500613], nj54a), window[D[500034]][D[500035]][D[500337]](), window[D[500034]][D[500035]][D[500338]](), window[D[500034]][D[500035]][D[500351]]();
}, window['b11S'] = function ($54e) {
  window['b1STP1'](D[500614]);var tzy1mc = { 'id': window['b1P1'][D[500015]], 'role': window['b1P1'][D[500016]], 'level': window['b1P1'][D[500017]], 'account': window['b1P1'][D[500018]], 'version': window['b1P1'][D[500019]], 'cdn': window['b1P1'][D[500020]], 'pkgName': window['b1P1'][D[500021]], 'gamever': window[D[500005]][D[500006]], 'serverid': window['b1P1'][D[500022]] ? window['b1P1'][D[500022]][D[500023]] : 0x0, 'systemInfo': window[D[500024]], 'error': D[500615], 'stack': $54e ? $54e : D[500614] },
      rv2_h = JSON[D[500026]](tzy1mc);console[D[500027]](D[500616] + rv2_h), window['b1SP'](rv2_h);
}, window['b1PS1'] = function (uynzi0) {
  var $nj54a = JSON[D[500617]](uynzi0);$nj54a[D[500618]] = window[D[500005]][D[500006]], $nj54a[D[500619]] = window['b1P1'][D[500022]] ? window['b1P1'][D[500022]][D[500023]] : 0x0, $nj54a[D[500024]] = window[D[500024]];var mztu = JSON[D[500026]]($nj54a);console[D[500027]](D[500620] + mztu), window['b1SP'](mztu);
}, window['b1P1S'] = function (wv_hp2, kx3q) {
  var mtzy1 = { 'id': window['b1P1'][D[500015]], 'role': window['b1P1'][D[500016]], 'level': window['b1P1'][D[500017]], 'account': window['b1P1'][D[500018]], 'version': window['b1P1'][D[500019]], 'cdn': window['b1P1'][D[500020]], 'pkgName': window['b1P1'][D[500021]], 'gamever': window[D[500005]][D[500006]], 'serverid': window['b1P1'][D[500022]] ? window['b1P1'][D[500022]][D[500023]] : 0x0, 'systemInfo': window[D[500024]], 'error': wv_hp2, 'stack': kx3q },
      _wh1v = JSON[D[500026]](mtzy1);console[D[500142]](D[500621] + _wh1v), window['b1SP'](_wh1v);
}, window['b1SP'] = function (kg7qlx) {
  if (window['b1P1'][D[500115]] == D[500622]) return;var cmtuyz = b1P1['b1SP'] + D[500623] + b1P1[D[500018]];wx[D[500624]]({ 'url': cmtuyz, 'method': D[500625], 'data': kg7qlx, 'header': { 'content-type': D[500626], 'cache-control': D[500627] }, 'success': function (ok67x) {
      DEBUG && console[D[500041]](D[500628], cmtuyz, kg7qlx, ok67x);
    }, 'fail': function (zcmyt) {
      DEBUG && console[D[500041]](D[500628], cmtuyz, kg7qlx, zcmyt);
    }, 'complete': function () {} });
}, window[D[500629]] = function () {
  function o98ds6() {
    return ((0x1 + Math[D[500340]]()) * 0x10000 | 0x0)[D[500630]](0x10)[D[500631]](0x1);
  }return o98ds6() + o98ds6() + '-' + o98ds6() + '-' + o98ds6() + '-' + o98ds6() + '+' + o98ds6() + o98ds6() + o98ds6();
}, window['b1PS'] = function () {
  console[D[500041]](D[500632]);var h9s2r = btw1c[D[500633]]();b1P1[D[500585]] = h9s2r[D[500634]], b1P1[D[500584]] = h9s2r[D[500634]], b1P1[D[500581]] = h9s2r[D[500634]], b1P1[D[500021]] = h9s2r[D[500635]];var iujn0 = { 'game_ver': b1P1[D[500079]] };b1P1[D[500582]] = this[D[500629]](), b1SPT1({ 'title': D[500636] }), btw1c[D[500480]](iujn0, this['b11SP'][D[500344]](this));
};var wx_develop = ![];window['b11SP'] = function (wph) {
  var p2vhr = wph[D[500637]];wx_develop = p2vhr == 0x1, console[D[500041]](D[500638] + p2vhr + D[500639] + (p2vhr == 0x1) + D[500640] + wph[D[500006]] + D[500641] + window[D[500564]][D[500347]]);if (!wph[D[500006]] || window['b17T1SP'](window[D[500564]][D[500347]], wph[D[500006]]) < 0x0) console[D[500041]](D[500642]), b1P1[D[500573]] = D[500643], b1P1[D[500575]] = D[500644], b1P1[D[500577]] = D[500645], b1P1[D[500020]] = D[500646], b1P1[D[500647]] = D[500648], b1P1[D[500649]] = 'll', b1P1[D[500594]] = ![];else window['b17T1SP'](window[D[500564]][D[500347]], wph[D[500006]]) == 0x0 ? (console[D[500041]](D[500650]), b1P1[D[500573]] = D[500574], b1P1[D[500575]] = D[500576], b1P1[D[500577]] = D[500578], b1P1[D[500020]] = D[500651], b1P1[D[500647]] = D[500648], b1P1[D[500649]] = D[500652], b1P1[D[500594]] = !![]) : (console[D[500041]](D[500653]), b1P1[D[500573]] = D[500574], b1P1[D[500575]] = D[500576], b1P1[D[500577]] = D[500578], b1P1[D[500020]] = D[500651], b1P1[D[500647]] = D[500648], b1P1[D[500649]] = D[500652], b1P1[D[500594]] = ![]);b1P1[D[500583]] = config[D[500654]] ? config[D[500654]] : 0x0, this['b1TPS1'](), this['b1TP1S'](), window[D[500655]] = 0x5, b1SPT1({ 'title': D[500656] }), btw1c[D[500657]](this['b11PS'][D[500344]](this));
}, window[D[500655]] = 0x5, window['b11PS'] = function (h1vw, njyu0i) {
  if (h1vw == 0x0 && njyu0i && njyu0i[D[500658]]) {
    b1P1[D[500659]] = njyu0i[D[500658]];var f45e$a = this;b1SPT1({ 'title': D[500660] }), sendApi(b1P1[D[500573]], D[500661], { 'platform': b1P1[D[500571]], 'partner_id': b1P1[D[500581]], 'token': njyu0i[D[500658]], 'game_pkg': b1P1[D[500021]], 'deviceId': b1P1[D[500582]], 'scene': D[500662] + b1P1[D[500583]] }, this['b1TSP1'][D[500344]](this), b1T1P, b11S);
  } else njyu0i && njyu0i[D[500058]] && window[D[500655]] > 0x0 && (njyu0i[D[500058]][D[500107]](D[500663]) != -0x1 || njyu0i[D[500058]][D[500107]](D[500664]) != -0x1 || njyu0i[D[500058]][D[500107]](D[500665]) != -0x1 || njyu0i[D[500058]][D[500107]](D[500666]) != -0x1 || njyu0i[D[500058]][D[500107]](D[500667]) != -0x1 || njyu0i[D[500058]][D[500107]](D[500668]) != -0x1) ? (window[D[500655]]--, btw1c[D[500657]](this['b11PS'][D[500344]](this))) : (window['b1P1S'](D[500669], JSON[D[500026]]({ 'status': h1vw, 'data': njyu0i })), window['b1STP1'](D[500670] + (njyu0i && njyu0i[D[500058]] ? '，' + njyu0i[D[500058]] : '')));
}, window['b1TSP1'] = function (ea$4f) {
  if (!ea$4f) {
    window['b1P1S'](D[500671], D[500672]), window['b1STP1'](D[500673]);return;
  }if (ea$4f[D[500447]] != D[500446]) {
    window['b1P1S'](D[500671], JSON[D[500026]](ea$4f)), window['b1STP1'](D[500674] + ea$4f[D[500447]]);return;
  }b1P1[D[500675]] = String(ea$4f[D[500018]]), b1P1[D[500018]] = String(ea$4f[D[500018]]), b1P1[D[500083]] = String(ea$4f[D[500083]]), b1P1[D[500585]] = String(ea$4f[D[500083]]), b1P1[D[500676]] = String(ea$4f[D[500676]]), b1P1[D[500677]] = String(ea$4f[D[500678]]), b1P1[D[500679]] = String(ea$4f[D[500680]]), b1P1[D[500678]] = '';var m1cz = this;b1SPT1({ 'title': D[500681] }), sendApi(b1P1[D[500573]], D[500682], { 'partner_id': b1P1[D[500581]], 'uid': b1P1[D[500018]], 'version': b1P1[D[500079]], 'game_pkg': b1P1[D[500021]], 'device': b1P1[D[500582]] }, m1cz['b1TS1P'][D[500344]](m1cz), b1T1P, b11S);
}, window['b1TS1P'] = function (s92rd8) {
  if (!s92rd8) {
    window['b1STP1'](D[500683]);return;
  }if (s92rd8[D[500447]] != D[500446]) {
    window['b1STP1'](D[500684] + s92rd8[D[500447]]);return;
  }if (!s92rd8[D[500448]] || s92rd8[D[500448]][D[500009]] == 0x0) {
    window['b1STP1'](D[500685]);return;
  }b1P1[D[500524]] = s92rd8[D[500686]], b1P1[D[500022]] = { 'server_id': String(s92rd8[D[500448]][0x0][D[500023]]), 'server_name': String(s92rd8[D[500448]][0x0][D[500426]]), 'entry_ip': s92rd8[D[500448]][0x0][D[500687]], 'entry_port': parseInt(s92rd8[D[500448]][0x0][D[500688]]), 'status': b1PTS(s92rd8[D[500448]][0x0]), 'start_time': s92rd8[D[500448]][0x0][D[500689]], 'cdn': b1P1[D[500020]] }, this['b11PTS']();
}, window['b11PTS'] = function () {
  if (b1P1[D[500524]] == 0x1) {
    var cvtp1 = b1P1[D[500022]][D[500425]];if (cvtp1 === -0x1 || cvtp1 === 0x0) {
      window['b1STP1'](cvtp1 === -0x1 ? D[500690] : D[500691]);return;
    }b11STP(0x0, b1P1[D[500022]][D[500023]]), window[D[500034]][D[500035]][D[500519]](b1P1[D[500524]]);
  } else window[D[500034]][D[500035]][D[500516]](), b1SP1T();window['b1PT'] = !![], window['b11TPS'](), window['b11PST']();
}, window['b1TPS1'] = function () {
  sendApi(b1P1[D[500573]], D[500692], { 'game_pkg': b1P1[D[500021]], 'version_name': b1P1[D[500649]] }, this[D[500693]][D[500344]](this), b1T1P, b11S);
}, window[D[500693]] = function (mzui) {
  if (!mzui) {
    window['b1STP1'](D[500694]);return;
  }if (mzui[D[500447]] != D[500446]) {
    window['b1STP1'](D[500695] + mzui[D[500447]]);return;
  }if (!mzui[D[500448]] || !mzui[D[500448]][D[500079]]) {
    window['b1STP1'](D[500696] + (mzui[D[500448]] && mzui[D[500448]][D[500079]]));return;
  }mzui[D[500448]][D[500697]] && mzui[D[500448]][D[500697]][D[500009]] > 0xa && (b1P1[D[500698]] = mzui[D[500448]][D[500697]], b1P1[D[500020]] = mzui[D[500448]][D[500697]]), mzui[D[500448]][D[500079]] && (b1P1[D[500019]] = mzui[D[500448]][D[500079]]), console[D[500000]](D[500699] + b1P1[D[500019]] + D[500700] + b1P1[D[500649]]), window['b1P1T'] = !![], window['b11TPS'](), window['b11PST']();
}, window[D[500701]], window['b1TP1S'] = function () {
  sendApi(b1P1[D[500573]], D[500702], { 'game_pkg': b1P1[D[500021]] }, this['b1T1SP'][D[500344]](this), b1T1P, b11S);
}, window['b1T1SP'] = function (juin4) {
  if (juin4[D[500447]] === D[500446] && juin4[D[500448]]) {
    window[D[500701]] = juin4[D[500448]];for (var czmtuy in juin4[D[500448]]) {
      b1P1[czmtuy] = juin4[D[500448]][czmtuy];
    }
  } else console[D[500000]](D[500703] + juin4[D[500447]]);window['b1TP'] = !![], window['b11PST']();
}, window[D[500704]] = function (uymi0z, mztwc, k8old, yzmtui, j4$5a, kq7xgl, lqgk, l68okd, mitzu) {
  j4$5a = String(j4$5a);var d8r92 = lqgk,
      hpv2r = l68okd;b1P1[D[500569]][j4$5a] = { 'productid': j4$5a, 'productname': d8r92, 'productdesc': hpv2r, 'roleid': uymi0z, 'rolename': mztwc, 'rolelevel': k8old, 'price': kq7xgl, 'callback': mitzu }, sendApi(b1P1[D[500577]], D[500705], { 'game_pkg': b1P1[D[500021]], 'server_id': b1P1[D[500022]][D[500023]], 'server_name': b1P1[D[500022]][D[500426]], 'level': k8old, 'uid': b1P1[D[500018]], 'role_id': uymi0z, 'role_name': mztwc, 'product_id': j4$5a, 'product_name': d8r92, 'product_desc': hpv2r, 'money': kq7xgl, 'partner_id': b1P1[D[500581]] }, toPayCallBack, b1T1P, b11S);
}, window[D[500706]] = function (tcpv) {
  if (tcpv) {
    if (tcpv[D[500707]] === 0xc8 || tcpv[D[500447]] == D[500446]) {
      var qkx73g = b1P1[D[500569]][String(tcpv[D[500708]])];if (qkx73g[D[500709]]) qkx73g[D[500709]](tcpv[D[500708]], tcpv[D[500710]], -0x1);btw1c[D[500711]]({ 'cpbill': tcpv[D[500710]], 'productid': tcpv[D[500708]], 'productname': qkx73g[D[500712]], 'productdesc': qkx73g[D[500713]], 'serverid': b1P1[D[500022]][D[500023]], 'servername': b1P1[D[500022]][D[500426]], 'roleid': qkx73g[D[500714]], 'rolename': qkx73g[D[500715]], 'rolelevel': qkx73g[D[500716]], 'price': qkx73g[D[500717]], 'extension': JSON[D[500026]]({ 'cp_order_id': tcpv[D[500710]] }) }, function (o6k8d, vw_1h) {
        qkx73g[D[500709]] && o6k8d == 0x0 && qkx73g[D[500709]](tcpv[D[500708]], tcpv[D[500710]], o6k8d);console[D[500000]](JSON[D[500026]]({ 'type': D[500718], 'status': o6k8d, 'data': tcpv, 'role_name': qkx73g[D[500715]] }));if (o6k8d === 0x0) {} else {
          if (o6k8d === 0x1) {} else {
            if (o6k8d === 0x2) {}
          }
        }
      });
    } else alert(tcpv[D[500000]]);
  }
}, window['b1T1PS'] = function () {}, window['b1ST1'] = function (faj4, rvhp2, wtp1cv, jn40$5, fa5$e4) {
  btw1c[D[500719]](b1P1[D[500022]][D[500023]], b1P1[D[500022]][D[500426]] || b1P1[D[500022]][D[500023]], faj4, rvhp2, wtp1cv), sendApi(b1P1[D[500573]], D[500720], { 'game_pkg': b1P1[D[500021]], 'server_id': b1P1[D[500022]][D[500023]], 'role_id': faj4, 'uid': b1P1[D[500018]], 'role_name': rvhp2, 'role_type': jn40$5, 'level': wtp1cv });
}, window['b1S1T'] = function (yzcu, jui0y, mc1yzt, rs986, n450ji, x7k, lk6o7x, ni04ju, v1ph_, gxq7l) {
  b1P1[D[500015]] = yzcu, b1P1[D[500016]] = jui0y, b1P1[D[500017]] = mc1yzt, btw1c[D[500721]](b1P1[D[500022]][D[500023]], b1P1[D[500022]][D[500426]] || b1P1[D[500022]][D[500023]], yzcu, jui0y, mc1yzt), sendApi(b1P1[D[500573]], D[500722], { 'game_pkg': b1P1[D[500021]], 'server_id': b1P1[D[500022]][D[500023]], 'role_id': yzcu, 'uid': b1P1[D[500018]], 'role_name': jui0y, 'role_type': rs986, 'level': mc1yzt, 'evolution': n450ji });
}, window['b1TS1'] = function (qg3x7, gk73q, ptwmc, mpctw, hp_w2, mtycz1, r968, ldo86k, tcwm1, mcpwt1) {
  b1P1[D[500015]] = qg3x7, b1P1[D[500016]] = gk73q, b1P1[D[500017]] = ptwmc, btw1c[D[500723]](b1P1[D[500022]][D[500023]], b1P1[D[500022]][D[500426]] || b1P1[D[500022]][D[500023]], qg3x7, gk73q, ptwmc), sendApi(b1P1[D[500573]], D[500722], { 'game_pkg': b1P1[D[500021]], 'server_id': b1P1[D[500022]][D[500023]], 'role_id': qg3x7, 'uid': b1P1[D[500018]], 'role_name': gk73q, 'role_type': mpctw, 'level': ptwmc, 'evolution': hp_w2 });
}, window['b1T1S'] = function (tcmzy1) {}, window['b1ST'] = function (ij0n45) {
  btw1c[D[500724]](D[500724], function (c1mt) {
    ij0n45 && ij0n45(c1mt);
  });
}, window[D[500725]] = function () {
  btw1c[D[500725]]();
}, window[D[500726]] = function () {
  btw1c[D[500727]]();
}, window[D[500728]] = function (wcpm, qglxk7, v92r_h, yjn0, qxkg3, zy1mt, nizy0, _9rh2s) {
  _9rh2s = _9rh2s || b1P1[D[500022]][D[500023]], sendApi(b1P1[D[500573]], D[500729], { 'phone': wcpm, 'role_id': qglxk7, 'uid': b1P1[D[500018]], 'game_pkg': b1P1[D[500021]], 'partner_id': b1P1[D[500581]], 'server_id': _9rh2s }, nizy0);
}, window[D[500135]] = function (vw1hcp) {
  window['b11ST'] = vw1hcp, window['b11ST'] && window['b1TS'] && (console[D[500000]](D[500136] + window['b1TS'][D[500137]]), window['b11ST'](window['b1TS']), window['b1TS'] = null);
}, window['b11TS'] = function (p_hv1, rp2hv, hwp2_, vw_1ph) {
  window[D[500730]](D[500731], { 'game_pkg': window['b1P1'][D[500021]], 'role_id': rp2hv, 'server_id': hwp2_ }, vw_1ph);
}, window['b1PST1'] = function (wcvt, lox6k7) {
  function czwm1(mw1zt) {
    var _2prhv = [],
        iu04n = [],
        x7qk = window[D[500005]][D[500732]];for (var d982s in x7qk) {
      var mc1t = Number(d982s);(!wcvt || !wcvt[D[500009]] || wcvt[D[500107]](mc1t) != -0x1) && (iu04n[D[500038]](x7qk[d982s]), _2prhv[D[500038]]([mc1t, 0x3]));
    }window['b17T1SP'](window[D[500039]], D[500733]) >= 0x0 ? (console[D[500041]](D[500734]), btw1c[D[500735]] && btw1c[D[500735]](iu04n, function (cmp1w) {
      console[D[500041]](D[500736]), console[D[500041]](cmp1w);if (cmp1w && cmp1w[D[500058]] == D[500737]) for (var y0zimu in x7qk) {
        if (cmp1w[x7qk[y0zimu]] == D[500738]) {
          var xl6ko7 = Number(y0zimu);for (var mutiy = 0x0; mutiy < _2prhv[D[500009]]; mutiy++) {
            if (_2prhv[mutiy][0x0] == xl6ko7) {
              _2prhv[mutiy][0x1] = 0x1;break;
            }
          }
        }
      }window['b17T1SP'](window[D[500039]], D[500739]) >= 0x0 ? wx[D[500740]]({ 'withSubscriptions': !![], 'success': function (pvw2_h) {
          var j0$45n = pvw2_h[D[500741]][D[500742]];if (j0$45n) {
            console[D[500041]](D[500743]), console[D[500041]](j0$45n);for (var vtwc1 in x7qk) {
              if (j0$45n[x7qk[vtwc1]] == D[500738]) {
                var af$ = Number(vtwc1);for (var s68d9 = 0x0; s68d9 < _2prhv[D[500009]]; s68d9++) {
                  if (_2prhv[s68d9][0x0] == af$) {
                    _2prhv[s68d9][0x1] = 0x2;break;
                  }
                }
              }
            }console[D[500041]](_2prhv), lox6k7 && lox6k7(_2prhv);
          } else console[D[500041]](D[500744]), console[D[500041]](pvw2_h), console[D[500041]](_2prhv), lox6k7 && lox6k7(_2prhv);
        }, 'fail': function () {
          console[D[500041]](D[500745]), console[D[500041]](_2prhv), lox6k7 && lox6k7(_2prhv);
        } }) : (console[D[500041]](D[500746] + window[D[500039]]), console[D[500041]](_2prhv), lox6k7 && lox6k7(_2prhv));
    })) : (console[D[500041]](D[500747] + window[D[500039]]), console[D[500041]](_2prhv), lox6k7 && lox6k7(_2prhv)), wx[D[500748]](czwm1);
  }wx[D[500749]](czwm1);
}, window['b1PS1T'] = { 'isSuccess': ![], 'level': D[500750], 'isCharging': ![] }, window['b1PTS1'] = function (r2s_8) {
  wx[D[500123]]({ 'success': function (w_p2h) {
      var vhw_1p = window['b1PS1T'];vhw_1p[D[500751]] = !![], vhw_1p[D[500125]] = Number(w_p2h[D[500125]])[D[500752]](0x0), vhw_1p[D[500127]] = w_p2h[D[500127]], r2s_8 && r2s_8(vhw_1p[D[500751]], vhw_1p[D[500125]], vhw_1p[D[500127]]);
    }, 'fail': function (lk6ox) {
      console[D[500041]](D[500753], lk6ox[D[500058]]);var jn0yi = window['b1PS1T'];r2s_8 && r2s_8(jn0yi[D[500751]], jn0yi[D[500125]], jn0yi[D[500127]]);
    } });
}, window[D[500730]] = function (tziymu, pcvh1w, lox7k6, my1z, ztymc1, myt1cz, xklo76, oxk7lq) {
  if (my1z == undefined) my1z = 0x1;wx[D[500624]]({ 'url': tziymu, 'method': xklo76 || D[500754], 'responseType': D[500342], 'data': pcvh1w, 'header': { 'content-type': oxk7lq || D[500626] }, 'success': function (izuy) {
      DEBUG && console[D[500041]](D[500755], tziymu, info, izuy);if (izuy && izuy[D[500756]] == 0xc8) {
        var r2d98 = izuy[D[500448]];!myt1cz || myt1cz(r2d98) ? lox7k6 && lox7k6(r2d98) : window[D[500757]](tziymu, pcvh1w, lox7k6, my1z, ztymc1, myt1cz, izuy);
      } else window[D[500757]](tziymu, pcvh1w, lox7k6, my1z, ztymc1, myt1cz, izuy);
    }, 'fail': function (s8o6) {
      DEBUG && console[D[500041]](D[500758], tziymu, info, s8o6), window[D[500757]](tziymu, pcvh1w, lox7k6, my1z, ztymc1, myt1cz, s8o6);
    }, 'complete': function () {} });
}, window[D[500757]] = function (kxq37g, yu0nij, n0i45j, pc1mw, h1_pv, sd68l, w_vp1h) {
  pc1mw - 0x1 > 0x0 ? setTimeout(function () {
    window[D[500730]](kxq37g, yu0nij, n0i45j, pc1mw - 0x1, h1_pv, sd68l);
  }, 0x3e8) : h1_pv && h1_pv(JSON[D[500026]]({ 'url': kxq37g, 'response': w_vp1h }));
}, window[D[500759]] = function (dxk6lo, m0yzui, s9r2, lkdx, tucz, vprh, l8s6d) {
  !s9r2 && (s9r2 = {});var a5j$ = Math[D[500536]](Date[D[500141]]() / 0x3e8);s9r2[D[500680]] = a5j$, s9r2[D[500760]] = m0yzui;var qkxlg = Object[D[500761]](s9r2)[D[500452]](),
      qoxk7l = '',
      qkg = '';for (var unyij = 0x0; unyij < qkxlg[D[500009]]; unyij++) {
    qoxk7l = qoxk7l + (unyij == 0x0 ? '' : '&') + qkxlg[unyij] + s9r2[qkxlg[unyij]], qkg = qkg + (unyij == 0x0 ? '' : '&') + qkxlg[unyij] + '=' + encodeURIComponent(s9r2[qkxlg[unyij]]);
  }qoxk7l = qoxk7l + b1P1[D[500579]];var h_s9r2 = D[500762] + md5(qoxk7l);send(dxk6lo + '?' + qkg + (qkg == '' ? '' : '&') + h_s9r2, null, lkdx, tucz, vprh, l8s6d || function (xkqo7) {
    return xkqo7[D[500447]] == D[500446];
  }, null, D[500763]);
}, window['b1PT1S'] = function (mtcw, h2_pwv) {
  var mytiu = 0x0;b1P1[D[500022]] && (mytiu = b1P1[D[500022]][D[500023]]), sendApi(b1P1[D[500575]], D[500764], { 'partnerId': b1P1[D[500581]], 'gamePkg': b1P1[D[500021]], 'logTime': Math[D[500536]](Date[D[500141]]() / 0x3e8), 'platformUid': b1P1[D[500676]], 'type': mtcw, 'serverId': mytiu }, null, 0x2, null, function () {
    return !![];
  });
}, window['b1P1ST'] = function (uzity) {
  sendApi(b1P1[D[500573]], D[500765], { 'partner_id': b1P1[D[500581]], 'uid': b1P1[D[500018]], 'version': b1P1[D[500079]], 'game_pkg': b1P1[D[500021]], 'device': b1P1[D[500582]] }, b1P1TS, b1T1P, b11S);
}, window['b1P1TS'] = function (p_hvr2) {
  if (p_hvr2[D[500447]] === D[500446] && p_hvr2[D[500448]]) {
    p_hvr2[D[500448]][D[500766]]({ 'id': -0x2, 'name': D[500767] }), p_hvr2[D[500448]][D[500766]]({ 'id': -0x1, 'name': D[500768] }), b1P1[D[500399]] = p_hvr2[D[500448]];if (window[D[500391]]) window[D[500391]][D[500432]]();
  } else b1P1[D[500409]] = ![], window['b1STP1'](D[500769] + p_hvr2[D[500447]]);
}, window['b1STP'] = function (k68dl) {
  sendApi(b1P1[D[500573]], D[500770], { 'partner_id': b1P1[D[500581]], 'uid': b1P1[D[500018]], 'version': b1P1[D[500079]], 'game_pkg': b1P1[D[500021]], 'device': b1P1[D[500582]] }, b1SPT, b1T1P, b11S);
}, window['b1SPT'] = function (h1vcp) {
  b1P1[D[500440]] = ![];if (h1vcp[D[500447]] === D[500446] && h1vcp[D[500448]]) {
    for (var vr_h29 = 0x0; vr_h29 < h1vcp[D[500448]][D[500009]]; vr_h29++) {
      h1vcp[D[500448]][vr_h29][D[500425]] = b1PTS(h1vcp[D[500448]][vr_h29]);
    }b1P1[D[500438]][-0x1] = window[D[500771]](h1vcp[D[500448]]), window[D[500391]][D[500439]](-0x1);
  } else window['b1STP1'](D[500772] + h1vcp[D[500447]]);
}, window[D[500773]] = function (yt1z) {
  sendApi(b1P1[D[500573]], D[500770], { 'partner_id': b1P1[D[500581]], 'uid': b1P1[D[500018]], 'version': b1P1[D[500079]], 'game_pkg': b1P1[D[500021]], 'device': b1P1[D[500582]] }, yt1z, b1T1P, b11S);
}, window['b1TSP'] = function (mzyut, i0yuz) {
  sendApi(b1P1[D[500573]], D[500774], { 'partner_id': b1P1[D[500581]], 'uid': b1P1[D[500018]], 'version': b1P1[D[500079]], 'game_pkg': b1P1[D[500021]], 'device': b1P1[D[500582]], 'server_group_id': i0yuz }, b1TPS, b1T1P, b11S);
}, window['b1TPS'] = function (uitmy) {
  b1P1[D[500440]] = ![];if (uitmy[D[500447]] === D[500446] && uitmy[D[500448]] && uitmy[D[500448]][D[500448]]) {
    var cy1tm = uitmy[D[500448]][D[500775]],
        nj045i = [];for (var p_wv = 0x0; p_wv < uitmy[D[500448]][D[500448]][D[500009]]; p_wv++) {
      uitmy[D[500448]][D[500448]][p_wv][D[500425]] = b1PTS(uitmy[D[500448]][D[500448]][p_wv]), (nj045i[D[500009]] == 0x0 || uitmy[D[500448]][D[500448]][p_wv][D[500425]] != 0x0) && (nj045i[nj045i[D[500009]]] = uitmy[D[500448]][D[500448]][p_wv]);
    }b1P1[D[500438]][cy1tm] = window[D[500771]](nj045i), window[D[500391]][D[500439]](cy1tm);
  } else window['b1STP1'](D[500776] + uitmy[D[500447]]);
}, window['b17T1P'] = function (_pvhw) {
  sendApi(b1P1[D[500573]], D[500777], { 'partner_id': b1P1[D[500581]], 'uid': b1P1[D[500018]], 'version': b1P1[D[500079]], 'game_pkg': b1P1[D[500021]], 'device': b1P1[D[500582]] }, reqServerRecommendCallBack, b1T1P, b11S);
}, window[D[500778]] = function (r2p) {
  b1P1[D[500440]] = ![];if (r2p[D[500447]] === D[500446] && r2p[D[500448]]) {
    for (var d6so98 = 0x0; d6so98 < r2p[D[500448]][D[500009]]; d6so98++) {
      r2p[D[500448]][d6so98][D[500425]] = b1PTS(r2p[D[500448]][d6so98]);
    }b1P1[D[500438]][-0x2] = window[D[500771]](r2p[D[500448]]), window[D[500391]][D[500439]](-0x2);
  } else alert(D[500779] + r2p[D[500447]]);
}, window[D[500771]] = function (ol6dk) {
  if (!ol6dk && ol6dk[D[500009]] <= 0x0) return ol6dk;for (let s_982 = 0x0; s_982 < ol6dk[D[500009]]; s_982++) {
    ol6dk[s_982][D[500780]] && ol6dk[s_982][D[500780]] == 0x1 && (ol6dk[s_982][D[500426]] += D[500781]);
  }return ol6dk;
}, window['b1PST'] = function (olx76, _1wpvh) {
  olx76 = olx76 || b1P1[D[500022]][D[500023]], sendApi(b1P1[D[500573]], D[500782], { 'type': '4', 'game_pkg': b1P1[D[500021]], 'server_id': olx76 }, _1wpvh);
}, window[D[500783]] = function (r9s_82, ld68ko, qok7x, n5i0j) {
  qok7x = qok7x || b1P1[D[500022]][D[500023]], sendApi(b1P1[D[500573]], D[500784], { 'type': r9s_82, 'game_pkg': ld68ko, 'server_id': qok7x }, n5i0j);
}, window['b1PTS'] = function (ld8s6o) {
  if (ld8s6o) {
    if (ld8s6o[D[500425]] == 0x1) {
      if (ld8s6o[D[500785]] == 0x1) return 0x2;else return 0x1;
    } else return ld8s6o[D[500425]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['b11STP'] = function (nj40$, lqk7xg) {
  b1P1[D[500786]] = { 'step': nj40$, 'server_id': lqk7xg };var _p1wvh = this;b1SPT1({ 'title': D[500787] }), sendApi(b1P1[D[500573]], D[500788], { 'partner_id': b1P1[D[500581]], 'uid': b1P1[D[500018]], 'game_pkg': b1P1[D[500021]], 'server_id': lqk7xg, 'platform': b1P1[D[500083]], 'platform_uid': b1P1[D[500676]], 'check_login_time': b1P1[D[500679]], 'check_login_sign': b1P1[D[500677]], 'version_name': b1P1[D[500649]] }, b11SPT, b1T1P, b11S, function (twczm1) {
    return twczm1[D[500447]] == D[500446] || twczm1[D[500000]] == D[500789] || twczm1[D[500000]] == D[500790];
  });
}, window['b11SPT'] = function (af5$) {
  var zyun0i = this;if (af5$[D[500447]] === D[500446] && af5$[D[500448]]) {
    var o6kldx = b1P1[D[500022]];o6kldx[D[500791]] = b1P1[D[500584]], o6kldx[D[500678]] = String(af5$[D[500448]][D[500792]]), o6kldx[D[500590]] = parseInt(af5$[D[500448]][D[500680]]);if (af5$[D[500448]][D[500793]]) o6kldx[D[500793]] = parseInt(af5$[D[500448]][D[500793]]);else o6kldx[D[500793]] = parseInt(af5$[D[500448]][D[500023]]);o6kldx[D[500794]] = 0x0, o6kldx[D[500020]] = b1P1[D[500698]], o6kldx[D[500795]] = af5$[D[500448]][D[500796]], o6kldx[D[500797]] = af5$[D[500448]][D[500797]], console[D[500041]](D[500798] + JSON[D[500026]](o6kldx[D[500797]])), b1P1[D[500524]] == 0x1 && o6kldx[D[500797]] && o6kldx[D[500797]][D[500799]] == 0x1 && (b1P1[D[500348]] = 0x1, window[D[500034]][D[500035]]['b171P']()), b11TSP();
  } else b1P1[D[500786]][D[500800]] >= 0x3 ? (b11S(JSON[D[500026]](af5$)), window['b1STP1'](D[500801] + af5$[D[500447]])) : sendApi(b1P1[D[500573]], D[500661], { 'platform': b1P1[D[500571]], 'partner_id': b1P1[D[500581]], 'token': b1P1[D[500659]], 'game_pkg': b1P1[D[500021]], 'deviceId': b1P1[D[500582]], 'scene': D[500662] + b1P1[D[500583]] }, function (zi0y) {
    if (!zi0y || zi0y[D[500447]] != D[500446]) {
      window['b1STP1'](D[500674] + zi0y && zi0y[D[500447]]);return;
    }b1P1[D[500677]] = String(zi0y[D[500678]]), b1P1[D[500679]] = String(zi0y[D[500680]]), setTimeout(function () {
      b11STP(b1P1[D[500786]][D[500800]] + 0x1, b1P1[D[500786]][D[500023]]);
    }, 0x5dc);
  }, b1T1P, b11S, function (jni450) {
    return jni450[D[500447]] == D[500446] || jni450[D[500447]] == D[500802];
  });
}, window['b11TSP'] = function () {
  ServerLoading[D[500035]][D[500519]](b1P1[D[500524]]), window['b1T1'] = !![], window['b11PST']();
}, window['b11TPS'] = function () {
  if (window['b11T'] && window['b1PT1'] && window[D[500515]] && window[D[500518]] && window['b1P1T'] && window['b1PT']) {
    if (!window[D[500803]][D[500035]]) {
      console[D[500041]](D[500804] + window[D[500803]][D[500035]]);var tcuyzm = wx[D[500805]](),
          cw1vp = tcuyzm[D[500137]] ? tcuyzm[D[500137]] : 0x0,
          zimu0 = { 'cdn': window['b1P1'][D[500020]], 'spareCdn': window['b1P1'][D[500647]], 'newRegister': window['b1P1'][D[500524]], 'wxPC': window['b1P1'][D[500112]], 'wxIOS': window['b1P1'][D[500106]], 'wxAndroid': window['b1P1'][D[500109]], 'wxParam': { 'limitLoad': window['b1P1']['b17ST1P'], 'benchmarkLevel': window['b1P1']['b17SPT1'], 'wxFrom': window[D[500005]][D[500654]] == D[500806] ? 0x1 : 0x0, 'wxSDKVersion': window[D[500039]] }, 'configType': window['b1P1'][D[500591]], 'exposeType': window['b1P1'][D[500593]], 'scene': cw1vp };new window[D[500803]](zimu0, window['b1P1'][D[500019]], window['b17STP1']);
    }
  }
}, window['b11PST'] = function () {
  if (window['b11T'] && window['b1PT1'] && window[D[500515]] && window[D[500518]] && window['b1P1T'] && window['b1PT'] && window['b1T1'] && window['b1TP']) {
    b1SP1T();if (!b11TP) {
      b11TP = !![];if (!window[D[500803]][D[500035]]) window['b11TPS']();var $n4aj5 = 0x0,
          lok86d = wx[D[500807]]();lok86d && (window['b1P1'][D[500111]] && ($n4aj5 = lok86d[D[500101]]), console[D[500000]](D[500808] + lok86d[D[500101]] + D[500809] + lok86d[D[500102]] + D[500810] + lok86d[D[500103]] + D[500811] + lok86d[D[500104]] + D[500812] + lok86d[D[500311]] + D[500813] + lok86d[D[500313]]));var uym0z = {};for (const izuny in b1P1[D[500022]]) {
        uym0z[izuny] = b1P1[D[500022]][izuny];
      }var _hw1pv = { 'channel': window['b1P1'][D[500585]], 'account': window['b1P1'][D[500018]], 'userId': window['b1P1'][D[500675]], 'cdn': window['b1P1'][D[500020]], 'data': window['b1P1'][D[500448]], 'package': window['b1P1'][D[500570]], 'newRegister': window['b1P1'][D[500524]], 'pkgName': window['b1P1'][D[500021]], 'partnerId': window['b1P1'][D[500581]], 'platform_uid': window['b1P1'][D[500676]], 'deviceId': window['b1P1'][D[500582]], 'selectedServer': uym0z, 'configType': window['b1P1'][D[500591]], 'exposeType': window['b1P1'][D[500593]], 'debugUsers': window['b1P1'][D[500588]], 'wxMenuTop': $n4aj5, 'wxShield': window['b1P1'][D[500594]] };if (window[D[500701]]) for (var vwh2 in window[D[500701]]) {
        _hw1pv[vwh2] = window[D[500701]][vwh2];
      }window[D[500803]][D[500035]]['b11P7'](_hw1pv);
    }
  } else console[D[500000]](D[500814] + window['b11T'] + D[500815] + window['b1PT1'] + D[500816] + window[D[500515]] + D[500817] + window[D[500518]] + D[500818] + window['b1P1T'] + D[500819] + window['b1PT'] + D[500820] + window['b1T1'] + D[500821] + window['b1TP']);
};