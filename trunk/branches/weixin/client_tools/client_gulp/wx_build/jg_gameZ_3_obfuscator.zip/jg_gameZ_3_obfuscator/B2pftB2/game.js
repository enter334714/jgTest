var D = wx.$b;
require('BBFBB.js'), window[D[501270]][D[501251]][D[500916]] = null, window['client_pb'] = require('BBIENBB.js'), window[D[501784]] = window[D[501270]][D[501101]][D[500967]](client_pb);