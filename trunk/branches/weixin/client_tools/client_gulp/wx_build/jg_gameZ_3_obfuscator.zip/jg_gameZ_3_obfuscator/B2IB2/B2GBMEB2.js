var D = wx.$b;
console[D[500000]](D[500001]), window[D[500002]], wx[D[500003]](function (s69do8) {
  if (s69do8) {
    if (s69do8[D[500004]]) {
      var e$54fa = window[D[500005]][D[500006]][D[500007]](new RegExp(/\./, 'g'), '_'),
          n54i0j = s69do8[D[500004]],
          ucytz = n54i0j[D[500008]](/(BBBBB\/B2GBMEB2.js:)[0-9]{1,60}(:)/g);if (ucytz) for (var $jn045 = 0x0; $jn045 < ucytz[D[500009]]; $jn045++) {
        if (ucytz[$jn045] && ucytz[$jn045][D[500009]] > 0x0) {
          var lo76x = parseInt(ucytz[$jn045][D[500007]](D[500010], '')[D[500007]](':', ''));n54i0j = n54i0j[D[500007]](ucytz[$jn045], ucytz[$jn045][D[500007]](':' + lo76x + ':', ':' + (lo76x - 0x2) + ':'));
        }
      }n54i0j = n54i0j[D[500007]](new RegExp(D[500011], 'g'), D[500012] + e$54fa + D[500013]), n54i0j = n54i0j[D[500007]](new RegExp(D[500014], 'g'), D[500012] + e$54fa + D[500013]), s69do8[D[500004]] = n54i0j;
    }var wpt1cm = { 'id': window['b1P1'][D[500015]], 'role': window['b1P1'][D[500016]], 'level': window['b1P1'][D[500017]], 'user': window['b1P1'][D[500018]], 'version': window['b1P1'][D[500019]], 'cdn': window['b1P1'][D[500020]], 'pkgName': window['b1P1'][D[500021]], 'gamever': window[D[500005]][D[500006]], 'serverid': window['b1P1'][D[500022]] ? window['b1P1'][D[500022]][D[500023]] : 0x0, 'systemInfo': window[D[500024]], 'error': D[500025], 'stack': s69do8 ? s69do8[D[500004]] : '' },
        pwhv2_ = JSON[D[500026]](wpt1cm);console[D[500027]](D[500028] + pwhv2_), (!window[D[500002]] || window[D[500002]] != wpt1cm[D[500027]]) && (window[D[500002]] = wpt1cm[D[500027]], window['b1SP'](wpt1cm));
  }
});import 'BBbfBB.js';import 'BB11BB.js';window[D[500029]] = require(D[500030]);import 'BINDBB.js';import 'BBIB1BB.js';import 'BBMtadBB.js';import 'BBINIBaB.js';console[D[500000]](D[500031]), console[D[500000]](D[500032]), b1SPT1({ 'title': D[500033] });var bj$4fa5 = { 'b17S1PT': !![] };new window[D[500034]](bj$4fa5), window[D[500034]][D[500035]]['b17TP1S']();if (window['b17SP1T']) clearInterval(window['b17SP1T']);window['b17SP1T'] = null, window['b17T1SP'] = function (w_vh, ui04) {
  if (!w_vh || !ui04) return 0x0;w_vh = w_vh[D[500036]]('.'), ui04 = ui04[D[500036]]('.');const nj45i = Math[D[500037]](w_vh[D[500009]], ui04[D[500009]]);while (w_vh[D[500009]] < nj45i) {
    w_vh[D[500038]]('0');
  }while (ui04[D[500009]] < nj45i) {
    ui04[D[500038]]('0');
  }for (var izymt = 0x0; izymt < nj45i; izymt++) {
    const utczm = parseInt(w_vh[izymt]),
          tcwmp = parseInt(ui04[izymt]);if (utczm > tcwmp) return 0x1;else {
      if (utczm < tcwmp) return -0x1;
    }
  }return 0x0;
}, window[D[500039]] = wx[D[500040]]()[D[500039]], console[D[500041]](D[500042] + window[D[500039]]);var bs68d9o = wx[D[500043]]();bs68d9o[D[500044]](function (o68l) {
  console[D[500041]](D[500045] + o68l[D[500046]]);
}), bs68d9o[D[500047]](function () {
  wx[D[500048]]({ 'title': D[500049], 'content': D[500050], 'showCancel': ![], 'success': function (ymzi0u) {
      bs68d9o[D[500051]]();
    } });
}), bs68d9o[D[500052]](function () {
  console[D[500041]](D[500053]);
}), window['b17T1PS'] = function () {
  console[D[500041]](D[500054]);var r9sh_ = wx[D[500055]]({ 'name': D[500056], 'success': function (ytmziu) {
      console[D[500041]](D[500057]), console[D[500041]](ytmziu), ytmziu && ytmziu[D[500058]] == D[500059] ? (window['b11T'] = !![], window['b11TPS'](), window['b11PST']()) : setTimeout(function () {
        window['b17T1PS']();
      }, 0x1f4);
    }, 'fail': function (k6ldxo) {
      console[D[500041]](D[500060]), console[D[500041]](k6ldxo), setTimeout(function () {
        window['b17T1PS']();
      }, 0x1f4);
    } });r9sh_ && r9sh_[D[500061]](cuyzmt => {});
}, window['b17PS1T'] = function () {
  console[D[500041]](D[500062]);var pvrh = wx[D[500055]]({ 'name': D[500063], 'success': function (tw1cmp) {
      console[D[500041]](D[500064]), console[D[500041]](tw1cmp), tw1cmp && tw1cmp[D[500058]] == D[500059] ? (window['b1PT1'] = !![], window['b11TPS'](), window['b11PST']()) : setTimeout(function () {
        window['b17PS1T']();
      }, 0x1f4);
    }, 'fail': function (v_pr) {
      console[D[500041]](D[500065]), console[D[500041]](v_pr), setTimeout(function () {
        window['b17PS1T']();
      }, 0x1f4);
    } });pvrh && pvrh[D[500061]](n45j$0 => {});
}, window[D[500066]] = function () {
  window['b17T1SP'](window[D[500039]], D[500067]) >= 0x0 ? (console[D[500041]](D[500068] + window[D[500039]] + D[500069]), window['b1PS'](), window['b17T1PS'](), window['b17PS1T']()) : (window['b1P1S'](D[500070], window[D[500039]]), wx[D[500048]]({ 'title': D[500071], 'content': D[500072] }));
}, window[D[500024]] = '', wx[D[500073]]({ 'success'(jaf$) {
    window[D[500024]] = D[500074] + jaf$[D[500075]] + D[500076] + jaf$[D[500077]] + D[500078] + jaf$[D[500079]] + D[500080] + jaf$[D[500081]] + D[500082] + jaf$[D[500083]] + D[500084] + jaf$[D[500039]] + D[500085] + jaf$[D[500086]], console[D[500041]](window[D[500024]]), console[D[500041]](D[500087] + jaf$[D[500088]] + D[500089] + jaf$[D[500090]] + D[500091] + jaf$[D[500092]] + D[500093] + jaf$[D[500094]] + D[500095] + jaf$[D[500096]] + D[500097] + jaf$[D[500098]] + D[500099] + (jaf$[D[500100]] ? jaf$[D[500100]][D[500101]] + ',' + jaf$[D[500100]][D[500102]] + ',' + jaf$[D[500100]][D[500103]] + ',' + jaf$[D[500100]][D[500104]] : ''));var _h29s = jaf$[D[500081]] ? jaf$[D[500081]][D[500105]]() : '',
        ds8r6 = jaf$[D[500077]] ? jaf$[D[500077]][D[500105]]()[D[500007]]('\x20', '') : '';window['b1P1'][D[500106]] = _h29s[D[500107]](D[500108]) != -0x1, window['b1P1'][D[500109]] = _h29s[D[500107]](D[500110]) != -0x1, window['b1P1'][D[500111]] = _h29s[D[500107]](D[500108]) != -0x1 || _h29s[D[500107]](D[500110]) != -0x1, window['b1P1'][D[500112]] = _h29s[D[500107]](D[500113]) != -0x1 || _h29s[D[500107]](D[500114]) != -0x1, window['b1P1'][D[500115]] = jaf$[D[500083]] ? jaf$[D[500083]][D[500105]]() : '', window['b1P1']['b17ST1P'] = ![], window['b1P1']['b17SPT1'] = 0x2;if (_h29s[D[500107]](D[500110]) != -0x1) {
      if (jaf$[D[500086]] >= 0x18) window['b1P1']['b17SPT1'] = 0x3;else window['b1P1']['b17SPT1'] = 0x2;
    } else {
      if (_h29s[D[500107]](D[500108]) != -0x1) {
        if (jaf$[D[500086]] && jaf$[D[500086]] >= 0x14) window['b1P1']['b17SPT1'] = 0x3;else {
          if (ds8r6[D[500107]](D[500116]) != -0x1 || ds8r6[D[500107]](D[500117]) != -0x1 || ds8r6[D[500107]](D[500118]) != -0x1 || ds8r6[D[500107]](D[500119]) != -0x1 || ds8r6[D[500107]](D[500120]) != -0x1) window['b1P1']['b17SPT1'] = 0x2;else window['b1P1']['b17SPT1'] = 0x3;
        }
      } else window['b1P1']['b17SPT1'] = 0x2;
    }console[D[500041]](D[500121] + window['b1P1']['b17ST1P'] + D[500122] + window['b1P1']['b17SPT1']);
  } }), wx[D[500123]]({ 'success': function (izun0y) {
    console[D[500041]](D[500124] + izun0y[D[500125]] + D[500126] + izun0y[D[500127]]);
  } }), wx[D[500128]]({ 'success': function (v_hp1) {
    console[D[500041]](D[500129] + v_hp1[D[500130]]);
  } }), wx[D[500131]]({ 'keepScreenOn': !![] }), wx[D[500132]](function (v1cwtp) {
  console[D[500041]](D[500129] + v1cwtp[D[500130]] + D[500133] + v1cwtp[D[500134]]);
}), wx[D[500135]](function (x37gkq) {
  window['b1TS'] = x37gkq, window['b11ST'] && window['b1TS'] && (console[D[500000]](D[500136] + window['b1TS'][D[500137]]), window['b11ST'](window['b1TS']), window['b1TS'] = null);
}), window[D[500138]] = 0x0, window['b17PT1S'] = 0x0, window[D[500139]] = null, wx[D[500140]](function () {
  window['b17PT1S']++;var $jn405 = Date[D[500141]]();(window[D[500138]] == 0x0 || $jn405 - window[D[500138]] > 0x1d4c0) && (console[D[500142]](D[500143]), wx[D[500144]]());if (window['b17PT1S'] >= 0x2) {
    window['b17PT1S'] = 0x0, console[D[500027]](D[500145]), wx[D[500146]]('0', 0x1);if (window['b1P1'] && window['b1P1'][D[500106]]) window['b1P1S'](D[500147], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});