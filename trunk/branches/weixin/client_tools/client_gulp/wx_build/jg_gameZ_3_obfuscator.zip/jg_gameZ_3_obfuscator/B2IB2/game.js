var D = wx.$b;
require(D[500822]);