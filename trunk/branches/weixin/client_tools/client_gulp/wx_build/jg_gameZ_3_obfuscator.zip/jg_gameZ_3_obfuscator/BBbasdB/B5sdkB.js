var D = wx.$b;

import test from "../untils/ddtSDKPlat.js";
var config = {
    game_id: D[500823],
    game_pkg: D[500824],
    partner_label: D[500825],
    partner_id: D[500826],
    game_ver: D[500827], //666-绝地蛮荒
    platId: 1000,
    gameId: 272,
    channelVer: D[500828],
    mode: 2,
    is_auth: true //授权登录
};
window.config = config;
var b17P1ST = b171TSP();
var HOST = D[500829];
var b17P1TS = null;
var b171STP = null;
var partner_data = {};

function b171TSP() {
    var callbacks = {};
    return {
        order_data: {},
        init: function (ops, callback) {
            var game_ver = ops && ops.game_ver ? ops.game_ver : 0;
            console.log(D[500830]);
            var self = this;
            var uuid = wx.getStorageSync(D[500831]);
            var is_new;
            if (!uuid) {
                uuid = self.uuid(16, 32);
                wx.setStorageSync(D[500831], uuid);
                is_new = 1;
            } else {
                is_new = 0;
            }
            var idfv = wx.getStorageSync(D[500832]);
            if (!idfv) {
                idfv = self.uuid(16, 32);
                wx.setStorageSync(D[500832], idfv);
            }

            var info = wx.getLaunchOptionsSync();
            var scene = info.scene ? info.scene : '';

            //判断今天是否已经上报过
            if (is_new && info.query && info.query.ad_code) {
                wx.setStorageSync(D[500833], info.query.ad_code);
            }

            var data = {
                install: is_new,
                scene: scene
            };
            self.log(D[500834], data);
            //TODO 替换对应参数
            var sdkCallback = function (code, data) {
                switch (code) {
                    case D[500835]:
                        // 初始化成功
                        console.log(D[500836], code, data);
                        break;
                    case D[500837]:
                        // 初始化失败
                        console.log(D[500838], code, data);
                        break;
                    case D[500839]:
                        // 登录成功
                        console.log(D[500840], code, data);
                        self.do_login(data);
                        // 登录成功后会返回uname、gameToken、time、sign；CP拿这几个字段进行登录校验
                        break;
                    case D[500841]:
                        //登录失败
                        console.log(D[500842], code, data);
                        callbacks[D[500657]] && callbacks[D[500657]](1, {
                            errMsg: data.msg
                        });
                        break;
                    case D[500843]:
                        // 支付成功（支付以服务端返回为准）
                        console.log(D[500844], code, data);
                        break;
                    case D[500845]:
                        // 支付失败
                        console.log(D[500846], code, data);
                        callbacks[D[500711]] && callbacks[D[500711]](1, {
                            errMsg: data.errMsg
                        });
                        break;
                }
            };

            ddtSDKPlat.init({
                platId: config.platId,
                gameId: config.gameId,
                channelVer: config.channelVer,
                mode: config.mode
            }, sdkCallback, true);

            wx.showShareMenu({ withShareTicket: true });

            console.log(D[500847] + ddtSDKPlat.version);

            //玩家是分享过来的，单独上报给服务器
            var invite = info.query && info.query.invite ? info.query.invite : '';
            var invite_type = info.query && info.query.invite_type ? info.query.invite_type : '';

            if (invite) {
                b171STP = {
                    invite: invite,
                    invite_type: invite_type,
                    is_new: is_new,
                    scene: scene
                };
            }

            //判断版本号
            if (game_ver) {
                this.checkGameVersion(game_ver, function (data) {
                    callback && callback(data);
                });
            }
        },

        login: function (data, callback) {
            console.log(D[500848]);
            callbacks[D[500657]] = typeof callback == D[500849] ? callback : null;
        },

        do_login: function (info) {
            var self = this;
            partner_data = {
                uid: info.uid,
                gameToken: info.gameToken,
                time: info.time,
                sign: info.sign
            };
            var public_data = self.getPublicData();
            public_data[D[500850]] = 1;
            public_data[D[500851]] = JSON.stringify(partner_data);
            if (b171STP && typeof b171STP == D[500852]) {
                for (var key in b171STP) {
                    public_data[key] = b171STP[key];
                }
            }

            //发起网络请求
            wx.request({
                url: D[500853] + HOST + D[500854],
                method: D[500625],
                dataType: D[500855],
                header: {
                    'content-type': D[500763] // 默认值
                },
                data: public_data,
                success: function (res) {
                    console.log(D[500856]);
                    console.log(res);
                    if (res.statusCode === 200) {
                        var data = res.data;
                        if (data.state) {
                            try {
                                wx.setStorageSync(D[500857], data.data.sdk_token);
                                wx.setStorageSync(D[500858], data.data.user_id);
                                wx.setStorageSync(D[500859], data.data.username);
                                if (data.data.ext) {
                                    wx.setStorageSync(D[500860], data.data.ext);
                                }
                            } catch (e) {}
                            var userData = {
                                userid: data.data.user_id,
                                account: data.data.nick_name,
                                token: data.data.token,
                                invite_uid: data.data.invite_uid || '',
                                invite_nickname: data.data.invite_nickname || '',
                                invite_head_img: data.data.invite_head_img || '',
                                head_img: data.data.head_img || '',
                                is_client: data.data.is_client || '0',
                                ios_pay: data.data.ios_pay || '0'
                            };
                            callbacks[D[500657]] && callbacks[D[500657]](0, userData);
                        } else {
                            callbacks[D[500657]] && callbacks[D[500657]](1, {
                                errMsg: data.msg
                            });
                        }

                        //登录成功，加载右上角分享数据
                        self.getShareInfo(D[500861], function (data) {
                            console.log(D[500862]);
                            wx.onShareAppMessage(function () {
                                //记录开始分享
                                self.logStartShare(D[500861]);
                                return {
                                    title: data.title,
                                    imageUrl: data.img,
                                    query: data.query
                                };
                            });
                        });
                    } else {
                        callbacks[D[500657]] && callbacks[D[500657]](1, {
                            errMsg: D[500863]
                        });
                    }
                }
            });
        },

        share: function (data) {
            callbacks[D[500724]] = typeof callback == D[500849] ? callback : null;
            var type = data.type || D[500724];
            console.log(D[500864] + type);
            var self = this;

            this.getShareInfo(type, function (data) {

                //记录开始分享
                self.logStartShare(type);
                wx.shareAppMessage({
                    title: data.title,
                    imageUrl: data.img,
                    query: data.query
                });
            });
        },

        logStartShare: function (type) {
            var sdk_token = wx.getStorageSync(D[500857]);
            wx.request({
                url: D[500853] + HOST + D[500865],
                method: D[500625],
                dataType: D[500855],
                header: {
                    'content-type': D[500763] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    sdk_token: sdk_token,
                    server_id: b17P1TS ? b17P1TS.server_id : '',
                    role_id: b17P1TS ? b17P1TS.role_id : '',
                    type: type
                },
                success: function (res) {}
            });
        },

        openService: function () {
            wx.openCustomerServiceConversation();
        },

        checkGameVersion: function (game_ver, callback) {
            console.log(D[500866]);
            var sdk_token = wx.getStorageSync(D[500857]);
            wx.request({
                url: D[500853] + HOST + D[500867],
                method: D[500625],
                dataType: D[500855],
                header: {
                    'content-type': D[500763] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    game_ver: game_ver
                },
                success: function (res) {
                    console.log(D[500868]);
                    console.log(res);
                    if (res.statusCode == 200) {
                        var data = res.data;
                        if (data.state) {
                            callback && callback(data.data);
                        } else {
                            callback && callback({
                                develop: 0
                            });
                        }
                    } else {
                        callback && callback({
                            develop: 0
                        });
                    }
                }
            });
        },

        getShareInfo: function (type, callback) {
            console.log(D[500869]);
            var sdk_token = wx.getStorageSync(D[500857]);
            wx.request({
                url: D[500853] + HOST + D[500870],
                method: D[500625],
                dataType: D[500855],
                header: {
                    'content-type': D[500763] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    sdk_token: sdk_token,
                    type: type,
                    server_id: b17P1TS ? b17P1TS.server_id : '',
                    role_id: b17P1TS ? b17P1TS.role_id : '',
                    no_log: 1 //设置为1后就不在这个接口打log，交给logStartShare接口
                },
                success: function (res) {
                    console.log(D[500871]);
                    console.log(res);
                    if (res.statusCode == 200) {
                        var data = res.data;
                        if (data.state) {
                            callback && callback(data.data);
                        } else {
                            callbacks[D[500724]] && callbacks[D[500724]](1, {
                                errMsg: D[500872] + data.msg
                            });
                        }
                    } else {
                        callbacks[D[500724]] && callbacks[D[500724]](1, {
                            errMsg: D[500873]
                        });
                    }
                }
            });
        },

        updateShare: function (invite, invite_type, is_new, role_id, server_id, scene) {
            console.log(D[500874]);
            var sdk_token = wx.getStorageSync(D[500857]);
            wx.request({
                url: D[500853] + HOST + D[500875],
                method: D[500625],
                dataType: D[500855],
                header: {
                    'content-type': D[500763] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    sdk_token: sdk_token,
                    invite: invite,
                    invite_type: invite_type,
                    is_new: is_new,
                    role_id: role_id,
                    sever_id: server_id,
                    scene: scene
                },
                success: function (res) {
                    console.log(D[500876]);
                    console.log(res);
                }
            });
        },

        msgCheck: function (content, callback) {
            console.log(D[500877]);
            var sdk_token = wx.getStorageSync(D[500857]);
            wx.request({
                url: D[500853] + HOST + D[500878] + config.partner_id + '/' + config.game_pkg,
                method: D[500625],
                dataType: D[500855],
                header: {
                    'content-type': D[500763] // 默认值
                },
                data: {
                    game_pkg: config.game_pkg,
                    partner_id: config.partner_id,
                    sdk_token: sdk_token,
                    content: content,
                    gameToken: partner_data.gameToken,
                    uid: partner_data.uid,
                    channelVer: config.channelVer,
                    gameId: config.gameId,
                    platId: config.platId
                },
                success: function (res) {
                    console.log(D[500879]);
                    console.log(res);
                    callback && callback(res);
                }
            });
        },

        pay: function (data, callback) {
            var self = this;
            self.startPay(data, callback);
        },

        //支付接口
        startPay: function (data, callback) {
            console.log(D[500880]);
            console.log(data);

            var self = this;
            callbacks[D[500711]] = typeof callback == D[500849] ? callback : null;
            //先下单
            var sdk_token = wx.getStorageSync(D[500857]);
            var session_key = wx.getStorageSync(D[500860]);
            if (!sdk_token && !session_key) {
                callbacks[D[500711]] && callbacks[D[500711]](1, {
                    errMsg: D[500881]
                });
                return;
            }

            var sysInfo = wx.getSystemInfoSync();

            var order_data = {
                cpbill: data.cpbill,
                productid: data.productid,
                productname: data.productname,
                productdesc: data.productdesc,
                serverid: data.serverid,
                servername: data.servername,
                roleid: data.roleid,
                rolename: data.rolename,
                rolelevel: data.rolelevel,
                price: data.price,
                extension: data.extension,
                sdk_token: sdk_token,
                session_key: session_key,
                platform: sysInfo.platform
            };
            self.order_data = order_data;

            var public_data = self.getPublicData();
            public_data[D[500882]] = JSON.stringify(order_data);
            public_data[D[500850]] = 1;

            //发起网络请求
            wx.request({
                url: D[500853] + HOST + D[500883],
                method: D[500625],
                dataType: D[500855],
                header: {
                    'content-type': D[500763] // 默认值
                },
                data: public_data,
                success: function (res) {
                    console.log(D[500884]);
                    console.log(res);
                    if (res.statusCode == 200) {
                        var data = res.data;
                        if (data.state && data.data.pay_data) {
                            //TODO 替换对应方法
                            console.log(D[500885] + JSON.stringify(data.data.pay_data));
                            var payInfo = {
                                billNo: data.data.pay_data.billNo,
                                amount: data.data.pay_data.amount,
                                serverId: data.data.pay_data.serverId,
                                roleId: data.data.pay_data.roleId,
                                roleName: data.data.pay_data.roleName,
                                roleLevel: data.data.pay_data.roleLevel,
                                subject: data.data.pay_data.subject,
                                productDesc: data.data.pay_data.productDesc,
                                extraInfo: data.data.pay_data.extraInfo
                            };
                            ddtSDKPlat.pay(payInfo);
                        } else {
                            callbacks[D[500711]] && callbacks[D[500711]](1, {
                                errMsg: data.errMsg
                            });
                        }
                    } else {
                        callbacks[D[500657]] && callbacks[D[500657]](1, {
                            errMsg: D[500863]
                        });
                    }
                }
            });
        },

        logCreateRole: function (data) {
            var uid = wx.getStorageSync(D[500858]);
            var username = wx.getStorageSync(D[500859]);

            var postData = {};
            postData[D[500886]] = uid;
            postData[D[500887]] = username;
            postData[D[500888]] = data.roleid;
            postData[D[500889]] = data.rolelevel;
            postData[D[500890]] = data.rolename;
            postData[D[500023]] = data.serverid;

            if (data.roleid && data.serverid) {
                b17P1TS = {
                    role_id: data.roleid,
                    server_id: data.serverid
                };
            }
            this.log(D[500154], postData);
            var roleInfo = {
                roleLevel: data.rolelevel + '',
                roleId: data.roleid + '',
                roleName: data.rolename,
                serverName: data.servername,
                serverId: data.serverid + ''
            };

            ddtSDKPlat.submitData(D[500891], roleInfo);
        },

        //进入游戏
        logEnterGame: function (data, callback) {
            var uid = wx.getStorageSync(D[500858]);
            var username = wx.getStorageSync(D[500859]);

            var postData = {};
            postData[D[500886]] = uid;
            postData[D[500887]] = username;
            postData[D[500888]] = data.roleid;
            postData[D[500889]] = data.rolelevel;
            postData[D[500890]] = data.rolename;
            postData[D[500023]] = data.serverid;

            if (data.roleid && data.serverid) {
                b17P1TS = {
                    role_id: data.roleid,
                    server_id: data.serverid
                };
            }

            this.log(D[500892], postData);

            var roleInfo = {
                roleLevel: data.rolelevel,
                roleId: data.roleid,
                roleName: data.rolename,
                serverName: data.servername,
                serverId: data.serverid

            };

            ddtSDKPlat.submitData(D[500893], roleInfo);

            //进入游戏确认邀请成功
            if (b171STP) {
                this.updateShare(b171STP.invite, b171STP.invite_type, b171STP.is_new, data.roleid, data.serverid, b171STP.scene);
            }
        },

        //角色升级
        logRoleUpLevel: function (data, callback) {
            var uid = wx.getStorageSync(D[500858]);
            var username = wx.getStorageSync(D[500859]);
            this.log(D[500894], data);

            var postData = {};
            postData[D[500886]] = uid;
            postData[D[500887]] = username;
            postData[D[500888]] = data.roleid;
            postData[D[500889]] = data.rolelevel;
            postData[D[500890]] = data.rolename;
            postData[D[500023]] = data.serverid;

            if (data.roleid && data.serverid) {
                b17P1TS = {
                    role_id: data.roleid,
                    server_id: data.serverid,
                    role_level: data.rolelevel,
                    role_createtime: data.rolecreatetime

                };
            }

            var roleInfo = {
                roleLevel: data.rolelevel,
                roleId: data.roleid,
                roleName: data.rolename,
                serverName: data.servername,
                serverId: data.serverid,
                rolecreatetime: data.rolecreatetime,
                vipLevel: "",
                power: "",
                roleSex: "",
                partyId: "",
                partyName: ""
            };

            ddtSDKPlat.submitData(D[500895], roleInfo);
        },

        subscribeMessage: function (tmplIds, callback) {
            console.log(D[500896] + tmplIds);
            //获取模板ID
            callbacks[D[500735]] = typeof callback == D[500849] ? callback : null;
            wx.requestSubscribeMessage({
                tmplIds: tmplIds,
                success(res) {
                    console.log(D[500897]);
                    console.log(res);
                    callbacks[D[500735]] && callbacks[D[500735]](res);
                },
                fail(res) {
                    console.log(D[500898]);
                    console.log(res);
                    callbacks[D[500735]] && callbacks[D[500735]](res);
                }
            });
        },
        // 微端小助手
        weiduanHelper: function () {
            console.log(D[500899]);
            ddtSDKPlat.jump();
            // var queryConfig={
            //     "channelVer" : config.channelVer,
            //     "gameId" : config.gameId, 
            //     "gameToken" :partner_data.gameToken , 
            //     "mode" :config.mode,
            //     "platId":config.platId,
            //     "roleId":user_game_info.role_id,
            //     "roleLevel":user_game_info.role_level,
            //     "rolecreatetime":user_game_info.role_createtime,
            //     "sceneId":'enterGame',
            //     "serverId":user_game_info.server_id,
            //     "time":Date.parse(new Date()),
            //     "uid":partner_data.uid,
            //     "sign":'',
            //     "partyId":'',
            //     "partyName":'',
            //     "power":'',
            //     "roleSex":'',
            //     "vipLevel":'',
            // };
            // var _str = "";
            // for(var o in queryConfig){
            //     if(queryConfig[o] != -1){
            //         _str += o + "=" + queryConfig[o] + "&";
            //     }
            // };
            //  _str = _str.substr(0, _str.length-1);
            // var sendMessagePath = _str;
            // wx.openCustomerServiceConversation({
            //     sessionFrom: 'turngame',
            //     showMessageCard:true,
            //     sendMessageTitle: '多梦江湖',
            //     sendMessagePath:sendMessagePath,
            //     sendMessageImg: '',
            //     success:function(res){
            //         console.log("weiduan helper success");
            //     },
            //     fail:function(res){
            //         console.log("weiduan helper fail");
            //     },
            //     complete:function(res){
            //         console.log("weiduan helper complete");
            //     }
            // })
        },

        //获取唯一设备码（自定义）
        uuid: function (radix, len) {
            var chars = D[500900].split('');
            var uuid = [],
                i;
            radix = radix || chars.length;

            if (len) {
                for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
            } else {
                var r;

                uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
                uuid[14] = '4';

                for (i = 0; i < 36; i++) {
                    if (!uuid[i]) {
                        r = 0 | Math.random() * 16;
                        uuid[i] = chars[i == 19 ? r & 0x3 | 0x8 : r];
                    }
                }
            }

            return uuid.join('');
        },

        //获取公共参数
        getPublicData: function () {
            var system = wx.getSystemInfoSync();
            var uuid = wx.getStorageSync(D[500831]);
            var idfv = wx.getStorageSync(D[500832]);
            var ad_code = wx.getStorageSync(D[500833]);

            return {
                game_id: config.game_id,
                game_pkg: config.game_pkg,
                partner_id: config.partner_id,
                partner_label: config.partner_label,
                ad_code: ad_code,
                uuid: uuid,
                idfv: idfv,
                dname: system.model,
                mac: D[500901],
                net_type: system.wifiSignal == 0 ? '4G' : D[500902],
                os_ver: system.system,
                sdk_ver: system.version, //存放的是微信版本号
                game_ver: config.game_ver, //存放的是SDK版本号
                device: system.platform == D[500110] ? 1 : 2
            };
        },

        //统一发送log
        log: function (type, data) {
            var public_data = this.getPublicData();
            for (var key in data) {
                public_data[key] = data[key];
            }

            console.log(D[500903] + type);
            console.log(public_data);

            wx.request({
                url: D[500853] + HOST + D[500904] + type + D[500905] + encodeURIComponent(JSON.stringify(public_data))
            });
        },

        getDate: function () {
            var date = new Date();
            return date.getFullYear() + '-' + date.getMonth() + '-' + date.getDate();
        },

        downloadClient: function () {
            wx.openCustomerServiceConversation();
        }
    };
}

function run(method, data, callback) {
    method in b17P1ST && b17P1ST[method](data, callback);
}

exports.init = function (data, callback) {
    run(D[500480], data, callback);
};

exports.login = function (callback) {
    run(D[500657], '', callback);
};

exports.pay = function (data, callback) {
    run(D[500711], data, callback);
};

exports.openService = function () {
    run(D[500725]);
};

exports.logCreateRole = function (serverId, serverName, roleId, roleName, roleLevel) {
    var data = {
        serverid: serverId,
        servername: serverName,
        roleid: roleId,
        rolename: roleName,
        rolelevel: roleLevel
    };
    run(D[500719], data);
};

exports.logEnterGame = function (serverId, serverName, roleId, roleName, roleLevel, rolecreatetime, callback) {
    var data = {
        serverid: serverId,
        servername: serverName,
        roleid: roleId,
        rolename: roleName,
        rolelevel: roleLevel,
        rolecreatetime: rolecreatetime
    };

    run(D[500721], data, callback);
};

exports.logRoleUpLevel = function (serverId, serverName, roleId, roleName, roleLevel, rolecreatetime, callback) {
    var data = {
        serverid: serverId,
        servername: serverName,
        roleid: roleId,
        rolename: roleName,
        rolelevel: roleLevel,
        rolecreatetime: rolecreatetime
    };
    run(D[500723], data, callback);
};

exports.share = function (type) {
    var data = {
        type: type
    };
    run(D[500724], data);
};
exports.subscribeMessage = function (data, callback) {
    run(D[500735], data, callback);
};

exports.msgCheck = function (data, callback) {
    run(D[500609], data, callback);
};

exports.downloadClient = function () {
    run(D[500906]);
};

exports.getConfig = function () {
    return {
        game_id: config.game_id,
        game_pkg: config.game_pkg,
        partner_id: config.partner_id
    };
};

exports.getPublicData = function () {
    run(D[500907]);
};
exports.weiduanHelper = function () {
    run(D[500727]);
};