var b = wx.$e;
function exlgit$() {}function evr4fyz(c7o_am, eocmpa, fz_yv4, a7pcom, rfvzyh) {
  function wb850(ixj) {
    if (ixj > 0xffff) {
      ixj -= 0x10000;var glti$ = 0xd800 + (ixj >> 0xa),
          fyhrlz = 0xdc00 + (0x3ff & ixj);return String['fromCharCode'](glti$, fyhrlz);
    }return String['fromCharCode'](ixj);
  }function $3qjix(ju3iq) {
    var ylhzr = ju3iq['slice'](0x1, -0x1);return ylhzr in fz_yv4 ? fz_yv4[ylhzr] : '#' === ylhzr['charAt'](0x0) ? wb850(parseInt(ylhzr['substr'](0x1)['replace']('x', '0x'))) : (rfvzyh['error']('entity not found:' + ju3iq), ju3iq);
  }function y4v_7(fhv) {
    if (fhv > kq9uns) {
      var fyzr4v = c7o_am['substring'](kq9uns, fhv)['replace'](/&#?\w+;/g, $3qjix);apmceo && qjn3s(kq9uns), a7pcom['characters'](fyzr4v, 0x0, fhv - kq9uns), kq9uns = fhv;
    }
  }function qjn3s($htlgx, zhfyrl) {
    for (; $htlgx >= inqu3j && (zhfyrl = fyrhzl['exec'](c7o_am));) jxti$g = zhfyrl['index'], inqu3j = jxti$g + zhfyrl[0x0]['length'], apmceo['lineNumber']++;apmceo['columnNumber'] = $htlgx - jxti$g + 0x1;
  }for (var jxti$g = 0x0, inqu3j = 0x0, fyrhzl = /.*(?:\r\n?|\n)|.*$/g, apmceo = a7pcom['locator'], nk96su = [{ 'currentNSMap': eocmpa }], vy = {}, kq9uns = 0x0;;) {
    try {
      var d8b065 = c7o_am['indexOf']('<', kq9uns);if (0x0 > d8b065) {
        if (!c7o_am['substr'](kq9uns)['match'](/^\s*$/)) {
          var hgrlt = a7pcom['doc'],
              g$ix = hgrlt['createTextNode'](c7o_am['substr'](kq9uns));hgrlt['appendChild'](g$ix), a7pcom['currentElement'] = g$ix;
        }return;
      }switch (d8b065 > kq9uns && y4v_7(d8b065), c7o_am['charAt'](d8b065 + 0x1)) {case '/':
          var _vaf7 = c7o_am['indexOf']('>', d8b065 + 0x3),
              a7c_ = c7o_am['substring'](d8b065 + 0x2, _vaf7),
              lhfzry = nk96su['pop']();0x0 > _vaf7 ? (a7c_ = c7o_am['substring'](d8b065 + 0x2)['replace'](/[\s<].*/, ''), rfvzyh['error']('end tag name: ' + a7c_ + ' is not complete:' + lhfzry['tagName']), _vaf7 = d8b065 + 0x1 + a7c_['length']) : a7c_['match'](/\s</) && (a7c_ = a7c_['replace'](/[\s<].*/, ''), rfvzyh['error']('end tag name: ' + a7c_ + ' maybe not complete'), _vaf7 = d8b065 + 0x1 + a7c_['length']);var ij3x$q = lhfzry['localNSMap'],
              yrfzlh = lhfzry['tagName'] == a7c_,
              vf4zyr = yrfzlh || lhfzry['tagName'] && lhfzry['tagName']['toLowerCase']() == a7c_['toLowerCase']();if (vf4zyr) {
            if (a7pcom['endElement'](lhfzry['uri'], lhfzry['localName'], a7c_), ij3x$q) {
              for (var ji$g in ij3x$q) a7pcom['endPrefixMapping'](ji$g);
            }yrfzlh || rfvzyh['fatalError']('end tag name: ' + a7c_ + ' is not match the current start tagName:' + lhfzry['tagName']);
          } else nk96su['push'](lhfzry);_vaf7++;break;case '?':
          apmceo && qjn3s(d8b065), _vaf7 = e_v4z(c7o_am, d8b065, a7pcom);break;case '!':
          apmceo && qjn3s(d8b065), _vaf7 = efryzv4(c7o_am, d8b065, a7pcom, rfvzyh);break;default:
          apmceo && qjn3s(d8b065);var _vf7y4 = new eijq3x(),
              a47_vm = nk96su[nk96su['length'] - 0x1]['currentNSMap'],
              _vaf7 = eqinj3u(c7o_am, d8b065, _vf7y4, a47_vm, $3qjix, rfvzyh),
              lzyfrh = _vf7y4['length'];if (!_vf7y4['closed'] && ei3xg$(c7o_am, _vaf7, _vf7y4['tagName'], vy) && (_vf7y4['closed'] = !0x0, fz_yv4['nbsp'] || rfvzyh['warning']('unclosed xml attribute')), apmceo && lzyfrh) {
            for (var $3ijn = ensjqu3(apmceo, {}), _am7v4 = 0x0; lzyfrh > _am7v4; _am7v4++) {
              var u69sbk = _vf7y4[_am7v4];qjn3s(u69sbk['offset']), u69sbk['locator'] = ensjqu3(apmceo, {});
            }a7pcom['locator'] = $3ijn, ezhvyfr(_vf7y4, a7pcom, a47_vm) && nk96su['push'](_vf7y4), a7pcom['locator'] = apmceo;
          } else ezhvyfr(_vf7y4, a7pcom, a47_vm) && nk96su['push'](_vf7y4);'http://www.w3.org/1999/xhtml' !== _vf7y4['uri'] || _vf7y4['closed'] ? _vaf7++ : _vaf7 = eyrvhf(c7o_am, _vaf7, _vf7y4['tagName'], $3qjix, a7pcom);}
    } catch (b8w5d0) {
      rfvzyh['error']('element parse error: ' + b8w5d0), _vaf7 = -0x1;
    }_vaf7 > kq9uns ? kq9uns = _vaf7 : y4v_7(Math['max'](d8b065, kq9uns) + 0x1);
  }
}function ensjqu3(cmeao, yfhr) {
  return yfhr['lineNumber'] = cmeao['lineNumber'], yfhr['columnNumber'] = cmeao['columnNumber'], yfhr;
}function eqinj3u(sunq9k, jx$q3i, wd2, nquji3, vma47, yf7_v4) {
  for (var uni3q, c_ma7, _fvy7 = ++jx$q3i, ght$x = extjig;;) {
    var b0685d = sunq9k['charAt'](_fvy7);switch (b0685d) {case '=':
        if (ght$x === exiqj3) uni3q = sunq9k['slice'](jx$q3i, _fvy7), ght$x = ehxr;else {
          if (ght$x !== enqu93) throw new Error('attribute equal must after attrName');ght$x = ehxr;
        }break;case '\x27':case '\x22':
        if (ght$x === ehxr || ght$x === exiqj3) {
          if (ght$x === exiqj3 && (yf7_v4['warning']('attribute value must after "="'), uni3q = sunq9k['slice'](jx$q3i, _fvy7)), jx$q3i = _fvy7 + 0x1, _fvy7 = sunq9k['indexOf'](b0685d, jx$q3i), !(_fvy7 > 0x0)) throw new Error('attribute value no end \'' + b0685d + '\' match');c_ma7 = sunq9k['slice'](jx$q3i, _fvy7)['replace'](/&#?\w+;/g, vma47), wd2['add'](uni3q, c_ma7, jx$q3i - 0x1), ght$x = einq3j;
        } else {
          if (ght$x != ehlrfy) throw new Error('attribute value must after "="');c_ma7 = sunq9k['slice'](jx$q3i, _fvy7)['replace'](/&#?\w+;/g, vma47), wd2['add'](uni3q, c_ma7, jx$q3i), yf7_v4['warning']('attribute "' + uni3q + '" missed start quot(' + b0685d + ')!!'), jx$q3i = _fvy7 + 0x1, ght$x = einq3j;
        }break;case '/':
        switch (ght$x) {case extjig:
            wd2['setTagName'](sunq9k['slice'](jx$q3i, _fvy7));case einq3j:case eu9n6sk:case esk9n6:
            ght$x = esk9n6, wd2['closed'] = !0x0;case ehlrfy:case exiqj3:case enqu93:
            break;default:
            throw new Error('attribute invalid close char(\'/\')');}break;case '':
        return yf7_v4['error']('unexpected end of input'), ght$x == extjig && wd2['setTagName'](sunq9k['slice'](jx$q3i, _fvy7)), _fvy7;case '>':
        switch (ght$x) {case extjig:
            wd2['setTagName'](sunq9k['slice'](jx$q3i, _fvy7));case einq3j:case eu9n6sk:case esk9n6:
            break;case ehlrfy:case exiqj3:
            c_ma7 = sunq9k['slice'](jx$q3i, _fvy7), '/' === c_ma7['slice'](-0x1) && (wd2['closed'] = !0x0, c_ma7 = c_ma7['slice'](0x0, -0x1));case enqu93:
            ght$x === enqu93 && (c_ma7 = uni3q), ght$x == ehlrfy ? (yf7_v4['warning']('attribute "' + c_ma7 + '" missed quot(")!!'), wd2['add'](uni3q, c_ma7['replace'](/&#?\w+;/g, vma47), jx$q3i)) : ('http://www.w3.org/1999/xhtml' === nquji3[''] && c_ma7['match'](/^(?:disabled|checked|selected)$/i) || yf7_v4['warning']('attribute "' + c_ma7 + '" missed value!! "' + c_ma7 + '" instead!!'), wd2['add'](c_ma7, c_ma7, jx$q3i));break;case ehxr:
            throw new Error('attribute value missed!!');}return _fvy7;case '\u0080':
        b0685d = '\x20';default:
        if ('\x20' >= b0685d) switch (ght$x) {case extjig:
            wd2['setTagName'](sunq9k['slice'](jx$q3i, _fvy7)), ght$x = eu9n6sk;break;case exiqj3:
            uni3q = sunq9k['slice'](jx$q3i, _fvy7), ght$x = enqu93;break;case ehlrfy:
            var c_ma7 = sunq9k['slice'](jx$q3i, _fvy7)['replace'](/&#?\w+;/g, vma47);yf7_v4['warning']('attribute "' + c_ma7 + '" missed quot(")!!'), wd2['add'](uni3q, c_ma7, jx$q3i);case einq3j:
            ght$x = eu9n6sk;} else switch (ght$x) {case enqu93:
            {
              wd2['tagName'];
            }'http://www.w3.org/1999/xhtml' === nquji3[''] && uni3q['match'](/^(?:disabled|checked|selected)$/i) || yf7_v4['warning']('attribute "' + uni3q + '" missed value!! "' + uni3q + '" instead2!!'), wd2['add'](uni3q, uni3q, jx$q3i), jx$q3i = _fvy7, ght$x = exiqj3;break;case einq3j:
            yf7_v4['warning']('attribute space is required"' + uni3q + '\x22!!');case eu9n6sk:
            ght$x = exiqj3, jx$q3i = _fvy7;break;case ehxr:
            ght$x = ehlrfy, jx$q3i = _fvy7;break;case esk9n6:
            throw new Error('elements closed character \'/\' and \'>\' must be connected to');}}_fvy7++;
  }
}function ezhvyfr(uk96b, gth$x, lzrhgt) {
  for (var cm_o7a = uk96b['tagName'], sq93n = null, y_v4f = uk96b['length']; y_v4f--;) {
    var tixlg$ = uk96b[y_v4f],
        _vyf4z = tixlg$['qName'],
        hvzfy = tixlg$['value'],
        nqiu3j = _vyf4z['indexOf'](':');if (nqiu3j > 0x0) var vf4_7y = tixlg$['prefix'] = _vyf4z['slice'](0x0, nqiu3j),
        pmoa = _vyf4z['slice'](nqiu3j + 0x1),
        c4m7_ = 'xmlns' === vf4_7y && pmoa;else pmoa = _vyf4z, vf4_7y = null, c4m7_ = 'xmlns' === _vyf4z && '';tixlg$['localName'] = pmoa, c4m7_ !== !0x1 && (null == sq93n && (sq93n = {}, e_zfv4(lzrhgt, lzrhgt = {})), lzrhgt[c4m7_] = sq93n[c4m7_] = hvzfy, tixlg$['uri'] = 'http://www.w3.org/2000/xmlns/', gth$x['startPrefixMapping'](c4m7_, hvzfy));
  }for (var y_v4f = uk96b['length']; y_v4f--;) {
    tixlg$ = uk96b[y_v4f];var vf4_7y = tixlg$['prefix'];vf4_7y && ('xml' === vf4_7y && (tixlg$['uri'] = 'http://www.w3.org/XML/1998/namespace'), 'xmlns' !== vf4_7y && (tixlg$['uri'] = lzrhgt[vf4_7y || '']));
  }var nqiu3j = cm_o7a['indexOf'](':');nqiu3j > 0x0 ? (vf4_7y = uk96b['prefix'] = cm_o7a['slice'](0x0, nqiu3j), pmoa = uk96b['localName'] = cm_o7a['slice'](nqiu3j + 0x1)) : (vf4_7y = null, pmoa = uk96b['localName'] = cm_o7a);var iq3ujn = uk96b['uri'] = lzrhgt[vf4_7y || ''];if (gth$x['startElement'](iq3ujn, pmoa, cm_o7a, uk96b), !uk96b['closed']) return uk96b['currentNSMap'] = lzrhgt, uk96b['localNSMap'] = sq93n, !0x0;if (gth$x['endElement'](iq3ujn, pmoa, cm_o7a), sq93n) {
    for (vf4_7y in sq93n) gth$x['endPrefixMapping'](vf4_7y);
  }
}function eyrvhf(g$3xij, htly, t$jxgi, lyrh, tgi$xl) {
  if (/^(?:script|textarea)$/i['test'](t$jxgi)) {
    var fvr4yz = g$3xij['indexOf']('</' + t$jxgi + '>', htly),
        uiq3j = g$3xij['substring'](htly + 0x1, fvr4yz);if (/[&<]/['test'](uiq3j)) return (/^script$/i['test'](t$jxgi) ? (tgi$xl['characters'](uiq3j, 0x0, uiq3j['length']), fvr4yz) : (uiq3j = uiq3j['replace'](/&#?\w+;/g, lyrh), tgi$xl['characters'](uiq3j, 0x0, uiq3j['length']), fvr4yz)
    );
  }return htly + 0x1;
}function ei3xg$(uk9nq, k5d0b6, q93ns, s9buk) {
  var sk0 = s9buk[q93ns];return null == sk0 && (sk0 = uk9nq['lastIndexOf']('</' + q93ns + '>'), k5d0b6 > sk0 && (sk0 = uk9nq['lastIndexOf']('</' + q93ns)), s9buk[q93ns] = sk0), k5d0b6 > sk0;
}function e_zfv4(hfrzyl, uq9s3n) {
  for (var lfrzhy in hfrzyl) uq9s3n[lfrzhy] = hfrzyl[lfrzhy];
}function efryzv4(kd96b0, i3jxg$, su9nkq, lthzy) {
  var ltghrx = kd96b0['charAt'](i3jxg$ + 0x2);switch (ltghrx) {case '-':
      if ('-' === kd96b0['charAt'](i3jxg$ + 0x3)) {
        var q$jn = kd96b0['indexOf']('-->', i3jxg$ + 0x4);return q$jn > i3jxg$ ? (su9nkq['comment'](kd96b0, i3jxg$ + 0x4, q$jn - i3jxg$ - 0x4), q$jn + 0x3) : (lthzy['error']('Unclosed comment'), -0x1);
      }return -0x1;default:
      if ('CDATA[' == kd96b0['substr'](i3jxg$ + 0x3, 0x6)) {
        var q$jn = kd96b0['indexOf'](']]>', i3jxg$ + 0x9);return su9nkq['startCDATA'](), su9nkq['characters'](kd96b0, i3jxg$ + 0x9, q$jn - i3jxg$ - 0x9), su9nkq['endCDATA'](), q$jn + 0x3;
      }var ma_v47 = edk6b0(kd96b0, i3jxg$),
          n3q9us = ma_v47['length'];if (n3q9us > 0x1 && /!doctype/i['test'](ma_v47[0x0][0x0])) {
        var rtylh = ma_v47[0x1][0x0],
            f7a_v4 = n3q9us > 0x3 && /^public$/i['test'](ma_v47[0x2][0x0]) && ma_v47[0x3][0x0],
            bsk69 = n3q9us > 0x4 && ma_v47[0x4][0x0],
            aocpe = ma_v47[n3q9us - 0x1];return su9nkq['startDTD'](rtylh, f7a_v4 && f7a_v4['replace'](/^(['"])(.*?)\1$/, '$2'), bsk69 && bsk69['replace'](/^(['"])(.*?)\1$/, '$2')), su9nkq['endDTD'](), aocpe['index'] + aocpe[0x0]['length'];
      }}return -0x1;
}function e_v4z(yf_4v, il$gx, ijq$n3) {
  var amec = yf_4v['indexOf']('?>', il$gx);if (amec) {
    var ij3nuq = yf_4v['substring'](il$gx, amec)['match'](/^<\?(\S*)\s*([\s\S]*?)\s*$/);if (ij3nuq) {
      {
        ij3nuq[0x0]['length'];
      }return ijq$n3['processingInstruction'](ij3nuq[0x1], ij3nuq[0x2]), amec + 0x2;
    }return -0x1;
  }return -0x1;
}function eijq3x() {}function ezyrhl($ixg, s3qu9n) {
  return $ixg['__proto__'] = s3qu9n, $ixg;
}function edk6b0(b50d6k, $jxtgi) {
  var caomp,
      i3$q = [],
      k9s0b = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;for (k9s0b['lastIndex'] = $jxtgi, k9s0b['exec'](b50d6k); caomp = k9s0b['exec'](b50d6k);) if (i3$q['push'](caomp), caomp[0x1]) return i3$q;
}var epc7aom = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    eigl = new RegExp('[\\-\\.0-9' + epc7aom['source']['slice'](0x1, -0x1) + '\\u00B7\\u0300-\\u036F\\u203F-\\u2040]'),
    ehgtl = new RegExp('^' + epc7aom['source'] + eigl['source'] + '*(?::' + epc7aom['source'] + eigl['source'] + '*)?$'),
    extjig = 0x0,
    exiqj3 = 0x1,
    enqu93 = 0x2,
    ehxr = 0x3,
    ehlrfy = 0x4,
    einq3j = 0x5,
    eu9n6sk = 0x6,
    esk9n6 = 0x7;exlgit$['prototype'] = { 'parse': function (_cm7o, x$itgl, $itxjg) {
    var ubk9 = this['domBuilder'];ubk9['startDocument'](), e_zfv4(x$itgl, x$itgl = {}), evr4fyz(_cm7o, x$itgl, $itxjg, ubk9, this['errorHandler']), ubk9['endDocument']();
  } }, eijq3x['prototype'] = { 'setTagName': function (li$xtg) {
    if (!ehgtl['test'](li$xtg)) throw new Error('invalid tagName:' + li$xtg);this['tagName'] = li$xtg;
  }, 'add': function (bks96, uj3iq, nqju) {
    if (!ehgtl['test'](bks96)) throw new Error('invalid attribute:' + bks96);this[this['length']++] = { 'qName': bks96, 'value': uj3iq, 'offset': nqju };
  }, 'length': 0x0, 'getLocalName': function ($xglit) {
    return this[$xglit]['localName'];
  }, 'getLocator': function (m4_v7) {
    return this[m4_v7]['locator'];
  }, 'getQName': function (vf4_a) {
    return this[vf4_a]['qName'];
  }, 'getURI': function (_47mac) {
    return this[_47mac]['uri'];
  }, 'getValue': function (usnq) {
    return this[usnq]['value'];
  } }, ezyrhl({}, ezyrhl['prototype']) instanceof ezyrhl || (ezyrhl = function (ryvfz4, j3gi$x) {
  function m_o7() {}m_o7['prototype'] = j3gi$x, m_o7 = new m_o7();for (j3gi$x in ryvfz4) m_o7[j3gi$x] = ryvfz4[j3gi$x];return m_o7;
}), exports['XMLReader'] = exlgit$;