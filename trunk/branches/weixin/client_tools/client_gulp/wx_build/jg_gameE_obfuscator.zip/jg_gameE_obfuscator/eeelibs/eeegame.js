var b = wx.$e;
console[b[40078]](b[69183]), window[b[69184]], wx[b[69185]](function (kus9) {
  if (kus9) {
    if (kus9[b[44513]]) {
      var lzytr = window[b[40557]][b[69186]][b[44691]](new RegExp(/\./, 'g'), '_'),
          tgj$x = kus9[b[44513]],
          om_c7 = tgj$x[b[52061]](/(eeeeeeee\/eeegame.js:)[0-9]{1,60}(:)/g);if (om_c7) for (var xi$jg3 = 0x0; xi$jg3 < om_c7[b[40013]]; xi$jg3++) {
        if (om_c7[xi$jg3] && om_c7[xi$jg3][b[40013]] > 0x0) {
          var a7_vm = parseInt(om_c7[xi$jg3][b[44691]](b[69187], '')[b[44691]](':', ''));tgj$x = tgj$x[b[44691]](om_c7[xi$jg3], om_c7[xi$jg3][b[44691]](':' + a7_vm + ':', ':' + (a7_vm - 0x2) + ':'));
        }
      }tgj$x = tgj$x[b[44691]](new RegExp(b[69188], 'g'), b[69189] + lzytr + b[65326]), tgj$x = tgj$x[b[44691]](new RegExp(b[69190], 'g'), b[69189] + lzytr + b[65326]), kus9[b[44513]] = tgj$x;
    }var _4a7cm = { 'id': window['e1U0'][b[69191]], 'role': window['e1U0'][b[44633]], 'level': window['e1U0'][b[69192]], 'user': window['e1U0'][b[65226]], 'version': window['e1U0'][b[40101]], 'cdn': window['e1U0'][b[44511]], 'pkgName': window['e1U0'][b[65227]], 'gamever': window[b[40557]][b[69186]], 'serverid': window['e1U0'][b[65221]] ? window['e1U0'][b[65221]][b[51515]] : 0x0, 'systemInfo': window[b[69193]], 'error': b[69194], 'stack': kus9 ? kus9[b[44513]] : '' },
        _fy47 = JSON[b[44497]](_4a7cm);console[b[40125]](b[69195] + _fy47), (!window[b[69184]] || window[b[69184]] != _4a7cm[b[40125]]) && (window[b[69184]] = _4a7cm[b[40125]], window['e11U'](_4a7cm));
  }
});import 'eeemd5min.js';import 'eeezlibs.js';window[b[69196]] = require(b[69197]);import 'eeeindex.js';import 'eeelibsmin.js';import 'eeewxmini.js';import 'eeeinitmin.js';console[b[40078]](b[69198]), console[b[40078]](b[69199]), e11UG0({ 'title': b[69200] });var ex3iqj$ = { 'e1I10UG': !![] };new window[b[69201]](ex3iqj$), window[b[69201]][b[40148]]['e1IGU01']();if (window['e1I1U0G']) clearInterval(window['e1I1U0G']);window['e1I1U0G'] = null, window['e1IG01U'] = function (ujqi3n, moce) {
  if (!ujqi3n || !moce) return 0x0;ujqi3n = ujqi3n[b[40015]]('.'), moce = moce[b[40015]]('.');const $tghxl = Math[b[40853]](ujqi3n[b[40013]], moce[b[40013]]);while (ujqi3n[b[40013]] < $tghxl) {
    ujqi3n[b[40029]]('0');
  }while (moce[b[40013]] < $tghxl) {
    moce[b[40029]]('0');
  }for (var $n3i = 0x0; $n3i < $tghxl; $n3i++) {
    const uqs9k = parseInt(ujqi3n[$n3i]),
          $xi3qj = parseInt(moce[$n3i]);if (uqs9k > $xi3qj) return 0x1;else {
      if (uqs9k < $xi3qj) return -0x1;
    }
  }return 0x0;
}, window[b[69202]] = wx[b[69203]]()[b[69202]], console[b[40482]](b[69204] + window[b[69202]]);var ertgxh = wx[b[69205]]();ertgxh[b[69206]](function (_4a) {
  console[b[40482]](b[69207] + _4a[b[69208]]);
}), ertgxh[b[69209]](function () {
  wx[b[69210]]({ 'title': b[69211], 'content': b[69212], 'showCancel': ![], 'success': function ($xijtg) {
      ertgxh[b[69213]]();
    } });
}), ertgxh[b[69214]](function () {
  console[b[40482]](b[69215]);
}), window['e1IG0U1'] = function () {
  console[b[40482]](b[69216]);var lfrhyz = wx[b[69217]]({ 'name': b[69218], 'success': function (nq9usk) {
      console[b[40482]](b[69219]), console[b[40482]](nq9usk), nq9usk && nq9usk[b[65410]] == b[69220] ? (window['e10G'] = !![], window['e10GU1'](), window['e10U1G']()) : setTimeout(function () {
        window['e1IG0U1']();
      }, 0x1f4);
    }, 'fail': function (xrlgt) {
      console[b[40482]](b[69221]), console[b[40482]](xrlgt), setTimeout(function () {
        window['e1IG0U1']();
      }, 0x1f4);
    } });lfrhyz && lfrhyz[b[69222]](d60b9 => {});
}, window['e1IU10G'] = function () {
  console[b[40482]](b[69223]);var f4vrz = wx[b[69217]]({ 'name': b[69224], 'success': function (txgl) {
      console[b[40482]](b[69225]), console[b[40482]](txgl), txgl && txgl[b[65410]] == b[69220] ? (window['e1UG0'] = !![], window['e10GU1'](), window['e10U1G']()) : setTimeout(function () {
        window['e1IU10G']();
      }, 0x1f4);
    }, 'fail': function ($gji) {
      console[b[40482]](b[69226]), console[b[40482]]($gji), setTimeout(function () {
        window['e1IU10G']();
      }, 0x1f4);
    } });f4vrz && f4vrz[b[69222]](m4ac_7 => {});
}, window[b[69227]] = function () {
  window['e1IG01U'](window[b[69202]], b[69228]) >= 0x0 ? (console[b[40482]](b[69229] + window[b[69202]] + b[69230]), window['e1U1'](), window['e1IG0U1'](), window['e1IU10G']()) : (window['e1U01'](b[69231], window[b[69202]]), wx[b[69210]]({ 'title': b[46357], 'content': b[69232] }));
}, window[b[69193]] = '', wx[b[69233]]({ 'success'(m_47ca) {
    window[b[69193]] = b[69234] + m_47ca[b[69235]] + b[69236] + m_47ca[b[69237]] + b[69238] + m_47ca[b[44704]] + b[69239] + m_47ca[b[40475]] + b[69240] + m_47ca[b[65198]] + b[69241] + m_47ca[b[69202]] + b[69242] + m_47ca[b[49312]], console[b[40482]](window[b[69193]]), console[b[40482]](b[69243] + m_47ca[b[69244]] + b[69245] + m_47ca[b[69246]] + b[69247] + m_47ca[b[69248]] + b[69249] + m_47ca[b[69250]] + b[69251] + m_47ca[b[69252]] + b[69253] + m_47ca[b[69254]] + b[69255] + (m_47ca[b[69256]] ? m_47ca[b[69256]][b[40323]] + ',' + m_47ca[b[69256]][b[41216]] + ',' + m_47ca[b[69256]][b[41218]] + ',' + m_47ca[b[69256]][b[41217]] : ''));var tgl$ = m_47ca[b[40475]] ? m_47ca[b[40475]][b[52358]]() : '',
        glrht = m_47ca[b[69237]] ? m_47ca[b[69237]][b[52358]]()[b[44691]]('\x20', '') : '';window['e1U0'][b[41074]] = tgl$[b[40115]](b[68490]) != -0x1, window['e1U0'][b[51337]] = tgl$[b[40115]](b[68489]) != -0x1, window['e1U0'][b[69257]] = tgl$[b[40115]](b[68490]) != -0x1 || tgl$[b[40115]](b[68489]) != -0x1, window['e1U0'][b[64934]] = tgl$[b[40115]](b[69258]) != -0x1 || tgl$[b[40115]](b[68495]) != -0x1, window['e1U0'][b[69259]] = m_47ca[b[65198]] ? m_47ca[b[65198]][b[52358]]() : '', window['e1U0']['e1I1G0U'] = ![], window['e1U0']['e1I1UG0'] = 0x2;if (tgl$[b[40115]](b[68489]) != -0x1) {
      if (m_47ca[b[49312]] >= 0x18) window['e1U0']['e1I1UG0'] = 0x3;else window['e1U0']['e1I1UG0'] = 0x2;
    } else {
      if (tgl$[b[40115]](b[68490]) != -0x1) {
        if (m_47ca[b[49312]] && m_47ca[b[49312]] >= 0x14) window['e1U0']['e1I1UG0'] = 0x3;else {
          if (glrht[b[40115]](b[69260]) != -0x1 || glrht[b[40115]](b[69261]) != -0x1 || glrht[b[40115]](b[69262]) != -0x1 || glrht[b[40115]](b[69263]) != -0x1 || glrht[b[40115]](b[69264]) != -0x1) window['e1U0']['e1I1UG0'] = 0x2;else window['e1U0']['e1I1UG0'] = 0x3;
        }
      } else window['e1U0']['e1I1UG0'] = 0x2;
    }console[b[40482]](b[69265] + window['e1U0']['e1I1G0U'] + b[69266] + window['e1U0']['e1I1UG0']);
  } }), wx[b[69267]]({ 'success': function (_f4zyv) {
    console[b[40482]](b[69268] + _f4zyv[b[44609]] + b[69269] + _f4zyv[b[69270]]);
  } }), wx[b[69271]]({ 'success': function (tzlyhr) {
    console[b[40482]](b[69272] + tzlyhr[b[69273]]);
  } }), wx[b[69274]]({ 'keepScreenOn': !![] }), wx[b[69275]](function (j3x$ig) {
  console[b[40482]](b[69272] + j3x$ig[b[69273]] + b[69276] + j3x$ig[b[69277]]);
}), wx[b[50847]](function (fhrzl) {
  window['e1G1'] = fhrzl, window['e101G'] && window['e1G1'] && (console[b[40078]](b[69278] + window['e1G1'][b[40776]]), window['e101G'](window['e1G1']), window['e1G1'] = null);
}), window[b[69279]] = 0x0, window['e1IUG01'] = 0x0, window[b[69280]] = null, wx[b[69281]](function () {
  window['e1IUG01']++;var fyzrhl = Date[b[40083]]();(window[b[69279]] == 0x0 || fyzrhl - window[b[69279]] > 0x1d4c0) && (console[b[40096]](b[69282]), wx[b[51914]]());if (window['e1IUG01'] >= 0x2) {
    window['e1IUG01'] = 0x0, console[b[40125]](b[69283]), wx[b[69284]]('0', 0x1);if (window['e1U0'] && window['e1U0'][b[41074]]) window['e1U01'](b[69285], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});