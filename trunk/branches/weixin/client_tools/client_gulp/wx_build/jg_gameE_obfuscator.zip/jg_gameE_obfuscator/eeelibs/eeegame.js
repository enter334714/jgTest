var b = wx.$e;
console[b[40082]](b[70112]), window[b[70113]], wx[b[70114]](function (g3i$) {
  if (g3i$) {
    if (g3i$[b[44863]]) {
      var ytzrh = window[b[40588]][b[70115]][b[45043]](new RegExp(/\./, 'g'), '_'),
          y_fvz4 = g3i$[b[44863]],
          q3jun = y_fvz4[b[52570]](/(eeeeeeee\/eeegame.js:)[0-9]{1,60}(:)/g);if (q3jun) for (var bk5 = 0x0; bk5 < q3jun[b[40016]]; bk5++) {
        if (q3jun[bk5] && q3jun[bk5][b[40016]] > 0x0) {
          var hrltzy = parseInt(q3jun[bk5][b[45043]](b[70116], '')[b[45043]](':', ''));y_fvz4 = y_fvz4[b[45043]](q3jun[bk5], q3jun[bk5][b[45043]](':' + hrltzy + ':', ':' + (hrltzy - 0x2) + ':'));
        }
      }y_fvz4 = y_fvz4[b[45043]](new RegExp(b[70117], 'g'), b[70118] + ytzrh + b[66273]), y_fvz4 = y_fvz4[b[45043]](new RegExp(b[70119], 'g'), b[70118] + ytzrh + b[66273]), g3i$[b[44863]] = y_fvz4;
    }var ubks = { 'id': window[b[70120]][b[70121]], 'role': window[b[70120]][b[44984]], 'level': window[b[70120]][b[70122]], 'user': window[b[70120]][b[66172]], 'version': window[b[70120]][b[40109]], 'cdn': window[b[70120]][b[44861]], 'pkgName': window[b[70120]][b[66173]], 'gamever': window[b[40588]][b[70115]], 'serverid': window[b[70120]][b[66167]] ? window[b[70120]][b[66167]][b[51940]] : 0x0, 'systemInfo': window[b[70123]], 'error': b[70124], 'stack': g3i$ ? g3i$[b[44863]] : '' },
        m4_c7 = JSON[b[44847]](ubks);console[b[40143]](b[70125] + m4_c7), (!window[b[70113]] || window[b[70113]] != ubks[b[40143]]) && (window[b[70113]] = ubks[b[40143]], window[b[70126]](ubks));
  }
});import 'eeemd5min.js';import 'eeezlibs.js';window[b[70127]] = require(b[70128]);import 'eeeindex.js';import 'eeelibsmin.js';import 'eeewxmini.js';import 'eeeinitmin.js';console[b[40082]](b[70129]), console[b[40082]](b[70130]), e11UG0({ 'title': b[70131] });var elxg$it = { 'e1I10UG': !![] };new window[b[70132]](elxg$it), window[b[70132]][b[40166]][b[70133]]();if (window[b[70134]]) clearInterval(window[b[70134]]);window[b[70134]] = null, window[b[70135]] = function (bd8w, qun39s) {
  if (!bd8w || !qun39s) return 0x0;bd8w = bd8w[b[40018]]('.'), qun39s = qun39s[b[40018]]('.');const b50d = Math[b[40907]](bd8w[b[40016]], qun39s[b[40016]]);while (bd8w[b[40016]] < b50d) {
    bd8w[b[40033]]('0');
  }while (qun39s[b[40016]] < b50d) {
    qun39s[b[40033]]('0');
  }for (var hlgzrt = 0x0; hlgzrt < b50d; hlgzrt++) {
    const n3jqsu = parseInt(bd8w[hlgzrt]),
          y_f7v = parseInt(qun39s[hlgzrt]);if (n3jqsu > y_f7v) return 0x1;else {
      if (n3jqsu < y_f7v) return -0x1;
    }
  }return 0x0;
}, window[b[70136]] = wx[b[70137]]()[b[70136]], console[b[40511]](b[70138] + window[b[70136]]);var eqji$x = wx[b[70139]]();eqji$x[b[70140]](function (a4fv_) {
  console[b[40511]](b[70141] + a4fv_[b[70142]]);
}), eqji$x[b[70143]](function () {
  wx[b[70144]]({ 'title': b[70145], 'content': b[70146], 'showCancel': ![], 'success': function (cmoap7) {
      eqji$x[b[70147]]();
    } });
}), eqji$x[b[70148]](function () {
  console[b[40511]](b[70149]);
}), window[b[70150]] = function () {
  console[b[40511]](b[70151]);var rglhtx = wx[b[70152]]({ 'name': b[70153], 'success': function (jgxi$3) {
      console[b[40511]](b[70154]), console[b[40511]](jgxi$3), jgxi$3 && jgxi$3[b[66370]] == b[70155] ? (window[b[70156]] = !![], window[b[70157]](), window[b[70158]]()) : setTimeout(function () {
        window[b[70150]]();
      }, 0x1f4);
    }, 'fail': function (q3$xj) {
      console[b[40511]](b[70159]), console[b[40511]](q3$xj), setTimeout(function () {
        window[b[70150]]();
      }, 0x1f4);
    } });rglhtx && rglhtx[b[69841]](lzryf => {});
}, window[b[70160]] = function () {
  console[b[40511]](b[70161]);var _4yfvz = wx[b[70152]]({ 'name': b[70162], 'success': function (njqus3) {
      console[b[40511]](b[70163]), console[b[40511]](njqus3), njqus3 && njqus3[b[66370]] == b[70155] ? (window[b[70164]] = !![], window[b[70157]](), window[b[70158]]()) : setTimeout(function () {
        window[b[70160]]();
      }, 0x1f4);
    }, 'fail': function (b9dk0) {
      console[b[40511]](b[70165]), console[b[40511]](b9dk0), setTimeout(function () {
        window[b[70160]]();
      }, 0x1f4);
    } });_4yfvz && _4yfvz[b[69841]](_4vm7 => {});
}, window[b[70166]] = function () {
  window[b[70135]](window[b[70136]], b[70167]) >= 0x0 ? (console[b[40511]](b[70168] + window[b[70136]] + b[70169]), window[b[70170]](), window[b[70150]](), window[b[70160]]()) : (window[b[70171]](b[70172], window[b[70136]]), wx[b[70144]]({ 'title': b[46726], 'content': b[70173] }));
}, window[b[70123]] = '', wx[b[70174]]({ 'success'(kd6b05) {
    window[b[70123]] = b[70175] + kd6b05[b[70176]] + b[70177] + kd6b05[b[70178]] + b[70179] + kd6b05[b[45056]] + b[70180] + kd6b05[b[40504]] + b[70181] + kd6b05[b[66137]] + b[70182] + kd6b05[b[70136]] + b[70183] + kd6b05[b[49701]], console[b[40511]](window[b[70123]]), console[b[40511]](b[70184] + kd6b05[b[70185]] + b[70186] + kd6b05[b[70187]] + b[70188] + kd6b05[b[70189]] + b[70190] + kd6b05[b[70191]] + b[70192] + kd6b05[b[70193]] + b[70194] + kd6b05[b[70195]] + b[70196] + (kd6b05[b[70197]] ? kd6b05[b[70197]][b[40342]] + ',' + kd6b05[b[70197]][b[41345]] + ',' + kd6b05[b[70197]][b[41347]] + ',' + kd6b05[b[70197]][b[41346]] : ''));var $3xqi = kd6b05[b[40504]] ? kd6b05[b[40504]][b[52876]]() : '',
        xltgi$ = kd6b05[b[70178]] ? kd6b05[b[70178]][b[52876]]()[b[45043]]('\x20', '') : '';window[b[70120]][b[41132]] = $3xqi[b[40124]](b[70198]) != -0x1, window[b[70120]][b[51762]] = $3xqi[b[40124]](b[70089]) != -0x1, window[b[70120]][b[70199]] = $3xqi[b[40124]](b[70198]) != -0x1 || $3xqi[b[40124]](b[70089]) != -0x1, window[b[70120]][b[65867]] = $3xqi[b[40124]](b[70200]) != -0x1 || $3xqi[b[40124]](b[70201]) != -0x1, window[b[70120]][b[70202]] = kd6b05[b[66137]] ? kd6b05[b[66137]][b[52876]]() : '', window[b[70120]][b[70203]] = ![], window[b[70120]][b[70204]] = 0x2;if ($3xqi[b[40124]](b[70089]) != -0x1) {
      if (kd6b05[b[49701]] >= 0x18) window[b[70120]][b[70204]] = 0x3;else window[b[70120]][b[70204]] = 0x2;
    } else {
      if ($3xqi[b[40124]](b[70198]) != -0x1) {
        if (kd6b05[b[49701]] && kd6b05[b[49701]] >= 0x14) window[b[70120]][b[70204]] = 0x3;else {
          if (xltgi$[b[40124]](b[70205]) != -0x1 || xltgi$[b[40124]](b[70206]) != -0x1 || xltgi$[b[40124]](b[70207]) != -0x1 || xltgi$[b[40124]](b[70208]) != -0x1 || xltgi$[b[40124]](b[70209]) != -0x1) window[b[70120]][b[70204]] = 0x2;else window[b[70120]][b[70204]] = 0x3;
        }
      } else window[b[70120]][b[70204]] = 0x2;
    }console[b[40511]](b[70210] + window[b[70120]][b[70203]] + b[70211] + window[b[70120]][b[70204]]);
  } }), wx[b[70212]]({ 'success': function ($iqjx) {
    console[b[40511]](b[70213] + $iqjx[b[44960]] + b[70214] + $iqjx[b[70215]]);
  } }), wx[b[52342]]({ 'success': function (k9) {
    console[b[40511]](b[70216] + k9[b[53658]]);
  } }), wx[b[70217]]({ 'keepScreenOn': !![] }), wx[b[52344]](function (lyzhtr) {
  console[b[40511]](b[70216] + lyzhtr[b[53658]] + b[70218] + lyzhtr[b[70219]]);
}), wx[b[51268]](function (f7y_v) {
  window[b[70220]] = f7y_v, window[b[70221]] && window[b[70220]] && (console[b[40082]](b[70222] + window[b[70220]][b[40830]]), window[b[70221]](window[b[70220]]), window[b[70220]] = null);
}), window[b[70223]] = 0x0, window[b[70224]] = 0x0, window[b[70225]] = null, wx[b[70226]](function () {
  window[b[70224]]++;var ubs9k = Date[b[40087]]();(window[b[70223]] == 0x0 || ubs9k - window[b[70223]] > 0x1d4c0) && (console[b[40102]](b[70227]), wx[b[52414]]());if (window[b[70224]] >= 0x2) {
    window[b[70224]] = 0x0, console[b[40143]](b[70228]), wx[b[70229]]('0', 0x1);if (window[b[70120]] && window[b[70120]][b[41132]]) window[b[70171]](b[70230], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});