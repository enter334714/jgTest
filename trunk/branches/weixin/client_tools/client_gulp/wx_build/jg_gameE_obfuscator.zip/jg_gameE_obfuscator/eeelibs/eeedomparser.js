var b = wx.$e;
function ec7_aom(y4v7f) {
  this['options'] = y4v7f || { 'locator': {} };
}function euq9s3(xti$gl, frhyz, iqj3x$) {
  function g3xji$(vryhfz) {
    var uk96bs = xti$gl[vryhfz];!uk96bs && grlthz && (uk96bs = 0x2 == xti$gl['length'] ? function (fyvz) {
      xti$gl(vryhfz, fyvz);
    } : xti$gl), aoepc[vryhfz] = uk96bs && function (ns9qk) {
      uk96bs('[xmldom ' + vryhfz + ']\t' + ns9qk + e_amco7(iqj3x$));
    } || function () {};
  }if (!xti$gl) {
    if (frhyz instanceof e_a4fv) return frhyz;xti$gl = frhyz;
  }var aoepc = {},
      grlthz = xti$gl instanceof Function;return iqj3x$ = iqj3x$ || {}, g3xji$('warning'), g3xji$('error'), g3xji$('fatalError'), aoepc;
}function e_a4fv() {
  this['cdata'] = !0x1;
}function eb0w5(peoma, n69us) {
  n69us['lineNumber'] = peoma['lineNumber'], n69us['columnNumber'] = peoma['columnNumber'];
}function e_amco7(vyzf4) {
  return vyzf4 ? '\x0a@' + (vyzf4['systemId'] || '') + '#[line:' + vyzf4['lineNumber'] + ',col:' + vyzf4['columnNumber'] + ']' : void 0x0;
}function elhtr(lhfyr, tyzrl, ksqu9) {
  return 'string' == typeof lhfyr ? lhfyr['substr'](tyzrl, ksqu9) : lhfyr['length'] >= tyzrl + ksqu9 || tyzrl ? new java['lang']['String'](lhfyr, tyzrl, ksqu9) + '' : lhfyr;
}function eqs3un9(d0b5k, _ca47m) {
  d0b5k['currentElement'] ? d0b5k['currentElement']['appendChild'](_ca47m) : d0b5k['doc']['appendChild'](_ca47m);
}ec7_aom['prototype']['parseFromString'] = function (qn93u, yr4vf) {
  var x3qi = this['options'],
      g$xi3 = new ez4vyr(),
      _y4fzv = x3qi['domBuilder'] || new e_a4fv(),
      u9s6b = x3qi['errorHandler'],
      grltx = x3qi['locator'],
      n3iq$j = x3qi['xmlns'] || {},
      yr4 = { 'lt': '<', 'gt': '>', 'amp': '&', 'quot': '\x22', 'apos': '\x27' };return grltx && _y4fzv['setDocumentLocator'](grltx), g$xi3['errorHandler'] = euq9s3(u9s6b, _y4fzv, grltx), g$xi3['domBuilder'] = x3qi['domBuilder'] || _y4fzv, /\/x?html?$/['test'](yr4vf) && (yr4['nbsp'] = '\u00a0', yr4['copy'] = '©', n3iq$j[''] = 'http://www.w3.org/1999/xhtml'), n3iq$j['xml'] = n3iq$j['xml'] || 'http://www.w3.org/XML/1998/namespace', qn93u ? g$xi3['parse'](qn93u, n3iq$j, yr4) : g$xi3['errorHandler']['error']('invalid doc source'), _y4fzv['doc'];
}, e_a4fv['prototype'] = { 'startDocument': function () {
    this['doc'] = new ec4a()['createDocument'](null, null, null), this['locator'] && (this['doc']['documentURI'] = this['locator']['systemId']);
  }, 'startElement': function (xgtil, d05k, v4fa, juni3q) {
    var sukn9 = this['doc'],
        in3jq = sukn9['createElementNS'](xgtil, v4fa || d05k),
        zflhr = juni3q['length'];eqs3un9(this, in3jq), this['currentElement'] = in3jq, this['locator'] && eb0w5(this['locator'], in3jq);for (var hgx$lt = 0x0; zflhr > hgx$lt; hgx$lt++) {
      var xgtil = juni3q['getURI'](hgx$lt),
          d0b = juni3q['getValue'](hgx$lt),
          v4fa = juni3q['getQName'](hgx$lt),
          lt$gh = sukn9['createAttributeNS'](xgtil, v4fa);this['locator'] && eb0w5(juni3q['getLocator'](hgx$lt), lt$gh), lt$gh['value'] = lt$gh['nodeValue'] = d0b, in3jq['setAttributeNode'](lt$gh);
    }
  }, 'endElement': function () {
    {
      var ujq3ns = this['currentElement'];ujq3ns['tagName'];
    }this['currentElement'] = ujq3ns['parentNode'];
  }, 'startPrefixMapping': function () {}, 'endPrefixMapping': function () {}, 'processingInstruction': function (zrhtlg, k6b90s) {
    var s3q = this['doc']['createProcessingInstruction'](zrhtlg, k6b90s);this['locator'] && eb0w5(this['locator'], s3q), eqs3un9(this, s3q);
  }, 'ignorableWhitespace': function () {}, 'characters': function (_ac7o) {
    if (_ac7o = elhtr['apply'](this, arguments)) {
      if (this['cdata']) var amc7_4 = this['doc']['createCDATASection'](_ac7o);else var amc7_4 = this['doc']['createTextNode'](_ac7o);this['currentElement'] ? this['currentElement']['appendChild'](amc7_4) : /^\s*$/['test'](_ac7o) && this['doc']['appendChild'](amc7_4), this['locator'] && eb0w5(this['locator'], amc7_4);
    }
  }, 'skippedEntity': function () {}, 'endDocument': function () {
    this['doc']['normalize']();
  }, 'setDocumentLocator': function (a_7c4m) {
    (this['locator'] = a_7c4m) && (a_7c4m['lineNumber'] = 0x0);
  }, 'comment': function (hrxt) {
    hrxt = elhtr['apply'](this, arguments);var gtxi$ = this['doc']['createComment'](hrxt);this['locator'] && eb0w5(this['locator'], gtxi$), eqs3un9(this, gtxi$);
  }, 'startCDATA': function () {
    this['cdata'] = !0x0;
  }, 'endCDATA': function () {
    this['cdata'] = !0x1;
  }, 'startDTD': function (q3ijn$, uqsn39, z4fyv) {
    var gtlxi$ = this['doc']['implementation'];if (gtlxi$ && gtlxi$['createDocumentType']) {
      var ap7co = gtlxi$['createDocumentType'](q3ijn$, uqsn39, z4fyv);this['locator'] && eb0w5(this['locator'], ap7co), eqs3un9(this, ap7co);
    }
  }, 'warning': function (tghlzr) {
    console['warn']('[xmldom warning]\t' + tghlzr, e_amco7(this['locator']));
  }, 'error': function (jnq3ui) {
    console['error']('[xmldom error]\t' + jnq3ui, e_amco7(this['locator']));
  }, 'fatalError': function (b6805) {
    throw console['error']('[xmldom fatalError]\t' + b6805, e_amco7(this['locator'])), b6805;
  } }, 'endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl'['replace'](/\w+/g, function (jqin) {
  e_a4fv['prototype'][jqin] = function () {
    return null;
  };
});var ez4vyr = require('./eeesax')['XMLReader'],
    ec4a = exports['DOMImplementation'] = require('./eeedom')['DOMImplementation'];exports['XMLSerializer'] = require('./eeedom')['XMLSerializer'], exports['DOMParser'] = ec7_aom;