var b = wx.$e;
require('eeeeBuff.js'), window[b[69172]][b[69162]][b[69051]] = null, window['client_pb'] = require('eeecleintpb.js'), window[b[65367]] = window[b[69172]][b[65255]][b[65256]](client_pb);