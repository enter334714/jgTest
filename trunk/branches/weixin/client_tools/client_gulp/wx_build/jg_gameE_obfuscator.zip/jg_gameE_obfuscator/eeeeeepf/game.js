var b = wx.$e;
require('eeeeBuff.js'), window[b[71174]][b[71164]][b[71056]] = null, window['client_pb'] = require('eeecleintpb.js'), window[b[66315]] = window[b[71174]][b[66203]][b[66204]](client_pb);