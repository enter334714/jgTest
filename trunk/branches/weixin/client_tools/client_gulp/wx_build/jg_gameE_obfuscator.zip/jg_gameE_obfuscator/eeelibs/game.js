var b = wx.$e;
require(b[70766]);