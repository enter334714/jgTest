var b = wx.$e;
import ebk05d from '../eeeesdk/eeesdk.js';window[b[69286]] = { 'wxVersion': window[b[40557]][b[69186]] }, window[b[69287]] = ![], window['e10U'] = 0x1, window[b[69288]] = 0x1, window['e1GU0'] = !![], window[b[69289]] = !![], window['e1I1GU0'] = '', window['e1U0'] = { 'base_cdn': b[69290], 'cdn': b[69290] }, e1U0[b[69291]] = {}, e1U0[b[64932]] = '0', e1U0[b[44704]] = window[b[69286]][b[69292]], e1U0[b[68495]] = '', e1U0['os'] = '1', e1U0[b[69293]] = b[69294], e1U0[b[69295]] = b[69296], e1U0[b[69297]] = b[69298], e1U0[b[69299]] = b[69300], e1U0[b[69301]] = b[69302], e1U0[b[63632]] = '1', e1U0[b[65227]] = '', e1U0[b[65229]] = '', e1U0[b[69303]] = 0x0, e1U0[b[69304]] = {}, e1U0[b[69305]] = parseInt(e1U0[b[63632]]), e1U0[b[65225]] = e1U0[b[63632]], e1U0[b[65221]] = {}, e1U0['e11U'] = b[69306], e1U0[b[69307]] = ![], e1U0[b[52259]] = b[69308], e1U0[b[65200]] = Date[b[40083]](), e1U0[b[51861]] = b[69309], e1U0[b[40714]] = '_a', e1U0[b[69310]] = 0x2, e1U0[b[40101]] = 0x7c1, e1U0[b[69292]] = window[b[69286]][b[69292]], e1U0[b[40738]] = ![], e1U0[b[41074]] = ![], e1U0[b[51337]] = ![], e1U0[b[64934]] = ![], window['e1G0U'] = 0x5, window['e1G0'] = ![], window['e10G'] = ![], window['e1UG0'] = ![], window[b[69311]] = ![], window[b[69312]] = ![], window['e1U0G'] = ![], window['e1GU'] = ![], window['e1UG'] = ![], window['e10GU'] = ![], window[b[44177]] = function (db68) {
  console[b[40482]](b[44177], db68), wx[b[44983]]({}), wx[b[69210]]({ 'title': b[46357], 'content': db68, 'success'(zrlhfy) {
      if (zrlhfy[b[69313]]) console[b[40482]](b[69314]);else zrlhfy[b[40553]] && console[b[40482]](b[68648]);
    } });
}, window['e11GU0'] = function (v_7m) {
  console[b[40482]](b[69315], v_7m), e11U0G(), wx[b[69210]]({ 'title': b[46357], 'content': v_7m, 'confirmText': b[69316], 'cancelText': b[58508], 'success'(qjn$) {
      if (qjn$[b[69313]]) window['e1U1']();else qjn$[b[40553]] && (console[b[40482]](b[69317]), wx[b[64927]]({}));
    } });
}, window[b[69318]] = function (ubk6s9) {
  console[b[40482]](b[69318], ubk6s9), wx[b[69210]]({ 'title': b[46357], 'content': ubk6s9, 'confirmText': b[65357], 'showCancel': ![], 'complete'(u9nk6) {
      console[b[40482]](b[69317]), wx[b[64927]]({});
    } });
}, window['e11G0U'] = ![], window['e11UG0'] = function (skunq) {
  window['e11G0U'] = !![], wx[b[44982]](skunq);
}, window['e11U0G'] = function () {
  window['e11G0U'] && (window['e11G0U'] = ![], wx[b[44983]]({}));
}, window['e110GU'] = function (s0kb6) {
  window[b[69201]][b[40148]]['e110GU'](s0kb6);
}, window[b[52137]] = function (qu9, busk96) {
  ebk05d[b[52137]](qu9, function (ju3qsn) {
    ju3qsn && ju3qsn[b[40011]] ? ju3qsn[b[40011]][b[44110]] == 0x1 ? busk96(!![]) : (busk96(![]), console[b[40078]](b[69319] + ju3qsn[b[40011]][b[69320]])) : console[b[40482]](b[52137], ju3qsn);
  });
}, window['e110UG'] = function (c7ma4_) {
  console[b[40482]](b[69321], c7ma4_);
}, window['e11U0'] = function (j3gi) {}, window['e110U'] = function (jnq, rfyzvh, suj3) {}, window['e110'] = function (xtjg) {
  console[b[40482]](b[69322], xtjg), window[b[69201]][b[40148]][b[69323]](), window[b[69201]][b[40148]][b[69324]](), window[b[69201]][b[40148]][b[69325]]();
}, window['e101'] = function (gth$xl) {
  window['e11GU0'](b[69326]);var suq93n = { 'id': window['e1U0'][b[69191]], 'role': window['e1U0'][b[44633]], 'level': window['e1U0'][b[69192]], 'account': window['e1U0'][b[65226]], 'version': window['e1U0'][b[40101]], 'cdn': window['e1U0'][b[44511]], 'pkgName': window['e1U0'][b[65227]], 'gamever': window[b[40557]][b[69186]], 'serverid': window['e1U0'][b[65221]] ? window['e1U0'][b[65221]][b[51515]] : 0x0, 'systemInfo': window[b[69193]], 'error': b[69327], 'stack': gth$xl ? gth$xl : b[69326] },
      mac7_o = JSON[b[44497]](suq93n);console[b[40125]](b[69328] + mac7_o), window['e11U'](mac7_o);
}, window['e1U10'] = function (moac_7) {
  var cmapo = JSON[b[40527]](moac_7);cmapo[b[69329]] = window[b[40557]][b[69186]], cmapo[b[69330]] = window['e1U0'][b[65221]] ? window['e1U0'][b[65221]][b[51515]] : 0x0, cmapo[b[69193]] = window[b[69193]];var gxrthl = JSON[b[44497]](cmapo);console[b[40125]](b[69331] + gxrthl), window['e11U'](gxrthl);
}, window['e1U01'] = function (dbk96, i3junq) {
  var yrzf = { 'id': window['e1U0'][b[69191]], 'role': window['e1U0'][b[44633]], 'level': window['e1U0'][b[69192]], 'account': window['e1U0'][b[65226]], 'version': window['e1U0'][b[40101]], 'cdn': window['e1U0'][b[44511]], 'pkgName': window['e1U0'][b[65227]], 'gamever': window[b[40557]][b[69186]], 'serverid': window['e1U0'][b[65221]] ? window['e1U0'][b[65221]][b[51515]] : 0x0, 'systemInfo': window[b[69193]], 'error': dbk96, 'stack': i3junq },
      bd65 = JSON[b[44497]](yrzf);console[b[40096]](b[69332] + bd65), window['e11U'](bd65);
}, window['e11U'] = function (f_vz4y) {
  if (window['e1U0'][b[69259]] == b[69333]) return;var s69k0 = e1U0['e11U'] + b[69334] + e1U0[b[65226]];wx[b[40477]]({ 'url': s69k0, 'method': b[68731], 'data': f_vz4y, 'header': { 'content-type': b[69335], 'cache-control': b[69336] }, 'success': function (snqj3) {
      DEBUG && console[b[40482]](b[69337], s69k0, f_vz4y, snqj3);
    }, 'fail': function (gi$tlx) {
      DEBUG && console[b[40482]](b[69337], s69k0, f_vz4y, gi$tlx);
    }, 'complete': function () {} });
}, window[b[69338]] = function () {
  function zyfv() {
    return ((0x1 + Math[b[40119]]()) * 0x10000 | 0x0)[b[40275]](0x10)[b[40500]](0x1);
  }return zyfv() + zyfv() + '-' + zyfv() + '-' + zyfv() + '-' + zyfv() + '+' + zyfv() + zyfv() + zyfv();
}, window['e1U1'] = function () {
  console[b[40482]](b[69339]);var d60bk5 = ebk05d[b[69340]]();e1U0[b[65225]] = d60bk5[b[69341]], e1U0[b[69305]] = d60bk5[b[69341]], e1U0[b[63632]] = d60bk5[b[69341]], e1U0[b[65227]] = d60bk5[b[69342]];var qu3njs = { 'game_ver': e1U0[b[44704]] };e1U0[b[65229]] = this[b[69338]](), e11UG0({ 'title': b[69343] }), ebk05d[b[40368]](qu3njs, this['e101U'][b[40074]](this));
}, window['e101U'] = function (_m4) {
  var a7f4 = _m4[b[69344]];console[b[40482]](b[69345] + a7f4 + b[69346] + (a7f4 == 0x1) + b[69347] + _m4[b[69186]] + b[69348] + window[b[69286]][b[69292]]);if (!_m4[b[69186]] || window['e1IG01U'](window[b[69286]][b[69292]], _m4[b[69186]]) < 0x0) console[b[40482]](b[69349]), e1U0[b[69295]] = b[69350], e1U0[b[69297]] = b[69351], e1U0[b[69299]] = b[69352], e1U0[b[44511]] = b[69353], e1U0[b[64931]] = b[69354], e1U0[b[69355]] = 'fj', e1U0[b[40738]] = ![];else window['e1IG01U'](window[b[69286]][b[69292]], _m4[b[69186]]) == 0x0 ? (console[b[40482]](b[69356]), e1U0[b[69295]] = b[69296], e1U0[b[69297]] = b[69298], e1U0[b[69299]] = b[69300], e1U0[b[44511]] = b[69357], e1U0[b[64931]] = b[69354], e1U0[b[69355]] = b[69358], e1U0[b[40738]] = !![]) : (console[b[40482]](b[69359]), e1U0[b[69295]] = b[69296], e1U0[b[69297]] = b[69298], e1U0[b[69299]] = b[69300], e1U0[b[44511]] = b[69357], e1U0[b[64931]] = b[69354], e1U0[b[69355]] = b[69358], e1U0[b[40738]] = ![]);e1U0[b[69303]] = config[b[69064]] ? config[b[69064]] : 0x0, this['e1GU10'](), this['e1GU01'](), window[b[69360]] = 0x5, e11UG0({ 'title': b[69361] }), ebk05d[b[68578]](this['e10U1'][b[40074]](this));
}, window[b[69360]] = 0x5, window['e10U1'] = function (d0685, oc_ma7) {
  if (d0685 == 0x0 && oc_ma7 && oc_ma7[b[69156]]) {
    e1U0[b[69362]] = oc_ma7[b[69156]];var zrglth = this;e11UG0({ 'title': b[69363] }), sendApi(e1U0[b[69295]], b[69364], { 'platform': e1U0[b[69293]], 'partner_id': e1U0[b[63632]], 'token': oc_ma7[b[69156]], 'game_pkg': e1U0[b[65227]], 'deviceId': e1U0[b[65229]], 'scene': b[69365] + e1U0[b[69303]] }, this['e1G1U0'][b[40074]](this), e1G0U, e101);
  } else oc_ma7 && oc_ma7[b[65410]] && window[b[69360]] > 0x0 && (oc_ma7[b[65410]][b[40115]](b[69366]) != -0x1 || oc_ma7[b[65410]][b[40115]](b[69367]) != -0x1 || oc_ma7[b[65410]][b[40115]](b[69368]) != -0x1 || oc_ma7[b[65410]][b[40115]](b[69369]) != -0x1 || oc_ma7[b[65410]][b[40115]](b[69370]) != -0x1 || oc_ma7[b[65410]][b[40115]](b[69371]) != -0x1) ? (window[b[69360]]--, ebk05d[b[68578]](this['e10U1'][b[40074]](this))) : (window['e1U01'](b[69372], JSON[b[44497]]({ 'status': d0685, 'data': oc_ma7 })), window['e11GU0'](b[69373] + (oc_ma7 && oc_ma7[b[65410]] ? '，' + oc_ma7[b[65410]] : '')));
}, window['e1G1U0'] = function (sbu96k) {
  if (!sbu96k) {
    window['e1U01'](b[69374], b[69375]), window['e11GU0'](b[69376]);return;
  }if (sbu96k[b[44110]] != b[49925]) {
    window['e1U01'](b[69374], JSON[b[44497]](sbu96k)), window['e11GU0'](b[69377] + sbu96k[b[44110]]);return;
  }e1U0[b[63631]] = String(sbu96k[b[65226]]), e1U0[b[65226]] = String(sbu96k[b[65226]]), e1U0[b[65198]] = String(sbu96k[b[65198]]), e1U0[b[65225]] = String(sbu96k[b[65198]]), e1U0[b[65228]] = String(sbu96k[b[65228]]), e1U0[b[69378]] = String(sbu96k[b[51498]]), e1U0[b[69379]] = String(sbu96k[b[40851]]), e1U0[b[51498]] = '';var cmpae = this;e11UG0({ 'title': b[69380] }), sendApi(e1U0[b[69295]], b[69381], { 'partner_id': e1U0[b[63632]], 'uid': e1U0[b[65226]], 'version': e1U0[b[44704]], 'game_pkg': e1U0[b[65227]], 'device': e1U0[b[65229]] }, cmpae['e1G10U'][b[40074]](cmpae), e1G0U, e101);
}, window['e1G10U'] = function (nqj3iu) {
  if (!nqj3iu) {
    window['e11GU0'](b[69382]);return;
  }if (nqj3iu[b[44110]] != b[49925]) {
    window['e11GU0'](b[69383] + nqj3iu[b[44110]]);return;
  }if (!nqj3iu[b[40011]] || nqj3iu[b[40011]][b[40013]] == 0x0) {
    window['e11GU0'](b[69384]);return;
  }e1U0[b[40630]] = nqj3iu[b[69385]], e1U0[b[65221]] = { 'server_id': String(nqj3iu[b[40011]][0x0][b[51515]]), 'server_name': String(nqj3iu[b[40011]][0x0][b[69386]]), 'entry_ip': nqj3iu[b[40011]][0x0][b[65249]], 'entry_port': parseInt(nqj3iu[b[40011]][0x0][b[65250]]), 'status': e1UG1(nqj3iu[b[40011]][0x0]), 'start_time': nqj3iu[b[40011]][0x0][b[69387]], 'cdn': e1U0[b[44511]] }, this['e10UG1']();
}, window['e10UG1'] = function () {
  if (e1U0[b[40630]] == 0x1) {
    var ix3jg = e1U0[b[65221]][b[40106]];if (ix3jg === -0x1 || ix3jg === 0x0) {
      window['e11GU0'](ix3jg === -0x1 ? b[69388] : b[69389]);return;
    }e101GU(0x0, e1U0[b[65221]][b[51515]]), window[b[69201]][b[40148]][b[69390]](e1U0[b[40630]]);
  } else window[b[69201]][b[40148]][b[69391]](), e11U0G();window['e1UG'] = !![], window['e10GU1'](), window['e10U1G']();
}, window['e1GU10'] = function () {
  sendApi(e1U0[b[69295]], b[69392], { 'game_pkg': e1U0[b[65227]], 'version_name': e1U0[b[69355]] }, this[b[69393]][b[40074]](this), e1G0U, e101);
}, window[b[69393]] = function (b6s9k0) {
  if (!b6s9k0) {
    window['e11GU0'](b[69394]);return;
  }if (b6s9k0[b[44110]] != b[49925]) {
    window['e11GU0'](b[69395] + b6s9k0[b[44110]]);return;
  }if (!b6s9k0[b[40011]] || !b6s9k0[b[40011]][b[44704]]) {
    window['e11GU0'](b[69396] + (b6s9k0[b[40011]] && b6s9k0[b[40011]][b[44704]]));return;
  }b6s9k0[b[40011]][b[69397]] && b6s9k0[b[40011]][b[69397]][b[40013]] > 0xa && (e1U0[b[69398]] = b6s9k0[b[40011]][b[69397]], e1U0[b[44511]] = b6s9k0[b[40011]][b[69397]]), b6s9k0[b[40011]][b[44704]] && (e1U0[b[40101]] = b6s9k0[b[40011]][b[44704]]), console[b[40078]](b[65363] + e1U0[b[40101]] + b[69399] + e1U0[b[69355]]), window['e1U0G'] = !![], window['e10GU1'](), window['e10U1G']();
}, window[b[69400]], window['e1GU01'] = function () {
  sendApi(e1U0[b[69295]], b[69401], { 'game_pkg': e1U0[b[65227]] }, this['e1G01U'][b[40074]](this), e1G0U, e101);
}, window['e1G01U'] = function (flyrhz) {
  if (flyrhz[b[44110]] === b[49925] && flyrhz[b[40011]]) {
    window[b[69400]] = flyrhz[b[40011]];for (var n39qus in flyrhz[b[40011]]) {
      e1U0[n39qus] = flyrhz[b[40011]][n39qus];
    }
  } else console[b[40078]](b[69402] + flyrhz[b[44110]]);window['e1GU'] = !![], window['e10U1G']();
}, window[b[69403]] = function (trzly, f_z4yv, vf_4y, a7mc_o, opemac, xlh$t, x$lht, j$tix, v_47m) {
  opemac = String(opemac);var wd = x$lht,
      grzhtl = j$tix;e1U0[b[69291]][opemac] = { 'productid': opemac, 'productname': wd, 'productdesc': grzhtl, 'roleid': trzly, 'rolename': f_z4yv, 'rolelevel': vf_4y, 'price': xlh$t, 'callback': v_47m }, sendApi(e1U0[b[69299]], b[69404], { 'game_pkg': e1U0[b[65227]], 'server_id': e1U0[b[65221]][b[51515]], 'server_name': e1U0[b[65221]][b[69386]], 'level': vf_4y, 'uid': e1U0[b[65226]], 'role_id': trzly, 'role_name': f_z4yv, 'product_id': opemac, 'product_name': wd, 'product_desc': grzhtl, 'money': xlh$t, 'partner_id': e1U0[b[63632]] }, toPayCallBack, e1G0U, e101);
}, window[b[69405]] = function (w085d) {
  if (w085d) {
    if (w085d[b[69406]] === 0xc8 || w085d[b[44110]] == b[49925]) {
      var xjqi3 = e1U0[b[69291]][String(w085d[b[69407]])];if (xjqi3[b[40335]]) xjqi3[b[40335]](w085d[b[69407]], w085d[b[69408]], -0x1);ebk05d[b[68763]]({ 'cpbill': w085d[b[69408]], 'productid': w085d[b[69407]], 'productname': xjqi3[b[69409]], 'productdesc': xjqi3[b[69410]], 'serverid': e1U0[b[65221]][b[51515]], 'servername': e1U0[b[65221]][b[69386]], 'roleid': xjqi3[b[69411]], 'rolename': xjqi3[b[69412]], 'rolelevel': xjqi3[b[69413]], 'price': xjqi3[b[66920]], 'extension': JSON[b[44497]]({ 'cp_order_id': w085d[b[69408]] }) }, function (fy7v4_, aepo) {
        xjqi3[b[40335]] && fy7v4_ == 0x0 && xjqi3[b[40335]](w085d[b[69407]], w085d[b[69408]], fy7v4_);console[b[40078]](JSON[b[44497]]({ 'type': b[69414], 'status': fy7v4_, 'data': w085d, 'role_name': xjqi3[b[69412]] }));if (fy7v4_ === 0x0) {} else {
          if (fy7v4_ === 0x1) {} else {
            if (fy7v4_ === 0x2) {}
          }
        }
      });
    } else alert(w085d[b[40078]]);
  }
}, window['e1G0U1'] = function () {}, window['e11G0'] = function (uqnk, itgl$x, rtzyh, us39, xjitg) {
  ebk05d[b[68782]](e1U0[b[65221]][b[51515]], e1U0[b[65221]][b[69386]] || e1U0[b[65221]][b[51515]], uqnk, itgl$x, rtzyh), sendApi(e1U0[b[69295]], b[69415], { 'game_pkg': e1U0[b[65227]], 'server_id': e1U0[b[65221]][b[51515]], 'role_id': uqnk, 'uid': e1U0[b[65226]], 'role_name': itgl$x, 'role_type': us39, 'level': rtzyh });
}, window['e110G'] = function ($gjti, sbk6u9, q3snu9, uq9skn, m_ao, kd60, v_74am, rzyv4, v4fyz, eocpa) {
  e1U0[b[69191]] = $gjti, e1U0[b[44633]] = sbk6u9, e1U0[b[69192]] = q3snu9, ebk05d[b[68783]](e1U0[b[65221]][b[51515]], e1U0[b[65221]][b[69386]] || e1U0[b[65221]][b[51515]], $gjti, sbk6u9, q3snu9), sendApi(e1U0[b[69295]], b[69416], { 'game_pkg': e1U0[b[65227]], 'server_id': e1U0[b[65221]][b[51515]], 'role_id': $gjti, 'uid': e1U0[b[65226]], 'role_name': sbk6u9, 'role_type': uq9skn, 'level': q3snu9, 'evolution': m_ao });
}, window['e1G10'] = function ($i3nj, vyrf4, om_ac7, u69kns, apcom, xigl, hztlgr, b0dw8, jun3, va4_f) {
  e1U0[b[69191]] = $i3nj, e1U0[b[44633]] = vyrf4, e1U0[b[69192]] = om_ac7, ebk05d[b[68784]](e1U0[b[65221]][b[51515]], e1U0[b[65221]][b[69386]] || e1U0[b[65221]][b[51515]], $i3nj, vyrf4, om_ac7), sendApi(e1U0[b[69295]], b[69416], { 'game_pkg': e1U0[b[65227]], 'server_id': e1U0[b[65221]][b[51515]], 'role_id': $i3nj, 'uid': e1U0[b[65226]], 'role_name': vyrf4, 'role_type': u69kns, 'level': om_ac7, 'evolution': apcom });
}, window['e1G01'] = function (u69skn) {}, window['e11G'] = function (rflzyh) {
  ebk05d[b[68702]](b[68702], function (skb0) {
    rflzyh && rflzyh(skb0);
  });
}, window[b[64911]] = function () {
  ebk05d[b[64911]]();
}, window[b[69417]] = function () {
  ebk05d[b[63524]]();
}, window[b[69418]] = function (empoa, v_7y4f, xgi$j3, fyrhv, zfry4v, glxi$, ytlrz, bs9uk6) {
  bs9uk6 = bs9uk6 || e1U0[b[65221]][b[51515]], sendApi(e1U0[b[69295]], b[69419], { 'phone': empoa, 'role_id': v_7y4f, 'uid': e1U0[b[65226]], 'game_pkg': e1U0[b[65227]], 'partner_id': e1U0[b[63632]], 'server_id': bs9uk6 }, ytlrz);
}, window[b[50847]] = function (f7a_) {
  window['e101G'] = f7a_, window['e101G'] && window['e1G1'] && (console[b[40078]](b[69278] + window['e1G1'][b[40776]]), window['e101G'](window['e1G1']), window['e1G1'] = null);
}, window['e10G1'] = function (x$tlhg, j3$inq, s6bku9, ompec) {
  window[b[40022]](b[69420], { 'game_pkg': window['e1U0'][b[65227]], 'role_id': j3$inq, 'server_id': s6bku9 }, ompec);
}, window['e1U1G0'] = function (lhfyrz, a47_vm) {
  function f7v_4(lrfyhz) {
    var yzf_4 = [],
        trhlzg = [],
        xigjt = window[b[40557]][b[69421]];for (var _7m4ac in xigjt) {
      var jqun3 = Number(_7m4ac);(!lhfyrz || !lhfyrz[b[40013]] || lhfyrz[b[40115]](jqun3) != -0x1) && (trhlzg[b[40029]](xigjt[_7m4ac]), yzf_4[b[40029]]([jqun3, 0x3]));
    }window['e1IG01U'](window[b[69202]], b[69422]) >= 0x0 ? (console[b[40482]](b[69423]), ebk05d[b[69424]] && ebk05d[b[69424]](trhlzg, function (iuj3q) {
      console[b[40482]](b[69425]), console[b[40482]](iuj3q);if (iuj3q && iuj3q[b[65410]] == b[69426]) for (var mac7_ in xigjt) {
        if (iuj3q[xigjt[mac7_]] == b[69427]) {
          var b8d06 = Number(mac7_);for (var yv4rfz = 0x0; yv4rfz < yzf_4[b[40013]]; yv4rfz++) {
            if (yzf_4[yv4rfz][0x0] == b8d06) {
              yzf_4[yv4rfz][0x1] = 0x1;break;
            }
          }
        }
      }window['e1IG01U'](window[b[69202]], b[69428]) >= 0x0 ? wx[b[69429]]({ 'withSubscriptions': !![], 'success': function (nuqi3j) {
          var fzhlry = nuqi3j[b[69430]][b[69431]];if (fzhlry) {
            console[b[40482]](b[69432]), console[b[40482]](fzhlry);for (var x$ilt in xigjt) {
              if (fzhlry[xigjt[x$ilt]] == b[69427]) {
                var m7c_o = Number(x$ilt);for (var nqs9 = 0x0; nqs9 < yzf_4[b[40013]]; nqs9++) {
                  if (yzf_4[nqs9][0x0] == m7c_o) {
                    yzf_4[nqs9][0x1] = 0x2;break;
                  }
                }
              }
            }console[b[40482]](yzf_4), a47_vm && a47_vm(yzf_4);
          } else console[b[40482]](b[69433]), console[b[40482]](nuqi3j), console[b[40482]](yzf_4), a47_vm && a47_vm(yzf_4);
        }, 'fail': function () {
          console[b[40482]](b[69434]), console[b[40482]](yzf_4), a47_vm && a47_vm(yzf_4);
        } }) : (console[b[40482]](b[69435] + window[b[69202]]), console[b[40482]](yzf_4), a47_vm && a47_vm(yzf_4));
    })) : (console[b[40482]](b[69436] + window[b[69202]]), console[b[40482]](yzf_4), a47_vm && a47_vm(yzf_4)), wx[b[69437]](f7v_4);
  }wx[b[69438]](f7v_4);
}, window['e1U10G'] = { 'isSuccess': ![], 'level': b[69439], 'isCharging': ![] }, window['e1UG10'] = function (quji) {
  wx[b[69267]]({ 'success': function (fyrvh) {
      var xl$thg = window['e1U10G'];xl$thg[b[69440]] = !![], xl$thg[b[44609]] = Number(fyrvh[b[44609]])[b[44225]](0x0), xl$thg[b[69270]] = fyrvh[b[69270]], quji && quji(xl$thg[b[69440]], xl$thg[b[44609]], xl$thg[b[69270]]);
    }, 'fail': function (htylrz) {
      console[b[40482]](b[69441], htylrz[b[65410]]);var xj$tgi = window['e1U10G'];quji && quji(xj$tgi[b[69440]], xj$tgi[b[44609]], xj$tgi[b[69270]]);
    } });
}, window[b[40022]] = function (rxglh, ni3uq, a_7mv, bw8, _m4ac, lxtg$i, igl$tx, $itx) {
  if (bw8 == undefined) bw8 = 0x1;wx[b[40477]]({ 'url': rxglh, 'method': igl$tx || b[65117], 'responseType': b[44421], 'data': ni3uq, 'header': { 'content-type': $itx || b[69335] }, 'success': function (s3nuq) {
      DEBUG && console[b[40482]](b[69442], rxglh, info, s3nuq);if (s3nuq && s3nuq[b[65479]] == 0xc8) {
        var zfhrl = s3nuq[b[40011]];!lxtg$i || lxtg$i(zfhrl) ? a_7mv && a_7mv(zfhrl) : window[b[69443]](rxglh, ni3uq, a_7mv, bw8, _m4ac, lxtg$i, s3nuq);
      } else window[b[69443]](rxglh, ni3uq, a_7mv, bw8, _m4ac, lxtg$i, s3nuq);
    }, 'fail': function (cm7oa_) {
      DEBUG && console[b[40482]](b[69444], rxglh, info, cm7oa_), window[b[69443]](rxglh, ni3uq, a_7mv, bw8, _m4ac, lxtg$i, cm7oa_);
    }, 'complete': function () {} });
}, window[b[69443]] = function (flzryh, b6kd05, ma74_, c7_m4, zrtlyh, qkun9s, ixj3g$) {
  c7_m4 - 0x1 > 0x0 ? setTimeout(function () {
    window[b[40022]](flzryh, b6kd05, ma74_, c7_m4 - 0x1, zrtlyh, qkun9s);
  }, 0x3e8) : zrtlyh && zrtlyh(JSON[b[44497]]({ 'url': flzryh, 'response': ixj3g$ }));
}, window[b[69445]] = function (hflryz, b09kd, w21d58, pcoa, vyrfzh, q9k, ltrgxh) {
  !w21d58 && (w21d58 = {});var emp = Math[b[40118]](Date[b[40083]]() / 0x3e8);w21d58[b[40851]] = emp, w21d58[b[69446]] = b09kd;var moacp7 = Object[b[40267]](w21d58)[b[41078]](),
      yv4r = '',
      zfy4_ = '';for (var $txjg = 0x0; $txjg < moacp7[b[40013]]; $txjg++) {
    yv4r = yv4r + ($txjg == 0x0 ? '' : '&') + moacp7[$txjg] + w21d58[moacp7[$txjg]], zfy4_ = zfy4_ + ($txjg == 0x0 ? '' : '&') + moacp7[$txjg] + '=' + encodeURIComponent(w21d58[moacp7[$txjg]]);
  }yv4r = yv4r + e1U0[b[69301]];var yfv47_ = b[69447] + md5(yv4r);send(hflryz + '?' + zfy4_ + (zfy4_ == '' ? '' : '&') + yfv47_, null, pcoa, vyrfzh, q9k, ltrgxh || function (q3ujin) {
    return q3ujin[b[44110]] == b[49925];
  }, null, b[68604]);
}, window['e1UG01'] = function (bd, aeopm) {
  var qjn3iu = 0x0;e1U0[b[65221]] && (qjn3iu = e1U0[b[65221]][b[51515]]), sendApi(e1U0[b[69297]], b[69448], { 'partnerId': e1U0[b[63632]], 'gamePkg': e1U0[b[65227]], 'logTime': Math[b[40118]](Date[b[40083]]() / 0x3e8), 'platformUid': e1U0[b[65228]], 'type': bd, 'serverId': qjn3iu }, null, 0x2, null, function () {
    return !![];
  });
}, window['e1U01G'] = function (i3jq) {
  sendApi(e1U0[b[69295]], b[69449], { 'partner_id': e1U0[b[63632]], 'uid': e1U0[b[65226]], 'version': e1U0[b[44704]], 'game_pkg': e1U0[b[65227]], 'device': e1U0[b[65229]] }, e1U0G1, e1G0U, e101);
}, window['e1U0G1'] = function (ixg$jt) {
  if (ixg$jt[b[44110]] === b[49925] && ixg$jt[b[40011]]) {
    ixg$jt[b[40011]][b[45586]]({ 'id': -0x2, 'name': b[69450] }), ixg$jt[b[40011]][b[45586]]({ 'id': -0x1, 'name': b[69451] }), e1U0[b[69452]] = ixg$jt[b[40011]];if (window[b[52309]]) window[b[52309]][b[69453]]();
  } else e1U0[b[69454]] = ![], window['e11GU0'](b[69455] + ixg$jt[b[44110]]);
}, window['e11GU'] = function (_a7vf4) {
  sendApi(e1U0[b[69295]], b[69456], { 'partner_id': e1U0[b[63632]], 'uid': e1U0[b[65226]], 'version': e1U0[b[44704]], 'game_pkg': e1U0[b[65227]], 'device': e1U0[b[65229]] }, e11UG, e1G0U, e101);
}, window['e11UG'] = function (j$g) {
  e1U0[b[69457]] = ![];if (j$g[b[44110]] === b[49925] && j$g[b[40011]]) {
    for (var rzfy4 = 0x0; rzfy4 < j$g[b[40011]][b[40013]]; rzfy4++) {
      j$g[b[40011]][rzfy4][b[40106]] = e1UG1(j$g[b[40011]][rzfy4]);
    }e1U0[b[69304]][-0x1] = window[b[69458]](j$g[b[40011]]), window[b[52309]][b[69459]](-0x1);
  } else window['e11GU0'](b[69460] + j$g[b[44110]]);
}, window[b[69461]] = function (p7maoc) {
  sendApi(e1U0[b[69295]], b[69456], { 'partner_id': e1U0[b[63632]], 'uid': e1U0[b[65226]], 'version': e1U0[b[44704]], 'game_pkg': e1U0[b[65227]], 'device': e1U0[b[65229]] }, p7maoc, e1G0U, e101);
}, window['e1G1U'] = function (hyrtlz, x$tigj) {
  sendApi(e1U0[b[69295]], b[69462], { 'partner_id': e1U0[b[63632]], 'uid': e1U0[b[65226]], 'version': e1U0[b[44704]], 'game_pkg': e1U0[b[65227]], 'device': e1U0[b[65229]], 'server_group_id': x$tigj }, e1GU1, e1G0U, e101);
}, window['e1GU1'] = function (pcao) {
  e1U0[b[69457]] = ![];if (pcao[b[44110]] === b[49925] && pcao[b[40011]] && pcao[b[40011]][b[40011]]) {
    var nsu69k = pcao[b[40011]][b[69463]],
        af = [];for (var b506kd = 0x0; b506kd < pcao[b[40011]][b[40011]][b[40013]]; b506kd++) {
      pcao[b[40011]][b[40011]][b506kd][b[40106]] = e1UG1(pcao[b[40011]][b[40011]][b506kd]), (af[b[40013]] == 0x0 || pcao[b[40011]][b[40011]][b506kd][b[40106]] != 0x0) && (af[af[b[40013]]] = pcao[b[40011]][b[40011]][b506kd]);
    }e1U0[b[69304]][nsu69k] = window[b[69458]](af), window[b[52309]][b[69459]](nsu69k);
  } else window['e11GU0'](b[69464] + pcao[b[44110]]);
}, window['e1IG0U'] = function (s09b) {
  sendApi(e1U0[b[69295]], b[69465], { 'partner_id': e1U0[b[63632]], 'uid': e1U0[b[65226]], 'version': e1U0[b[44704]], 'game_pkg': e1U0[b[65227]], 'device': e1U0[b[65229]] }, reqServerRecommendCallBack, e1G0U, e101);
}, window[b[69466]] = function (_ocm) {
  e1U0[b[69457]] = ![];if (_ocm[b[44110]] === b[49925] && _ocm[b[40011]]) {
    for (var v7a_4 = 0x0; v7a_4 < _ocm[b[40011]][b[40013]]; v7a_4++) {
      _ocm[b[40011]][v7a_4][b[40106]] = e1UG1(_ocm[b[40011]][v7a_4]);
    }e1U0[b[69304]][-0x2] = window[b[69458]](_ocm[b[40011]]), window[b[52309]][b[69459]](-0x2);
  } else alert(b[69467] + _ocm[b[44110]]);
}, window[b[69458]] = function (u39nsq) {
  if (!u39nsq && u39nsq[b[40013]] <= 0x0) return u39nsq;for (let s69un = 0x0; s69un < u39nsq[b[40013]]; s69un++) {
    u39nsq[s69un][b[69468]] && u39nsq[s69un][b[69468]] == 0x1 && (u39nsq[s69un][b[69386]] += b[69469]);
  }return u39nsq;
}, window['e1U1G'] = function (yrz, a47_mv) {
  yrz = yrz || e1U0[b[65221]][b[51515]], sendApi(e1U0[b[69295]], b[69470], { 'type': '4', 'game_pkg': e1U0[b[65227]], 'server_id': yrz }, a47_mv);
}, window[b[69471]] = function (ac74_m, xgl$, zthyr, y7_v4f) {
  zthyr = zthyr || e1U0[b[65221]][b[51515]], sendApi(e1U0[b[69295]], b[69472], { 'type': ac74_m, 'game_pkg': xgl$, 'server_id': zthyr }, y7_v4f);
}, window['e1UG1'] = function (ghxtr) {
  if (ghxtr) {
    if (ghxtr[b[40106]] == 0x1) {
      if (ghxtr[b[69473]] == 0x1) return 0x2;else return 0x1;
    } else return ghxtr[b[40106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['e101GU'] = function (hrlzyf, fhyl) {
  e1U0[b[69474]] = { 'step': hrlzyf, 'server_id': fhyl };var w58d02 = this;e11UG0({ 'title': b[69475] }), sendApi(e1U0[b[69295]], b[69476], { 'partner_id': e1U0[b[63632]], 'uid': e1U0[b[65226]], 'game_pkg': e1U0[b[65227]], 'server_id': fhyl, 'platform': e1U0[b[65198]], 'platform_uid': e1U0[b[65228]], 'check_login_time': e1U0[b[69379]], 'check_login_sign': e1U0[b[69378]], 'version_name': e1U0[b[69355]] }, e101UG, e1G0U, e101, function (f7av4_) {
    return f7av4_[b[44110]] == b[49925] || f7av4_[b[40078]] == b[69477] || f7av4_[b[40078]] == b[69478];
  });
}, window['e101UG'] = function (tgli$x) {
  var jni$3q = this;if (tgli$x[b[44110]] === b[49925] && tgli$x[b[40011]]) {
    var d8wb50 = e1U0[b[65221]];d8wb50[b[69479]] = e1U0[b[69305]], d8wb50[b[51498]] = String(tgli$x[b[40011]][b[69480]]), d8wb50[b[65200]] = parseInt(tgli$x[b[40011]][b[40851]]);if (tgli$x[b[40011]][b[65199]]) d8wb50[b[65199]] = parseInt(tgli$x[b[40011]][b[65199]]);else d8wb50[b[65199]] = parseInt(tgli$x[b[40011]][b[51515]]);d8wb50[b[69481]] = 0x0, d8wb50[b[44511]] = e1U0[b[69398]], d8wb50[b[69482]] = tgli$x[b[40011]][b[69483]], d8wb50[b[69484]] = tgli$x[b[40011]][b[69484]], console[b[40482]](b[69485] + JSON[b[44497]](d8wb50[b[69484]])), e1U0[b[40630]] == 0x1 && d8wb50[b[69484]] && d8wb50[b[69484]][b[69486]] == 0x1 && (e1U0[b[69487]] = 0x1, window[b[69201]][b[40148]]['e1I0U']()), e10G1U();
  } else e1U0[b[69474]][b[47127]] >= 0x3 ? (e101(JSON[b[44497]](tgli$x)), window['e11GU0'](b[69488] + tgli$x[b[44110]])) : sendApi(e1U0[b[69295]], b[69364], { 'platform': e1U0[b[69293]], 'partner_id': e1U0[b[63632]], 'token': e1U0[b[69362]], 'game_pkg': e1U0[b[65227]], 'deviceId': e1U0[b[65229]], 'scene': b[69365] + e1U0[b[69303]] }, function (f4_yv7) {
    if (!f4_yv7 || f4_yv7[b[44110]] != b[49925]) {
      window['e11GU0'](b[69377] + f4_yv7 && f4_yv7[b[44110]]);return;
    }e1U0[b[69378]] = String(f4_yv7[b[51498]]), e1U0[b[69379]] = String(f4_yv7[b[40851]]), setTimeout(function () {
      e101GU(e1U0[b[69474]][b[47127]] + 0x1, e1U0[b[69474]][b[51515]]);
    }, 0x5dc);
  }, e1G0U, e101, function (rlhyf) {
    return rlhyf[b[44110]] == b[49925] || rlhyf[b[44110]] == b[65558];
  });
}, window['e10G1U'] = function () {
  ServerLoading[b[40148]][b[69390]](e1U0[b[40630]]), window['e1G0'] = !![], window['e10U1G']();
}, window['e10GU1'] = function () {
  if (window['e10G'] && window['e1UG0'] && window[b[69311]] && window[b[69312]] && window['e1U0G'] && window['e1UG']) {
    if (!window[b[68480]][b[40148]]) {
      console[b[40482]](b[69489] + window[b[68480]][b[40148]]);var zvhryf = wx[b[68786]](),
          q3ix$ = zvhryf[b[40776]] ? zvhryf[b[40776]] : 0x0,
          iquj3 = { 'cdn': window['e1U0'][b[44511]], 'spareCdn': window['e1U0'][b[64931]], 'newRegister': window['e1U0'][b[40630]], 'wxPC': window['e1U0'][b[64934]], 'wxIOS': window['e1U0'][b[41074]], 'wxAndroid': window['e1U0'][b[51337]], 'wxParam': { 'limitLoad': window['e1U0']['e1I1G0U'], 'benchmarkLevel': window['e1U0']['e1I1UG0'], 'wxFrom': window[b[40557]][b[69064]] == b[69490] ? 0x1 : 0x0, 'wxSDKVersion': window[b[69202]] }, 'configType': window['e1U0'][b[51861]], 'exposeType': window['e1U0'][b[40714]], 'scene': q3ix$ };new window[b[68480]](iquj3, window['e1U0'][b[40101]], window['e1I1GU0']);
    }
  }
}, window['e10U1G'] = function () {
  if (window['e10G'] && window['e1UG0'] && window[b[69311]] && window[b[69312]] && window['e1U0G'] && window['e1UG'] && window['e1G0'] && window['e1GU']) {
    e11U0G();if (!e10GU) {
      e10GU = !![];if (!window[b[68480]][b[40148]]) window['e10GU1']();var cpomea = 0x0,
          _caom7 = wx[b[69491]]();_caom7 && (window['e1U0'][b[69257]] && (cpomea = _caom7[b[40323]]), console[b[40078]](b[69492] + _caom7[b[40323]] + b[69493] + _caom7[b[41216]] + b[69494] + _caom7[b[41218]] + b[69495] + _caom7[b[41217]] + b[69496] + _caom7[b[40176]] + b[69497] + _caom7[b[40177]]));var nj3ui = {};for (const hty in e1U0[b[65221]]) {
        nj3ui[hty] = e1U0[b[65221]][hty];
      }var amecpo = { 'channel': window['e1U0'][b[65225]], 'account': window['e1U0'][b[65226]], 'userId': window['e1U0'][b[63631]], 'serverId': nj3ui[b[51515]], 'cdn': window['e1U0'][b[44511]], 'data': window['e1U0'][b[40011]], 'package': window['e1U0'][b[64932]], 'newRegister': window['e1U0'][b[40630]], 'pkgName': window['e1U0'][b[65227]], 'partnerId': window['e1U0'][b[63632]], 'platform_uid': window['e1U0'][b[65228]], 'deviceId': window['e1U0'][b[65229]], 'selectedServer': nj3ui, 'configType': window['e1U0'][b[51861]], 'exposeType': window['e1U0'][b[40714]], 'debugUsers': window['e1U0'][b[52259]], 'wxMenuTop': cpomea, 'wxShield': window['e1U0'][b[40738]] };if (window[b[69400]]) for (var q3xj in window[b[69400]]) {
        amecpo[q3xj] = window[b[69400]][q3xj];
      }window[b[68480]][b[40148]]['e10UI'](amecpo);
    }
  } else console[b[40078]](b[69498] + window['e10G'] + b[69499] + window['e1UG0'] + b[69500] + window[b[69311]] + b[69501] + window[b[69312]] + b[69502] + window['e1U0G'] + b[69503] + window['e1UG'] + b[69504] + window['e1G0'] + b[69505] + window['e1GU']);
};