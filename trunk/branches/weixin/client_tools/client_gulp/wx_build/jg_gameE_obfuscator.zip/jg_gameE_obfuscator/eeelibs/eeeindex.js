var b = wx.$e;
import esn3u9 from '../eeeesdk/eeesdk.js';window[b[70231]] = { 'wxVersion': window[b[40588]][b[70115]] }, window[b[70232]] = ![], window[b[70233]] = 0x1, window[b[70234]] = 0x1, window[b[70235]] = !![], window[b[70236]] = !![], window[b[70237]] = '', window[b[70238]] = ![], window[b[70120]] = { 'base_cdn': b[70239], 'cdn': b[70239] }, e1U0[b[70240]] = {}, e1U0[b[65865]] = '0', e1U0[b[45056]] = window[b[70231]][b[70241]], e1U0[b[70201]] = '', e1U0['os'] = '1', e1U0[b[70242]] = b[70243], e1U0[b[70244]] = b[70245], e1U0[b[70246]] = b[70247], e1U0[b[70248]] = b[70249], e1U0[b[70250]] = b[70251], e1U0[b[64473]] = '1', e1U0[b[66173]] = '', e1U0[b[66175]] = '', e1U0[b[70252]] = 0x0, e1U0[b[70253]] = {}, e1U0[b[70254]] = parseInt(e1U0[b[64473]]), e1U0[b[66171]] = e1U0[b[64473]], e1U0[b[66167]] = {}, e1U0[b[70126]] = b[70255], e1U0[b[70256]] = ![], e1U0[b[52776]] = b[70257], e1U0[b[66139]] = Date[b[40087]](), e1U0[b[52372]] = b[70258], e1U0[b[40768]] = '_a', e1U0[b[70259]] = 0x2, e1U0[b[40109]] = 0x7c1, e1U0[b[70241]] = window[b[70231]][b[70241]], e1U0[b[40792]] = ![], e1U0[b[41132]] = ![], e1U0[b[51762]] = ![], e1U0[b[65867]] = ![], window[b[70260]] = 0x5, window[b[70261]] = ![], window[b[70156]] = ![], window[b[70164]] = ![], window[b[70262]] = ![], window[b[70263]] = ![], window[b[70264]] = ![], window[b[70265]] = ![], window[b[70266]] = ![], window[b[70267]] = ![], window[b[70268]] = null, window[b[40670]] = function (nkq9su) {
  console[b[40511]](b[40670], nkq9su), wx[b[45337]]({}), wx[b[70144]]({ 'title': b[46726], 'content': nkq9su, 'success'(d0b568) {
      if (d0b568[b[70269]]) console[b[40511]](b[70270]);else d0b568[b[40584]] && console[b[40511]](b[70271]);
    } });
}, window[b[70272]] = function (jq$3x) {
  console[b[40511]](b[70273], jq$3x), e11U0G(), wx[b[70144]]({ 'title': b[46726], 'content': jq$3x, 'confirmText': b[70274], 'cancelText': b[59253], 'success'(aom7cp) {
      if (aom7cp[b[70269]]) window[b[70170]]();else aom7cp[b[40584]] && (console[b[40511]](b[70275]), wx[b[65863]]({}));
    } });
}, window[b[70276]] = function (lzrtgh) {
  console[b[40511]](b[70276], lzrtgh), wx[b[70144]]({ 'title': b[46726], 'content': lzrtgh, 'confirmText': b[66304], 'showCancel': ![], 'complete'(v4_f) {
      console[b[40511]](b[70275]), wx[b[65863]]({});
    } });
}, window[b[70277]] = ![], window[b[70278]] = function (_74yv) {
  window[b[70277]] = !![], wx[b[45336]](_74yv);
}, window[b[70279]] = function () {
  window[b[70277]] && (window[b[70277]] = ![], wx[b[45337]]({}));
}, window[b[70280]] = function (mv4a_7) {
  window[b[70132]][b[40166]][b[70280]](mv4a_7);
}, window[b[52646]] = function (p7moca, kd6b05) {
  esn3u9[b[52646]](p7moca, function (g3j$xi) {
    g3j$xi && g3j$xi[b[40014]] ? g3j$xi[b[40014]][b[41318]] == 0x1 ? kd6b05(!![]) : (kd6b05(![]), console[b[40082]](b[70281] + g3j$xi[b[40014]][b[70282]])) : console[b[40511]](b[52646], g3j$xi);
  });
}, window[b[70283]] = function (gtzhrl) {
  console[b[40511]](b[70284], gtzhrl);
}, window[b[70285]] = function (xrtlgh) {}, window[b[70286]] = function ($giltx, c7a_m, f4vzyr) {}, window[b[70287]] = function (zgh) {
  console[b[40511]](b[70288], zgh), window[b[70132]][b[40166]][b[70289]](), window[b[70132]][b[40166]][b[70290]](), window[b[70132]][b[40166]][b[70291]]();
}, window[b[70292]] = function (gx3i) {
  window[b[70293]](0xe, b[70294] + gx3i), window[b[70272]](b[70295]);var uqj3ni = { 'id': window[b[70120]][b[70121]], 'role': window[b[70120]][b[44984]], 'level': window[b[70120]][b[70122]], 'account': window[b[70120]][b[66172]], 'version': window[b[70120]][b[40109]], 'cdn': window[b[70120]][b[44861]], 'pkgName': window[b[70120]][b[66173]], 'gamever': window[b[40588]][b[70115]], 'serverid': window[b[70120]][b[66167]] ? window[b[70120]][b[66167]][b[51940]] : 0x0, 'systemInfo': window[b[70123]], 'error': b[70296], 'stack': gx3i ? gx3i : b[70295] },
      ijtgx$ = JSON[b[44847]](uqj3ni);console[b[40143]](b[70297] + ijtgx$), window[b[70126]](ijtgx$);
}, window[b[70293]] = function (mc7apo, d82w50) {
  sendApi(e1U0[b[70246]], b[70298], { 'game_pkg': e1U0[b[66173]], 'partner_id': e1U0[b[64473]], 'server_id': e1U0[b[66167]] && e1U0[b[66167]][b[51940]] > 0x0 ? e1U0[b[66167]][b[51940]] : 0x0, 'uid': e1U0[b[66172]] > 0x0 ? e1U0[b[66172]] : 0x0, 'type': mc7apo, 'info': d82w50 });
}, window[b[70299]] = function (vm7_a) {
  var qi$nj3 = JSON[b[40556]](vm7_a);qi$nj3[b[70300]] = window[b[40588]][b[70115]], qi$nj3[b[70301]] = window[b[70120]][b[66167]] ? window[b[70120]][b[66167]][b[51940]] : 0x0, qi$nj3[b[70123]] = window[b[70123]];var dw8502 = JSON[b[44847]](qi$nj3);console[b[40143]](b[70302] + dw8502), window[b[70126]](dw8502);
}, window[b[70171]] = function (z4vrf, sn3qju) {
  var w8d02 = { 'id': window[b[70120]][b[70121]], 'role': window[b[70120]][b[44984]], 'level': window[b[70120]][b[70122]], 'account': window[b[70120]][b[66172]], 'version': window[b[70120]][b[40109]], 'cdn': window[b[70120]][b[44861]], 'pkgName': window[b[70120]][b[66173]], 'gamever': window[b[40588]][b[70115]], 'serverid': window[b[70120]][b[66167]] ? window[b[70120]][b[66167]][b[51940]] : 0x0, 'systemInfo': window[b[70123]], 'error': z4vrf, 'stack': sn3qju },
      _4a = JSON[b[44847]](w8d02);console[b[40102]](b[70303] + _4a), window[b[70126]](_4a);
}, window[b[70126]] = function ($gxitj) {
  if (window[b[70120]][b[70202]] == b[70304]) return;var $itlg = e1U0[b[70126]] + b[70305] + e1U0[b[66172]];wx[b[40506]]({ 'url': $itlg, 'method': b[70045], 'data': $gxitj, 'header': { 'content-type': b[70306], 'cache-control': b[70307] }, 'success': function (mopa7c) {
      DEBUG && console[b[40511]](b[70308], $itlg, $gxitj, mopa7c);
    }, 'fail': function (aco_7m) {
      DEBUG && console[b[40511]](b[70308], $itlg, $gxitj, aco_7m);
    }, 'complete': function () {} });
}, window[b[70309]] = function () {
  function u3ns() {
    return ((0x1 + Math[b[40130]]()) * 0x10000 | 0x0)[b[40288]](0x10)[b[40526]](0x1);
  }return u3ns() + u3ns() + '-' + u3ns() + '-' + u3ns() + '-' + u3ns() + '+' + u3ns() + u3ns() + u3ns();
}, window[b[70170]] = function () {
  console[b[40511]](b[70310]);var amo7p = esn3u9[b[70311]]();e1U0[b[66171]] = amo7p[b[70312]], e1U0[b[70254]] = amo7p[b[70312]], e1U0[b[64473]] = amo7p[b[70312]], e1U0[b[66173]] = amo7p[b[70313]];var pam7o = { 'game_ver': e1U0[b[45056]] };e1U0[b[66175]] = this[b[70309]](), e11UG0({ 'title': b[70314] }), esn3u9[b[40392]](pam7o, this[b[70315]][b[40078]](this));
}, window[b[70315]] = function (w5d218) {
  var lhytr = w5d218[b[70316]];sdkInitRes = w5d218, console[b[40511]](b[70317] + lhytr + b[70318] + (lhytr == 0x1) + b[70319] + w5d218[b[70115]] + b[70320] + window[b[70231]][b[70241]]);if (!w5d218[b[70115]] || window[b[70135]](window[b[70231]][b[70241]], w5d218[b[70115]]) < 0x0) console[b[40511]](b[70321]), e1U0[b[70244]] = b[70322], e1U0[b[70246]] = b[70323], e1U0[b[70248]] = b[70324], e1U0[b[44861]] = b[70325], e1U0[b[65864]] = b[70326], e1U0[b[70327]] = 'fj', e1U0[b[40792]] = ![];else window[b[70135]](window[b[70231]][b[70241]], w5d218[b[70115]]) == 0x0 ? (console[b[40511]](b[70328]), e1U0[b[70244]] = b[70245], e1U0[b[70246]] = b[70247], e1U0[b[70248]] = b[70249], e1U0[b[44861]] = b[70329], e1U0[b[65864]] = b[70326], e1U0[b[70327]] = b[70330], e1U0[b[40792]] = !![]) : (console[b[40511]](b[70331]), e1U0[b[70244]] = b[70245], e1U0[b[70246]] = b[70247], e1U0[b[70248]] = b[70249], e1U0[b[44861]] = b[70329], e1U0[b[65864]] = b[70326], e1U0[b[70327]] = b[70330], e1U0[b[40792]] = ![]);e1U0[b[70252]] = config[b[70332]] ? config[b[70332]] : 0x0, this[b[70333]](), this[b[70334]](), window[b[70335]] = 0x5, e11UG0({ 'title': b[70336] }), esn3u9[b[70036]](this[b[70337]][b[40078]](this));
}, window[b[70335]] = 0x5, window[b[70337]] = function (xlitg, qnu9sk) {
  if (xlitg == 0x0 && qnu9sk && qnu9sk[b[70338]]) {
    e1U0[b[70339]] = qnu9sk[b[70338]];var _vm74a = this;e11UG0({ 'title': b[70340] }), sendApi(e1U0[b[70244]], b[70341], { 'platform': e1U0[b[70242]], 'partner_id': e1U0[b[64473]], 'token': qnu9sk[b[70338]], 'game_pkg': e1U0[b[66173]], 'deviceId': e1U0[b[66175]], 'scene': b[70342] + e1U0[b[70252]] }, this[b[70343]][b[40078]](this), e1G0U, e101);
  } else qnu9sk && qnu9sk[b[66370]] && window[b[70335]] > 0x0 && (qnu9sk[b[66370]][b[40124]](b[70344]) != -0x1 || qnu9sk[b[66370]][b[40124]](b[70345]) != -0x1 || qnu9sk[b[66370]][b[40124]](b[70346]) != -0x1 || qnu9sk[b[66370]][b[40124]](b[70347]) != -0x1 || qnu9sk[b[66370]][b[40124]](b[70348]) != -0x1 || qnu9sk[b[66370]][b[40124]](b[70349]) != -0x1) ? (window[b[70335]]--, esn3u9[b[70036]](this[b[70337]][b[40078]](this))) : (window[b[70293]](0x1, b[70350] + xlitg + b[70351] + (qnu9sk ? qnu9sk[b[66370]] : '')), window[b[70171]](b[70352], JSON[b[44847]]({ 'status': xlitg, 'data': qnu9sk })), window[b[70272]](b[70353] + (qnu9sk && qnu9sk[b[66370]] ? '，' + qnu9sk[b[66370]] : '')));
}, window[b[70343]] = function (usjnq) {
  if (!usjnq) {
    window[b[70293]](0x2, b[70354]), window[b[70171]](b[70355], b[70356]), window[b[70272]](b[70357]);return;
  }if (usjnq[b[41318]] != b[50313]) {
    window[b[70293]](0x2, b[70358] + usjnq[b[41318]]), window[b[70171]](b[70355], JSON[b[44847]](usjnq)), window[b[70272]](b[70359] + usjnq[b[41318]]);return;
  }e1U0[b[59632]] = String(usjnq[b[66172]]), e1U0[b[66172]] = String(usjnq[b[66172]]), e1U0[b[66137]] = String(usjnq[b[66137]]), e1U0[b[66171]] = String(usjnq[b[66137]]), e1U0[b[66174]] = String(usjnq[b[66174]]), e1U0[b[70360]] = String(usjnq[b[51923]]), e1U0[b[70361]] = String(usjnq[b[40905]]), e1U0[b[51923]] = '';var s69knu = this;e11UG0({ 'title': b[70362] });var gtxl = localStorage[b[40509]](b[70363] + e1U0[b[66173]] + e1U0[b[66172]]);if (gtxl && gtxl != '') {
    var lrhgz = Number(gtxl);s69knu[b[70364]](lrhgz);
  } else s69knu[b[70365]]();
}, window[b[70365]] = function () {
  var poma7 = this;sendApi(e1U0[b[70244]], b[70366], { 'partner_id': e1U0[b[64473]], 'uid': e1U0[b[66172]], 'version': e1U0[b[45056]], 'game_pkg': e1U0[b[66173]], 'device': e1U0[b[66175]] }, poma7[b[70367]][b[40078]](poma7), e1G0U, e101);
}, window[b[70367]] = function (co_) {
  if (!co_) {
    window[b[70293]](0x3, b[70368]), window[b[70272]](b[70368]);return;
  }if (co_[b[41318]] != b[50313]) {
    window[b[70293]](0x3, b[70369] + co_[b[41318]]), window[b[70272]](b[70369] + co_[b[41318]]);return;
  }if (!co_[b[40014]] || co_[b[40014]][b[40016]] == 0x0) {
    window[b[70293]](0x3, b[70370]), window[b[70272]](b[70371]);return;
  }this[b[70372]](co_);
}, window[b[70364]] = function (zfyv4_) {
  var tgrxlh = this;sendApi(e1U0[b[70244]], b[70373], { 'server_id': zfyv4_, 'time': Date[b[40087]]() / 0x3e8 }, tgrxlh[b[70374]][b[40078]](tgrxlh), e1G0U, e101);
}, window[b[70374]] = function (jtgix) {
  if (!jtgix) {
    window[b[70293]](0x4, b[70375]), this[b[70365]]();return;
  }if (jtgix[b[41318]] != b[50313]) {
    window[b[70293]](0x4, b[70376] + jtgix[b[41318]]), this[b[70365]]();return;
  }if (!jtgix[b[40014]] || jtgix[b[40014]][b[40016]] == 0x0) {
    window[b[70293]](0x4, b[70377]), this[b[70365]]();return;
  }this[b[70372]](jtgix), window[b[70132]] && window[b[70132]][b[40166]][b[70378]] && window[b[70132]][b[40166]][b[70378]](sdkInitRes[b[70379]], sdkInitRes[b[70380]], sdkInitRes[b[70381]], sdkInitRes[b[70382]], sdkInitRes[b[70383]]);
}, window[b[70372]] = function (tglxh) {
  e1U0[b[40680]] = tglxh[b[70384]] != undefined ? tglxh[b[70384]] : 0x0, e1U0[b[66167]] = { 'server_id': String(tglxh[b[40014]][0x0][b[51940]]), 'server_name': String(tglxh[b[40014]][0x0][b[70385]]), 'entry_ip': tglxh[b[40014]][0x0][b[66197]], 'entry_port': parseInt(tglxh[b[40014]][0x0][b[66198]]), 'status': e1UG1(tglxh[b[40014]][0x0]), 'start_time': tglxh[b[40014]][0x0][b[70386]], 'cdn': e1U0[b[44861]] }, this[b[70387]]();
}, window[b[70388]] = null, window[b[70387]] = function () {
  var bs069 = this;esn3u9[b[70109]](function (yfz4r) {
    console[b[40511]](b[70389] + JSON[b[44847]](yfz4r)), youYiCofig = yfz4r;window[b[70388]][b[70390]] == 0x1 && (e1U0[b[40680]] = 0x0);if (e1U0[b[40680]] == 0x1) {
      var usn96k = e1U0[b[66167]][b[40115]];if (usn96k === -0x1 || usn96k === 0x0) {
        window[b[70293]](0xf, b[70391] + e1U0[b[66167]]['id'] + b[70392] + e1U0[b[66167]][b[40115]]), window[b[70272]](usn96k === -0x1 ? b[70393] : b[70394]);return;
      }e101GU(0x0, e1U0[b[66167]][b[51940]]), window[b[70132]][b[40166]][b[70395]](e1U0[b[40680]]);
    } else window[b[70132]][b[40166]][b[70396]](() => {
      var ylrz = window[b[70388]][b[70397]],
          k06d5 = window[b[70388]][b[70390]] == 0x1;k06d5 && window[b[70132]][b[40166]][b[70398]](b[70399], ylrz, b[70400]);
    }, bs069), e11U0G();window[b[70266]] = !![], window[b[70157]](), window[b[70158]]();
  });
}, window[b[70401]] = function () {
  esn3u9[b[70110]](function (ztlghr) {
    console[b[40511]](b[70402] + JSON[b[44847]](ztlghr));
  });
}, window[b[70333]] = function () {
  sendApi(e1U0[b[70244]], b[70403], { 'game_pkg': e1U0[b[66173]], 'version_name': e1U0[b[70327]] }, this[b[70404]][b[40078]](this), e1G0U, e101);
}, window[b[70404]] = function (kd0b65) {
  if (!kd0b65) {
    window[b[70293]](0x5, b[70405]), window[b[70272]](b[70405]);return;
  }if (kd0b65[b[41318]] != b[50313]) {
    window[b[70293]](0x5, b[70406] + kd0b65[b[41318]]), window[b[70272]](b[70406] + kd0b65[b[41318]]);return;
  }if (!kd0b65[b[40014]] || !kd0b65[b[40014]][b[45056]]) {
    window[b[70293]](0x5, b[70407] + (kd0b65[b[40014]] && kd0b65[b[40014]][b[45056]])), window[b[70272]](b[70407] + (kd0b65[b[40014]] && kd0b65[b[40014]][b[45056]]));return;
  }kd0b65[b[40014]][b[70408]] && kd0b65[b[40014]][b[70408]][b[40016]] > 0xa && (e1U0[b[70409]] = kd0b65[b[40014]][b[70408]], e1U0[b[44861]] = kd0b65[b[40014]][b[70408]]), kd0b65[b[40014]][b[45056]] && (e1U0[b[40109]] = kd0b65[b[40014]][b[45056]]), console[b[40082]](b[66311] + e1U0[b[40109]] + b[70410] + e1U0[b[70327]]), window[b[70264]] = !![], window[b[70157]](), window[b[70158]]();
}, window[b[70411]], window[b[70334]] = function () {
  sendApi(e1U0[b[70244]], b[70412], { 'game_pkg': e1U0[b[66173]] }, this[b[70413]][b[40078]](this), e1G0U, e101);
}, window[b[70413]] = function (ig$xtj) {
  if (ig$xtj && ig$xtj[b[41318]] === b[50313] && ig$xtj[b[40014]]) {
    window[b[70411]] = ig$xtj[b[40014]];for (var un96s in ig$xtj[b[40014]]) {
      e1U0[un96s] = ig$xtj[b[40014]][un96s];
    }
  } else window[b[70293]](0xb, b[70414]), console[b[40082]](b[70415] + ig$xtj[b[41318]]);window[b[70265]] = !![], window[b[70158]]();
}, window[b[70416]] = function (b90ks, cm4a_, _av4m7, rzhly, d9k6, f4zy_, n6sku, fv4a_7, xj3$gi, aopmc) {
  d9k6 = String(d9k6);var ryfhlz = n6sku,
      j$gtx = fv4a_7;e1U0[b[70240]][d9k6] = { 'productid': d9k6, 'productname': ryfhlz, 'productdesc': j$gtx, 'roleid': b90ks, 'rolename': cm4a_, 'rolelevel': _av4m7, 'price': f4zy_, 'callback': xj3$gi }, sendApi(e1U0[b[70248]], b[70417], { 'game_pkg': e1U0[b[66173]], 'server_id': e1U0[b[66167]][b[51940]], 'server_name': e1U0[b[66167]][b[70385]], 'level': _av4m7, 'uid': e1U0[b[66172]], 'role_id': b90ks, 'role_name': cm4a_, 'product_id': d9k6, 'product_name': ryfhlz, 'product_desc': j$gtx, 'money': f4zy_, 'partner_id': e1U0[b[64473]] }, toPayCallBack, e1G0U, e101);
}, window[b[70418]] = function (lhyrz) {
  if (lhyrz && (lhyrz[b[70419]] === 0xc8 || lhyrz[b[41318]] == b[50313])) {
    var n3iq = e1U0[b[70240]][String(lhyrz[b[70420]])];if (n3iq[b[40358]]) n3iq[b[40358]](lhyrz[b[70420]], lhyrz[b[70421]], -0x1);esn3u9[b[70072]]({ 'cpbill': lhyrz[b[70421]], 'productid': lhyrz[b[70420]], 'productname': n3iq[b[70422]], 'productdesc': n3iq[b[70423]], 'serverid': e1U0[b[66167]][b[51940]], 'servername': e1U0[b[66167]][b[70385]], 'roleid': n3iq[b[70424]], 'rolename': n3iq[b[70425]], 'rolelevel': n3iq[b[70426]], 'price': n3iq[b[67960]], 'extension': JSON[b[44847]]({ 'cp_order_id': lhyrz[b[70421]] }) }, function (tghlrx, kuqn9) {
      n3iq[b[40358]] && tghlrx == 0x0 && n3iq[b[40358]](lhyrz[b[70420]], lhyrz[b[70421]], tghlrx);console[b[40082]](JSON[b[44847]]({ 'type': b[70427], 'status': tghlrx, 'data': lhyrz, 'role_name': n3iq[b[70425]] }));if (tghlrx === 0x0) {} else {
        if (tghlrx === 0x1) {} else {
          if (tghlrx === 0x2) {}
        }
      }
    });
  } else {
    var grl = lhyrz ? b[70428] + lhyrz[b[70419]] + b[70429] + lhyrz[b[41318]] + b[70430] + lhyrz[b[40082]] : b[70431];window[b[70293]](0xd, b[70432] + grl), alert(grl);
  }
}, window[b[70433]] = function () {}, window[b[70434]] = function (lghxtr, a4_7mc, j$3xg, nu9s6, qi$xj3) {
  esn3u9[b[70104]](e1U0[b[66167]][b[51940]], e1U0[b[66167]][b[70385]] || e1U0[b[66167]][b[51940]], lghxtr, a4_7mc, j$3xg), sendApi(e1U0[b[70244]], b[70435], { 'game_pkg': e1U0[b[66173]], 'server_id': e1U0[b[66167]][b[51940]], 'role_id': lghxtr, 'uid': e1U0[b[66172]], 'role_name': a4_7mc, 'role_type': nu9s6, 'level': j$3xg });
}, window[b[70436]] = function (x$tjg, qiu3j, d0w5, mcoepa, opma7, hrxg, c7a4m, snu3qj, ijxtg, s6ukb) {
  e1U0[b[70121]] = x$tjg, e1U0[b[44984]] = qiu3j, e1U0[b[70122]] = d0w5, esn3u9[b[70105]](e1U0[b[66167]][b[51940]], e1U0[b[66167]][b[70385]] || e1U0[b[66167]][b[51940]], x$tjg, qiu3j, d0w5), sendApi(e1U0[b[70244]], b[70437], { 'game_pkg': e1U0[b[66173]], 'server_id': e1U0[b[66167]][b[51940]], 'role_id': x$tjg, 'uid': e1U0[b[66172]], 'role_name': qiu3j, 'role_type': mcoepa, 'level': d0w5, 'evolution': opma7 });
}, window[b[70438]] = function (htyzrl, hztylr, tx$ij, uk9q, zrhl, d20w58, htx$g, opca7, xjigt, d9k06b) {
  e1U0[b[70121]] = htyzrl, e1U0[b[44984]] = hztylr, e1U0[b[70122]] = tx$ij, esn3u9[b[70106]](e1U0[b[66167]][b[51940]], e1U0[b[66167]][b[70385]] || e1U0[b[66167]][b[51940]], htyzrl, hztylr, tx$ij), sendApi(e1U0[b[70244]], b[70437], { 'game_pkg': e1U0[b[66173]], 'server_id': e1U0[b[66167]][b[51940]], 'role_id': htyzrl, 'uid': e1U0[b[66172]], 'role_name': hztylr, 'role_type': uk9q, 'level': tx$ij, 'evolution': zrhl });
}, window[b[70439]] = function (eampco) {}, window[b[70440]] = function ($tjg) {
  esn3u9[b[70055]](b[70055], function (zyhfvr) {
    $tjg && $tjg(zyhfvr);
  });
}, window[b[64471]] = function () {
  esn3u9[b[64471]]();
}, window[b[70441]] = function () {
  esn3u9[b[64361]]();
}, window[b[70442]] = function (lgx$i, il, v7f, grxhtl, r4vy, oma7_c, k650db, pae) {
  pae = pae || e1U0[b[66167]][b[51940]], sendApi(e1U0[b[70244]], b[70443], { 'phone': lgx$i, 'role_id': il, 'uid': e1U0[b[66172]], 'game_pkg': e1U0[b[66173]], 'partner_id': e1U0[b[64473]], 'server_id': pae }, k650db, 0x2, null, function () {
    return !![];
  });
}, window[b[51268]] = function (fry) {
  window[b[70221]] = fry, window[b[70221]] && window[b[70220]] && (console[b[40082]](b[70222] + window[b[70220]][b[40830]]), window[b[70221]](window[b[70220]]), window[b[70220]] = null);
}, window[b[70444]] = function (_yfv4z, $igxtj, $iqx, gxj$it) {
  window[b[40026]](b[70445], { 'game_pkg': window[b[70120]][b[66173]], 'role_id': $igxtj, 'server_id': $iqx }, gxj$it);
}, window[b[70446]] = function ($g3j, xgjt$i, yhzfl) {
  function _va7f(ixt$l) {
    var sqn93u = [],
        a4f = [],
        _fzy = yhzfl || window[b[40588]][b[70447]];for (var k6b90 in _fzy) {
      var hrztl = Number(k6b90);(!$g3j || !$g3j[b[40016]] || $g3j[b[40124]](hrztl) != -0x1) && (a4f[b[40033]](_fzy[k6b90]), sqn93u[b[40033]]([hrztl, 0x3]));
    }window[b[70135]](window[b[70136]], b[70448]) >= 0x0 ? (console[b[40511]](b[70449]), esn3u9[b[70101]] && esn3u9[b[70101]](a4f, function (_7acmo) {
      console[b[40511]](b[70450]), console[b[40511]](_7acmo);if (_7acmo && _7acmo[b[66370]] == b[70451]) for (var fryzhl in _fzy) {
        if (_7acmo[_fzy[fryzhl]] == b[70452]) {
          var mcpoa7 = Number(fryzhl);for (var k60b9s = 0x0; k60b9s < sqn93u[b[40016]]; k60b9s++) {
            if (sqn93u[k60b9s][0x0] == mcpoa7) {
              sqn93u[k60b9s][0x1] = 0x1;break;
            }
          }
        }
      }window[b[70135]](window[b[70136]], b[70453]) >= 0x0 ? wx[b[70454]]({ 'withSubscriptions': !![], 'success': function (dw285) {
          var lrhtgx = dw285[b[70455]][b[70456]];if (lrhtgx) {
            console[b[40511]](b[70457]), console[b[40511]](lrhtgx);for (var hrvfz in _fzy) {
              if (lrhtgx[_fzy[hrvfz]] == b[70452]) {
                var qs9ukn = Number(hrvfz);for (var niquj = 0x0; niquj < sqn93u[b[40016]]; niquj++) {
                  if (sqn93u[niquj][0x0] == qs9ukn) {
                    sqn93u[niquj][0x1] = 0x2;break;
                  }
                }
              }
            }console[b[40511]](sqn93u), xgjt$i && xgjt$i(sqn93u);
          } else console[b[40511]](b[70458]), console[b[40511]](dw285), console[b[40511]](sqn93u), xgjt$i && xgjt$i(sqn93u);
        }, 'fail': function () {
          console[b[40511]](b[70459]), console[b[40511]](sqn93u), xgjt$i && xgjt$i(sqn93u);
        } }) : (console[b[40511]](b[70460] + window[b[70136]]), console[b[40511]](sqn93u), xgjt$i && xgjt$i(sqn93u));
    })) : (console[b[40511]](b[70461] + window[b[70136]]), console[b[40511]](sqn93u), xgjt$i && xgjt$i(sqn93u)), wx[b[70462]](_va7f);
  }wx[b[70463]](_va7f);
}, window[b[70464]] = { 'isSuccess': ![], 'level': b[70465], 'isCharging': ![] }, window[b[53668]] = function (snk96) {
  wx[b[70212]]({ 'success': function (hrlgxt) {
      var oapmc = window[b[70464]];oapmc[b[70466]] = !![], oapmc[b[44960]] = Number(hrlgxt[b[44960]])[b[44581]](0x0), oapmc[b[70215]] = hrlgxt[b[70215]], snk96 && snk96(oapmc[b[70466]], oapmc[b[44960]], oapmc[b[70215]]);
    }, 'fail': function (hrltg) {
      console[b[40511]](b[70467], hrltg[b[66370]]);var s9qnuk = window[b[70464]];snk96 && snk96(s9qnuk[b[70466]], s9qnuk[b[44960]], s9qnuk[b[70215]]);
    } });
}, window[b[52342]] = function (f4_vy) {
  wx[b[52342]]({ 'success': function (hzvrfy) {
      f4_vy && f4_vy(!![], hzvrfy);
    }, 'fail': function (cm47_) {
      f4_vy && f4_vy(![], cm47_);
    } });
}, window[b[52344]] = function (_aocm) {
  if (_aocm) wx[b[52344]](_aocm);
}, window[b[65859]] = function (n9s3u) {
  wx[b[65859]](n9s3u);
}, window[b[40026]] = function (vf_y7, b9u6s, m_7c4, zfv4y, qkns9u, rgzlh, n3qj, jix$g3) {
  if (zfv4y == undefined) zfv4y = 0x1;wx[b[40506]]({ 'url': vf_y7, 'method': n3qj || b[66055], 'responseType': b[44765], 'data': b9u6s, 'header': { 'content-type': jix$g3 || b[70306] }, 'success': function (tlhrzg) {
      DEBUG && console[b[40511]](b[70468], vf_y7, info, tlhrzg);if (tlhrzg && tlhrzg[b[66440]] == 0xc8) {
        var n3qsj = tlhrzg[b[40014]];!rgzlh || rgzlh(n3qsj) ? m_7c4 && m_7c4(n3qsj) : window[b[70469]](vf_y7, b9u6s, m_7c4, zfv4y, qkns9u, rgzlh, tlhrzg);
      } else window[b[70469]](vf_y7, b9u6s, m_7c4, zfv4y, qkns9u, rgzlh, tlhrzg);
    }, 'fail': function (xthl) {
      DEBUG && console[b[40511]](b[70470], vf_y7, info, xthl), window[b[70469]](vf_y7, b9u6s, m_7c4, zfv4y, qkns9u, rgzlh, xthl);
    }, 'complete': function () {} });
}, window[b[70469]] = function (d8b65, ytzrhl, b5d60, xlgt$, d096, _vaf4, mv4_a) {
  xlgt$ - 0x1 > 0x0 ? setTimeout(function () {
    window[b[40026]](d8b65, ytzrhl, b5d60, xlgt$ - 0x1, d096, _vaf4);
  }, 0x3e8) : d096 && d096(JSON[b[44847]]({ 'url': d8b65, 'response': mv4_a }));
}, window[b[70471]] = function (mav4_7, oc_7m, w8b0d, _oca7, unj3qs, gj$3xi, ilxgt) {
  !w8b0d && (w8b0d = {});var rghtzl = Math[b[40129]](Date[b[40087]]() / 0x3e8);w8b0d[b[40905]] = rghtzl, w8b0d[b[70472]] = oc_7m;var hrtxgl = Object[b[40280]](w8b0d)[b[41137]](),
      dk09b6 = '',
      grltxh = '';for (var k69un = 0x0; k69un < hrtxgl[b[40016]]; k69un++) {
    dk09b6 = dk09b6 + (k69un == 0x0 ? '' : '&') + hrtxgl[k69un] + w8b0d[hrtxgl[k69un]], grltxh = grltxh + (k69un == 0x0 ? '' : '&') + hrtxgl[k69un] + '=' + encodeURIComponent(w8b0d[hrtxgl[k69un]]);
  }dk09b6 = dk09b6 + e1U0[b[70250]];var fl = b[70473] + md5(dk09b6);send(mav4_7 + '?' + grltxh + (grltxh == '' ? '' : '&') + fl, null, _oca7, unj3qs, gj$3xi, ilxgt || function (sq9unk) {
    return sq9unk[b[41318]] == b[50313];
  }, null, b[70046]);
}, window[b[70474]] = function (ltgix$, k9qsn) {
  var lgrth = 0x0;e1U0[b[66167]] && (lgrth = e1U0[b[66167]][b[51940]]), sendApi(e1U0[b[70246]], b[70475], { 'partnerId': e1U0[b[64473]], 'gamePkg': e1U0[b[66173]], 'logTime': Math[b[40129]](Date[b[40087]]() / 0x3e8), 'platformUid': e1U0[b[66174]], 'type': ltgix$, 'serverId': lgrth }, null, 0x2, null, function () {
    return !![];
  });
}, window[b[70476]] = function (t$gxli) {
  sendApi(e1U0[b[70244]], b[70477], { 'partner_id': e1U0[b[64473]], 'uid': e1U0[b[66172]], 'version': e1U0[b[45056]], 'game_pkg': e1U0[b[66173]], 'device': e1U0[b[66175]] }, e1U0G1, e1G0U, e101);
}, window[b[70478]] = function (vyf_74) {
  if (vyf_74 && vyf_74[b[41318]] === b[50313] && vyf_74[b[40014]]) {
    vyf_74[b[40014]][b[45942]]({ 'id': -0x2, 'name': b[70479] }), vyf_74[b[40014]][b[45942]]({ 'id': -0x1, 'name': b[70480] }), e1U0[b[70481]] = vyf_74[b[40014]];if (window[b[52827]]) window[b[52827]][b[70482]]();
  } else {
    e1U0[b[70483]] = ![];var y7_f = vyf_74 ? vyf_74[b[41318]] : '';window[b[70293]](0x7, b[70484] + y7_f), window[b[70272]](b[70485] + y7_f);
  }
}, window[b[70486]] = function (yvfz) {
  sendApi(e1U0[b[70244]], b[70487], { 'partner_id': e1U0[b[64473]], 'uid': e1U0[b[66172]], 'version': e1U0[b[45056]], 'game_pkg': e1U0[b[66173]], 'device': e1U0[b[66175]] }, e11UG, e1G0U, e101);
}, window[b[70488]] = function (nsk9uq) {
  e1U0[b[70489]] = ![];if (nsk9uq && nsk9uq[b[41318]] === b[50313] && nsk9uq[b[40014]]) {
    for (var b9 = 0x0; b9 < nsk9uq[b[40014]][b[40016]]; b9++) {
      nsk9uq[b[40014]][b9][b[40115]] = e1UG1(nsk9uq[b[40014]][b9]);
    }e1U0[b[70253]][-0x1] = window[b[70490]](nsk9uq[b[40014]]), window[b[52827]][b[70491]](-0x1);
  } else {
    var b60d85 = nsk9uq ? nsk9uq[b[41318]] : '';window[b[70293]](0x8, b[70492] + b60d85), window[b[70272]](b[70493] + b60d85);
  }
}, window[b[70494]] = function ($ixgtl) {
  sendApi(e1U0[b[70244]], b[70487], { 'partner_id': e1U0[b[64473]], 'uid': e1U0[b[66172]], 'version': e1U0[b[45056]], 'game_pkg': e1U0[b[66173]], 'device': e1U0[b[66175]] }, $ixgtl, e1G0U, e101);
}, window[b[70495]] = function (oacmep, b6d5) {
  sendApi(e1U0[b[70244]], b[70496], { 'partner_id': e1U0[b[64473]], 'uid': e1U0[b[66172]], 'version': e1U0[b[45056]], 'game_pkg': e1U0[b[66173]], 'device': e1U0[b[66175]], 'server_group_id': b6d5 }, e1GU1, e1G0U, e101);
}, window[b[70497]] = function (in$3jq) {
  e1U0[b[70489]] = ![];if (in$3jq && in$3jq[b[41318]] === b[50313] && in$3jq[b[40014]] && in$3jq[b[40014]][b[40014]]) {
    var omcpe = in$3jq[b[40014]][b[70498]],
        ukn9sq = [];for (var _4zvfy = 0x0; _4zvfy < in$3jq[b[40014]][b[40014]][b[40016]]; _4zvfy++) {
      in$3jq[b[40014]][b[40014]][_4zvfy][b[40115]] = e1UG1(in$3jq[b[40014]][b[40014]][_4zvfy]), (ukn9sq[b[40016]] == 0x0 || in$3jq[b[40014]][b[40014]][_4zvfy][b[40115]] != 0x0) && (ukn9sq[ukn9sq[b[40016]]] = in$3jq[b[40014]][b[40014]][_4zvfy]);
    }e1U0[b[70253]][omcpe] = window[b[70490]](ukn9sq), window[b[52827]][b[70491]](omcpe);
  } else {
    var bd860 = in$3jq ? in$3jq[b[41318]] : '';window[b[70293]](0x9, b[70499] + bd860), window[b[70272]](b[70500] + bd860);
  }
}, window[b[70501]] = function (yrhv) {
  sendApi(e1U0[b[70244]], b[70502], { 'partner_id': e1U0[b[64473]], 'uid': e1U0[b[66172]], 'version': e1U0[b[45056]], 'game_pkg': e1U0[b[66173]], 'device': e1U0[b[66175]] }, reqServerRecommendCallBack, e1G0U, e101);
}, window[b[70503]] = function (q3njui) {
  e1U0[b[70489]] = ![];if (q3njui && q3njui[b[41318]] === b[50313] && q3njui[b[40014]]) {
    for (var qiunj = 0x0; qiunj < q3njui[b[40014]][b[40016]]; qiunj++) {
      q3njui[b[40014]][qiunj][b[40115]] = e1UG1(q3njui[b[40014]][qiunj]);
    }e1U0[b[70253]][-0x2] = window[b[70490]](q3njui[b[40014]]), window[b[52827]][b[70491]](-0x2);
  } else {
    var gxit = q3njui ? q3njui[b[41318]] : '';window[b[70293]](0xa, b[70504] + gxit), alert(b[70505] + gxit);
  }
}, window[b[70490]] = function (w1d82) {
  return w1d82;
}, window[b[70506]] = function (jsqnu3, u93nsq) {
  jsqnu3 = jsqnu3 || e1U0[b[66167]][b[51940]], sendApi(e1U0[b[70244]], b[70507], { 'type': '4', 'game_pkg': e1U0[b[66173]], 'server_id': jsqnu3 }, u93nsq);
}, window[b[70508]] = function (su6bk9, db08, _fyz4v, grtxhl) {
  _fyz4v = _fyz4v || e1U0[b[66167]][b[51940]], sendApi(e1U0[b[70244]], b[70509], { 'type': su6bk9, 'game_pkg': db08, 'server_id': _fyz4v }, grtxhl);
}, window[b[70510]] = function (v4fz_, xg$itj) {
  sendApi(e1U0[b[70244]], b[70511], { 'game_pkg': v4fz_ }, xg$itj);
}, window[b[70512]] = function (d60k9b) {
  if (d60k9b) {
    if (d60k9b[b[40115]] == 0x1) {
      if (d60k9b[b[70513]] == 0x1) return 0x2;else return 0x1;
    } else return d60k9b[b[40115]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window[b[70514]] = function (lxt$h, bd06k) {
  var q$ix3j = window[b[70388]][b[70390]] == 0x1;if (q$ix3j) {
    var o7amp = window[b[70388]][b[70397]],
        q$ix3j = window[b[70388]][b[70390]] == 0x1;window[b[70132]][b[40166]][b[70398]](b[70399], o7amp, b[70400]);return;
  }e1U0[b[70515]] = { 'step': lxt$h, 'server_id': bd06k };var q9uk = this;e11UG0({ 'title': b[70516] }), sendApi(e1U0[b[70244]], b[70517], { 'partner_id': e1U0[b[64473]], 'uid': e1U0[b[66172]], 'game_pkg': e1U0[b[66173]], 'server_id': bd06k, 'platform': e1U0[b[66137]], 'platform_uid': e1U0[b[66174]], 'check_login_time': e1U0[b[70361]], 'check_login_sign': e1U0[b[70360]], 'version_name': e1U0[b[70327]] }, e101UG, e1G0U, e101, function (kb50d) {
    return kb50d[b[41318]] == b[50313] || kb50d[b[40082]] == b[70518] || kb50d[b[40082]] == b[70519];
  });
}, window[b[70520]] = function (dw80b5) {
  var _zyv4 = this;if (dw80b5 && dw80b5[b[41318]] === b[50313] && dw80b5[b[40014]]) {
    var qjnsu = e1U0[b[66167]];qjnsu[b[70521]] = e1U0[b[70254]], qjnsu[b[51923]] = String(dw80b5[b[40014]][b[70522]]), qjnsu[b[66139]] = parseInt(dw80b5[b[40014]][b[40905]]);if (dw80b5[b[40014]][b[66138]]) qjnsu[b[66138]] = parseInt(dw80b5[b[40014]][b[66138]]);else qjnsu[b[66138]] = parseInt(dw80b5[b[40014]][b[51940]]);qjnsu[b[70523]] = 0x0, qjnsu[b[44861]] = e1U0[b[70409]], qjnsu[b[70524]] = dw80b5[b[40014]][b[70525]], qjnsu[b[70526]] = dw80b5[b[40014]][b[70526]];if (dw80b5[b[40014]][b[66142]]) qjnsu[b[66142]] = parseInt(dw80b5[b[40014]][b[66142]]);console[b[40511]](b[70527] + JSON[b[44847]](qjnsu[b[70526]])), e1U0[b[40680]] == 0x1 && qjnsu[b[70526]] && qjnsu[b[70526]][b[70528]] == 0x1 && (e1U0[b[70529]] = 0x1, window[b[70132]][b[40166]][b[70530]]()), e10G1U();
  } else {
    if (e1U0[b[70515]][b[47511]] >= 0x3) {
      var inj3u = dw80b5 ? dw80b5[b[41318]] : '';window[b[70293]](0xc, b[70531] + inj3u), e101(JSON[b[44847]](dw80b5)), window[b[70272]](b[70532] + inj3u);
    } else sendApi(e1U0[b[70244]], b[70341], { 'platform': e1U0[b[70242]], 'partner_id': e1U0[b[64473]], 'token': e1U0[b[70339]], 'game_pkg': e1U0[b[66173]], 'deviceId': e1U0[b[66175]], 'scene': b[70342] + e1U0[b[70252]] }, function (z4rvy) {
      if (!z4rvy || z4rvy[b[41318]] != b[50313]) {
        window[b[70272]](b[70359] + z4rvy && z4rvy[b[41318]]);return;
      }e1U0[b[70360]] = String(z4rvy[b[51923]]), e1U0[b[70361]] = String(z4rvy[b[40905]]), setTimeout(function () {
        e101GU(e1U0[b[70515]][b[47511]] + 0x1, e1U0[b[70515]][b[51940]]);
      }, 0x5dc);
    }, e1G0U, e101, function (n9skuq) {
      return n9skuq[b[41318]] == b[50313] || n9skuq[b[41318]] == b[66518];
    });
  }
}, window[b[70533]] = function () {
  ServerLoading[b[40166]][b[70395]](e1U0[b[40680]]), window[b[70261]] = !![], window[b[70158]]();
}, window[b[70157]] = function () {
  if (window[b[70156]] && window[b[70164]] && window[b[70262]] && window[b[70263]] && window[b[70264]] && window[b[70266]]) {
    if (!window[b[70019]][b[40166]]) {
      console[b[40511]](b[70534] + window[b[70019]][b[40166]]);var hgrl = wx[b[70108]](),
          sku69b = hgrl[b[40830]] ? hgrl[b[40830]] : 0x0,
          qx$j = { 'cdn': window[b[70120]][b[44861]], 'spareCdn': window[b[70120]][b[65864]], 'newRegister': window[b[70120]][b[40680]], 'wxPC': window[b[70120]][b[65867]], 'wxIOS': window[b[70120]][b[41132]], 'wxAndroid': window[b[70120]][b[51762]], 'wxParam': { 'limitLoad': window[b[70120]][b[70203]], 'benchmarkLevel': window[b[70120]][b[70204]], 'wxFrom': window[b[40588]][b[70332]] == b[70535] ? 0x1 : 0x0, 'wxSDKVersion': window[b[70136]] }, 'configType': window[b[70120]][b[52372]], 'exposeType': window[b[70120]][b[40768]], 'scene': sku69b };new window[b[70019]](qx$j, window[b[70120]][b[40109]], window[b[70237]]);
    }
  }
}, window[b[70158]] = function () {
  if (window[b[70156]] && window[b[70164]] && window[b[70262]] && window[b[70263]] && window[b[70264]] && window[b[70266]] && window[b[70261]] && window[b[70265]]) {
    e11U0G();if (!e10GU) {
      e10GU = !![];if (!window[b[70019]][b[40166]]) window[b[70157]]();var aocm = 0x0,
          m7ocpa = wx[b[70536]]();m7ocpa && (window[b[70120]][b[70199]] && (aocm = m7ocpa[b[40342]]), console[b[40082]](b[70537] + m7ocpa[b[40342]] + b[70538] + m7ocpa[b[41345]] + b[70539] + m7ocpa[b[41347]] + b[70540] + m7ocpa[b[41346]] + b[70541] + m7ocpa[b[40196]] + b[70542] + m7ocpa[b[40197]]));var vf4a7 = {};for (const kd05b6 in e1U0[b[66167]]) {
        vf4a7[kd05b6] = e1U0[b[66167]][kd05b6];
      }var n$i = { 'channel': window[b[70120]][b[66171]], 'account': window[b[70120]][b[66172]], 'userId': window[b[70120]][b[59632]], 'cdn': window[b[70120]][b[44861]], 'data': window[b[70120]][b[40014]], 'package': window[b[70120]][b[65865]], 'newRegister': window[b[70120]][b[40680]], 'pkgName': window[b[70120]][b[66173]], 'partnerId': window[b[70120]][b[64473]], 'platform_uid': window[b[70120]][b[66174]], 'deviceId': window[b[70120]][b[66175]], 'selectedServer': vf4a7, 'configType': window[b[70120]][b[52372]], 'exposeType': window[b[70120]][b[40768]], 'debugUsers': window[b[70120]][b[52776]], 'wxMenuTop': aocm, 'wxShield': window[b[70120]][b[40792]] };if (window[b[70411]]) for (var txlr in window[b[70411]]) {
        n$i[txlr] = window[b[70411]][txlr];
      }window[b[70019]][b[40166]][b[66189]](n$i);if (e1U0[b[66167]] && e1U0[b[66167]][b[51940]]) localStorage[b[40514]](b[70363] + e1U0[b[66173]] + e1U0[b[66172]], e1U0[b[66167]][b[51940]]);
    }
  } else console[b[40082]](b[70543] + window[b[70156]] + b[70544] + window[b[70164]] + b[70545] + window[b[70262]] + b[70546] + window[b[70263]] + b[70547] + window[b[70264]] + b[70548] + window[b[70266]] + b[70549] + window[b[70261]] + b[70550] + window[b[70265]]);
};