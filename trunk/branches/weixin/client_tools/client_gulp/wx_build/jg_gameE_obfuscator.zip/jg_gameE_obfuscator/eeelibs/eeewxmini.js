var b = wx.$e;
(function (window, document, fhrlzy) {
  var hyfrvz = fhrlzy['un'],
      sub9k = fhrlzy['uns'],
      mav7 = fhrlzy['static'],
      zyrv = fhrlzy['class'],
      tzrhly = fhrlzy['getset'],
      a_7co = fhrlzy['__newvec'],
      a74vm_ = laya['utils']['Browser'],
      ae = laya['events']['Event'],
      vzyrf4 = laya['events']['EventDispatcher'],
      vf4ry = laya['resource']['HTMLImage'],
      ix$tjg = laya['utils']['Handler'],
      usk96 = laya['display']['Input'],
      rtglx = laya['net']['Loader'],
      $htl = laya['maths']['Matrix'],
      d05b = laya['renders']['Render'],
      v7a_f = laya['utils']['RunDriver'],
      xlht$ = laya['media']['Sound'],
      am7p = laya['media']['SoundChannel'],
      vf7_y = laya['media']['SoundManager'],
      w582d0 = laya['display']['Stage'],
      r4 = laya['net']['URL'],
      kn9qs = laya['utils']['Utils'],
      av = function () {
    function uq3sn9() {}return zyrv(uq3sn9, 'laya.wx.mini.MiniAdpter'), uq3sn9['getJson'] = function (hfly) {
      return JSON['parse'](hfly);
    }, uq3sn9['init'] = function ($tgxl, ecm) {
      $tgxl === void 0x0 && ($tgxl = ![]), ecm === void 0x0 && (ecm = ![]);if (uq3sn9['_inited']) return;uq3sn9['window'] = window;if (uq3sn9['window']['navigator']['userAgent']['indexOf']('MiniGame') < 0x0) return;uq3sn9['_inited'] = !![], uq3sn9['isZiYu'] = ecm, uq3sn9['isPosMsgYu'] = $tgxl, uq3sn9['EnvConfig'] = {}, !uq3sn9['isZiYu'] && (gtlrz['setNativeFileDir']('/layaairGame'), gtlrz['existDir'](gtlrz['fileNativeDir'], ix$tjg['create'](uq3sn9, uq3sn9['onMkdirCallBack']))), uq3sn9['window']['focus'] = function () {}, fhrlzy['getUrlPath'] = function () {}, uq3sn9['window']['logtime'] = function (hzfr) {}, uq3sn9['window']['alertTimeLog'] = function (am4_c7) {}, uq3sn9['window']['resetShareInfo'] = function () {}, uq3sn9['window']['CanvasRenderingContext2D'] = function () {}, uq3sn9['window']['CanvasRenderingContext2D']['prototype'] = uq3sn9['window']['wx']['createCanvas']()['getContext']('2d')['__proto__'], uq3sn9['window']['document']['body']['appendChild'] = function () {}, uq3sn9['EnvConfig']['pixelRatioInt'] = 0x0, v7a_f['getPixelRatio'] = uq3sn9['pixelRatio'], uq3sn9['_preCreateElement'] = a74vm_['createElement'], a74vm_['createElement'] = uq3sn9['createElement'], v7a_f['createShaderCondition'] = uq3sn9['createShaderCondition'], kn9qs['parseXMLFromString'] = uq3sn9['parseXMLFromString'], usk96['_createInputElement'] = jx3$ig['_createInputElement'], uq3sn9['EnvConfig']['load'] = rtglx['prototype']['load'], rtglx['prototype']['load'] = s9b60k['prototype']['load'], uq3sn9['isZiYu'] && $tgxl && wx['onMessage'](function (m_ao7c) {
        m_ao7c['isLoad'] && (gtlrz['ziyuFileData'][m_ao7c['url']] = m_ao7c['data']);
      });
    }, uq3sn9['onMkdirCallBack'] = function (snku96, tzlrgh) {
      if (!snku96) gtlrz['filesListObj'] = JSON['parse'](tzlrgh['data']);
    }, uq3sn9['pixelRatio'] = function () {
      if (!uq3sn9['EnvConfig']['pixelRatioInt']) try {
        var fv4a_ = wx['getSystemInfoSync']();return uq3sn9['EnvConfig']['pixelRatioInt'] = fv4a_['pixelRatio'], fv4a_ = fv4a_, fv4a_['pixelRatio'];
      } catch (y_v7) {}return uq3sn9['EnvConfig']['pixelRatioInt'];
    }, uq3sn9['createElement'] = function (a7poc) {
      if (a7poc == 'canvas') {
        var s93nuq;return uq3sn9['idx'] == 0x1 ? uq3sn9['isZiYu'] ? (s93nuq = sharedCanvas, s93nuq['style'] = {}) : s93nuq = window['canvas'] : s93nuq = window['wx']['createCanvas'](), uq3sn9['idx']++, s93nuq;
      } else {
        if (a7poc == 'textarea' || a7poc == 'input') return uq3sn9['onCreateInput'](a7poc);else {
          if (a7poc == 'div') {
            var qn9s = uq3sn9['_preCreateElement'](a7poc);return qn9s['contains'] = function (_74vy) {
              return null;
            }, qn9s['removeChild'] = function (rzfhly) {}, qn9s;
          } else return uq3sn9['_preCreateElement'](a7poc);
        }
      }
    }, uq3sn9['onCreateInput'] = function (l$igxt) {
      var zy4fvr = uq3sn9['_preCreateElement'](l$igxt);return zy4fvr['focus'] = jx3$ig['wxinputFocus'], zy4fvr['blur'] = jx3$ig['wxinputblur'], zy4fvr['style'] = {}, zy4fvr['value'] = 0x0, zy4fvr['parentElement'] = {}, zy4fvr['placeholder'] = {}, zy4fvr['type'] = {}, zy4fvr['setColor'] = function (v47_a) {}, zy4fvr['setType'] = function (frzly) {}, zy4fvr['setFontFace'] = function (n$qji) {}, zy4fvr['addEventListener'] = function (qnks9) {}, zy4fvr['contains'] = function (qnsu39) {
        return null;
      }, zy4fvr['removeChild'] = function (i$xq3) {}, zy4fvr;
    }, uq3sn9['createShaderCondition'] = function (_amo) {
      var ku9n = this,
          lixgt = function () {
        var va74 = _amo;return ku9n[_amo['replace']('this.', '')];
      };return lixgt;
    }, uq3sn9['EnvConfig'] = null, uq3sn9['window'] = null, uq3sn9['_preCreateElement'] = null, uq3sn9['_inited'] = ![], uq3sn9['wxRequest'] = null, uq3sn9['systemInfo'] = null, uq3sn9['version'] = '0.0.1', uq3sn9['isZiYu'] = ![], uq3sn9['isPosMsgYu'] = ![], uq3sn9['parseXMLFromString'] = function (sbu96) {
      var lrxt, jxtgi$;sbu96 = sbu96['replace'](/>\s+</g, '><');try {
        lrxt = new window['Parser']['DOMParser']()['parseFromString'](sbu96, 'text/xml');
      } catch (mao) {
        throw '需要引入xml解析库文件';
      }return lrxt;
    }, uq3sn9['idx'] = 0x1, uq3sn9;
  }(),
      k6us9b = function () {
    function ig$j3() {}zyrv(ig$j3, 'laya.wx.mini.MiniImage');var sku69b = ig$j3['prototype'];return sku69b['_loadImage'] = function (xhrgtl) {
      var lyzh = this,
          $j3ni = ![];xhrgtl['indexOf']('layaNativeDir/') == -0x1 && ($j3ni = !![], xhrgtl = r4['formatURL'](xhrgtl));if (!gtlrz['getFileInfo'](xhrgtl)) {
        if (xhrgtl['indexOf']('http://') != -0x1 || xhrgtl['indexOf']('https://') != -0x1) gtlrz['downImg'](xhrgtl, new ix$tjg(ig$j3, ig$j3['onDownImgCallBack'], [xhrgtl, lyzh]), xhrgtl);else ig$j3['onCreateImage'](xhrgtl, lyzh, !![]);
      } else ig$j3['onCreateImage'](xhrgtl, lyzh, !$j3ni);
    }, ig$j3['onDownImgCallBack'] = function (hztyl, gilxt$, $tgxh) {
      if (!$tgxh) ig$j3['onCreateImage'](hztyl, gilxt$);else gilxt$['onError'](null);
    }, ig$j3['onCreateImage'] = function (_7f4y, meap, skb960) {
      skb960 === void 0x0 && (skb960 = ![]);var niq;if (!skb960) {
        var pc7o = gtlrz['getFileInfo'](_7f4y),
            cm_a47 = pc7o['md5'];niq = gtlrz['getFileNativePath'](cm_a47);
      } else niq = _7f4y;if (meap['imgCache'] == null) meap['imgCache'] = {};var tixjg;function i$xj() {
        tixjg['onload'] = null, tixjg['onerror'] = null, delete meap['imgCache'][_7f4y];
      };var eopma = function () {
        i$xj(), meap['onLoaded'](tixjg);
      },
          nuj = function () {
        i$xj(), meap['event']('error', 'Load image failed');
      };meap['_type'] == 'nativeimage' ? (tixjg = new a74vm_['window']['Image'](), tixjg['crossOrigin'] = '', tixjg['onload'] = eopma, tixjg['onerror'] = nuj, tixjg['src'] = niq, meap['imgCache'][_7f4y] = tixjg) : new vf4ry['create'](niq, { 'onload': eopma, 'onerror': nuj, 'onCreate': function (j3nuqi) {
          tixjg = j3nuqi, meap['imgCache'][_7f4y] = j3nuqi;
        } });
    }, ig$j3;
  }(),
      jx3$ig = function () {
    function xtglh() {}return zyrv(xtglh, 'laya.wx.mini.MiniInput'), xtglh['_createInputElement'] = function () {
      usk96['_initInput'](usk96['area'] = a74vm_['createElement']('textarea')), usk96['_initInput'](usk96['input'] = a74vm_['createElement']('input')), usk96['inputContainer'] = a74vm_['createElement']('div'), usk96['inputContainer']['style']['position'] = 'absolute', usk96['inputContainer']['style']['zIndex'] = 0x186a0, a74vm_['container']['appendChild'](usk96['inputContainer']), usk96['inputContainer']['setPos'] = function (rhlt, b9usk6) {
        usk96['inputContainer']['style']['left'] = rhlt + 'px', usk96['inputContainer']['style']['top'] = b9usk6 + 'px';
      }, fhrlzy['stage']['on']('resize', null, xtglh['_onStageResize']), wx['onWindowResize'] && wx['onWindowResize'](function (rlxth) {
        window['dispatchEvent'] && window['dispatchEvent']('resize');
      }), vf7_y['_soundClass'] = tig$lx, vf7_y['_musicClass'] = tig$lx, window['_videoClass'] = v_7fa4;
    }, xtglh['_onStageResize'] = function () {
      var i$gjx = fhrlzy['stage']['_canvasTransform']['identity']();i$gjx['scale'](a74vm_['width'] / d05b['canvas']['width'] / v7a_f['getPixelRatio'](), a74vm_['height'] / d05b['canvas']['height'] / v7a_f['getPixelRatio']());
    }, xtglh['wxinputFocus'] = function (vf7_y4) {
      var grthx = usk96['inputElement']['target'];if (grthx && !grthx['editable']) return;av['window']['wx']['offKeyboardConfirm'](), av['window']['wx']['offKeyboardInput'](), av['window']['wx']['showKeyboard']({ 'defaultValue': grthx['text'], 'maxLength': grthx['maxChars'], 'multiple': grthx['multiline'], 'confirmHold': !![], 'confirmType': 'done', 'success': function (am4v7) {}, 'fail': function (wd820) {} }), av['window']['wx']['onKeyboardConfirm'](function (lyzfhr) {
        var hvyfrz = lyzfhr ? lyzfhr['value'] : '';grthx['text'] = hvyfrz, grthx['event']('input'), laya['wx']['mini']['MiniInput']['inputEnter']();
      }), av['window']['wx']['onKeyboardInput'](function (kb5d0) {
        var $ijtgx = kb5d0 ? kb5d0['value'] : '';if (!grthx['multiline']) {
          if ($ijtgx['indexOf']('\x0a') != -0x1) {
            laya['wx']['mini']['MiniInput']['inputEnter']();return;
          }
        }grthx['text'] = $ijtgx, grthx['event']('input');
      });
    }, xtglh['inputEnter'] = function () {
      usk96['inputElement']['target']['focus'] = ![];
    }, xtglh['wxinputblur'] = function () {
      xtglh['hideKeyboard']();
    }, xtglh['hideKeyboard'] = function () {
      av['window']['wx']['offKeyboardConfirm'](), av['window']['wx']['offKeyboardInput'](), av['window']['wx']['hideKeyboard']({ 'success': function (vyf4r) {
          console['log']('隐藏键盘');
        }, 'fail': function (n39q) {
          console['log']('隐藏键盘出错:' + (n39q ? n39q['errMsg'] : ''));
        } });
    }, xtglh;
  }(),
      s9b60k = function () {
    function cm4a_7() {}zyrv(cm4a_7, 'laya.wx.mini.MiniLoader');var ij$x3 = cm4a_7['prototype'];return ij$x3['load'] = function (s9b6ku, k069bd, oam_7, maocep, w58db) {
      oam_7 === void 0x0 && (oam_7 = !![]), w58db === void 0x0 && (w58db = ![]);var b6kd = this;b6kd['_url'] = s9b6ku;if (s9b6ku['indexOf']('data:image') === 0x0) b6kd['_type'] = k069bd = 'image';else b6kd['_type'] = k069bd || (k069bd = b6kd['getTypeFromUrl'](s9b6ku));b6kd['_cache'] = oam_7, b6kd['_data'] = null;var zyr4v = 'ascii';if (s9b6ku['indexOf']('.fnt') != -0x1) zyr4v = 'utf8';else k069bd == 'arraybuffer' && (zyr4v = '');;var ltxrgh = kn9qs['getFileExtension'](s9b6ku);if (cm4a_7['_fileTypeArr']['indexOf'](ltxrgh) != -0x1) av['EnvConfig']['load']['call'](this, s9b6ku, k069bd, oam_7, maocep, w58db);else {
        if (!gtlrz['getFileInfo'](s9b6ku)) {
          if (s9b6ku['indexOf']('layaNativeDir/') != -0x1) {
            if (av['isZiYu']) {
              var k9nsu = gtlrz['ziyuFileData'][s9b6ku];b6kd['onLoaded'](k9nsu);return;
            } else {
              cosnole['log']('read read'), gtlrz['read'](s9b6ku, zyr4v, new ix$tjg(cm4a_7, cm4a_7['onReadNativeCallBack'], [zyr4v, s9b6ku, k069bd, oam_7, maocep, w58db, b6kd]));return;
            }
          }if (r4['rootPath'] == '') var k9unqs = s9b6ku;else k9unqs = s9b6ku['split'](r4['rootPath'])[0x0];s9b6ku['indexOf']('http://') != -0x1 || s9b6ku['indexOf']('https://') != -0x1 ? av['EnvConfig']['load']['call'](b6kd, s9b6ku, k069bd, oam_7, maocep, w58db) : gtlrz['readFile'](k9unqs, zyr4v, new ix$tjg(cm4a_7, cm4a_7['onReadNativeCallBack'], [zyr4v, s9b6ku, k069bd, oam_7, maocep, w58db, b6kd]), s9b6ku);
        } else av['EnvConfig']['load']['call'](this, s9b6ku, k069bd, oam_7, maocep, w58db);
      }
    }, ij$x3['resMgrLoad'] = function (mcao7_, hg$xtl, v47_yf, gxl$ti, c7moa, q9u, h$txg) {
      v47_yf === void 0x0 && (v47_yf = 0x0), gxl$ti === void 0x0 && (gxl$ti = ![]), c7moa === void 0x0 && (c7moa = ![]), q9u === void 0x0 && (q9u = 0x0), h$txg === void 0x0 && (h$txg = 0x3), mcao7_['indexOf']('mpack') != -0x1 && console['log']('=============resMgrLoad url:', mcao7_), av['EnvConfig']['resMgrLoad'](mcao7_, (xjtg$i, j$nq, nqk) => {
        cm4a_7['prototype']['resMgrLoadCallBack'](xjtg$i, j$nq, nqk, hg$xtl);
      }, v47_yf, gxl$ti, c7moa, q9u, h$txg);
    }, ij$x3['resMgrLoadCallBack'] = function (ij$xtg, _7fy, nj3squ, i3n$jq) {
      console['log']('buff:::', ij$xtg, nj3squ, gtlrz['fileNativeDir'] + '///' + gtlrz['fileListName']), i3n$jq(ij$xtg, _7fy, nj3squ);
    }, ij$x3['clearRes'] = function (_y4f7, v_y47) {
      v_y47 === void 0x0 && (v_y47 = ![]);var unjq = this;unjq['clearRes'](_y4f7, v_y47);var dw281 = gtlrz['getFileInfo'](_y4f7);if (dw281 && (_y4f7['indexOf']('http://') != -0x1 || _y4f7['indexOf']('https://') != -0x1)) {
        var $ij3qn = dw281['md5'],
            eopcma = gtlrz['getFileNativePath']($ij3qn);gtlrz['remove'](eopcma);
      }
    }, cm4a_7['onReadNativeCallBack'] = function (meoap, sk0b69, tzyhrl, rvzfhy, qnu3js, fy4zrv, hflrz, zv_y, hlfzy) {
      rvzfhy === void 0x0 && (rvzfhy = !![]), fy4zrv === void 0x0 && (fy4zrv = ![]), zv_y === void 0x0 && (zv_y = 0x0);if (!zv_y) {
        var tgixj$;if (tzyhrl == 'json' || tzyhrl == 'atlas') tgixj$ = av['getJson'](hlfzy['data']);else tzyhrl == 'xml' ? tgixj$ = kn9qs['parseXMLFromString'](hlfzy['data']) : tgixj$ = hlfzy['data'];hflrz['onLoaded'](tgixj$), !av['isZiYu'] && av['isPosMsgYu'] && tzyhrl != 'arraybuffer' && wx['postMessage']({ 'url': sk0b69, 'data': tgixj$, 'isLoad': !![] });
      } else zv_y == 0x1 && av['EnvConfig']['load']['call'](hflrz, sk0b69, tzyhrl, rvzfhy, qnu3js, fy4zrv);
    }, mav7(cm4a_7, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['png', 'jpg', 'bmp', 'jpeg', 'gif'];
    }]), cm4a_7;
  }(),
      gtlrz = function (b6850d) {
    function ujq3() {
      ujq3['__super']['call'](this);;
    }return zyrv(ujq3, 'laya.wx.mini.MiniFileMgr', b6850d), ujq3['isLoadFile'] = function (jixg3) {
      return ujq3['_fileTypeArr']['indexOf'](jixg3) != -0x1 ? !![] : ![];
    }, ujq3['getFileInfo'] = function (vfrh) {
      var j$xgi = vfrh['split']('?')[0x0],
          hzrlyt = ujq3['filesListObj'][j$xgi];if (hzrlyt == null) return null;else return hzrlyt;return null;
    }, ujq3['onFileUpdate'] = function (gj3x$, _4a7cm) {
      var yrltzh = gj3x$['split']('/'),
          a_4fv = yrltzh[yrltzh['length'] - 0x1],
          f4yvr = ujq3['getFileInfo'](_4a7cm);if (f4yvr == null) ujq3['onSaveFile'](_4a7cm, a_4fv);else {
        if (f4yvr['readyUrl'] != _4a7cm) ujq3['remove'](a_4fv, _4a7cm);
      }
    }, ujq3['exits'] = function (nu39q, yv4f7_) {
      var hryl = ujq3['getFileNativePath'](nu39q);ujq3['fs']['getFileInfo']({ 'filePath': hryl, 'success': function (ltg$hx) {
          yv4f7_ != null && yv4f7_['runWith']([0x0, ltg$hx]);
        }, 'fail': function (f_4va7) {
          yv4f7_ != null && yv4f7_['runWith']([0x1, f_4va7]);
        } });
    }, ujq3['read'] = function (fvhr, hgtrlx, s3u9nq, v4yfr) {
      hgtrlx === void 0x0 && (hgtrlx = 'ascill'), v4yfr === void 0x0 && (v4yfr = '');var bs9;v4yfr != '' ? bs9 = ujq3['getFileNativePath'](fvhr) : bs9 = fvhr, ujq3['fs']['readFile']({ 'filePath': bs9, 'encoding': hgtrlx, 'success': function (xhtgr) {
          s3u9nq != null && s3u9nq['runWith']([0x0, xhtgr]);
        }, 'fail': function (hrytlz) {
          if (hrytlz && v4yfr != '') ujq3['down'](v4yfr, hgtrlx, s3u9nq, v4yfr);else s3u9nq != null && s3u9nq['runWith']([0x1]);
        } });
    }, ujq3['readNativeFile'] = function (f7v4_, un9s3q) {
      ujq3['fs']['readFile']({ 'filePath': f7v4_, 'encoding': '', 'success': function (ltrhyz) {
          un9s3q != null && un9s3q['runWith']([0x0]);
        }, 'fail': function (x$t) {
          un9s3q != null && un9s3q['runWith']([0x1]);
        } });
    }, ujq3['down'] = function (xg$it, gtlix$, _4fzy, k605b) {
      gtlix$ === void 0x0 && (gtlix$ = 'ascill'), k605b === void 0x0 && (k605b = '');var xi$3q = ujq3['getFileNativePath'](k605b),
          v_yz = ujq3['wxdown']({ 'url': xg$it, 'filePath': xi$3q, 'success': function (ltryzh) {
          if (ltryzh['statusCode'] === 0xc8) ujq3['readFile'](ltryzh['filePath'], gtlix$, _4fzy, k605b);
        }, 'fail': function (moa7_) {
          _4fzy != null && _4fzy['runWith']([0x1, moa7_]);
        } });v_yz['onProgressUpdate'](function (bk06d) {
        _4fzy != null && _4fzy['runWith']([0x2, bk06d['progress']]);
      });
    }, ujq3['readFile'] = function (x$lht, gzthlr, ju3snq, d09b6) {
      gzthlr === void 0x0 && (gzthlr = 'ascill'), d09b6 === void 0x0 && (d09b6 = ''), ujq3['fs']['readFile']({ 'filePath': x$lht, 'encoding': gzthlr, 'success': function (empaoc) {
          if (x$lht['indexOf']('http://') != -0x1 || x$lht['indexOf']('https://') != -0x1) ujq3['onFileUpdate'](x$lht, d09b6);ju3snq != null && ju3snq['runWith']([0x0, empaoc]);
        }, 'fail': function (nsku) {
          if (nsku) ju3snq != null && ju3snq['runWith']([0x1, nsku]);
        } });
    }, ujq3['downImg'] = function (jsq3un, jniu3q, $gtixl) {
      $gtixl === void 0x0 && ($gtixl = '');var ma_v47 = ujq3['wxdown']({ 'url': jsq3un, 'success': function (nqus) {
          nqus['statusCode'] === 0xc8 && ujq3['copyFile'](nqus['tempFilePath'], $gtixl, jniu3q);
        }, 'fail': function (_vm47a) {
          jniu3q != null && jniu3q['runWith']([0x1, _vm47a]);
        } });
    }, ujq3['copyFile'] = function (v74yf, d0bw58, bk96s0) {
      var ixj$ = v74yf['split']('/'),
          qu3ji = ixj$[ixj$['length'] - 0x1],
          fy4r = d0bw58['split']('?')[0x0],
          ij$xgt = ujq3['getFileInfo'](d0bw58),
          fv4zry = ujq3['getFileNativePath'](qu3ji);ujq3['fs']['copyFile']({ 'srcPath': v74yf, 'destPath': fv4zry, 'success': function (nkqs) {
          if (!ij$xgt) ujq3['onSaveFile'](d0bw58, qu3ji), bk96s0 != null && bk96s0['runWith']([0x0]);else {
            if (ij$xgt['readyUrl'] != d0bw58) ujq3['remove'](qu3ji, d0bw58, bk96s0);
          }
        }, 'fail': function (ji3$x) {
          bk96s0 != null && bk96s0['runWith']([0x1, ji3$x]);
        } });
    }, ujq3['getFileNativePath'] = function (wb5d) {
      return laya['wx']['mini']['MiniFileMgr']['fileNativeDir'] + '/' + wb5d;
    }, ujq3['remove'] = function (yz_vf, ujqi3n, fvyhzr) {
      ujqi3n === void 0x0 && (ujqi3n = '');var j$3qxi = ujq3['getFileInfo'](ujqi3n),
          a7v_f4 = ujq3['getFileNativePath'](j$3qxi['md5']);fhrlzy['loader']['clearRes'](j$3qxi['readyUrl']), ujq3['fs']['unlink']({ 'filePath': a7v_f4, 'success': function (pemcoa) {
          if (ujqi3n != '') ujq3['onSaveFile'](ujqi3n, yz_vf);fvyhzr != null && fvyhzr['runWith']([0x0]);
        }, 'fail': function (rfz4vy) {} });
    }, ujq3['onSaveFile'] = function (glxi, b0d6) {
      var zvyf4_ = glxi['split']('?')[0x0];ujq3['filesListObj'][zvyf4_] = { 'md5': b0d6, 'readyUrl': glxi }, ujq3['fs']['writeFile']({ 'filePath': ujq3['fileNativeDir'] + '/' + ujq3['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](ujq3['filesListObj']), 'success': function (f_4zvy) {
          console['log']('写入测试测试成功：', f_4zvy);
        }, 'fail': function (hrfy) {
          console['log']('写入测试测试失败：', hrfy);
        } });
    }, ujq3['existDir'] = function (m_ac7, m7pa) {
      ujq3['fs']['mkdir']({ 'dirPath': m_ac7, 'success': function (quk9) {
          m7pa != null && m7pa['runWith']([0x0, { 'data': JSON['stringify']({}) }]);
        }, 'fail': function (bk6s09) {
          if (bk6s09['errMsg']['indexOf']('file already exists') != -0x1) ujq3['readSync'](ujq3['fileListName'], 'utf8', m7pa);else m7pa != null && m7pa['runWith']([0x1, bk6s09]);
        } });
    }, ujq3['readSync'] = function (sn6, j$iq, kbus9, skbu9) {
      j$iq === void 0x0 && (j$iq = 'ascill'), skbu9 === void 0x0 && (skbu9 = '');var meo = ujq3['getFileNativePath'](sn6),
          ig$txj;try {
        ig$txj = ujq3['fs']['readFileSync'](meo), kbus9 != null && kbus9['runWith']([0x0, { 'data': ig$txj }]);
      } catch (grtx) {
        kbus9 != null && kbus9['runWith']([0x1]);
      }
    }, ujq3['readCache'] = function () {}, ujq3['writeCache'] = function (coemp) {
      var rghl = readyUrl['split']('?')[0x0];ujq3['filesListObj'][rghl] = { 'md5': md5Name, 'readyUrl': readyUrl }, ujq3['fs']['writeFile']({ 'filePath': ujq3['fileNativeDir'] + '/' + ujq3['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](ujq3['filesListObj']), 'success': function (i$q3nj) {}, 'fail': function (sku9q) {} });
    }, ujq3['setNativeFileDir'] = function (pamoce) {
      ujq3['fileNativeDir'] = wx['env']['USER_DATA_PATH'] + pamoce;
    }, ujq3['filesListObj'] = {}, ujq3['fileNativeDir'] = null, ujq3['fileListName'] = 'layaairfiles.txt', ujq3['ziyuFileData'] = {}, mav7(ujq3, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['json', 'ani', 'xml', 'sk', 'txt', 'atlas', 'swf', 'part', 'fnt', 'proto', 'lh', 'lav', 'lani', 'lmat', 'lm', 'ltc'];
    }, 'fs', function () {
      return this['fs'] = wx['getFileSystemManager']();
    }, 'wxdown', function () {
      return this['wxdown'] = wx['downloadFile'];
    }]), ujq3;
  }(vzyrf4),
      tig$lx = function (pme) {
    function qj3ix$() {
      this['_sound'] = null, this['_chanell'] = null, this['url'] = null, this['loaded'] = ![], qj3ix$['__super']['call'](this), this['_sound'] = qj3ix$['_createSound'](), this['_chanell'] = new ghrxtl(this['_sound']);
    }zyrv(qj3ix$, 'laya.wx.mini.MiniSound', pme);var i$3xq = qj3ix$['prototype'];return i$3xq['load'] = function (a7f4v) {
      var c_74am = this;a7f4v = r4['formatURL'](a7f4v), this['url'] = a7f4v;if (qj3ix$['_audioCache'][a7f4v]) {
        this['event']('complete');return;
      }function hgrtz() {
        if (qj3ix$['_null'] != undefined) c_74am['_sound']['onCanplay'](qj3ix$['_null']), c_74am['_sound']['onError'](qj3ix$['_null']);else try {
          c_74am['_sound']['onCanplay'](null), c_74am['_sound']['onError'](null), qj3ix$['_null'] = null;
        } catch (a_47v) {
          console['warn']('[wxmini] _clearSound:' + a_47v), c_74am['_sound']['onCanplay'](u9sq3), c_74am['_sound']['onError'](u9sq3), qj3ix$['_null'] = u9sq3;
        }
      }function tligx$() {
        htl['loaded'] = !![], htl['event']('complete'), qj3ix$['_audioCache'][htl['url']] = htl;
      }function n3i$qj(qnu9ks) {
        console['error']('errCode=' + qnu9ks['errCode'] + '  errMsg=' + qnu9ks['errMsg']), htl['event']('error');
      }function u9sq3() {}this['_sound']['onCanplay'](tligx$), this['_sound']['onError'](n3i$qj), this['_sound']['src'] = a7f4v;var htl = this;
    }, i$3xq['play'] = function (qujin3, yhrlt) {
      qujin3 === void 0x0 && (qujin3 = 0x0), yhrlt === void 0x0 && (yhrlt = 0x0);var c_a7m4, nuks9q;if (this['url'] == vf7_y['_tMusic']) {
        if (!qj3ix$['_musicAudio']) qj3ix$['_musicAudio'] = this['_sound'];c_a7m4 = qj3ix$['_musicAudio'], nuks9q = this['_chanell'];
      } else c_a7m4 = this['_sound'], nuks9q = this['_chanell'];return c_a7m4['src'] = this['url'], c_a7m4['startTime'] = 0x0, nuks9q['isStopped'] && (nuks9q['url'] = this['url'], nuks9q['loops'] = yhrlt, nuks9q['startTime'] = qujin3, nuks9q['play'](), vf7_y['addChannel'](nuks9q)), nuks9q;
    }, i$3xq['dispose'] = function () {
      var fvzy_ = qj3ix$['_audioCache'][this['url']];fvzy_ && (fvzy_['src'] = '', delete qj3ix$['_audioCache'][this['url']]);
    }, tzrhly(0x0, i$3xq, 'duration', function () {
      return this['_sound']['duration'];
    }), qj3ix$['_createSound'] = function () {
      qj3ix$['_id']++;var d05bw8 = av['window']['wx']['createInnerAudioContext']({ 'useWebAudioImplement': ![] });return d05bw8;
    }, qj3ix$['_musicAudio'] = null, qj3ix$['_id'] = 0x0, qj3ix$['_audioCache'] = {}, qj3ix$['_null'] = undefined, qj3ix$;
  }(vzyrf4),
      ghrxtl = function (quskn9) {
    function ksb9u(f7_y4v) {
      this['_audio'] = null, this['_onEnd'] = null, ksb9u['__super']['call'](this), this['isStopped'] = !![], this['_audio'] = f7_y4v, this['_onEnd'] = kn9qs['bind'](this['__onEnd'], this), f7_y4v['onEnded'](this['_onEnd']);
    }zyrv(ksb9u, 'laya.wx.mini.MiniSoundChannel', quskn9);var v4_7fy = ksb9u['prototype'];return v4_7fy['__onEnd'] = function () {
      if (this['loops'] == 0x1) {
        this['completeHandler'] && (fhrlzy['timer']['once'](0xa, this, this['__runComplete'], [this['completeHandler']], ![]), this['completeHandler'] = null);this['stop'](), this['event']('complete');return;
      }this['loops'] > 0x0 && this['loops']--, this['startTime'] = 0x0, this['play']();
    }, v4_7fy['__onNull'] = function () {}, v4_7fy['play'] = function () {
      this['isStopped'] = ![], vf7_y['addChannel'](this);if (this['_audio']) this['_audio']['play']();
    }, v4_7fy['stop'] = function () {
      this['isStopped'] = !![], vf7_y['removeChannel'](this), this['completeHandler'] = null;if (!this['_audio']) return;this['_audio']['stop']();
    }, v4_7fy['pause'] = function () {
      this['isStopped'] = !![], this['_audio']['pause']();
    }, v4_7fy['resume'] = function () {
      if (!this['_audio']) return;this['isStopped'] = ![], vf7_y['addChannel'](this), this['_audio']['play']();
    }, tzrhly(0x0, v4_7fy, 'position', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['currentTime'];
    }), tzrhly(0x0, v4_7fy, 'duration', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['duration'];
    }), tzrhly(0x0, v4_7fy, 'volume', function () {
      return 0x1;
    }, function (p7c) {}), ksb9u['_null'] = undefined, ksb9u;
  }(am7p),
      v_7fa4 = function () {
    function fz4vyr() {
      this['videoend'] = ![], this['videourl'] = '', this['videoElement'] = av['window']['wx']['createVideo']({ 'showCenterPlayBtn': ![], 'showProgressInControlMode': ![], 'objectFit': 'fill' });
    }zyrv(fz4vyr, 'laya.wx.mini.MiniVideo');var _fy74v = fz4vyr['prototype'];return _fy74v['on'] = function (zrghlt, j3nqu, w2d85) {
      if (zrghlt == 'loadedmetadata') this['onPlayFunc'] = w2d85['bind'](j3nqu), this['videoElement']['onPlay'] = this['onPlayFunction']['bind'](this);else zrghlt == 'ended' && (this['onEndedFunC'] = w2d85['bind'](j3nqu), this['videoElement']['onEnded'] = this['onEndedFunction']['bind'](this));this['videoElement']['onTimeUpdate'] = this['onTimeUpdateFunc']['bind'](this);
    }, _fy74v['onTimeUpdateFunc'] = function (lyfzh) {
      this['position'] = lyfzh['position'], this['_duration'] = lyfzh['duration'];
    }, _fy74v['onPlayFunction'] = function () {
      if (this['videoElement']) this['videoElement']['readyState'] = 0xc8;console['log']('=====视频加载完成========'), this['onPlayFunc'] != null && this['onPlayFunc']();
    }, _fy74v['onended'] = function (tj$xig, w8205) {
      this['onEndedFunC'] = w8205['bind'](tj$xig), this['videoElement']['onended'] = this['onEndedFunction']['bind'](this);
    }, _fy74v['onEndedFunction'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], console['log']('=====视频播放完毕========'), this['onEndedFunC'] != null && this['onEndedFunC']();
    }, _fy74v['off'] = function (v7a4_, tx$igl, k6b0d) {
      if (v7a4_ == 'loadedmetadata') this['onPlayFunc'] = k6b0d['bind'](tx$igl), this['videoElement']['offPlay'] = this['onPlayFunction']['bind'](this);else v7a4_ == 'ended' && (this['onEndedFunC'] = k6b0d['bind'](tx$igl), this['videoElement']['offEnded'] = this['onEndedFunction']['bind'](this));
    }, _fy74v['load'] = function (lhtgx) {
      if (!this['videoElement']) return;this['videoElement']['src'] = lhtgx;
    }, _fy74v['play'] = function () {
      if (!this['videoElement']) return;this['videoend'] = ![], this['videoElement']['play']();
    }, _fy74v['pause'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], this['videoElement']['pause']();
    }, _fy74v['size'] = function (zyvr, f_yzv) {
      if (!this['videoElement']) return;this['videoElement']['width'] = zyvr, this['videoElement']['height'] = f_yzv;
    }, _fy74v['destroy'] = function () {
      if (this['videoElement']) this['videoElement']['destroy']();this['videoElement'] = null, this['onEndedFunC'] = null, this['onPlayFunc'] = null, this['videoend'] = ![], this['videourl'] = null;
    }, _fy74v['reload'] = function () {
      if (!this['videoElement']) return;this['videoElement']['src'] = this['videourl'];
    }, tzrhly(0x0, _fy74v, 'duration', function () {
      return this['_duration'];
    }), tzrhly(0x0, _fy74v, 'currentTime', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['initialTime'];
    }, function (ji3x$) {
      if (!this['videoElement']) return;this['videoElement']['initialTime'] = ji3x$;
    }), tzrhly(0x0, _fy74v, 'videoWidth', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['width'];
    }), tzrhly(0x0, _fy74v, 'videoHeight', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['height'];
    }), tzrhly(0x0, _fy74v, 'ended', function () {
      return this['videoend'];
    }), tzrhly(0x0, _fy74v, 'loop', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['loop'];
    }, function (i$glx) {
      if (!this['videoElement']) return;this['videoElement']['loop'] = i$glx;
    }), tzrhly(0x0, _fy74v, 'playbackRate', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['playbackRate'];
    }, function (c7m_o) {
      if (!this['videoElement']) return;this['videoElement']['playbackRate'] = c7m_o;
    }), tzrhly(0x0, _fy74v, 'muted', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['muted'];
    }, function (yfhl) {
      if (!this['videoElement']) return;this['videoElement']['muted'] = yfhl;
    }), tzrhly(0x0, _fy74v, 'paused', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['paused'];
    }), tzrhly(0x0, _fy74v, 'x', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['x'];
    }, function (cm4) {
      if (!this['videoElement']) return;this['videoElement']['x'] = cm4;
    }), tzrhly(0x0, _fy74v, 'y', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['y'];
    }, function (fzrhy) {
      if (!this['videoElement']) return;this['videoElement']['y'] = fzrhy;
    }), tzrhly(0x0, _fy74v, 'currentSrc', function () {
      return this['videoElement']['src'];
    }), tzrhly(0x0, _fy74v, 'src', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['src'];
    }, function (lrxgh) {
      if (!this['videoElement']) return;this['videoElement']['src'] = lrxgh;
    }), tzrhly(0x0, _fy74v, 'controls', function () {
      if (!this['videoElement']) return;return this['videoElement']['controls'];
    }, function (y_vzf) {
      if (!this['videoElement']) return;this['videoElement']['controls'] = y_vzf;
    }), tzrhly(0x0, _fy74v, 'autoplay', function () {
      if (!this['videoElement']) return;return this['videoElement']['autoplay'];
    }, function (jnqs3) {
      if (!this['videoElement']) return;this['videoElement']['autoplay'] = jnqs3;
    }), fz4vyr;
  }();
})(window, document, Laya);typeof define === 'function' && define['amd'] && define('laya.core', ['require', 'exports'], function (require, exports) {
  'use strict';
  Object['defineProperty'](exports, '__esModule', { 'value': !![] });for (var a_m4v in Laya) {
    var zlhrg = Laya[a_m4v];zlhrg && zlhrg['__isclass'] && (exports[a_m4v] = zlhrg);
  }
});