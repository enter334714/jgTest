﻿var sdk_conf = {
  game_id: '256', //九歌行--天枢服--官方
    game_pkg: 'tjqy_jgxxyx_AF',
    partner_id: '19',
    game_ver: '2.0.259',  //B包为2.x.x，每次上传版本修改，先设置，上传审核版本的时候保持一致
    is_auth: false,  //授权登录
    from: null, //来源
    tmpId: {1:'EINuK1ZxS2r8DUPVqymQs_JbjT6nV5o_bo-wc67bbs8', 2:'JJ3T3yUyMvF_XfMKx3fFEPYJV8iZHI4M8Do5ddeN7sM', 3:'snQEtMujGdKT78ppl6C_k6z2Tzvp3W-2E_Tr02w2pB0'},  // 订阅的类型 和 模板id
    min_app_id: '',
};

module.exports = sdk_conf;