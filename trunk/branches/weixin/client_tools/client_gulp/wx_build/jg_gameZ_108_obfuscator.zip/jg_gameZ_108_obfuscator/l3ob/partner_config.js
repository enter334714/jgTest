var _j = wx.n$;
var sdk_conf = {
  game_id: _j[0],
  game_pkg: _j[1],
  partner_label: _j[2],
  partner_id: _j[3],
  game_ver: _j[4],
  is_auth: false //授权登录

};
window.config = sdk_conf;
module.exports = sdk_conf;