import Sdk from './sdk.d';
declare const defaultInstance: Sdk;
export default defaultInstance;