var _j = wx.n$;
import _qauv9kc from '../l3ob/x8a.js';
window[_j[1179]] = { 'wxVersion': window[_j[1054]][_j[1180]] }, window[_j[1181]] = ![], window['y$5X'] = 0x1, window[_j[1182]] = 0x1, window['y$TX5'] = !![], window[_j[1183]] = !![], window['y$HITX5'] = '', window[_j[1184]] = ![], window['y$X5'] = {
    'base_cdn': _j[1185],
    'cdn': _j[1185]
}, y$X5[_j[1186]] = {}, y$X5[_j[602]] = '0', y$X5[_j[1187]] = window[_j[1179]][_j[864]], y$X5[_j[1188]] = '', y$X5['os'] = '1', y$X5[_j[1189]] = _j[1190], y$X5[_j[1191]] = _j[1192], y$X5[_j[1193]] = _j[1194], y$X5[_j[1195]] = _j[1196], y$X5[_j[1197]] = _j[1198], y$X5[_j[1199]] = '1', y$X5[_j[944]] = '', y$X5[_j[1200]] = '', y$X5[_j[1201]] = 0x0, y$X5[_j[978]] = {}, y$X5[_j[1202]] = parseInt(y$X5[_j[1199]]), y$X5[_j[1203]] = y$X5[_j[1199]], y$X5[_j[807]] = {}, y$X5['y$IX'] = _j[1204], y$X5[_j[1205]] = ![], y$X5[_j[1206]] = _j[1207], y$X5[_j[1208]] = Date[_j[802]](), y$X5[_j[1209]] = _j[1210], y$X5[_j[1211]] = '_a', y$X5[_j[1212]] = '', y$X5[_j[850]] = 0x2, y$X5[_j[862]] = 0x7c1, y$X5[_j[864]] = window[_j[1179]][_j[864]], y$X5[_j[949]] = ![], y$X5[_j[1213]] = ![], y$X5[_j[1214]] = ![], y$X5[_j[1215]] = ![], window['y$T5X'] = 0x5, window['y$T5'] = ![], window['y$5T'] = ![], window['y$XT5'] = ![], window[_j[1088]] = ![], window[_j[1099]] = ![], window['y$X5T'] = ![], window['y$TX'] = ![], window['y$XT'] = ![], window['y$5TX'] = ![], window[_j[1090]] = null, window[_j[1216]] = function (c7_o3m) {
    console[_j[566]](_j[1216], c7_o3m), wx[_j[1217]]({}), wx[_j[1218]]({
        'title': _j[1219],
        'content': c7_o3m,
        'success'(if2w) {
            if (if2w[_j[1220]]) console[_j[566]](_j[1221]);else if2w[_j[1222]] && console[_j[566]](_j[1223]);
        }
    });
}, window['y$ITX5'] = function (bqints) {
    console[_j[566]](_j[1224], bqints), y$IX5T(), wx[_j[1218]]({
        'title': _j[1219],
        'content': bqints,
        'confirmText': _j[1225],
        'cancelText': _j[1226],
        'success'(c7mv_) {
            if (c7mv_[_j[1220]]) window['y$XI']();else c7mv_[_j[1222]] && (console[_j[566]](_j[1227]), wx[_j[1228]]({}));
        }
    });
}, window[_j[1229]] = function (qf2r) {
    console[_j[566]](_j[1229], qf2r), wx[_j[1218]]({
        'title': _j[1219],
        'content': qf2r,
        'confirmText': _j[1230],
        'showCancel': ![],
        'complete'(tbsqni) {
            console[_j[566]](_j[1227]), wx[_j[1228]]({});
        }
    });
}, window['y$IT5X'] = ![], window['y$IXT5'] = function (j5yk) {
    window['y$IT5X'] = !![], wx[_j[1231]](j5yk);
}, window['y$IX5T'] = function () {
    window['y$IT5X'] && (window['y$IT5X'] = ![], wx[_j[1217]]({}));
}, window['y$I5TX'] = function (muv9a) {
    window[_j[1178]][_j[803]]['y$I5TX'](muv9a);
}, window[_j[94]] = function (pf602r, qfrwi2) {
    _qauv9kc[_j[94]](pf602r, function (itbns) {
        itbns && itbns[_j[611]] ? itbns[_j[611]][_j[984]] == 0x1 ? qfrwi2(!![]) : (qfrwi2(![]), console[_j[1232]](_j[1233] + itbns[_j[611]][_j[1234]])) : console[_j[566]](_j[94], itbns);
    });
}, window['y$I5XT'] = function (rifq2w) {
    console[_j[566]](_j[1235], rifq2w);
}, window['y$IX5'] = function (jayh) {}, window['y$I5X'] = function (u9cav, vac9mu, zehx$) {}, window['y$I5'] = function (yjakgu) {
    console[_j[566]](_j[1236], yjakgu), window[_j[1178]][_j[803]][_j[854]](), window[_j[1178]][_j[803]][_j[855]](), window[_j[1178]][_j[803]][_j[868]](), window[_j[1237]]();
}, window['y$5I'] = function (exh5) {
    window[_j[1238]](0xe, _j[1239] + exh5), window['y$ITX5'](_j[1240]);
    var hy5exj = {
        'id': window['y$X5'][_j[1241]],
        'role': window['y$X5'][_j[1242]],
        'level': window['y$X5'][_j[1243]],
        'account': window['y$X5'][_j[1244]],
        'version': window['y$X5'][_j[862]],
        'cdn': window['y$X5'][_j[973]],
        'pkgName': window['y$X5'][_j[944]],
        'gamever': window[_j[1054]][_j[1180]],
        'serverid': window['y$X5'][_j[807]] ? window['y$X5'][_j[807]][_j[71]] : 0x0,
        'systemInfo': window[_j[1245]],
        'error': _j[1246],
        'stack': exh5 ? exh5 : _j[1240]
    },
        hygja = JSON[_j[1116]](hy5exj);
    console[_j[609]](_j[1247] + hygja), window['y$IX'](hygja);
}, window[_j[1238]] = function (_p703, ibsrwq) {
    sendApi(y$X5[_j[1193]], _j[1248], {
        'game_pkg': y$X5[_j[944]],
        'partner_id': y$X5[_j[1199]],
        'server_id': y$X5[_j[807]] && y$X5[_j[807]][_j[71]] > 0x0 ? y$X5[_j[807]][_j[71]] : 0x0,
        'uid': y$X5[_j[1244]] > 0x0 ? y$X5[_j[1244]] : 0x0,
        'type': _p703,
        'info': ibsrwq
    });
}, window['y$XI5'] = function (ukavg9) {
    var fwr2 = JSON[_j[565]](ukavg9);
    fwr2[_j[1249]] = window[_j[1054]][_j[1180]], fwr2[_j[1250]] = window['y$X5'][_j[807]] ? window['y$X5'][_j[807]][_j[71]] : 0x0, fwr2[_j[1245]] = window[_j[1245]];
    var wsqi = JSON[_j[1116]](fwr2);
    console[_j[609]](_j[1251] + wsqi), window['y$IX'](wsqi);
}, window['y$X5I'] = function (vomcu9, wr62p) {
    var wrfi2p = {
        'id': window['y$X5'][_j[1241]],
        'role': window['y$X5'][_j[1242]],
        'level': window['y$X5'][_j[1243]],
        'account': window['y$X5'][_j[1244]],
        'version': window['y$X5'][_j[862]],
        'cdn': window['y$X5'][_j[973]],
        'pkgName': window['y$X5'][_j[944]],
        'gamever': window[_j[1054]][_j[1180]],
        'serverid': window['y$X5'][_j[807]] ? window['y$X5'][_j[807]][_j[71]] : 0x0,
        'systemInfo': window[_j[1245]],
        'error': vomcu9,
        'stack': wr62p
    },
        rswifq = JSON[_j[1116]](wrfi2p);
    console[_j[622]](_j[1252] + rswifq), window['y$IX'](rswifq);
}, window['y$IX'] = function (btiq) {
    if (window['y$X5'][_j[1253]] == _j[1254]) return;
    var s1bq = y$X5['y$IX'] + _j[1255] + y$X5[_j[1244]];
    wx[_j[1256]]({
        'url': s1bq,
        'method': _j[21],
        'data': btiq,
        'header': {
            'content-type': _j[1257],
            'cache-control': _j[1258]
        },
        'success': function (a9umv) {
            DEBUG && console[_j[566]](_j[1259], s1bq, btiq, a9umv);
        },
        'fail': function (p26fr) {
            DEBUG && console[_j[566]](_j[1259], s1bq, btiq, p26fr);
        },
        'complete': function () {}
    });
}, window[_j[1260]] = function () {
    function rbisw() {
        return ((0x1 + Math[_j[857]]()) * 0x10000 | 0x0)[_j[454]](0x10)[_j[572]](0x1);
    }
    return rbisw() + rbisw() + '-' + rbisw() + '-' + rbisw() + '-' + rbisw() + '+' + rbisw() + rbisw() + rbisw();
}, window['y$XI'] = function () {
    console[_j[566]](_j[1261]);
    var wfqsir = _qauv9kc[_j[1262]]();
    y$X5[_j[1203]] = wfqsir[_j[1263]], y$X5[_j[1202]] = wfqsir[_j[1263]], y$X5[_j[1199]] = wfqsir[_j[1263]], y$X5[_j[944]] = wfqsir[_j[1055]];
    var j9uk = { 'game_ver': y$X5[_j[1187]] };
    y$X5[_j[1200]] = this[_j[1260]](), y$IXT5({ 'title': _j[1264] }), _qauv9kc[_j[89]](j9uk, this['y$5IX'][_j[425]](this));
}, window['y$5IX'] = function ($4ez5x) {
    var hx$5ez = $4ez5x[_j[1091]];
    sdkInitRes = $4ez5x, console[_j[566]](_j[1265] + hx$5ez + _j[1266] + (hx$5ez == 0x1) + _j[1267] + $4ez5x[_j[1180]] + _j[1268] + window[_j[1179]][_j[864]] + _j[1269] + $4ez5x[_j[1270]]);
    if (!$4ez5x[_j[1180]] || window['y$HT5IX'](window[_j[1179]][_j[864]], $4ez5x[_j[1180]]) < 0x0) console[_j[566]](_j[1271]), y$X5[_j[1191]] = _j[1272], y$X5[_j[1193]] = _j[1273], y$X5[_j[1195]] = _j[1274], y$X5[_j[973]] = _j[1275], y$X5[_j[1276]] = _j[1277], y$X5[_j[1270]] = $4ez5x[_j[1270]], y$X5[_j[949]] = ![];else window['y$HT5IX'](window[_j[1179]][_j[864]], $4ez5x[_j[1180]]) == 0x0 ? (console[_j[566]](_j[1278]), y$X5[_j[1191]] = _j[1192], y$X5[_j[1193]] = _j[1194], y$X5[_j[1195]] = _j[1196], y$X5[_j[973]] = _j[1185], y$X5[_j[1276]] = _j[1277], y$X5[_j[1270]] = _j[1279], y$X5[_j[949]] = !![]) : (console[_j[566]](_j[1280]), y$X5[_j[1191]] = _j[1192], y$X5[_j[1193]] = _j[1194], y$X5[_j[1195]] = _j[1196], y$X5[_j[973]] = _j[1185], y$X5[_j[1276]] = _j[1277], y$X5[_j[1270]] = _j[1279], y$X5[_j[949]] = ![]);
    y$X5[_j[1201]] = config[_j[449]] ? config[_j[449]] : 0x0, this['y$TXI5'](), this['y$TX5I'](), window[_j[1281]] = 0x5, y$IXT5({ 'title': _j[1282] }), _qauv9kc[_j[14]](this['y$5XI'][_j[425]](this));
}, window[_j[1281]] = 0x5, window['y$5XI'] = function (rqsfi, kaygh) {
    if (rqsfi == 0x0 && kaygh && kaygh[_j[597]]) {
        y$X5[_j[1283]] = kaygh[_j[597]], y$X5[_j[1284]] = kaygh[_j[1284]], y$X5[_j[1285]] = kaygh[_j[1285]], y$X5[_j[1286]] = kaygh[_j[1286]], y$X5[_j[948]] = kaygh[_j[948]];
        var q1t = this;
        y$IXT5({ 'title': _j[1287] }), sendApi(y$X5[_j[1191]], _j[1288], {
            'platform': y$X5[_j[1189]],
            'partner_id': y$X5[_j[1199]],
            'token': kaygh[_j[597]],
            'game_pkg': y$X5[_j[944]],
            'deviceId': y$X5[_j[1200]],
            'scene': _j[1289] + y$X5[_j[1201]]
        }, this['y$TIX5'][_j[425]](this), y$T5X, y$5I);
    } else kaygh && kaygh[_j[85]] && window[_j[1281]] > 0x0 && (kaygh[_j[85]][_j[515]](_j[1290]) != -0x1 || kaygh[_j[85]][_j[515]](_j[1291]) != -0x1 || kaygh[_j[85]][_j[515]](_j[1292]) != -0x1 || kaygh[_j[85]][_j[515]](_j[1293]) != -0x1 || kaygh[_j[85]][_j[515]](_j[1294]) != -0x1 || kaygh[_j[85]][_j[515]](_j[1295]) != -0x1) ? (window[_j[1281]]--, _qauv9kc[_j[14]](this['y$5XI'][_j[425]](this))) : (window[_j[1238]](0x1, _j[1296] + rqsfi + _j[1297] + (kaygh ? kaygh[_j[85]] : '')), window['y$X5I'](_j[1298], JSON[_j[1116]]({
        'status': rqsfi,
        'data': kaygh
    })), window['y$ITX5'](_j[1299] + (kaygh && kaygh[_j[85]] ? '，' + kaygh[_j[85]] : '')));
}, window['y$TIX5'] = function (ifrpw) {
    if (!ifrpw) {
        window[_j[1238]](0x2, _j[1300]), window['y$X5I'](_j[1301], _j[1302]), window['y$ITX5'](_j[1303]);
        return;
    }
    if (ifrpw[_j[984]] != _j[983]) {
        window[_j[1238]](0x2, _j[1304] + ifrpw[_j[984]]), window['y$X5I'](_j[1301], JSON[_j[1116]](ifrpw)), window['y$ITX5'](_j[1305] + ifrpw[_j[984]]);
        return;
    }
    if (ifrpw[_j[1306]] == 0x1) {
        window['y$ITX5'](_j[1307]);
        return;
    }
    y$X5[_j[1308]] = String(ifrpw[_j[1244]]), y$X5[_j[1244]] = String(ifrpw[_j[1244]]), y$X5[_j[1309]] = String(ifrpw[_j[1309]]), y$X5[_j[1203]] = String(ifrpw[_j[1309]]), y$X5[_j[1310]] = String(ifrpw[_j[1310]]), y$X5[_j[1311]] = String(ifrpw[_j[1312]]), y$X5[_j[1313]] = String(ifrpw[_j[1314]]), y$X5[_j[1312]] = '';
    var vugk9a = this;
    y$IXT5({ 'title': _j[1315] });
    var rf206 = localStorage[_j[982]](_j[1316] + y$X5[_j[944]] + y$X5[_j[1244]]);
    if (rf206 && rf206 != '') {
        var a9mcu = Number(rf206);
        vugk9a[_j[1317]](a9mcu);
    } else vugk9a[_j[1318]]();
}, window[_j[1318]] = function () {
    var p2iwf = this;
    sendApi(y$X5[_j[1191]], _j[1319], {
        'partner_id': y$X5[_j[1199]],
        'uid': y$X5[_j[1244]],
        'version': y$X5[_j[1187]],
        'game_pkg': y$X5[_j[944]],
        'device': y$X5[_j[1200]]
    }, p2iwf['y$TI5X'][_j[425]](p2iwf), y$T5X, y$5I);
}, window['y$TI5X'] = function (rwfqi2) {
    if (!rwfqi2) {
        window[_j[1238]](0x3, _j[1320]), window['y$ITX5'](_j[1320]);
        return;
    }
    if (rwfqi2[_j[984]] != _j[983]) {
        window[_j[1238]](0x3, _j[1321] + rwfqi2[_j[984]]), window['y$ITX5'](_j[1321] + rwfqi2[_j[984]]);
        return;
    }
    if (!rwfqi2[_j[611]] || rwfqi2[_j[611]][_j[435]] == 0x0) {
        window[_j[1238]](0x3, _j[1322]), window['y$ITX5'](_j[1323]);
        return;
    }
    this[_j[1324]](rwfqi2);
}, window[_j[1317]] = function ($z5x) {
    var f2w6r = this;
    sendApi(y$X5[_j[1191]], _j[1325], {
        'server_id': $z5x,
        'time': Date[_j[802]]() / 0x3e8
    }, f2w6r[_j[1326]][_j[425]](f2w6r), y$T5X, y$5I);
}, window[_j[1326]] = function (mo73c) {
    if (!mo73c) {
        window[_j[1238]](0x4, _j[1327]), this[_j[1318]]();
        return;
    }
    if (mo73c[_j[984]] != _j[983]) {
        window[_j[1238]](0x4, _j[1328] + mo73c[_j[984]]), this[_j[1318]]();
        return;
    }
    if (!mo73c[_j[611]] || mo73c[_j[611]][_j[435]] == 0x0) {
        window[_j[1238]](0x4, _j[1329]), this[_j[1318]]();
        return;
    }
    this[_j[1324]](mo73c);
}, window[_j[1324]] = function (pirf2) {
    y$X5[_j[1105]] = pirf2[_j[1330]] != undefined ? pirf2[_j[1330]] : 0x0, y$X5[_j[807]] = {
        'server_id': String(pirf2[_j[611]][0x0][_j[71]]),
        'server_name': String(pirf2[_j[611]][0x0][_j[972]]),
        'entry_ip': pirf2[_j[611]][0x0][_j[1331]],
        'entry_port': parseInt(pirf2[_j[611]][0x0][_j[1332]]),
        'status': y$XTI(pirf2[_j[611]][0x0]),
        'start_time': pirf2[_j[611]][0x0][_j[1333]],
        'maintain_time': pirf2[_j[611]][0x0][_j[891]] ? pirf2[_j[611]][0x0][_j[891]] : '',
        'cdn': y$X5[_j[973]]
    }, this[_j[1334]](), window[_j[1178]] && window[_j[1178]][_j[803]][_j[1335]] && window[_j[1178]][_j[803]][_j[1335]](sdkInitRes[_j[1336]], sdkInitRes[_j[1337]], sdkInitRes[_j[1338]], sdkInitRes[_j[1339]], sdkInitRes[_j[1340]]);
}, window[_j[1334]] = function () {
    window['y$XT'] = !![], window['y$5XTI']();
}, window['y$5XTI'] = function () {
    if (window['y$XT'] && window['y$TX']) {
        var wsrfiq = y$X5[_j[947]] != undefined ? y$X5[_j[947]] : 0x0,
            vc9_o = y$X5[_j[948]] == undefined ? 0x0 : y$X5[_j[948]],
            xhz5e = wsrfiq == 0x1 && vc9_o == 0x1 || wsrfiq == 0x2 && vc9_o != 0x1 || wsrfiq == 0x3;
        console[_j[1232]](_j[1341] + y$X5[_j[1105]] + _j[1342] + xhz5e + _j[1343] + y$X5[_j[948]] + _j[1344] + y$X5[_j[947]]);
        if (!xhz5e && y$X5[_j[1105]] == 0x1) {
            var c_mo73 = y$X5[_j[807]][_j[887]];
            if (c_mo73 === -0x1 || c_mo73 === 0x0) {
                window[_j[1238]](0xf, _j[1345] + y$X5[_j[807]]['id'] + _j[1346] + y$X5[_j[807]][_j[887]]), window['y$ITX5'](c_mo73 === -0x1 ? _j[1347] : _j[1348]);
                return;
            }
            y$5ITX(0x0, y$X5[_j[807]][_j[71]]), window[_j[1178]][_j[803]][_j[1100]](y$X5[_j[1105]]);
        } else window[_j[1178]][_j[803]][_j[1095]]({
            'show': sdkInitRes[_j[1336]],
            'skinUrl': sdkInitRes[_j[1337]],
            'content': sdkInitRes[_j[1338]],
            'x': sdkInitRes[_j[1339]],
            'y': sdkInitRes[_j[1340]]
        }), y$IX5T();
        window[_j[1349]](), window['y$5TXI'](), window['y$5XIT']();
    }
}, window['y$TXI5'] = function () {
    sendApi(y$X5[_j[1191]], _j[1350], {
        'game_pkg': y$X5[_j[944]],
        'version_name': y$X5[_j[1270]]
    }, this[_j[1351]][_j[425]](this), y$T5X, y$5I);
}, window[_j[1351]] = function (bs8tn1) {
    if (!bs8tn1) {
        window[_j[1238]](0x5, _j[1352]), window['y$ITX5'](_j[1352]);
        return;
    }
    if (bs8tn1[_j[984]] != _j[983]) {
        window[_j[1238]](0x5, _j[1353] + bs8tn1[_j[984]]), window['y$ITX5'](_j[1353] + bs8tn1[_j[984]]);
        return;
    }
    if (!bs8tn1[_j[611]] || !bs8tn1[_j[611]][_j[1187]]) {
        window[_j[1238]](0x5, _j[1354] + (bs8tn1[_j[611]] && bs8tn1[_j[611]][_j[1187]])), window['y$ITX5'](_j[1354] + (bs8tn1[_j[611]] && bs8tn1[_j[611]][_j[1187]]));
        return;
    }
    bs8tn1[_j[611]][_j[1355]] && bs8tn1[_j[611]][_j[1355]][_j[435]] > 0xa && (y$X5[_j[1356]] = bs8tn1[_j[611]][_j[1355]], y$X5[_j[973]] = bs8tn1[_j[611]][_j[1355]]), bs8tn1[_j[611]][_j[1187]] && (y$X5[_j[862]] = bs8tn1[_j[611]][_j[1187]]), console[_j[1232]](_j[1357] + y$X5[_j[862]] + _j[1358] + y$X5[_j[1270]]), window['y$X5T'] = !![], window['y$5TXI'](), window['y$5XIT']();
}, window[_j[1359]], window['y$TX5I'] = function () {
    sendApi(y$X5[_j[1191]], _j[1360], { 'game_pkg': y$X5[_j[944]] }, this['y$T5IX'][_j[425]](this), y$T5X, y$5I);
}, window['y$T5IX'] = function (y5jgeh) {
    if (y5jgeh && y5jgeh[_j[984]] === _j[983] && y5jgeh[_j[611]]) {
        window[_j[1359]] = y5jgeh[_j[611]];
        for (var rifws in y5jgeh[_j[611]]) {
            y$X5[rifws] = y5jgeh[_j[611]][rifws];
        }
    } else window[_j[1238]](0xb, _j[1361]), console[_j[1232]](_j[1362] + y5jgeh[_j[984]]);
    window['y$TX'] = !![], window['y$5XTI']();
}, window[_j[1349]] = function () {
    if (!window['y$XT'] || !window['y$TX']) return;
    var v9cmo_ = y$X5[_j[1105]] == 0x1,
        z5yehx = y$X5[_j[949]],
        nltd8 = y$X5[_j[1363]] && y$X5[_j[1363]] > 0x0;
    if (z5yehx || v9cmo_ && nltd8) {
        var $eh5x = y$X5[_j[1364]],
            tbqiw = $eh5x && $eh5x[_j[435]] == 0x9;
        tbqiw && (window[_j[1365]] = $eh5x);
        var ovc_9m = y$X5[_j[1366]],
            kg9uja = ovc_9m && ovc_9m[_j[555]]('#')[_j[435]] == 0x4;
        kg9uja && (window[_j[1060]] = ovc_9m);
    }
}, window[_j[1237]] = function () {
    window[_j[1365]] = null, window[_j[1060]] = null;
}, window[_j[1367]] = function (rpwf2, yajhkg, cm9ov_, jkh, m3_o0, qsitw, nb1tq, o_73, ntibqs, gv9) {
    m3_o0 = String(m3_o0);
    var sf = nb1tq,
        hgkj = o_73;
    y$X5[_j[1186]][m3_o0] = {
        'productid': m3_o0,
        'productname': sf,
        'productdesc': hgkj,
        'roleid': rpwf2,
        'rolename': yajhkg,
        'rolelevel': cm9ov_,
        'price': qsitw,
        'callback': ntibqs
    }, sendApi(y$X5[_j[1195]], _j[1368], {
        'game_pkg': y$X5[_j[944]],
        'server_id': y$X5[_j[807]][_j[71]],
        'server_name': y$X5[_j[807]][_j[972]],
        'level': cm9ov_,
        'uid': y$X5[_j[1244]],
        'role_id': rpwf2,
        'role_name': yajhkg,
        'product_id': m3_o0,
        'product_name': sf,
        'product_desc': hgkj,
        'money': qsitw,
        'partner_id': y$X5[_j[1199]]
    }, toPayCallBack, y$T5X, y$5I);
}, window[_j[1369]] = function (om_07) {
    if (om_07 && (om_07[_j[1370]] === 0xc8 || om_07[_j[984]] == _j[983])) {
        var f60p3 = y$X5[_j[1186]][String(om_07[_j[1371]])];
        if (f60p3[_j[1372]]) f60p3[_j[1372]](om_07[_j[1371]], om_07[_j[1373]], -0x1);
        _qauv9kc[_j[51]]({
            'cpbill': om_07[_j[1373]],
            'productid': om_07[_j[1371]],
            'productname': f60p3[_j[1374]],
            'productdesc': f60p3[_j[1375]],
            'serverid': y$X5[_j[807]][_j[71]],
            'servername': y$X5[_j[807]][_j[972]],
            'roleid': f60p3[_j[1376]],
            'rolename': f60p3[_j[1377]],
            'rolelevel': f60p3[_j[1378]],
            'price': f60p3[_j[1379]],
            'extension': JSON[_j[1116]]({ 'cp_order_id': om_07[_j[1373]] })
        }, function ($5exz4, gkau9v) {
            f60p3[_j[1372]] && $5exz4 == 0x0 && f60p3[_j[1372]](om_07[_j[1371]], om_07[_j[1373]], $5exz4);
            console[_j[1232]](JSON[_j[1116]]({
                'type': _j[1380],
                'status': $5exz4,
                'data': om_07,
                'role_name': f60p3[_j[1377]]
            }));
            if ($5exz4 === 0x0) {} else {
                if ($5exz4 === 0x1) {} else {
                    if ($5exz4 === 0x2) {}
                }
            }
        });
    } else {
        var kgyuj = om_07 ? _j[1381] + om_07[_j[1370]] + _j[1382] + om_07[_j[984]] + _j[1383] + om_07[_j[1232]] : _j[1384];
        window[_j[1238]](0xd, _j[1385] + kgyuj), alert(kgyuj);
    }
}, window['y$T5XI'] = function () {}, window['y$IT5'] = function (kug, yjkhg5, wfrsiq, v9m_co, q1tnb) {
    _qauv9kc[_j[91]](y$X5[_j[807]][_j[71]], y$X5[_j[807]][_j[972]] || y$X5[_j[807]][_j[71]], kug, yjkhg5, wfrsiq), sendApi(y$X5[_j[1191]], _j[1386], {
        'game_pkg': y$X5[_j[944]],
        'server_id': y$X5[_j[807]][_j[71]],
        'role_id': kug,
        'uid': y$X5[_j[1244]],
        'role_name': yjkhg5,
        'role_type': v9m_co,
        'level': wfrsiq
    });
}, window['y$I5T'] = function (r0p6f, n1stbq, uvcm9, hegjy, stwbq, uvgka, vga9k, v9k, ua9kgj, iswrf) {
    y$X5[_j[1241]] = r0p6f, y$X5[_j[1242]] = n1stbq, y$X5[_j[1243]] = uvcm9, _qauv9kc[_j[92]](y$X5[_j[807]][_j[71]], y$X5[_j[807]][_j[972]] || y$X5[_j[807]][_j[71]], r0p6f, n1stbq, uvcm9), sendApi(y$X5[_j[1191]], _j[1387], {
        'game_pkg': y$X5[_j[944]],
        'server_id': y$X5[_j[807]][_j[71]],
        'role_id': r0p6f,
        'uid': y$X5[_j[1244]],
        'role_name': n1stbq,
        'role_type': hegjy,
        'level': uvcm9,
        'evolution': stwbq
    });
}, window['y$TI5'] = function (bti, x5jh, co_7m, ghkyja, tl81d, p62f3, c3m7_, ahkgjy, xe$h, ovu9cm) {
    y$X5[_j[1241]] = bti, y$X5[_j[1242]] = x5jh, y$X5[_j[1243]] = co_7m, _qauv9kc[_j[93]](y$X5[_j[807]][_j[71]], y$X5[_j[807]][_j[972]] || y$X5[_j[807]][_j[71]], bti, x5jh, co_7m), sendApi(y$X5[_j[1191]], _j[1387], {
        'game_pkg': y$X5[_j[944]],
        'server_id': y$X5[_j[807]][_j[71]],
        'role_id': bti,
        'uid': y$X5[_j[1244]],
        'role_name': x5jh,
        'role_type': ghkyja,
        'level': co_7m,
        'evolution': tl81d
    });
}, window['y$T5I'] = function (fwrpi2) {}, window['y$IT'] = function (av9cuk) {
    _qauv9kc[_j[32]](_j[32], function (nblt) {
        av9cuk && av9cuk(nblt);
    });
}, window[_j[90]] = function () {
    _qauv9kc[_j[90]]();
}, window[_j[1388]] = function () {
    _qauv9kc[_j[101]] && _qauv9kc[_j[101]]();
}, window[_j[1389]] = function (qtin, sqt1b, h5$x, c7vm, rwfi2, wqitbs, tnd18, p0r26f) {
    p0r26f = p0r26f || y$X5[_j[807]][_j[71]], sendApi(y$X5[_j[1191]], _j[1390], {
        'phone': qtin,
        'role_id': sqt1b,
        'uid': y$X5[_j[1244]],
        'game_pkg': y$X5[_j[944]],
        'partner_id': y$X5[_j[1199]],
        'server_id': p0r26f
    }, tnd18, 0x2, null, function () {
        return !![];
    });
}, window[_j[1391]] = function (akyhjg) {
    window['y$5IT'] = akyhjg, window['y$5IT'] && window['y$TI'] && (console[_j[1232]](_j[1392] + window['y$TI'][_j[1393]]), window['y$5IT'](window['y$TI']), window['y$TI'] = null);
}, window['y$5TI'] = function (macuv, hygk5j, zye5xh, x5eh$) {
    window[_j[1394]](_j[1395], {
        'game_pkg': window['y$X5'][_j[944]],
        'role_id': hygk5j,
        'server_id': zye5xh
    }, x5eh$);
}, window['y$XIT5'] = function (e5zyhx, jhxy5e, ykaujg) {
    function mcouv9(m_9oc) {
        var yex = [],
            p_6703 = [],
            gej = ykaujg || window[_j[1054]][_j[1396]];
        for (var hexyz in gej) {
            var a9gv = Number(hexyz);
            (!e5zyhx || !e5zyhx[_j[435]] || e5zyhx[_j[515]](a9gv) != -0x1) && (p_6703[_j[457]](gej[hexyz]), yex[_j[457]]([a9gv, 0x3]));
        }
        window['y$HT5IX'](window[_j[1397]], _j[1398]) >= 0x0 ? (console[_j[566]](_j[1399]), _qauv9kc[_j[83]] && _qauv9kc[_j[83]](p_6703, function (c_ovm9) {
            console[_j[566]](_j[1400]), console[_j[566]](c_ovm9);
            if (c_ovm9 && c_ovm9[_j[85]] == _j[86]) for (var qswbit in gej) {
                if (c_ovm9[gej[qswbit]] == _j[88]) {
                    var ibsrw = Number(qswbit);
                    for (var gj = 0x0; gj < yex[_j[435]]; gj++) {
                        if (yex[gj][0x0] == ibsrw) {
                            yex[gj][0x1] = 0x1;
                            break;
                        }
                    }
                }
            }
            window['y$HT5IX'](window[_j[1397]], _j[1401]) >= 0x0 ? wx[_j[1402]]({
                'withSubscriptions': !![],
                'success': function (isrwqf) {
                    var hjey5g = isrwqf[_j[1403]][_j[1404]];
                    if (hjey5g) {
                        console[_j[566]](_j[1405]), console[_j[566]](hjey5g);
                        for (var a9kcv in gej) {
                            if (hjey5g[gej[a9kcv]] == _j[88]) {
                                var pw2fr = Number(a9kcv);
                                for (var e5$ = 0x0; e5$ < yex[_j[435]]; e5$++) {
                                    if (yex[e5$][0x0] == pw2fr) {
                                        yex[e5$][0x1] = 0x2;
                                        break;
                                    }
                                }
                            }
                        }
                        console[_j[566]](yex), jhxy5e && jhxy5e(yex);
                    } else console[_j[566]](_j[1406]), console[_j[566]](isrwqf), console[_j[566]](yex), jhxy5e && jhxy5e(yex);
                },
                'fail': function () {
                    console[_j[566]](_j[1407]), console[_j[566]](yex), jhxy5e && jhxy5e(yex);
                }
            }) : (console[_j[566]](_j[1408] + window[_j[1397]]), console[_j[566]](yex), jhxy5e && jhxy5e(yex));
        })) : (console[_j[566]](_j[1409] + window[_j[1397]]), console[_j[566]](yex), jhxy5e && jhxy5e(yex)), wx[_j[1410]](mcouv9);
    }
    wx[_j[1411]](mcouv9);
}, window['y$XI5T'] = {
    'isSuccess': ![],
    'level': _j[1412],
    'isCharging': ![]
}, window['y$XTI5'] = function (rfqwis) {
    wx[_j[1413]]({
        'success': function (_c9mv) {
            var bsqti = window['y$XI5T'];
            bsqti[_j[1414]] = !![], bsqti[_j[1415]] = Number(_c9mv[_j[1415]])[_j[1416]](0x0), bsqti[_j[1417]] = _c9mv[_j[1417]], rfqwis && rfqwis(bsqti[_j[1414]], bsqti[_j[1415]], bsqti[_j[1417]]);
        },
        'fail': function (z5x$eh) {
            console[_j[566]](_j[1418], z5x$eh[_j[85]]);
            var vo_m7 = window['y$XI5T'];
            rfqwis && rfqwis(vo_m7[_j[1414]], vo_m7[_j[1415]], vo_m7[_j[1417]]);
        }
    });
}, window[_j[1419]] = function (z$x4e) {
    wx[_j[1419]]({
        'success': function (_comv) {
            z$x4e && z$x4e(!![], _comv);
        },
        'fail': function (hjykg) {
            z$x4e && z$x4e(![], hjykg);
        }
    });
}, window[_j[1420]] = function (cu9vom) {
    if (cu9vom) wx[_j[1420]](cu9vom);
}, window[_j[1421]] = function (e45zx) {
    wx[_j[1421]](e45zx);
}, window[_j[1394]] = function (ygjhak, x$45e, j9g, hj5eyx, qfrwsi, m_07o, bsnt1, firw) {
    if (hj5eyx == undefined) hj5eyx = 0x1;
    wx[_j[1256]]({
        'url': ygjhak,
        'method': bsnt1 || _j[1422],
        'responseType': _j[859],
        'data': x$45e,
        'header': { 'content-type': firw || _j[1257] },
        'success': function (ejyx) {
            DEBUG && console[_j[566]](_j[1423], ygjhak, info, ejyx);
            if (ejyx && ejyx[_j[1424]] == 0xc8) {
                var exy5jh = ejyx[_j[611]];
                !m_07o || m_07o(exy5jh) ? j9g && j9g(exy5jh) : window[_j[1425]](ygjhak, x$45e, j9g, hj5eyx, qfrwsi, m_07o, ejyx);
            } else window[_j[1425]](ygjhak, x$45e, j9g, hj5eyx, qfrwsi, m_07o, ejyx);
        },
        'fail': function (x5hyj) {
            DEBUG && console[_j[566]](_j[1426], ygjhak, info, x5hyj), window[_j[1425]](ygjhak, x$45e, j9g, hj5eyx, qfrwsi, m_07o, x5hyj);
        },
        'complete': function () {}
    });
}, window[_j[1425]] = function (rbqis, t8sn1, yhzex5, jyhxe5, vucm9o, pfwr62, ejh) {
    jyhxe5 - 0x1 > 0x0 ? setTimeout(function () {
        window[_j[1394]](rbqis, t8sn1, yhzex5, jyhxe5 - 0x1, vucm9o, pfwr62);
    }, 0x3e8) : vucm9o && vucm9o(JSON[_j[1116]]({
        'url': rbqis,
        'response': ejh
    }));
}, window[_j[1427]] = function (h5yjk, bntsiq, rf2wi, ln81tb, e$zx, rfsqiw, guyja) {
    !rf2wi && (rf2wi = {});
    var eg5y = Math[_j[462]](Date[_j[802]]() / 0x3e8);
    rf2wi[_j[1314]] = eg5y, rf2wi[_j[1428]] = bntsiq;
    var hyzx = Object[_j[434]](rf2wi)[_j[621]](),
        isqbw = '',
        agvku = '';
    for (var ykjgu = 0x0; ykjgu < hyzx[_j[435]]; ykjgu++) {
        isqbw = isqbw + (ykjgu == 0x0 ? '' : '&') + hyzx[ykjgu] + rf2wi[hyzx[ykjgu]], agvku = agvku + (ykjgu == 0x0 ? '' : '&') + hyzx[ykjgu] + '=' + encodeURIComponent(rf2wi[hyzx[ykjgu]]);
    }
    isqbw = isqbw + y$X5[_j[1197]];
    var btsn = _j[1429] + md5(isqbw);
    send(h5yjk + '?' + agvku + (agvku == '' ? '' : '&') + btsn, null, ln81tb, e$zx, rfsqiw, guyja || function (ukagy) {
        return ukagy[_j[984]] == _j[983];
    }, null, _j[23]);
}, window['y$XT5I'] = function (btinq, riwp2f) {
    var b8 = 0x0;
    y$X5[_j[807]] && (b8 = y$X5[_j[807]][_j[71]]), sendApi(y$X5[_j[1193]], _j[1430], {
        'partnerId': y$X5[_j[1199]],
        'gamePkg': y$X5[_j[944]],
        'logTime': Math[_j[462]](Date[_j[802]]() / 0x3e8),
        'platformUid': y$X5[_j[1310]],
        'type': btinq,
        'serverId': b8
    }, null, 0x2, null, function () {
        return !![];
    });
}, window['y$X5IT'] = function (hex$5z) {
    sendApi(y$X5[_j[1191]], _j[1431], {
        'partner_id': y$X5[_j[1199]],
        'uid': y$X5[_j[1244]],
        'version': y$X5[_j[1187]],
        'game_pkg': y$X5[_j[944]],
        'device': y$X5[_j[1200]]
    }, y$X5TI, y$T5X, y$5I);
}, window['y$X5TI'] = function (fiw2rq) {
    if (fiw2rq && fiw2rq[_j[984]] === _j[983] && fiw2rq[_j[611]]) {
        fiw2rq[_j[611]][_j[538]]({
            'id': -0x2,
            'name': _j[1432]
        }), fiw2rq[_j[611]][_j[538]]({
            'id': -0x1,
            'name': _j[1433]
        }), y$X5[_j[943]] = fiw2rq[_j[611]];
        if (window[_j[933]]) window[_j[933]][_j[974]]();
    } else {
        y$X5[_j[953]] = ![];
        var e5$xhz = fiw2rq ? fiw2rq[_j[984]] : '';
        window[_j[1238]](0x7, _j[1434] + e5$xhz), window['y$ITX5'](_j[1435] + e5$xhz);
    }
}, window['y$ITX'] = function (kj5yh) {
    sendApi(y$X5[_j[1191]], _j[1436], {
        'partner_id': y$X5[_j[1199]],
        'uid': y$X5[_j[1244]],
        'version': y$X5[_j[1187]],
        'game_pkg': y$X5[_j[944]],
        'device': y$X5[_j[1200]]
    }, y$IXT, y$T5X, y$5I);
}, window['y$IXT'] = function (hj5yex) {
    y$X5[_j[980]] = ![];
    if (hj5yex && hj5yex[_j[984]] === _j[983] && hj5yex[_j[611]]) {
        for (var vukc9 = 0x0; vukc9 < hj5yex[_j[611]][_j[435]]; vukc9++) {
            hj5yex[_j[611]][vukc9][_j[887]] = y$XTI(hj5yex[_j[611]][vukc9]);
        }
        y$X5[_j[978]][-0x1] = window[_j[1437]](hj5yex[_j[611]]), window[_j[933]][_j[979]](-0x1);
    } else {
        var i2wf = hj5yex ? hj5yex[_j[984]] : '';
        window[_j[1238]](0x8, _j[1438] + i2wf), window['y$ITX5'](_j[1439] + i2wf);
    }
}, window[_j[1440]] = function (qrwif2) {
    sendApi(y$X5[_j[1191]], _j[1436], {
        'partner_id': y$X5[_j[1199]],
        'uid': y$X5[_j[1244]],
        'version': y$X5[_j[1187]],
        'game_pkg': y$X5[_j[944]],
        'device': y$X5[_j[1200]]
    }, qrwif2, y$T5X, y$5I);
}, window['y$TIX'] = function (srifqw, wqsrb) {
    sendApi(y$X5[_j[1191]], _j[1441], {
        'partner_id': y$X5[_j[1199]],
        'uid': y$X5[_j[1244]],
        'version': y$X5[_j[1187]],
        'game_pkg': y$X5[_j[944]],
        'device': y$X5[_j[1200]],
        'server_group_id': wqsrb
    }, y$TXI, y$T5X, y$5I);
}, window['y$TXI'] = function (z5he$x) {
    y$X5[_j[980]] = ![];
    if (z5he$x && z5he$x[_j[984]] === _j[983] && z5he$x[_j[611]] && z5he$x[_j[611]][_j[611]]) {
        var z5x$ = z5he$x[_j[611]][_j[1442]],
            ghjyka = [];
        for (var ezyh = 0x0; ezyh < z5he$x[_j[611]][_j[611]][_j[435]]; ezyh++) {
            z5he$x[_j[611]][_j[611]][ezyh][_j[887]] = y$XTI(z5he$x[_j[611]][_j[611]][ezyh]), (ghjyka[_j[435]] == 0x0 || z5he$x[_j[611]][_j[611]][ezyh][_j[887]] != 0x0) && (ghjyka[ghjyka[_j[435]]] = z5he$x[_j[611]][_j[611]][ezyh]);
        }
        y$X5[_j[978]][z5x$] = window[_j[1437]](ghjyka), window[_j[933]][_j[979]](z5x$);
    } else {
        var _p063 = z5he$x ? z5he$x[_j[984]] : '';
        window[_j[1238]](0x9, _j[1443] + _p063), window['y$ITX5'](_j[1444] + _p063);
    }
}, window['y$HT5X'] = function (nt18l) {
    sendApi(y$X5[_j[1191]], _j[1445], {
        'partner_id': y$X5[_j[1199]],
        'uid': y$X5[_j[1244]],
        'version': y$X5[_j[1187]],
        'game_pkg': y$X5[_j[944]],
        'device': y$X5[_j[1200]]
    }, reqServerRecommendCallBack, y$T5X, y$5I);
}, window[_j[1446]] = function (m_c7vo) {
    y$X5[_j[980]] = ![];
    if (m_c7vo && m_c7vo[_j[984]] === _j[983] && m_c7vo[_j[611]]) {
        for (var u9mvo = 0x0; u9mvo < m_c7vo[_j[611]][_j[435]]; u9mvo++) {
            m_c7vo[_j[611]][u9mvo][_j[887]] = y$XTI(m_c7vo[_j[611]][u9mvo]);
        }
        y$X5[_j[978]][-0x2] = window[_j[1437]](m_c7vo[_j[611]]), window[_j[933]][_j[979]](-0x2);
    } else {
        var $h5zxe = m_c7vo ? m_c7vo[_j[984]] : '';
        window[_j[1238]](0xa, _j[1447] + $h5zxe), alert(_j[1448] + $h5zxe);
    }
}, window[_j[1437]] = function (prw2fi) {
    return prw2fi;
}, window['y$XIT'] = function (itsbn, tbln18) {
    itsbn = itsbn || y$X5[_j[807]][_j[71]], sendApi(y$X5[_j[1191]], _j[1449], {
        'type': '4',
        'game_pkg': y$X5[_j[944]],
        'server_id': itsbn
    }, tbln18);
}, window[_j[1450]] = function (tqs1n, prw2i, sn1qb, sqtni) {
    sn1qb = sn1qb || y$X5[_j[807]][_j[71]], sendApi(y$X5[_j[1191]], _j[1451], {
        'type': tqs1n,
        'game_pkg': prw2i,
        'server_id': sn1qb
    }, sqtni);
}, window[_j[1452]] = function (ejhxy5, nsqbt) {
    sendApi(y$X5[_j[1191]], _j[1453], { 'game_pkg': ejhxy5 }, nsqbt);
}, window['y$XTI'] = function (p2iwr) {
    if (p2iwr) {
        if (p2iwr[_j[887]] == 0x1) {
            if (p2iwr[_j[1454]] == 0x1) return 0x2;else return 0x1;
        } else return p2iwr[_j[887]] == 0x0 ? 0x0 : -0x1;
    }
    return -0x1;
}, window['y$5ITX'] = function (gkujy, iw2) {
    y$X5[_j[1455]] = {
        'step': gkujy,
        'server_id': iw2
    };
    var tinqbs = this;
    y$IXT5({ 'title': _j[1456] }), sendApi(y$X5[_j[1191]], _j[1457], {
        'partner_id': y$X5[_j[1199]],
        'uid': y$X5[_j[1244]],
        'game_pkg': y$X5[_j[944]],
        'server_id': iw2,
        'platform': y$X5[_j[1309]],
        'platform_uid': y$X5[_j[1310]],
        'check_login_time': y$X5[_j[1313]],
        'check_login_sign': y$X5[_j[1311]],
        'version_name': y$X5[_j[1270]]
    }, y$5IXT, y$T5X, y$5I, function (r0p62f) {
        return r0p62f[_j[984]] == _j[983] || r0p62f[_j[1232]] == _j[1458] || r0p62f[_j[1232]] == _j[1459];
    });
}, window['y$5IXT'] = function (f36p0) {
    var $x5eh = this;
    if (f36p0 && f36p0[_j[984]] === _j[983] && f36p0[_j[611]]) {
        var qr2if = y$X5[_j[807]];
        qr2if[_j[1460]] = y$X5[_j[1202]], qr2if[_j[1312]] = String(f36p0[_j[611]][_j[1461]]), qr2if[_j[1208]] = parseInt(f36p0[_j[611]][_j[1314]]);
        if (f36p0[_j[611]][_j[1462]]) qr2if[_j[1462]] = parseInt(f36p0[_j[611]][_j[1462]]);else qr2if[_j[1462]] = parseInt(f36p0[_j[611]][_j[71]]);
        qr2if[_j[1463]] = 0x0, qr2if[_j[973]] = y$X5[_j[1356]], qr2if[_j[1464]] = f36p0[_j[611]][_j[1465]], qr2if[_j[1466]] = f36p0[_j[611]][_j[1466]];
        if (f36p0[_j[611]][_j[1467]]) qr2if[_j[1467]] = parseInt(f36p0[_j[611]][_j[1467]]);
        console[_j[566]](_j[1468] + JSON[_j[1116]](qr2if[_j[1466]])), y$X5[_j[1105]] == 0x1 && qr2if[_j[1466]] && qr2if[_j[1466]][_j[1469]] == 0x1 && (y$X5[_j[865]] = 0x1, window[_j[1178]][_j[803]]['y$H5X']()), y$5TIX();
    } else {
        if (y$X5[_j[1455]][_j[1470]] >= 0x3) {
            var yhjkga = f36p0 ? f36p0[_j[984]] : '';
            window[_j[1238]](0xc, _j[1471] + yhjkga), y$5I(JSON[_j[1116]](f36p0)), window['y$ITX5'](_j[1472] + yhjkga);
        } else sendApi(y$X5[_j[1191]], _j[1288], {
            'platform': y$X5[_j[1189]],
            'partner_id': y$X5[_j[1199]],
            'token': y$X5[_j[1283]],
            'game_pkg': y$X5[_j[944]],
            'deviceId': y$X5[_j[1200]],
            'scene': _j[1289] + y$X5[_j[1201]]
        }, function (ejy5gh) {
            if (!ejy5gh || ejy5gh[_j[984]] != _j[983]) {
                window['y$ITX5'](_j[1305] + ejy5gh && ejy5gh[_j[984]]);
                return;
            }
            y$X5[_j[1311]] = String(ejy5gh[_j[1312]]), y$X5[_j[1313]] = String(ejy5gh[_j[1314]]), setTimeout(function () {
                y$5ITX(y$X5[_j[1455]][_j[1470]] + 0x1, y$X5[_j[1455]][_j[71]]);
            }, 0x5dc);
        }, y$T5X, y$5I, function (kg9jua) {
            return kg9jua[_j[984]] == _j[983] || kg9jua[_j[984]] == _j[1473];
        });
    }
}, window['y$5TIX'] = function () {
    ServerLoading[_j[803]][_j[1100]](y$X5[_j[1105]]), window['y$T5'] = !![], window['y$5XIT']();
}, window['y$5TXI'] = function () {
    if (window['y$5T'] && window['y$XT5'] && window[_j[1088]] && window[_j[1099]] && window['y$X5T'] && window['y$XT']) {
        if (!window[_j[1474]][_j[803]]) {
            console[_j[566]](_j[1475] + window[_j[1474]][_j[803]]);
            var eh5yjx = wx[_j[1476]](),
                siwqbr = eh5yjx[_j[1393]] ? eh5yjx[_j[1393]] : 0x0,
                geyhj = {
                'cdn': window['y$X5'][_j[973]],
                'spareCdn': window['y$X5'][_j[1276]],
                'newRegister': window['y$X5'][_j[1105]],
                'wxPC': window['y$X5'][_j[1215]],
                'wxIOS': window['y$X5'][_j[1213]],
                'wxAndroid': window['y$X5'][_j[1214]],
                'wxParam': {
                    'limitLoad': window['y$X5']['y$HIT5X'],
                    'benchmarkLevel': window['y$X5']['y$HIXT5'],
                    'wxFrom': window[_j[1054]][_j[449]] == _j[1477] ? 0x1 : 0x0,
                    'wxSDKVersion': window[_j[1397]],
                    'qudao': _j[1478]
                },
                'configType': window['y$X5'][_j[1209]],
                'exposeType': window['y$X5'][_j[1211]],
                'scene': siwqbr,
                'video_type': window['y$X5'][_j[1285]],
                'ad_flag': window['y$X5'][_j[948]]
            };
            if (window[_j[1359]]) for (var j9a in window[_j[1359]]) {
                if (!geyhj[j9a]) geyhj[j9a] = window[_j[1359]][j9a];
            }
            new window[_j[1474]](geyhj, window['y$X5'][_j[862]], window['y$HITX5']);
        }
    }
}, window['y$5XIT'] = function () {
    if (window['y$5T'] && window['y$XT5'] && window[_j[1088]] && window[_j[1099]] && window['y$X5T'] && window['y$XT'] && window['y$T5'] && window['y$TX']) {
        y$IX5T();
        if (!y$5TX) {
            y$5TX = !![];
            if (!window[_j[1474]][_j[803]]) window['y$5TXI']();
            var n1l = 0x0,
                p2rif = wx[_j[1479]]();
            p2rif && (window['y$X5'][_j[1480]] && (n1l = p2rif[_j[755]]), console[_j[1232]](_j[1481] + p2rif[_j[755]] + _j[1482] + p2rif[_j[876]] + _j[1483] + p2rif[_j[999]] + _j[1484] + p2rif[_j[718]] + _j[1485] + p2rif[_j[829]] + _j[1486] + p2rif[_j[831]]));
            var bt18s = {};
            for (const qifwr in y$X5[_j[807]]) {
                bt18s[qifwr] = y$X5[_j[807]][qifwr];
            }
            var sbqt1 = {
                'channel': window['y$X5'][_j[1203]],
                'account': window['y$X5'][_j[1244]],
                'userId': window['y$X5'][_j[1308]],
                'cdn': window['y$X5'][_j[973]],
                'data': window['y$X5'][_j[611]],
                'package': window['y$X5'][_j[602]],
                'newRegister': window['y$X5'][_j[1105]],
                'pkgName': window['y$X5'][_j[944]],
                'partnerId': window['y$X5'][_j[1199]],
                'platform_uid': window['y$X5'][_j[1310]],
                'deviceId': window['y$X5'][_j[1200]],
                'selectedServer': bt18s,
                'configType': window['y$X5'][_j[1209]],
                'exposeType': window['y$X5'][_j[1211]],
                'debugUsers': window['y$X5'][_j[1206]],
                'wxMenuTop': n1l,
                'wxShield': window['y$X5'][_j[949]],
                'encryptParam': window['y$X5'][_j[1212]],
                'wx_channel': window['y$X5'][_j[1284]],
                'zsy_tp_state': window['y$X5'][_j[1286]]
            };
            if (window[_j[1359]]) for (var y5xjh in window[_j[1359]]) {
                sbqt1[y5xjh] = window[_j[1359]][y5xjh];
            }
            window[_j[1474]][_j[803]]['y$5XH'](sbqt1);
            if (y$X5[_j[807]] && y$X5[_j[807]][_j[71]]) localStorage[_j[954]](_j[1316] + y$X5[_j[944]] + y$X5[_j[1244]], y$X5[_j[807]][_j[71]]);
        }
    } else console[_j[1232]](_j[1487] + window['y$5T'] + _j[1488] + window['y$XT5'] + _j[1489] + window[_j[1088]] + _j[1490] + window[_j[1099]] + _j[1491] + window['y$X5T'] + _j[1492] + window['y$XT'] + _j[1493] + window['y$T5'] + _j[1494] + window['y$TX']);
}, window[_j[1495]] = function (ghky) {
    if (!window[_j[1496]]) {
        console[_j[609]](_j[1497]);
        return;
    }
    var ky = ghky[_j[1098]];
    ky == 0x1 ? window[_j[1496]][_j[1498]](0x2327, ghky) : window[_j[1496]][_j[866]](0x2327);
};