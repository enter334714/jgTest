var _j = wx.n$;
import _qnbtl from '../l3ob/x8a.js';
window[_j[1180]] = { 'wxVersion': window[_j[1055]][_j[1181]] }, window[_j[1182]] = ![], window['y$5X'] = 0x1, window[_j[1183]] = 0x1, window['y$TX5'] = !![], window[_j[1184]] = !![], window['y$HITX5'] = '', window[_j[1185]] = !![], window['y$X5'] = {
    'base_cdn': _j[1186],
    'cdn': _j[1186]
}, y$X5[_j[1187]] = {}, y$X5[_j[603]] = '0', y$X5[_j[1188]] = window[_j[1180]][_j[865]], y$X5[_j[1189]] = '', y$X5['os'] = '1', y$X5[_j[1190]] = _j[1191], y$X5[_j[1192]] = _j[1193], y$X5[_j[1194]] = _j[1195], y$X5[_j[1196]] = _j[1197], y$X5[_j[1198]] = _j[1199], y$X5[_j[1200]] = '1', y$X5[_j[945]] = '', y$X5[_j[1201]] = '', y$X5[_j[1202]] = 0x0, y$X5[_j[979]] = {}, y$X5[_j[1203]] = parseInt(y$X5[_j[1200]]), y$X5[_j[1204]] = y$X5[_j[1200]], y$X5[_j[808]] = {}, y$X5['y$IX'] = _j[1205], y$X5[_j[1206]] = ![], y$X5[_j[1207]] = _j[1208], y$X5[_j[1209]] = Date[_j[803]](), y$X5[_j[1210]] = _j[1211], y$X5[_j[1212]] = '_a', y$X5[_j[1213]] = '', y$X5[_j[851]] = 0x2, y$X5[_j[863]] = 0x7c1, y$X5[_j[865]] = window[_j[1180]][_j[865]], y$X5[_j[950]] = ![], y$X5[_j[1214]] = ![], y$X5[_j[1215]] = ![], y$X5[_j[1216]] = ![], window['y$T5X'] = 0x5, window['y$T5'] = ![], window['y$5T'] = ![], window['y$XT5'] = ![], window[_j[1089]] = ![], window[_j[1100]] = ![], window['y$X5T'] = ![], window['y$TX'] = ![], window['y$XT'] = ![], window['y$5TX'] = ![], window[_j[1091]] = null, window[_j[1217]] = function (co9_v) {
    console[_j[567]](_j[1217], co9_v), wx[_j[1218]]({}), wx[_j[1219]]({
        'title': _j[1220],
        'content': co9_v,
        'success'(fwriqs) {
            if (fwriqs[_j[1221]]) console[_j[567]](_j[1222]);else fwriqs[_j[1223]] && console[_j[567]](_j[1224]);
        }
    });
}, window['y$ITX5'] = function (zhxy) {
    console[_j[567]](_j[1225], zhxy), y$IX5T(), wx[_j[1219]]({
        'title': _j[1220],
        'content': zhxy,
        'confirmText': _j[1226],
        'cancelText': _j[1227],
        'success'(khgya) {
            if (khgya[_j[1221]]) window['y$XI']();else khgya[_j[1223]] && (console[_j[567]](_j[1228]), wx[_j[1229]]({}));
        }
    });
}, window[_j[1230]] = function (tbln18) {
    console[_j[567]](_j[1230], tbln18), wx[_j[1219]]({
        'title': _j[1220],
        'content': tbln18,
        'confirmText': _j[1231],
        'showCancel': ![],
        'complete'(t81nld) {
            console[_j[567]](_j[1228]), wx[_j[1229]]({});
        }
    });
}, window['y$IT5X'] = ![], window['y$IXT5'] = function (qr) {
    window['y$IT5X'] = !![], wx[_j[1232]](qr);
}, window['y$IX5T'] = function () {
    window['y$IT5X'] && (window['y$IT5X'] = ![], wx[_j[1218]]({}));
}, window['y$I5TX'] = function (m_37o) {
    window[_j[1179]][_j[804]]['y$I5TX'](m_37o);
}, window[_j[94]] = function (nbtis, egh5jy) {
    _qnbtl[_j[94]](nbtis, function (bsqnti) {
        bsqnti && bsqnti[_j[612]] ? bsqnti[_j[612]][_j[985]] == 0x1 ? egh5jy(!![]) : (egh5jy(![]), console[_j[1233]](_j[1234] + bsqnti[_j[612]][_j[1235]])) : console[_j[567]](_j[94], bsqnti);
    });
}, window['y$I5XT'] = function (k5jhg) {
    console[_j[567]](_j[1236], k5jhg);
}, window['y$IX5'] = function (t8lnd1) {}, window['y$I5X'] = function (cov_7m, e5xyhz, cuk9a) {}, window['y$I5'] = function (wfpr) {
    console[_j[567]](_j[1237], wfpr), window[_j[1179]][_j[804]][_j[855]](), window[_j[1179]][_j[804]][_j[856]](), window[_j[1179]][_j[804]][_j[869]](), window[_j[1238]]();
}, window['y$5I'] = function (lt18) {
    window[_j[1239]](0xe, _j[1240] + lt18), window['y$ITX5'](_j[1241]);
    var riwbq = {
        'id': window['y$X5'][_j[1242]],
        'role': window['y$X5'][_j[1243]],
        'level': window['y$X5'][_j[1244]],
        'account': window['y$X5'][_j[1245]],
        'version': window['y$X5'][_j[863]],
        'cdn': window['y$X5'][_j[974]],
        'pkgName': window['y$X5'][_j[945]],
        'gamever': window[_j[1055]][_j[1181]],
        'serverid': window['y$X5'][_j[808]] ? window['y$X5'][_j[808]][_j[71]] : 0x0,
        'systemInfo': window[_j[1246]],
        'error': _j[1247],
        'stack': lt18 ? lt18 : _j[1241]
    },
        iqsbw = JSON[_j[1117]](riwbq);
    console[_j[610]](_j[1248] + iqsbw), window['y$IX'](iqsbw);
}, window[_j[1239]] = function (hejgy, rfp0) {
    sendApi(y$X5[_j[1194]], _j[1249], {
        'game_pkg': y$X5[_j[945]],
        'partner_id': y$X5[_j[1200]],
        'server_id': y$X5[_j[808]] && y$X5[_j[808]][_j[71]] > 0x0 ? y$X5[_j[808]][_j[71]] : 0x0,
        'uid': y$X5[_j[1245]] > 0x0 ? y$X5[_j[1245]] : 0x0,
        'type': hejgy,
        'info': rfp0
    });
}, window['y$XI5'] = function (vguak) {
    var uvocm9 = JSON[_j[566]](vguak);
    uvocm9[_j[1250]] = window[_j[1055]][_j[1181]], uvocm9[_j[1251]] = window['y$X5'][_j[808]] ? window['y$X5'][_j[808]][_j[71]] : 0x0, uvocm9[_j[1246]] = window[_j[1246]];
    var v_co9m = JSON[_j[1117]](uvocm9);
    console[_j[610]](_j[1252] + v_co9m), window['y$IX'](v_co9m);
}, window['y$X5I'] = function (stqin, nt8b) {
    var rf0p6 = {
        'id': window['y$X5'][_j[1242]],
        'role': window['y$X5'][_j[1243]],
        'level': window['y$X5'][_j[1244]],
        'account': window['y$X5'][_j[1245]],
        'version': window['y$X5'][_j[863]],
        'cdn': window['y$X5'][_j[974]],
        'pkgName': window['y$X5'][_j[945]],
        'gamever': window[_j[1055]][_j[1181]],
        'serverid': window['y$X5'][_j[808]] ? window['y$X5'][_j[808]][_j[71]] : 0x0,
        'systemInfo': window[_j[1246]],
        'error': stqin,
        'stack': nt8b
    },
        vu9gka = JSON[_j[1117]](rf0p6);
    console[_j[623]](_j[1253] + vu9gka), window['y$IX'](vu9gka);
}, window['y$IX'] = function (mvo7c) {
    if (window['y$X5'][_j[1254]] == _j[1255]) return;
    var pri2 = y$X5['y$IX'] + _j[1256] + y$X5[_j[1245]];
    wx[_j[1257]]({
        'url': pri2,
        'method': _j[21],
        'data': mvo7c,
        'header': {
            'content-type': _j[1258],
            'cache-control': _j[1259]
        },
        'success': function (mcau9) {
            DEBUG && console[_j[567]](_j[1260], pri2, mvo7c, mcau9);
        },
        'fail': function (nsbt8) {
            DEBUG && console[_j[567]](_j[1260], pri2, mvo7c, nsbt8);
        },
        'complete': function () {}
    });
}, window[_j[1261]] = function () {
    function hgejy5() {
        return ((0x1 + Math[_j[858]]()) * 0x10000 | 0x0)[_j[455]](0x10)[_j[573]](0x1);
    }
    return hgejy5() + hgejy5() + '-' + hgejy5() + '-' + hgejy5() + '-' + hgejy5() + '+' + hgejy5() + hgejy5() + hgejy5();
}, window['y$XI'] = function () {
    console[_j[567]](_j[1262]);
    var wifpr = _qnbtl[_j[1263]]();
    y$X5[_j[1204]] = wifpr[_j[1264]], y$X5[_j[1203]] = wifpr[_j[1264]], y$X5[_j[1200]] = wifpr[_j[1264]], y$X5[_j[945]] = wifpr[_j[1056]];
    var l8t1b = { 'game_ver': y$X5[_j[1188]] };
    y$X5[_j[1201]] = this[_j[1261]](), y$IXT5({ 'title': _j[1265] }), _qnbtl[_j[89]](l8t1b, this['y$5IX'][_j[426]](this));
}, window['y$5IX'] = function (riqws) {
    var _6o73 = riqws[_j[1092]];
    sdkInitRes = riqws, console[_j[567]](_j[1266] + _6o73 + _j[1267] + (_6o73 == 0x1) + _j[1268] + riqws[_j[1181]] + _j[1269] + window[_j[1180]][_j[865]] + _j[1270] + riqws[_j[1271]]);
    if (!riqws[_j[1181]] || window['y$HT5IX'](window[_j[1180]][_j[865]], riqws[_j[1181]]) < 0x0) console[_j[567]](_j[1272]), y$X5[_j[1192]] = _j[1273], y$X5[_j[1194]] = _j[1274], y$X5[_j[1196]] = _j[1275], y$X5[_j[974]] = _j[1276], y$X5[_j[1277]] = _j[1278], y$X5[_j[1271]] = riqws[_j[1271]], y$X5[_j[950]] = ![];else window['y$HT5IX'](window[_j[1180]][_j[865]], riqws[_j[1181]]) == 0x0 ? (console[_j[567]](_j[1279]), y$X5[_j[1192]] = _j[1193], y$X5[_j[1194]] = _j[1195], y$X5[_j[1196]] = _j[1197], y$X5[_j[974]] = _j[1186], y$X5[_j[1277]] = _j[1278], y$X5[_j[1271]] = _j[1280], y$X5[_j[950]] = !![]) : (console[_j[567]](_j[1281]), y$X5[_j[1192]] = _j[1193], y$X5[_j[1194]] = _j[1195], y$X5[_j[1196]] = _j[1197], y$X5[_j[974]] = _j[1186], y$X5[_j[1277]] = _j[1278], y$X5[_j[1271]] = _j[1280], y$X5[_j[950]] = ![]);
    y$X5[_j[1202]] = config[_j[450]] ? config[_j[450]] : 0x0, this['y$TXI5'](), this['y$TX5I'](), window[_j[1282]] = 0x5, y$IXT5({ 'title': _j[1283] }), _qnbtl[_j[14]](this['y$5XI'][_j[426]](this));
}, window[_j[1282]] = 0x5, window['y$5XI'] = function (yxzhe, qfwrs) {
    if (yxzhe == 0x0 && qfwrs && qfwrs[_j[598]]) {
        y$X5[_j[1284]] = qfwrs[_j[598]], y$X5[_j[1285]] = qfwrs[_j[1285]], y$X5[_j[1286]] = qfwrs[_j[1286]], y$X5[_j[1287]] = qfwrs[_j[1287]], y$X5[_j[949]] = qfwrs[_j[949]];
        var ucavm9 = this;
        y$IXT5({ 'title': _j[1288] }), sendApi(y$X5[_j[1192]], _j[1289], {
            'platform': y$X5[_j[1190]],
            'partner_id': y$X5[_j[1200]],
            'token': qfwrs[_j[598]],
            'game_pkg': y$X5[_j[945]],
            'deviceId': y$X5[_j[1201]],
            'scene': _j[1290] + y$X5[_j[1202]]
        }, this['y$TIX5'][_j[426]](this), y$T5X, y$5I);
    } else qfwrs && qfwrs[_j[85]] && window[_j[1282]] > 0x0 && (qfwrs[_j[85]][_j[516]](_j[1291]) != -0x1 || qfwrs[_j[85]][_j[516]](_j[1292]) != -0x1 || qfwrs[_j[85]][_j[516]](_j[1293]) != -0x1 || qfwrs[_j[85]][_j[516]](_j[1294]) != -0x1 || qfwrs[_j[85]][_j[516]](_j[1295]) != -0x1 || qfwrs[_j[85]][_j[516]](_j[1296]) != -0x1) ? (window[_j[1282]]--, _qnbtl[_j[14]](this['y$5XI'][_j[426]](this))) : (window[_j[1239]](0x1, _j[1297] + yxzhe + _j[1298] + (qfwrs ? qfwrs[_j[85]] : '')), window['y$X5I'](_j[1299], JSON[_j[1117]]({
        'status': yxzhe,
        'data': qfwrs
    })), window['y$ITX5'](_j[1300] + (qfwrs && qfwrs[_j[85]] ? '，' + qfwrs[_j[85]] : '')));
}, window['y$TIX5'] = function (eyxjh5) {
    if (!eyxjh5) {
        window[_j[1239]](0x2, _j[1301]), window['y$X5I'](_j[1302], _j[1303]), window['y$ITX5'](_j[1304]);
        return;
    }
    if (eyxjh5[_j[985]] != _j[984]) {
        window[_j[1239]](0x2, _j[1305] + eyxjh5[_j[985]]), window['y$X5I'](_j[1302], JSON[_j[1117]](eyxjh5)), window['y$ITX5'](_j[1306] + eyxjh5[_j[985]]);
        return;
    }
    if (eyxjh5[_j[1307]] == 0x1) {
        window['y$ITX5'](_j[1308]);
        return;
    }
    y$X5[_j[1309]] = String(eyxjh5[_j[1245]]), y$X5[_j[1245]] = String(eyxjh5[_j[1245]]), y$X5[_j[1310]] = String(eyxjh5[_j[1310]]), y$X5[_j[1204]] = String(eyxjh5[_j[1310]]), y$X5[_j[1311]] = String(eyxjh5[_j[1311]]), y$X5[_j[1312]] = String(eyxjh5[_j[1313]]), y$X5[_j[1314]] = String(eyxjh5[_j[1315]]), y$X5[_j[1313]] = '';
    var l8tnd1 = this;
    y$IXT5({ 'title': _j[1316] });
    var z$x4e5 = localStorage[_j[983]](_j[1317] + y$X5[_j[945]] + y$X5[_j[1245]]);
    if (z$x4e5 && z$x4e5 != '') {
        var qibstw = Number(z$x4e5);
        l8tnd1[_j[1318]](qibstw);
    } else l8tnd1[_j[1319]]();
}, window[_j[1319]] = function () {
    var bts = this;
    sendApi(y$X5[_j[1192]], _j[1320], {
        'partner_id': y$X5[_j[1200]],
        'uid': y$X5[_j[1245]],
        'version': y$X5[_j[1188]],
        'game_pkg': y$X5[_j[945]],
        'device': y$X5[_j[1201]]
    }, bts['y$TI5X'][_j[426]](bts), y$T5X, y$5I);
}, window['y$TI5X'] = function (au9vkc) {
    if (!au9vkc) {
        window[_j[1239]](0x3, _j[1321]), window['y$ITX5'](_j[1321]);
        return;
    }
    if (au9vkc[_j[985]] != _j[984]) {
        window[_j[1239]](0x3, _j[1322] + au9vkc[_j[985]]), window['y$ITX5'](_j[1322] + au9vkc[_j[985]]);
        return;
    }
    if (!au9vkc[_j[612]] || au9vkc[_j[612]][_j[436]] == 0x0) {
        window[_j[1239]](0x3, _j[1323]), window['y$ITX5'](_j[1324]);
        return;
    }
    this[_j[1325]](au9vkc);
}, window[_j[1318]] = function (k5hyg) {
    var q2fwir = this;
    sendApi(y$X5[_j[1192]], _j[1326], {
        'server_id': k5hyg,
        'time': Date[_j[803]]() / 0x3e8
    }, q2fwir[_j[1327]][_j[426]](q2fwir), y$T5X, y$5I);
}, window[_j[1327]] = function (_73m0) {
    if (!_73m0) {
        window[_j[1239]](0x4, _j[1328]), this[_j[1319]]();
        return;
    }
    if (_73m0[_j[985]] != _j[984]) {
        window[_j[1239]](0x4, _j[1329] + _73m0[_j[985]]), this[_j[1319]]();
        return;
    }
    if (!_73m0[_j[612]] || _73m0[_j[612]][_j[436]] == 0x0) {
        window[_j[1239]](0x4, _j[1330]), this[_j[1319]]();
        return;
    }
    this[_j[1325]](_73m0);
}, window[_j[1325]] = function (y5xj) {
    y$X5[_j[1106]] = y5xj[_j[1331]] != undefined ? y5xj[_j[1331]] : 0x0, y$X5[_j[808]] = {
        'server_id': String(y5xj[_j[612]][0x0][_j[71]]),
        'server_name': String(y5xj[_j[612]][0x0][_j[973]]),
        'entry_ip': y5xj[_j[612]][0x0][_j[1332]],
        'entry_port': parseInt(y5xj[_j[612]][0x0][_j[1333]]),
        'status': y$XTI(y5xj[_j[612]][0x0]),
        'start_time': y5xj[_j[612]][0x0][_j[1334]],
        'maintain_time': y5xj[_j[612]][0x0][_j[892]] ? y5xj[_j[612]][0x0][_j[892]] : '',
        'cdn': y$X5[_j[974]]
    }, this[_j[1335]](), window[_j[1179]] && window[_j[1179]][_j[804]][_j[1336]] && window[_j[1179]][_j[804]][_j[1336]](sdkInitRes[_j[1337]], sdkInitRes[_j[1338]], sdkInitRes[_j[1339]], sdkInitRes[_j[1340]], sdkInitRes[_j[1341]]);
}, window[_j[1335]] = function () {
    window['y$XT'] = !![], window['y$5XTI']();
}, window['y$5XTI'] = function () {
    if (window['y$XT'] && window['y$TX']) {
        var m7_co3 = y$X5[_j[948]] != undefined ? y$X5[_j[948]] : 0x0,
            hx5ze$ = y$X5[_j[949]] == undefined ? 0x0 : y$X5[_j[949]],
            i2fwrq = m7_co3 == 0x1 && hx5ze$ == 0x1 || m7_co3 == 0x2 && hx5ze$ != 0x1 || m7_co3 == 0x3;
        console[_j[1233]](_j[1342] + y$X5[_j[1106]] + _j[1343] + i2fwrq + _j[1344] + y$X5[_j[949]] + _j[1345] + y$X5[_j[948]]);
        if (!i2fwrq && y$X5[_j[1106]] == 0x1) {
            var e5y = y$X5[_j[808]][_j[888]];
            if (e5y === -0x1 || e5y === 0x0) {
                window[_j[1239]](0xf, _j[1346] + y$X5[_j[808]]['id'] + _j[1347] + y$X5[_j[808]][_j[888]]), window['y$ITX5'](e5y === -0x1 ? _j[1348] : _j[1349]);
                return;
            }
            y$5ITX(0x0, y$X5[_j[808]][_j[71]]), window[_j[1179]][_j[804]][_j[1101]](y$X5[_j[1106]]);
        } else window[_j[1179]][_j[804]][_j[1096]]({
            'show': sdkInitRes[_j[1337]],
            'skinUrl': sdkInitRes[_j[1338]],
            'content': sdkInitRes[_j[1339]],
            'x': sdkInitRes[_j[1340]],
            'y': sdkInitRes[_j[1341]]
        }), y$IX5T();
        window[_j[1350]](), window['y$5TXI'](), window['y$5XIT']();
    }
}, window['y$TXI5'] = function () {
    sendApi(y$X5[_j[1192]], _j[1351], {
        'game_pkg': y$X5[_j[945]],
        'version_name': y$X5[_j[1271]]
    }, this[_j[1352]][_j[426]](this), y$T5X, y$5I);
}, window[_j[1352]] = function (qnist) {
    if (!qnist) {
        window[_j[1239]](0x5, _j[1353]), window['y$ITX5'](_j[1353]);
        return;
    }
    if (qnist[_j[985]] != _j[984]) {
        window[_j[1239]](0x5, _j[1354] + qnist[_j[985]]), window['y$ITX5'](_j[1354] + qnist[_j[985]]);
        return;
    }
    if (!qnist[_j[612]] || !qnist[_j[612]][_j[1188]]) {
        window[_j[1239]](0x5, _j[1355] + (qnist[_j[612]] && qnist[_j[612]][_j[1188]])), window['y$ITX5'](_j[1355] + (qnist[_j[612]] && qnist[_j[612]][_j[1188]]));
        return;
    }
    qnist[_j[612]][_j[1356]] && qnist[_j[612]][_j[1356]][_j[436]] > 0xa && (y$X5[_j[1357]] = qnist[_j[612]][_j[1356]], y$X5[_j[974]] = qnist[_j[612]][_j[1356]]), qnist[_j[612]][_j[1188]] && (y$X5[_j[863]] = qnist[_j[612]][_j[1188]]), console[_j[1233]](_j[1358] + y$X5[_j[863]] + _j[1359] + y$X5[_j[1271]]), window['y$X5T'] = !![], window['y$5TXI'](), window['y$5XIT']();
}, window[_j[1360]], window['y$TX5I'] = function () {
    sendApi(y$X5[_j[1192]], _j[1361], { 'game_pkg': y$X5[_j[945]] }, this['y$T5IX'][_j[426]](this), y$T5X, y$5I);
}, window['y$T5IX'] = function (if2wqr) {
    if (if2wqr && if2wqr[_j[985]] === _j[984] && if2wqr[_j[612]]) {
        window[_j[1360]] = if2wqr[_j[612]];
        for (var vc7om_ in if2wqr[_j[612]]) {
            y$X5[vc7om_] = if2wqr[_j[612]][vc7om_];
        }
    } else window[_j[1239]](0xb, _j[1362]), console[_j[1233]](_j[1363] + if2wqr[_j[985]]);
    window['y$TX'] = !![], window['y$5XTI']();
}, window[_j[1350]] = function () {
    if (!window['y$XT'] || !window['y$TX']) return;
    var cauvk = y$X5[_j[1106]] == 0x1,
        rp0f6 = y$X5[_j[950]],
        tsqw = y$X5[_j[1364]] && y$X5[_j[1364]] > 0x0;
    if (rp0f6 || cauvk && tsqw) {
        var vuoc9 = y$X5[_j[1365]],
            _73cmo = vuoc9 && vuoc9[_j[436]] == 0x9;
        _73cmo && (window[_j[1366]] = vuoc9);
        var jkghy = y$X5[_j[1367]],
            ejyh5g = jkghy && jkghy[_j[556]]('#')[_j[436]] == 0x4;
        ejyh5g && (window[_j[1061]] = jkghy);
    }
}, window[_j[1238]] = function () {
    window[_j[1366]] = null, window[_j[1061]] = null;
}, window[_j[1368]] = function (l18t, p0f26r, e$xh5z, av9ug, e5xzhy, qifr, sqfw, xe5z4$, nt8b1l, x5e$hz) {
    e5xzhy = String(e5xzhy);
    var agkyu = sqfw,
        qtsnb = xe5z4$;
    y$X5[_j[1187]][e5xzhy] = {
        'productid': e5xzhy,
        'productname': agkyu,
        'productdesc': qtsnb,
        'roleid': l18t,
        'rolename': p0f26r,
        'rolelevel': e$xh5z,
        'price': qifr,
        'callback': nt8b1l
    }, sendApi(y$X5[_j[1196]], _j[1369], {
        'game_pkg': y$X5[_j[945]],
        'server_id': y$X5[_j[808]][_j[71]],
        'server_name': y$X5[_j[808]][_j[973]],
        'level': e$xh5z,
        'uid': y$X5[_j[1245]],
        'role_id': l18t,
        'role_name': p0f26r,
        'product_id': e5xzhy,
        'product_name': agkyu,
        'product_desc': qtsnb,
        'money': qifr,
        'partner_id': y$X5[_j[1200]]
    }, toPayCallBack, y$T5X, y$5I);
}, window[_j[1370]] = function (wisfqr) {
    if (wisfqr && (wisfqr[_j[1371]] === 0xc8 || wisfqr[_j[985]] == _j[984])) {
        var p2w = y$X5[_j[1187]][String(wisfqr[_j[1372]])];
        if (p2w[_j[1373]]) p2w[_j[1373]](wisfqr[_j[1372]], wisfqr[_j[1374]], -0x1);
        _qnbtl[_j[51]]({
            'cpbill': wisfqr[_j[1374]],
            'productid': wisfqr[_j[1372]],
            'productname': p2w[_j[1375]],
            'productdesc': p2w[_j[1376]],
            'serverid': y$X5[_j[808]][_j[71]],
            'servername': y$X5[_j[808]][_j[973]],
            'roleid': p2w[_j[1377]],
            'rolename': p2w[_j[1378]],
            'rolelevel': p2w[_j[1379]],
            'price': p2w[_j[1380]],
            'extension': JSON[_j[1117]]({ 'cp_order_id': wisfqr[_j[1374]] })
        }, function (irswb, j9uag) {
            p2w[_j[1373]] && irswb == 0x0 && p2w[_j[1373]](wisfqr[_j[1372]], wisfqr[_j[1374]], irswb);
            console[_j[1233]](JSON[_j[1117]]({
                'type': _j[1381],
                'status': irswb,
                'data': wisfqr,
                'role_name': p2w[_j[1378]]
            }));
            if (irswb === 0x0) {} else {
                if (irswb === 0x1) {} else {
                    if (irswb === 0x2) {}
                }
            }
        });
    } else {
        var swrb = wisfqr ? _j[1382] + wisfqr[_j[1371]] + _j[1383] + wisfqr[_j[985]] + _j[1384] + wisfqr[_j[1233]] : _j[1385];
        window[_j[1239]](0xd, _j[1386] + swrb), alert(swrb);
    }
}, window['y$T5XI'] = function () {}, window['y$IT5'] = function (m9acvu, heg5j, omc7_3, fp0263, jhyxe) {
    _qnbtl[_j[91]](y$X5[_j[808]][_j[71]], y$X5[_j[808]][_j[973]] || y$X5[_j[808]][_j[71]], m9acvu, heg5j, omc7_3), sendApi(y$X5[_j[1192]], _j[1387], {
        'game_pkg': y$X5[_j[945]],
        'server_id': y$X5[_j[808]][_j[71]],
        'role_id': m9acvu,
        'uid': y$X5[_j[1245]],
        'role_name': heg5j,
        'role_type': fp0263,
        'level': omc7_3
    });
}, window['y$I5T'] = function (ka9ugj, srqwbi, x5$4ze, yezh5, uaj9g, oc9u, qtwis, kahj, o9mv_c, swrqb) {
    y$X5[_j[1242]] = ka9ugj, y$X5[_j[1243]] = srqwbi, y$X5[_j[1244]] = x5$4ze, _qnbtl[_j[92]](y$X5[_j[808]][_j[71]], y$X5[_j[808]][_j[973]] || y$X5[_j[808]][_j[71]], ka9ugj, srqwbi, x5$4ze), sendApi(y$X5[_j[1192]], _j[1388], {
        'game_pkg': y$X5[_j[945]],
        'server_id': y$X5[_j[808]][_j[71]],
        'role_id': ka9ugj,
        'uid': y$X5[_j[1245]],
        'role_name': srqwbi,
        'role_type': yezh5,
        'level': x5$4ze,
        'evolution': uaj9g
    });
}, window['y$TI5'] = function (x$45ze, cmv, wp6f2r, ukyjg, omvuc, p6f02, ntl18b, agyujk, kujyg, vucm) {
    y$X5[_j[1242]] = x$45ze, y$X5[_j[1243]] = cmv, y$X5[_j[1244]] = wp6f2r, _qnbtl[_j[93]](y$X5[_j[808]][_j[71]], y$X5[_j[808]][_j[973]] || y$X5[_j[808]][_j[71]], x$45ze, cmv, wp6f2r), sendApi(y$X5[_j[1192]], _j[1388], {
        'game_pkg': y$X5[_j[945]],
        'server_id': y$X5[_j[808]][_j[71]],
        'role_id': x$45ze,
        'uid': y$X5[_j[1245]],
        'role_name': cmv,
        'role_type': ukyjg,
        'level': wp6f2r,
        'evolution': omvuc
    });
}, window['y$T5I'] = function (hjg5e) {}, window['y$IT'] = function (c9uav) {
    _qnbtl[_j[32]](_j[32], function (fqir) {
        c9uav && c9uav(fqir);
    });
}, window[_j[90]] = function () {
    _qnbtl[_j[90]]();
}, window[_j[1389]] = function () {
    _qnbtl[_j[101]] && _qnbtl[_j[101]]();
}, window[_j[1390]] = function ($hxe5, jhagyk, vc9ou, iw2rf, hejxy, _o0m, swfqi, $zxh) {
    $zxh = $zxh || y$X5[_j[808]][_j[71]], sendApi(y$X5[_j[1192]], _j[1391], {
        'phone': $hxe5,
        'role_id': jhagyk,
        'uid': y$X5[_j[1245]],
        'game_pkg': y$X5[_j[945]],
        'partner_id': y$X5[_j[1200]],
        'server_id': $zxh
    }, swfqi, 0x2, null, function () {
        return !![];
    });
}, window[_j[1392]] = function (cvk9) {
    window['y$5IT'] = cvk9, window['y$5IT'] && window['y$TI'] && (console[_j[1233]](_j[1393] + window['y$TI'][_j[1394]]), window['y$5IT'](window['y$TI']), window['y$TI'] = null);
}, window['y$5TI'] = function (ayjkh, l1d8n, gh5jye, hjgak) {
    window[_j[1395]](_j[1396], {
        'game_pkg': window['y$X5'][_j[945]],
        'role_id': l1d8n,
        'server_id': gh5jye
    }, hjgak);
}, window['y$XIT5'] = function (e5yhjx, kjga, tnsqb) {
    function m_0o(bqtis) {
        var gu9jak = [],
            f2qrw = [],
            gyjha = tnsqb || window[_j[1055]][_j[1397]];
        for (var co7m3_ in gyjha) {
            var akj9ug = Number(co7m3_);
            (!e5yhjx || !e5yhjx[_j[436]] || e5yhjx[_j[516]](akj9ug) != -0x1) && (f2qrw[_j[458]](gyjha[co7m3_]), gu9jak[_j[458]]([akj9ug, 0x3]));
        }
        window['y$HT5IX'](window[_j[1398]], _j[1399]) >= 0x0 ? (console[_j[567]](_j[1400]), _qnbtl[_j[83]] && _qnbtl[_j[83]](f2qrw, function (n1stb) {
            console[_j[567]](_j[1401]), console[_j[567]](n1stb);
            if (n1stb && n1stb[_j[85]] == _j[86]) for (var jghak in gyjha) {
                if (n1stb[gyjha[jghak]] == _j[88]) {
                    var qtsnib = Number(jghak);
                    for (var oc7 = 0x0; oc7 < gu9jak[_j[436]]; oc7++) {
                        if (gu9jak[oc7][0x0] == qtsnib) {
                            gu9jak[oc7][0x1] = 0x1;
                            break;
                        }
                    }
                }
            }
            window['y$HT5IX'](window[_j[1398]], _j[1402]) >= 0x0 ? wx[_j[1403]]({
                'withSubscriptions': !![],
                'success': function (z4e5x) {
                    var p26rf0 = z4e5x[_j[1404]][_j[1405]];
                    if (p26rf0) {
                        console[_j[567]](_j[1406]), console[_j[567]](p26rf0);
                        for (var blt8 in gyjha) {
                            if (p26rf0[gyjha[blt8]] == _j[88]) {
                                var kayjug = Number(blt8);
                                for (var gy5j = 0x0; gy5j < gu9jak[_j[436]]; gy5j++) {
                                    if (gu9jak[gy5j][0x0] == kayjug) {
                                        gu9jak[gy5j][0x1] = 0x2;
                                        break;
                                    }
                                }
                            }
                        }
                        console[_j[567]](gu9jak), kjga && kjga(gu9jak);
                    } else console[_j[567]](_j[1407]), console[_j[567]](z4e5x), console[_j[567]](gu9jak), kjga && kjga(gu9jak);
                },
                'fail': function () {
                    console[_j[567]](_j[1408]), console[_j[567]](gu9jak), kjga && kjga(gu9jak);
                }
            }) : (console[_j[567]](_j[1409] + window[_j[1398]]), console[_j[567]](gu9jak), kjga && kjga(gu9jak));
        })) : (console[_j[567]](_j[1410] + window[_j[1398]]), console[_j[567]](gu9jak), kjga && kjga(gu9jak)), wx[_j[1411]](m_0o);
    }
    wx[_j[1412]](m_0o);
}, window['y$XI5T'] = {
    'isSuccess': ![],
    'level': _j[1413],
    'isCharging': ![]
}, window['y$XTI5'] = function (yehjx) {
    wx[_j[1414]]({
        'success': function (x5yej) {
            var akvcu9 = window['y$XI5T'];
            akvcu9[_j[1415]] = !![], akvcu9[_j[1416]] = Number(x5yej[_j[1416]])[_j[1417]](0x0), akvcu9[_j[1418]] = x5yej[_j[1418]], yehjx && yehjx(akvcu9[_j[1415]], akvcu9[_j[1416]], akvcu9[_j[1418]]);
        },
        'fail': function (om9cu) {
            console[_j[567]](_j[1419], om9cu[_j[85]]);
            var j9uakg = window['y$XI5T'];
            yehjx && yehjx(j9uakg[_j[1415]], j9uakg[_j[1416]], j9uakg[_j[1418]]);
        }
    });
}, window[_j[1420]] = function (qbtisw) {
    wx[_j[1420]]({
        'success': function (f6230) {
            qbtisw && qbtisw(!![], f6230);
        },
        'fail': function (he$x) {
            qbtisw && qbtisw(![], he$x);
        }
    });
}, window[_j[1421]] = function (o_c7) {
    if (o_c7) wx[_j[1421]](o_c7);
}, window[_j[1422]] = function (f036p) {
    wx[_j[1422]](f036p);
}, window[_j[1395]] = function (co_m9, n8, w6r2, _m3oc, au9gkv, ehz$5, yezx, _0om) {
    if (_m3oc == undefined) _m3oc = 0x1;
    wx[_j[1257]]({
        'url': co_m9,
        'method': yezx || _j[1423],
        'responseType': _j[860],
        'data': n8,
        'header': { 'content-type': _0om || _j[1258] },
        'success': function (iwfp2) {
            DEBUG && console[_j[567]](_j[1424], co_m9, info, iwfp2);
            if (iwfp2 && iwfp2[_j[1425]] == 0xc8) {
                var stwb = iwfp2[_j[612]];
                !ehz$5 || ehz$5(stwb) ? w6r2 && w6r2(stwb) : window[_j[1426]](co_m9, n8, w6r2, _m3oc, au9gkv, ehz$5, iwfp2);
            } else window[_j[1426]](co_m9, n8, w6r2, _m3oc, au9gkv, ehz$5, iwfp2);
        },
        'fail': function (f6wp2) {
            DEBUG && console[_j[567]](_j[1427], co_m9, info, f6wp2), window[_j[1426]](co_m9, n8, w6r2, _m3oc, au9gkv, ehz$5, f6wp2);
        },
        'complete': function () {}
    });
}, window[_j[1426]] = function (f2rwip, acm9uv, ayhjkg, j5eg, mco_v, qitbws, qwfirs) {
    j5eg - 0x1 > 0x0 ? setTimeout(function () {
        window[_j[1395]](f2rwip, acm9uv, ayhjkg, j5eg - 0x1, mco_v, qitbws);
    }, 0x3e8) : mco_v && mco_v(JSON[_j[1117]]({
        'url': f2rwip,
        'response': qwfirs
    }));
}, window[_j[1428]] = function (swfriq, qtnsb1, sb1qt, qsriw, c7vo_m, oum9c, bqsti) {
    !sb1qt && (sb1qt = {});
    var o70_6 = Math[_j[463]](Date[_j[803]]() / 0x3e8);
    sb1qt[_j[1315]] = o70_6, sb1qt[_j[1429]] = qtnsb1;
    var ov9_c = Object[_j[435]](sb1qt)[_j[622]](),
        bnt1l8 = '',
        l8dt1 = '';
    for (var kjg9a = 0x0; kjg9a < ov9_c[_j[436]]; kjg9a++) {
        bnt1l8 = bnt1l8 + (kjg9a == 0x0 ? '' : '&') + ov9_c[kjg9a] + sb1qt[ov9_c[kjg9a]], l8dt1 = l8dt1 + (kjg9a == 0x0 ? '' : '&') + ov9_c[kjg9a] + '=' + encodeURIComponent(sb1qt[ov9_c[kjg9a]]);
    }
    bnt1l8 = bnt1l8 + y$X5[_j[1198]];
    var _cov7 = _j[1430] + md5(bnt1l8);
    send(swfriq + '?' + l8dt1 + (l8dt1 == '' ? '' : '&') + _cov7, null, qsriw, c7vo_m, oum9c, bqsti || function (vaguk) {
        return vaguk[_j[985]] == _j[984];
    }, null, _j[23]);
}, window['y$XT5I'] = function (irqbs, vkgua9) {
    var isnb = 0x0;
    y$X5[_j[808]] && (isnb = y$X5[_j[808]][_j[71]]), sendApi(y$X5[_j[1194]], _j[1431], {
        'partnerId': y$X5[_j[1200]],
        'gamePkg': y$X5[_j[945]],
        'logTime': Math[_j[463]](Date[_j[803]]() / 0x3e8),
        'platformUid': y$X5[_j[1311]],
        'type': irqbs,
        'serverId': isnb
    }, null, 0x2, null, function () {
        return !![];
    });
}, window['y$X5IT'] = function (ykhgj5) {
    sendApi(y$X5[_j[1192]], _j[1432], {
        'partner_id': y$X5[_j[1200]],
        'uid': y$X5[_j[1245]],
        'version': y$X5[_j[1188]],
        'game_pkg': y$X5[_j[945]],
        'device': y$X5[_j[1201]]
    }, y$X5TI, y$T5X, y$5I);
}, window['y$X5TI'] = function (tnbs1q) {
    if (tnbs1q && tnbs1q[_j[985]] === _j[984] && tnbs1q[_j[612]]) {
        tnbs1q[_j[612]][_j[539]]({
            'id': -0x2,
            'name': _j[1433]
        }), tnbs1q[_j[612]][_j[539]]({
            'id': -0x1,
            'name': _j[1434]
        }), y$X5[_j[944]] = tnbs1q[_j[612]];
        if (window[_j[934]]) window[_j[934]][_j[975]]();
    } else {
        y$X5[_j[954]] = ![];
        var yz5xe = tnbs1q ? tnbs1q[_j[985]] : '';
        window[_j[1239]](0x7, _j[1435] + yz5xe), window['y$ITX5'](_j[1436] + yz5xe);
    }
}, window['y$ITX'] = function (ghjye) {
    sendApi(y$X5[_j[1192]], _j[1437], {
        'partner_id': y$X5[_j[1200]],
        'uid': y$X5[_j[1245]],
        'version': y$X5[_j[1188]],
        'game_pkg': y$X5[_j[945]],
        'device': y$X5[_j[1201]]
    }, y$IXT, y$T5X, y$5I);
}, window['y$IXT'] = function (vo9m_) {
    y$X5[_j[981]] = ![];
    if (vo9m_ && vo9m_[_j[985]] === _j[984] && vo9m_[_j[612]]) {
        for (var mcv9o_ = 0x0; mcv9o_ < vo9m_[_j[612]][_j[436]]; mcv9o_++) {
            vo9m_[_j[612]][mcv9o_][_j[888]] = y$XTI(vo9m_[_j[612]][mcv9o_]);
        }
        y$X5[_j[979]][-0x1] = window[_j[1438]](vo9m_[_j[612]]), window[_j[934]][_j[980]](-0x1);
    } else {
        var n8lb = vo9m_ ? vo9m_[_j[985]] : '';
        window[_j[1239]](0x8, _j[1439] + n8lb), window['y$ITX5'](_j[1440] + n8lb);
    }
}, window[_j[1441]] = function (ehx5y) {
    sendApi(y$X5[_j[1192]], _j[1437], {
        'partner_id': y$X5[_j[1200]],
        'uid': y$X5[_j[1245]],
        'version': y$X5[_j[1188]],
        'game_pkg': y$X5[_j[945]],
        'device': y$X5[_j[1201]]
    }, ehx5y, y$T5X, y$5I);
}, window['y$TIX'] = function (cvuka, e5hyx) {
    sendApi(y$X5[_j[1192]], _j[1442], {
        'partner_id': y$X5[_j[1200]],
        'uid': y$X5[_j[1245]],
        'version': y$X5[_j[1188]],
        'game_pkg': y$X5[_j[945]],
        'device': y$X5[_j[1201]],
        'server_group_id': e5hyx
    }, y$TXI, y$T5X, y$5I);
}, window['y$TXI'] = function (b18sn) {
    y$X5[_j[981]] = ![];
    if (b18sn && b18sn[_j[985]] === _j[984] && b18sn[_j[612]] && b18sn[_j[612]][_j[612]]) {
        var uva9 = b18sn[_j[612]][_j[1443]],
            wi2qfr = [];
        for (var ug9akj = 0x0; ug9akj < b18sn[_j[612]][_j[612]][_j[436]]; ug9akj++) {
            b18sn[_j[612]][_j[612]][ug9akj][_j[888]] = y$XTI(b18sn[_j[612]][_j[612]][ug9akj]), (wi2qfr[_j[436]] == 0x0 || b18sn[_j[612]][_j[612]][ug9akj][_j[888]] != 0x0) && (wi2qfr[wi2qfr[_j[436]]] = b18sn[_j[612]][_j[612]][ug9akj]);
        }
        y$X5[_j[979]][uva9] = window[_j[1438]](wi2qfr), window[_j[934]][_j[980]](uva9);
    } else {
        var jkgyau = b18sn ? b18sn[_j[985]] : '';
        window[_j[1239]](0x9, _j[1444] + jkgyau), window['y$ITX5'](_j[1445] + jkgyau);
    }
}, window['y$HT5X'] = function (gka9j) {
    sendApi(y$X5[_j[1192]], _j[1446], {
        'partner_id': y$X5[_j[1200]],
        'uid': y$X5[_j[1245]],
        'version': y$X5[_j[1188]],
        'game_pkg': y$X5[_j[945]],
        'device': y$X5[_j[1201]]
    }, reqServerRecommendCallBack, y$T5X, y$5I);
}, window[_j[1447]] = function (t1bnl8) {
    y$X5[_j[981]] = ![];
    if (t1bnl8 && t1bnl8[_j[985]] === _j[984] && t1bnl8[_j[612]]) {
        for (var yukjag = 0x0; yukjag < t1bnl8[_j[612]][_j[436]]; yukjag++) {
            t1bnl8[_j[612]][yukjag][_j[888]] = y$XTI(t1bnl8[_j[612]][yukjag]);
        }
        y$X5[_j[979]][-0x2] = window[_j[1438]](t1bnl8[_j[612]]), window[_j[934]][_j[980]](-0x2);
    } else {
        var mu9ovc = t1bnl8 ? t1bnl8[_j[985]] : '';
        window[_j[1239]](0xa, _j[1448] + mu9ovc), alert(_j[1449] + mu9ovc);
    }
}, window[_j[1438]] = function (o7vm_c) {
    return o7vm_c;
}, window['y$XIT'] = function (yhjk5, qbrs) {
    yhjk5 = yhjk5 || y$X5[_j[808]][_j[71]], sendApi(y$X5[_j[1192]], _j[1450], {
        'type': '4',
        'game_pkg': y$X5[_j[945]],
        'server_id': yhjk5
    }, qbrs);
}, window[_j[1451]] = function (hez5x$, mc73, qwtsbi, ey5jx) {
    qwtsbi = qwtsbi || y$X5[_j[808]][_j[71]], sendApi(y$X5[_j[1192]], _j[1452], {
        'type': hez5x$,
        'game_pkg': mc73,
        'server_id': qwtsbi
    }, ey5jx);
}, window[_j[1453]] = function (uakgj9, jgyhk5) {
    sendApi(y$X5[_j[1192]], _j[1454], { 'game_pkg': uakgj9 }, jgyhk5);
}, window['y$XTI'] = function (frw6p2) {
    if (frw6p2) {
        if (frw6p2[_j[888]] == 0x1) {
            if (frw6p2[_j[1455]] == 0x1) return 0x2;else return 0x1;
        } else return frw6p2[_j[888]] == 0x0 ? 0x0 : -0x1;
    }
    return -0x1;
}, window['y$5ITX'] = function (comv7, wq2f) {
    y$X5[_j[1456]] = {
        'step': comv7,
        'server_id': wq2f
    };
    var o0_37m = this;
    y$IXT5({ 'title': _j[1457] }), sendApi(y$X5[_j[1192]], _j[1458], {
        'partner_id': y$X5[_j[1200]],
        'uid': y$X5[_j[1245]],
        'game_pkg': y$X5[_j[945]],
        'server_id': wq2f,
        'platform': y$X5[_j[1310]],
        'platform_uid': y$X5[_j[1311]],
        'check_login_time': y$X5[_j[1314]],
        'check_login_sign': y$X5[_j[1312]],
        'version_name': y$X5[_j[1271]]
    }, y$5IXT, y$T5X, y$5I, function (cmavu9) {
        return cmavu9[_j[985]] == _j[984] || cmavu9[_j[1233]] == _j[1459] || cmavu9[_j[1233]] == _j[1460];
    });
}, window['y$5IXT'] = function (haygjk) {
    var yhjxe = this;
    if (haygjk && haygjk[_j[985]] === _j[984] && haygjk[_j[612]]) {
        var kjhayg = y$X5[_j[808]];
        kjhayg[_j[1461]] = y$X5[_j[1203]], kjhayg[_j[1313]] = String(haygjk[_j[612]][_j[1462]]), kjhayg[_j[1209]] = parseInt(haygjk[_j[612]][_j[1315]]);
        if (haygjk[_j[612]][_j[1463]]) kjhayg[_j[1463]] = parseInt(haygjk[_j[612]][_j[1463]]);else kjhayg[_j[1463]] = parseInt(haygjk[_j[612]][_j[71]]);
        kjhayg[_j[1464]] = 0x0, kjhayg[_j[974]] = y$X5[_j[1357]], kjhayg[_j[1465]] = haygjk[_j[612]][_j[1466]], kjhayg[_j[1467]] = haygjk[_j[612]][_j[1467]];
        if (haygjk[_j[612]][_j[1468]]) kjhayg[_j[1468]] = parseInt(haygjk[_j[612]][_j[1468]]);
        console[_j[567]](_j[1469] + JSON[_j[1117]](kjhayg[_j[1467]])), y$X5[_j[1106]] == 0x1 && kjhayg[_j[1467]] && kjhayg[_j[1467]][_j[1470]] == 0x1 && (y$X5[_j[866]] = 0x1, window[_j[1179]][_j[804]]['y$H5X']()), y$5TIX();
    } else {
        if (y$X5[_j[1456]][_j[1471]] >= 0x3) {
            var jygh = haygjk ? haygjk[_j[985]] : '';
            window[_j[1239]](0xc, _j[1472] + jygh), y$5I(JSON[_j[1117]](haygjk)), window['y$ITX5'](_j[1473] + jygh);
        } else sendApi(y$X5[_j[1192]], _j[1289], {
            'platform': y$X5[_j[1190]],
            'partner_id': y$X5[_j[1200]],
            'token': y$X5[_j[1284]],
            'game_pkg': y$X5[_j[945]],
            'deviceId': y$X5[_j[1201]],
            'scene': _j[1290] + y$X5[_j[1202]]
        }, function (y5xhze) {
            if (!y5xhze || y5xhze[_j[985]] != _j[984]) {
                window['y$ITX5'](_j[1306] + y5xhze && y5xhze[_j[985]]);
                return;
            }
            y$X5[_j[1312]] = String(y5xhze[_j[1313]]), y$X5[_j[1314]] = String(y5xhze[_j[1315]]), setTimeout(function () {
                y$5ITX(y$X5[_j[1456]][_j[1471]] + 0x1, y$X5[_j[1456]][_j[71]]);
            }, 0x5dc);
        }, y$T5X, y$5I, function (bsqwti) {
            return bsqwti[_j[985]] == _j[984] || bsqwti[_j[985]] == _j[1474];
        });
    }
}, window['y$5TIX'] = function () {
    ServerLoading[_j[804]][_j[1101]](y$X5[_j[1106]]), window['y$T5'] = !![], window['y$5XIT']();
}, window['y$5TXI'] = function () {
    if (window['y$5T'] && window['y$XT5'] && window[_j[1089]] && window[_j[1100]] && window['y$X5T'] && window['y$XT']) {
        if (!window[_j[1475]][_j[804]]) {
            console[_j[567]](_j[1476] + window[_j[1475]][_j[804]]);
            var wi2pf = wx[_j[1477]](),
                akjgyu = wi2pf[_j[1394]] ? wi2pf[_j[1394]] : 0x0,
                tbsniq = {
                'cdn': window['y$X5'][_j[974]],
                'spareCdn': window['y$X5'][_j[1277]],
                'newRegister': window['y$X5'][_j[1106]],
                'wxPC': window['y$X5'][_j[1216]],
                'wxIOS': window['y$X5'][_j[1214]],
                'wxAndroid': window['y$X5'][_j[1215]],
                'wxParam': {
                    'limitLoad': window['y$X5']['y$HIT5X'],
                    'benchmarkLevel': window['y$X5']['y$HIXT5'],
                    'wxFrom': window[_j[1055]][_j[450]] == _j[1478] ? 0x1 : 0x0,
                    'wxSDKVersion': window[_j[1398]],
                    'qudao': _j[1479]
                },
                'configType': window['y$X5'][_j[1210]],
                'exposeType': window['y$X5'][_j[1212]],
                'scene': akjgyu,
                'video_type': window['y$X5'][_j[1286]],
                'ad_flag': window['y$X5'][_j[949]]
            };
            if (window[_j[1360]]) for (var qbtwi in window[_j[1360]]) {
                if (!tbsniq[qbtwi]) tbsniq[qbtwi] = window[_j[1360]][qbtwi];
            }
            new window[_j[1475]](tbsniq, window['y$X5'][_j[863]], window['y$HITX5']);
        }
    }
}, window['y$5XIT'] = function () {
    if (window['y$5T'] && window['y$XT5'] && window[_j[1089]] && window[_j[1100]] && window['y$X5T'] && window['y$XT'] && window['y$T5'] && window['y$TX']) {
        y$IX5T();
        if (!y$5TX) {
            y$5TX = !![];
            if (!window[_j[1475]][_j[804]]) window['y$5TXI']();
            var y5 = 0x0,
                hgkjy = wx[_j[1480]]();
            hgkjy && (window['y$X5'][_j[1481]] && (y5 = hgkjy[_j[756]]), console[_j[1233]](_j[1482] + hgkjy[_j[756]] + _j[1483] + hgkjy[_j[877]] + _j[1484] + hgkjy[_j[1000]] + _j[1485] + hgkjy[_j[719]] + _j[1486] + hgkjy[_j[830]] + _j[1487] + hgkjy[_j[832]]));
            var p32760 = {};
            for (const _comv9 in y$X5[_j[808]]) {
                p32760[_comv9] = y$X5[_j[808]][_comv9];
            }
            var t1snbq = {
                'channel': window['y$X5'][_j[1204]],
                'account': window['y$X5'][_j[1245]],
                'userId': window['y$X5'][_j[1309]],
                'cdn': window['y$X5'][_j[974]],
                'data': window['y$X5'][_j[612]],
                'package': window['y$X5'][_j[603]],
                'newRegister': window['y$X5'][_j[1106]],
                'pkgName': window['y$X5'][_j[945]],
                'partnerId': window['y$X5'][_j[1200]],
                'platform_uid': window['y$X5'][_j[1311]],
                'deviceId': window['y$X5'][_j[1201]],
                'selectedServer': p32760,
                'configType': window['y$X5'][_j[1210]],
                'exposeType': window['y$X5'][_j[1212]],
                'debugUsers': window['y$X5'][_j[1207]],
                'wxMenuTop': y5,
                'wxShield': window['y$X5'][_j[950]],
                'encryptParam': window['y$X5'][_j[1213]],
                'wx_channel': window['y$X5'][_j[1285]],
                'zsy_tp_state': window['y$X5'][_j[1287]]
            };
            if (window[_j[1360]]) for (var ucvak in window[_j[1360]]) {
                t1snbq[ucvak] = window[_j[1360]][ucvak];
            }
            window[_j[1475]][_j[804]]['y$5XH'](t1snbq);
            if (y$X5[_j[808]] && y$X5[_j[808]][_j[71]]) localStorage[_j[955]](_j[1317] + y$X5[_j[945]] + y$X5[_j[1245]], y$X5[_j[808]][_j[71]]);
        }
    } else console[_j[1233]](_j[1488] + window['y$5T'] + _j[1489] + window['y$XT5'] + _j[1490] + window[_j[1089]] + _j[1491] + window[_j[1100]] + _j[1492] + window['y$X5T'] + _j[1493] + window['y$XT'] + _j[1494] + window['y$T5'] + _j[1495] + window['y$TX']);
}, window[_j[1496]] = function (guavk9) {
    if (!window[_j[1497]]) {
        console[_j[610]](_j[1498]);
        return;
    }
    var j9gkau = guavk9[_j[1099]];
    j9gkau == 0x1 ? window[_j[1497]][_j[1499]](0x2327, guavk9) : window[_j[1497]][_j[867]](0x2327);
};