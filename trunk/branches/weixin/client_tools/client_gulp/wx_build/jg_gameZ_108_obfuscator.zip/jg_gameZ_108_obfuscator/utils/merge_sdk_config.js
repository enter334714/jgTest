var _j = wx.n$;
/**
 * sdk 配置
 */
let _sdk_config = {
  app_name: "侠隐双剑", // 应用名
  wx_app_id: "wx5f1636354915164b", // 微信appId
  datarangers_app_id: 436672, // 数说ID
  offerId: "1450046052", // 米大师offid
  isTestEvn: false, // 是否是测试环境
  rewarded_vedio_ad_unit: "", // 激励视频广告id(可不填写)
  interstitial_ad_unit: "", // 插屏广告id(可不填写)
  oreyun_app_key: "7221163bb7a184af04a7dac919e0fec3", // 热云appKey
  menu_share_img_id: "QW2xZAI+RJ+nLgnCL8CqAQ==",
  menu_share_img_url: "https://mmocgame.qpic.cn/wechatgame/nqMkEamOlOhaKYtkvEh5X1I0Ewick74KoaMmtAJHn3fDGkW6ZUahib3pzYYxzT8lnx/0"

  // 导出
};module.exports = _sdk_config;