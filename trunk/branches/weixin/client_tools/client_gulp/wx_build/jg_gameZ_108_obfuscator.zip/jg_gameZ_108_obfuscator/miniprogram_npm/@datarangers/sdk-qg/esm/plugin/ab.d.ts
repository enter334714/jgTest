import { Plugin, PluginConstructor } from '../../sdk.d';
declare const Plugin: PluginConstructor;
export default Plugin;
