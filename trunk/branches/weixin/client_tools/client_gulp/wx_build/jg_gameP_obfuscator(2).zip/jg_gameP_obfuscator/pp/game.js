var E = wx.$p;
import 'ppppMAIN.js';