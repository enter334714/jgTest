var E = wx.$p;
require(E[240000]);