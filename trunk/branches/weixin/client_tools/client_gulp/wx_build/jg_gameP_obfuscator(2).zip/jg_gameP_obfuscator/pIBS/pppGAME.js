var E = wx.$p;
console[E[240488]](E[244590]), window[E[244591]], wx[E[241934]](function (r67v$) {
  if (r67v$) {
    if (r67v$[E[241101]]) {
      var uxplt = window[E[240434]][E[240435]][E[240282]](new RegExp(/\./, 'g'), '_'),
          cdagb = r67v$[E[241101]],
          n935e = cdagb[E[241495]](/(pp\/pppGAME.js:)[0-9]{1,60}(:)/g);if (n935e) for (var vr76 = 0x0; vr76 < n935e[E[240178]]; vr76++) {
        if (n935e[vr76] && n935e[vr76][E[240178]] > 0x0) {
          var omxu_f = parseInt(n935e[vr76][E[240282]](E[244592], '')[E[240282]](':', ''));cdagb = cdagb[E[240282]](n935e[vr76], n935e[vr76][E[240282]](':' + omxu_f + ':', ':' + (omxu_f - 0x2) + ':'));
        }
      }cdagb = cdagb[E[240282]](new RegExp(E[244593], 'g'), E[244594] + uxplt + E[244595]), cdagb = cdagb[E[240282]](new RegExp(E[244596], 'g'), E[244594] + uxplt + E[244595]), r67v$[E[241101]] = cdagb;
    }var aqgdb = { 'id': window['_p$3'][E[240494]], 'role': window['_p$3'][E[240495]], 'level': window['_p$3'][E[240496]], 'user': window['_p$3'][E[240497]], 'version': window['_p$3'][E[240206]], 'gamever': window[E[240434]][E[240435]], 'cdn': window['_p$3'][E[240292]], 'serverid': window['_p$3'][E[240149]] ? window['_p$3'][E[240149]][E[240150]] : 0x0, 'systemInfo': window[E[240498]], 'error': E[244597], 'stack': r67v$ ? r67v$[E[241101]] : '' },
        lxfup = JSON[E[240399]](aqgdb);console[E[240401]](E[244598] + lxfup), (!window[E[244591]] || window[E[244591]] != aqgdb[E[240401]]) && (window[E[244591]] = aqgdb[E[240401]], window['_pF$'](aqgdb));
  }
});import 'ppMDadfap.js';import 'pp12asz.js';window[E[244599]] = require(E[244600]);import 'pINDEX.js';import 'ppLIBsdsa.js';import 'pppWXMsad.js';import 'ooooINITMIN.js';import 'SyMiniTool.js';console[E[240488]](E[244601]), console[E[240488]](E[244602]), _pF$23({ 'title': E[244603] });var p_rv62 = { '_pXF3$2': !![] };new window[E[240432]](p_rv62), window[E[240432]][E[240145]]['_pX2$3F']();if (window['_pXF$32']) clearInterval(window['_pXF$32']);window['_pXF$32'] = null, window['_pX23F$'] = function (ouxf_m, $yv16i) {
  if (!ouxf_m || !$yv16i) return 0x0;ouxf_m = ouxf_m[E[240725]]('.'), $yv16i = $yv16i[E[240725]]('.');const vz02 = Math[E[240870]](ouxf_m[E[240178]], $yv16i[E[240178]]);while (ouxf_m[E[240178]] < vz02) {
    ouxf_m[E[240314]]('0');
  }while ($yv16i[E[240178]] < vz02) {
    $yv16i[E[240314]]('0');
  }for (var n5q8e = 0x0; n5q8e < vz02; n5q8e++) {
    const wn359 = parseInt(ouxf_m[n5q8e]),
          fltpux = parseInt($yv16i[n5q8e]);if (wn359 > fltpux) return 0x1;else {
      if (wn359 < fltpux) return -0x1;
    }
  }return 0x0;
}, window[E[240619]] = wx[E[244604]]()[E[240619]], console[E[240306]](E[244605] + window[E[240619]]);var p_oxm_uf = wx[E[244606]]();p_oxm_uf[E[244607]](function (lsx4p) {
  console[E[240306]](E[244608] + lsx4p[E[244609]]);
}), p_oxm_uf[E[244610]](function () {
  wx[E[240473]]({ 'title': E[244611], 'content': E[244612], 'showCancel': ![], 'success': function (futx) {
      p_oxm_uf[E[244613]]();
    } });
}), p_oxm_uf[E[244614]](function () {
  console[E[240306]](E[244615]);
}), window['_pX23$F'] = function () {
  console[E[240306]](E[244616]);var z3072r = wx[E[244617]]({ 'name': E[244618], 'success': function (k4psl) {
      console[E[240306]](E[244619]), console[E[240306]](k4psl), k4psl && k4psl[E[240548]] == E[244620] ? (window['_p32'] = !![], window['_p32$F'](), window['_p3$F2']()) : setTimeout(function () {
        window['_pX23$F']();
      }, 0x1f4);
    }, 'fail': function (cbgdq) {
      console[E[240306]](E[244621]), console[E[240306]](cbgdq), setTimeout(function () {
        window['_pX23$F']();
      }, 0x1f4);
    } });z3072r && z3072r[E[244622]](sl4pk => {});
}, window['_pX$F32'] = function () {
  console[E[240306]](E[244623]);var lksh4 = wx[E[244617]]({ 'name': 'pp', 'success': function (i4hsj) {
      console[E[240306]](E[244624]), console[E[240306]](i4hsj), i4hsj && i4hsj[E[240548]] == E[244620] ? (window['_p$23'] = !![], window['_p32$F'](), window['_p3$F2']()) : setTimeout(function () {
        window['_pX$F32']();
      }, 0x1f4);
    }, 'fail': function (sjih4) {
      console[E[240306]](E[244625]), console[E[240306]](sjih4), setTimeout(function () {
        window['_pX$F32']();
      }, 0x1f4);
    } });lksh4 && lksh4[E[244622]](n9q => {});
}, window[E[244626]] = function () {
  window['_pX23F$'](window[E[240619]], E[244627]) >= 0x0 ? (console[E[240306]](E[244628] + window[E[240619]] + E[244629]), window['_p$F'](), window['_pX23$F'](), window['_pX$F32']()) : (window['_p$3F'](E[244630], window[E[240619]]), wx[E[240473]]({ 'title': E[240474], 'content': E[244631] }));
}, window[E[240498]] = '', wx[E[244632]]({ 'success'(p4sl) {
    window[E[240498]] = E[244633] + p4sl[E[244634]] + E[244635] + p4sl[E[244636]] + E[244637] + p4sl[E[240442]] + E[244638] + p4sl[E[242350]] + E[244639] + p4sl[E[240562]] + E[244640] + p4sl[E[240619]] + E[244641] + p4sl[E[244642]], console[E[240306]](window[E[240498]]), console[E[240306]](E[244643] + p4sl[E[240756]] + E[244644] + p4sl[E[244645]] + E[244646] + p4sl[E[244647]] + E[244648] + p4sl[E[244649]] + E[244650] + p4sl[E[244651]] + E[244652] + p4sl[E[244653]] + E[244654] + (p4sl[E[244655]] ? p4sl[E[244655]][E[240107]] + ',' + p4sl[E[244655]][E[240220]] + ',' + p4sl[E[244655]][E[240702]] + ',' + p4sl[E[244655]][E[240068]] : ''));var _oumf = p4sl[E[242350]] ? p4sl[E[242350]][E[241788]]() : '',
        oumfx = p4sl[E[244636]] ? p4sl[E[244636]][E[241788]]()[E[240282]]('\x20', '') : '';window['_p$3'][E[240468]] = _oumf[E[240421]](E[244656]) != -0x1, window['_p$3'][E[240469]] = _oumf[E[240421]](E[244657]) != -0x1, window['_p$3'][E[240698]] = _oumf[E[240421]](E[244656]) != -0x1 || _oumf[E[240421]](E[244657]) != -0x1, window['_p$3'][E[240470]] = _oumf[E[240421]](E[244658]) != -0x1 || _oumf[E[240421]](E[240443]) != -0x1, window['_p$3'][E[240506]] = p4sl[E[240562]] ? p4sl[E[240562]][E[241788]]() : '', window['_p$3']['_pXF23$'] = ![], window['_p$3']['_pXF$23'] = 0x2;if (_oumf[E[240421]](E[244657]) != -0x1) {
      if (p4sl[E[244642]] >= 0x18) window['_p$3']['_pXF$23'] = 0x3;else window['_p$3']['_pXF$23'] = 0x2;
    } else {
      if (_oumf[E[240421]](E[244656]) != -0x1) {
        if (p4sl[E[244642]] && p4sl[E[244642]] >= 0x14) window['_p$3']['_pXF$23'] = 0x3;else {
          if (oumfx[E[240421]](E[244659]) != -0x1 || oumfx[E[240421]](E[244660]) != -0x1 || oumfx[E[240421]](E[244661]) != -0x1 || oumfx[E[240421]](E[244662]) != -0x1 || oumfx[E[240421]](E[244663]) != -0x1) window['_p$3']['_pXF$23'] = 0x2;else window['_p$3']['_pXF$23'] = 0x3;
        }
      } else window['_p$3']['_pXF$23'] = 0x2;
    }console[E[240306]](E[244664] + window['_p$3']['_pXF23$'] + E[244665] + window['_p$3']['_pXF$23']);
  } }), wx[E[240638]]({ 'success': function (ul4pt) {
    console[E[240306]](E[244666] + ul4pt[E[240640]] + E[244667] + ul4pt[E[240642]]);
  } }), wx[E[244668]]({ 'success': function (hsyjik) {
    console[E[240306]](E[244669] + hsyjik[E[244670]]);
  } }), wx[E[244671]]({ 'keepScreenOn': !![] }), wx[E[244672]](function (q8ga9b) {
  console[E[240306]](E[244669] + q8ga9b[E[244670]] + E[244673] + q8ga9b[E[244674]]);
}), wx[E[240613]](function ($v6r71) {
  window['_p2F'] = $v6r71, window['_p3F2'] && window['_p2F'] && (console[E[240488]](E[240614] + window['_p2F'][E[240615]]), window['_p3F2'](window['_p2F']), window['_p2F'] = null);
}), window['_pX$23F'] = 0x0, window[E[244675]] = null, wx[E[244676]](function () {
  window['_pX$23F']++, wx[E[244677]]();if (window['_pX$23F'] >= 0x2) {
    window['_pX$23F'] = 0x0, console[E[240401]](E[244678]), wx[E[244679]]('0', 0x1);if (window['_p$3'] && window['_p$3'][E[240468]]) window['_p$3F'](E[244680], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});