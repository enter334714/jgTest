var E = wx.$p;
import p_isjyh from '../pskp/psdkp.js';window[E[240433]] = { 'wxVersion': window[E[240434]][E[240435]] }, window[E[240436]] = ![], window['_p3$'] = 0x1, window[E[240437]] = 0x1, window['_p2$3'] = !![], window[E[240438]] = !![], window['_pXF2$3'] = '', window['_p$3'] = { 'base_cdn': E[240439], 'cdn': E[240439] }, _p$3[E[240440]] = {}, _p$3[E[240441]] = '0', _p$3[E[240442]] = window[E[240433]][E[240208]], _p$3[E[240443]] = '', _p$3['os'] = '1', _p$3[E[240444]] = E[240445], _p$3[E[240446]] = E[240447], _p$3[E[240448]] = E[240449], _p$3[E[240450]] = E[240451], _p$3[E[240452]] = E[240453], _p$3[E[240454]] = '1', _p$3[E[240262]] = '', _p$3[E[240455]] = '', _p$3[E[240456]] = 0x0, _p$3[E[240299]] = {}, _p$3[E[240457]] = parseInt(_p$3[E[240454]]), _p$3[E[240458]] = _p$3[E[240454]], _p$3[E[240149]] = {}, _p$3['_pF$'] = E[240459], _p$3[E[240460]] = ![], _p$3[E[240461]] = E[240462], _p$3[E[240463]] = Date[E[240144]](), _p$3[E[240464]] = E[240465], _p$3[E[240466]] = '_a', _p$3[E[240193]] = 0x2, _p$3[E[240206]] = 0x7c1, _p$3[E[240208]] = window[E[240433]][E[240208]], _p$3[E[240467]] = ![], _p$3[E[240468]] = ![], _p$3[E[240469]] = ![], _p$3[E[240470]] = ![], window['_p23$'] = 0x5, window['_p23'] = ![], window['_p32'] = ![], window['_p$23'] = ![], window[E[240379]] = ![], window[E[240382]] = ![], window['_p$32'] = ![], window['_p2$'] = ![], window['_p$2'] = ![], window['_p32$'] = ![], window[E[240471]] = function ($6j1i) {
  console[E[240306]](E[240471], $6j1i), wx[E[240472]]({}), wx[E[240473]]({ 'title': E[240474], 'content': $6j1i, 'success'(iy6kj) {
      if (iy6kj[E[240475]]) console[E[240306]](E[240476]);else iy6kj[E[240477]] && console[E[240306]](E[240478]);
    } });
}, window['_pF2$3'] = function (qb8ea) {
  console[E[240306]](E[240479], qb8ea), _pF$32(), wx[E[240473]]({ 'title': E[240474], 'content': qb8ea, 'confirmText': E[240480], 'cancelText': E[240481], 'success'(stp4xl) {
      if (stp4xl[E[240475]]) window['_p$F']();else stp4xl[E[240477]] && (console[E[240306]](E[240482]), wx[E[240483]]({}));
    } });
}, window[E[240484]] = function (wn05z3) {
  console[E[240306]](E[240484], wn05z3), wx[E[240473]]({ 'title': E[240474], 'content': wn05z3, 'confirmText': E[240485], 'showCancel': ![], 'complete'(kph4s) {
      console[E[240306]](E[240482]), wx[E[240483]]({});
    } });
}, window['_pF23$'] = ![], window['_pF$23'] = function (j61iy) {
  window['_pF23$'] = !![], wx[E[240486]](j61iy);
}, window['_pF$32'] = function () {
  window['_pF23$'] && (window['_pF23$'] = ![], wx[E[240472]]({}));
}, window['_pF32$'] = function (v2701) {
  window[E[240432]][E[240145]]['_pF32$'](v2701);
}, window[E[240487]] = function (_mfxuo, b8ne9q) {
  p_isjyh[E[240487]](_mfxuo, function ($y7v) {
    $y7v && $y7v[E[240310]] ? $y7v[E[240310]][E[240309]] == 0x1 ? b8ne9q(!![]) : (b8ne9q(![]), console[E[240488]](E[240489] + $y7v[E[240310]][E[240490]])) : console[E[240306]](E[240487], $y7v);
  });
}, window['_pF3$2'] = function (z0v27) {
  console[E[240306]](E[240491], z0v27);
}, window['_pF$3'] = function (oxu_m) {}, window['_pF3$'] = function (z5e3nw, tx4lup, ksh4jp) {}, window['_pF3'] = function (y7$) {
  console[E[240306]](E[240492], y7$), window[E[240432]][E[240145]][E[240197]](), window[E[240432]][E[240145]][E[240198]](), window[E[240432]][E[240145]][E[240212]]();
}, window['_p3F'] = function (cdqba) {
  window['_pF2$3'](E[240493]);var ulpx4t = { 'id': window['_p$3'][E[240494]], 'role': window['_p$3'][E[240495]], 'level': window['_p$3'][E[240496]], 'account': window['_p$3'][E[240497]], 'version': window['_p$3'][E[240206]], 'cdn': window['_p$3'][E[240292]], 'pkgName': window['_p$3'][E[240262]], 'gamever': window[E[240434]][E[240435]], 'serverid': window['_p$3'][E[240149]] ? window['_p$3'][E[240149]][E[240150]] : 0x0, 'systemInfo': window[E[240498]], 'error': E[240499], 'stack': cdqba ? cdqba : E[240493] },
      wn9e5 = JSON[E[240399]](ulpx4t);console[E[240401]](E[240500] + wn9e5), window['_pF$'](wn9e5);
}, window['_p$F3'] = function (ew593) {
  var cqbdg = JSON[E[240501]](ew593);cqbdg[E[240502]] = window[E[240434]][E[240435]], cqbdg[E[240503]] = window['_p$3'][E[240149]] ? window['_p$3'][E[240149]][E[240150]] : 0x0, cqbdg[E[240498]] = window[E[240498]];var $i6yk = JSON[E[240399]](cqbdg);console[E[240401]](E[240504] + $i6yk), window['_pF$']($i6yk);
}, window['_p$3F'] = function (lt4sph, yv6i1$) {
  var x4lpt = { 'id': window['_p$3'][E[240494]], 'role': window['_p$3'][E[240495]], 'level': window['_p$3'][E[240496]], 'account': window['_p$3'][E[240497]], 'version': window['_p$3'][E[240206]], 'cdn': window['_p$3'][E[240292]], 'pkgName': window['_p$3'][E[240262]], 'gamever': window[E[240434]][E[240435]], 'serverid': window['_p$3'][E[240149]] ? window['_p$3'][E[240149]][E[240150]] : 0x0, 'systemInfo': window[E[240498]], 'error': lt4sph, 'stack': yv6i1$ },
      y716v = JSON[E[240399]](x4lpt);console[E[240418]](E[240505] + y716v), window['_pF$'](y716v);
}, window['_pF$'] = function (ltx4p) {
  if (window['_p$3'][E[240506]] == E[240507]) return;var u_fmxo = _p$3['_pF$'] + E[240508] + _p$3[E[240497]];wx[E[240509]]({ 'url': u_fmxo, 'method': E[240510], 'data': ltx4p, 'header': { 'content-type': E[240511], 'cache-control': E[240512] }, 'success': function (y6i$kj) {
      DEBUG && console[E[240306]](E[240513], u_fmxo, ltx4p, y6i$kj);
    }, 'fail': function (r216v) {
      DEBUG && console[E[240306]](E[240513], u_fmxo, ltx4p, r216v);
    }, 'complete': function () {} });
}, window[E[240514]] = function () {
  function hyski() {
    return ((0x1 + Math[E[240200]]()) * 0x10000 | 0x0)[E[240515]](0x10)[E[240516]](0x1);
  }return hyski() + hyski() + '-' + hyski() + '-' + hyski() + '-' + hyski() + '+' + hyski() + hyski() + hyski();
}, window['_p$F'] = function () {
  console[E[240306]](E[240517]);var yhj$ki = p_isjyh[E[240518]]();_p$3[E[240458]] = yhj$ki[E[240519]], _p$3[E[240457]] = yhj$ki[E[240519]], _p$3[E[240454]] = yhj$ki[E[240519]], _p$3[E[240262]] = yhj$ki['game_pkg'];var wz0n35 = { 'game_ver': _p$3[E[240442]] };_p$3[E[240455]] = this[E[240514]](), _pF$23({ 'title': E[240520] }), p_isjyh[E[240344]](wz0n35, this['_p3F$'][E[240204]](this));
}, window['_p3F$'] = function (qbgda) {
  var n8e9q = qbgda[E[240521]];console[E[240306]](E[240522] + n8e9q + E[240523] + (n8e9q == 0x1) + E[240524] + qbgda[E[240435]] + E[240525] + window[E[240433]][E[240208]]);if (!qbgda[E[240435]] || window['_pX23F$'](window[E[240433]][E[240208]], qbgda[E[240435]]) < 0x0) console[E[240306]](E[240526]), _p$3[E[240446]] = E[240527], _p$3[E[240448]] = E[240528], _p$3[E[240450]] = E[240529], _p$3[E[240292]] = E[240530], _p$3[E[240531]] = E[240532], _p$3[E[240533]] = E[240534], _p$3[E[240467]] = ![];else window['_pX23F$'](window[E[240433]][E[240208]], qbgda[E[240435]]) == 0x0 ? (console[E[240306]](E[240535]), _p$3[E[240446]] = E[240447], _p$3[E[240448]] = E[240449], _p$3[E[240450]] = E[240451], _p$3[E[240292]] = E[240536], _p$3[E[240531]] = E[240532], _p$3[E[240533]] = E[240537], _p$3[E[240467]] = !![]) : (console[E[240306]](E[240538]), _p$3[E[240446]] = E[240447], _p$3[E[240448]] = E[240449], _p$3[E[240450]] = E[240451], _p$3[E[240292]] = E[240536], _p$3[E[240531]] = E[240532], _p$3[E[240533]] = E[240537], _p$3[E[240467]] = ![]);_p$3[E[240456]] = config[E[240539]] ? config[E[240539]] : 0x0, this['_p2$F3'](), this['_p2$3F'](), window[E[240540]] = 0x5, _pF$23({ 'title': E[240541] }), p_isjyh[E[240542]](this['_p3$F'][E[240204]](this));
}, window[E[240540]] = 0x5, window['_p3$F'] = function ($6kyji, abq9e) {
  if ($6kyji == 0x0 && abq9e && abq9e[E[240543]]) {
    _p$3[E[240544]] = abq9e[E[240543]];var tupx4 = this;_pF$23({ 'title': E[240545] }), sendApi(_p$3[E[240446]], E[240546], { 'platform': _p$3[E[240444]], 'partner_id': _p$3[E[240454]], 'token': abq9e[E[240543]], 'game_pkg': _p$3[E[240262]], 'deviceId': _p$3[E[240455]], 'scene': E[240547] + _p$3[E[240456]] }, this['_p2F$3'][E[240204]](this), _p23$, _p3F);
  } else abq9e && abq9e[E[240548]] && window[E[240540]] > 0x0 && (abq9e[E[240548]][E[240421]](E[240549]) != -0x1 || abq9e[E[240548]][E[240421]](E[240550]) != -0x1 || abq9e[E[240548]][E[240421]](E[240551]) != -0x1 || abq9e[E[240548]][E[240421]](E[240552]) != -0x1 || abq9e[E[240548]][E[240421]](E[240553]) != -0x1 || abq9e[E[240548]][E[240421]](E[240554]) != -0x1) ? (window[E[240540]]--, p_isjyh[E[240542]](this['_p3$F'][E[240204]](this))) : (window['_p$3F'](E[240555], JSON[E[240399]]({ 'status': $6kyji, 'data': abq9e })), window['_pF2$3'](E[240556] + (abq9e && abq9e[E[240548]] ? '，' + abq9e[E[240548]] : '')));
}, window['_p2F$3'] = function (z3072r) {
  if (!z3072r) {
    window['_p$3F'](E[240557], E[240558]), window['_pF2$3'](E[240559]);return;
  }if (z3072r[E[240309]] != E[240308]) {
    window['_p$3F'](E[240557], JSON[E[240399]](z3072r)), window['_pF2$3'](E[240560] + z3072r[E[240309]]);return;
  }_p$3[E[240561]] = String(z3072r[E[240497]]), _p$3[E[240497]] = String(z3072r[E[240497]]), _p$3[E[240562]] = String(z3072r[E[240562]]), _p$3[E[240458]] = String(z3072r[E[240562]]), _p$3[E[240563]] = String(z3072r[E[240563]]), _p$3[E[240564]] = String(z3072r[E[240565]]), _p$3[E[240566]] = String(z3072r[E[240567]]), _p$3[E[240565]] = '';var hst = this;_pF$23({ 'title': E[240568] }), sendApi(_p$3[E[240446]], E[240569], { 'partner_id': _p$3[E[240454]], 'uid': _p$3[E[240497]], 'version': _p$3[E[240442]], 'game_pkg': _p$3[E[240262]], 'device': _p$3[E[240455]] }, hst['_p2F3$'][E[240204]](hst), _p23$, _p3F);
}, window['_p2F3$'] = function (tfu_xl) {
  if (!tfu_xl) {
    window['_pF2$3'](E[240570]);return;
  }if (tfu_xl[E[240309]] != E[240308]) {
    window['_pF2$3'](E[240571] + tfu_xl[E[240309]]);return;
  }if (!tfu_xl[E[240310]] || tfu_xl[E[240310]][E[240178]] == 0x0) {
    window['_pF2$3'](E[240572]);return;
  }_p$3[E[240388]] = tfu_xl[E[240573]], _p$3[E[240149]] = { 'server_id': String(tfu_xl[E[240310]][0x0][E[240150]]), 'server_name': String(tfu_xl[E[240310]][0x0][E[240286]]), 'entry_ip': tfu_xl[E[240310]][0x0][E[240574]], 'entry_port': parseInt(tfu_xl[E[240310]][0x0]['entry_port']), 'status': _p$2F(tfu_xl[E[240310]][0x0]), 'start_time': tfu_xl[E[240310]][0x0][E[240575]], 'cdn': _p$3[E[240292]] }, this['_p3$2F']();
}, window['_p3$2F'] = function () {
  if (_p$3[E[240388]] == 0x1) {
    var enb9q8 = _p$3[E[240149]][E[240285]];if (enb9q8 === -0x1 || enb9q8 === 0x0) {
      window['_pF2$3'](enb9q8 === -0x1 ? E[240576] : E[240577]);return;
    }_p3F2$(0x0, _p$3[E[240149]][E[240150]]), window[E[240432]][E[240145]][E[240383]](_p$3[E[240388]]);
  } else window[E[240432]][E[240145]][E[240380]](), _pF$32();window['_p$2'] = !![], window['_p32$F'](), window['_p3$F2']();
}, window['_p2$F3'] = function () {
  sendApi(_p$3[E[240446]], E[240578], { 'game_pkg': _p$3[E[240262]], 'version_name': _p$3[E[240533]] }, this[E[240579]][E[240204]](this), _p23$, _p3F);
}, window[E[240579]] = function (jihys) {
  if (!jihys) {
    window['_pF2$3'](E[240580]);return;
  }if (jihys[E[240309]] != E[240308]) {
    window['_pF2$3'](E[240581] + jihys[E[240309]]);return;
  }if (!jihys[E[240310]] || !jihys[E[240310]][E[240442]]) {
    window['_pF2$3'](E[240582] + (jihys[E[240310]] && jihys[E[240310]][E[240442]]));return;
  }jihys[E[240310]][E[240583]] && jihys[E[240310]][E[240583]][E[240178]] > 0xa && (_p$3[E[240584]] = jihys[E[240310]][E[240583]], _p$3[E[240292]] = jihys[E[240310]][E[240583]]), jihys[E[240310]][E[240442]] && (_p$3[E[240206]] = jihys[E[240310]][E[240442]]), console[E[240488]](E[240585] + _p$3[E[240206]] + E[240586] + _p$3[E[240533]]), window['_p$32'] = !![], window['_p32$F'](), window['_p3$F2']();
}, window[E[240587]], window['_p2$3F'] = function () {
  sendApi(_p$3[E[240446]], 'Common.get_option_pkg', { 'game_pkg': _p$3[E[240262]] }, this['_p23F$'][E[240204]](this), _p23$, _p3F);
}, window['_p23F$'] = function (en53w9) {
  if (en53w9[E[240309]] === E[240308] && en53w9[E[240310]]) {
    window[E[240587]] = en53w9[E[240310]];for (var ofm_xu in en53w9[E[240310]]) {
      _p$3[ofm_xu] = en53w9[E[240310]][ofm_xu];
    }
  } else console[E[240488]](E[240588] + en53w9[E[240309]]);window['_p2$'] = !![], window['_p3$F2']();
}, window[E[240589]] = function ($iy6v1, ijy16$, acqg8b, xuflpt, ji6k$, i4hsk, pxutf, lp4sth, y$j6k) {
  ji6k$ = String(ji6k$);var foum_ = pxutf,
      v0r271 = lp4sth;_p$3[E[240440]][ji6k$] = { 'productid': ji6k$, 'productname': foum_, 'productdesc': v0r271, 'roleid': $iy6v1, 'rolename': ijy16$, 'rolelevel': acqg8b, 'price': i4hsk, 'callback': y$j6k }, sendApi(_p$3[E[240450]], E[240590], { 'game_pkg': _p$3[E[240262]], 'server_id': _p$3[E[240149]][E[240150]], 'server_name': _p$3[E[240149]][E[240286]], 'level': acqg8b, 'uid': _p$3[E[240497]], 'role_id': $iy6v1, 'role_name': ijy16$, 'product_id': ji6k$, 'product_name': foum_, 'product_desc': v0r271, 'money': i4hsk, 'partner_id': _p$3[E[240454]] }, toPayCallBack, _p23$, _p3F);
}, window[E[240591]] = function (zr30) {
  if (zr30) {
    if (zr30[E[240592]] === 0xc8 || zr30[E[240309]] == E[240308]) {
      var yj6i$1 = _p$3[E[240440]][String(zr30[E[240593]])];if (yj6i$1[E[240594]]) yj6i$1[E[240594]](zr30[E[240593]], zr30[E[240595]], -0x1);p_isjyh[E[240596]]({ 'cpbill': zr30[E[240595]], 'productid': zr30[E[240593]], 'productname': yj6i$1[E[240597]], 'productdesc': yj6i$1[E[240598]], 'serverid': _p$3[E[240149]][E[240150]], 'servername': _p$3[E[240149]][E[240286]], 'roleid': yj6i$1[E[240599]], 'rolename': yj6i$1[E[240600]], 'rolelevel': yj6i$1[E[240601]], 'price': yj6i$1[E[240602]], 'extension': JSON[E[240399]]({ 'cp_order_id': zr30[E[240595]] }) }, function (cdgaqb, bqcg) {
        yj6i$1[E[240594]] && cdgaqb == 0x0 && yj6i$1[E[240594]](zr30[E[240593]], zr30[E[240595]], cdgaqb);console[E[240488]](JSON[E[240399]]({ 'type': E[240603], 'status': cdgaqb, 'data': zr30, 'role_name': yj6i$1[E[240600]] }));if (cdgaqb === 0x0) {} else {
          if (cdgaqb === 0x1) {} else {
            if (cdgaqb === 0x2) {}
          }
        }
      });
    } else alert(zr30[E[240488]]);
  }
}, window['_p23$F'] = function () {}, window['_pF23'] = function (tfux_l, fuomx, kshi, syjki, jski) {
  p_isjyh[E[240604]](_p$3[E[240149]][E[240150]], _p$3[E[240149]][E[240286]] || _p$3[E[240149]][E[240150]], tfux_l, fuomx, kshi), sendApi(_p$3[E[240446]], E[240605], { 'game_pkg': _p$3[E[240262]], 'server_id': _p$3[E[240149]][E[240150]], 'role_id': tfux_l, 'uid': _p$3[E[240497]], 'role_name': fuomx, 'role_type': syjki, 'level': kshi });
}, window['_pF32'] = function (fmt_x, w203, $7yv6, $j1yi, txf_mu, $y1, ftuxp, v$y1, y6vi, xfut_m) {
  _p$3[E[240494]] = fmt_x, _p$3[E[240495]] = w203, _p$3[E[240496]] = $7yv6, p_isjyh[E[240606]](_p$3[E[240149]][E[240150]], _p$3[E[240149]][E[240286]] || _p$3[E[240149]][E[240150]], fmt_x, w203, $7yv6), sendApi(_p$3[E[240446]], E[240607], { 'game_pkg': _p$3[E[240262]], 'server_id': _p$3[E[240149]][E[240150]], 'role_id': fmt_x, 'uid': _p$3[E[240497]], 'role_name': w203, 'role_type': $j1yi, 'level': $7yv6, 'evolution': txf_mu });
}, window['_p2F3'] = function (utflxp, q98e5, pl4hst, k4lshp, uxfmt, sx4ltp, $yijhk, um_xf, v$i, fxtul) {
  _p$3[E[240494]] = utflxp, _p$3[E[240495]] = q98e5, _p$3[E[240496]] = pl4hst, p_isjyh[E[240608]](_p$3[E[240149]][E[240150]], _p$3[E[240149]][E[240286]] || _p$3[E[240149]][E[240150]], utflxp, q98e5, pl4hst), sendApi(_p$3[E[240446]], E[240607], { 'game_pkg': _p$3[E[240262]], 'server_id': _p$3[E[240149]][E[240150]], 'role_id': utflxp, 'uid': _p$3[E[240497]], 'role_name': q98e5, 'role_type': k4lshp, 'level': pl4hst, 'evolution': uxfmt });
}, window['_p23F'] = function (a98gbq) {}, window['_pF2'] = function (fputlx) {
  p_isjyh[E[240609]](E[240609], function (i$1y6) {
    fputlx && fputlx(i$1y6);
  });
}, window[E[240610]] = function () {
  p_isjyh[E[240610]]();
}, window[E[240611]] = function () {
  p_isjyh[E[240612]]();
}, window[E[240613]] = function (hstp) {
  window['_p3F2'] = hstp, window['_p3F2'] && window['_p2F'] && (console[E[240488]](E[240614] + window['_p2F'][E[240615]]), window['_p3F2'](window['_p2F']), window['_p2F'] = null);
}, window['_p32F'] = function (hjisk4, b9e8, ew9n3, _ufmx) {
  window[E[240616]](E[240617], { 'game_pkg': window['_p$3'][E[240262]], 'role_id': b9e8, 'server_id': ew9n3 }, _ufmx);
}, window['_p$F23'] = function (hk$iy, dbqacg) {
  function ls4xp(ft_mu) {
    var _uxtm = [],
        hklp4 = [],
        xtfl_ = window[E[240434]][E[240618]];for (var $i61y in xtfl_) {
      var upt = Number($i61y);(!hk$iy || !hk$iy[E[240178]] || hk$iy[E[240421]](upt) != -0x1) && (hklp4[E[240314]](xtfl_[$i61y]), _uxtm[E[240314]]([upt, 0x3]));
    }window['_pX23F$'](window[E[240619]], E[240620]) >= 0x0 ? (console[E[240306]](E[240621]), p_isjyh[E[240622]] && p_isjyh[E[240622]](hklp4, function (yi$kj6) {
      console[E[240306]](E[240623]), console[E[240306]](yi$kj6);if (yi$kj6 && yi$kj6[E[240548]] == E[240624]) for (var m_ in xtfl_) {
        if (yi$kj6[xtfl_[m_]] == E[240625]) {
          var $jiky = Number(m_);for (var ltfup = 0x0; ltfup < _uxtm[E[240178]]; ltfup++) {
            if (_uxtm[ltfup][0x0] == $jiky) {
              _uxtm[ltfup][0x1] = 0x1;break;
            }
          }
        }
      }window['_pX23F$'](window[E[240619]], E[240626]) >= 0x0 ? wx[E[240627]]({ 'withSubscriptions': !![], 'success': function (qbga) {
          var ysihkj = qbga[E[240628]][E[240629]];if (ysihkj) {
            console[E[240306]](E[240630]), console[E[240306]](ysihkj);for (var agc8qb in xtfl_) {
              if (ysihkj[xtfl_[agc8qb]] == E[240625]) {
                var n5w8e = Number(agc8qb);for (var yi1$ = 0x0; yi1$ < _uxtm[E[240178]]; yi1$++) {
                  if (_uxtm[yi1$][0x0] == n5w8e) {
                    _uxtm[yi1$][0x1] = 0x2;break;
                  }
                }
              }
            }console[E[240306]](_uxtm), dbqacg && dbqacg(_uxtm);
          } else console[E[240306]](E[240631]), console[E[240306]](qbga), console[E[240306]](_uxtm), dbqacg && dbqacg(_uxtm);
        }, 'fail': function () {
          console[E[240306]](E[240632]), console[E[240306]](_uxtm), dbqacg && dbqacg(_uxtm);
        } }) : (console[E[240306]](E[240633] + window[E[240619]]), console[E[240306]](_uxtm), dbqacg && dbqacg(_uxtm));
    })) : (console[E[240306]](E[240634] + window[E[240619]]), console[E[240306]](_uxtm), dbqacg && dbqacg(_uxtm)), wx[E[240635]](ls4xp);
  }wx[E[240636]](ls4xp);
}, window['_p$F32'] = { 'isSuccess': ![], 'level': E[240637], 'isCharging': ![] }, window['_p$2F3'] = function (q8gb9a) {
  wx[E[240638]]({ 'success': function (wzen5) {
      var tmf = window['_p$F32'];tmf[E[240639]] = !![], tmf[E[240640]] = Number(wzen5[E[240640]])[E[240641]](0x0), tmf[E[240642]] = wzen5[E[240642]], q8gb9a && q8gb9a(tmf[E[240639]], tmf[E[240640]], tmf[E[240642]]);
    }, 'fail': function (lpt4s) {
      console[E[240306]](E[240643], lpt4s[E[240548]]);var y61ij$ = window['_p$F32'];q8gb9a && q8gb9a(y61ij$[E[240639]], y61ij$[E[240640]], y61ij$[E[240642]]);
    } });
}, window[E[240616]] = function (we953, ishyk, gbq8, ufm_o, acbg, isykhj, i$j16y, z203w5) {
  if (ufm_o == undefined) ufm_o = 0x1;wx[E[240509]]({ 'url': we953, 'method': i$j16y || E[240644], 'responseType': E[240202], 'data': ishyk, 'header': { 'content-type': z203w5 || E[240511] }, 'success': function (yki6j) {
      DEBUG && console[E[240306]](E[240645], we953, info, yki6j);if (yki6j && yki6j[E[240646]] == 0xc8) {
        var xp4tlu = yki6j[E[240310]];!isykhj || isykhj(xp4tlu) ? gbq8 && gbq8(xp4tlu) : window[E[240647]](we953, ishyk, gbq8, ufm_o, acbg, isykhj, yki6j);
      } else window[E[240647]](we953, ishyk, gbq8, ufm_o, acbg, isykhj, yki6j);
    }, 'fail': function (ultfx) {
      DEBUG && console[E[240306]](E[240648], we953, info, ultfx), window[E[240647]](we953, ishyk, gbq8, ufm_o, acbg, isykhj, ultfx);
    }, 'complete': function () {} });
}, window[E[240647]] = function (u_lftx, vy61i$, qe98b, i6$ky, bga89q, w25z, jkh$) {
  i6$ky - 0x1 > 0x0 ? setTimeout(function () {
    window[E[240616]](u_lftx, vy61i$, qe98b, i6$ky - 0x1, bga89q, w25z);
  }, 0x3e8) : bga89q && bga89q(JSON[E[240399]]({ 'url': u_lftx, 'response': jkh$ }));
}, window[E[240649]] = function (xfu_mt, u_mft, ij$k6y, z305w2, fxuplt, q85ne, hkpsl) {
  !ij$k6y && (ij$k6y = {});var v217r = Math[E[240402]](Date[E[240144]]() / 0x3e8);ij$k6y[E[240567]] = v217r, ij$k6y[E[240650]] = u_mft;var ph4tl = Object[E[240651]](ij$k6y)[E[240315]](),
      ihskj4 = '',
      gqba = '';for (var ux_fom = 0x0; ux_fom < ph4tl[E[240178]]; ux_fom++) {
    ihskj4 = ihskj4 + (ux_fom == 0x0 ? '' : '&') + ph4tl[ux_fom] + ij$k6y[ph4tl[ux_fom]], gqba = gqba + (ux_fom == 0x0 ? '' : '&') + ph4tl[ux_fom] + '=' + encodeURIComponent(ij$k6y[ph4tl[ux_fom]]);
  }ihskj4 = ihskj4 + _p$3[E[240452]];var ihksjy = E[240652] + md5(ihskj4);send(xfu_mt + '?' + gqba + (gqba == '' ? '' : '&') + ihksjy, null, z305w2, fxuplt, q85ne, hkpsl || function (i1v6$) {
    return i1v6$[E[240309]] == E[240308];
  }, null, E[240653]);
}, window['_p$23F'] = function (jy6k$i, ab9e) {
  var n3we5z = 0x0;_p$3[E[240149]] && (n3we5z = _p$3[E[240149]][E[240150]]), sendApi(_p$3[E[240448]], E[240654], { 'partnerId': _p$3[E[240454]], 'gamePkg': _p$3[E[240262]], 'logTime': Math[E[240402]](Date[E[240144]]() / 0x3e8), 'platformUid': _p$3[E[240563]], 'type': jy6k$i, 'serverId': n3we5z }, null, 0x2, null, function () {
    return !![];
  });
}, window['_p$3F2'] = function (ptlux4) {
  sendApi(_p$3[E[240446]], E[240655], { 'partner_id': _p$3[E[240454]], 'uid': _p$3[E[240497]], 'version': _p$3[E[240442]], 'game_pkg': _p$3[E[240262]], 'device': _p$3[E[240455]] }, _p$32F, _p23$, _p3F);
}, window['_p$32F'] = function (jk$y) {
  if (jk$y[E[240309]] === E[240308] && jk$y[E[240310]]) {
    jk$y[E[240310]][E[240656]]({ 'id': -0x2, 'name': E[240657] }), jk$y[E[240310]][E[240656]]({ 'id': -0x1, 'name': E[240658] }), _p$3[E[240261]] = jk$y[E[240310]];if (window[E[240253]]) window[E[240253]][E[240293]]();
  } else _p$3[E[240268]] = ![], window['_pF2$3'](E[240659] + jk$y[E[240309]]);
}, window['_pF2$'] = function (q59e8) {
  sendApi(_p$3[E[240446]], E[240660], { 'partner_id': _p$3[E[240454]], 'uid': _p$3[E[240497]], 'version': _p$3[E[240442]], 'game_pkg': _p$3[E[240262]], 'device': _p$3[E[240455]] }, _pF$2, _p23$, _p3F);
}, window['_pF$2'] = function ($yj1i) {
  _p$3[E[240301]] = ![];if ($yj1i[E[240309]] === E[240308] && $yj1i[E[240310]]) {
    for (var gqbc8 = 0x0; gqbc8 < $yj1i[E[240310]][E[240178]]; gqbc8++) {
      $yj1i[E[240310]][gqbc8][E[240285]] = _p$2F($yj1i[E[240310]][gqbc8]);
    }_p$3[E[240299]][-0x1] = window[E[240661]]($yj1i[E[240310]]), window[E[240253]][E[240300]](-0x1);
  } else window['_pF2$3'](E[240662] + $yj1i[E[240309]]);
}, window[E[240663]] = function (v71$r) {
  sendApi(_p$3[E[240446]], E[240660], { 'partner_id': _p$3[E[240454]], 'uid': _p$3[E[240497]], 'version': _p$3[E[240442]], 'game_pkg': _p$3[E[240262]], 'device': _p$3[E[240455]] }, v71$r, _p23$, _p3F);
}, window['_p2F$'] = function (abe8, bga89) {
  sendApi(_p$3[E[240446]], E[240664], { 'partner_id': _p$3[E[240454]], 'uid': _p$3[E[240497]], 'version': _p$3[E[240442]], 'game_pkg': _p$3[E[240262]], 'device': _p$3[E[240455]], 'server_group_id': bga89 }, _p2$F, _p23$, _p3F);
}, window['_p2$F'] = function (e5w9n8) {
  _p$3[E[240301]] = ![];if (e5w9n8[E[240309]] === E[240308] && e5w9n8[E[240310]] && e5w9n8[E[240310]][E[240310]]) {
    var xfom_u = e5w9n8[E[240310]][E[240665]],
        lx4stp = [];for (var ykji6 = 0x0; ykji6 < e5w9n8[E[240310]][E[240310]][E[240178]]; ykji6++) {
      e5w9n8[E[240310]][E[240310]][ykji6][E[240285]] = _p$2F(e5w9n8[E[240310]][E[240310]][ykji6]), (lx4stp[E[240178]] == 0x0 || e5w9n8[E[240310]][E[240310]][ykji6][E[240285]] != 0x0) && (lx4stp[lx4stp[E[240178]]] = e5w9n8[E[240310]][E[240310]][ykji6]);
    }_p$3[E[240299]][xfom_u] = window[E[240661]](lx4stp), window[E[240253]][E[240300]](xfom_u);
  } else window['_pF2$3'](E[240666] + e5w9n8[E[240309]]);
}, window['_pX23$'] = function (ijy$k6) {
  sendApi(_p$3[E[240446]], E[240667], { 'partner_id': _p$3[E[240454]], 'uid': _p$3[E[240497]], 'version': _p$3[E[240442]], 'game_pkg': _p$3[E[240262]], 'device': _p$3[E[240455]] }, reqServerRecommendCallBack, _p23$, _p3F);
}, window[E[240668]] = function (rv7612) {
  _p$3[E[240301]] = ![];if (rv7612[E[240309]] === E[240308] && rv7612[E[240310]]) {
    for (var ij$y61 = 0x0; ij$y61 < rv7612[E[240310]][E[240178]]; ij$y61++) {
      rv7612[E[240310]][ij$y61][E[240285]] = _p$2F(rv7612[E[240310]][ij$y61]);
    }_p$3[E[240299]][-0x2] = window[E[240661]](rv7612[E[240310]]), window[E[240253]][E[240300]](-0x2);
  } else alert(E[240669] + rv7612[E[240309]]);
}, window[E[240661]] = function (_fultx) {
  if (!_fultx && _fultx[E[240178]] <= 0x0) return _fultx;for (let e5n9q8 = 0x0; e5n9q8 < _fultx[E[240178]]; e5n9q8++) {
    _fultx[e5n9q8][E[240670]] && _fultx[e5n9q8][E[240670]] == 0x1 && (_fultx[e5n9q8][E[240286]] += E[240671]);
  }return _fultx;
}, window['_p$F2'] = function (sh4ki, iy$1v) {
  sh4ki = sh4ki || _p$3[E[240149]][E[240150]], sendApi(_p$3[E[240446]], E[240672], { 'type': '4', 'game_pkg': _p$3[E[240262]], 'server_id': sh4ki }, iy$1v);
}, window[E[240673]] = function (daqb, qn5e, r612v, fxmo) {
  r612v = r612v || _p$3[E[240149]][E[240150]], sendApi(_p$3[E[240446]], E[240674], { 'type': daqb, 'game_pkg': qn5e, 'server_id': r612v }, fxmo);
}, window['_p$2F'] = function (_oum) {
  if (_oum) {
    if (_oum[E[240285]] == 0x1) {
      if (_oum[E[240675]] == 0x1) return 0x2;else return 0x1;
    } else return _oum[E[240285]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_p3F2$'] = function (qne89b, ihj4k) {
  _p$3[E[240676]] = { 'step': qne89b, 'server_id': ihj4k };var dbqcag = this;_pF$23({ 'title': E[240677] }), sendApi(_p$3[E[240446]], E[240678], { 'partner_id': _p$3[E[240454]], 'uid': _p$3[E[240497]], 'game_pkg': _p$3[E[240262]], 'server_id': ihj4k, 'platform': _p$3[E[240562]], 'platform_uid': _p$3[E[240563]], 'check_login_time': _p$3[E[240566]], 'check_login_sign': _p$3[E[240564]], 'version_name': _p$3[E[240533]] }, _p3F$2, _p23$, _p3F, function (n58we) {
    return n58we[E[240309]] == E[240308] || n58we[E[240488]] == E[240679] || n58we[E[240488]] == E[240680];
  });
}, window['_p3F$2'] = function (utlxf_) {
  var $khyji = this;if (utlxf_[E[240309]] === E[240308] && utlxf_[E[240310]]) {
    var lxtf_ = _p$3[E[240149]];lxtf_[E[240681]] = _p$3[E[240457]], lxtf_[E[240565]] = String(utlxf_[E[240310]][E[240682]]), lxtf_[E[240463]] = parseInt(utlxf_[E[240310]][E[240567]]);if (utlxf_[E[240310]][E[240683]]) lxtf_[E[240683]] = parseInt(utlxf_[E[240310]][E[240683]]);else lxtf_[E[240683]] = parseInt(utlxf_[E[240310]][E[240150]]);lxtf_[E[240684]] = 0x0, lxtf_[E[240292]] = _p$3[E[240584]], lxtf_[E[240685]] = utlxf_[E[240310]][E[240686]], lxtf_[E[240687]] = utlxf_[E[240310]][E[240687]], console[E[240306]](E[240688] + JSON[E[240399]](lxtf_[E[240687]])), _p$3[E[240388]] == 0x1 && lxtf_[E[240687]] && lxtf_[E[240687]][E[240689]] == 0x1 && (_p$3[E[240209]] = 0x1, window[E[240432]][E[240145]]['_pX3$']()), _p32F$();
  } else _p$3[E[240676]][E[240690]] >= 0x3 ? (_p3F(JSON[E[240399]](utlxf_)), window['_pF2$3'](E[240691] + utlxf_[E[240309]])) : sendApi(_p$3[E[240446]], E[240546], { 'platform': _p$3[E[240444]], 'partner_id': _p$3[E[240454]], 'token': _p$3[E[240544]], 'game_pkg': _p$3[E[240262]], 'deviceId': _p$3[E[240455]], 'scene': E[240547] + _p$3[E[240456]] }, function (q98ba) {
    if (!q98ba || q98ba[E[240309]] != E[240308]) {
      window['_pF2$3'](E[240560] + q98ba && q98ba[E[240309]]);return;
    }_p$3[E[240564]] = String(q98ba[E[240565]]), _p$3[E[240566]] = String(q98ba[E[240567]]), setTimeout(function () {
      _p3F2$(_p$3[E[240676]][E[240690]] + 0x1, _p$3[E[240676]][E[240150]]);
    }, 0x5dc);
  }, _p23$, _p3F, function (fuom_) {
    return fuom_[E[240309]] == E[240308] || fuom_[E[240309]] == E[240692];
  });
}, window['_p32F$'] = function () {
  ServerLoading[E[240145]][E[240383]](_p$3[E[240388]]), window['_p23'] = !![], window['_p3$F2']();
}, window['_p32$F'] = function () {
  if (window['_p32'] && window['_p$23'] && window[E[240379]] && window[E[240382]] && window['_p$32'] && window['_p$2']) {
    if (!window[E[240693]][E[240145]]) {
      console[E[240306]](E[240694] + window[E[240693]][E[240145]]);var pkhsj4 = wx[E[240695]](),
          _umxo = pkhsj4[E[240615]] ? pkhsj4[E[240615]] : 0x0,
          f_lxut = { 'cdn': window['_p$3'][E[240292]], 'spareCdn': window['_p$3'][E[240531]], 'newRegister': window['_p$3'][E[240388]], 'wxPC': window['_p$3'][E[240470]], 'wxIOS': window['_p$3'][E[240468]], 'wxAndroid': window['_p$3'][E[240469]], 'wxParam': { 'limitLoad': window['_p$3']['_pXF23$'], 'benchmarkLevel': window['_p$3']['_pXF$23'], 'wxFrom': window[E[240434]][E[240539]] == E[240696] ? 0x1 : 0x0, 'wxSDKVersion': window[E[240619]] }, 'configType': window['_p$3'][E[240464]], 'exposeType': window['_p$3'][E[240466]], 'scene': _umxo };new window[E[240693]](f_lxut, window['_p$3'][E[240206]], window['_pXF2$3']);
    }
  }
}, window['_p3$F2'] = function () {
  if (window['_p32'] && window['_p$23'] && window[E[240379]] && window[E[240382]] && window['_p$32'] && window['_p$2'] && window['_p23'] && window['_p2$']) {
    _pF$32();if (!_p32$) {
      _p32$ = !![];if (!window[E[240693]][E[240145]]) window['_p32$F']();var t4lpsx = 0x0,
          fxtl_ = wx[E[240697]]();fxtl_ && (window['_p$3'][E[240698]] && (t4lpsx = fxtl_[E[240107]]), console[E[240488]](E[240699] + fxtl_[E[240107]] + E[240700] + fxtl_[E[240220]] + E[240701] + fxtl_[E[240702]] + E[240703] + fxtl_[E[240068]] + E[240704] + fxtl_[E[240170]] + E[240705] + fxtl_[E[240172]]));var jh4ki = {};for (const $167vr in _p$3[E[240149]]) {
        jh4ki[$167vr] = _p$3[E[240149]][$167vr];
      }var fm_utx = { 'channel': window['_p$3'][E[240458]], 'account': window['_p$3'][E[240497]], 'userId': window['_p$3'][E[240561]], 'cdn': window['_p$3'][E[240292]], 'data': window['_p$3'][E[240310]], 'package': window['_p$3'][E[240441]], 'newRegister': window['_p$3'][E[240388]], 'pkgName': window['_p$3'][E[240262]], 'partnerId': window['_p$3'][E[240454]], 'platform_uid': window['_p$3'][E[240563]], 'deviceId': window['_p$3'][E[240455]], 'selectedServer': jh4ki, 'configType': window['_p$3'][E[240464]], 'exposeType': window['_p$3'][E[240466]], 'debugUsers': window['_p$3'][E[240461]], 'wxMenuTop': t4lpsx, 'wxShield': window['_p$3'][E[240467]] };if (window[E[240587]]) for (var w0n5z in window[E[240587]]) {
        fm_utx[w0n5z] = window[E[240587]][w0n5z];
      }window[E[240693]][E[240145]]['_p3$X'](fm_utx), setTimeout(() => {
        !_p$3[E[240467]] && new minitool();
      }, 0x2710);
    }
  } else console[E[240488]](E[240706] + window['_p32'] + E[240707] + window['_p$23'] + E[240708] + window[E[240379]] + E[240709] + window[E[240382]] + E[240710] + window['_p$32'] + E[240711] + window['_p$2'] + E[240712] + window['_p23'] + E[240713] + window['_p2$']);
};