var Q = wx.$v;
import vdac from '../vvavvv/v7tvv.js';window[Q[360148]] = { 'wxVersion': window[Q[360006]]['game_ver'] }, window[Q[360149]] = ![], window['_vDK'] = 0x1, window[Q[360150]] = 0x1, window['_v$KD'] = !![], window[Q[360151]] = !![], window['_v6O$KD'] = '', window['_vKD'] = { 'base_cdn': Q[360152], 'cdn': Q[360152] }, _vKD[Q[360153]] = {}, _vKD[Q[360154]] = '0', _vKD[Q[360079]] = window[Q[360148]][Q[360155]], _vKD[Q[360114]] = '', _vKD['os'] = '1', _vKD[Q[360156]] = Q[360157], _vKD[Q[360158]] = Q[360159], _vKD[Q[360160]] = Q[360161], _vKD[Q[360162]] = Q[360163], _vKD[Q[360164]] = Q[360165], _vKD[Q[360166]] = '1', _vKD[Q[360021]] = '', _vKD[Q[360167]] = '', _vKD[Q[360168]] = 0x0, _vKD[Q[360169]] = {}, _vKD[Q[360170]] = parseInt(_vKD[Q[360166]]), _vKD[Q[360171]] = _vKD[Q[360166]], _vKD[Q[360022]] = {}, _vKD['_vOK'] = Q[360172], _vKD[Q[360173]] = ![], _vKD[Q[360174]] = Q[360175], _vKD[Q[360176]] = Date[Q[360141]](), _vKD[Q[360177]] = Q[360178], _vKD[Q[360179]] = '_a', _vKD[Q[360180]] = 0x2, _vKD[Q[360019]] = 0x7c1, _vKD[Q[360155]] = window[Q[360148]][Q[360155]], _vKD[Q[360181]] = ![], _vKD[Q[360106]] = ![], _vKD[Q[360109]] = ![], _vKD[Q[360112]] = ![], window['_v$DK'] = 0x5, window['_v$D'] = ![], window['_vD$'] = ![], window['_vK$D'] = ![], window[Q[360182]] = ![], window[Q[360183]] = ![], window['_vKD$'] = ![], window['_v$K'] = ![], window['_vK$'] = ![], window['_vD$K'] = ![], window[Q[360184]] = function (s34) {
  console[Q[360041]](Q[360184], s34), wx[Q[360185]]({}), wx[Q[360048]]({ 'title': Q[360071], 'content': s34, 'success'(buz86l) {
      if (buz86l[Q[360186]]) console[Q[360041]](Q[360187]);else buz86l[Q[360188]] && console[Q[360041]](Q[360189]);
    } });
}, window['_vO$KD'] = function (pv7g5x) {
  console[Q[360041]](Q[360190], pv7g5x), _vOKD$(), wx[Q[360048]]({ 'title': Q[360071], 'content': pv7g5x, 'confirmText': Q[360191], 'cancelText': Q[360192], 'success'(jkcdm0) {
      if (jkcdm0[Q[360186]]) window['_vKO']();else jkcdm0[Q[360188]] && (console[Q[360041]](Q[360193]), wx[Q[360194]]({}));
    } });
}, window['_vK6'] = function (p75gvx) {
  console[Q[360041]](Q[360195], p75gvx), wx[Q[360048]]({ 'title': Q[360071], 'content': p75gvx, 'confirmText': Q[360196], 'showCancel': ![], 'complete'(c5km70) {
      console[Q[360041]](Q[360193]), wx[Q[360194]]({});
    } });
}, window['_vO$DK'] = ![], window['_vOK$D'] = function (qwebg) {
  window['_vO$DK'] = !![], wx[Q[360197]](qwebg);
}, window['_vOKD$'] = function () {
  window['_vO$DK'] && (window['_vO$DK'] = ![], wx[Q[360185]]({}));
}, window['_vOD$K'] = function (cja0d) {
  window[Q[360034]][Q[360035]]['_vOD$K'](cja0d);
}, window[Q[360198]] = function (qwgxeb, if$s4o) {
  vdac[Q[360198]](qwgxeb, function (_324t) {
    _324t && _324t[Q[360199]] ? _324t[Q[360199]][Q[360200]] == 0x1 ? if$s4o(!![]) : (if$s4o(![]), console[Q[360001]](Q[360201] + _324t[Q[360199]][Q[360202]])) : console[Q[360041]](Q[360198], _324t);
  });
}, window['_vODK$'] = function (pvqgw) {
  console[Q[360041]](Q[360203], pvqgw);
}, window['_vOKD'] = function (u8yl) {}, window['_vODK'] = function (xwqgv, el8uzb, z16yh) {}, window['_vOD'] = function (v7xg5) {
  console[Q[360041]](Q[360204], v7xg5), window[Q[360034]][Q[360035]][Q[360205]](), window[Q[360034]][Q[360035]][Q[360206]](), window[Q[360034]][Q[360035]][Q[360207]]();
}, window['_vDO'] = function (v7gx5p) {
  window['_vO$KD'](Q[360208]);var _t21y = { 'id': window['_vKD'][Q[360015]], 'role': window['_vKD'][Q[360016]], 'level': window['_vKD'][Q[360017]], 'account': window['_vKD'][Q[360018]], 'version': window['_vKD'][Q[360019]], 'cdn': window['_vKD'][Q[360020]], 'pkgName': window['_vKD'][Q[360021]], 'gamever': window[Q[360006]]['game_ver'], 'serverid': window['_vKD'][Q[360022]] ? window['_vKD'][Q[360022]][Q[360023]] : 0x0, 'systemInfo': window[Q[360024]], 'error': Q[360209], 'stack': v7gx5p ? v7gx5p : Q[360208] },
      mc570k = JSON[Q[360026]](_t21y);console[Q[360027]](Q[360210] + mc570k), window['_vOK'](mc570k);
}, window['_vKOD'] = function (p0k5) {
  var y_th12 = JSON[Q[360211]](p0k5);y_th12[Q[360212]] = window[Q[360006]]['game_ver'], y_th12[Q[360213]] = window['_vKD'][Q[360022]] ? window['_vKD'][Q[360022]][Q[360023]] : 0x0, y_th12[Q[360024]] = window[Q[360024]];var hy6zlu = JSON[Q[360026]](y_th12);console[Q[360027]](Q[360214] + hy6zlu), window['_vOK'](hy6zlu);
}, window['_vKDO'] = function (xk7vp, qe8wbg) {
  var eb8uql = { 'id': window['_vKD'][Q[360015]], 'role': window['_vKD'][Q[360016]], 'level': window['_vKD'][Q[360017]], 'account': window['_vKD'][Q[360018]], 'version': window['_vKD'][Q[360019]], 'cdn': window['_vKD'][Q[360020]], 'pkgName': window['_vKD'][Q[360021]], 'gamever': window[Q[360006]]['game_ver'], 'serverid': window['_vKD'][Q[360022]] ? window['_vKD'][Q[360022]][Q[360023]] : 0x0, 'systemInfo': window[Q[360024]], 'error': xk7vp, 'stack': qe8wbg },
      hn1t2 = JSON[Q[360026]](eb8uql);console[Q[360142]](Q[360215] + hn1t2), window['_vOK'](hn1t2);
}, window['_vOK'] = function (ebz8ul) {
  if (window['_vKD'][Q[360115]] == Q[360216]) return;var w5gxv = _vKD['_vOK'] + Q[360217] + _vKD[Q[360018]];wx[Q[360218]]({ 'url': w5gxv, 'method': Q[360219], 'data': ebz8ul, 'header': { 'content-type': Q[360220], 'cache-control': Q[360221] }, 'success': function (wgp5) {
      DEBUG && console[Q[360041]](Q[360222], w5gxv, ebz8ul, wgp5);
    }, 'fail': function (uzlbe8) {
      DEBUG && console[Q[360041]](Q[360222], w5gxv, ebz8ul, uzlbe8);
    }, 'complete': function () {} });
}, window[Q[360223]] = function () {
  function m0kd7c() {
    return ((0x1 + Math[Q[360224]]()) * 0x10000 | 0x0)[Q[360225]](0x10)[Q[360226]](0x1);
  }return m0kd7c() + m0kd7c() + '-' + m0kd7c() + '-' + m0kd7c() + '-' + m0kd7c() + '+' + m0kd7c() + m0kd7c() + m0kd7c();
}, window['_vKO'] = function () {
  console[Q[360041]](Q[360227]);var z6yhl1 = vdac[Q[360228]]();_vKD[Q[360171]] = z6yhl1[Q[360229]], _vKD[Q[360170]] = z6yhl1[Q[360229]], _vKD[Q[360166]] = z6yhl1[Q[360229]], _vKD[Q[360021]] = z6yhl1[Q[360230]];var sof$i4 = { 'game_ver': _vKD[Q[360079]] };_vKD[Q[360167]] = this[Q[360223]](), _vOK$D({ 'title': Q[360231] }), vdac[Q[360232]](sof$i4, this['_vDOK'][Q[360233]](this));
}, window['_vDOK'] = function (pv5k7) {
  var leqb = pv5k7[Q[360234]];console[Q[360041]](Q[360235] + leqb + Q[360236] + (leqb == 0x1) + Q[360237] + pv5k7['game_ver'] + Q[360238] + window[Q[360148]][Q[360155]]);if (!pv5k7['game_ver'] || window['_v6$DOK'](window[Q[360148]][Q[360155]], pv5k7['game_ver']) < 0x0) console[Q[360041]](Q[360239]), _vKD[Q[360158]] = Q[360240], _vKD[Q[360160]] = Q[360241], _vKD[Q[360162]] = Q[360242], _vKD[Q[360020]] = Q[360243], _vKD[Q[360244]] = Q[360245], _vKD[Q[360246]] = 'qy', _vKD[Q[360181]] = ![];else window['_v6$DOK'](window[Q[360148]][Q[360155]], pv5k7['game_ver']) == 0x0 ? (console[Q[360041]](Q[360247]), _vKD[Q[360158]] = Q[360159], _vKD[Q[360160]] = Q[360161], _vKD[Q[360162]] = Q[360163], _vKD[Q[360020]] = Q[360248], _vKD[Q[360244]] = Q[360245], _vKD[Q[360246]] = Q[360249], _vKD[Q[360181]] = !![]) : (console[Q[360041]](Q[360250]), _vKD[Q[360158]] = Q[360159], _vKD[Q[360160]] = Q[360161], _vKD[Q[360162]] = Q[360163], _vKD[Q[360020]] = Q[360248], _vKD[Q[360244]] = Q[360245], _vKD[Q[360246]] = Q[360249], _vKD[Q[360181]] = ![]);_vKD[Q[360168]] = config[Q[360251]] ? config[Q[360251]] : 0x0, this['_v$KOD'](), this['_v$KDO'](), window[Q[360252]] = 0x5, _vOK$D({ 'title': Q[360253] }), vdac[Q[360254]](this['_vDKO'][Q[360233]](this));
}, window[Q[360252]] = 0x5, window['_vDKO'] = function (vwp5gx, o3s4) {
  if (vwp5gx == 0x0 && o3s4 && o3s4[Q[360255]]) {
    _vKD[Q[360256]] = o3s4[Q[360255]];var rfi9$s = this;_vOK$D({ 'title': Q[360257] }), sendApi(_vKD[Q[360158]], Q[360258], { 'platform': _vKD[Q[360156]], 'partner_id': _vKD[Q[360166]], 'token': o3s4[Q[360255]], 'game_pkg': _vKD[Q[360021]], 'deviceId': _vKD[Q[360167]], 'scene': Q[360259] + _vKD[Q[360168]] }, this['_v$OKD'][Q[360233]](this), _v$DK, _vDO);
  } else o3s4 && o3s4[Q[360058]] && window[Q[360252]] > 0x0 && (o3s4[Q[360058]][Q[360107]](Q[360260]) != -0x1 || o3s4[Q[360058]][Q[360107]](Q[360261]) != -0x1 || o3s4[Q[360058]][Q[360107]](Q[360262]) != -0x1 || o3s4[Q[360058]][Q[360107]](Q[360263]) != -0x1 || o3s4[Q[360058]][Q[360107]](Q[360264]) != -0x1 || o3s4[Q[360058]][Q[360107]](Q[360265]) != -0x1) ? (window[Q[360252]]--, vdac[Q[360254]](this['_vDKO'][Q[360233]](this))) : (window['_vKDO'](Q[360266], JSON[Q[360026]]({ 'status': vwp5gx, 'data': o3s4 })), window['_vO$KD'](Q[360267] + (o3s4 && o3s4[Q[360058]] ? '，' + o3s4[Q[360058]] : '')));
}, window['_v$OKD'] = function (cd70m) {
  if (!cd70m) {
    window['_vKDO'](Q[360268], Q[360269]), window['_vO$KD'](Q[360270]);return;
  }if (cd70m[Q[360200]] != Q[360271]) {
    window['_vKDO'](Q[360268], JSON[Q[360026]](cd70m)), window['_vO$KD'](Q[360272] + cd70m[Q[360200]]);return;
  }_vKD[Q[360273]] = String(cd70m[Q[360018]]), _vKD[Q[360018]] = String(cd70m[Q[360018]]), _vKD[Q[360083]] = String(cd70m[Q[360083]]), _vKD[Q[360171]] = String(cd70m[Q[360083]]), _vKD[Q[360274]] = String(cd70m[Q[360274]]), _vKD[Q[360275]] = String(cd70m[Q[360276]]), _vKD[Q[360277]] = String(cd70m[Q[360278]]), _vKD[Q[360276]] = '';var kd7cm = this;_vOK$D({ 'title': Q[360279] }), sendApi(_vKD[Q[360158]], Q[360280], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, kd7cm['_v$ODK'][Q[360233]](kd7cm), _v$DK, _vDO);
}, window['_v$ODK'] = function (ylu68z) {
  if (!ylu68z) {
    window['_vO$KD'](Q[360281]);return;
  }if (ylu68z[Q[360200]] != Q[360271]) {
    window['_vO$KD'](Q[360282] + ylu68z[Q[360200]]);return;
  }if (!ylu68z[Q[360199]] || ylu68z[Q[360199]][Q[360009]] == 0x0) {
    window['_vO$KD'](Q[360283]);return;
  }_vKD[Q[360284]] = ylu68z[Q[360285]], _vKD[Q[360022]] = { 'server_id': String(ylu68z[Q[360199]][0x0][Q[360023]]), 'server_name': String(ylu68z[Q[360199]][0x0][Q[360286]]), 'entry_ip': ylu68z[Q[360199]][0x0][Q[360287]], 'entry_port': parseInt(ylu68z[Q[360199]][0x0][Q[360288]]), 'status': _vK$O(ylu68z[Q[360199]][0x0]), 'start_time': ylu68z[Q[360199]][0x0][Q[360289]], 'cdn': _vKD[Q[360020]] }, this['_vDK$O']();
}, window['_vDK$O'] = function () {
  if (_vKD[Q[360284]] == 0x1) {
    var cjm0d = _vKD[Q[360022]][Q[360290]];if (cjm0d === -0x1 || cjm0d === 0x0) {
      window['_vO$KD'](cjm0d === -0x1 ? Q[360291] : Q[360292]);return;
    }_vDO$K(0x0, _vKD[Q[360022]][Q[360023]]), window[Q[360034]][Q[360035]][Q[360293]](_vKD[Q[360284]]);
  } else window[Q[360034]][Q[360035]][Q[360294]](), _vOKD$();window['_vK$'] = !![], window['_vD$KO'](), window['_vDKO$']();
}, window['_v$KOD'] = function () {
  sendApi(_vKD[Q[360158]], Q[360295], { 'game_pkg': _vKD[Q[360021]], 'version_name': _vKD[Q[360246]] }, this[Q[360296]][Q[360233]](this), _v$DK, _vDO);
}, window[Q[360296]] = function (t32n1_) {
  if (!t32n1_) {
    window['_vO$KD'](Q[360297]);return;
  }if (t32n1_[Q[360200]] != Q[360271]) {
    window['_vO$KD'](Q[360298] + t32n1_[Q[360200]]);return;
  }if (!t32n1_[Q[360199]] || !t32n1_[Q[360199]][Q[360079]]) {
    window['_vO$KD'](Q[360299] + (t32n1_[Q[360199]] && t32n1_[Q[360199]][Q[360079]]));return;
  }t32n1_[Q[360199]][Q[360300]] && t32n1_[Q[360199]][Q[360300]][Q[360009]] > 0xa && (_vKD[Q[360301]] = t32n1_[Q[360199]][Q[360300]], _vKD[Q[360020]] = t32n1_[Q[360199]][Q[360300]]), t32n1_[Q[360199]][Q[360079]] && (_vKD[Q[360019]] = t32n1_[Q[360199]][Q[360079]]), console[Q[360001]](Q[360302] + _vKD[Q[360019]] + Q[360303] + _vKD[Q[360246]]), window['_vKD$'] = !![], window['_vD$KO'](), window['_vDKO$']();
}, window[Q[360304]], window['_v$KDO'] = function () {
  sendApi(_vKD[Q[360158]], Q[360305], { 'game_pkg': _vKD[Q[360021]] }, this['_v$DOK'][Q[360233]](this), _v$DK, _vDO);
}, window['_v$DOK'] = function (ube8) {
  if (ube8[Q[360200]] === Q[360271] && ube8[Q[360199]]) {
    window[Q[360304]] = ube8[Q[360199]];for (var t1h_y2 in ube8[Q[360199]]) {
      _vKD[t1h_y2] = ube8[Q[360199]][t1h_y2];
    }
  } else console[Q[360001]](Q[360306] + ube8[Q[360200]]);window['_v$K'] = !![], window['_vDKO$']();
}, window[Q[360307]] = function (xweqb, nt2h_, h1ylz6, sr9$f, nt32o, z_h61, zu86y, cm7d0, xpwvqg) {
  nt32o = String(nt32o);var t34n$ = zu86y,
      fi$so4 = cm7d0;_vKD[Q[360153]][nt32o] = { 'productid': nt32o, 'productname': t34n$, 'productdesc': fi$so4, 'roleid': xweqb, 'rolename': nt2h_, 'rolelevel': h1ylz6, 'price': z_h61, 'callback': xpwvqg }, sendApi(_vKD[Q[360162]], Q[360308], { 'game_pkg': _vKD[Q[360021]], 'server_id': _vKD[Q[360022]][Q[360023]], 'server_name': _vKD[Q[360022]][Q[360286]], 'level': h1ylz6, 'uid': _vKD[Q[360018]], 'role_id': xweqb, 'role_name': nt2h_, 'product_id': nt32o, 'product_name': t34n$, 'product_desc': fi$so4, 'money': z_h61, 'partner_id': _vKD[Q[360166]] }, toPayCallBack, _v$DK, _vDO);
}, window[Q[360309]] = function (i4$f) {
  if (i4$f) {
    if (i4$f[Q[360310]] === 0xc8 || i4$f[Q[360200]] == Q[360271]) {
      var is$o34 = _vKD[Q[360153]][String(i4$f[Q[360311]])];if (is$o34[Q[360312]]) is$o34[Q[360312]](i4$f[Q[360311]], i4$f[Q[360313]], -0x1);vdac[Q[360314]]({ 'cpbill': i4$f[Q[360313]], 'productid': i4$f[Q[360311]], 'productname': is$o34[Q[360315]], 'productdesc': is$o34[Q[360316]], 'serverid': _vKD[Q[360022]][Q[360023]], 'servername': _vKD[Q[360022]][Q[360286]], 'roleid': is$o34[Q[360317]], 'rolename': is$o34[Q[360318]], 'rolelevel': is$o34[Q[360319]], 'price': is$o34[Q[360320]], 'extension': JSON[Q[360026]]({ 'cp_order_id': i4$f[Q[360313]] }) }, function (on4, qule8b) {
        is$o34[Q[360312]] && on4 == 0x0 && is$o34[Q[360312]](i4$f[Q[360311]], i4$f[Q[360313]], on4);console[Q[360001]](JSON[Q[360026]]({ 'type': Q[360321], 'status': on4, 'data': i4$f, 'role_name': is$o34[Q[360318]] }));if (on4 === 0x0) {} else {
          if (on4 === 0x1) {} else {
            if (on4 === 0x2) {}
          }
        }
      });
    } else alert(i4$f[Q[360001]]);
  }
}, window['_v$DKO'] = function () {}, window['_vO$D'] = function (xwpg5v, $rsi, v7c05k, gbexwq, t_312n) {
  vdac[Q[360322]](_vKD[Q[360022]][Q[360023]], _vKD[Q[360022]][Q[360286]] || _vKD[Q[360022]][Q[360023]], xwpg5v, $rsi, v7c05k), sendApi(_vKD[Q[360158]], Q[360323], { 'game_pkg': _vKD[Q[360021]], 'server_id': _vKD[Q[360022]][Q[360023]], 'role_id': xwpg5v, 'uid': _vKD[Q[360018]], 'role_name': $rsi, 'role_type': gbexwq, 'level': v7c05k });
}, window['_vOD$'] = function (ot42n3, ofsi$, m7d, hy1z, gwqe, vx57, eul8b, dc0k7, $rfsi9, pk7x) {
  _vKD[Q[360015]] = ot42n3, _vKD[Q[360016]] = ofsi$, _vKD[Q[360017]] = m7d, vdac[Q[360324]](_vKD[Q[360022]][Q[360023]], _vKD[Q[360022]][Q[360286]] || _vKD[Q[360022]][Q[360023]], ot42n3, ofsi$, m7d), sendApi(_vKD[Q[360158]], Q[360325], { 'game_pkg': _vKD[Q[360021]], 'server_id': _vKD[Q[360022]][Q[360023]], 'role_id': ot42n3, 'uid': _vKD[Q[360018]], 'role_name': ofsi$, 'role_type': hy1z, 'level': m7d, 'evolution': gwqe });
}, window['_v$OD'] = function (ton32, e8quwb, u8l6zb, c5m70, i$os4, fr$s9i, d70mc, j0damc, ot34$, k0vp57) {
  _vKD[Q[360015]] = ton32, _vKD[Q[360016]] = e8quwb, _vKD[Q[360017]] = u8l6zb, vdac[Q[360326]](_vKD[Q[360022]][Q[360023]], _vKD[Q[360022]][Q[360286]] || _vKD[Q[360022]][Q[360023]], ton32, e8quwb, u8l6zb), sendApi(_vKD[Q[360158]], Q[360325], { 'game_pkg': _vKD[Q[360021]], 'server_id': _vKD[Q[360022]][Q[360023]], 'role_id': ton32, 'uid': _vKD[Q[360018]], 'role_name': e8quwb, 'role_type': c5m70, 'level': u8l6zb, 'evolution': i$os4 });
}, window['_v$DO'] = function (os$fi9) {}, window['_vO$'] = function (v57p0k) {
  vdac[Q[360327]](Q[360327], function (bxqgw) {
    v57p0k && v57p0k(bxqgw);
  });
}, window[Q[360328]] = function () {
  vdac[Q[360328]]();
}, window[Q[360329]] = function () {
  vdac[Q[360330]]();
}, window[Q[360135]] = function (s4$if) {
  window['_vDO$'] = s4$if, window['_vDO$'] && window['_v$O'] && (console[Q[360001]](Q[360136] + window['_v$O'][Q[360137]]), window['_vDO$'](window['_v$O']), window['_v$O'] = null);
}, window['_vD$O'] = function (ht12_y, qwb8u, l6buz8, of9$i) {
  window[Q[360331]](Q[360332], { 'game_pkg': window['_vKD'][Q[360021]], 'role_id': qwb8u, 'server_id': l6buz8 }, of9$i);
}, window['_vKO$D'] = function (sofi$9, zeu8l) {
  function xeqpwg($o34sn) {
    var vk57xp = [],
        t2yh1 = [],
        el8 = window[Q[360006]][Q[360333]];for (var z8ul6y in el8) {
      var i4$sf = Number(z8ul6y);(!sofi$9 || !sofi$9[Q[360009]] || sofi$9[Q[360107]](i4$sf) != -0x1) && (t2yh1[Q[360038]](el8[z8ul6y]), vk57xp[Q[360038]]([i4$sf, 0x3]));
    }window['_v6$DOK'](window[Q[360039]], Q[360334]) >= 0x0 ? (console[Q[360041]](Q[360335]), vdac[Q[360336]] && vdac[Q[360336]](t2yh1, function (c0dj) {
      console[Q[360041]](Q[360337]), console[Q[360041]](c0dj);if (c0dj && c0dj[Q[360058]] == Q[360338]) for (var wequb8 in el8) {
        if (c0dj[el8[wequb8]] == Q[360339]) {
          var n$t = Number(wequb8);for (var zuelb = 0x0; zuelb < vk57xp[Q[360009]]; zuelb++) {
            if (vk57xp[zuelb][0x0] == n$t) {
              vk57xp[zuelb][0x1] = 0x1;break;
            }
          }
        }
      }window['_v6$DOK'](window[Q[360039]], Q[360340]) >= 0x0 ? wx[Q[360341]]({ 'withSubscriptions': !![], 'success': function ($r9i) {
          var $4otn = $r9i[Q[360342]][Q[360343]];if ($4otn) {
            console[Q[360041]](Q[360344]), console[Q[360041]]($4otn);for (var pg7v in el8) {
              if ($4otn[el8[pg7v]] == Q[360339]) {
                var yhl16 = Number(pg7v);for (var k7p05v = 0x0; k7p05v < vk57xp[Q[360009]]; k7p05v++) {
                  if (vk57xp[k7p05v][0x0] == yhl16) {
                    vk57xp[k7p05v][0x1] = 0x2;break;
                  }
                }
              }
            }console[Q[360041]](vk57xp), zeu8l && zeu8l(vk57xp);
          } else console[Q[360041]](Q[360345]), console[Q[360041]]($r9i), console[Q[360041]](vk57xp), zeu8l && zeu8l(vk57xp);
        }, 'fail': function () {
          console[Q[360041]](Q[360346]), console[Q[360041]](vk57xp), zeu8l && zeu8l(vk57xp);
        } }) : (console[Q[360041]](Q[360347] + window[Q[360039]]), console[Q[360041]](vk57xp), zeu8l && zeu8l(vk57xp));
    })) : (console[Q[360041]](Q[360348] + window[Q[360039]]), console[Q[360041]](vk57xp), zeu8l && zeu8l(vk57xp)), wx[Q[360349]](xeqpwg);
  }wx[Q[360350]](xeqpwg);
}, window['_vKOD$'] = { 'isSuccess': ![], 'level': Q[360351], 'isCharging': ![] }, window['_vK$OD'] = function ($si4o3) {
  wx[Q[360123]]({ 'success': function (sif9r) {
      var sof9i$ = window['_vKOD$'];sof9i$[Q[360352]] = !![], sof9i$[Q[360125]] = Number(sif9r[Q[360125]])[Q[360353]](0x0), sof9i$[Q[360127]] = sif9r[Q[360127]], $si4o3 && $si4o3(sof9i$[Q[360352]], sof9i$[Q[360125]], sof9i$[Q[360127]]);
    }, 'fail': function (wqbue) {
      console[Q[360041]](Q[360354], wqbue[Q[360058]]);var fo4si$ = window['_vKOD$'];$si4o3 && $si4o3(fo4si$[Q[360352]], fo4si$[Q[360125]], fo4si$[Q[360127]]);
    } });
}, window[Q[360331]] = function (gqbxew, web8qg, elbuz8, r$sfi, $srf9i, beul8, z16lyh, wueqb8) {
  if (r$sfi == undefined) r$sfi = 0x1;wx[Q[360218]]({ 'url': gqbxew, 'method': z16lyh || Q[360355], 'responseType': Q[360356], 'data': web8qg, 'header': { 'content-type': wueqb8 || Q[360220] }, 'success': function (os3$) {
      DEBUG && console[Q[360041]](Q[360357], gqbxew, info, os3$);if (os3$ && os3$[Q[360358]] == 0xc8) {
        var _h1y26 = os3$[Q[360199]];!beul8 || beul8(_h1y26) ? elbuz8 && elbuz8(_h1y26) : window[Q[360359]](gqbxew, web8qg, elbuz8, r$sfi, $srf9i, beul8, os3$);
      } else window[Q[360359]](gqbxew, web8qg, elbuz8, r$sfi, $srf9i, beul8, os3$);
    }, 'fail': function (c7md0) {
      DEBUG && console[Q[360041]](Q[360360], gqbxew, info, c7md0), window[Q[360359]](gqbxew, web8qg, elbuz8, r$sfi, $srf9i, beul8, c7md0);
    }, 'complete': function () {} });
}, window[Q[360359]] = function (t1nh_, wvgqpx, kv5x7, w8bqg, qxegw, w5xg, o23n) {
  w8bqg - 0x1 > 0x0 ? setTimeout(function () {
    window[Q[360331]](t1nh_, wvgqpx, kv5x7, w8bqg - 0x1, qxegw, w5xg);
  }, 0x3e8) : qxegw && qxegw(JSON[Q[360026]]({ 'url': t1nh_, 'response': o23n }));
}, window[Q[360361]] = function (ly6hzu, v7c5k, u6z8, c0dmja, dkmcj, jc0d, qxbwge) {
  !u6z8 && (u6z8 = {});var b8weuq = Math[Q[360362]](Date[Q[360141]]() / 0x3e8);u6z8[Q[360278]] = b8weuq, u6z8[Q[360363]] = v7c5k;var lu6zy8 = Object[Q[360364]](u6z8)[Q[360365]](),
      t24o3 = '',
      ot$ = '';for (var z1_y6 = 0x0; z1_y6 < lu6zy8[Q[360009]]; z1_y6++) {
    t24o3 = t24o3 + (z1_y6 == 0x0 ? '' : '&') + lu6zy8[z1_y6] + u6z8[lu6zy8[z1_y6]], ot$ = ot$ + (z1_y6 == 0x0 ? '' : '&') + lu6zy8[z1_y6] + '=' + encodeURIComponent(u6z8[lu6zy8[z1_y6]]);
  }t24o3 = t24o3 + _vKD[Q[360164]];var jk0 = Q[360366] + md5(t24o3);send(ly6hzu + '?' + ot$ + (ot$ == '' ? '' : '&') + jk0, null, c0dmja, dkmcj, jc0d, qxbwge || function (not43$) {
    return not43$[Q[360200]] == Q[360271];
  }, null, Q[360367]);
}, window['_vK$DO'] = function (b8lz6, q8w) {
  var u6lz8 = 0x0;_vKD[Q[360022]] && (u6lz8 = _vKD[Q[360022]][Q[360023]]), sendApi(_vKD[Q[360160]], Q[360368], { 'partnerId': _vKD[Q[360166]], 'gamePkg': _vKD[Q[360021]], 'logTime': Math[Q[360362]](Date[Q[360141]]() / 0x3e8), 'platformUid': _vKD[Q[360274]], 'type': b8lz6, 'serverId': u6lz8 }, null, 0x2, null, function () {
    return !![];
  });
}, window['_vKDO$'] = function (bwqexg) {
  sendApi(_vKD[Q[360158]], Q[360369], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, _vKD$O, _v$DK, _vDO);
}, window['_vKD$O'] = function (e8lzub) {
  if (e8lzub[Q[360200]] === Q[360271] && e8lzub[Q[360199]]) {
    e8lzub[Q[360199]][Q[360370]]({ 'id': -0x2, 'name': Q[360371] }), e8lzub[Q[360199]][Q[360370]]({ 'id': -0x1, 'name': Q[360372] }), _vKD[Q[360373]] = e8lzub[Q[360199]];if (window[Q[360374]]) window[Q[360374]][Q[360375]]();
  } else _vKD[Q[360376]] = ![], window['_vO$KD'](Q[360377] + e8lzub[Q[360200]]);
}, window['_vO$K'] = function (wbqex) {
  sendApi(_vKD[Q[360158]], Q[360378], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, _vOK$, _v$DK, _vDO);
}, window['_vOK$'] = function (o34i$) {
  _vKD[Q[360379]] = ![];if (o34i$[Q[360200]] === Q[360271] && o34i$[Q[360199]]) {
    for (var vwpxqg = 0x0; vwpxqg < o34i$[Q[360199]][Q[360009]]; vwpxqg++) {
      o34i$[Q[360199]][vwpxqg][Q[360290]] = _vK$O(o34i$[Q[360199]][vwpxqg]);
    }_vKD[Q[360169]][-0x1] = window[Q[360380]](o34i$[Q[360199]]), window[Q[360374]][Q[360381]](-0x1);
  } else window['_vO$KD'](Q[360382] + o34i$[Q[360200]]);
}, window[Q[360383]] = function (i$os) {
  sendApi(_vKD[Q[360158]], Q[360378], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, i$os, _v$DK, _vDO);
}, window['_v$OK'] = function (lb8zu6, qwe8) {
  sendApi(_vKD[Q[360158]], Q[360384], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]], 'server_group_id': qwe8 }, _v$KO, _v$DK, _vDO);
}, window['_v$KO'] = function (bu8elz) {
  _vKD[Q[360379]] = ![];if (bu8elz[Q[360200]] === Q[360271] && bu8elz[Q[360199]] && bu8elz[Q[360199]][Q[360199]]) {
    var xwqpeg = bu8elz[Q[360199]][Q[360385]],
        $3o4nt = [];for (var _tn2h1 = 0x0; _tn2h1 < bu8elz[Q[360199]][Q[360199]][Q[360009]]; _tn2h1++) {
      bu8elz[Q[360199]][Q[360199]][_tn2h1][Q[360290]] = _vK$O(bu8elz[Q[360199]][Q[360199]][_tn2h1]), ($3o4nt[Q[360009]] == 0x0 || bu8elz[Q[360199]][Q[360199]][_tn2h1][Q[360290]] != 0x0) && ($3o4nt[$3o4nt[Q[360009]]] = bu8elz[Q[360199]][Q[360199]][_tn2h1]);
    }_vKD[Q[360169]][xwqpeg] = window[Q[360380]]($3o4nt), window[Q[360374]][Q[360381]](xwqpeg);
  } else window['_vO$KD'](Q[360386] + bu8elz[Q[360200]]);
}, window['_v6$DK'] = function (xpg75v) {
  sendApi(_vKD[Q[360158]], Q[360387], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'version': _vKD[Q[360079]], 'game_pkg': _vKD[Q[360021]], 'device': _vKD[Q[360167]] }, reqServerRecommendCallBack, _v$DK, _vDO);
}, window[Q[360388]] = function ($4os3n) {
  _vKD[Q[360379]] = ![];if ($4os3n[Q[360200]] === Q[360271] && $4os3n[Q[360199]]) {
    for (var yu68zl = 0x0; yu68zl < $4os3n[Q[360199]][Q[360009]]; yu68zl++) {
      $4os3n[Q[360199]][yu68zl][Q[360290]] = _vK$O($4os3n[Q[360199]][yu68zl]);
    }_vKD[Q[360169]][-0x2] = window[Q[360380]]($4os3n[Q[360199]]), window[Q[360374]][Q[360381]](-0x2);
  } else alert(Q[360389] + $4os3n[Q[360200]]);
}, window[Q[360380]] = function (n132t) {
  if (!n132t && n132t[Q[360009]] <= 0x0) return n132t;for (let bgwqe = 0x0; bgwqe < n132t[Q[360009]]; bgwqe++) {
    n132t[bgwqe][Q[360390]] && n132t[bgwqe][Q[360390]] == 0x1 && (n132t[bgwqe][Q[360286]] += Q[360391]);
  }return n132t;
}, window['_vKO$'] = function (zeb8u, i$f4o) {
  zeb8u = zeb8u || _vKD[Q[360022]][Q[360023]], sendApi(_vKD[Q[360158]], Q[360392], { 'type': '4', 'game_pkg': _vKD[Q[360021]], 'server_id': zeb8u }, i$f4o);
}, window[Q[360393]] = function (mdja0c, vwgxq, pqexwg, webg8) {
  pqexwg = pqexwg || _vKD[Q[360022]][Q[360023]], sendApi(_vKD[Q[360158]], Q[360394], { 'type': mdja0c, 'game_pkg': vwgxq, 'server_id': pqexwg }, webg8);
}, window['_vK$O'] = function (sr$i9) {
  if (sr$i9) {
    if (sr$i9[Q[360290]] == 0x1) {
      if (sr$i9[Q[360395]] == 0x1) return 0x2;else return 0x1;
    } else return sr$i9[Q[360290]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_vDO$K'] = function (gwpqvx, kcmd70) {
  _vKD[Q[360396]] = { 'step': gwpqvx, 'server_id': kcmd70 };var gepqx = this;_vOK$D({ 'title': Q[360397] }), sendApi(_vKD[Q[360158]], Q[360398], { 'partner_id': _vKD[Q[360166]], 'uid': _vKD[Q[360018]], 'game_pkg': _vKD[Q[360021]], 'server_id': kcmd70, 'platform': _vKD[Q[360083]], 'platform_uid': _vKD[Q[360274]], 'check_login_time': _vKD[Q[360277]], 'check_login_sign': _vKD[Q[360275]], 'version_name': _vKD[Q[360246]] }, _vDOK$, _v$DK, _vDO, function (cma0d) {
    return cma0d[Q[360200]] == Q[360271] || cma0d[Q[360001]] == Q[360399] || cma0d[Q[360001]] == Q[360400];
  });
}, window['_vDOK$'] = function (x7pv5k) {
  var bq8uew = this;if (x7pv5k[Q[360200]] === Q[360271] && x7pv5k[Q[360199]]) {
    var v75kp = _vKD[Q[360022]];v75kp[Q[360401]] = _vKD[Q[360170]], v75kp[Q[360276]] = String(x7pv5k[Q[360199]][Q[360402]]), v75kp[Q[360176]] = parseInt(x7pv5k[Q[360199]][Q[360278]]);if (x7pv5k[Q[360199]][Q[360403]]) v75kp[Q[360403]] = parseInt(x7pv5k[Q[360199]][Q[360403]]);else v75kp[Q[360403]] = parseInt(x7pv5k[Q[360199]][Q[360023]]);v75kp[Q[360404]] = 0x0, v75kp[Q[360020]] = _vKD[Q[360301]], v75kp[Q[360405]] = x7pv5k[Q[360199]]['cdn_version'], v75kp[Q[360406]] = x7pv5k[Q[360199]][Q[360406]], console[Q[360041]](Q[360407] + JSON[Q[360026]](v75kp[Q[360406]])), _vKD[Q[360284]] == 0x1 && v75kp[Q[360406]] && v75kp[Q[360406]][Q[360408]] == 0x1 && (_vKD[Q[360409]] = 0x1, window[Q[360034]][Q[360035]]['_v6DK']()), _vD$OK();
  } else _vKD[Q[360396]][Q[360410]] >= 0x3 ? (_vDO(JSON[Q[360026]](x7pv5k)), window['_vO$KD'](Q[360411] + x7pv5k[Q[360200]])) : sendApi(_vKD[Q[360158]], Q[360258], { 'platform': _vKD[Q[360156]], 'partner_id': _vKD[Q[360166]], 'token': _vKD[Q[360256]], 'game_pkg': _vKD[Q[360021]], 'deviceId': _vKD[Q[360167]], 'scene': Q[360259] + _vKD[Q[360168]] }, function (qbwu) {
    if (!qbwu || qbwu[Q[360200]] != Q[360271]) {
      window['_vO$KD'](Q[360272] + qbwu && qbwu[Q[360200]]);return;
    }_vKD[Q[360275]] = String(qbwu[Q[360276]]), _vKD[Q[360277]] = String(qbwu[Q[360278]]), setTimeout(function () {
      _vDO$K(_vKD[Q[360396]][Q[360410]] + 0x1, _vKD[Q[360396]][Q[360023]]);
    }, 0x5dc);
  }, _v$DK, _vDO, function (z_6yh1) {
    return z_6yh1[Q[360200]] == Q[360271] || z_6yh1[Q[360200]] == Q[360412];
  });
}, window['_vD$OK'] = function () {
  ServerLoading[Q[360035]][Q[360293]](_vKD[Q[360284]]), window['_v$D'] = !![], window['_vDKO$']();
}, window['_vD$KO'] = function () {
  if (window['_vD$'] && window['_vK$D'] && window[Q[360182]] && window[Q[360183]] && window['_vKD$'] && window['_vK$']) {
    if (!window[Q[360413]][Q[360035]]) {
      console[Q[360041]](Q[360414] + window[Q[360413]][Q[360035]]);var qbu8l = wx[Q[360415]](),
          _1tn = qbu8l[Q[360137]] ? qbu8l[Q[360137]] : 0x0,
          i$f9 = { 'cdn': window['_vKD'][Q[360020]], 'spareCdn': window['_vKD'][Q[360244]], 'newRegister': window['_vKD'][Q[360284]], 'wxPC': window['_vKD'][Q[360112]], 'wxIOS': window['_vKD'][Q[360106]], 'wxAndroid': window['_vKD'][Q[360109]], 'wxParam': { 'limitLoad': window['_vKD']['_v6O$DK'], 'benchmarkLevel': window['_vKD']['_v6OK$D'], 'wxFrom': window[Q[360006]][Q[360251]] == Q[360416] ? 0x1 : 0x0, 'wxSDKVersion': window[Q[360039]] }, 'configType': window['_vKD'][Q[360177]], 'exposeType': window['_vKD'][Q[360179]], 'scene': _1tn };new window[Q[360413]](i$f9, window['_vKD'][Q[360019]], window['_v6O$KD']);
    }
  }
}, window['_vDKO$'] = function () {
  if (window['_vD$'] && window['_vK$D'] && window[Q[360182]] && window[Q[360183]] && window['_vKD$'] && window['_vK$'] && window['_v$D'] && window['_v$K']) {
    _vOKD$();if (!_vD$K) {
      _vD$K = !![];if (!window[Q[360413]][Q[360035]]) window['_vD$KO']();var pxg5v7 = 0x0,
          zhly61 = wx[Q[360417]]();zhly61 && (window['_vKD'][Q[360111]] && (pxg5v7 = zhly61[Q[360101]]), console[Q[360001]](Q[360418] + zhly61[Q[360101]] + Q[360419] + zhly61[Q[360102]] + Q[360420] + zhly61[Q[360103]] + Q[360421] + zhly61[Q[360104]] + Q[360422] + zhly61[Q[360423]] + Q[360424] + zhly61[Q[360425]]));var ewqx = {};for (const dmc0k7 in _vKD[Q[360022]]) {
        ewqx[dmc0k7] = _vKD[Q[360022]][dmc0k7];
      }var exqg = { 'channel': window['_vKD'][Q[360171]], 'account': window['_vKD'][Q[360018]], 'userId': window['_vKD'][Q[360273]], 'cdn': window['_vKD'][Q[360020]], 'data': window['_vKD'][Q[360199]], 'package': window['_vKD'][Q[360154]], 'newRegister': window['_vKD'][Q[360284]], 'pkgName': window['_vKD'][Q[360021]], 'partnerId': window['_vKD'][Q[360166]], 'platform_uid': window['_vKD'][Q[360274]], 'deviceId': window['_vKD'][Q[360167]], 'selectedServer': ewqx, 'configType': window['_vKD'][Q[360177]], 'exposeType': window['_vKD'][Q[360179]], 'debugUsers': window['_vKD'][Q[360174]], 'wxMenuTop': pxg5v7, 'wxShield': window['_vKD'][Q[360181]] };if (window[Q[360304]]) for (var egpw in window[Q[360304]]) {
        exqg[egpw] = window[Q[360304]][egpw];
      }window[Q[360413]][Q[360035]]['_v$6KD'](exqg);
    }
  } else console[Q[360001]](Q[360426] + window['_vD$'] + Q[360427] + window['_vK$D'] + Q[360428] + window[Q[360182]] + Q[360429] + window[Q[360183]] + Q[360430] + window['_vKD$'] + Q[360431] + window['_vK$'] + Q[360432] + window['_v$D'] + Q[360433] + window['_v$K']);
};