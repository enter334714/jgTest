var a = wx.$y;
require('a5a6uff.js'), window[a[547]][a[533]][a[327]] = null, window['client_pb'] = require('a5a6cleintpb.js'), window[a[571]] = window[a[547]][a[466]][a[370]](client_pb);