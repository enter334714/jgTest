var a = wx.$y;
import gzn6v from '../a3a4/eeesdk.js';
window[a[28512]] = { 'wxVersion': window[a[1130]][a[37558]] }, window[a[44043]] = ![], window[a[44044]] = 0x1, window[a[39658]] = 0x1, window[a[44045]] = !![], window[a[44046]] = !![], window[a[44047]] = '', window[a[44048]] = !![], window[a[5257]] = {
    'base_cdn': a[44049],
    'cdn': a[44049]
}, j1E[a[44050]] = {}, j1E[a[511]] = '0', j1E[a[6089]] = window[a[28512]][a[44051]], j1E[a[37642]] = '', j1E['os'] = '1', j1E[a[44052]] = a[44053], j1E[a[44054]] = a[44055], j1E[a[44056]] = a[44057], j1E[a[44058]] = a[44059], j1E[a[44060]] = a[44061], j1E[a[13741]] = '1', j1E[a[28950]] = '', j1E[a[28952]] = '', j1E[a[44062]] = 0x0, j1E[a[44063]] = {}, j1E[a[44064]] = parseInt(j1E[a[13741]]), j1E[a[13750]] = j1E[a[13741]], j1E[a[28944]] = {}, j1E[a[37568]] = a[44065], j1E[a[44066]] = ![], j1E[a[13887]] = a[44067], j1E[a[28904]] = Date[a[642]](), j1E[a[5256]] = a[44068], j1E[a[1318]] = '_a', j1E[a[29097]] = '', j1E[a[44069]] = 0x2, j1E[a[660]] = 0x7c1, j1E[a[44051]] = window[a[28512]][a[44051]], j1E[a[1340]] = ![], j1E[a[1695]] = ![], j1E[a[12543]] = ![], j1E[a[28576]] = ![], window[a[44070]] = 0x5, window[a[44071]] = ![], window[a[37598]] = ![], window[a[37606]] = ![], window[a[44072]] = ![], window[a[44073]] = ![], window[a[44074]] = ![], window[a[44075]] = ![], window[a[44076]] = ![], window[a[44077]] = ![], window[a[44078]] = null, window[a[1222]] = function (q6kt) {
    console[a[471]](a[1222], q6kt), wx[a[5599]]({}), wx[a[37586]]({
        'title': a[6841],
        'content': q6kt,
        'success'(ugf2) {
            if (ugf2[a[44079]]) console[a[471]](a[44080]);else ugf2[a[1126]] && console[a[471]](a[44081]);
        }
    });
}, window[a[44082]] = function (boc4y) {
    console[a[471]](a[44083], boc4y), jM1EB(), wx[a[37586]]({
        'title': a[6841],
        'content': boc4y,
        'confirmText': a[44084],
        'cancelText': a[21020],
        'success'(fux2g1) {
            if (fux2g1[a[44079]]) window[a[37612]]();else fux2g1[a[1126]] && (console[a[471]](a[44085]), wx[a[28549]]({}));
        }
    });
}, window[a[44086]] = function (_eyo0) {
    console[a[471]](a[44086], _eyo0), wx[a[37586]]({
        'title': a[6841],
        'content': _eyo0,
        'confirmText': a[29081],
        'showCancel': ![],
        'complete'(y4eo_0) {
            console[a[471]](a[44085]), wx[a[28549]]({});
        }
    });
}, window[a[44087]] = ![], window[a[44088]] = function (r3578) {
    window[a[44087]] = !![], wx[a[5598]](r3578);
}, window[a[44089]] = function () {
    window[a[44087]] && (window[a[44087]] = ![], wx[a[5599]]({}));
}, window[a[44090]] = function (kq6z8) {
    window[a[37574]][a[706]][a[44090]](kq6z8);
}, window[a[13757]] = function (sjxfnv, c0$bo) {
    gzn6v[a[13757]](sjxfnv, function (b$oy0c) {
        b$oy0c && b$oy0c[a[521]] ? b$oy0c[a[521]][a[1942]] == 0x1 ? c0$bo(!![]) : (c0$bo(![]), console[a[637]](a[44091] + b$oy0c[a[521]][a[44092]])) : console[a[471]](a[13757], b$oy0c);
    });
}, window[a[44093]] = function (bca9m$, wguf) {
    console[a[637]](a[44094] + JSON[a[5240]](bca9m$));
    if (bca9m$[a[349]]) bca9m$[a[349]] = JSON[a[5240]](bca9m$[a[349]]);
    if (bca9m$['to']) bca9m$['to'] = JSON[a[5240]](bca9m$['to']);
    var ugw2e_ = function (e12wg) {
        if (!e12wg) e12wg = {
            'state': 0x1,
            'display': 0x1,
            'msg': a[44095]
        };
        if (!e12wg[a[44092]]) e12wg[a[44092]] = a[44095];
        console[a[637]](a[44096] + JSON[a[5240]](e12wg)), wguf && wguf(e12wg);
    },
        zjnsvh = function (vnsjfx) {
        var zhjkv = {
            'state': 0x0,
            'display': 0x0,
            'msg': a[44097]
        };
        console[a[637]](a[44098] + vnsjfx), wguf && wguf(zhjkv);
    };
    sendApi(j1E[a[44054]], a[44099], bca9m$, ugw2e_, 0x1, zjnsvh, function () {
        return !![];
    });
}, window[a[44100]] = function ($bc0m) {
    console[a[471]](a[44101], $bc0m);
}, window[a[44102]] = function (qr758) {}, window[a[44103]] = function (o_4ey0, weug2_, cy0o4) {}, window[a[44104]] = function (g_e2w) {
    console[a[471]](a[44105], g_e2w), window[a[37574]][a[706]][a[44106]](), window[a[37574]][a[706]][a[44107]](), window[a[37574]][a[706]][a[44108]](), window[a[44109]]();
}, window[a[44110]] = function (cma9b$) {
    window[a[44111]](0xe, a[44112] + cma9b$), window[a[44082]](a[44113]);
    var ocy_4 = {
        'id': window[a[5257]][a[37563]],
        'role': window[a[5257]][a[5388]],
        'level': window[a[5257]][a[37564]],
        'account': window[a[5257]][a[28948]],
        'version': window[a[5257]][a[660]],
        'cdn': window[a[5257]][a[5254]],
        'pkgName': window[a[5257]][a[28950]],
        'gamever': window[a[1130]][a[37558]],
        'serverid': window[a[5257]][a[28944]] ? window[a[5257]][a[28944]][a[12719]] : 0x0,
        'systemInfo': window[a[37565]],
        'error': a[44114],
        'stack': cma9b$ ? cma9b$ : a[44113]
    },
        f2gxs = JSON[a[5240]](ocy_4);
    console[a[519]](a[44115] + f2gxs), window[a[37568]](f2gxs);
}, window[a[44111]] = function (q6dt8r, r8tqd6) {
    sendApi(j1E[a[44056]], a[44116], {
        'game_pkg': j1E[a[28950]],
        'partner_id': j1E[a[13741]],
        'server_id': j1E[a[28944]] && j1E[a[28944]][a[12719]] > 0x0 ? j1E[a[28944]][a[12719]] : 0x0,
        'uid': j1E[a[28948]] > 0x0 ? j1E[a[28948]] : 0x0,
        'type': q6dt8r,
        'info': r8tqd6
    });
}, window[a[44117]] = function (nxhvs) {
    var e2wg_u = JSON[a[470]](nxhvs);
    e2wg_u[a[44118]] = window[a[1130]][a[37558]], e2wg_u[a[44119]] = window[a[5257]][a[28944]] ? window[a[5257]][a[28944]][a[12719]] : 0x0, e2wg_u[a[37565]] = window[a[37565]];
    var hsnx = JSON[a[5240]](e2wg_u);
    console[a[519]](a[44120] + hsnx), window[a[37568]](hsnx);
}, window[a[37613]] = function (by0$cm, tr57q) {
    var eg4wu = {
        'id': window[a[5257]][a[37563]],
        'role': window[a[5257]][a[5388]],
        'level': window[a[5257]][a[37564]],
        'account': window[a[5257]][a[28948]],
        'version': window[a[5257]][a[660]],
        'cdn': window[a[5257]][a[5254]],
        'pkgName': window[a[5257]][a[28950]],
        'gamever': window[a[1130]][a[37558]],
        'serverid': window[a[5257]][a[28944]] ? window[a[5257]][a[28944]][a[12719]] : 0x0,
        'systemInfo': window[a[37565]],
        'error': by0$cm,
        'stack': tr57q
    },
        c0b4o = JSON[a[5240]](eg4wu);
    console[a[535]](a[44121] + c0b4o), window[a[37568]](c0b4o);
}, window[a[37568]] = function (i735pr) {
    if (window[a[5257]][a[37643]] == a[44122]) return;
    var yo4_c = j1E[a[37568]] + a[44123] + j1E[a[28948]];
    wx[a[1054]]({
        'url': yo4_c,
        'method': a[37469],
        'data': i735pr,
        'header': {
            'content-type': a[39275],
            'cache-control': a[28557]
        },
        'success': function (qz6k) {
            DEBUG && console[a[471]](a[44124], yo4_c, i735pr, qz6k);
        },
        'fail': function (jx12sf) {
            DEBUG && console[a[471]](a[44124], yo4_c, i735pr, jx12sf);
        },
        'complete': function () {}
    });
}, window[a[44125]] = function () {
    function nx1f() {
        return ((0x1 + Math[a[675]]()) * 0x10000 | 0x0)[a[354]](0x10)[a[477]](0x1);
    }
    return nx1f() + nx1f() + '-' + nx1f() + '-' + nx1f() + '-' + nx1f() + '+' + nx1f() + nx1f() + nx1f();
}, window[a[37612]] = function () {
    console[a[471]](a[44126]);
    var f1x = gzn6v[a[35614]]();
    j1E[a[13750]] = f1x[a[44127]], j1E[a[44064]] = f1x[a[44127]], j1E[a[13741]] = f1x[a[44127]], j1E[a[28950]] = f1x[a[44128]];
    var vzjnh = { 'game_ver': j1E[a[6089]] };
    j1E[a[28952]] = this[a[44125]](), jM1BE({ 'title': a[44129] }), gzn6v[a[944]](vzjnh, this[a[44130]][a[323]](this));
}, window[a[44130]] = function (rdt8) {
    var r5qd = rdt8[a[44131]];
    sdkInitRes = rdt8, console[a[471]](a[44132] + r5qd + a[44133] + (r5qd == 0x1) + a[44134] + rdt8[a[37558]] + a[44135] + window[a[28512]][a[44051]]);
    if (!rdt8[a[37558]] || window[a[37577]](window[a[28512]][a[44051]], rdt8[a[37558]]) < 0x0) console[a[471]](a[44136]), j1E[a[44054]] = a[44137], j1E[a[44056]] = a[44138], j1E[a[44058]] = a[44139], j1E[a[5254]] = a[44140], j1E[a[28574]] = a[44141], j1E[a[5258]] = a[44142], j1E[a[1340]] = ![];else window[a[37577]](window[a[28512]][a[44051]], rdt8[a[37558]]) == 0x0 ? (console[a[471]](a[44143]), j1E[a[44054]] = a[44055], j1E[a[44056]] = a[44057], j1E[a[44058]] = a[44059], j1E[a[5254]] = a[44144], j1E[a[28574]] = a[44141], j1E[a[5258]] = a[44145], j1E[a[1340]] = !![]) : (console[a[471]](a[44146]), j1E[a[44054]] = a[44055], j1E[a[44056]] = a[44057], j1E[a[44058]] = a[44059], j1E[a[5254]] = a[44147], j1E[a[28574]] = a[44141], j1E[a[5258]] = a[44145], j1E[a[1340]] = ![]);
    j1E[a[44062]] = config[a[349]] ? config[a[349]] : 0x0, this[a[44148]](), this[a[44149]](), window[a[44150]] = 0x5, jM1BE({ 'title': a[44151] }), gzn6v[a[37458]](this[a[44152]][a[323]](this));
}, window[a[44150]] = 0x5, window[a[44152]] = function (u12xgf, qdr6t) {
    if (u12xgf == 0x0 && qdr6t && qdr6t[a[503]]) {
        j1E[a[44153]] = qdr6t[a[503]], j1E[a[29095]] = qdr6t[a[29095]], j1E[a[29090]] = qdr6t[a[29090]], j1E[a[29096]] = qdr6t[a[29096]], j1E[a[29089]] = qdr6t[a[29089]];
        var tq5dr8 = this;
        jM1BE({ 'title': a[44154] }), sendApi(j1E[a[44054]], a[44155], {
            'platform': j1E[a[44052]],
            'partner_id': j1E[a[13741]],
            'token': qdr6t[a[503]],
            'game_pkg': j1E[a[28950]],
            'deviceId': j1E[a[28952]],
            'scene': a[44156] + j1E[a[44062]]
        }, this[a[44157]][a[323]](this), jBE1, jEM);
    } else qdr6t && qdr6t[a[28565]] && window[a[44150]] > 0x0 && (qdr6t[a[28565]][a[418]](a[44158]) != -0x1 || qdr6t[a[28565]][a[418]](a[44159]) != -0x1 || qdr6t[a[28565]][a[418]](a[44160]) != -0x1 || qdr6t[a[28565]][a[418]](a[44161]) != -0x1 || qdr6t[a[28565]][a[418]](a[44162]) != -0x1 || qdr6t[a[28565]][a[418]](a[44163]) != -0x1) ? (window[a[44150]]--, gzn6v[a[37458]](this[a[44152]][a[323]](this))) : (window[a[44111]](0x1, a[44164] + u12xgf + a[44165] + (qdr6t ? qdr6t[a[28565]] : '')), window[a[37613]](a[44166], JSON[a[5240]]({
        'status': u12xgf,
        'data': qdr6t
    })), window[a[44082]](a[44167] + (qdr6t && qdr6t[a[28565]] ? '，' + qdr6t[a[28565]] : '')));
}, window[a[44157]] = function (r538t7) {
    if (!r538t7) {
        window[a[44111]](0x2, a[44168]), window[a[37613]](a[44169], a[44170]), window[a[44082]](a[44171]);
        return;
    }
    if (r538t7[a[1942]] != a[10823]) {
        window[a[44111]](0x2, a[44172] + r538t7[a[1942]]), window[a[37613]](a[44169], JSON[a[5240]](r538t7)), window[a[44082]](a[44173] + r538t7[a[1942]]);
        return;
    }
    if (r538t7[a[44174]] == 0x1) {
        window[a[44082]](a[44175]);
        return;
    }
    j1E[a[13739]] = String(r538t7[a[28948]]), j1E[a[28948]] = String(r538t7[a[28948]]), j1E[a[28902]] = String(r538t7[a[28902]]), j1E[a[13750]] = String(r538t7[a[28902]]), j1E[a[28951]] = String(r538t7[a[28951]]), j1E[a[44176]] = String(r538t7[a[12702]]), j1E[a[44177]] = String(r538t7[a[1470]]), j1E[a[12702]] = '';
    var q785r = this;
    jM1BE({ 'title': a[44178] });
    var x1j2f = localStorage[a[1057]](a[44179] + j1E[a[28950]] + j1E[a[28948]]);
    if (x1j2f && x1j2f != '') {
        var o_uw4e = Number(x1j2f);
        q785r[a[44180]](o_uw4e);
    } else q785r[a[44181]]();
}, window[a[44181]] = function () {
    var bc4y = this;
    sendApi(j1E[a[44054]], a[44182], {
        'partner_id': j1E[a[13741]],
        'uid': j1E[a[28948]],
        'version': j1E[a[6089]],
        'game_pkg': j1E[a[28950]],
        'device': j1E[a[28952]]
    }, bc4y[a[44183]][a[323]](bc4y), jBE1, jEM);
}, window[a[44183]] = function (xuf12) {
    if (!xuf12) {
        window[a[44111]](0x3, a[44184]), window[a[44082]](a[44184]);
        return;
    }
    if (xuf12[a[1942]] != a[10823]) {
        window[a[44111]](0x3, a[44185] + xuf12[a[1942]]), window[a[44082]](a[44185] + xuf12[a[1942]]);
        return;
    }
    if (!xuf12[a[521]] || xuf12[a[521]][a[335]] == 0x0) {
        window[a[44111]](0x3, a[44186]), window[a[44082]](a[44187]);
        return;
    }
    this[a[44188]](xuf12);
}, window[a[44180]] = function (xsfj21) {
    var tr53p7 = this;
    sendApi(j1E[a[44054]], a[44189], {
        'server_id': xsfj21,
        'time': Date[a[642]]() / 0x3e8
    }, tr53p7[a[44190]][a[323]](tr53p7), jBE1, jEM);
}, window[a[44190]] = function (c04oy_) {
    if (!c04oy_) {
        window[a[44111]](0x4, a[44191]), this[a[44181]]();
        return;
    }
    if (c04oy_[a[1942]] != a[10823]) {
        window[a[44111]](0x4, a[44192] + c04oy_[a[1942]]), this[a[44181]]();
        return;
    }
    if (!c04oy_[a[521]] || c04oy_[a[521]][a[335]] == 0x0) {
        window[a[44111]](0x4, a[44193]), this[a[44181]]();
        return;
    }
    this[a[44188]](c04oy_);
}, window[a[44188]] = function (_eo4w0) {
    j1E[a[1235]] = _eo4w0[a[44194]] != undefined ? _eo4w0[a[44194]] : 0x0, j1E[a[28944]] = {
        'server_id': String(_eo4w0[a[521]][0x0][a[12719]]),
        'server_name': String(_eo4w0[a[521]][0x0][a[28949]]),
        'entry_ip': _eo4w0[a[521]][0x0][a[28555]],
        'entry_port': parseInt(_eo4w0[a[521]][0x0][a[28972]]),
        'status': j1BM(_eo4w0[a[521]][0x0]),
        'start_time': _eo4w0[a[521]][0x0][a[44195]],
        'maintain_time': _eo4w0[a[521]][0x0][a[44196]] ? _eo4w0[a[521]][0x0][a[44196]] : '',
        'is_recommend': _eo4w0[a[521]][0x0][a[44197]],
        'cdn': j1E[a[5254]]
    }, this[a[44198]](), window[a[37574]] && window[a[37574]][a[706]][a[44199]] && window[a[37574]][a[706]][a[44199]](sdkInitRes[a[44200]], sdkInitRes[a[44201]], sdkInitRes[a[44202]], sdkInitRes[a[44203]], sdkInitRes[a[44204]]);
}, window[a[44198]] = function () {
    window[a[44076]] = !![], window[a[44205]]();
}, window[a[44205]] = function () {
    if (window[a[44076]] && window[a[44075]]) {
        var pr5i73 = j1E[a[44206]] != undefined ? j1E[a[44206]] : 0x0,
            oby0 = j1E[a[29089]] == undefined ? 0x0 : j1E[a[29089]],
            snj1x = pr5i73 == 0x1 && oby0 == 0x1 || pr5i73 == 0x2 && oby0 != 0x1 || pr5i73 == 0x3;
        console[a[637]](a[44207] + j1E[a[1235]] + a[44208] + snj1x + a[44209] + j1E[a[29089]] + a[44210] + j1E[a[44206]]);
        if (!snj1x && j1E[a[1235]] == 0x1) {
            var dzqk = j1E[a[28944]][a[665]];
            if (dzqk === -0x1 || dzqk === 0x0) {
                window[a[44111]](0xf, a[44211] + j1E[a[28944]]['id'] + a[44212] + j1E[a[28944]][a[665]]), window[a[44082]](dzqk === -0x1 ? a[44213] : a[44214]);
                return;
            }
            jEMB1(0x0, j1E[a[28944]][a[12719]]), window[a[37574]][a[706]][a[44215]](j1E[a[1235]]);
        } else window[a[37574]][a[706]][a[44216]]({
            'show': sdkInitRes[a[44200]],
            'skinUrl': sdkInitRes[a[44201]],
            'content': sdkInitRes[a[44202]],
            'x': sdkInitRes[a[44203]],
            'y': sdkInitRes[a[44204]]
        }), jM1EB();
        window[a[44217]](), window[a[37599]](), window[a[37600]]();
    }
}, window[a[44148]] = function () {
    sendApi(j1E[a[44054]], a[44218], {
        'game_pkg': j1E[a[28950]],
        'version_name': j1E[a[5258]]
    }, this[a[44219]][a[323]](this), jBE1, jEM);
}, window[a[44219]] = function (sjnhzv) {
    if (!sjnhzv) {
        window[a[44111]](0x5, a[44220]), window[a[44082]](a[44220]);
        return;
    }
    if (sjnhzv[a[1942]] != a[10823]) {
        window[a[44111]](0x5, a[44221] + sjnhzv[a[1942]]), window[a[44082]](a[44221] + sjnhzv[a[1942]]);
        return;
    }
    if (!sjnhzv[a[521]] || !sjnhzv[a[521]][a[6089]]) {
        window[a[44111]](0x5, a[44222] + (sjnhzv[a[521]] && sjnhzv[a[521]][a[6089]])), window[a[44082]](a[44222] + (sjnhzv[a[521]] && sjnhzv[a[521]][a[6089]]));
        return;
    }
    sjnhzv[a[521]][a[44223]] && sjnhzv[a[521]][a[44223]][a[335]] > 0xa && (j1E[a[44224]] = sjnhzv[a[521]][a[44223]], j1E[a[5254]] = sjnhzv[a[521]][a[44223]]), sjnhzv[a[521]][a[6089]] && (j1E[a[660]] = sjnhzv[a[521]][a[6089]]), console[a[637]](a[29092] + j1E[a[660]] + a[44225] + j1E[a[5258]]), window[a[44074]] = !![], window[a[37599]](), window[a[37600]]();
}, window[a[44226]], window[a[44149]] = function () {
    sendApi(j1E[a[44054]], a[44227], { 'game_pkg': j1E[a[28950]] }, this[a[44228]][a[323]](this), jBE1, jEM);
}, window[a[44228]] = function (g_wue) {
    if (g_wue && g_wue[a[1942]] === a[10823] && g_wue[a[521]]) {
        window[a[44226]] = g_wue[a[521]];
        for (var o4y0_e in g_wue[a[521]]) {
            j1E[o4y0_e] = g_wue[a[521]][o4y0_e];
        }
    } else window[a[44111]](0xb, a[44229]), console[a[637]](a[44230] + g_wue[a[1942]]);
    window[a[44075]] = !![], window[a[44205]]();
}, window[a[44217]] = function () {
    if (!window[a[44076]] || !window[a[44075]]) return;
    var $y0mb = j1E[a[1235]] == 0x1,
        my0$bc = j1E[a[1340]],
        qt8dr6 = j1E[a[28814]] && j1E[a[28814]] > 0x0;
    if (my0$bc || $y0mb && qt8dr6) {
        var xs1jnf = j1E[a[28815]],
            ge4wu = xs1jnf && xs1jnf[a[335]] == 0x9;
        ge4wu && (window[a[31926]] = xs1jnf);
        var uw_2ge = j1E[a[28816]],
            jkvznh = uw_2ge && uw_2ge[a[458]]('#')[a[335]] == 0x4;
        jkvznh && (window[a[31927]] = uw_2ge);
    }
}, window[a[44109]] = function () {
    window[a[31926]] = null, window[a[31927]] = null;
}, window[a[44231]] = function (hzq6, knhvjz, nxhvj, ipr75, w1ug2f, $cy0ob, bcy0$m, gwf2u1, vh6zkd, qzdh) {
    w1ug2f = String(w1ug2f);
    var nvzhjk = bcy0$m,
        r78t = gwf2u1;
    j1E[a[44050]][w1ug2f] = {
        'productid': w1ug2f,
        'productname': nvzhjk,
        'productdesc': r78t,
        'roleid': hzq6,
        'rolename': knhvjz,
        'rolelevel': nxhvj,
        'price': $cy0ob,
        'callback': vh6zkd
    }, sendApi(j1E[a[44058]], a[44232], {
        'game_pkg': j1E[a[28950]],
        'server_id': j1E[a[28944]][a[12719]],
        'server_name': j1E[a[28944]][a[28949]],
        'level': nxhvj,
        'uid': j1E[a[28948]],
        'role_id': hzq6,
        'role_name': knhvjz,
        'product_id': w1ug2f,
        'product_name': nvzhjk,
        'product_desc': r78t,
        'money': $cy0ob,
        'partner_id': j1E[a[13741]]
    }, toPayCallBack, jBE1, jEM);
}, window[a[44233]] = function (zq6khd) {
    if (zq6khd && (zq6khd[a[44234]] === 0xc8 || zq6khd[a[1942]] == a[10823])) {
        var y4boc0 = j1E[a[44050]][String(zq6khd[a[44235]])];
        if (y4boc0[a[909]]) y4boc0[a[909]](zq6khd[a[44235]], zq6khd[a[44236]], -0x1);
        gzn6v[a[37504]]({
            'cpbill': zq6khd[a[44236]],
            'productid': zq6khd[a[44235]],
            'productname': y4boc0[a[44237]],
            'productdesc': y4boc0[a[44238]],
            'serverid': j1E[a[28944]][a[12719]],
            'servername': j1E[a[28944]][a[28949]],
            'roleid': y4boc0[a[13745]],
            'rolename': y4boc0[a[13746]],
            'rolelevel': y4boc0[a[44239]],
            'price': y4boc0[a[31156]],
            'extension': JSON[a[5240]]({ 'cp_order_id': zq6khd[a[44236]] })
        }, function (q8z, o0y$bc) {
            y4boc0[a[909]] && q8z == 0x0 && y4boc0[a[909]](zq6khd[a[44235]], zq6khd[a[44236]], q8z);
            console[a[637]](JSON[a[5240]]({
                'type': a[44240],
                'status': q8z,
                'data': zq6khd,
                'role_name': y4boc0[a[13746]]
            }));
            if (q8z === 0x0) {} else {
                if (q8z === 0x1) {} else {
                    if (q8z === 0x2) {}
                }
            }
        });
    } else {
        var abcmy$ = zq6khd ? a[44241] + zq6khd[a[44234]] + a[44242] + zq6khd[a[1942]] + a[44243] + zq6khd[a[637]] : a[44244];
        window[a[44111]](0xd, a[44245] + abcmy$), alert(abcmy$);
    }
}, window[a[44246]] = function () {}, window[a[44247]] = function (x2f1gs, znvsh, nvhj, x2ug1, yob0) {
    gzn6v[a[37541]](j1E[a[28944]][a[12719]], j1E[a[28944]][a[28949]] || j1E[a[28944]][a[12719]], x2f1gs, znvsh, nvhj), sendApi(j1E[a[44054]], a[44248], {
        'game_pkg': j1E[a[28950]],
        'server_id': j1E[a[28944]][a[12719]],
        'role_id': x2f1gs,
        'uid': j1E[a[28948]],
        'role_name': znvsh,
        'role_type': x2ug1,
        'level': nvhj
    });
}, window[a[44249]] = function (eow0, woe_u4, c$a, g1x2fs, k6zv, a9b$, m$b0yc, jkznhv, we2g_, qk6z) {
    j1E[a[37563]] = eow0, j1E[a[5388]] = woe_u4, j1E[a[37564]] = c$a, gzn6v[a[37542]](j1E[a[28944]][a[12719]], j1E[a[28944]][a[28949]] || j1E[a[28944]][a[12719]], eow0, woe_u4, c$a), sendApi(j1E[a[44054]], a[44250], {
        'game_pkg': j1E[a[28950]],
        'server_id': j1E[a[28944]][a[12719]],
        'role_id': eow0,
        'uid': j1E[a[28948]],
        'role_name': woe_u4,
        'role_type': g1x2fs,
        'level': c$a,
        'evolution': k6zv
    });
}, window[a[44251]] = function (_4weuo, zqkd, p7t, n6zhv, bmcy$, jvnxsf, b$c9, dzv, hqkz, am9$) {
    j1E[a[37563]] = _4weuo, j1E[a[5388]] = zqkd, j1E[a[37564]] = p7t, gzn6v[a[37543]](j1E[a[28944]][a[12719]], j1E[a[28944]][a[28949]] || j1E[a[28944]][a[12719]], _4weuo, zqkd, p7t), sendApi(j1E[a[44054]], a[44250], {
        'game_pkg': j1E[a[28950]],
        'server_id': j1E[a[28944]][a[12719]],
        'role_id': _4weuo,
        'uid': j1E[a[28948]],
        'role_name': zqkd,
        'role_type': n6zhv,
        'level': p7t,
        'evolution': bmcy$
    });
}, window[a[44252]] = function (yob0c4) {}, window[a[44253]] = function (nk6zv, vhsnx) {
    gzn6v[a[37482]](a[37482], { 'activity_id': vhsnx }, function (aybcm) {
        nk6zv && nk6zv(aybcm);
    });
}, window[a[26603]] = function () {
    gzn6v[a[26603]]();
}, window[a[44254]] = function () {
    gzn6v[a[26473]]();
}, window[a[44255]] = function (sfx21j, s12jxf, q6dkzh, yo_c04, n6kv, ycob, xhjvsn, xfj1ns) {
    xfj1ns = xfj1ns || j1E[a[28944]][a[12719]], sendApi(j1E[a[44054]], a[44256], {
        'phone': sfx21j,
        'role_id': s12jxf,
        'uid': j1E[a[28948]],
        'game_pkg': j1E[a[28950]],
        'partner_id': j1E[a[13741]],
        'server_id': xfj1ns
    }, xhjvsn, 0x2, null, function () {
        return !![];
    });
}, window[a[12032]] = function (c4yo_0) {
    window[a[37662]] = c4yo_0, window[a[37662]] && window[a[37661]] && (console[a[637]](a[37663] + window[a[37661]][a[1396]]), window[a[37662]](window[a[37661]]), window[a[37661]] = null);
}, window[a[44257]] = function (s2j1xf, vh6nk, yoe4, $bac) {
    window[a[584]](a[44258], {
        'game_pkg': window[a[5257]][a[28950]],
        'role_id': vh6nk,
        'server_id': yoe4
    }, $bac);
}, window[a[44259]] = function (fsx2g, zk6dqh, jzshnv) {
    function c0yo_(ow_40) {
        var vn6h = [],
            am$b9c = [],
            $bcm = jzshnv || window[a[1130]][a[44260]];
        for (var yc40ob in $bcm) {
            var r5t7q8 = Number(yc40ob);
            (!fsx2g || !fsx2g[a[335]] || fsx2g[a[418]](r5t7q8) != -0x1) && (am$b9c[a[358]]($bcm[yc40ob]), vn6h[a[358]]([r5t7q8, 0x3]));
        }
        window[a[37577]](window[a[37578]], a[44261]) >= 0x0 ? (console[a[471]](a[44262]), gzn6v[a[37538]] && gzn6v[a[37538]](am$b9c, function (uf2gx1) {
            console[a[471]](a[44263]), console[a[471]](uf2gx1);
            if (uf2gx1 && uf2gx1[a[28565]] == a[44264]) for (var vjzsnh in $bcm) {
                if (uf2gx1[$bcm[vjzsnh]] == a[44265]) {
                    var nkzv6h = Number(vjzsnh);
                    for (var bcma$y = 0x0; bcma$y < vn6h[a[335]]; bcma$y++) {
                        if (vn6h[bcma$y][0x0] == nkzv6h) {
                            vn6h[bcma$y][0x1] = 0x1;
                            break;
                        }
                    }
                }
            }
            window[a[37577]](window[a[37578]], a[44266]) >= 0x0 ? wx[a[44267]]({
                'withSubscriptions': !![],
                'success': function (wo4u_e) {
                    var y$0cbo = wo4u_e[a[44268]][a[44269]];
                    if (y$0cbo) {
                        console[a[471]](a[44270]), console[a[471]](y$0cbo);
                        for (var jnfxs in $bcm) {
                            if (y$0cbo[$bcm[jnfxs]] == a[44265]) {
                                var ac9b$m = Number(jnfxs);
                                for (var y0bo$c = 0x0; y0bo$c < vn6h[a[335]]; y0bo$c++) {
                                    if (vn6h[y0bo$c][0x0] == ac9b$m) {
                                        vn6h[y0bo$c][0x1] = 0x2;
                                        break;
                                    }
                                }
                            }
                        }
                        console[a[471]](vn6h), zk6dqh && zk6dqh(vn6h);
                    } else console[a[471]](a[44271]), console[a[471]](wo4u_e), console[a[471]](vn6h), zk6dqh && zk6dqh(vn6h);
                },
                'fail': function () {
                    console[a[471]](a[44272]), console[a[471]](vn6h), zk6dqh && zk6dqh(vn6h);
                }
            }) : (console[a[471]](a[44273] + window[a[37578]]), console[a[471]](vn6h), zk6dqh && zk6dqh(vn6h));
        })) : (console[a[471]](a[44274] + window[a[37578]]), console[a[471]](vn6h), zk6dqh && zk6dqh(vn6h)), wx[a[44275]](c0yo_);
    }
    wx[a[44276]](c0yo_);
}, window[a[44277]] = {
    'isSuccess': ![],
    'level': a[33175],
    'isCharging': ![]
}, window[a[15162]] = function (njzs) {
    wx[a[37653]]({
        'success': function (zshnvj) {
            var dtq8r6 = window[a[44277]];
            dtq8r6[a[44278]] = !![], dtq8r6[a[5364]] = Number(zshnvj[a[5364]])[a[4946]](0x0), dtq8r6[a[37656]] = zshnvj[a[37656]], njzs && njzs(dtq8r6[a[44278]], dtq8r6[a[5364]], dtq8r6[a[37656]]);
        },
        'fail': function (cam9$) {
            console[a[471]](a[44279], cam9$[a[28565]]);
            var e04w_ = window[a[44277]];
            njzs && njzs(e04w_[a[44278]], e04w_[a[5364]], e04w_[a[37656]]);
        }
    });
}, window[a[13104]] = function (g21wu) {
    wx[a[13104]]({
        'success': function (qd8tk) {
            g21wu && g21wu(!![], qd8tk);
        },
        'fail': function (f21xj) {
            g21wu && g21wu(![], f21xj);
        }
    });
}, window[a[13106]] = function (bm0$c) {
    if (bm0$c) wx[a[13106]](bm0$c);
}, window[a[28544]] = function (dqtk68) {
    wx[a[28544]](dqtk68);
}, window[a[584]] = function (nvjzkh, $0bcm, _eg2wu, b$cm0y, fgu21w, yob$0, kd8q, _wge) {
    if (b$cm0y == undefined) b$cm0y = 0x1;
    wx[a[1054]]({
        'url': nvjzkh,
        'method': kd8q || a[28556],
        'responseType': a[5149],
        'data': $0bcm,
        'header': { 'content-type': _wge || a[39275] },
        'success': function (hdzqk) {
            DEBUG && console[a[471]](a[44280], nvjzkh, info, hdzqk);
            if (hdzqk && hdzqk[a[28563]] == 0xc8) {
                var zk68qd = hdzqk[a[521]];
                !yob$0 || yob$0(zk68qd) ? _eg2wu && _eg2wu(zk68qd) : window[a[44281]](nvjzkh, $0bcm, _eg2wu, b$cm0y, fgu21w, yob$0, hdzqk);
            } else window[a[44281]](nvjzkh, $0bcm, _eg2wu, b$cm0y, fgu21w, yob$0, hdzqk);
        },
        'fail': function (u4o_) {
            DEBUG && console[a[471]](a[44282], nvjzkh, info, u4o_), window[a[44281]](nvjzkh, $0bcm, _eg2wu, b$cm0y, fgu21w, yob$0, u4o_);
        },
        'complete': function () {}
    });
}, window[a[44281]] = function (cab9, kd6t, xfg2u1, $myacb, i357, ybc$0m, jxvhs) {
    $myacb - 0x1 > 0x0 ? setTimeout(function () {
        window[a[584]](cab9, kd6t, xfg2u1, $myacb - 0x1, i357, ybc$0m);
    }, 0x3e8) : i357 && i357(JSON[a[5240]]({
        'url': cab9,
        'response': jxvhs
    }));
}, window[a[44283]] = function (c0_yo4, bo40, snxjf1, $0cybo, uo_we, woeu_4, t86dqr) {
    !snxjf1 && (snxjf1 = {});
    var wu_o = Math[a[363]](Date[a[642]]() / 0x3e8);
    snxjf1[a[1470]] = wu_o, snxjf1[a[37947]] = bo40;
    var t57r38 = Object[a[334]](snxjf1)[a[534]](),
        am$cb = '',
        eoy0_4 = '';
    for (var rpt3 = 0x0; rpt3 < t57r38[a[335]]; rpt3++) {
        am$cb = am$cb + (rpt3 == 0x0 ? '' : '&') + t57r38[rpt3] + snxjf1[t57r38[rpt3]], eoy0_4 = eoy0_4 + (rpt3 == 0x0 ? '' : '&') + t57r38[rpt3] + '=' + encodeURIComponent(snxjf1[t57r38[rpt3]]);
    }
    am$cb = am$cb + j1E[a[44060]];
    var coy_0 = a[44284] + md5(am$cb);
    send(c0_yo4 + '?' + eoy0_4 + (eoy0_4 == '' ? '' : '&') + coy_0, null, $0cybo, uo_we, woeu_4, t86dqr || function (zhnjkv) {
        return zhnjkv[a[1942]] == a[10823];
    }, null, a[37470]);
}, window[a[44285]] = function (jfns1x, ca$b9) {
    var wu4eg_ = 0x0;
    j1E[a[28944]] && (wu4eg_ = j1E[a[28944]][a[12719]]), sendApi(j1E[a[44056]], a[44286], {
        'partnerId': j1E[a[13741]],
        'gamePkg': j1E[a[28950]],
        'logTime': Math[a[363]](Date[a[642]]() / 0x3e8),
        'platformUid': j1E[a[28951]],
        'type': jfns1x,
        'serverId': wu4eg_
    }, null, 0x2, null, function () {
        return !![];
    });
}, window[a[44287]] = function (f12sj) {
    sendApi(j1E[a[44054]], a[44288], {
        'partner_id': j1E[a[13741]],
        'uid': j1E[a[28948]],
        'version': j1E[a[6089]],
        'game_pkg': j1E[a[28950]],
        'device': j1E[a[28952]]
    }, j1EBM, jBE1, jEM);
}, window[a[44289]] = function (oyc40) {
    if (oyc40 && oyc40[a[1942]] === a[10823] && oyc40[a[521]]) {
        oyc40[a[521]][a[441]]({
            'id': -0x2,
            'name': a[44290]
        }), oyc40[a[521]][a[441]]({
            'id': -0x1,
            'name': a[44291]
        }), j1E[a[44292]] = oyc40[a[521]];
        if (window[a[13934]]) window[a[13934]][a[44293]]();
    } else {
        j1E[a[44294]] = ![];
        var kz6d8q = oyc40 ? oyc40[a[1942]] : '';
        window[a[44111]](0x7, a[44295] + kz6d8q), window[a[44082]](a[44296] + kz6d8q);
    }
}, window[a[44297]] = function (xf1njs) {
    sendApi(j1E[a[44054]], a[44298], {
        'partner_id': j1E[a[13741]],
        'uid': j1E[a[28948]],
        'version': j1E[a[6089]],
        'game_pkg': j1E[a[28950]],
        'device': j1E[a[28952]]
    }, jM1B, jBE1, jEM);
}, window[a[44299]] = function (vhk6zd) {
    j1E[a[44300]] = ![];
    if (vhk6zd && vhk6zd[a[1942]] === a[10823] && vhk6zd[a[521]]) {
        for (var fxj12 = 0x0; fxj12 < vhk6zd[a[521]][a[335]]; fxj12++) {
            vhk6zd[a[521]][fxj12][a[665]] = j1BM(vhk6zd[a[521]][fxj12]);
        }
        j1E[a[44063]][-0x1] = window[a[44301]](vhk6zd[a[521]]), window[a[13934]][a[44302]](-0x1);
    } else {
        var dvhk = vhk6zd ? vhk6zd[a[1942]] : '';
        window[a[44111]](0x8, a[44303] + dvhk), window[a[44082]](a[44304] + dvhk);
    }
}, window[a[44305]] = function (zhkjv) {
    sendApi(j1E[a[44054]], a[44298], {
        'partner_id': j1E[a[13741]],
        'uid': j1E[a[28948]],
        'version': j1E[a[6089]],
        'game_pkg': j1E[a[28950]],
        'device': j1E[a[28952]]
    }, zhkjv, jBE1, jEM);
}, window[a[44306]] = function (dqt8r, hkdz) {
    sendApi(j1E[a[44054]], a[44307], {
        'partner_id': j1E[a[13741]],
        'uid': j1E[a[28948]],
        'version': j1E[a[6089]],
        'game_pkg': j1E[a[28950]],
        'device': j1E[a[28952]],
        'server_group_id': hkdz
    }, jB1M, jBE1, jEM);
}, window[a[44308]] = function (knzjv) {
    j1E[a[44300]] = ![];
    if (knzjv && knzjv[a[1942]] === a[10823] && knzjv[a[521]] && knzjv[a[521]][a[521]]) {
        var c$bo0y = knzjv[a[521]][a[44309]],
            s1fxg = [];
        for (var fg2uw1 = 0x0; fg2uw1 < knzjv[a[521]][a[521]][a[335]]; fg2uw1++) {
            knzjv[a[521]][a[521]][fg2uw1][a[665]] = j1BM(knzjv[a[521]][a[521]][fg2uw1]), (s1fxg[a[335]] == 0x0 || knzjv[a[521]][a[521]][fg2uw1][a[665]] != 0x0) && (s1fxg[s1fxg[a[335]]] = knzjv[a[521]][a[521]][fg2uw1]);
        }
        j1E[a[44063]][c$bo0y] = window[a[44301]](s1fxg), window[a[13934]][a[44302]](c$bo0y);
    } else {
        var o4u_w = knzjv ? knzjv[a[1942]] : '';
        window[a[44111]](0x9, a[44310] + o4u_w), window[a[44082]](a[44311] + o4u_w);
    }
}, window[a[44312]] = function (xf21u) {
    sendApi(j1E[a[44054]], a[44313], {
        'partner_id': j1E[a[13741]],
        'uid': j1E[a[28948]],
        'version': j1E[a[6089]],
        'game_pkg': j1E[a[28950]],
        'device': j1E[a[28952]]
    }, reqServerRecommendCallBack, jBE1, jEM);
}, window[a[44314]] = function (nfvxjs) {
    j1E[a[44300]] = ![];
    if (nfvxjs && nfvxjs[a[1942]] === a[10823] && nfvxjs[a[521]]) {
        for (var j2fxs = 0x0; j2fxs < nfvxjs[a[521]][a[335]]; j2fxs++) {
            nfvxjs[a[521]][j2fxs][a[665]] = j1BM(nfvxjs[a[521]][j2fxs]);
        }
        j1E[a[44063]][-0x2] = window[a[44301]](nfvxjs[a[521]]), window[a[13934]][a[44302]](-0x2);
    } else {
        var xs12fg = nfvxjs ? nfvxjs[a[1942]] : '';
        window[a[44111]](0xa, a[44315] + xs12fg), alert(a[44316] + xs12fg);
    }
}, window[a[44301]] = function (kv6hn) {
    return kv6hn;
}, window[a[44317]] = function (ug1, ge21u) {
    ug1 = ug1 || j1E[a[28944]][a[12719]], sendApi(j1E[a[44054]], a[44318], {
        'type': '4',
        'game_pkg': j1E[a[28950]],
        'server_id': ug1
    }, ge21u);
}, window[a[44319]] = function (w2_gue, tq58rd, kqt, dqhzk6) {
    kqt = kqt || j1E[a[28944]][a[12719]], sendApi(j1E[a[44054]], a[44320], {
        'type': w2_gue,
        'game_pkg': tq58rd,
        'server_id': kqt
    }, dqhzk6);
}, window[a[44321]] = function (t5r8, z6vkdh) {
    sendApi(j1E[a[44054]], a[44322], { 'game_pkg': t5r8 }, z6vkdh);
}, window[a[44323]] = function (s2fx) {
    if (s2fx) {
        if (s2fx[a[665]] == 0x1) {
            if (s2fx[a[44324]] == 0x3) return 0x3;else return s2fx[a[44324]] == 0x1 ? 0x2 : 0x1;
        } else return s2fx[a[665]] == 0x0 ? 0x0 : -0x1;
    }
    return -0x1;
}, window[a[44325]] = function (q6k8td, gxu1f) {
    j1E[a[44326]] = {
        'step': q6k8td,
        'server_id': gxu1f
    }, jM1BE({ 'title': a[44327] }), sendApi(j1E[a[44054]], a[44328], {
        'partner_id': j1E[a[13741]],
        'uid': j1E[a[28948]],
        'game_pkg': j1E[a[28950]],
        'server_id': gxu1f,
        'platform': j1E[a[28902]],
        'platform_uid': j1E[a[28951]],
        'check_login_time': j1E[a[44177]],
        'check_login_sign': j1E[a[44176]],
        'version_name': j1E[a[5258]]
    }, jEM1B, jBE1, jEM, function (xgfs) {
        return xgfs[a[1942]] == a[10823] || xgfs[a[637]] == a[44329] || xgfs[a[637]] == a[44330];
    });
}, window[a[44331]] = function (y_0oe) {
    var fxvj = this;
    if (y_0oe && y_0oe[a[1942]] === a[10823] && y_0oe[a[521]]) {
        var dh6zvk = j1E[a[28944]];
        dh6zvk[a[44332]] = j1E[a[44064]], dh6zvk[a[12702]] = String(y_0oe[a[521]][a[44333]]), dh6zvk[a[28904]] = parseInt(y_0oe[a[521]][a[1470]]);
        if (y_0oe[a[521]][a[28903]]) dh6zvk[a[28903]] = parseInt(y_0oe[a[521]][a[28903]]);else dh6zvk[a[28903]] = parseInt(y_0oe[a[521]][a[12719]]);
        dh6zvk[a[44334]] = 0x0, dh6zvk[a[5254]] = j1E[a[44224]], dh6zvk[a[44335]] = y_0oe[a[521]][a[44336]], dh6zvk[a[44337]] = y_0oe[a[521]][a[44337]];
        if (y_0oe[a[521]][a[28908]]) dh6zvk[a[28908]] = parseInt(y_0oe[a[521]][a[28908]]);
        console[a[471]](a[44338] + JSON[a[5240]](dh6zvk[a[44337]])), j1E[a[1235]] == 0x1 && dh6zvk[a[44337]] && dh6zvk[a[44337]][a[44339]] == 0x1 && (j1E[a[44340]] = 0x1, window[a[37574]][a[706]][a[44341]]()), jEBM1();
    } else {
        if (j1E[a[44326]][a[5171]] >= 0x3) {
            var zhsnv = y_0oe ? y_0oe[a[1942]] : '';
            window[a[44111]](0xc, a[44342] + zhsnv), jEM(JSON[a[5240]](y_0oe)), window[a[44082]](a[44343] + zhsnv);
        } else sendApi(j1E[a[44054]], a[44155], {
            'platform': j1E[a[44052]],
            'partner_id': j1E[a[13741]],
            'token': j1E[a[44153]],
            'game_pkg': j1E[a[28950]],
            'deviceId': j1E[a[28952]],
            'scene': a[44156] + j1E[a[44062]]
        }, function (wge4u) {
            if (!wge4u || wge4u[a[1942]] != a[10823]) {
                window[a[44082]](a[44173] + wge4u && wge4u[a[1942]]);
                return;
            }
            j1E[a[44176]] = String(wge4u[a[12702]]), j1E[a[44177]] = String(wge4u[a[1470]]), setTimeout(function () {
                jEMB1(j1E[a[44326]][a[5171]] + 0x1, j1E[a[44326]][a[12719]]);
            }, 0x5dc);
        }, jBE1, jEM, function (gf12w) {
            return gf12w[a[1942]] == a[10823] || gf12w[a[1942]] == a[29292];
        });
    }
}, window[a[44344]] = function () {
    ServerLoading[a[706]][a[44215]](j1E[a[1235]]), window[a[44071]] = !![], window[a[37600]]();
}, window[a[37599]] = function () {
    if (window[a[37598]] && window[a[37606]] && window[a[44072]] && window[a[44073]] && window[a[44074]] && window[a[44076]]) {
        if (!window[a[37450]][a[706]]) {
            console[a[471]](a[44345] + window[a[37450]][a[706]]);
            var eg_4w = wx[a[28527]](),
                f1gxs2 = eg_4w[a[1396]] ? eg_4w[a[1396]] : 0x0,
                bym$ca = {
                'cdn': window[a[5257]][a[5254]],
                'spareCdn': window[a[5257]][a[28574]],
                'newRegister': window[a[5257]][a[1235]],
                'wxPC': window[a[5257]][a[28576]],
                'wxIOS': window[a[5257]][a[1695]],
                'wxAndroid': window[a[5257]][a[12543]],
                'wxParam': {
                    'limitLoad': window[a[5257]][a[37644]],
                    'benchmarkLevel': window[a[5257]][a[37645]],
                    'wxFrom': window[a[1130]][a[349]] == a[44346] ? 0x1 : 0x0,
                    'wxSDKVersion': window[a[37578]]
                },
                'configType': window[a[5257]][a[5256]],
                'exposeType': window[a[5257]][a[1318]],
                'scene': f1gxs2,
                'video_type': window[a[5257]][a[29090]],
                'ad_flag': window[a[5257]][a[29089]]
            };
            if (window[a[44226]]) for (var bmyac in window[a[44226]]) {
                if (!bym$ca[bmyac]) bym$ca[bmyac] = window[a[44226]][bmyac];
            }
            new window[a[37450]](bym$ca, window[a[5257]][a[660]], window[a[44047]]);
        }
    }
}, window[a[37600]] = function () {
    if (window[a[37598]] && window[a[37606]] && window[a[44072]] && window[a[44073]] && window[a[44074]] && window[a[44076]] && window[a[44071]] && window[a[44075]]) {
        jM1EB();
        if (!jEB1) {
            jEB1 = !![];
            if (!window[a[37450]][a[706]]) window[a[37599]]();
            var fsjxnv = 0x0,
                q8r6t = wx[a[44347]]();
            q8r6t && (window[a[5257]][a[37640]] && (fsjxnv = q8r6t[a[894]]), console[a[637]](a[44348] + q8r6t[a[894]] + a[44349] + q8r6t[a[1968]] + a[44350] + q8r6t[a[1970]] + a[44351] + q8r6t[a[1969]] + a[44352] + q8r6t[a[740]] + a[44353] + q8r6t[a[741]]));
            var weg12u = {};
            for (const qd6k8z in j1E[a[28944]]) {
                weg12u[qd6k8z] = j1E[a[28944]][qd6k8z];
            }
            var $bco0 = {
                'channel': window[a[5257]][a[13750]],
                'account': window[a[5257]][a[28948]],
                'userId': window[a[5257]][a[13739]],
                'cdn': window[a[5257]][a[5254]],
                'data': window[a[5257]][a[521]],
                'package': window[a[5257]][a[511]],
                'newRegister': window[a[5257]][a[1235]],
                'pkgName': window[a[5257]][a[28950]],
                'partnerId': window[a[5257]][a[13741]],
                'platform_uid': window[a[5257]][a[28951]],
                'deviceId': window[a[5257]][a[28952]],
                'selectedServer': weg12u,
                'configType': window[a[5257]][a[5256]],
                'exposeType': window[a[5257]][a[1318]],
                'debugUsers': window[a[5257]][a[13887]],
                'wxMenuTop': fsjxnv,
                'wxShield': window[a[5257]][a[1340]],
                'encryptParam': window[a[5257]][a[29097]],
                'wx_channel': window[a[5257]][a[29095]],
                'zsy_tp_state': window[a[5257]][a[29096]]
            };
            if (window[a[44226]]) for (var d5rqt8 in window[a[44226]]) {
                $bco0[d5rqt8] = window[a[44226]][d5rqt8];
            }
            window[a[37450]][a[706]][a[28966]]($bco0);
            if (j1E[a[28944]] && j1E[a[28944]][a[12719]]) localStorage[a[1061]](a[44179] + j1E[a[28950]] + j1E[a[28948]], j1E[a[28944]][a[12719]]);
        }
    } else console[a[637]](a[44354] + window[a[37598]] + a[44355] + window[a[37606]] + a[44356] + window[a[44072]] + a[44357] + window[a[44073]] + a[44358] + window[a[44074]] + a[44359] + window[a[44076]] + a[44360] + window[a[44071]] + a[44361] + window[a[44075]]);
};