var a = wx.$y;
var sdk_conf = {
  game_id: 256,
  game_pkg: a[37550],
  partner_label: a[37551],
  partner_id: a[37552],
  game_ver: a[37553],
  is_auth: false, //授权登录
  partner_game_id: 1290,
  partner_app_key: a[37554]
};

module.exports = sdk_conf;