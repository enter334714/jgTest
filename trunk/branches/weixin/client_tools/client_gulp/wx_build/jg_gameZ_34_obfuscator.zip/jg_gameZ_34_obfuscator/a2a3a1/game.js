var a = wx.$y;
import 'amain.js';