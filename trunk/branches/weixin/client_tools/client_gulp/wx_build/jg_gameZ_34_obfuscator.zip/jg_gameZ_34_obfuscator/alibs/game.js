var a = wx.$y;
require(a[45036]);