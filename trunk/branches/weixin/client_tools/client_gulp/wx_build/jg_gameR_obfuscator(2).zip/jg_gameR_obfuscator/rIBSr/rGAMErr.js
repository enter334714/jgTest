var I = wx.$R;
console[I[280001]](I[280002]), window[I[280003]], wx[I[280004]](function (nc) {
  if (nc) {
    if (nc[I[280005]]) {
      var dcpnq = window[I[280006]][I[280007]][I[280008]](new RegExp(/\./, 'g'), '_'),
          _uh6c = nc[I[280005]],
          cndfpq = _uh6c[I[280009]](/(rmmmr\/rGAMErr.js:)[0-9]{1,60}(:)/g);if (cndfpq) for (var jiyo8 = 0x0; jiyo8 < cndfpq[I[280010]]; jiyo8++) {
        if (cndfpq[jiyo8] && cndfpq[jiyo8][I[280010]] > 0x0) {
          var fdpgq = parseInt(cndfpq[jiyo8][I[280008]](I[280011], '')[I[280008]](':', ''));_uh6c = _uh6c[I[280008]](cndfpq[jiyo8], cndfpq[jiyo8][I[280008]](':' + fdpgq + ':', ':' + (fdpgq - 0x2) + ':'));
        }
      }_uh6c = _uh6c[I[280008]](new RegExp(I[280012], 'g'), I[280013] + dcpnq + I[280014]), _uh6c = _uh6c[I[280008]](new RegExp(I[280015], 'g'), I[280013] + dcpnq + I[280014]), nc[I[280005]] = _uh6c;
    }var u$a19 = { 'id': window['_rYE'][I[280016]], 'role': window['_rYE'][I[280017]], 'level': window['_rYE'][I[280018]], 'user': window['_rYE'][I[280019]], 'version': window['_rYE'][I[280020]], 'gamever': window[I[280006]][I[280007]], 'cdn': window['_rYE'][I[280021]], 'serverid': window['_rYE'][I[280022]] ? window['_rYE'][I[280022]][I[280023]] : 0x0, 'systemInfo': window[I[280024]], 'error': I[280025], 'stack': nc ? nc[I[280005]] : '' },
        qndfep = JSON[I[280026]](u$a19);console[I[280027]](I[280028] + qndfep), (!window[I[280003]] || window[I[280003]] != u$a19[I[280027]]) && (window[I[280003]] = u$a19[I[280027]], window['_rSY'](u$a19));
  }
});import 'rsfs32r.js';import 'rr12rr.js';window[I[280029]] = require(I[280030]);import 'rINDEXr.js';import 'rrLIB12r.js';import 'rWXMsadrr.js';import 'rrINITMINrr.js';import 'SyMiniTool.js';console[I[280001]](I[280031]), console[I[280001]](I[280032]), _rSYFE({ 'title': I[280033] });var r_oywk = { '_rUSEYF': !![] };new window[I[280034]](r_oywk), window[I[280034]][I[280035]]['_rUFYES']();if (window['_rUSYEF']) clearInterval(window['_rUSYEF']);window['_rUSYEF'] = null, window['_rUFESY'] = function (qfdeg, rme7gw) {
  if (!qfdeg || !rme7gw) return 0x0;qfdeg = qfdeg[I[280036]]('.'), rme7gw = rme7gw[I[280036]]('.');const rg7mwe = Math[I[280037]](qfdeg[I[280010]], rme7gw[I[280010]]);while (qfdeg[I[280010]] < rg7mwe) {
    qfdeg[I[280038]]('0');
  }while (rme7gw[I[280010]] < rg7mwe) {
    rme7gw[I[280038]]('0');
  }for (var wiyo8 = 0x0; wiyo8 < rg7mwe; wiyo8++) {
    const grm = parseInt(qfdeg[wiyo8]),
          cdqnfp = parseInt(rme7gw[wiyo8]);if (grm > cdqnfp) return 0x1;else {
      if (grm < cdqnfp) return -0x1;
    }
  }return 0x0;
}, window[I[280039]] = wx[I[280040]]()[I[280039]], console[I[280041]](I[280042] + window[I[280039]]);var r_ndpef = wx[I[280043]]();r_ndpef[I[280044]](function (fnc6h) {
  console[I[280041]](I[280045] + fnc6h[I[280046]]);
}), r_ndpef[I[280047]](function () {
  wx[I[280048]]({ 'title': I[280049], 'content': I[280050], 'showCancel': ![], 'success': function (b1$u9a) {
      r_ndpef[I[280051]]();
    } });
}), r_ndpef[I[280052]](function () {
  console[I[280041]](I[280053]);
}), window['_rUFEYS'] = function () {
  console[I[280041]](I[280054]);var szvl = wx[I[280055]]({ 'name': I[280056], 'success': function (au9b$1) {
      console[I[280041]](I[280057]), console[I[280041]](au9b$1), au9b$1 && au9b$1[I[280058]] == I[280059] ? (window['_rEF'] = !![], window['_rEFYS'](), window['_rEYSF']()) : setTimeout(function () {
        window['_rUFEYS']();
      }, 0x1f4);
    }, 'fail': function (s3l0vt) {
      console[I[280041]](I[280060]), console[I[280041]](s3l0vt), setTimeout(function () {
        window['_rUFEYS']();
      }, 0x1f4);
    } });szvl && szvl[I[280061]](xs2i => {});
}, window['_rUYSEF'] = function () {
  console[I[280041]](I[280062]);var lzs2 = wx[I[280055]]({ 'name': I[280063], 'success': function (mgwre) {
      console[I[280041]](I[280064]), console[I[280041]](mgwre), mgwre && mgwre[I[280058]] == I[280059] ? (window['_rYFE'] = !![], window['_rEFYS'](), window['_rEYSF']()) : setTimeout(function () {
        window['_rUYSEF']();
      }, 0x1f4);
    }, 'fail': function (jzo2xi) {
      console[I[280041]](I[280065]), console[I[280041]](jzo2xi), setTimeout(function () {
        window['_rUYSEF']();
      }, 0x1f4);
    } });lzs2 && lzs2[I[280061]](_h5nc => {});
}, window[I[280066]] = function () {
  window['_rUFESY'](window[I[280039]], I[280067]) >= 0x0 ? (console[I[280041]](I[280068] + window[I[280039]] + I[280069]), window['_rYS'](), window['_rUFEYS'](), window['_rUYSEF']()) : (window['_rYES'](I[280070], window[I[280039]]), wx[I[280048]]({ 'title': I[280071], 'content': I[280072] }));
}, window[I[280024]] = '', wx[I[280073]]({ 'success'(_b1au) {
    window[I[280024]] = I[280074] + _b1au[I[280075]] + I[280076] + _b1au[I[280077]] + I[280078] + _b1au[I[280079]] + I[280080] + _b1au[I[280081]] + I[280082] + _b1au[I[280083]] + I[280084] + _b1au[I[280039]] + I[280085] + _b1au[I[280086]], console[I[280041]](window[I[280024]]), console[I[280041]](I[280087] + _b1au[I[280088]] + I[280089] + _b1au[I[280090]] + I[280091] + _b1au[I[280092]] + I[280093] + _b1au[I[280094]] + I[280095] + _b1au[I[280096]] + I[280097] + _b1au[I[280098]] + I[280099] + (_b1au[I[280100]] ? _b1au[I[280100]][I[280101]] + ',' + _b1au[I[280100]][I[280102]] + ',' + _b1au[I[280100]][I[280103]] + ',' + _b1au[I[280100]][I[280104]] : ''));var t3z2 = _b1au[I[280081]] ? _b1au[I[280081]][I[280105]]() : '',
        fdnqp = _b1au[I[280077]] ? _b1au[I[280077]][I[280105]]()[I[280008]]('\x20', '') : '';window['_rYE'][I[280106]] = t3z2[I[280107]](I[280108]) != -0x1, window['_rYE'][I[280109]] = t3z2[I[280107]](I[280110]) != -0x1, window['_rYE'][I[280111]] = t3z2[I[280107]](I[280108]) != -0x1 || t3z2[I[280107]](I[280110]) != -0x1, window['_rYE'][I[280112]] = t3z2[I[280107]](I[280113]) != -0x1 || t3z2[I[280107]](I[280114]) != -0x1, window['_rYE'][I[280115]] = _b1au[I[280083]] ? _b1au[I[280083]][I[280105]]() : '', window['_rYE']['_rUSFEY'] = ![], window['_rYE']['_rUSYFE'] = 0x2;if (t3z2[I[280107]](I[280110]) != -0x1) {
      if (_b1au[I[280086]] >= 0x18) window['_rYE']['_rUSYFE'] = 0x3;else window['_rYE']['_rUSYFE'] = 0x2;
    } else {
      if (t3z2[I[280107]](I[280108]) != -0x1) {
        if (_b1au[I[280086]] && _b1au[I[280086]] >= 0x14) window['_rYE']['_rUSYFE'] = 0x3;else {
          if (fdnqp[I[280107]](I[280116]) != -0x1 || fdnqp[I[280107]](I[280117]) != -0x1 || fdnqp[I[280107]](I[280118]) != -0x1 || fdnqp[I[280107]](I[280119]) != -0x1 || fdnqp[I[280107]](I[280120]) != -0x1) window['_rYE']['_rUSYFE'] = 0x2;else window['_rYE']['_rUSYFE'] = 0x3;
        }
      } else window['_rYE']['_rUSYFE'] = 0x2;
    }console[I[280041]](I[280121] + window['_rYE']['_rUSFEY'] + I[280122] + window['_rYE']['_rUSYFE']);
  } }), wx[I[280123]]({ 'success': function (_c5) {
    console[I[280041]](I[280124] + _c5[I[280125]] + I[280126] + _c5[I[280127]]);
  } }), wx[I[280128]]({ 'success': function (kyw8oi) {
    console[I[280041]](I[280129] + kyw8oi[I[280130]]);
  } }), wx[I[280131]]({ 'keepScreenOn': !![] }), wx[I[280132]](function (fh5nc6) {
  console[I[280041]](I[280129] + fh5nc6[I[280130]] + I[280133] + fh5nc6[I[280134]]);
}), wx[I[280135]](function (eqdg) {
  window['_rFS'] = eqdg, window['_rESF'] && window['_rFS'] && (console[I[280001]](I[280136] + window['_rFS'][I[280137]]), window['_rESF'](window['_rFS']), window['_rFS'] = null);
}), window['_rUYFES'] = 0x0, window[I[280138]] = null, wx[I[280139]](function () {
  window['_rUYFES']++, wx[I[280140]]();if (window['_rUYFES'] >= 0x2) {
    window['_rUYFES'] = 0x0, console[I[280027]](I[280141]), wx[I[280142]]('0', 0x1);if (window['_rYE'] && window['_rYE'][I[280106]]) window['_rYES'](I[280143], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});