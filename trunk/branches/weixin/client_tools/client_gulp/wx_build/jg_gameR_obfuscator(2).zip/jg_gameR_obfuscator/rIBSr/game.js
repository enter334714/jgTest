var I = wx.$R;
require(I[280000]);