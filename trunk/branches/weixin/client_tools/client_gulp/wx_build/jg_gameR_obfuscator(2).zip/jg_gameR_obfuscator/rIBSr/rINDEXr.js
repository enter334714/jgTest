var I = wx.$R;
import r_cdf56n from '../RskRR/rs6kr.js';window[I[280144]] = { 'wxVersion': window[I[280006]][I[280007]] }, window[I[280145]] = ![], window['_rEY'] = 0x1, window[I[280146]] = 0x1, window['_rFYE'] = !![], window[I[280147]] = !![], window['_rUSFYE'] = '', window['_rYE'] = { 'base_cdn': I[280148], 'cdn': I[280148] }, _rYE[I[280149]] = {}, _rYE[I[280150]] = '0', _rYE[I[280079]] = window[I[280144]][I[280151]], _rYE[I[280114]] = '', _rYE['os'] = '1', _rYE[I[280152]] = I[280153], _rYE[I[280154]] = I[280155], _rYE[I[280156]] = I[280157], _rYE[I[280158]] = I[280159], _rYE[I[280160]] = I[280161], _rYE[I[280162]] = '1', _rYE[I[280163]] = '', _rYE[I[280164]] = '', _rYE[I[280165]] = 0x0, _rYE[I[280166]] = {}, _rYE[I[280167]] = parseInt(_rYE[I[280162]]), _rYE[I[280168]] = _rYE[I[280162]], _rYE[I[280022]] = {}, _rYE['_rSY'] = I[280169], _rYE[I[280170]] = ![], _rYE[I[280171]] = I[280172], _rYE[I[280173]] = Date[I[280174]](), _rYE[I[280175]] = I[280176], _rYE[I[280177]] = '_a', _rYE[I[280178]] = 0x2, _rYE[I[280020]] = 0x7c1, _rYE[I[280151]] = window[I[280144]][I[280151]], _rYE[I[280179]] = ![], _rYE[I[280106]] = ![], _rYE[I[280109]] = ![], _rYE[I[280112]] = ![], window['_rFEY'] = 0x5, window['_rFE'] = ![], window['_rEF'] = ![], window['_rYFE'] = ![], window[I[280180]] = ![], window[I[280181]] = ![], window['_rYEF'] = ![], window['_rFY'] = ![], window['_rYF'] = ![], window['_rEFY'] = ![], window[I[280182]] = function (m8woyk) {
  console[I[280041]](I[280182], m8woyk), wx[I[280183]]({}), wx[I[280048]]({ 'title': I[280071], 'content': m8woyk, 'success'(rgw) {
      if (rgw[I[280184]]) console[I[280041]](I[280185]);else rgw[I[280186]] && console[I[280041]](I[280187]);
    } });
}, window['_rSFYE'] = function (gr7mqe) {
  console[I[280041]](I[280188], gr7mqe), _rSYEF(), wx[I[280048]]({ 'title': I[280071], 'content': gr7mqe, 'confirmText': I[280189], 'cancelText': I[280190], 'success'(r8k7wm) {
      if (r8k7wm[I[280184]]) window['_rYS']();else r8k7wm[I[280186]] && (console[I[280041]](I[280191]), wx[I[280192]]({}));
    } });
}, window[I[280193]] = function (_65n) {
  console[I[280041]](I[280193], _65n), wx[I[280048]]({ 'title': I[280071], 'content': _65n, 'confirmText': I[280194], 'showCancel': ![], 'complete'(gem7q) {
      console[I[280041]](I[280191]), wx[I[280192]]({});
    } });
}, window['_rSFEY'] = ![], window['_rSYFE'] = function (wg7em) {
  window['_rSFEY'] = !![], wx[I[280195]](wg7em);
}, window['_rSYEF'] = function () {
  window['_rSFEY'] && (window['_rSFEY'] = ![], wx[I[280183]]({}));
}, window['_rSEFY'] = function (ba1$94) {
  window[I[280034]][I[280035]]['_rSEFY'](ba1$94);
}, window[I[280196]] = function (_auh, tsvz3) {
  r_cdf56n[I[280196]](_auh, function (_56u1) {
    _56u1 && _56u1[I[280197]] ? _56u1[I[280197]][I[280198]] == 0x1 ? tsvz3(!![]) : (tsvz3(![]), console[I[280001]](I[280199] + _56u1[I[280197]][I[280200]])) : console[I[280041]](I[280196], _56u1);
  });
}, window['_rSEYF'] = function (e7wmrg) {
  console[I[280041]](I[280201], e7wmrg);
}, window['_rSYE'] = function (z2xji) {}, window['_rSEY'] = function (s2jiz, stvl3z, io8wky) {}, window['_rSE'] = function (ztsv) {
  console[I[280041]](I[280202], ztsv), window[I[280034]][I[280035]][I[280203]](), window[I[280034]][I[280035]][I[280204]](), window[I[280034]][I[280035]][I[280205]]();
}, window['_rES'] = function (dnfp) {
  window['_rSFYE'](I[280206]);var h6u5c = { 'id': window['_rYE'][I[280016]], 'role': window['_rYE'][I[280017]], 'level': window['_rYE'][I[280018]], 'account': window['_rYE'][I[280019]], 'version': window['_rYE'][I[280020]], 'cdn': window['_rYE'][I[280021]], 'pkgName': window['_rYE'][I[280163]], 'gamever': window[I[280006]][I[280007]], 'serverid': window['_rYE'][I[280022]] ? window['_rYE'][I[280022]][I[280023]] : 0x0, 'systemInfo': window[I[280024]], 'error': I[280207], 'stack': dnfp ? dnfp : I[280206] },
      jz2oi = JSON[I[280026]](h6u5c);console[I[280027]](I[280208] + jz2oi), window['_rSY'](jz2oi);
}, window['_rYSE'] = function (rqgem) {
  var vt3lzs = JSON[I[280209]](rqgem);vt3lzs[I[280210]] = window[I[280006]][I[280007]], vt3lzs[I[280211]] = window['_rYE'][I[280022]] ? window['_rYE'][I[280022]][I[280023]] : 0x0, vt3lzs[I[280024]] = window[I[280024]];var myk8o = JSON[I[280026]](vt3lzs);console[I[280027]](I[280212] + myk8o), window['_rSY'](myk8o);
}, window['_rYES'] = function (c_nh, jioy8) {
  var ix2zjo = { 'id': window['_rYE'][I[280016]], 'role': window['_rYE'][I[280017]], 'level': window['_rYE'][I[280018]], 'account': window['_rYE'][I[280019]], 'version': window['_rYE'][I[280020]], 'cdn': window['_rYE'][I[280021]], 'pkgName': window['_rYE'][I[280163]], 'gamever': window[I[280006]][I[280007]], 'serverid': window['_rYE'][I[280022]] ? window['_rYE'][I[280022]][I[280023]] : 0x0, 'systemInfo': window[I[280024]], 'error': c_nh, 'stack': jioy8 },
      wo8iky = JSON[I[280026]](ix2zjo);console[I[280213]](I[280214] + wo8iky), window['_rSY'](wo8iky);
}, window['_rSY'] = function (jxis2) {
  if (window['_rYE'][I[280115]] == I[280215]) return;var b1uha = _rYE['_rSY'] + I[280216] + _rYE[I[280019]];wx[I[280217]]({ 'url': b1uha, 'method': I[280218], 'data': jxis2, 'header': { 'content-type': I[280219], 'cache-control': I[280220] }, 'success': function (dq) {
      DEBUG && console[I[280041]](I[280221], b1uha, jxis2, dq);
    }, 'fail': function (u1b$_a) {
      DEBUG && console[I[280041]](I[280221], b1uha, jxis2, u1b$_a);
    }, 'complete': function () {} });
}, window[I[280222]] = function () {
  function nf6hc() {
    return ((0x1 + Math[I[280223]]()) * 0x10000 | 0x0)[I[280224]](0x10)[I[280225]](0x1);
  }return nf6hc() + nf6hc() + '-' + nf6hc() + '-' + nf6hc() + '-' + nf6hc() + '+' + nf6hc() + nf6hc() + nf6hc();
}, window['_rYS'] = function () {
  console[I[280041]](I[280226]);var y8km = r_cdf56n[I[280227]]();_rYE[I[280168]] = y8km[I[280228]], _rYE[I[280167]] = y8km[I[280228]], _rYE[I[280162]] = y8km[I[280228]], _rYE[I[280163]] = y8km[I[280229]];var r7m8 = { 'game_ver': _rYE[I[280079]] };_rYE[I[280164]] = this[I[280222]](), _rSYFE({ 'title': I[280230] }), r_cdf56n[I[280231]](r7m8, this['_rESY'][I[280232]](this));
}, window['_rESY'] = function (fdpenq) {
  var pedqgf = fdpenq[I[280233]];console[I[280041]](I[280234] + pedqgf + I[280235] + (pedqgf == 0x1) + I[280236] + fdpenq[I[280007]] + I[280237] + window[I[280144]][I[280151]]);if (!fdpenq[I[280007]] || window['_rUFESY'](window[I[280144]][I[280151]], fdpenq[I[280007]]) < 0x0) console[I[280041]](I[280238]), _rYE[I[280154]] = I[280239], _rYE[I[280156]] = I[280240], _rYE[I[280158]] = I[280241], _rYE[I[280021]] = I[280242], _rYE[I[280243]] = I[280244], _rYE[I[280245]] = I[280246], _rYE[I[280179]] = ![];else window['_rUFESY'](window[I[280144]][I[280151]], fdpenq[I[280007]]) == 0x0 ? (console[I[280041]](I[280247]), _rYE[I[280154]] = I[280155], _rYE[I[280156]] = I[280157], _rYE[I[280158]] = I[280159], _rYE[I[280021]] = I[280248], _rYE[I[280243]] = I[280244], _rYE[I[280245]] = I[280249], _rYE[I[280179]] = !![]) : (console[I[280041]](I[280250]), _rYE[I[280154]] = I[280155], _rYE[I[280156]] = I[280157], _rYE[I[280158]] = I[280159], _rYE[I[280021]] = I[280248], _rYE[I[280243]] = I[280244], _rYE[I[280245]] = I[280249], _rYE[I[280179]] = ![]);_rYE[I[280165]] = config[I[280251]] ? config[I[280251]] : 0x0, this['_rFYSE'](), this['_rFYES'](), window[I[280252]] = 0x5, _rSYFE({ 'title': I[280253] }), r_cdf56n[I[280254]](this['_rEYS'][I[280232]](this));
}, window[I[280252]] = 0x5, window['_rEYS'] = function (gwrem7, $91) {
  if (gwrem7 == 0x0 && $91 && $91[I[280255]]) {
    _rYE[I[280256]] = $91[I[280255]];var r7wmge = this;_rSYFE({ 'title': I[280257] }), sendApi(_rYE[I[280154]], I[280258], { 'platform': _rYE[I[280152]], 'partner_id': _rYE[I[280162]], 'token': $91[I[280255]], 'game_pkg': _rYE[I[280163]], 'deviceId': _rYE[I[280164]], 'scene': I[280259] + _rYE[I[280165]] }, this['_rFSYE'][I[280232]](this), _rFEY, _rES);
  } else $91 && $91[I[280058]] && window[I[280252]] > 0x0 && ($91[I[280058]][I[280107]](I[280260]) != -0x1 || $91[I[280058]][I[280107]](I[280261]) != -0x1 || $91[I[280058]][I[280107]](I[280262]) != -0x1 || $91[I[280058]][I[280107]](I[280263]) != -0x1 || $91[I[280058]][I[280107]](I[280264]) != -0x1 || $91[I[280058]][I[280107]](I[280265]) != -0x1) ? (window[I[280252]]--, r_cdf56n[I[280254]](this['_rEYS'][I[280232]](this))) : (window['_rYES'](I[280266], JSON[I[280026]]({ 'status': gwrem7, 'data': $91 })), window['_rSFYE'](I[280267] + ($91 && $91[I[280058]] ? '，' + $91[I[280058]] : '')));
}, window['_rFSYE'] = function (bu_1$) {
  if (!bu_1$) {
    window['_rYES'](I[280268], I[280269]), window['_rSFYE'](I[280270]);return;
  }if (bu_1$[I[280198]] != I[280271]) {
    window['_rYES'](I[280268], JSON[I[280026]](bu_1$)), window['_rSFYE'](I[280272] + bu_1$[I[280198]]);return;
  }_rYE[I[280273]] = String(bu_1$[I[280019]]), _rYE[I[280019]] = String(bu_1$[I[280019]]), _rYE[I[280083]] = String(bu_1$[I[280083]]), _rYE[I[280168]] = String(bu_1$[I[280083]]), _rYE[I[280274]] = String(bu_1$[I[280274]]), _rYE[I[280275]] = String(bu_1$[I[280276]]), _rYE[I[280277]] = String(bu_1$[I[280278]]), _rYE[I[280276]] = '';var yiowk = this;_rSYFE({ 'title': I[280279] }), sendApi(_rYE[I[280154]], I[280280], { 'partner_id': _rYE[I[280162]], 'uid': _rYE[I[280019]], 'version': _rYE[I[280079]], 'game_pkg': _rYE[I[280163]], 'device': _rYE[I[280164]] }, yiowk['_rFSEY'][I[280232]](yiowk), _rFEY, _rES);
}, window['_rFSEY'] = function (pde7q) {
  if (!pde7q) {
    window['_rSFYE'](I[280281]);return;
  }if (pde7q[I[280198]] != I[280271]) {
    window['_rSFYE'](I[280282] + pde7q[I[280198]]);return;
  }if (!pde7q[I[280197]] || pde7q[I[280197]][I[280010]] == 0x0) {
    window['_rSFYE'](I[280283]);return;
  }_rYE[I[280284]] = pde7q[I[280285]], _rYE[I[280022]] = { 'server_id': String(pde7q[I[280197]][0x0][I[280023]]), 'server_name': String(pde7q[I[280197]][0x0][I[280286]]), 'entry_ip': pde7q[I[280197]][0x0][I[280287]], 'entry_port': parseInt(pde7q[I[280197]][0x0][I[280288]]), 'status': _rYFS(pde7q[I[280197]][0x0]), 'start_time': pde7q[I[280197]][0x0][I[280289]], 'cdn': _rYE[I[280021]] }, this['_rEYFS']();
}, window['_rEYFS'] = function () {
  if (_rYE[I[280284]] == 0x1) {
    var t2sjz = _rYE[I[280022]][I[280290]];if (t2sjz === -0x1 || t2sjz === 0x0) {
      window['_rSFYE'](t2sjz === -0x1 ? I[280291] : I[280292]);return;
    }_rESFY(0x0, _rYE[I[280022]][I[280023]]), window[I[280034]][I[280035]][I[280293]](_rYE[I[280284]]);
  } else window[I[280034]][I[280035]][I[280294]](), _rSYEF();window['_rYF'] = !![], window['_rEFYS'](), window['_rEYSF']();
}, window['_rFYSE'] = function () {
  sendApi(_rYE[I[280154]], I[280295], { 'game_pkg': _rYE[I[280163]], 'version_name': _rYE[I[280245]] }, this[I[280296]][I[280232]](this), _rFEY, _rES);
}, window[I[280296]] = function (ky8i) {
  if (!ky8i) {
    window['_rSFYE'](I[280297]);return;
  }if (ky8i[I[280198]] != I[280271]) {
    window['_rSFYE'](I[280298] + ky8i[I[280198]]);return;
  }if (!ky8i[I[280197]] || !ky8i[I[280197]][I[280079]]) {
    window['_rSFYE'](I[280299] + (ky8i[I[280197]] && ky8i[I[280197]][I[280079]]));return;
  }ky8i[I[280197]][I[280300]] && ky8i[I[280197]][I[280300]][I[280010]] > 0xa && (_rYE[I[280301]] = ky8i[I[280197]][I[280300]], _rYE[I[280021]] = ky8i[I[280197]][I[280300]]), ky8i[I[280197]][I[280079]] && (_rYE[I[280020]] = ky8i[I[280197]][I[280079]]), console[I[280001]](I[280302] + _rYE[I[280020]] + I[280303] + _rYE[I[280245]]), window['_rYEF'] = !![], window['_rEFYS'](), window['_rEYSF']();
}, window[I[280304]], window['_rFYES'] = function () {
  sendApi(_rYE[I[280154]], I[280305], { 'game_pkg': _rYE[I[280163]] }, this['_rFESY'][I[280232]](this), _rFEY, _rES);
}, window['_rFESY'] = function (zs3lv) {
  if (zs3lv[I[280198]] === I[280271] && zs3lv[I[280197]]) {
    window[I[280304]] = zs3lv[I[280197]];for (var fdcp in zs3lv[I[280197]]) {
      _rYE[fdcp] = zs3lv[I[280197]][fdcp];
    }
  } else console[I[280001]](I[280306] + zs3lv[I[280198]]);window['_rFY'] = !![], window['_rEYSF']();
}, window[I[280307]] = function (pdf5, ikj8yo, $1_ub, ki8wyo, xjy, em7w, i2zxj, wm7er, ub$_a) {
  xjy = String(xjy);var xoy2 = i2zxj,
      y8mok = wm7er;_rYE[I[280149]][xjy] = { 'productid': xjy, 'productname': xoy2, 'productdesc': y8mok, 'roleid': pdf5, 'rolename': ikj8yo, 'rolelevel': $1_ub, 'price': em7w, 'callback': ub$_a }, sendApi(_rYE[I[280158]], I[280308], { 'game_pkg': _rYE[I[280163]], 'server_id': _rYE[I[280022]][I[280023]], 'server_name': _rYE[I[280022]][I[280286]], 'level': $1_ub, 'uid': _rYE[I[280019]], 'role_id': pdf5, 'role_name': ikj8yo, 'product_id': xjy, 'product_name': xoy2, 'product_desc': y8mok, 'money': em7w, 'partner_id': _rYE[I[280162]] }, toPayCallBack, _rFEY, _rES);
}, window[I[280309]] = function (wokm8y) {
  if (wokm8y) {
    if (wokm8y[I[280310]] === 0xc8 || wokm8y[I[280198]] == I[280271]) {
      var _65cnh = _rYE[I[280149]][String(wokm8y[I[280311]])];if (_65cnh[I[280312]]) _65cnh[I[280312]](wokm8y[I[280311]], wokm8y[I[280313]], -0x1);r_cdf56n[I[280314]]({ 'cpbill': wokm8y[I[280313]], 'productid': wokm8y[I[280311]], 'productname': _65cnh[I[280315]], 'productdesc': _65cnh[I[280316]], 'serverid': _rYE[I[280022]][I[280023]], 'servername': _rYE[I[280022]][I[280286]], 'roleid': _65cnh[I[280317]], 'rolename': _65cnh[I[280318]], 'rolelevel': _65cnh[I[280319]], 'price': _65cnh[I[280320]], 'extension': JSON[I[280026]]({ 'cp_order_id': wokm8y[I[280313]] }) }, function (pqger7, w8my) {
        _65cnh[I[280312]] && pqger7 == 0x0 && _65cnh[I[280312]](wokm8y[I[280311]], wokm8y[I[280313]], pqger7);console[I[280001]](JSON[I[280026]]({ 'type': I[280321], 'status': pqger7, 'data': wokm8y, 'role_name': _65cnh[I[280318]] }));if (pqger7 === 0x0) {} else {
          if (pqger7 === 0x1) {} else {
            if (pqger7 === 0x2) {}
          }
        }
      });
    } else alert(wokm8y[I[280001]]);
  }
}, window['_rFEYS'] = function () {}, window['_rSFE'] = function (npdqfc, b$19ua, a_h6, m7rgeq, h5_6cu) {
  r_cdf56n[I[280322]](_rYE[I[280022]][I[280023]], _rYE[I[280022]][I[280286]] || _rYE[I[280022]][I[280023]], npdqfc, b$19ua, a_h6), sendApi(_rYE[I[280154]], 'User.create_role', { 'game_pkg': _rYE[I[280163]], 'server_id': _rYE[I[280022]][I[280023]], 'role_id': npdqfc, 'uid': _rYE[I[280019]], 'role_name': b$19ua, 'role_type': m7rgeq, 'level': a_h6 });
}, window['_rSEF'] = function (yixo2j, egqpfd, nc6h5_, sxz3t, xzoj2i, dpg7, ojyi2x, nhf5c6, p5cdn, nf5pd) {
  _rYE[I[280016]] = yixo2j, _rYE[I[280017]] = egqpfd, _rYE[I[280018]] = nc6h5_, r_cdf56n[I[280323]](_rYE[I[280022]][I[280023]], _rYE[I[280022]][I[280286]] || _rYE[I[280022]][I[280023]], yixo2j, egqpfd, nc6h5_), sendApi(_rYE[I[280154]], 'User.update_role', { 'game_pkg': _rYE[I[280163]], 'server_id': _rYE[I[280022]][I[280023]], 'role_id': yixo2j, 'uid': _rYE[I[280019]], 'role_name': egqpfd, 'role_type': sxz3t, 'level': nc6h5_, 'evolution': xzoj2i });
}, window['_rFSE'] = function (req7, u$9b1a, hf6n5c, c56_h, b$41a9, d5pfcn, qpen, sxj2zi, fpdneq, fcdpnq) {
  _rYE[I[280016]] = req7, _rYE[I[280017]] = u$9b1a, _rYE[I[280018]] = hf6n5c, r_cdf56n[I[280324]](_rYE[I[280022]][I[280023]], _rYE[I[280022]][I[280286]] || _rYE[I[280022]][I[280023]], req7, u$9b1a, hf6n5c), sendApi(_rYE[I[280154]], 'User.update_role', { 'game_pkg': _rYE[I[280163]], 'server_id': _rYE[I[280022]][I[280023]], 'role_id': req7, 'uid': _rYE[I[280019]], 'role_name': u$9b1a, 'role_type': c56_h, 'level': hf6n5c, 'evolution': b$41a9 });
}, window['_rFES'] = function (sltvz) {}, window['_rSF'] = function (e7dqgp) {
  r_cdf56n[I[280325]](I[280325], function (npqfe) {
    e7dqgp && e7dqgp(npqfe);
  });
}, window[I[280326]] = function () {
  r_cdf56n[I[280326]]();
}, window[I[280327]] = function () {
  r_cdf56n[I[280328]]();
}, window[I[280135]] = function (tsl) {
  window['_rESF'] = tsl, window['_rESF'] && window['_rFS'] && (console[I[280001]](I[280136] + window['_rFS'][I[280137]]), window['_rESF'](window['_rFS']), window['_rFS'] = null);
}, window['_rEFS'] = function (fcn5p, hu_5c6, oyk8i, zsij2x) {
  window[I[280329]](I[280330], { 'game_pkg': window['_rYE'][I[280163]], 'role_id': hu_5c6, 'server_id': oyk8i }, zsij2x);
}, window['_rYSFE'] = function (_uh, oji8xy) {
  function _15uh6(oy8kj) {
    var a16_hu = [],
        fqpedn = [],
        nfdpqc = window[I[280006]][I[280331]];for (var mg7re in nfdpqc) {
      var fdpeqn = Number(mg7re);(!_uh || !_uh[I[280010]] || _uh[I[280107]](fdpeqn) != -0x1) && (fqpedn[I[280038]](nfdpqc[mg7re]), a16_hu[I[280038]]([fdpeqn, 0x3]));
    }window['_rUFESY'](window[I[280039]], I[280332]) >= 0x0 ? (console[I[280041]](I[280333]), r_cdf56n[I[280334]] && r_cdf56n[I[280334]](fqpedn, function (sjxz2) {
      console[I[280041]](I[280335]), console[I[280041]](sjxz2);if (sjxz2 && sjxz2[I[280058]] == I[280336]) for (var cn_56h in nfdpqc) {
        if (sjxz2[nfdpqc[cn_56h]] == I[280337]) {
          var b$u9a = Number(cn_56h);for (var lt23z = 0x0; lt23z < a16_hu[I[280010]]; lt23z++) {
            if (a16_hu[lt23z][0x0] == b$u9a) {
              a16_hu[lt23z][0x1] = 0x1;break;
            }
          }
        }
      }window['_rUFESY'](window[I[280039]], I[280338]) >= 0x0 ? wx[I[280339]]({ 'withSubscriptions': !![], 'success': function (wr7kmg) {
          var ua9b1$ = wr7kmg[I[280340]][I[280341]];if (ua9b1$) {
            console[I[280041]](I[280342]), console[I[280041]](ua9b1$);for (var t3l0v in nfdpqc) {
              if (ua9b1$[nfdpqc[t3l0v]] == I[280337]) {
                var fdepgq = Number(t3l0v);for (var okij = 0x0; okij < a16_hu[I[280010]]; okij++) {
                  if (a16_hu[okij][0x0] == fdepgq) {
                    a16_hu[okij][0x1] = 0x2;break;
                  }
                }
              }
            }console[I[280041]](a16_hu), oji8xy && oji8xy(a16_hu);
          } else console[I[280041]](I[280343]), console[I[280041]](wr7kmg), console[I[280041]](a16_hu), oji8xy && oji8xy(a16_hu);
        }, 'fail': function () {
          console[I[280041]](I[280344]), console[I[280041]](a16_hu), oji8xy && oji8xy(a16_hu);
        } }) : (console[I[280041]](I[280345] + window[I[280039]]), console[I[280041]](a16_hu), oji8xy && oji8xy(a16_hu));
    })) : (console[I[280041]](I[280346] + window[I[280039]]), console[I[280041]](a16_hu), oji8xy && oji8xy(a16_hu)), wx[I[280347]](_15uh6);
  }wx[I[280348]](_15uh6);
}, window['_rYSEF'] = { 'isSuccess': ![], 'level': I[280349], 'isCharging': ![] }, window['_rYFSE'] = function (ep7rq) {
  wx[I[280123]]({ 'success': function (g7qrpe) {
      var _56uch = window['_rYSEF'];_56uch[I[280350]] = !![], _56uch[I[280125]] = Number(g7qrpe[I[280125]])[I[280351]](0x0), _56uch[I[280127]] = g7qrpe[I[280127]], ep7rq && ep7rq(_56uch[I[280350]], _56uch[I[280125]], _56uch[I[280127]]);
    }, 'fail': function (qen) {
      console[I[280041]](I[280352], qen[I[280058]]);var eqpfg = window['_rYSEF'];ep7rq && ep7rq(eqpfg[I[280350]], eqpfg[I[280125]], eqpfg[I[280127]]);
    } });
}, window[I[280329]] = function (c56f, stzlv, jioy8k, u$b9a1, xztjs, kjo8iy, a194b$, krym) {
  if (u$b9a1 == undefined) u$b9a1 = 0x1;wx[I[280217]]({ 'url': c56f, 'method': a194b$ || I[280353], 'responseType': I[280354], 'data': stzlv, 'header': { 'content-type': krym || I[280219] }, 'success': function (nh6c_) {
      DEBUG && console[I[280041]](I[280355], c56f, info, nh6c_);if (nh6c_ && nh6c_[I[280356]] == 0xc8) {
        var sv03l = nh6c_[I[280197]];!kjo8iy || kjo8iy(sv03l) ? jioy8k && jioy8k(sv03l) : window[I[280357]](c56f, stzlv, jioy8k, u$b9a1, xztjs, kjo8iy, nh6c_);
      } else window[I[280357]](c56f, stzlv, jioy8k, u$b9a1, xztjs, kjo8iy, nh6c_);
    }, 'fail': function (pnqd) {
      DEBUG && console[I[280041]](I[280358], c56f, info, pnqd), window[I[280357]](c56f, stzlv, jioy8k, u$b9a1, xztjs, kjo8iy, pnqd);
    }, 'complete': function () {} });
}, window[I[280357]] = function (cfhn, ztl3sv, ch_n, xyioj8, jix2o, lt0s, de7pgq) {
  xyioj8 - 0x1 > 0x0 ? setTimeout(function () {
    window[I[280329]](cfhn, ztl3sv, ch_n, xyioj8 - 0x1, jix2o, lt0s);
  }, 0x3e8) : jix2o && jix2o(JSON[I[280026]]({ 'url': cfhn, 'response': de7pgq }));
}, window[I[280359]] = function (rq7meg, wk8moy, vltz3s, vlzs3t, df5np, zvlt3, ltz3vs) {
  !vltz3s && (vltz3s = {});var i2jxz = Math[I[280360]](Date[I[280174]]() / 0x3e8);vltz3s[I[280278]] = i2jxz, vltz3s[I[280361]] = wk8moy;var zs2xtj = Object[I[280362]](vltz3s)[I[280363]](),
      vt30sl = '',
      yk8joi = '';for (var wk8iy = 0x0; wk8iy < zs2xtj[I[280010]]; wk8iy++) {
    vt30sl = vt30sl + (wk8iy == 0x0 ? '' : '&') + zs2xtj[wk8iy] + vltz3s[zs2xtj[wk8iy]], yk8joi = yk8joi + (wk8iy == 0x0 ? '' : '&') + zs2xtj[wk8iy] + '=' + encodeURIComponent(vltz3s[zs2xtj[wk8iy]]);
  }vt30sl = vt30sl + _rYE[I[280160]];var x2joiz = I[280364] + md5(vt30sl);send(rq7meg + '?' + yk8joi + (yk8joi == '' ? '' : '&') + x2joiz, null, vlzs3t, df5np, zvlt3, ltz3vs || function (n5pdfc) {
    return n5pdfc[I[280198]] == I[280271];
  }, null, I[280365]);
}, window['_rYFES'] = function (fcnh6, tlvz3s) {
  var iyjxo2 = 0x0;_rYE[I[280022]] && (iyjxo2 = _rYE[I[280022]][I[280023]]), sendApi(_rYE[I[280156]], I[280366], { 'partnerId': _rYE[I[280162]], 'gamePkg': _rYE[I[280163]], 'logTime': Math[I[280360]](Date[I[280174]]() / 0x3e8), 'platformUid': _rYE[I[280274]], 'type': fcnh6, 'serverId': iyjxo2 }, null, 0x2, null, function () {
    return !![];
  });
}, window['_rYESF'] = function (xisz) {
  sendApi(_rYE[I[280154]], I[280367], { 'partner_id': _rYE[I[280162]], 'uid': _rYE[I[280019]], 'version': _rYE[I[280079]], 'game_pkg': _rYE[I[280163]], 'device': _rYE[I[280164]] }, _rYEFS, _rFEY, _rES);
}, window['_rYEFS'] = function (rgpeq) {
  if (rgpeq[I[280198]] === I[280271] && rgpeq[I[280197]]) {
    rgpeq[I[280197]][I[280368]]({ 'id': -0x2, 'name': I[280369] }), rgpeq[I[280197]][I[280368]]({ 'id': -0x1, 'name': I[280370] }), _rYE[I[280371]] = rgpeq[I[280197]];if (window[I[280372]]) window[I[280372]][I[280373]]();
  } else _rYE[I[280374]] = ![], window['_rSFYE'](I[280375] + rgpeq[I[280198]]);
}, window['_rSFY'] = function (kyr8m) {
  sendApi(_rYE[I[280154]], I[280376], { 'partner_id': _rYE[I[280162]], 'uid': _rYE[I[280019]], 'version': _rYE[I[280079]], 'game_pkg': _rYE[I[280163]], 'device': _rYE[I[280164]] }, _rSYF, _rFEY, _rES);
}, window['_rSYF'] = function (wr7gk) {
  _rYE[I[280377]] = ![];if (wr7gk[I[280198]] === I[280271] && wr7gk[I[280197]]) {
    for (var hnf65 = 0x0; hnf65 < wr7gk[I[280197]][I[280010]]; hnf65++) {
      wr7gk[I[280197]][hnf65][I[280290]] = _rYFS(wr7gk[I[280197]][hnf65]);
    }_rYE[I[280166]][-0x1] = window[I[280378]](wr7gk[I[280197]]), window[I[280372]][I[280379]](-0x1);
  } else window['_rSFYE'](I[280380] + wr7gk[I[280198]]);
}, window[I[280381]] = function (oxyij) {
  sendApi(_rYE[I[280154]], I[280376], { 'partner_id': _rYE[I[280162]], 'uid': _rYE[I[280019]], 'version': _rYE[I[280079]], 'game_pkg': _rYE[I[280163]], 'device': _rYE[I[280164]] }, oxyij, _rFEY, _rES);
}, window['_rFSY'] = function (qdgpe, f5dpnc) {
  sendApi(_rYE[I[280154]], I[280382], { 'partner_id': _rYE[I[280162]], 'uid': _rYE[I[280019]], 'version': _rYE[I[280079]], 'game_pkg': _rYE[I[280163]], 'device': _rYE[I[280164]], 'server_group_id': f5dpnc }, _rFYS, _rFEY, _rES);
}, window['_rFYS'] = function (jxs2) {
  _rYE[I[280377]] = ![];if (jxs2[I[280198]] === I[280271] && jxs2[I[280197]] && jxs2[I[280197]][I[280197]]) {
    var qeg7m = jxs2[I[280197]][I[280383]],
        dqfnc = [];for (var $a_b1u = 0x0; $a_b1u < jxs2[I[280197]][I[280197]][I[280010]]; $a_b1u++) {
      jxs2[I[280197]][I[280197]][$a_b1u][I[280290]] = _rYFS(jxs2[I[280197]][I[280197]][$a_b1u]), (dqfnc[I[280010]] == 0x0 || jxs2[I[280197]][I[280197]][$a_b1u][I[280290]] != 0x0) && (dqfnc[dqfnc[I[280010]]] = jxs2[I[280197]][I[280197]][$a_b1u]);
    }_rYE[I[280166]][qeg7m] = window[I[280378]](dqfnc), window[I[280372]][I[280379]](qeg7m);
  } else window['_rSFYE'](I[280384] + jxs2[I[280198]]);
}, window['_rUFEY'] = function (n6d) {
  sendApi(_rYE[I[280154]], I[280385], { 'partner_id': _rYE[I[280162]], 'uid': _rYE[I[280019]], 'version': _rYE[I[280079]], 'game_pkg': _rYE[I[280163]], 'device': _rYE[I[280164]] }, reqServerRecommendCallBack, _rFEY, _rES);
}, window[I[280386]] = function (u51) {
  _rYE[I[280377]] = ![];if (u51[I[280198]] === I[280271] && u51[I[280197]]) {
    for (var c6hn5 = 0x0; c6hn5 < u51[I[280197]][I[280010]]; c6hn5++) {
      u51[I[280197]][c6hn5][I[280290]] = _rYFS(u51[I[280197]][c6hn5]);
    }_rYE[I[280166]][-0x2] = window[I[280378]](u51[I[280197]]), window[I[280372]][I[280379]](-0x2);
  } else alert(I[280387] + u51[I[280198]]);
}, window[I[280378]] = function (_1u5) {
  if (!_1u5 && _1u5[I[280010]] <= 0x0) return _1u5;for (let emr7g = 0x0; emr7g < _1u5[I[280010]]; emr7g++) {
    _1u5[emr7g]['is_recommend'] && _1u5[emr7g]['is_recommend'] == 0x1 && (_1u5[emr7g][I[280286]] += I[280388]);
  }return _1u5;
}, window['_rYSF'] = function (oj8y, kyj) {
  oj8y = oj8y || _rYE[I[280022]][I[280023]], sendApi(_rYE[I[280154]], I[280389], { 'type': '4', 'game_pkg': _rYE[I[280163]], 'server_id': oj8y }, kyj);
}, window[I[280390]] = function (o2yjx, ts3lvz, pdfenq, iyjx8o) {
  pdfenq = pdfenq || _rYE[I[280022]][I[280023]], sendApi(_rYE[I[280154]], I[280391], { 'type': o2yjx, 'game_pkg': ts3lvz, 'server_id': pdfenq }, iyjx8o);
}, window['_rYFS'] = function (epqdf) {
  if (epqdf) {
    if (epqdf[I[280290]] == 0x1) {
      if (epqdf[I[280392]] == 0x1) return 0x2;else return 0x1;
    } else return epqdf[I[280290]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_rESFY'] = function (s3tl, g7rwm) {
  _rYE[I[280393]] = { 'step': s3tl, 'server_id': g7rwm };var _hcn65 = this;_rSYFE({ 'title': I[280394] }), sendApi(_rYE[I[280154]], I[280395], { 'partner_id': _rYE[I[280162]], 'uid': _rYE[I[280019]], 'game_pkg': _rYE[I[280163]], 'server_id': g7rwm, 'platform': _rYE[I[280083]], 'platform_uid': _rYE[I[280274]], 'check_login_time': _rYE[I[280277]], 'check_login_sign': _rYE[I[280275]], 'version_name': _rYE[I[280245]] }, _rESYF, _rFEY, _rES, function (gm7) {
    return gm7[I[280198]] == I[280271] || gm7[I[280001]] == I[280396] || gm7[I[280001]] == I[280397];
  });
}, window['_rESYF'] = function (h65cu_) {
  var xsjz = this;if (h65cu_[I[280198]] === I[280271] && h65cu_[I[280197]]) {
    var x2yi = _rYE[I[280022]];x2yi[I[280398]] = _rYE[I[280167]], x2yi[I[280276]] = String(h65cu_[I[280197]][I[280399]]), x2yi[I[280173]] = parseInt(h65cu_[I[280197]][I[280278]]);if (h65cu_[I[280197]][I[280400]]) x2yi[I[280400]] = parseInt(h65cu_[I[280197]][I[280400]]);else x2yi[I[280400]] = parseInt(h65cu_[I[280197]][I[280023]]);x2yi[I[280401]] = 0x0, x2yi[I[280021]] = _rYE[I[280301]], x2yi[I[280402]] = h65cu_[I[280197]][I[280403]], x2yi[I[280404]] = h65cu_[I[280197]][I[280404]], console[I[280041]](I[280405] + JSON[I[280026]](x2yi[I[280404]])), _rYE[I[280284]] == 0x1 && x2yi[I[280404]] && x2yi[I[280404]][I[280406]] == 0x1 && (_rYE[I[280407]] = 0x1, window[I[280034]][I[280035]]['_rUEY']()), _rEFSY();
  } else _rYE[I[280393]][I[280408]] >= 0x3 ? (_rES(JSON[I[280026]](h65cu_)), window['_rSFYE'](I[280409] + h65cu_[I[280198]])) : sendApi(_rYE[I[280154]], I[280258], { 'platform': _rYE[I[280152]], 'partner_id': _rYE[I[280162]], 'token': _rYE[I[280256]], 'game_pkg': _rYE[I[280163]], 'deviceId': _rYE[I[280164]], 'scene': I[280259] + _rYE[I[280165]] }, function (szxt2) {
    if (!szxt2 || szxt2[I[280198]] != I[280271]) {
      window['_rSFYE'](I[280272] + szxt2 && szxt2[I[280198]]);return;
    }_rYE[I[280275]] = String(szxt2[I[280276]]), _rYE[I[280277]] = String(szxt2[I[280278]]), setTimeout(function () {
      _rESFY(_rYE[I[280393]][I[280408]] + 0x1, _rYE[I[280393]][I[280023]]);
    }, 0x5dc);
  }, _rFEY, _rES, function (iszj) {
    return iszj[I[280198]] == I[280271] || iszj[I[280198]] == I[280410];
  });
}, window['_rEFSY'] = function () {
  ServerLoading[I[280035]][I[280293]](_rYE[I[280284]]), window['_rFE'] = !![], window['_rEYSF']();
}, window['_rEFYS'] = function () {
  if (window['_rEF'] && window['_rYFE'] && window[I[280180]] && window[I[280181]] && window['_rYEF'] && window['_rYF']) {
    if (!window[I[280411]][I[280035]]) {
      console[I[280041]](I[280412] + window[I[280411]][I[280035]]);var _hu516 = wx[I[280413]](),
          nfedq = _hu516[I[280137]] ? _hu516[I[280137]] : 0x0,
          fnch65 = { 'cdn': window['_rYE'][I[280021]], 'spareCdn': window['_rYE'][I[280243]], 'newRegister': window['_rYE'][I[280284]], 'wxPC': window['_rYE'][I[280112]], 'wxIOS': window['_rYE'][I[280106]], 'wxAndroid': window['_rYE'][I[280109]], 'wxParam': { 'limitLoad': window['_rYE']['_rUSFEY'], 'benchmarkLevel': window['_rYE']['_rUSYFE'], 'wxFrom': window[I[280006]][I[280251]] == I[280414] ? 0x1 : 0x0, 'wxSDKVersion': window[I[280039]] }, 'configType': window['_rYE'][I[280175]], 'exposeType': window['_rYE'][I[280177]], 'scene': nfedq };new window[I[280411]](fnch65, window['_rYE'][I[280020]], window['_rUSFYE']);
    }
  }
}, window['_rEYSF'] = function () {
  if (window['_rEF'] && window['_rYFE'] && window[I[280180]] && window[I[280181]] && window['_rYEF'] && window['_rYF'] && window['_rFE'] && window['_rFY']) {
    _rSYEF();if (!_rEFY) {
      _rEFY = !![];if (!window[I[280411]][I[280035]]) window['_rEFYS']();var mwky = 0x0,
          tzsxj = wx[I[280415]]();tzsxj && (window['_rYE'][I[280111]] && (mwky = tzsxj[I[280101]]), console[I[280001]](I[280416] + tzsxj[I[280101]] + I[280417] + tzsxj[I[280102]] + I[280418] + tzsxj[I[280103]] + I[280419] + tzsxj[I[280104]] + I[280420] + tzsxj[I[280421]] + I[280422] + tzsxj[I[280423]]));var cfdqpn = {};for (const qndfcp in _rYE[I[280022]]) {
        cfdqpn[qndfcp] = _rYE[I[280022]][qndfcp];
      }var xt2jz = { 'channel': window['_rYE'][I[280168]], 'account': window['_rYE'][I[280019]], 'userId': window['_rYE'][I[280273]], 'cdn': window['_rYE'][I[280021]], 'data': window['_rYE'][I[280197]], 'package': window['_rYE'][I[280150]], 'newRegister': window['_rYE'][I[280284]], 'pkgName': window['_rYE'][I[280163]], 'partnerId': window['_rYE'][I[280162]], 'platform_uid': window['_rYE'][I[280274]], 'deviceId': window['_rYE'][I[280164]], 'selectedServer': cfdqpn, 'configType': window['_rYE'][I[280175]], 'exposeType': window['_rYE'][I[280177]], 'debugUsers': window['_rYE'][I[280171]], 'wxMenuTop': mwky, 'wxShield': window['_rYE'][I[280179]] };if (window[I[280304]]) for (var cdnp5f in window[I[280304]]) {
        xt2jz[cdnp5f] = window[I[280304]][cdnp5f];
      }window[I[280411]][I[280035]]['_rEYU'](xt2jz), setTimeout(() => {
        !_rYE[I[280179]] && new minitool();
      }, 0x2710);
    }
  } else console[I[280001]](I[280424] + window['_rEF'] + I[280425] + window['_rYFE'] + I[280426] + window[I[280180]] + I[280427] + window[I[280181]] + I[280428] + window['_rYEF'] + I[280429] + window['_rYF'] + I[280430] + window['_rFE'] + I[280431] + window['_rFY']);
};