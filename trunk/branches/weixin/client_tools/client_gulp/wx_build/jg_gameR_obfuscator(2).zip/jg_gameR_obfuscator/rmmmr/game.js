var I = wx.$R;
import 'rrMAINrr.js';