var B = wx.$B;
import Busepgn from '../T5T5basdT5/T55sdkT5.js';window[B[520144]] = { 'wxVersion': window[B[520006]][B[520007]] }, window[B[520145]] = ![], window['B1LN'] = 0x1, window[B[520146]] = 0x1, window['B1SNL'] = !![], window[B[520147]] = !![], window['B12_SNL'] = '', window['B1NL'] = { 'base_cdn': B[520148], 'cdn': B[520148] }, B1NL[B[520149]] = {}, B1NL[B[520150]] = '0', B1NL[B[520079]] = window[B[520144]][B[520151]], B1NL[B[520114]] = '', B1NL['os'] = '1', B1NL[B[520152]] = B[520153], B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520160]] = B[520161], B1NL[B[520162]] = '1', B1NL[B[520163]] = '', B1NL[B[520164]] = '', B1NL[B[520165]] = 0x0, B1NL[B[520166]] = {}, B1NL[B[520167]] = parseInt(B1NL[B[520162]]), B1NL[B[520168]] = B1NL[B[520162]], B1NL[B[520022]] = {}, B1NL['B1_N'] = B[520169], B1NL[B[520170]] = ![], B1NL[B[520171]] = B[520172], B1NL[B[520173]] = Date[B[520174]](), B1NL[B[520175]] = B[520176], B1NL[B[520177]] = '_a', B1NL[B[520178]] = 0x2, B1NL[B[520020]] = 0x7c1, B1NL[B[520151]] = window[B[520144]][B[520151]], B1NL[B[520179]] = ![], B1NL[B[520106]] = ![], B1NL[B[520109]] = ![], B1NL[B[520112]] = ![], window['B1SLN'] = 0x5, window['B1SL'] = ![], window['B1LS'] = ![], window['B1NSL'] = ![], window[B[520180]] = ![], window[B[520181]] = ![], window['B1NLS'] = ![], window['B1SN'] = ![], window['B1NS'] = ![], window['B1LSN'] = ![], window[B[520182]] = function (s9hk76) {
  console[B[520041]](B[520182], s9hk76), wx[B[520183]]({}), wx[B[520048]]({ 'title': B[520071], 'content': s9hk76, 'success'(_$yxt) {
      if (_$yxt[B[520184]]) console[B[520041]](B[520185]);else _$yxt[B[520186]] && console[B[520041]](B[520187]);
    } });
}, window['B1_SNL'] = function (h67ks9) {
  console[B[520041]](B[520188], h67ks9), B1_NLS(), wx[B[520048]]({ 'title': B[520071], 'content': h67ks9, 'confirmText': B[520189], 'cancelText': B[520190], 'success'(f5r81) {
      if (f5r81[B[520184]]) window['B1N_']();else f5r81[B[520186]] && (console[B[520041]](B[520191]), wx[B[520192]]({}));
    } });
}, window[B[520193]] = function (vbl4zy) {
  console[B[520041]](B[520193], vbl4zy), wx[B[520048]]({ 'title': B[520071], 'content': vbl4zy, 'confirmText': B[520194], 'showCancel': ![], 'complete'(frjm) {
      console[B[520041]](B[520191]), wx[B[520192]]({});
    } });
}, window['B1_SLN'] = ![], window['B1_NSL'] = function (husn) {
  window['B1_SLN'] = !![], wx[B[520195]](husn);
}, window['B1_NLS'] = function () {
  window['B1_SLN'] && (window['B1_SLN'] = ![], wx[B[520183]]({}));
}, window['B1_LSN'] = function (vl4zb) {
  window[B[520034]][B[520035]]['B1_LSN'](vl4zb);
}, window[B[520196]] = function (iu2gpe, jr5m1f) {
  Busepgn[B[520196]](iu2gpe, function (l4$yv) {
    l4$yv && l4$yv[B[520197]] ? l4$yv[B[520197]][B[520198]] == 0x1 ? jr5m1f(!![]) : (jr5m1f(![]), console[B[520001]](B[520199] + l4$yv[B[520197]][B[520200]])) : console[B[520041]](B[520196], l4$yv);
  });
}, window['B1_LNS'] = function (epi2) {
  console[B[520041]](B[520201], epi2);
}, window['B1_NL'] = function (lk4bvz) {}, window['B1_LN'] = function (ega2i, $_dtq, pge) {}, window['B1_L'] = function (bvz4y) {
  console[B[520041]](B[520202], bvz4y), window[B[520034]][B[520035]][B[520203]](), window[B[520034]][B[520035]][B[520204]](), window[B[520034]][B[520035]][B[520205]]();
}, window['B1L_'] = function (a32f8w) {
  window['B1_SNL'](B[520206]);var x_$q = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'account': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'cdn': window['B1NL'][B[520021]], 'pkgName': window['B1NL'][B[520163]], 'gamever': window[B[520006]][B[520007]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': B[520207], 'stack': a32f8w ? a32f8w : B[520206] },
      r85f3j = JSON[B[520026]](x_$q);console[B[520027]](B[520208] + r85f3j), window['B1_N'](r85f3j);
}, window['B1N_L'] = function (gpeuni) {
  var $qx_t = JSON[B[520209]](gpeuni);$qx_t[B[520210]] = window[B[520006]][B[520007]], $qx_t[B[520211]] = window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, $qx_t[B[520024]] = window[B[520024]];var klzbv = JSON[B[520026]]($qx_t);console[B[520027]](B[520212] + klzbv), window['B1_N'](klzbv);
}, window['B1NL_'] = function (puengs, v0tyl) {
  var jom1r5 = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'account': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'cdn': window['B1NL'][B[520021]], 'pkgName': window['B1NL'][B[520163]], 'gamever': window[B[520006]][B[520007]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': puengs, 'stack': v0tyl },
      _dtx$ = JSON[B[520026]](jom1r5);console[B[520213]](B[520214] + _dtx$), window['B1_N'](_dtx$);
}, window['B1_N'] = function (egsnp) {
  if (window['B1NL'][B[520115]] == B[520215]) return;var nu7s = B1NL['B1_N'] + B[520216] + B1NL[B[520019]];wx[B[520217]]({ 'url': nu7s, 'method': B[520218], 'data': egsnp, 'header': { 'content-type': B[520219], 'cache-control': B[520220] }, 'success': function (genus) {
      DEBUG && console[B[520041]](B[520221], nu7s, egsnp, genus);
    }, 'fail': function (pg7sn) {
      DEBUG && console[B[520041]](B[520221], nu7s, egsnp, pg7sn);
    }, 'complete': function () {} });
}, window[B[520222]] = function () {
  function uengi() {
    return ((0x1 + Math[B[520223]]()) * 0x10000 | 0x0)[B[520224]](0x10)[B[520225]](0x1);
  }return uengi() + uengi() + '-' + uengi() + '-' + uengi() + '-' + uengi() + '+' + uengi() + uengi() + uengi();
}, window['B1N_'] = function () {
  console[B[520041]](B[520226]);var $vy0x = Busepgn[B[520227]]();B1NL[B[520168]] = $vy0x[B[520228]], B1NL[B[520167]] = $vy0x[B[520228]], B1NL[B[520162]] = $vy0x[B[520228]], B1NL[B[520163]] = $vy0x[B[520229]];var w82a3f = { 'game_ver': B1NL[B[520079]] };B1NL[B[520164]] = this[B[520222]](), B1_NSL({ 'title': B[520230] }), Busepgn[B[520231]](w82a3f, this['B1L_N'][B[520232]](this));
};var wx_develop = ![];window['B1L_N'] = function (pei) {
  var sh769 = pei[B[520233]];wx_develop = sh769 == 0x1, console[B[520041]](B[520234] + sh769 + B[520235] + (sh769 == 0x1) + B[520236] + pei[B[520007]] + B[520237] + window[B[520144]][B[520151]]);if (!pei[B[520007]] || window['B12SL_N'](window[B[520144]][B[520151]], pei[B[520007]]) < 0x0) console[B[520041]](B[520238]), B1NL[B[520154]] = B[520239], B1NL[B[520156]] = B[520240], B1NL[B[520158]] = B[520241], B1NL[B[520021]] = B[520242], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = 'fs', B1NL[B[520179]] = ![];else window['B12SL_N'](window[B[520144]][B[520151]], pei[B[520007]]) == 0x0 ? (console[B[520041]](B[520246]), B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520021]] = B[520247], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = B[520248], B1NL[B[520179]] = !![]) : (console[B[520041]](B[520249]), B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520021]] = B[520247], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = B[520248], B1NL[B[520179]] = ![]);B1NL[B[520165]] = config[B[520250]] ? config[B[520250]] : 0x0, this['B1SN_L'](), this['B1SNL_'](), window[B[520251]] = 0x5, B1_NSL({ 'title': B[520252] }), Busepgn[B[520253]](this['B1LN_'][B[520232]](this));
}, window[B[520251]] = 0x5, window['B1LN_'] = function (i8aw2, t_xy) {
  if (i8aw2 == 0x0 && t_xy && t_xy[B[520254]]) {
    B1NL[B[520255]] = t_xy[B[520254]];var awpi = this;B1_NSL({ 'title': B[520256] }), sendApi(B1NL[B[520154]], B[520257], { 'platform': B1NL[B[520152]], 'partner_id': B1NL[B[520162]], 'token': t_xy[B[520254]], 'game_pkg': B1NL[B[520163]], 'deviceId': B1NL[B[520164]], 'scene': B[520258] + B1NL[B[520165]] }, this['B1S_NL'][B[520232]](this), B1SLN, B1L_);
  } else t_xy && t_xy[B[520058]] && window[B[520251]] > 0x0 && (t_xy[B[520058]][B[520107]](B[520259]) != -0x1 || t_xy[B[520058]][B[520107]](B[520260]) != -0x1 || t_xy[B[520058]][B[520107]](B[520261]) != -0x1 || t_xy[B[520058]][B[520107]](B[520262]) != -0x1 || t_xy[B[520058]][B[520107]](B[520263]) != -0x1 || t_xy[B[520058]][B[520107]](B[520264]) != -0x1) ? (window[B[520251]]--, Busepgn[B[520253]](this['B1LN_'][B[520232]](this))) : (window['B1NL_'](B[520265], JSON[B[520026]]({ 'status': i8aw2, 'data': t_xy })), window['B1_SNL'](B[520266] + (t_xy && t_xy[B[520058]] ? '，' + t_xy[B[520058]] : '')));
}, window['B1S_NL'] = function (xt0$_y) {
  if (!xt0$_y) {
    window['B1NL_'](B[520267], B[520268]), window['B1_SNL'](B[520269]);return;
  }if (xt0$_y[B[520198]] != B[520270]) {
    window['B1NL_'](B[520267], JSON[B[520026]](xt0$_y)), window['B1_SNL'](B[520271] + xt0$_y[B[520198]]);return;
  }B1NL[B[520272]] = String(xt0$_y[B[520019]]), B1NL[B[520019]] = String(xt0$_y[B[520019]]), B1NL[B[520083]] = String(xt0$_y[B[520083]]), B1NL[B[520168]] = String(xt0$_y[B[520083]]), B1NL[B[520273]] = String(xt0$_y[B[520273]]), B1NL[B[520274]] = String(xt0$_y[B[520275]]), B1NL[B[520276]] = String(xt0$_y[B[520277]]), B1NL[B[520275]] = '';var $_dx0t = this;B1_NSL({ 'title': B[520278] }), sendApi(B1NL[B[520154]], B[520279], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, $_dx0t['B1S_LN'][B[520232]]($_dx0t), B1SLN, B1L_);
}, window['B1S_LN'] = function (shn67u) {
  if (!shn67u) {
    window['B1_SNL'](B[520280]);return;
  }if (shn67u[B[520198]] != B[520270]) {
    window['B1_SNL'](B[520281] + shn67u[B[520198]]);return;
  }if (!shn67u[B[520197]] || shn67u[B[520197]][B[520010]] == 0x0) {
    window['B1_SNL'](B[520282]);return;
  }B1NL[B[520283]] = shn67u[B[520284]], B1NL[B[520022]] = { 'server_id': String(shn67u[B[520197]][0x0][B[520023]]), 'server_name': String(shn67u[B[520197]][0x0][B[520285]]), 'entry_ip': shn67u[B[520197]][0x0][B[520286]], 'entry_port': parseInt(shn67u[B[520197]][0x0][B[520287]]), 'status': B1NS_(shn67u[B[520197]][0x0]), 'start_time': shn67u[B[520197]][0x0][B[520288]], 'cdn': B1NL[B[520021]] }, this['B1LNS_']();
}, window['B1LNS_'] = function () {
  if (B1NL[B[520283]] == 0x1) {
    var $lt0vy = B1NL[B[520022]][B[520289]];if ($lt0vy === -0x1 || $lt0vy === 0x0) {
      window['B1_SNL']($lt0vy === -0x1 ? B[520290] : B[520291]);return;
    }B1L_SN(0x0, B1NL[B[520022]][B[520023]]), window[B[520034]][B[520035]][B[520292]](B1NL[B[520283]]);
  } else window[B[520034]][B[520035]][B[520293]](), B1_NLS();window['B1NS'] = !![], window['B1LSN_'](), window['B1LN_S']();
}, window['B1SN_L'] = function () {
  sendApi(B1NL[B[520154]], B[520294], { 'game_pkg': B1NL[B[520163]], 'version_name': B1NL[B[520245]] }, this[B[520295]][B[520232]](this), B1SLN, B1L_);
}, window[B[520295]] = function (bylv) {
  if (!bylv) {
    window['B1_SNL'](B[520296]);return;
  }if (bylv[B[520198]] != B[520270]) {
    window['B1_SNL'](B[520297] + bylv[B[520198]]);return;
  }if (!bylv[B[520197]] || !bylv[B[520197]][B[520079]]) {
    window['B1_SNL'](B[520298] + (bylv[B[520197]] && bylv[B[520197]][B[520079]]));return;
  }bylv[B[520197]][B[520299]] && bylv[B[520197]][B[520299]][B[520010]] > 0xa && (B1NL[B[520300]] = bylv[B[520197]][B[520299]], B1NL[B[520021]] = bylv[B[520197]][B[520299]]), bylv[B[520197]][B[520079]] && (B1NL[B[520020]] = bylv[B[520197]][B[520079]]), console[B[520001]](B[520301] + B1NL[B[520020]] + B[520302] + B1NL[B[520245]]), window['B1NLS'] = !![], window['B1LSN_'](), window['B1LN_S']();
}, window[B[520303]], window['B1SNL_'] = function () {
  sendApi(B1NL[B[520154]], B[520304], { 'game_pkg': B1NL[B[520163]] }, this['B1SL_N'][B[520232]](this), B1SLN, B1L_);
}, window['B1SL_N'] = function (y0t$l) {
  if (y0t$l[B[520198]] === B[520270] && y0t$l[B[520197]]) {
    window[B[520303]] = y0t$l[B[520197]];for (var rfj5m1 in y0t$l[B[520197]]) {
      B1NL[rfj5m1] = y0t$l[B[520197]][rfj5m1];
    }
  } else console[B[520001]](B[520305] + y0t$l[B[520198]]);window['B1SN'] = !![], window['B1LN_S']();
}, window[B[520306]] = function (qd_$t, b9kh7, f5j1r, a3rwf8, z4kb96, pag2ei, y4$l, uh7gn, y0$x) {
  z4kb96 = String(z4kb96);var fw83r5 = y4$l,
      egpi2a = uh7gn;B1NL[B[520149]][z4kb96] = { 'productid': z4kb96, 'productname': fw83r5, 'productdesc': egpi2a, 'roleid': qd_$t, 'rolename': b9kh7, 'rolelevel': f5j1r, 'price': pag2ei, 'callback': y0$x }, sendApi(B1NL[B[520158]], B[520307], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'server_name': B1NL[B[520022]][B[520285]], 'level': f5j1r, 'uid': B1NL[B[520019]], 'role_id': qd_$t, 'role_name': b9kh7, 'product_id': z4kb96, 'product_name': fw83r5, 'product_desc': egpi2a, 'money': pag2ei, 'partner_id': B1NL[B[520162]] }, toPayCallBack, B1SLN, B1L_);
}, window[B[520308]] = function (zlkv4b) {
  if (zlkv4b) {
    if (zlkv4b[B[520309]] === 0xc8 || zlkv4b[B[520198]] == B[520270]) {
      var aiew2p = B1NL[B[520149]][String(zlkv4b[B[520310]])];if (aiew2p[B[520311]]) aiew2p[B[520311]](zlkv4b[B[520310]], zlkv4b[B[520312]], -0x1);Busepgn[B[520313]]({ 'cpbill': zlkv4b[B[520312]], 'productid': zlkv4b[B[520310]], 'productname': aiew2p[B[520314]], 'productdesc': aiew2p[B[520315]], 'serverid': B1NL[B[520022]][B[520023]], 'servername': B1NL[B[520022]][B[520285]], 'roleid': aiew2p[B[520316]], 'rolename': aiew2p[B[520317]], 'rolelevel': aiew2p[B[520318]], 'price': aiew2p[B[520319]], 'extension': JSON[B[520026]]({ 'cp_order_id': zlkv4b[B[520312]] }) }, function (sk7h6, bylz4v) {
        aiew2p[B[520311]] && sk7h6 == 0x0 && aiew2p[B[520311]](zlkv4b[B[520310]], zlkv4b[B[520312]], sk7h6);console[B[520001]](JSON[B[520026]]({ 'type': B[520320], 'status': sk7h6, 'data': zlkv4b, 'role_name': aiew2p[B[520317]] }));if (sk7h6 === 0x0) {} else {
          if (sk7h6 === 0x1) {} else {
            if (sk7h6 === 0x2) {}
          }
        }
      });
    } else alert(zlkv4b[B[520001]]);
  }
}, window['B1SLN_'] = function () {}, window['B1_SL'] = function (fa3w8, ie32a, lvy$0, ia3w2e, w23a8f) {
  Busepgn[B[520321]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], fa3w8, ie32a, lvy$0), sendApi(B1NL[B[520154]], B[520322], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': fa3w8, 'uid': B1NL[B[520019]], 'role_name': ie32a, 'role_type': ia3w2e, 'level': lvy$0 });
}, window['B1_LS'] = function (f3j8r5, gnush, vkbl4, y40vl$, upiegn, ra3, zb4k69, r58j1, $dtqx, zyvl40) {
  B1NL[B[520016]] = f3j8r5, B1NL[B[520017]] = gnush, B1NL[B[520018]] = vkbl4, Busepgn[B[520323]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], f3j8r5, gnush, vkbl4), sendApi(B1NL[B[520154]], B[520324], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': f3j8r5, 'uid': B1NL[B[520019]], 'role_name': gnush, 'role_type': y40vl$, 'level': vkbl4, 'evolution': upiegn });
}, window['B1S_L'] = function (npug7, _0tx$y, sepung, v$4, qxt_d$, hbk9z, a2eiwp, upsng7, gie, ieu2) {
  B1NL[B[520016]] = npug7, B1NL[B[520017]] = _0tx$y, B1NL[B[520018]] = sepung, Busepgn[B[520325]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], npug7, _0tx$y, sepung), sendApi(B1NL[B[520154]], B[520324], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': npug7, 'uid': B1NL[B[520019]], 'role_name': _0tx$y, 'role_type': v$4, 'level': sepung, 'evolution': qxt_d$ });
}, window['B1SL_'] = function (tx_$q) {}, window['B1_S'] = function (sg7hn) {
  Busepgn[B[520326]](B[520326], function (wip2) {
    sg7hn && sg7hn(wip2);
  });
}, window[B[520327]] = function () {
  Busepgn[B[520327]]();
}, window[B[520328]] = function () {
  Busepgn[B[520329]]();
}, window[B[520330]] = function (qt_$d, zk69, rf83j, k49lz, ugpei, r1omj5, ksh697, nuipge) {
  nuipge = nuipge || B1NL[B[520022]][B[520023]], sendApi(B1NL[B[520154]], B[520331], { 'phone': qt_$d, 'role_id': zk69, 'uid': B1NL[B[520019]], 'game_pkg': B1NL[B[520163]], 'partner_id': B1NL[B[520162]], 'server_id': nuipge }, ksh697);
}, window[B[520135]] = function (qt$dx_) {
  window['B1L_S'] = qt$dx_, window['B1L_S'] && window['B1S_'] && (console[B[520001]](B[520136] + window['B1S_'][B[520137]]), window['B1L_S'](window['B1S_']), window['B1S_'] = null);
}, window['B1LS_'] = function (g2pae, fjr5m, pnusge, a38i) {
  window[B[520332]](B[520333], { 'game_pkg': window['B1NL'][B[520163]], 'role_id': fjr5m, 'server_id': pnusge }, a38i);
}, window['B1N_SL'] = function (uepign, $x_0dt) {
  function ew2api(kh97s6) {
    var nipuge = [],
        r1m5 = [],
        txv = window[B[520006]][B[520334]];for (var _yx0 in txv) {
      var i3wa8 = Number(_yx0);(!uepign || !uepign[B[520010]] || uepign[B[520107]](i3wa8) != -0x1) && (r1m5[B[520038]](txv[_yx0]), nipuge[B[520038]]([i3wa8, 0x3]));
    }window['B12SL_N'](window[B[520039]], B[520335]) >= 0x0 ? (console[B[520041]](B[520336]), Busepgn[B[520337]] && Busepgn[B[520337]](r1m5, function (igeu) {
      console[B[520041]](B[520338]), console[B[520041]](igeu);if (igeu && igeu[B[520058]] == B[520339]) for (var iepg in txv) {
        if (igeu[txv[iepg]] == B[520340]) {
          var b6h9k7 = Number(iepg);for (var i28aw = 0x0; i28aw < nipuge[B[520010]]; i28aw++) {
            if (nipuge[i28aw][0x0] == b6h9k7) {
              nipuge[i28aw][0x1] = 0x1;break;
            }
          }
        }
      }window['B12SL_N'](window[B[520039]], B[520341]) >= 0x0 ? wx[B[520342]]({ 'withSubscriptions': !![], 'success': function (t0x_y) {
          var v0t$ = t0x_y[B[520343]][B[520344]];if (v0t$) {
            console[B[520041]](B[520345]), console[B[520041]](v0t$);for (var $yx_t0 in txv) {
              if (v0t$[txv[$yx_t0]] == B[520340]) {
                var hks96 = Number($yx_t0);for (var frm1j = 0x0; frm1j < nipuge[B[520010]]; frm1j++) {
                  if (nipuge[frm1j][0x0] == hks96) {
                    nipuge[frm1j][0x1] = 0x2;break;
                  }
                }
              }
            }console[B[520041]](nipuge), $x_0dt && $x_0dt(nipuge);
          } else console[B[520041]](B[520346]), console[B[520041]](t0x_y), console[B[520041]](nipuge), $x_0dt && $x_0dt(nipuge);
        }, 'fail': function () {
          console[B[520041]](B[520347]), console[B[520041]](nipuge), $x_0dt && $x_0dt(nipuge);
        } }) : (console[B[520041]](B[520348] + window[B[520039]]), console[B[520041]](nipuge), $x_0dt && $x_0dt(nipuge));
    })) : (console[B[520041]](B[520349] + window[B[520039]]), console[B[520041]](nipuge), $x_0dt && $x_0dt(nipuge)), wx[B[520350]](ew2api);
  }wx[B[520351]](ew2api);
}, window['B1N_LS'] = { 'isSuccess': ![], 'level': B[520352], 'isCharging': ![] }, window['B1NS_L'] = function (m5jor) {
  wx[B[520123]]({ 'success': function (rjm5f1) {
      var h67n9 = window['B1N_LS'];h67n9[B[520353]] = !![], h67n9[B[520125]] = Number(rjm5f1[B[520125]])[B[520354]](0x0), h67n9[B[520127]] = rjm5f1[B[520127]], m5jor && m5jor(h67n9[B[520353]], h67n9[B[520125]], h67n9[B[520127]]);
    }, 'fail': function (a3i2ew) {
      console[B[520041]](B[520355], a3i2ew[B[520058]]);var pia2 = window['B1N_LS'];m5jor && m5jor(pia2[B[520353]], pia2[B[520125]], pia2[B[520127]]);
    } });
}, window[B[520332]] = function (l4v0z, lyz4, engu, bz4vy, k4l9zb, b4z9l, v4yl$0, wa382i) {
  if (bz4vy == undefined) bz4vy = 0x1;wx[B[520217]]({ 'url': l4v0z, 'method': v4yl$0 || B[520356], 'responseType': B[520357], 'data': lyz4, 'header': { 'content-type': wa382i || B[520219] }, 'success': function (kbh76) {
      DEBUG && console[B[520041]](B[520358], l4v0z, info, kbh76);if (kbh76 && kbh76[B[520359]] == 0xc8) {
        var qdt_$ = kbh76[B[520197]];!b4z9l || b4z9l(qdt_$) ? engu && engu(qdt_$) : window[B[520360]](l4v0z, lyz4, engu, bz4vy, k4l9zb, b4z9l, kbh76);
      } else window[B[520360]](l4v0z, lyz4, engu, bz4vy, k4l9zb, b4z9l, kbh76);
    }, 'fail': function (vbzl) {
      DEBUG && console[B[520041]](B[520361], l4v0z, info, vbzl), window[B[520360]](l4v0z, lyz4, engu, bz4vy, k4l9zb, b4z9l, vbzl);
    }, 'complete': function () {} });
}, window[B[520360]] = function (dq_x, a8fw32, gusnp7, klb49z, bzv4y, bhk69z, xtv0$) {
  klb49z - 0x1 > 0x0 ? setTimeout(function () {
    window[B[520332]](dq_x, a8fw32, gusnp7, klb49z - 0x1, bzv4y, bhk69z);
  }, 0x3e8) : bzv4y && bzv4y(JSON[B[520026]]({ 'url': dq_x, 'response': xtv0$ }));
}, window[B[520362]] = function (g2eu, z4l9kb, _$tqdx, eaipg2, r8a, k9blz, frw38a) {
  !_$tqdx && (_$tqdx = {});var shng7 = Math[B[520363]](Date[B[520174]]() / 0x3e8);_$tqdx[B[520277]] = shng7, _$tqdx[B[520364]] = z4l9kb;var wraf = Object[B[520365]](_$tqdx)[B[520366]](),
      esgnpu = '',
      $0v = '';for (var ro51 = 0x0; ro51 < wraf[B[520010]]; ro51++) {
    esgnpu = esgnpu + (ro51 == 0x0 ? '' : '&') + wraf[ro51] + _$tqdx[wraf[ro51]], $0v = $0v + (ro51 == 0x0 ? '' : '&') + wraf[ro51] + '=' + encodeURIComponent(_$tqdx[wraf[ro51]]);
  }esgnpu = esgnpu + B1NL[B[520160]];var puigen = B[520367] + md5(esgnpu);send(g2eu + '?' + $0v + ($0v == '' ? '' : '&') + puigen, null, eaipg2, r8a, k9blz, frw38a || function (vlt$) {
    return vlt$[B[520198]] == B[520270];
  }, null, B[520368]);
}, window['B1NSL_'] = function (zkl4vb, fr38j) {
  var tlv0$y = 0x0;B1NL[B[520022]] && (tlv0$y = B1NL[B[520022]][B[520023]]), sendApi(B1NL[B[520156]], B[520369], { 'partnerId': B1NL[B[520162]], 'gamePkg': B1NL[B[520163]], 'logTime': Math[B[520363]](Date[B[520174]]() / 0x3e8), 'platformUid': B1NL[B[520273]], 'type': zkl4vb, 'serverId': tlv0$y }, null, 0x2, null, function () {
    return !![];
  });
}, window['B1NL_S'] = function (s7hn) {
  sendApi(B1NL[B[520154]], B[520370], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, B1NLS_, B1SLN, B1L_);
}, window['B1NLS_'] = function (yv04$l) {
  if (yv04$l[B[520198]] === B[520270] && yv04$l[B[520197]]) {
    yv04$l[B[520197]][B[520371]]({ 'id': -0x2, 'name': B[520372] }), yv04$l[B[520197]][B[520371]]({ 'id': -0x1, 'name': B[520373] }), B1NL[B[520374]] = yv04$l[B[520197]];if (window[B[520375]]) window[B[520375]][B[520376]]();
  } else B1NL[B[520377]] = ![], window['B1_SNL'](B[520378] + yv04$l[B[520198]]);
}, window['B1_SN'] = function (yz0l4) {
  sendApi(B1NL[B[520154]], B[520379], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, B1_NS, B1SLN, B1L_);
}, window['B1_NS'] = function (yvzl4b) {
  B1NL[B[520380]] = ![];if (yvzl4b[B[520198]] === B[520270] && yvzl4b[B[520197]]) {
    for (var hg7sn = 0x0; hg7sn < yvzl4b[B[520197]][B[520010]]; hg7sn++) {
      yvzl4b[B[520197]][hg7sn][B[520289]] = B1NS_(yvzl4b[B[520197]][hg7sn]);
    }B1NL[B[520166]][-0x1] = window[B[520381]](yvzl4b[B[520197]]), window[B[520375]][B[520382]](-0x1);
  } else window['B1_SNL'](B[520383] + yvzl4b[B[520198]]);
}, window[B[520384]] = function (f3wr85) {
  sendApi(B1NL[B[520154]], B[520379], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, f3wr85, B1SLN, B1L_);
}, window['B1S_N'] = function (z9bh6, aw283) {
  sendApi(B1NL[B[520154]], B[520385], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]], 'server_group_id': aw283 }, B1SN_, B1SLN, B1L_);
}, window['B1SN_'] = function (y$0t_x) {
  B1NL[B[520380]] = ![];if (y$0t_x[B[520198]] === B[520270] && y$0t_x[B[520197]] && y$0t_x[B[520197]][B[520197]]) {
    var u2pg = y$0t_x[B[520197]][B[520386]],
        eusng = [];for (var ks9h67 = 0x0; ks9h67 < y$0t_x[B[520197]][B[520197]][B[520010]]; ks9h67++) {
      y$0t_x[B[520197]][B[520197]][ks9h67][B[520289]] = B1NS_(y$0t_x[B[520197]][B[520197]][ks9h67]), (eusng[B[520010]] == 0x0 || y$0t_x[B[520197]][B[520197]][ks9h67][B[520289]] != 0x0) && (eusng[eusng[B[520010]]] = y$0t_x[B[520197]][B[520197]][ks9h67]);
    }B1NL[B[520166]][u2pg] = window[B[520381]](eusng), window[B[520375]][B[520382]](u2pg);
  } else window['B1_SNL'](B[520387] + y$0t_x[B[520198]]);
}, window['B12SLN'] = function (ei3a) {
  sendApi(B1NL[B[520154]], B[520388], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, reqServerRecommendCallBack, B1SLN, B1L_);
}, window[B[520389]] = function (l0yt$v) {
  B1NL[B[520380]] = ![];if (l0yt$v[B[520198]] === B[520270] && l0yt$v[B[520197]]) {
    for (var $vyl0 = 0x0; $vyl0 < l0yt$v[B[520197]][B[520010]]; $vyl0++) {
      l0yt$v[B[520197]][$vyl0][B[520289]] = B1NS_(l0yt$v[B[520197]][$vyl0]);
    }B1NL[B[520166]][-0x2] = window[B[520381]](l0yt$v[B[520197]]), window[B[520375]][B[520382]](-0x2);
  } else alert(B[520390] + l0yt$v[B[520198]]);
}, window[B[520381]] = function (a2gep) {
  if (!a2gep && a2gep[B[520010]] <= 0x0) return a2gep;for (let hb96 = 0x0; hb96 < a2gep[B[520010]]; hb96++) {
    a2gep[hb96][B[520391]] && a2gep[hb96][B[520391]] == 0x1 && (a2gep[hb96][B[520285]] += B[520392]);
  }return a2gep;
}, window['B1N_S'] = function (bvl4, ngu7sh) {
  bvl4 = bvl4 || B1NL[B[520022]][B[520023]], sendApi(B1NL[B[520154]], B[520393], { 'type': '4', 'game_pkg': B1NL[B[520163]], 'server_id': bvl4 }, ngu7sh);
}, window[B[520394]] = function (qt_x$d, qd$xt, w2ipea, y0t$lv) {
  w2ipea = w2ipea || B1NL[B[520022]][B[520023]], sendApi(B1NL[B[520154]], B[520395], { 'type': qt_x$d, 'game_pkg': qd$xt, 'server_id': w2ipea }, y0t$lv);
}, window['B1NS_'] = function (n7shug) {
  if (n7shug) {
    if (n7shug[B[520289]] == 0x1) {
      if (n7shug[B[520396]] == 0x1) return 0x2;else return 0x1;
    } else return n7shug[B[520289]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['B1L_SN'] = function (wr385f, z4klvb) {
  B1NL[B[520397]] = { 'step': wr385f, 'server_id': z4klvb };var u2epi = this;B1_NSL({ 'title': B[520398] }), sendApi(B1NL[B[520154]], B[520399], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'game_pkg': B1NL[B[520163]], 'server_id': z4klvb, 'platform': B1NL[B[520083]], 'platform_uid': B1NL[B[520273]], 'check_login_time': B1NL[B[520276]], 'check_login_sign': B1NL[B[520274]], 'version_name': B1NL[B[520245]] }, B1L_NS, B1SLN, B1L_, function (mjr51) {
    return mjr51[B[520198]] == B[520270] || mjr51[B[520001]] == B[520400] || mjr51[B[520001]] == B[520401];
  });
}, window['B1L_NS'] = function (fw38a) {
  var sgnupe = this;if (fw38a[B[520198]] === B[520270] && fw38a[B[520197]]) {
    var f51j8r = B1NL[B[520022]];f51j8r[B[520402]] = B1NL[B[520167]], f51j8r[B[520275]] = String(fw38a[B[520197]][B[520403]]), f51j8r[B[520173]] = parseInt(fw38a[B[520197]][B[520277]]);if (fw38a[B[520197]][B[520404]]) f51j8r[B[520404]] = parseInt(fw38a[B[520197]][B[520404]]);else f51j8r[B[520404]] = parseInt(fw38a[B[520197]][B[520023]]);f51j8r[B[520405]] = 0x0, f51j8r[B[520021]] = B1NL[B[520300]], f51j8r[B[520406]] = fw38a[B[520197]][B[520407]], f51j8r[B[520408]] = fw38a[B[520197]][B[520408]], console[B[520041]](B[520409] + JSON[B[520026]](f51j8r[B[520408]])), B1NL[B[520283]] == 0x1 && f51j8r[B[520408]] && f51j8r[B[520408]][B[520410]] == 0x1 && (B1NL[B[520411]] = 0x1, window[B[520034]][B[520035]]['B12LN']()), B1LS_N();
  } else sendApi(B1NL[B[520154]], B[520257], { 'platform': B1NL[B[520152]], 'partner_id': B1NL[B[520162]], 'token': B1NL[B[520255]], 'game_pkg': B1NL[B[520163]], 'deviceId': B1NL[B[520164]], 'scene': B[520258] + B1NL[B[520165]] }, function (b967hk) {
    if (b967hk[B[520198]] == B[520412]) {
      window['B1_SNL'](B[520271] + b967hk[B[520198]]);return;
    }B1NL[B[520274]] = String(b967hk[B[520275]]), B1NL[B[520276]] = String(b967hk[B[520277]]), setTimeout(function () {
      B1L_SN(B1NL[B[520397]][B[520413]], B1NL[B[520397]][B[520023]]);
    }, 0x5dc);
  }, B1SLN, B1L_, function (w3f5r8) {
    return w3f5r8[B[520198]] == B[520270] || w3f5r8[B[520198]] == B[520412];
  });
}, window['B1LS_N'] = function () {
  ServerLoading[B[520035]][B[520292]](B1NL[B[520283]]), window['B1SL'] = !![], window['B1LN_S']();
}, window['B1LSN_'] = function () {
  if (window['B1LS'] && window['B1NSL'] && window[B[520180]] && window[B[520181]] && window['B1NLS'] && window['B1NS']) {
    if (!window[B[520414]][B[520035]]) {
      console[B[520041]](B[520415] + window[B[520414]][B[520035]]);var gnueps = wx[B[520416]](),
          $t_0xy = gnueps[B[520137]] ? gnueps[B[520137]] : 0x0,
          lbzvy = { 'cdn': window['B1NL'][B[520021]], 'spareCdn': window['B1NL'][B[520243]], 'newRegister': window['B1NL'][B[520283]], 'wxPC': window['B1NL'][B[520112]], 'wxIOS': window['B1NL'][B[520106]], 'wxAndroid': window['B1NL'][B[520109]], 'wxParam': { 'limitLoad': window['B1NL']['B12_SLN'], 'benchmarkLevel': window['B1NL']['B12_NSL'], 'wxFrom': window[B[520006]][B[520250]] == B[520417] ? 0x1 : 0x0, 'wxSDKVersion': window[B[520039]] }, 'configType': window['B1NL'][B[520175]], 'exposeType': window['B1NL'][B[520177]], 'scene': $t_0xy };new window[B[520414]](lbzvy, window['B1NL'][B[520020]], window['B12_SNL']);
    }
  }
}, window['B1LN_S'] = function () {
  if (window['B1LS'] && window['B1NSL'] && window[B[520180]] && window[B[520181]] && window['B1NLS'] && window['B1NS'] && window['B1SL'] && window['B1SN']) {
    B1_NLS();if (!B1LSN) {
      B1LSN = !![];if (!window[B[520414]][B[520035]]) window['B1LSN_']();var xt$v = 0x0,
          peuni = wx[B[520418]]();peuni && (window['B1NL'][B[520111]] && (xt$v = peuni[B[520101]]), console[B[520001]](B[520419] + peuni[B[520101]] + B[520420] + peuni[B[520102]] + B[520421] + peuni[B[520103]] + B[520422] + peuni[B[520104]] + B[520423] + peuni[B[520424]] + B[520425] + peuni[B[520426]]));var r15mf = {};for (const su67n in B1NL[B[520022]]) {
        r15mf[su67n] = B1NL[B[520022]][su67n];
      }var i8a3 = { 'channel': window['B1NL'][B[520168]], 'account': window['B1NL'][B[520019]], 'userId': window['B1NL'][B[520272]], 'cdn': window['B1NL'][B[520021]], 'data': window['B1NL'][B[520197]], 'package': window['B1NL'][B[520150]], 'newRegister': window['B1NL'][B[520283]], 'pkgName': window['B1NL'][B[520163]], 'partnerId': window['B1NL'][B[520162]], 'platform_uid': window['B1NL'][B[520273]], 'deviceId': window['B1NL'][B[520164]], 'selectedServer': r15mf, 'configType': window['B1NL'][B[520175]], 'exposeType': window['B1NL'][B[520177]], 'debugUsers': window['B1NL'][B[520171]], 'wxMenuTop': xt$v, 'wxShield': window['B1NL'][B[520179]] };if (window[B[520303]]) for (var aiw83 in window[B[520303]]) {
        i8a3[aiw83] = window[B[520303]][aiw83];
      }window[B[520414]][B[520035]]['B1LN2'](i8a3);
    }
  } else console[B[520001]](B[520427] + window['B1LS'] + B[520428] + window['B1NSL'] + B[520429] + window[B[520180]] + B[520430] + window[B[520181]] + B[520431] + window['B1NLS'] + B[520432] + window['B1NS'] + B[520433] + window['B1SL'] + B[520434] + window['B1SN']);
};