var B = wx.$B;
console[B[520001]](B[520002]), window[B[520003]], wx[B[520004]](function (b7k69h) {
  if (b7k69h) {
    if (b7k69h[B[520005]]) {
      var ung7s = window[B[520006]][B[520007]][B[520008]](new RegExp(/\./, 'g'), '_'),
          i2epgu = b7k69h[B[520005]],
          gea = i2epgu[B[520009]](/(T5T5T5T5T5\/T52GT5MET52.js:)[0-9]{1,60}(:)/g);if (gea) for (var g7psu = 0x0; g7psu < gea[B[520010]]; g7psu++) {
        if (gea[g7psu] && gea[g7psu][B[520010]] > 0x0) {
          var td$x0_ = parseInt(gea[g7psu][B[520008]](B[520011], '')[B[520008]](':', ''));i2epgu = i2epgu[B[520008]](gea[g7psu], gea[g7psu][B[520008]](':' + td$x0_ + ':', ':' + (td$x0_ - 0x2) + ':'));
        }
      }i2epgu = i2epgu[B[520008]](new RegExp(B[520012], 'g'), B[520013] + ung7s + B[520014]), i2epgu = i2epgu[B[520008]](new RegExp(B[520015], 'g'), B[520013] + ung7s + B[520014]), b7k69h[B[520005]] = i2epgu;
    }var x_0d$t = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'user': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'gamever': window[B[520006]][B[520007]], 'cdn': window['B1NL'][B[520021]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': B[520025], 'stack': b7k69h ? b7k69h[B[520005]] : '' },
        sk6h7 = JSON[B[520026]](x_0d$t);console[B[520027]](B[520028] + sk6h7), (!window[B[520003]] || window[B[520003]] != x_0d$t[B[520027]]) && (window[B[520003]] = x_0d$t[B[520027]], window['B1_N'](x_0d$t));
  }
});import 'T5T5bfT5T5.js';import 'T5T511T5T5.js';window[B[520029]] = require(B[520030]);import 'T5INDT5T5.js';import 'T5T5IT51T5T5.js';import 'T5T5MtadT5T5.js';import 'T5T5INIT5aT5.js';console[B[520001]](B[520031]), console[B[520001]](B[520032]), B1_NSL({ 'title': B[520033] });var B_$ty0 = { 'B12_LNS': !![] };new window[B[520034]](B_$ty0), window[B[520034]][B[520035]]['B12SNL_']();if (window['B12_NLS']) clearInterval(window['B12_NLS']);window['B12_NLS'] = null, window['B12SL_N'] = function (j1f8r, v$yt0l) {
  if (!j1f8r || !v$yt0l) return 0x0;j1f8r = j1f8r[B[520036]]('.'), v$yt0l = v$yt0l[B[520036]]('.');const kbl4vz = Math[B[520037]](j1f8r[B[520010]], v$yt0l[B[520010]]);while (j1f8r[B[520010]] < kbl4vz) {
    j1f8r[B[520038]]('0');
  }while (v$yt0l[B[520010]] < kbl4vz) {
    v$yt0l[B[520038]]('0');
  }for (var $0_xt = 0x0; $0_xt < kbl4vz; $0_xt++) {
    const x0t_d = parseInt(j1f8r[$0_xt]),
          $x_d0t = parseInt(v$yt0l[$0_xt]);if (x0t_d > $x_d0t) return 0x1;else {
      if (x0t_d < $x_d0t) return -0x1;
    }
  }return 0x0;
}, window[B[520039]] = wx[B[520040]]()[B[520039]], console[B[520041]](B[520042] + window[B[520039]]);var Bzl40v = wx[B[520043]]();Bzl40v[B[520044]](function (rw53) {
  console[B[520041]](B[520045] + rw53[B[520046]]);
}), Bzl40v[B[520047]](function () {
  wx[B[520048]]({ 'title': B[520049], 'content': B[520050], 'showCancel': ![], 'success': function (v$4yl0) {
      Bzl40v[B[520051]]();
    } });
}), Bzl40v[B[520052]](function () {
  console[B[520041]](B[520053]);
}), window['B12SLN_'] = function () {
  console[B[520041]](B[520054]);var $lt0 = wx[B[520055]]({ 'name': B[520056], 'success': function (b9h76) {
      console[B[520041]](B[520057]), console[B[520041]](b9h76), b9h76 && b9h76[B[520058]] == B[520059] ? (window['B1LS'] = !![], window['B1LSN_'](), window['B1LN_S']()) : setTimeout(function () {
        window['B12SLN_']();
      }, 0x1f4);
    }, 'fail': function (pugsn7) {
      console[B[520041]](B[520060]), console[B[520041]](pugsn7), setTimeout(function () {
        window['B12SLN_']();
      }, 0x1f4);
    } });$lt0 && $lt0[B[520061]](y_$tx0 => {});
}, window['B12N_LS'] = function () {
  console[B[520041]](B[520062]);var yv0lz4 = wx[B[520055]]({ 'name': B[520063], 'success': function (e2iwa3) {
      console[B[520041]](B[520064]), console[B[520041]](e2iwa3), e2iwa3 && e2iwa3[B[520058]] == B[520059] ? (window['B1NSL'] = !![], window['B1LSN_'](), window['B1LN_S']()) : setTimeout(function () {
        window['B12N_LS']();
      }, 0x1f4);
    }, 'fail': function (nsh97) {
      console[B[520041]](B[520065]), console[B[520041]](nsh97), setTimeout(function () {
        window['B12N_LS']();
      }, 0x1f4);
    } });yv0lz4 && yv0lz4[B[520061]](_tdx$q => {});
}, window[B[520066]] = function () {
  window['B12SL_N'](window[B[520039]], B[520067]) >= 0x0 ? (console[B[520041]](B[520068] + window[B[520039]] + B[520069]), window['B1N_'](), window['B12SLN_'](), window['B12N_LS']()) : (window['B1NL_'](B[520070], window[B[520039]]), wx[B[520048]]({ 'title': B[520071], 'content': B[520072] }));
}, window[B[520024]] = '', wx[B[520073]]({ 'success'(qx$_t) {
    window[B[520024]] = B[520074] + qx$_t[B[520075]] + B[520076] + qx$_t[B[520077]] + B[520078] + qx$_t[B[520079]] + B[520080] + qx$_t[B[520081]] + B[520082] + qx$_t[B[520083]] + B[520084] + qx$_t[B[520039]] + B[520085] + qx$_t[B[520086]], console[B[520041]](window[B[520024]]), console[B[520041]](B[520087] + qx$_t[B[520088]] + B[520089] + qx$_t[B[520090]] + B[520091] + qx$_t[B[520092]] + B[520093] + qx$_t[B[520094]] + B[520095] + qx$_t[B[520096]] + B[520097] + qx$_t[B[520098]] + B[520099] + (qx$_t[B[520100]] ? qx$_t[B[520100]][B[520101]] + ',' + qx$_t[B[520100]][B[520102]] + ',' + qx$_t[B[520100]][B[520103]] + ',' + qx$_t[B[520100]][B[520104]] : ''));var f283aw = qx$_t[B[520081]] ? qx$_t[B[520081]][B[520105]]() : '',
        pg2a = qx$_t[B[520077]] ? qx$_t[B[520077]][B[520105]]()[B[520008]]('\x20', '') : '';window['B1NL'][B[520106]] = f283aw[B[520107]](B[520108]) != -0x1, window['B1NL'][B[520109]] = f283aw[B[520107]](B[520110]) != -0x1, window['B1NL'][B[520111]] = f283aw[B[520107]](B[520108]) != -0x1 || f283aw[B[520107]](B[520110]) != -0x1, window['B1NL'][B[520112]] = f283aw[B[520107]](B[520113]) != -0x1 || f283aw[B[520107]](B[520114]) != -0x1, window['B1NL'][B[520115]] = qx$_t[B[520083]] ? qx$_t[B[520083]][B[520105]]() : '', window['B1NL']['B12_SLN'] = ![], window['B1NL']['B12_NSL'] = 0x2;if (f283aw[B[520107]](B[520110]) != -0x1) {
      if (qx$_t[B[520086]] >= 0x18) window['B1NL']['B12_NSL'] = 0x3;else window['B1NL']['B12_NSL'] = 0x2;
    } else {
      if (f283aw[B[520107]](B[520108]) != -0x1) {
        if (qx$_t[B[520086]] && qx$_t[B[520086]] >= 0x14) window['B1NL']['B12_NSL'] = 0x3;else {
          if (pg2a[B[520107]](B[520116]) != -0x1 || pg2a[B[520107]](B[520117]) != -0x1 || pg2a[B[520107]](B[520118]) != -0x1 || pg2a[B[520107]](B[520119]) != -0x1 || pg2a[B[520107]](B[520120]) != -0x1) window['B1NL']['B12_NSL'] = 0x2;else window['B1NL']['B12_NSL'] = 0x3;
        }
      } else window['B1NL']['B12_NSL'] = 0x2;
    }console[B[520041]](B[520121] + window['B1NL']['B12_SLN'] + B[520122] + window['B1NL']['B12_NSL']);
  } }), wx[B[520123]]({ 'success': function (i38a) {
    console[B[520041]](B[520124] + i38a[B[520125]] + B[520126] + i38a[B[520127]]);
  } }), wx[B[520128]]({ 'success': function (l$v40y) {
    console[B[520041]](B[520129] + l$v40y[B[520130]]);
  } }), wx[B[520131]]({ 'keepScreenOn': !![] }), wx[B[520132]](function (xytv$0) {
  console[B[520041]](B[520129] + xytv$0[B[520130]] + B[520133] + xytv$0[B[520134]]);
}), wx[B[520135]](function (blkzv) {
  window['B1S_'] = blkzv, window['B1L_S'] && window['B1S_'] && (console[B[520001]](B[520136] + window['B1S_'][B[520137]]), window['B1L_S'](window['B1S_']), window['B1S_'] = null);
}), window['B12NSL_'] = 0x0, window[B[520138]] = null, wx[B[520139]](function () {
  window['B12NSL_']++, wx[B[520140]]();if (window['B12NSL_'] >= 0x2) {
    window['B12NSL_'] = 0x0, console[B[520027]](B[520141]), wx[B[520142]]('0', 0x1);if (window['B1NL'] && window['B1NL'][B[520106]]) window['B1NL_'](B[520143], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});