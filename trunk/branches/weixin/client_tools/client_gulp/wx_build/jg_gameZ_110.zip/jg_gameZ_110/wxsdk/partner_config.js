var sdk_conf = {
  game_id: '256',
  game_pkg: 'tjqy_tjqywdwsyywxxcx2_AOI',
  partner_id: '317',
  game_ver: '148.0.5',
  is_auth: false, //授权登录
  partner_app_id:'2000308',
  partner_app_key:'ea435548d4828e8aab7642c42d354046'
};
window.config = sdk_conf;
module.exports = sdk_conf;