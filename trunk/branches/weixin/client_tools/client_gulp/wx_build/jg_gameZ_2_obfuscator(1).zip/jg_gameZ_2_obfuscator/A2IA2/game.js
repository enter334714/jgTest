var d = wx.$A;
require(d[480799]);