var d = wx.$A;
import Atyxqbo from '../AAbasdA/A5sdkA.js';window[d[480543]] = { 'wxVersion': window[d[480005]][d[480006]] }, window[d[480544]] = ![], window['A16Z'] = 0x1, window[d[480545]] = 0x1, window['A17Z6'] = !![], window[d[480546]] = !![], window['A1$87Z6'] = '', window['A1Z6'] = { 'base_cdn': d[480547], 'cdn': d[480547] }, A1Z6[d[480548]] = {}, A1Z6[d[480549]] = '0', A1Z6[d[480079]] = window[d[480543]][d[480330]], A1Z6[d[480114]] = '', A1Z6['os'] = '1', A1Z6[d[480550]] = d[480551], A1Z6[d[480552]] = d[480553], A1Z6[d[480554]] = d[480555], A1Z6[d[480556]] = d[480557], A1Z6[d[480558]] = d[480559], A1Z6[d[480560]] = '1', A1Z6[d[480021]] = '', A1Z6[d[480561]] = '', A1Z6[d[480562]] = 0x0, A1Z6[d[480421]] = {}, A1Z6[d[480563]] = parseInt(A1Z6[d[480560]]), A1Z6[d[480564]] = A1Z6[d[480560]], A1Z6[d[480022]] = {}, A1Z6['A18Z'] = d[480565], A1Z6[d[480566]] = ![], A1Z6[d[480567]] = d[480568], A1Z6[d[480569]] = Date[d[480141]](), A1Z6[d[480570]] = d[480571], A1Z6[d[480572]] = '_a', A1Z6[d[480316]] = 0x2, A1Z6[d[480019]] = 0x7c1, A1Z6[d[480330]] = window[d[480543]][d[480330]], A1Z6[d[480573]] = ![], A1Z6[d[480106]] = ![], A1Z6[d[480109]] = ![], A1Z6[d[480112]] = ![], window['A176Z'] = 0x5, window['A176'] = ![], window['A167'] = ![], window['A1Z76'] = ![], window[d[480494]] = ![], window[d[480497]] = ![], window['A1Z67'] = ![], window['A17Z'] = ![], window['A1Z7'] = ![], window['A167Z'] = ![], window[d[480574]] = function (tbgo) {
  console[d[480041]](d[480574], tbgo), wx[d[480575]]({}), wx[d[480048]]({ 'title': d[480071], 'content': tbgo, 'success'(nm6s) {
      if (nm6s[d[480576]]) console[d[480041]](d[480577]);else nm6s[d[480578]] && console[d[480041]](d[480579]);
    } });
}, window['A187Z6'] = function (de$smn) {
  console[d[480041]](d[480580], de$smn), A18Z67(), wx[d[480048]]({ 'title': d[480071], 'content': de$smn, 'confirmText': d[480581], 'cancelText': d[480582], 'success'(sne$md) {
      if (sne$md[d[480576]]) window['A1Z8']();else sne$md[d[480578]] && (console[d[480041]](d[480583]), wx[d[480584]]({}));
    } });
}, window[d[480585]] = function (qbotg) {
  console[d[480041]](d[480585], qbotg), wx[d[480048]]({ 'title': d[480071], 'content': qbotg, 'confirmText': d[480586], 'showCancel': ![], 'complete'(av83) {
      console[d[480041]](d[480583]), wx[d[480584]]({});
    } });
}, window['A1876Z'] = ![], window['A18Z76'] = function (z6swh) {
  window['A1876Z'] = !![], wx[d[480587]](z6swh);
}, window['A18Z67'] = function () {
  window['A1876Z'] && (window['A1876Z'] = ![], wx[d[480575]]({}));
}, window['A1867Z'] = function (nmd6se) {
  window[d[480034]][d[480035]]['A1867Z'](nmd6se);
}, window[d[480588]] = function (e9a0$v, esd6mn) {
  Atyxqbo[d[480588]](e9a0$v, function (qyxtib) {
    qyxtib && qyxtib[d[480430]] ? qyxtib[d[480430]][d[480429]] == 0x1 ? esd6mn(!![]) : (esd6mn(![]), console[d[480000]](d[480589] + qyxtib[d[480430]][d[480590]])) : console[d[480041]](d[480588], qyxtib);
  });
}, window['A186Z7'] = function (hwj2) {
  console[d[480041]](d[480591], hwj2);
}, window['A18Z6'] = function (a$ne) {}, window['A186Z'] = function (txyp, nsedm6, py1t) {}, window['A186'] = function (ipytx1) {
  console[d[480041]](d[480592], ipytx1), window[d[480034]][d[480035]][d[480320]](), window[d[480034]][d[480035]][d[480321]](), window[d[480034]][d[480035]][d[480334]]();
}, window['A168'] = function (hwjs6) {
  window['A187Z6'](d[480593]);var uiykp1 = { 'id': window['A1Z6'][d[480015]], 'role': window['A1Z6'][d[480016]], 'level': window['A1Z6'][d[480017]], 'account': window['A1Z6'][d[480018]], 'version': window['A1Z6'][d[480019]], 'cdn': window['A1Z6'][d[480020]], 'pkgName': window['A1Z6'][d[480021]], 'gamever': window[d[480005]][d[480006]], 'serverid': window['A1Z6'][d[480022]] ? window['A1Z6'][d[480022]][d[480023]] : 0x0, 'systemInfo': window[d[480024]], 'error': d[480594], 'stack': hwjs6 ? hwjs6 : d[480593] },
      _goq4 = JSON[d[480026]](uiykp1);console[d[480027]](d[480595] + _goq4), window['A18Z'](_goq4);
}, window['A1Z86'] = function (ui1pky) {
  var qboxty = JSON[d[480596]](ui1pky);qboxty[d[480597]] = window[d[480005]][d[480006]], qboxty[d[480598]] = window['A1Z6'][d[480022]] ? window['A1Z6'][d[480022]][d[480023]] : 0x0, qboxty[d[480024]] = window[d[480024]];var xpy1k = JSON[d[480026]](qboxty);console[d[480027]](d[480599] + xpy1k), window['A18Z'](xpy1k);
}, window['A1Z68'] = function (em9av$, v$mae9) {
  var ky1xpi = { 'id': window['A1Z6'][d[480015]], 'role': window['A1Z6'][d[480016]], 'level': window['A1Z6'][d[480017]], 'account': window['A1Z6'][d[480018]], 'version': window['A1Z6'][d[480019]], 'cdn': window['A1Z6'][d[480020]], 'pkgName': window['A1Z6'][d[480021]], 'gamever': window[d[480005]][d[480006]], 'serverid': window['A1Z6'][d[480022]] ? window['A1Z6'][d[480022]][d[480023]] : 0x0, 'systemInfo': window[d[480024]], 'error': em9av$, 'stack': v$mae9 },
      uy1k = JSON[d[480026]](ky1xpi);console[d[480142]](d[480600] + uy1k), window['A18Z'](uy1k);
}, window['A18Z'] = function (xki1y) {
  if (window['A1Z6'][d[480115]] == d[480601]) return;var jwszh6 = A1Z6['A18Z'] + d[480602] + A1Z6[d[480018]];wx[d[480603]]({ 'url': jwszh6, 'method': d[480604], 'data': xki1y, 'header': { 'content-type': d[480605], 'cache-control': d[480606] }, 'success': function (tyoxbq) {
      DEBUG && console[d[480041]](d[480607], jwszh6, xki1y, tyoxbq);
    }, 'fail': function (nm$d9) {
      DEBUG && console[d[480041]](d[480607], jwszh6, xki1y, nm$d9);
    }, 'complete': function () {} });
}, window[d[480608]] = function () {
  function p3ik1u() {
    return ((0x1 + Math[d[480323]]()) * 0x10000 | 0x0)[d[480609]](0x10)[d[480610]](0x1);
  }return p3ik1u() + p3ik1u() + '-' + p3ik1u() + '-' + p3ik1u() + '-' + p3ik1u() + '+' + p3ik1u() + p3ik1u() + p3ik1u();
}, window['A1Z8'] = function () {
  console[d[480041]](d[480611]);var a0839 = Atyxqbo[d[480612]]();A1Z6[d[480564]] = a0839[d[480613]], A1Z6[d[480563]] = a0839[d[480613]], A1Z6[d[480560]] = a0839[d[480613]], A1Z6[d[480021]] = a0839[d[480614]];var z6hdj = { 'game_ver': A1Z6[d[480079]] };A1Z6[d[480561]] = this[d[480608]](), A18Z76({ 'title': d[480615] }), Atyxqbo[d[480459]](z6hdj, this['A168Z'][d[480327]](this));
}, window['A168Z'] = function (yoxtbq) {
  var k83pu = yoxtbq[d[480616]];console[d[480041]](d[480617] + k83pu + d[480618] + (k83pu == 0x1) + d[480619] + yoxtbq[d[480006]] + d[480620] + window[d[480543]][d[480330]]);if (!yoxtbq[d[480006]] || window['A1$768Z'](window[d[480543]][d[480330]], yoxtbq[d[480006]]) < 0x0) console[d[480041]](d[480621]), A1Z6[d[480552]] = d[480622], A1Z6[d[480554]] = d[480623], A1Z6[d[480556]] = d[480624], A1Z6[d[480020]] = d[480625], A1Z6[d[480626]] = d[480627], A1Z6[d[480628]] = 'lg', A1Z6[d[480573]] = ![];else window['A1$768Z'](window[d[480543]][d[480330]], yoxtbq[d[480006]]) == 0x0 ? (console[d[480041]](d[480629]), A1Z6[d[480552]] = d[480553], A1Z6[d[480554]] = d[480555], A1Z6[d[480556]] = d[480557], A1Z6[d[480020]] = d[480630], A1Z6[d[480626]] = d[480627], A1Z6[d[480628]] = d[480631], A1Z6[d[480573]] = !![]) : (console[d[480041]](d[480632]), A1Z6[d[480552]] = d[480553], A1Z6[d[480554]] = d[480555], A1Z6[d[480556]] = d[480557], A1Z6[d[480020]] = d[480630], A1Z6[d[480626]] = d[480627], A1Z6[d[480628]] = d[480631], A1Z6[d[480573]] = ![]);A1Z6[d[480562]] = config[d[480633]] ? config[d[480633]] : 0x0, this['A17Z86'](), this['A17Z68'](), window[d[480634]] = 0x5, A18Z76({ 'title': d[480635] }), Atyxqbo[d[480636]](this['A16Z8'][d[480327]](this));
}, window[d[480634]] = 0x5, window['A16Z8'] = function (j6dmsn, $8va9) {
  if (j6dmsn == 0x0 && $8va9 && $8va9[d[480637]]) {
    A1Z6[d[480638]] = $8va9[d[480637]];var or_4 = this;A18Z76({ 'title': d[480639] }), sendApi(A1Z6[d[480552]], d[480640], { 'platform': A1Z6[d[480550]], 'partner_id': A1Z6[d[480560]], 'token': $8va9[d[480637]], 'game_pkg': A1Z6[d[480021]], 'deviceId': A1Z6[d[480561]], 'scene': d[480641] + A1Z6[d[480562]] }, this['A178Z6'][d[480327]](this), A176Z, A168);
  } else $8va9 && $8va9[d[480058]] && window[d[480634]] > 0x0 && ($8va9[d[480058]][d[480107]](d[480642]) != -0x1 || $8va9[d[480058]][d[480107]](d[480643]) != -0x1 || $8va9[d[480058]][d[480107]](d[480644]) != -0x1 || $8va9[d[480058]][d[480107]](d[480645]) != -0x1 || $8va9[d[480058]][d[480107]](d[480646]) != -0x1 || $8va9[d[480058]][d[480107]](d[480647]) != -0x1) ? (window[d[480634]]--, Atyxqbo[d[480636]](this['A16Z8'][d[480327]](this))) : (window['A1Z68'](d[480648], JSON[d[480026]]({ 'status': j6dmsn, 'data': $8va9 })), window['A187Z6'](d[480649] + ($8va9 && $8va9[d[480058]] ? '，' + $8va9[d[480058]] : '')));
}, window['A178Z6'] = function (m9va$e) {
  if (!m9va$e) {
    window['A1Z68'](d[480650], d[480651]), window['A187Z6'](d[480652]);return;
  }if (m9va$e[d[480429]] != d[480428]) {
    window['A1Z68'](d[480650], JSON[d[480026]](m9va$e)), window['A187Z6'](d[480653] + m9va$e[d[480429]]);return;
  }A1Z6[d[480654]] = String(m9va$e[d[480018]]), A1Z6[d[480018]] = String(m9va$e[d[480018]]), A1Z6[d[480083]] = String(m9va$e[d[480083]]), A1Z6[d[480564]] = String(m9va$e[d[480083]]), A1Z6[d[480655]] = String(m9va$e[d[480655]]), A1Z6[d[480656]] = String(m9va$e[d[480657]]), A1Z6[d[480658]] = String(m9va$e[d[480659]]), A1Z6[d[480657]] = '';var xpiky1 = this;A18Z76({ 'title': d[480660] }), sendApi(A1Z6[d[480552]], d[480661], { 'partner_id': A1Z6[d[480560]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480561]] }, xpiky1['A1786Z'][d[480327]](xpiky1), A176Z, A168);
}, window['A1786Z'] = function (dhjns) {
  if (!dhjns) {
    window['A187Z6'](d[480662]);return;
  }if (dhjns[d[480429]] != d[480428]) {
    window['A187Z6'](d[480663] + dhjns[d[480429]]);return;
  }if (!dhjns[d[480430]] || dhjns[d[480430]][d[480009]] == 0x0) {
    window['A187Z6'](d[480664]);return;
  }A1Z6[d[480503]] = dhjns[d[480665]], A1Z6[d[480022]] = { 'server_id': String(dhjns[d[480430]][0x0][d[480023]]), 'server_name': String(dhjns[d[480430]][0x0][d[480409]]), 'entry_ip': dhjns[d[480430]][0x0][d[480666]], 'entry_port': parseInt(dhjns[d[480430]][0x0][d[480667]]), 'status': A1Z78(dhjns[d[480430]][0x0]), 'start_time': dhjns[d[480430]][0x0][d[480668]], 'cdn': A1Z6[d[480020]] }, this['A16Z78']();
}, window['A16Z78'] = function () {
  if (A1Z6[d[480503]] == 0x1) {
    var pku = A1Z6[d[480022]][d[480408]];if (pku === -0x1 || pku === 0x0) {
      window['A187Z6'](pku === -0x1 ? d[480669] : d[480670]);return;
    }A1687Z(0x0, A1Z6[d[480022]][d[480023]]), window[d[480034]][d[480035]][d[480498]](A1Z6[d[480503]]);
  } else window[d[480034]][d[480035]][d[480495]](), A18Z67();window['A1Z7'] = !![], window['A167Z8'](), window['A16Z87']();
}, window['A17Z86'] = function () {
  sendApi(A1Z6[d[480552]], d[480671], { 'game_pkg': A1Z6[d[480021]], 'version_name': A1Z6[d[480628]] }, this[d[480672]][d[480327]](this), A176Z, A168);
}, window[d[480672]] = function (got_bq) {
  if (!got_bq) {
    window['A187Z6'](d[480673]);return;
  }if (got_bq[d[480429]] != d[480428]) {
    window['A187Z6'](d[480674] + got_bq[d[480429]]);return;
  }if (!got_bq[d[480430]] || !got_bq[d[480430]][d[480079]]) {
    window['A187Z6'](d[480675] + (got_bq[d[480430]] && got_bq[d[480430]][d[480079]]));return;
  }got_bq[d[480430]][d[480676]] && got_bq[d[480430]][d[480676]][d[480009]] > 0xa && (A1Z6[d[480677]] = got_bq[d[480430]][d[480676]], A1Z6[d[480020]] = got_bq[d[480430]][d[480676]]), got_bq[d[480430]][d[480079]] && (A1Z6[d[480019]] = got_bq[d[480430]][d[480079]]), console[d[480000]](d[480678] + A1Z6[d[480019]] + d[480679] + A1Z6[d[480628]]), window['A1Z67'] = !![], window['A167Z8'](), window['A16Z87']();
}, window[d[480680]], window['A17Z68'] = function () {
  sendApi(A1Z6[d[480552]], d[480681], { 'game_pkg': A1Z6[d[480021]] }, this['A1768Z'][d[480327]](this), A176Z, A168);
}, window['A1768Z'] = function (g4o_b) {
  if (g4o_b[d[480429]] === d[480428] && g4o_b[d[480430]]) {
    window[d[480680]] = g4o_b[d[480430]];for (var hjwzl6 in g4o_b[d[480430]]) {
      A1Z6[hjwzl6] = g4o_b[d[480430]][hjwzl6];
    }
  } else console[d[480000]](d[480682] + g4o_b[d[480429]]);window['A17Z'] = !![], window['A16Z87']();
}, window[d[480683]] = function (jsdh6n, n$9am, bixq, kxpy1, v830a9, biyxqt, avm$9e, kp13, fo4_rg) {
  v830a9 = String(v830a9);var u3k1pi = avm$9e,
      a$nme9 = kp13;A1Z6[d[480548]][v830a9] = { 'productid': v830a9, 'productname': u3k1pi, 'productdesc': a$nme9, 'roleid': jsdh6n, 'rolename': n$9am, 'rolelevel': bixq, 'price': biyxqt, 'callback': fo4_rg }, sendApi(A1Z6[d[480556]], d[480684], { 'game_pkg': A1Z6[d[480021]], 'server_id': A1Z6[d[480022]][d[480023]], 'server_name': A1Z6[d[480022]][d[480409]], 'level': bixq, 'uid': A1Z6[d[480018]], 'role_id': jsdh6n, 'role_name': n$9am, 'product_id': v830a9, 'product_name': u3k1pi, 'product_desc': a$nme9, 'money': biyxqt, 'partner_id': A1Z6[d[480560]] }, toPayCallBack, A176Z, A168);
}, window[d[480685]] = function (hwj6zl) {
  if (hwj6zl) {
    if (hwj6zl[d[480686]] === 0xc8 || hwj6zl[d[480429]] == d[480428]) {
      var o_4rg = A1Z6[d[480548]][String(hwj6zl[d[480687]])];if (o_4rg[d[480688]]) o_4rg[d[480688]](hwj6zl[d[480687]], hwj6zl[d[480689]], -0x1);Atyxqbo[d[480690]]({ 'cpbill': hwj6zl[d[480689]], 'productid': hwj6zl[d[480687]], 'productname': o_4rg[d[480691]], 'productdesc': o_4rg[d[480692]], 'serverid': A1Z6[d[480022]][d[480023]], 'servername': A1Z6[d[480022]][d[480409]], 'roleid': o_4rg[d[480693]], 'rolename': o_4rg[d[480694]], 'rolelevel': o_4rg[d[480695]], 'price': o_4rg[d[480696]], 'extension': JSON[d[480026]]({ 'cp_order_id': hwj6zl[d[480689]] }) }, function (qr_g4o, s$demn) {
        o_4rg[d[480688]] && qr_g4o == 0x0 && o_4rg[d[480688]](hwj6zl[d[480687]], hwj6zl[d[480689]], qr_g4o);console[d[480000]](JSON[d[480026]]({ 'type': d[480697], 'status': qr_g4o, 'data': hwj6zl, 'role_name': o_4rg[d[480694]] }));if (qr_g4o === 0x0) {} else {
          if (qr_g4o === 0x1) {} else {
            if (qr_g4o === 0x2) {}
          }
        }
      });
    } else alert(hwj6zl[d[480000]]);
  }
}, window['A176Z8'] = function () {}, window['A1876'] = function (k1yxip, ku81p3, f457gr, hzjl2, md6njs) {
  Atyxqbo[d[480698]](A1Z6[d[480022]][d[480023]], A1Z6[d[480022]][d[480409]] || A1Z6[d[480022]][d[480023]], k1yxip, ku81p3, f457gr), sendApi(A1Z6[d[480552]], d[480699], { 'game_pkg': A1Z6[d[480021]], 'server_id': A1Z6[d[480022]][d[480023]], 'role_id': k1yxip, 'uid': A1Z6[d[480018]], 'role_name': ku81p3, 'role_type': hzjl2, 'level': f457gr });
}, window['A1867'] = function (g_oqt, xqybti, tyixpb, q4g_ob, $nsm, tobqg, a9emv$, a9vem$, j2zwl, fg547r) {
  A1Z6[d[480015]] = g_oqt, A1Z6[d[480016]] = xqybti, A1Z6[d[480017]] = tyixpb, Atyxqbo[d[480700]](A1Z6[d[480022]][d[480023]], A1Z6[d[480022]][d[480409]] || A1Z6[d[480022]][d[480023]], g_oqt, xqybti, tyixpb), sendApi(A1Z6[d[480552]], d[480701], { 'game_pkg': A1Z6[d[480021]], 'server_id': A1Z6[d[480022]][d[480023]], 'role_id': g_oqt, 'uid': A1Z6[d[480018]], 'role_name': xqybti, 'role_type': q4g_ob, 'level': tyixpb, 'evolution': $nsm });
}, window['A1786'] = function (xypi1t, e0$av9, groq_4, g4for_, ea$v9, iukp, ip, hzljw, v$a98, qxbtyi) {
  A1Z6[d[480015]] = xypi1t, A1Z6[d[480016]] = e0$av9, A1Z6[d[480017]] = groq_4, Atyxqbo[d[480702]](A1Z6[d[480022]][d[480023]], A1Z6[d[480022]][d[480409]] || A1Z6[d[480022]][d[480023]], xypi1t, e0$av9, groq_4), sendApi(A1Z6[d[480552]], d[480701], { 'game_pkg': A1Z6[d[480021]], 'server_id': A1Z6[d[480022]][d[480023]], 'role_id': xypi1t, 'uid': A1Z6[d[480018]], 'role_name': e0$av9, 'role_type': g4for_, 'level': groq_4, 'evolution': ea$v9 });
}, window['A1768'] = function (t1yi) {}, window['A187'] = function (gr4q_) {
  Atyxqbo[d[480703]](d[480703], function (k13pi) {
    gr4q_ && gr4q_(k13pi);
  });
}, window[d[480704]] = function () {
  Atyxqbo[d[480704]]();
}, window[d[480705]] = function () {
  Atyxqbo[d[480706]]();
}, window[d[480135]] = function (gt_bq) {
  window['A1687'] = gt_bq, window['A1687'] && window['A178'] && (console[d[480000]](d[480136] + window['A178'][d[480137]]), window['A1687'](window['A178']), window['A178'] = null);
}, window['A1678'] = function (d9$emn, jdnms6, ik1yu, yxtbqo) {
  window[d[480707]](d[480708], { 'game_pkg': window['A1Z6'][d[480021]], 'role_id': jdnms6, 'server_id': ik1yu }, yxtbqo);
}, window['A1Z876'] = function (ae9mn, _q4or) {
  function k1xipy(bogq_) {
    var puk381 = [],
        goq_4 = [],
        bt_qg = window[d[480005]][d[480709]];for (var ev9$am in bt_qg) {
      var got_qb = Number(ev9$am);(!ae9mn || !ae9mn[d[480009]] || ae9mn[d[480107]](got_qb) != -0x1) && (goq_4[d[480038]](bt_qg[ev9$am]), puk381[d[480038]]([got_qb, 0x3]));
    }window['A1$768Z'](window[d[480039]], d[480710]) >= 0x0 ? (console[d[480041]](d[480711]), Atyxqbo[d[480712]] && Atyxqbo[d[480712]](goq_4, function (_bgto) {
      console[d[480041]](d[480713]), console[d[480041]](_bgto);if (_bgto && _bgto[d[480058]] == d[480714]) for (var oyxq in bt_qg) {
        if (_bgto[bt_qg[oyxq]] == d[480715]) {
          var jzhlw2 = Number(oyxq);for (var ae0v$9 = 0x0; ae0v$9 < puk381[d[480009]]; ae0v$9++) {
            if (puk381[ae0v$9][0x0] == jzhlw2) {
              puk381[ae0v$9][0x1] = 0x1;break;
            }
          }
        }
      }window['A1$768Z'](window[d[480039]], d[480716]) >= 0x0 ? wx[d[480717]]({ 'withSubscriptions': !![], 'success': function (g5r74) {
          var txibyp = g5r74[d[480718]][d[480719]];if (txibyp) {
            console[d[480041]](d[480720]), console[d[480041]](txibyp);for (var k1u3i in bt_qg) {
              if (txibyp[bt_qg[k1u3i]] == d[480715]) {
                var g574 = Number(k1u3i);for (var ean$m9 = 0x0; ean$m9 < puk381[d[480009]]; ean$m9++) {
                  if (puk381[ean$m9][0x0] == g574) {
                    puk381[ean$m9][0x1] = 0x2;break;
                  }
                }
              }
            }console[d[480041]](puk381), _q4or && _q4or(puk381);
          } else console[d[480041]](d[480721]), console[d[480041]](g5r74), console[d[480041]](puk381), _q4or && _q4or(puk381);
        }, 'fail': function () {
          console[d[480041]](d[480722]), console[d[480041]](puk381), _q4or && _q4or(puk381);
        } }) : (console[d[480041]](d[480723] + window[d[480039]]), console[d[480041]](puk381), _q4or && _q4or(puk381));
    })) : (console[d[480041]](d[480724] + window[d[480039]]), console[d[480041]](puk381), _q4or && _q4or(puk381)), wx[d[480725]](k1xipy);
  }wx[d[480726]](k1xipy);
}, window['A1Z867'] = { 'isSuccess': ![], 'level': d[480727], 'isCharging': ![] }, window['A1Z786'] = function (yikup1) {
  wx[d[480123]]({ 'success': function (xypbit) {
      var got_b = window['A1Z867'];got_b[d[480728]] = !![], got_b[d[480125]] = Number(xypbit[d[480125]])[d[480729]](0x0), got_b[d[480127]] = xypbit[d[480127]], yikup1 && yikup1(got_b[d[480728]], got_b[d[480125]], got_b[d[480127]]);
    }, 'fail': function (e$av) {
      console[d[480041]](d[480730], e$av[d[480058]]);var jzlh2w = window['A1Z867'];yikup1 && yikup1(jzlh2w[d[480728]], jzlh2w[d[480125]], jzlh2w[d[480127]]);
    } });
}, window[d[480707]] = function (g_4qb, d$semn, bgo_, gf7r, nm9e$a, ro_f4g, gq4b_, amen) {
  if (gf7r == undefined) gf7r = 0x1;wx[d[480603]]({ 'url': g_4qb, 'method': gq4b_ || d[480731], 'responseType': d[480325], 'data': d$semn, 'header': { 'content-type': amen || d[480605] }, 'success': function (ua803v) {
      DEBUG && console[d[480041]](d[480732], g_4qb, info, ua803v);if (ua803v && ua803v[d[480733]] == 0xc8) {
        var $0a9v = ua803v[d[480430]];!ro_f4g || ro_f4g($0a9v) ? bgo_ && bgo_($0a9v) : window[d[480734]](g_4qb, d$semn, bgo_, gf7r, nm9e$a, ro_f4g, ua803v);
      } else window[d[480734]](g_4qb, d$semn, bgo_, gf7r, nm9e$a, ro_f4g, ua803v);
    }, 'fail': function (k3) {
      DEBUG && console[d[480041]](d[480735], g_4qb, info, k3), window[d[480734]](g_4qb, d$semn, bgo_, gf7r, nm9e$a, ro_f4g, k3);
    }, 'complete': function () {} });
}, window[d[480734]] = function (zhs6dj, j6hsdz, a3u80v, kxp1i, v0$e9a, emdn9, dme9) {
  kxp1i - 0x1 > 0x0 ? setTimeout(function () {
    window[d[480707]](zhs6dj, j6hsdz, a3u80v, kxp1i - 0x1, v0$e9a, emdn9);
  }, 0x3e8) : v0$e9a && v0$e9a(JSON[d[480026]]({ 'url': zhs6dj, 'response': dme9 }));
}, window[d[480736]] = function (uk03v8, wz2jhl, jl2h, sdjnm6, gf7_4, u13k0, shjz6d) {
  !jl2h && (jl2h = {});var dmjn6s = Math[d[480515]](Date[d[480141]]() / 0x3e8);jl2h[d[480659]] = dmjn6s, jl2h[d[480737]] = wz2jhl;var oq_tx = Object[d[480738]](jl2h)[d[480434]](),
      pty1xi = '',
      f4g_o = '';for (var ne$mds = 0x0; ne$mds < oq_tx[d[480009]]; ne$mds++) {
    pty1xi = pty1xi + (ne$mds == 0x0 ? '' : '&') + oq_tx[ne$mds] + jl2h[oq_tx[ne$mds]], f4g_o = f4g_o + (ne$mds == 0x0 ? '' : '&') + oq_tx[ne$mds] + '=' + encodeURIComponent(jl2h[oq_tx[ne$mds]]);
  }pty1xi = pty1xi + A1Z6[d[480558]];var jdh6s = d[480739] + md5(pty1xi);send(uk03v8 + '?' + f4g_o + (f4g_o == '' ? '' : '&') + jdh6s, null, sdjnm6, gf7_4, u13k0, shjz6d || function (qro4g_) {
    return qro4g_[d[480429]] == d[480428];
  }, null, d[480740]);
}, window['A1Z768'] = function (ave90$, _oq4g) {
  var yqbtx = 0x0;A1Z6[d[480022]] && (yqbtx = A1Z6[d[480022]][d[480023]]), sendApi(A1Z6[d[480554]], d[480741], { 'partnerId': A1Z6[d[480560]], 'gamePkg': A1Z6[d[480021]], 'logTime': Math[d[480515]](Date[d[480141]]() / 0x3e8), 'platformUid': A1Z6[d[480655]], 'type': ave90$, 'serverId': yqbtx }, null, 0x2, null, function () {
    return !![];
  });
}, window['A1Z687'] = function ($a) {
  sendApi(A1Z6[d[480552]], d[480742], { 'partner_id': A1Z6[d[480560]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480561]] }, A1Z678, A176Z, A168);
}, window['A1Z678'] = function (btiqx) {
  if (btiqx[d[480429]] === d[480428] && btiqx[d[480430]]) {
    btiqx[d[480430]][d[480743]]({ 'id': -0x2, 'name': d[480744] }), btiqx[d[480430]][d[480743]]({ 'id': -0x1, 'name': d[480745] }), A1Z6[d[480382]] = btiqx[d[480430]];if (window[d[480374]]) window[d[480374]][d[480415]]();
  } else A1Z6[d[480392]] = ![], window['A187Z6'](d[480746] + btiqx[d[480429]]);
}, window['A187Z'] = function (ndj6sm) {
  sendApi(A1Z6[d[480552]], d[480747], { 'partner_id': A1Z6[d[480560]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480561]] }, A18Z7, A176Z, A168);
}, window['A18Z7'] = function (men9$d) {
  A1Z6[d[480423]] = ![];if (men9$d[d[480429]] === d[480428] && men9$d[d[480430]]) {
    for (var ukp8 = 0x0; ukp8 < men9$d[d[480430]][d[480009]]; ukp8++) {
      men9$d[d[480430]][ukp8][d[480408]] = A1Z78(men9$d[d[480430]][ukp8]);
    }A1Z6[d[480421]][-0x1] = window[d[480748]](men9$d[d[480430]]), window[d[480374]][d[480422]](-0x1);
  } else window['A187Z6'](d[480749] + men9$d[d[480429]]);
}, window[d[480750]] = function (dmesn6) {
  sendApi(A1Z6[d[480552]], d[480747], { 'partner_id': A1Z6[d[480560]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480561]] }, dmesn6, A176Z, A168);
}, window['A178Z'] = function (p8k, qxti) {
  sendApi(A1Z6[d[480552]], d[480751], { 'partner_id': A1Z6[d[480560]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480561]], 'server_group_id': qxti }, A17Z8, A176Z, A168);
}, window['A17Z8'] = function (av9$0e) {
  A1Z6[d[480423]] = ![];if (av9$0e[d[480429]] === d[480428] && av9$0e[d[480430]] && av9$0e[d[480430]][d[480430]]) {
    var yixkp1 = av9$0e[d[480430]][d[480752]],
        u3vk8 = [];for (var bo_qtg = 0x0; bo_qtg < av9$0e[d[480430]][d[480430]][d[480009]]; bo_qtg++) {
      av9$0e[d[480430]][d[480430]][bo_qtg][d[480408]] = A1Z78(av9$0e[d[480430]][d[480430]][bo_qtg]), (u3vk8[d[480009]] == 0x0 || av9$0e[d[480430]][d[480430]][bo_qtg][d[480408]] != 0x0) && (u3vk8[u3vk8[d[480009]]] = av9$0e[d[480430]][d[480430]][bo_qtg]);
    }A1Z6[d[480421]][yixkp1] = window[d[480748]](u3vk8), window[d[480374]][d[480422]](yixkp1);
  } else window['A187Z6'](d[480753] + av9$0e[d[480429]]);
}, window['A1$76Z'] = function (t_obgq) {
  sendApi(A1Z6[d[480552]], d[480754], { 'partner_id': A1Z6[d[480560]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480561]] }, reqServerRecommendCallBack, A176Z, A168);
}, window[d[480755]] = function (a803) {
  A1Z6[d[480423]] = ![];if (a803[d[480429]] === d[480428] && a803[d[480430]]) {
    for (var n6esdm = 0x0; n6esdm < a803[d[480430]][d[480009]]; n6esdm++) {
      a803[d[480430]][n6esdm][d[480408]] = A1Z78(a803[d[480430]][n6esdm]);
    }A1Z6[d[480421]][-0x2] = window[d[480748]](a803[d[480430]]), window[d[480374]][d[480422]](-0x2);
  } else alert(d[480756] + a803[d[480429]]);
}, window[d[480748]] = function (pkx1iy) {
  if (!pkx1iy && pkx1iy[d[480009]] <= 0x0) return pkx1iy;for (let va9em = 0x0; va9em < pkx1iy[d[480009]]; va9em++) {
    pkx1iy[va9em][d[480757]] && pkx1iy[va9em][d[480757]] == 0x1 && (pkx1iy[va9em][d[480409]] += d[480758]);
  }return pkx1iy;
}, window['A1Z87'] = function (nmse, zl2w) {
  nmse = nmse || A1Z6[d[480022]][d[480023]], sendApi(A1Z6[d[480552]], d[480759], { 'type': '4', 'game_pkg': A1Z6[d[480021]], 'server_id': nmse }, zl2w);
}, window[d[480760]] = function (gorq4_, r4_go, p1i3k, iuyk1p) {
  p1i3k = p1i3k || A1Z6[d[480022]][d[480023]], sendApi(A1Z6[d[480552]], d[480761], { 'type': gorq4_, 'game_pkg': r4_go, 'server_id': p1i3k }, iuyk1p);
}, window['A1Z78'] = function (g4r57) {
  if (g4r57) {
    if (g4r57[d[480408]] == 0x1) {
      if (g4r57[d[480762]] == 0x1) return 0x2;else return 0x1;
    } else return g4r57[d[480408]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['A1687Z'] = function (d6m, z6hl) {
  A1Z6[d[480763]] = { 'step': d6m, 'server_id': z6hl };var njhs6d = this;A18Z76({ 'title': d[480764] }), sendApi(A1Z6[d[480552]], d[480765], { 'partner_id': A1Z6[d[480560]], 'uid': A1Z6[d[480018]], 'game_pkg': A1Z6[d[480021]], 'server_id': z6hl, 'platform': A1Z6[d[480083]], 'platform_uid': A1Z6[d[480655]], 'check_login_time': A1Z6[d[480658]], 'check_login_sign': A1Z6[d[480656]], 'version_name': A1Z6[d[480628]] }, A168Z7, A176Z, A168, function (tbyoqx) {
    return tbyoqx[d[480429]] == d[480428] || tbyoqx[d[480000]] == d[480766] || tbyoqx[d[480000]] == d[480767];
  });
}, window['A168Z7'] = function (r_fg4o) {
  var gqor4 = this;if (r_fg4o[d[480429]] === d[480428] && r_fg4o[d[480430]]) {
    var dmn6se = A1Z6[d[480022]];dmn6se[d[480768]] = A1Z6[d[480563]], dmn6se[d[480657]] = String(r_fg4o[d[480430]][d[480769]]), dmn6se[d[480569]] = parseInt(r_fg4o[d[480430]][d[480659]]);if (r_fg4o[d[480430]][d[480770]]) dmn6se[d[480770]] = parseInt(r_fg4o[d[480430]][d[480770]]);else dmn6se[d[480770]] = parseInt(r_fg4o[d[480430]][d[480023]]);dmn6se[d[480771]] = 0x0, dmn6se[d[480020]] = A1Z6[d[480677]], dmn6se[d[480772]] = r_fg4o[d[480430]][d[480773]], dmn6se[d[480774]] = r_fg4o[d[480430]][d[480774]], console[d[480041]](d[480775] + JSON[d[480026]](dmn6se[d[480774]])), A1Z6[d[480503]] == 0x1 && dmn6se[d[480774]] && dmn6se[d[480774]][d[480776]] == 0x1 && (A1Z6[d[480331]] = 0x1, window[d[480034]][d[480035]]['A1$6Z']()), A1678Z();
  } else A1Z6[d[480763]][d[480777]] >= 0x3 ? (A168(JSON[d[480026]](r_fg4o)), window['A187Z6'](d[480778] + r_fg4o[d[480429]])) : sendApi(A1Z6[d[480552]], d[480640], { 'platform': A1Z6[d[480550]], 'partner_id': A1Z6[d[480560]], 'token': A1Z6[d[480638]], 'game_pkg': A1Z6[d[480021]], 'deviceId': A1Z6[d[480561]], 'scene': d[480641] + A1Z6[d[480562]] }, function (yxbpti) {
    if (!yxbpti || yxbpti[d[480429]] != d[480428]) {
      window['A187Z6'](d[480653] + yxbpti && yxbpti[d[480429]]);return;
    }A1Z6[d[480656]] = String(yxbpti[d[480657]]), A1Z6[d[480658]] = String(yxbpti[d[480659]]), setTimeout(function () {
      A1687Z(A1Z6[d[480763]][d[480777]] + 0x1, A1Z6[d[480763]][d[480023]]);
    }, 0x5dc);
  }, A176Z, A168, function (kpuiy1) {
    return kpuiy1[d[480429]] == d[480428] || kpuiy1[d[480429]] == d[480779];
  });
}, window['A1678Z'] = function () {
  ServerLoading[d[480035]][d[480498]](A1Z6[d[480503]]), window['A176'] = !![], window['A16Z87']();
}, window['A167Z8'] = function () {
  if (window['A167'] && window['A1Z76'] && window[d[480494]] && window[d[480497]] && window['A1Z67'] && window['A1Z7']) {
    if (!window[d[480780]][d[480035]]) {
      console[d[480041]](d[480781] + window[d[480780]][d[480035]]);var bytxqo = wx[d[480782]](),
          hlj6wz = bytxqo[d[480137]] ? bytxqo[d[480137]] : 0x0,
          gr4_7f = { 'cdn': window['A1Z6'][d[480020]], 'spareCdn': window['A1Z6'][d[480626]], 'newRegister': window['A1Z6'][d[480503]], 'wxPC': window['A1Z6'][d[480112]], 'wxIOS': window['A1Z6'][d[480106]], 'wxAndroid': window['A1Z6'][d[480109]], 'wxParam': { 'limitLoad': window['A1Z6']['A1$876Z'], 'benchmarkLevel': window['A1Z6']['A1$8Z76'], 'wxFrom': window[d[480005]][d[480633]] == d[480783] ? 0x1 : 0x0, 'wxSDKVersion': window[d[480039]] }, 'configType': window['A1Z6'][d[480570]], 'exposeType': window['A1Z6'][d[480572]], 'scene': hlj6wz };new window[d[480780]](gr4_7f, window['A1Z6'][d[480019]], window['A1$87Z6']);
    }
  }
}, window['A16Z87'] = function () {
  if (window['A167'] && window['A1Z76'] && window[d[480494]] && window[d[480497]] && window['A1Z67'] && window['A1Z7'] && window['A176'] && window['A17Z']) {
    A18Z67();if (!A167Z) {
      A167Z = !![];if (!window[d[480780]][d[480035]]) window['A167Z8']();var jh6zlw = 0x0,
          frg5 = wx[d[480784]]();frg5 && (window['A1Z6'][d[480111]] && (jh6zlw = frg5[d[480101]]), console[d[480000]](d[480785] + frg5[d[480101]] + d[480786] + frg5[d[480102]] + d[480787] + frg5[d[480103]] + d[480788] + frg5[d[480104]] + d[480789] + frg5[d[480298]] + d[480790] + frg5[d[480300]]));var qxbt = {};for (const i1xypk in A1Z6[d[480022]]) {
        qxbt[i1xypk] = A1Z6[d[480022]][i1xypk];
      }var qbtx = { 'channel': window['A1Z6'][d[480564]], 'account': window['A1Z6'][d[480018]], 'userId': window['A1Z6'][d[480654]], 'serverId': qxbt[d[480023]], 'cdn': window['A1Z6'][d[480020]], 'data': window['A1Z6'][d[480430]], 'package': window['A1Z6'][d[480549]], 'newRegister': window['A1Z6'][d[480503]], 'pkgName': window['A1Z6'][d[480021]], 'partnerId': window['A1Z6'][d[480560]], 'platform_uid': window['A1Z6'][d[480655]], 'deviceId': window['A1Z6'][d[480561]], 'selectedServer': qxbt, 'configType': window['A1Z6'][d[480570]], 'exposeType': window['A1Z6'][d[480572]], 'debugUsers': window['A1Z6'][d[480567]], 'wxMenuTop': jh6zlw, 'wxShield': window['A1Z6'][d[480573]] };if (window[d[480680]]) for (var jhd6n in window[d[480680]]) {
        qbtx[jhd6n] = window[d[480680]][jhd6n];
      }window[d[480780]][d[480035]]['A16Z$'](qbtx);
    }
  } else console[d[480000]](d[480791] + window['A167'] + d[480792] + window['A1Z76'] + d[480793] + window[d[480494]] + d[480794] + window[d[480497]] + d[480795] + window['A1Z67'] + d[480796] + window['A1Z7'] + d[480797] + window['A176'] + d[480798] + window['A17Z']);
};