var d = wx.$A;
require('ABFAA.js'), window[d[481613]][d[481593]][d[481260]] = null, window['client_pb'] = require('AAIENAA.js'), window[d[481678]] = window[d[481613]][d[481443]][d[481311]](client_pb);