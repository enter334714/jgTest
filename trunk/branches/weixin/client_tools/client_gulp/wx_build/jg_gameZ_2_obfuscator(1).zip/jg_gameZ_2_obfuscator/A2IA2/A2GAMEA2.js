var d = wx.$A;
console[d[480000]](d[480001]), window[d[480002]], wx[d[480003]](function (a$9v0e) {
  if (a$9v0e) {
    if (a$9v0e[d[480004]]) {
      var hzjwl2 = window[d[480005]][d[480006]][d[480007]](new RegExp(/\./, 'g'), '_'),
          a$80v9 = a$9v0e[d[480004]],
          u1piy = a$80v9[d[480008]](/(AAAAA\/A2GAMEA2.js:)[0-9]{1,60}(:)/g);if (u1piy) for (var _qgbt = 0x0; _qgbt < u1piy[d[480009]]; _qgbt++) {
        if (u1piy[_qgbt] && u1piy[_qgbt][d[480009]] > 0x0) {
          var pyi1tx = parseInt(u1piy[_qgbt][d[480007]](d[480010], '')[d[480007]](':', ''));a$80v9 = a$80v9[d[480007]](u1piy[_qgbt], u1piy[_qgbt][d[480007]](':' + pyi1tx + ':', ':' + (pyi1tx - 0x2) + ':'));
        }
      }a$80v9 = a$80v9[d[480007]](new RegExp(d[480011], 'g'), d[480012] + hzjwl2 + d[480013]), a$80v9 = a$80v9[d[480007]](new RegExp(d[480014], 'g'), d[480012] + hzjwl2 + d[480013]), a$9v0e[d[480004]] = a$80v9;
    }var ybtpi = { 'id': window['A1Z6'][d[480015]], 'role': window['A1Z6'][d[480016]], 'level': window['A1Z6'][d[480017]], 'user': window['A1Z6'][d[480018]], 'version': window['A1Z6'][d[480019]], 'cdn': window['A1Z6'][d[480020]], 'pkgName': window['A1Z6'][d[480021]], 'gamever': window[d[480005]][d[480006]], 'serverid': window['A1Z6'][d[480022]] ? window['A1Z6'][d[480022]][d[480023]] : 0x0, 'systemInfo': window[d[480024]], 'error': d[480025], 'stack': a$9v0e ? a$9v0e[d[480004]] : '' },
        togqb = JSON[d[480026]](ybtpi);console[d[480027]](d[480028] + togqb), (!window[d[480002]] || window[d[480002]] != ybtpi[d[480027]]) && (window[d[480002]] = ybtpi[d[480027]], window['A18Z'](ybtpi));
  }
});import 'AAbfAA.js';import 'AA11AA.js';window[d[480029]] = require(d[480030]);import 'AINDAA.js';import 'AAIB1AA.js';import 'AAMtadAA.js';import 'AAINIAaA.js';console[d[480000]](d[480031]), console[d[480000]](d[480032]), A18Z76({ 'title': d[480033] });var Abxo_qt = { 'A1$86Z7': !![] };new window[d[480034]](Abxo_qt), window[d[480034]][d[480035]]['A1$7Z68']();if (window['A1$8Z67']) clearInterval(window['A1$8Z67']);window['A1$8Z67'] = null, window['A1$768Z'] = function (u1k8p3, jl6zh) {
  if (!u1k8p3 || !jl6zh) return 0x0;u1k8p3 = u1k8p3[d[480036]]('.'), jl6zh = jl6zh[d[480036]]('.');const hdsj6n = Math[d[480037]](u1k8p3[d[480009]], jl6zh[d[480009]]);while (u1k8p3[d[480009]] < hdsj6n) {
    u1k8p3[d[480038]]('0');
  }while (jl6zh[d[480009]] < hdsj6n) {
    jl6zh[d[480038]]('0');
  }for (var bq_xot = 0x0; bq_xot < hdsj6n; bq_xot++) {
    const $9v8a0 = parseInt(u1k8p3[bq_xot]),
          zjh6ws = parseInt(jl6zh[bq_xot]);if ($9v8a0 > zjh6ws) return 0x1;else {
      if ($9v8a0 < zjh6ws) return -0x1;
    }
  }return 0x0;
}, window[d[480039]] = wx[d[480040]]()[d[480039]], console[d[480041]](d[480042] + window[d[480039]]);var Aibtp = wx[d[480043]]();Aibtp[d[480044]](function (qyxit) {
  console[d[480041]](d[480045] + qyxit[d[480046]]);
}), Aibtp[d[480047]](function () {
  wx[d[480048]]({ 'title': d[480049], 'content': d[480050], 'showCancel': ![], 'success': function (ipx) {
      Aibtp[d[480051]]();
    } });
}), Aibtp[d[480052]](function () {
  console[d[480041]](d[480053]);
}), window['A1$76Z8'] = function () {
  console[d[480041]](d[480054]);var xboyq = wx[d[480055]]({ 'name': d[480056], 'success': function (yxt1ip) {
      console[d[480041]](d[480057]), console[d[480041]](yxt1ip), yxt1ip && yxt1ip[d[480058]] == d[480059] ? (window['A167'] = !![], window['A167Z8'](), window['A16Z87']()) : setTimeout(function () {
        window['A1$76Z8']();
      }, 0x1f4);
    }, 'fail': function (yqtxbo) {
      console[d[480041]](d[480060]), console[d[480041]](yqtxbo), setTimeout(function () {
        window['A1$76Z8']();
      }, 0x1f4);
    } });xboyq && xboyq[d[480061]](m6dnj => {});
}, window['A1$Z867'] = function () {
  console[d[480041]](d[480062]);var lhz6wj = wx[d[480055]]({ 'name': d[480063], 'success': function (g57r) {
      console[d[480041]](d[480064]), console[d[480041]](g57r), g57r && g57r[d[480058]] == d[480059] ? (window['A1Z76'] = !![], window['A167Z8'](), window['A16Z87']()) : setTimeout(function () {
        window['A1$Z867']();
      }, 0x1f4);
    }, 'fail': function (m9a$ve) {
      console[d[480041]](d[480065]), console[d[480041]](m9a$ve), setTimeout(function () {
        window['A1$Z867']();
      }, 0x1f4);
    } });lhz6wj && lhz6wj[d[480061]](bx_oqt => {});
}, window[d[480066]] = function () {
  window['A1$768Z'](window[d[480039]], d[480067]) >= 0x0 ? (console[d[480041]](d[480068] + window[d[480039]] + d[480069]), window['A1Z8'](), window['A1$76Z8'](), window['A1$Z867']()) : (window['A1Z68'](d[480070], window[d[480039]]), wx[d[480048]]({ 'title': d[480071], 'content': d[480072] }));
}, window[d[480024]] = '', wx[d[480073]]({ 'success'(nh6jds) {
    window[d[480024]] = d[480074] + nh6jds[d[480075]] + d[480076] + nh6jds[d[480077]] + d[480078] + nh6jds[d[480079]] + d[480080] + nh6jds[d[480081]] + d[480082] + nh6jds[d[480083]] + d[480084] + nh6jds[d[480039]] + d[480085] + nh6jds[d[480086]], console[d[480041]](window[d[480024]]), console[d[480041]](d[480087] + nh6jds[d[480088]] + d[480089] + nh6jds[d[480090]] + d[480091] + nh6jds[d[480092]] + d[480093] + nh6jds[d[480094]] + d[480095] + nh6jds[d[480096]] + d[480097] + nh6jds[d[480098]] + d[480099] + (nh6jds[d[480100]] ? nh6jds[d[480100]][d[480101]] + ',' + nh6jds[d[480100]][d[480102]] + ',' + nh6jds[d[480100]][d[480103]] + ',' + nh6jds[d[480100]][d[480104]] : ''));var $08va9 = nh6jds[d[480081]] ? nh6jds[d[480081]][d[480105]]() : '',
        s6wj = nh6jds[d[480077]] ? nh6jds[d[480077]][d[480105]]()[d[480007]]('\x20', '') : '';window['A1Z6'][d[480106]] = $08va9[d[480107]](d[480108]) != -0x1, window['A1Z6'][d[480109]] = $08va9[d[480107]](d[480110]) != -0x1, window['A1Z6'][d[480111]] = $08va9[d[480107]](d[480108]) != -0x1 || $08va9[d[480107]](d[480110]) != -0x1, window['A1Z6'][d[480112]] = $08va9[d[480107]](d[480113]) != -0x1 || $08va9[d[480107]](d[480114]) != -0x1, window['A1Z6'][d[480115]] = nh6jds[d[480083]] ? nh6jds[d[480083]][d[480105]]() : '', window['A1Z6']['A1$876Z'] = ![], window['A1Z6']['A1$8Z76'] = 0x2;if ($08va9[d[480107]](d[480110]) != -0x1) {
      if (nh6jds[d[480086]] >= 0x18) window['A1Z6']['A1$8Z76'] = 0x3;else window['A1Z6']['A1$8Z76'] = 0x2;
    } else {
      if ($08va9[d[480107]](d[480108]) != -0x1) {
        if (nh6jds[d[480086]] && nh6jds[d[480086]] >= 0x14) window['A1Z6']['A1$8Z76'] = 0x3;else {
          if (s6wj[d[480107]](d[480116]) != -0x1 || s6wj[d[480107]](d[480117]) != -0x1 || s6wj[d[480107]](d[480118]) != -0x1 || s6wj[d[480107]](d[480119]) != -0x1 || s6wj[d[480107]](d[480120]) != -0x1) window['A1Z6']['A1$8Z76'] = 0x2;else window['A1Z6']['A1$8Z76'] = 0x3;
        }
      } else window['A1Z6']['A1$8Z76'] = 0x2;
    }console[d[480041]](d[480121] + window['A1Z6']['A1$876Z'] + d[480122] + window['A1Z6']['A1$8Z76']);
  } }), wx[d[480123]]({ 'success': function (ixtqby) {
    console[d[480041]](d[480124] + ixtqby[d[480125]] + d[480126] + ixtqby[d[480127]]);
  } }), wx[d[480128]]({ 'success': function (d6) {
    console[d[480041]](d[480129] + d6[d[480130]]);
  } }), wx[d[480131]]({ 'keepScreenOn': !![] }), wx[d[480132]](function (tqxiby) {
  console[d[480041]](d[480129] + tqxiby[d[480130]] + d[480133] + tqxiby[d[480134]]);
}), wx[d[480135]](function (s6hjwz) {
  window['A178'] = s6hjwz, window['A1687'] && window['A178'] && (console[d[480000]](d[480136] + window['A178'][d[480137]]), window['A1687'](window['A178']), window['A178'] = null);
}), window[d[480138]] = 0x0, window['A1$Z768'] = 0x0, window[d[480139]] = null, wx[d[480140]](function () {
  window['A1$Z768']++;var e$9av0 = Date[d[480141]]();(window[d[480138]] == 0x0 || e$9av0 - window[d[480138]] > 0x1d4c0) && (console[d[480142]](d[480143]), wx[d[480144]]());if (window['A1$Z768'] >= 0x2) {
    window['A1$Z768'] = 0x0, console[d[480027]](d[480145]), wx[d[480146]]('0', 0x1);if (window['A1Z6'] && window['A1Z6'][d[480106]]) window['A1Z68'](d[480147], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});