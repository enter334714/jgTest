var d = wx.$A;
import 'A2MAIA2.js';