var p = wx.$h;
import a_rnpw2x from '../cccck/cccsdk.js';window[p[49265]] = { 'wxVersion': window[p[20557]][p[49164]] }, window[p[49266]] = ![], window['$aVQ'] = 0x1, window[p[49267]] = 0x1, window['$a3QV'] = !![], window[p[49268]] = !![], window['$aH53QV'] = '', window['$aQV'] = { 'base_cdn': p[49269], 'cdn': p[49269] }, $aQV[p[49270]] = {}, $aQV[p[45053]] = '0', $aQV[p[24741]] = window[p[49265]][p[49271]], $aQV[p[49237]] = '', $aQV['os'] = '1', $aQV[p[49272]] = p[49273], $aQV[p[49274]] = p[49275], $aQV[p[49276]] = p[49277], $aQV[p[49278]] = p[49279], $aQV[p[49280]] = p[49281], $aQV[p[43753]] = '1', $aQV[p[45348]] = '', $aQV[p[45350]] = '', $aQV[p[49282]] = 0x0, $aQV[p[49283]] = {}, $aQV[p[49284]] = parseInt($aQV[p[43753]]), $aQV[p[45346]] = $aQV[p[43753]], $aQV[p[45342]] = {}, $aQV['$a5Q'] = p[49285], $aQV[p[49286]] = ![], $aQV[p[32297]] = p[49287], $aQV[p[45321]] = Date[p[20083]](), $aQV[p[31899]] = p[49288], $aQV[p[20714]] = '_a', $aQV[p[49289]] = 0x2, $aQV[p[20101]] = 0x7c1, $aQV[p[49271]] = window[p[49265]][p[49271]], $aQV[p[20738]] = ![], $aQV[p[21074]] = ![], $aQV[p[31375]] = ![], $aQV[p[45055]] = ![], window['$a3VQ'] = 0x5, window['$a3V'] = ![], window['$aV3'] = ![], window['$aQ3V'] = ![], window[p[49290]] = ![], window[p[49291]] = ![], window['$aQV3'] = ![], window['$a3Q'] = ![], window['$aQ3'] = ![], window['$aV3Q'] = ![], window[p[24209]] = function (kg80h6) {
  console[p[20482]](p[24209], kg80h6), wx[p[25021]]({}), wx[p[49188]]({ 'title': p[26395], 'content': kg80h6, 'success'(f1t3j) {
      if (f1t3j[p[49292]]) console[p[20482]](p[49293]);else f1t3j[p[20553]] && console[p[20482]](p[49294]);
    } });
}, window['$a53QV'] = function (h$68k0) {
  console[p[20482]](p[49295], h$68k0), $a5QV3(), wx[p[49188]]({ 'title': p[26395], 'content': h$68k0, 'confirmText': p[49296], 'cancelText': p[38585], 'success'(xg2v_) {
      if (xg2v_[p[49292]]) window['$aQ5']();else xg2v_[p[20553]] && (console[p[20482]](p[49297]), wx[p[45048]]({}));
    } });
}, window[p[49298]] = function (m1c5) {
  console[p[20482]](p[49298], m1c5), wx[p[49188]]({ 'title': p[26395], 'content': m1c5, 'confirmText': p[45478], 'showCancel': ![], 'complete'(ky6e$i) {
      console[p[20482]](p[49297]), wx[p[45048]]({});
    } });
}, window['$a53VQ'] = ![], window['$a5Q3V'] = function (sf3t1j) {
  window['$a53VQ'] = !![], wx[p[25020]](sf3t1j);
}, window['$a5QV3'] = function () {
  window['$a53VQ'] && (window['$a53VQ'] = ![], wx[p[25021]]({}));
}, window['$a5V3Q'] = function ($iy) {
  window[p[49179]][p[20148]]['$a5V3Q']($iy);
}, window[p[32175]] = function (y9ozqb, ts5cd1) {
  a_rnpw2x[p[32175]](y9ozqb, function (x0v_g) {
    x0v_g && x0v_g[p[20011]] ? x0v_g[p[20011]][p[24142]] == 0x1 ? ts5cd1(!![]) : (ts5cd1(![]), console[p[20078]](p[49299] + x0v_g[p[20011]][p[49300]])) : console[p[20482]](p[32175], x0v_g);
  });
}, window['$a5VQ3'] = function (x2) {
  console[p[20482]](p[49301], x2);
}, window['$a5QV'] = function (d5smc1) {}, window['$a5VQ'] = function (v_h8, bziy9o, k$06) {}, window['$a5V'] = function (iy$e6) {
  console[p[20482]](p[49302], iy$e6), window[p[49179]][p[20148]][p[49303]](), window[p[49179]][p[20148]][p[49304]](), window[p[49179]][p[20148]][p[49305]]();
}, window['$aV5'] = function (t3jf1s) {
  window['$a53QV'](p[49306]);var fap73 = { 'id': window['$aQV'][p[49169]], 'role': window['$aQV'][p[24670]], 'level': window['$aQV'][p[49170]], 'account': window['$aQV'][p[45347]], 'version': window['$aQV'][p[20101]], 'cdn': window['$aQV'][p[24547]], 'pkgName': window['$aQV'][p[45348]], 'gamever': window[p[20557]][p[49164]], 'serverid': window['$aQV'][p[45342]] ? window['$aQV'][p[45342]][p[31553]] : 0x0, 'systemInfo': window[p[49171]], 'error': p[49307], 'stack': t3jf1s ? t3jf1s : p[49306] },
      ar4pw = JSON[p[24533]](fap73);console[p[20125]](p[49308] + ar4pw), window['$a5Q'](ar4pw);
}, window['$aQ5V'] = function (v2nrxw) {
  var f37pa4 = JSON[p[20527]](v2nrxw);f37pa4[p[49309]] = window[p[20557]][p[49164]], f37pa4[p[49310]] = window['$aQV'][p[45342]] ? window['$aQV'][p[45342]][p[31553]] : 0x0, f37pa4[p[49171]] = window[p[49171]];var j3ft1s = JSON[p[24533]](f37pa4);console[p[20125]](p[49311] + j3ft1s), window['$a5Q'](j3ft1s);
}, window['$aQV5'] = function (yei6$b, ts1fjc) {
  var qzyo9b = { 'id': window['$aQV'][p[49169]], 'role': window['$aQV'][p[24670]], 'level': window['$aQV'][p[49170]], 'account': window['$aQV'][p[45347]], 'version': window['$aQV'][p[20101]], 'cdn': window['$aQV'][p[24547]], 'pkgName': window['$aQV'][p[45348]], 'gamever': window[p[20557]][p[49164]], 'serverid': window['$aQV'][p[45342]] ? window['$aQV'][p[45342]][p[31553]] : 0x0, 'systemInfo': window[p[49171]], 'error': yei6$b, 'stack': ts1fjc },
      mdsl5 = JSON[p[24533]](qzyo9b);console[p[20096]](p[49312] + mdsl5), window['$a5Q'](mdsl5);
}, window['$a5Q'] = function (pranw) {
  if (window['$aQV'][p[49238]] == p[49062]) return;var f1j3t7 = $aQV['$a5Q'] + p[49313] + $aQV[p[45347]];wx[p[20477]]({ 'url': f1j3t7, 'method': p[49037], 'data': pranw, 'header': { 'content-type': p[49314], 'cache-control': p[49315] }, 'success': function (_kh0) {
      DEBUG && console[p[20482]](p[49316], f1j3t7, pranw, _kh0);
    }, 'fail': function (md5s1c) {
      DEBUG && console[p[20482]](p[49316], f1j3t7, pranw, md5s1c);
    }, 'complete': function () {} });
}, window[p[49317]] = function () {
  function jt15s() {
    return ((0x1 + Math[p[20119]]()) * 0x10000 | 0x0)[p[20275]](0x10)[p[20500]](0x1);
  }return jt15s() + jt15s() + '-' + jt15s() + '-' + jt15s() + '-' + jt15s() + '+' + jt15s() + jt15s() + jt15s();
}, window['$aQ5'] = function () {
  console[p[20482]](p[49318]);var _02x = a_rnpw2x[p[49319]]();$aQV[p[45346]] = _02x[p[49320]], $aQV[p[49284]] = _02x[p[49320]], $aQV[p[43753]] = _02x[p[49320]], $aQV[p[45348]] = _02x[p[49321]];var oieby$ = { 'game_ver': $aQV[p[24741]] };$aQV[p[45350]] = this[p[49317]](), $a5Q3V({ 'title': p[49322] }), a_rnpw2x[p[20368]](oieby$, this['$aV5Q'][p[20074]](this));
}, window['$aV5Q'] = function (sct1d) {
  var b6$yei = sct1d[p[49323]];console[p[20482]](p[49324] + b6$yei + p[49325] + (b6$yei == 0x1) + p[49326] + sct1d[p[49164]] + p[49327] + window[p[49265]][p[49271]]);if (!sct1d[p[49164]] || window['$aH3V5Q'](window[p[49265]][p[49271]], sct1d[p[49164]]) < 0x0) console[p[20482]](p[49328]), $aQV[p[49274]] = p[49329], $aQV[p[49276]] = p[49330], $aQV[p[49278]] = p[49331], $aQV[p[24547]] = p[49332], $aQV[p[45052]] = p[49333], $aQV[p[49334]] = 'ts', $aQV[p[20738]] = ![];else window['$aH3V5Q'](window[p[49265]][p[49271]], sct1d[p[49164]]) == 0x0 ? (console[p[20482]](p[49335]), $aQV[p[49274]] = p[49275], $aQV[p[49276]] = p[49277], $aQV[p[49278]] = p[49279], $aQV[p[24547]] = p[49336], $aQV[p[45052]] = p[49333], $aQV[p[49334]] = p[49337], $aQV[p[20738]] = !![]) : (console[p[20482]](p[49338]), $aQV[p[49274]] = p[49275], $aQV[p[49276]] = p[49277], $aQV[p[49278]] = p[49279], $aQV[p[24547]] = p[49336], $aQV[p[45052]] = p[49333], $aQV[p[49334]] = p[49337], $aQV[p[20738]] = ![]);$aQV[p[49282]] = config[p[48631]] ? config[p[48631]] : 0x0, this['$a3Q5V'](), this['$a3QV5'](), window[p[49339]] = 0x5, $a5Q3V({ 'title': p[49340] }), a_rnpw2x[p[49021]](this['$aVQ5'][p[20074]](this));
}, window[p[49339]] = 0x5, window['$aVQ5'] = function (o9yb, kiy$) {
  if (o9yb == 0x0 && kiy$ && kiy$[p[48724]]) {
    $aQV[p[49341]] = kiy$[p[48724]];var sc5t1d = this;$a5Q3V({ 'title': p[49342] }), sendApi($aQV[p[49274]], p[49343], { 'platform': $aQV[p[49272]], 'partner_id': $aQV[p[43753]], 'token': kiy$[p[48724]], 'game_pkg': $aQV[p[45348]], 'deviceId': $aQV[p[45350]], 'scene': p[49344] + $aQV[p[49282]] }, this['$a35QV'][p[20074]](this), $a3VQ, $aV5);
  } else kiy$ && kiy$[p[45533]] && window[p[49339]] > 0x0 && (kiy$[p[45533]][p[20115]](p[49345]) != -0x1 || kiy$[p[45533]][p[20115]](p[49346]) != -0x1 || kiy$[p[45533]][p[20115]](p[49347]) != -0x1 || kiy$[p[45533]][p[20115]](p[49348]) != -0x1 || kiy$[p[45533]][p[20115]](p[49349]) != -0x1 || kiy$[p[45533]][p[20115]](p[49350]) != -0x1) ? (window[p[49339]]--, a_rnpw2x[p[49021]](this['$aVQ5'][p[20074]](this))) : (window['$aQV5'](p[49351], JSON[p[24533]]({ 'status': o9yb, 'data': kiy$ })), window['$a53QV'](p[49352] + (kiy$ && kiy$[p[45533]] ? '，' + kiy$[p[45533]] : '')));
}, window['$a35QV'] = function (tsfc1j) {
  if (!tsfc1j) {
    window['$aQV5'](p[49353], p[49354]), window['$a53QV'](p[49355]);return;
  }if (tsfc1j[p[24142]] != p[29963]) {
    window['$aQV5'](p[49353], JSON[p[24533]](tsfc1j)), window['$a53QV'](p[49356] + tsfc1j[p[24142]]);return;
  }$aQV[p[43752]] = String(tsfc1j[p[45347]]), $aQV[p[45347]] = String(tsfc1j[p[45347]]), $aQV[p[45319]] = String(tsfc1j[p[45319]]), $aQV[p[45346]] = String(tsfc1j[p[45319]]), $aQV[p[45349]] = String(tsfc1j[p[45349]]), $aQV[p[49357]] = String(tsfc1j[p[31536]]), $aQV[p[49358]] = String(tsfc1j[p[20851]]), $aQV[p[31536]] = '';var ieob9y = this;$a5Q3V({ 'title': p[49359] }), sendApi($aQV[p[49274]], p[49360], { 'partner_id': $aQV[p[43753]], 'uid': $aQV[p[45347]], 'version': $aQV[p[24741]], 'game_pkg': $aQV[p[45348]], 'device': $aQV[p[45350]] }, ieob9y['$a35VQ'][p[20074]](ieob9y), $a3VQ, $aV5);
}, window['$a35VQ'] = function (wn4rp) {
  if (!wn4rp) {
    window['$a53QV'](p[49361]);return;
  }if (wn4rp[p[24142]] != p[29963]) {
    window['$a53QV'](p[49362] + wn4rp[p[24142]]);return;
  }if (!wn4rp[p[20011]] || wn4rp[p[20011]][p[20013]] == 0x0) {
    window['$a53QV'](p[49363]);return;
  }$aQV[p[20630]] = wn4rp[p[49364]], $aQV[p[45342]] = { 'server_id': String(wn4rp[p[20011]][0x0][p[31553]]), 'server_name': String(wn4rp[p[20011]][0x0][p[49365]]), 'entry_ip': wn4rp[p[20011]][0x0][p[45370]], 'entry_port': parseInt(wn4rp[p[20011]][0x0][p[45371]]), 'status': $aQ35(wn4rp[p[20011]][0x0]), 'start_time': wn4rp[p[20011]][0x0][p[49366]], 'cdn': $aQV[p[24547]] }, this['$aVQ35']();
}, window['$aVQ35'] = function () {
  if ($aQV[p[20630]] == 0x1) {
    var war = $aQV[p[45342]][p[20106]];if (war === -0x1 || war === 0x0) {
      window['$a53QV'](war === -0x1 ? p[49367] : p[49368]);return;
    }$aV53Q(0x0, $aQV[p[45342]][p[31553]]), window[p[49179]][p[20148]][p[49369]]($aQV[p[20630]]);
  } else window[p[49179]][p[20148]][p[49370]](), $a5QV3();window['$aQ3'] = !![], window['$aV3Q5'](), window['$aVQ53']();
}, window['$a3Q5V'] = function () {
  sendApi($aQV[p[49274]], p[49371], { 'game_pkg': $aQV[p[45348]], 'version_name': $aQV[p[49334]] }, this[p[49372]][p[20074]](this), $a3VQ, $aV5);
}, window[p[49372]] = function (rnp4a) {
  if (!rnp4a) {
    window['$a53QV'](p[49373]);return;
  }if (rnp4a[p[24142]] != p[29963]) {
    window['$a53QV'](p[49374] + rnp4a[p[24142]]);return;
  }if (!rnp4a[p[20011]] || !rnp4a[p[20011]][p[24741]]) {
    window['$a53QV'](p[49375] + (rnp4a[p[20011]] && rnp4a[p[20011]][p[24741]]));return;
  }rnp4a[p[20011]][p[49376]] && rnp4a[p[20011]][p[49376]][p[20013]] > 0xa && ($aQV[p[49377]] = rnp4a[p[20011]][p[49376]], $aQV[p[24547]] = rnp4a[p[20011]][p[49376]]), rnp4a[p[20011]][p[24741]] && ($aQV[p[20101]] = rnp4a[p[20011]][p[24741]]), console[p[20078]](p[45484] + $aQV[p[20101]] + p[49378] + $aQV[p[49334]]), window['$aQV3'] = !![], window['$aV3Q5'](), window['$aVQ53']();
}, window[p[49379]], window['$a3QV5'] = function () {
  sendApi($aQV[p[49274]], p[49380], { 'game_pkg': $aQV[p[45348]] }, this['$a3V5Q'][p[20074]](this), $a3VQ, $aV5);
}, window['$a3V5Q'] = function (ybio) {
  if (ybio[p[24142]] === p[29963] && ybio[p[20011]]) {
    window[p[49379]] = ybio[p[20011]];for (var rxp2wn in ybio[p[20011]]) {
      $aQV[rxp2wn] = ybio[p[20011]][rxp2wn];
    }
  } else console[p[20078]](p[49381] + ybio[p[24142]]);window['$a3Q'] = !![], window['$aVQ53']();
}, window[p[49382]] = function (g8k6h0, rxw2p, h0vgx_, a4wnp, hek68$, rnx2wp, wprxn, zqy9ob, io$) {
  hek68$ = String(hek68$);var rwnpa = wprxn,
      mdscl5 = zqy9ob;$aQV[p[49270]][hek68$] = { 'productid': hek68$, 'productname': rwnpa, 'productdesc': mdscl5, 'roleid': g8k6h0, 'rolename': rxw2p, 'rolelevel': h0vgx_, 'price': rnx2wp, 'callback': io$ }, sendApi($aQV[p[49278]], p[49383], { 'game_pkg': $aQV[p[45348]], 'server_id': $aQV[p[45342]][p[31553]], 'server_name': $aQV[p[45342]][p[49365]], 'level': h0vgx_, 'uid': $aQV[p[45347]], 'role_id': g8k6h0, 'role_name': rxw2p, 'product_id': hek68$, 'product_name': rwnpa, 'product_desc': mdscl5, 'money': rnx2wp, 'partner_id': $aQV[p[43753]] }, toPayCallBack, $a3VQ, $aV5);
}, window[p[49384]] = function (iyk$e6) {
  if (iyk$e6) {
    if (iyk$e6[p[49385]] === 0xc8 || iyk$e6[p[24142]] == p[29963]) {
      var ozi9yb = $aQV[p[49270]][String(iyk$e6[p[49386]])];if (ozi9yb[p[20335]]) ozi9yb[p[20335]](iyk$e6[p[49386]], iyk$e6[p[49387]], -0x1);a_rnpw2x[p[49055]]({ 'cpbill': iyk$e6[p[49387]], 'productid': iyk$e6[p[49386]], 'productname': ozi9yb[p[49388]], 'productdesc': ozi9yb[p[49389]], 'serverid': $aQV[p[45342]][p[31553]], 'servername': $aQV[p[45342]][p[49365]], 'roleid': ozi9yb[p[49390]], 'rolename': ozi9yb[p[49391]], 'rolelevel': ozi9yb[p[49392]], 'price': ozi9yb[p[47050]], 'extension': JSON[p[24533]]({ 'cp_order_id': iyk$e6[p[49387]] }) }, function (_gh0v8, k8h$6e) {
        ozi9yb[p[20335]] && _gh0v8 == 0x0 && ozi9yb[p[20335]](iyk$e6[p[49386]], iyk$e6[p[49387]], _gh0v8);console[p[20078]](JSON[p[24533]]({ 'type': p[49393], 'status': _gh0v8, 'data': iyk$e6, 'role_name': ozi9yb[p[49391]] }));if (_gh0v8 === 0x0) {} else {
          if (_gh0v8 === 0x1) {} else {
            if (_gh0v8 === 0x2) {}
          }
        }
      });
    } else alert(iyk$e6[p[20078]]);
  }
}, window['$a3VQ5'] = function () {}, window['$a53V'] = function (fa4j37, ds1cm5, wpn2rx, nxv, xh0_v) {
  a_rnpw2x[p[49106]]($aQV[p[45342]][p[31553]], $aQV[p[45342]][p[49365]] || $aQV[p[45342]][p[31553]], fa4j37, ds1cm5, wpn2rx), sendApi($aQV[p[49274]], p[49394], { 'game_pkg': $aQV[p[45348]], 'server_id': $aQV[p[45342]][p[31553]], 'role_id': fa4j37, 'uid': $aQV[p[45347]], 'role_name': ds1cm5, 'role_type': nxv, 'level': wpn2rx });
}, window['$a5V3'] = function (f7ap, iyeb$o, ik6$ey, r2n_xv, $y6eib, afp437, stj, g8_0vh, ap4nr, ykei) {
  $aQV[p[49169]] = f7ap, $aQV[p[24670]] = iyeb$o, $aQV[p[49170]] = ik6$ey, a_rnpw2x[p[49107]]($aQV[p[45342]][p[31553]], $aQV[p[45342]][p[49365]] || $aQV[p[45342]][p[31553]], f7ap, iyeb$o, ik6$ey), sendApi($aQV[p[49274]], p[49395], { 'game_pkg': $aQV[p[45348]], 'server_id': $aQV[p[45342]][p[31553]], 'role_id': f7ap, 'uid': $aQV[p[45347]], 'role_name': iyeb$o, 'role_type': r2n_xv, 'level': ik6$ey, 'evolution': $y6eib });
}, window['$a35V'] = function (ibe, $8ike6, a73f, nw2rpx, a4j7f3, h_x0g, $6hek, _xngv2, d5cml, p73aw4) {
  $aQV[p[49169]] = ibe, $aQV[p[24670]] = $8ike6, $aQV[p[49170]] = a73f, a_rnpw2x[p[49108]]($aQV[p[45342]][p[31553]], $aQV[p[45342]][p[49365]] || $aQV[p[45342]][p[31553]], ibe, $8ike6, a73f), sendApi($aQV[p[49274]], p[49395], { 'game_pkg': $aQV[p[45348]], 'server_id': $aQV[p[45342]][p[31553]], 'role_id': ibe, 'uid': $aQV[p[45347]], 'role_name': $8ike6, 'role_type': nw2rpx, 'level': a73f, 'evolution': a4j7f3 });
}, window['$a3V5'] = function ($ie86k) {}, window['$a53'] = function (rv2xn) {
  a_rnpw2x[p[49140]](p[49140], function (a734j) {
    rv2xn && rv2xn(a734j);
  });
}, window[p[45032]] = function () {
  a_rnpw2x[p[45032]]();
}, window[p[49396]] = function () {
  a_rnpw2x[p[43645]]();
}, window[p[49397]] = function (e$h6k, sj3t, tjc1fs, byei9, jf734, bye9, h8kg_0, xhvg0) {
  xhvg0 = xhvg0 || $aQV[p[45342]][p[31553]], sendApi($aQV[p[49274]], p[49398], { 'phone': e$h6k, 'role_id': sj3t, 'uid': $aQV[p[45347]], 'game_pkg': $aQV[p[45348]], 'partner_id': $aQV[p[43753]], 'server_id': xhvg0 }, h8kg_0);
}, window[p[30885]] = function (s5mcd) {
  window['$aV53'] = s5mcd, window['$aV53'] && window['$a35'] && (console[p[20078]](p[49257] + window['$a35'][p[20776]]), window['$aV53'](window['$a35']), window['$a35'] = null);
}, window['$aV35'] = function (k_8g, k6he8, wpxrn, i6eky) {
  window[p[20022]](p[49399], { 'game_pkg': window['$aQV'][p[45348]], 'role_id': k6he8, 'server_id': wpxrn }, i6eky);
}, window['$aQ53V'] = function (q9oyzb, pna4w) {
  function j3ft71(i$be) {
    var ke6$h8 = [],
        vrx_2n = [],
        g8h_0 = window[p[20557]][p[49400]];for (var hk086g in g8h_0) {
      var wnrvx = Number(hk086g);(!q9oyzb || !q9oyzb[p[20013]] || q9oyzb[p[20115]](wnrvx) != -0x1) && (vrx_2n[p[20029]](g8h_0[hk086g]), ke6$h8[p[20029]]([wnrvx, 0x3]));
    }window['$aH3V5Q'](window[p[49180]], p[49401]) >= 0x0 ? (console[p[20482]](p[49402]), a_rnpw2x[p[49158]] && a_rnpw2x[p[49158]](vrx_2n, function (ei$k68) {
      console[p[20482]](p[49403]), console[p[20482]](ei$k68);if (ei$k68 && ei$k68[p[45533]] == p[49404]) for (var i9ybeo in g8h_0) {
        if (ei$k68[g8h_0[i9ybeo]] == p[49405]) {
          var s5cmd = Number(i9ybeo);for (var f31tsj = 0x0; f31tsj < ke6$h8[p[20013]]; f31tsj++) {
            if (ke6$h8[f31tsj][0x0] == s5cmd) {
              ke6$h8[f31tsj][0x1] = 0x1;break;
            }
          }
        }
      }window['$aH3V5Q'](window[p[49180]], p[49406]) >= 0x0 ? wx[p[49407]]({ 'withSubscriptions': !![], 'success': function (n2x_) {
          var eo$yib = n2x_[p[49408]][p[49409]];if (eo$yib) {
            console[p[20482]](p[49410]), console[p[20482]](eo$yib);for (var h8k_g in g8h_0) {
              if (eo$yib[g8h_0[h8k_g]] == p[49405]) {
                var oy$eib = Number(h8k_g);for (var h_8 = 0x0; h_8 < ke6$h8[p[20013]]; h_8++) {
                  if (ke6$h8[h_8][0x0] == oy$eib) {
                    ke6$h8[h_8][0x1] = 0x2;break;
                  }
                }
              }
            }console[p[20482]](ke6$h8), pna4w && pna4w(ke6$h8);
          } else console[p[20482]](p[49411]), console[p[20482]](n2x_), console[p[20482]](ke6$h8), pna4w && pna4w(ke6$h8);
        }, 'fail': function () {
          console[p[20482]](p[49412]), console[p[20482]](ke6$h8), pna4w && pna4w(ke6$h8);
        } }) : (console[p[20482]](p[49413] + window[p[49180]]), console[p[20482]](ke6$h8), pna4w && pna4w(ke6$h8));
    })) : (console[p[20482]](p[49414] + window[p[49180]]), console[p[20482]](ke6$h8), pna4w && pna4w(ke6$h8)), wx[p[49415]](j3ft71);
  }wx[p[49416]](j3ft71);
}, window['$aQ5V3'] = { 'isSuccess': ![], 'level': p[49417], 'isCharging': ![] }, window['$aQ35V'] = function (fsj1tc) {
  wx[p[49246]]({ 'success': function (t4j3) {
      var f4t73j = window['$aQ5V3'];f4t73j[p[49418]] = !![], f4t73j[p[24646]] = Number(t4j3[p[24646]])[p[24257]](0x0), f4t73j[p[49249]] = t4j3[p[49249]], fsj1tc && fsj1tc(f4t73j[p[49418]], f4t73j[p[24646]], f4t73j[p[49249]]);
    }, 'fail': function (sjt13f) {
      console[p[20482]](p[49419], sjt13f[p[45533]]);var $6yike = window['$aQ5V3'];fsj1tc && fsj1tc($6yike[p[49418]], $6yike[p[24646]], $6yike[p[49249]]);
    } });
}, window[p[20022]] = function (_gv0x, a37w, c1sd5t, jt1sc, m5sd1c, ft1cjs, stf1j3, a73jf4) {
  if (jt1sc == undefined) jt1sc = 0x1;wx[p[20477]]({ 'url': _gv0x, 'method': stf1j3 || p[45238], 'responseType': p[24454], 'data': a37w, 'header': { 'content-type': a73jf4 || p[49314] }, 'success': function (yzi9bo) {
      DEBUG && console[p[20482]](p[49420], _gv0x, info, yzi9bo);if (yzi9bo && yzi9bo[p[45604]] == 0xc8) {
        var v2r = yzi9bo[p[20011]];!ft1cjs || ft1cjs(v2r) ? c1sd5t && c1sd5t(v2r) : window[p[49421]](_gv0x, a37w, c1sd5t, jt1sc, m5sd1c, ft1cjs, yzi9bo);
      } else window[p[49421]](_gv0x, a37w, c1sd5t, jt1sc, m5sd1c, ft1cjs, yzi9bo);
    }, 'fail': function (wnp2) {
      DEBUG && console[p[20482]](p[49422], _gv0x, info, wnp2), window[p[49421]](_gv0x, a37w, c1sd5t, jt1sc, m5sd1c, ft1cjs, wnp2);
    }, 'complete': function () {} });
}, window[p[49421]] = function (ap4f37, tj1sf, tj731f, rpan, oyie$b, qoyzb, tf13js) {
  rpan - 0x1 > 0x0 ? setTimeout(function () {
    window[p[20022]](ap4f37, tj1sf, tj731f, rpan - 0x1, oyie$b, qoyzb);
  }, 0x3e8) : oyie$b && oyie$b(JSON[p[24533]]({ 'url': ap4f37, 'response': tf13js }));
}, window[p[49423]] = function (_2gvnx, j1f7t, v_n2xg, stj51c, $68, ap4rw7, n2rxw) {
  !v_n2xg && (v_n2xg = {});var p4rnwa = Math[p[20118]](Date[p[20083]]() / 0x3e8);v_n2xg[p[20851]] = p4rnwa, v_n2xg[p[49424]] = j1f7t;var awpr = Object[p[20267]](v_n2xg)[p[21078]](),
      ts13j = '',
      ie9by = '';for (var $eyo = 0x0; $eyo < awpr[p[20013]]; $eyo++) {
    ts13j = ts13j + ($eyo == 0x0 ? '' : '&') + awpr[$eyo] + v_n2xg[awpr[$eyo]], ie9by = ie9by + ($eyo == 0x0 ? '' : '&') + awpr[$eyo] + '=' + encodeURIComponent(v_n2xg[awpr[$eyo]]);
  }ts13j = ts13j + $aQV[p[49280]];var ybei$o = p[49425] + md5(ts13j);send(_2gvnx + '?' + ie9by + (ie9by == '' ? '' : '&') + ybei$o, null, stj51c, $68, ap4rw7, n2rxw || function (ft7j13) {
    return ft7j13[p[24142]] == p[29963];
  }, null, p[49038]);
}, window['$aQ3V5'] = function (xrwnp, $68ei) {
  var _gvn = 0x0;$aQV[p[45342]] && (_gvn = $aQV[p[45342]][p[31553]]), sendApi($aQV[p[49276]], p[49426], { 'partnerId': $aQV[p[43753]], 'gamePkg': $aQV[p[45348]], 'logTime': Math[p[20118]](Date[p[20083]]() / 0x3e8), 'platformUid': $aQV[p[45349]], 'type': xrwnp, 'serverId': _gvn }, null, 0x2, null, function () {
    return !![];
  });
}, window['$aQV53'] = function (sj3ft) {
  sendApi($aQV[p[49274]], p[49427], { 'partner_id': $aQV[p[43753]], 'uid': $aQV[p[45347]], 'version': $aQV[p[24741]], 'game_pkg': $aQV[p[45348]], 'device': $aQV[p[45350]] }, $aQV35, $a3VQ, $aV5);
}, window['$aQV35'] = function ($yibe6) {
  if ($yibe6[p[24142]] === p[29963] && $yibe6[p[20011]]) {
    $yibe6[p[20011]][p[25624]]({ 'id': -0x2, 'name': p[49428] }), $yibe6[p[20011]][p[25624]]({ 'id': -0x1, 'name': p[49429] }), $aQV[p[49430]] = $yibe6[p[20011]];if (window[p[32347]]) window[p[32347]][p[49431]]();
  } else $aQV[p[49432]] = ![], window['$a53QV'](p[49433] + $yibe6[p[24142]]);
}, window['$a53Q'] = function (v_02gx) {
  sendApi($aQV[p[49274]], p[49434], { 'partner_id': $aQV[p[43753]], 'uid': $aQV[p[45347]], 'version': $aQV[p[24741]], 'game_pkg': $aQV[p[45348]], 'device': $aQV[p[45350]] }, $a5Q3, $a3VQ, $aV5);
}, window['$a5Q3'] = function (c5s) {
  $aQV[p[49435]] = ![];if (c5s[p[24142]] === p[29963] && c5s[p[20011]]) {
    for (var g6hk0 = 0x0; g6hk0 < c5s[p[20011]][p[20013]]; g6hk0++) {
      c5s[p[20011]][g6hk0][p[20106]] = $aQ35(c5s[p[20011]][g6hk0]);
    }$aQV[p[49283]][-0x1] = window[p[49436]](c5s[p[20011]]), window[p[32347]][p[49437]](-0x1);
  } else window['$a53QV'](p[49438] + c5s[p[24142]]);
}, window[p[49439]] = function (x_g) {
  sendApi($aQV[p[49274]], p[49434], { 'partner_id': $aQV[p[43753]], 'uid': $aQV[p[45347]], 'version': $aQV[p[24741]], 'game_pkg': $aQV[p[45348]], 'device': $aQV[p[45350]] }, x_g, $a3VQ, $aV5);
}, window['$a35Q'] = function (io$yb, aw3p4) {
  sendApi($aQV[p[49274]], p[49440], { 'partner_id': $aQV[p[43753]], 'uid': $aQV[p[45347]], 'version': $aQV[p[24741]], 'game_pkg': $aQV[p[45348]], 'device': $aQV[p[45350]], 'server_group_id': aw3p4 }, $a3Q5, $a3VQ, $aV5);
}, window['$a3Q5'] = function (c1sft) {
  $aQV[p[49435]] = ![];if (c1sft[p[24142]] === p[29963] && c1sft[p[20011]] && c1sft[p[20011]][p[20011]]) {
    var s15tdc = c1sft[p[20011]][p[49441]],
        g0xhv_ = [];for (var f3jt74 = 0x0; f3jt74 < c1sft[p[20011]][p[20011]][p[20013]]; f3jt74++) {
      c1sft[p[20011]][p[20011]][f3jt74][p[20106]] = $aQ35(c1sft[p[20011]][p[20011]][f3jt74]), (g0xhv_[p[20013]] == 0x0 || c1sft[p[20011]][p[20011]][f3jt74][p[20106]] != 0x0) && (g0xhv_[g0xhv_[p[20013]]] = c1sft[p[20011]][p[20011]][f3jt74]);
    }$aQV[p[49283]][s15tdc] = window[p[49436]](g0xhv_), window[p[32347]][p[49437]](s15tdc);
  } else window['$a53QV'](p[49442] + c1sft[p[24142]]);
}, window['$aH3VQ'] = function (ftjs3) {
  sendApi($aQV[p[49274]], p[49443], { 'partner_id': $aQV[p[43753]], 'uid': $aQV[p[45347]], 'version': $aQV[p[24741]], 'game_pkg': $aQV[p[45348]], 'device': $aQV[p[45350]] }, reqServerRecommendCallBack, $a3VQ, $aV5);
}, window[p[49444]] = function (g0vx) {
  $aQV[p[49435]] = ![];if (g0vx[p[24142]] === p[29963] && g0vx[p[20011]]) {
    for (var rpw4 = 0x0; rpw4 < g0vx[p[20011]][p[20013]]; rpw4++) {
      g0vx[p[20011]][rpw4][p[20106]] = $aQ35(g0vx[p[20011]][rpw4]);
    }$aQV[p[49283]][-0x2] = window[p[49436]](g0vx[p[20011]]), window[p[32347]][p[49437]](-0x2);
  } else alert(p[49445] + g0vx[p[24142]]);
}, window[p[49436]] = function (w37ap4) {
  if (!w37ap4 && w37ap4[p[20013]] <= 0x0) return w37ap4;for (let w7a3 = 0x0; w7a3 < w37ap4[p[20013]]; w7a3++) {
    w37ap4[w7a3][p[49446]] && w37ap4[w7a3][p[49446]] == 0x1 && (w37ap4[w7a3][p[49365]] += p[49447]);
  }return w37ap4;
}, window['$aQ53'] = function (tsdc15, e$6iyb) {
  tsdc15 = tsdc15 || $aQV[p[45342]][p[31553]], sendApi($aQV[p[49274]], p[49448], { 'type': '4', 'game_pkg': $aQV[p[45348]], 'server_id': tsdc15 }, e$6iyb);
}, window[p[49449]] = function (narp2, k8_h0g, ie9yob, dlsm5) {
  ie9yob = ie9yob || $aQV[p[45342]][p[31553]], sendApi($aQV[p[49274]], p[49450], { 'type': narp2, 'game_pkg': k8_h0g, 'server_id': ie9yob }, dlsm5);
}, window['$aQ35'] = function (nrxv2w) {
  if (nrxv2w) {
    if (nrxv2w[p[20106]] == 0x1) {
      if (nrxv2w[p[49451]] == 0x1) return 0x2;else return 0x1;
    } else return nrxv2w[p[20106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$aV53Q'] = function (d1tc5s, t17f) {
  $aQV[p[49452]] = { 'step': d1tc5s, 'server_id': t17f };var xng = this;$a5Q3V({ 'title': p[49453] }), sendApi($aQV[p[49274]], p[49454], { 'partner_id': $aQV[p[43753]], 'uid': $aQV[p[45347]], 'game_pkg': $aQV[p[45348]], 'server_id': t17f, 'platform': $aQV[p[45319]], 'platform_uid': $aQV[p[45349]], 'check_login_time': $aQV[p[49358]], 'check_login_sign': $aQV[p[49357]], 'version_name': $aQV[p[49334]] }, $aV5Q3, $a3VQ, $aV5, function (yob9i) {
    return yob9i[p[24142]] == p[29963] || yob9i[p[20078]] == p[49455] || yob9i[p[20078]] == p[49456];
  });
}, window['$aV5Q3'] = function (biyo9z) {
  var j1f3ts = this;if (biyo9z[p[24142]] === p[29963] && biyo9z[p[20011]]) {
    var y$eb6i = $aQV[p[45342]];y$eb6i[p[49457]] = $aQV[p[49284]], y$eb6i[p[31536]] = String(biyo9z[p[20011]][p[49458]]), y$eb6i[p[45321]] = parseInt(biyo9z[p[20011]][p[20851]]);if (biyo9z[p[20011]][p[45320]]) y$eb6i[p[45320]] = parseInt(biyo9z[p[20011]][p[45320]]);else y$eb6i[p[45320]] = parseInt(biyo9z[p[20011]][p[31553]]);y$eb6i[p[49459]] = 0x0, y$eb6i[p[24547]] = $aQV[p[49377]], y$eb6i[p[49460]] = biyo9z[p[20011]][p[49461]], y$eb6i[p[49462]] = biyo9z[p[20011]][p[49462]], console[p[20482]](p[49463] + JSON[p[24533]](y$eb6i[p[49462]])), $aQV[p[20630]] == 0x1 && y$eb6i[p[49462]] && y$eb6i[p[49462]][p[49464]] == 0x1 && ($aQV[p[49465]] = 0x1, window[p[49179]][p[20148]]['$aHVQ']()), $aV35Q();
  } else $aQV[p[49452]][p[27165]] >= 0x3 ? ($aV5(JSON[p[24533]](biyo9z)), window['$a53QV'](p[49466] + biyo9z[p[24142]])) : sendApi($aQV[p[49274]], p[49343], { 'platform': $aQV[p[49272]], 'partner_id': $aQV[p[43753]], 'token': $aQV[p[49341]], 'game_pkg': $aQV[p[45348]], 'deviceId': $aQV[p[45350]], 'scene': p[49344] + $aQV[p[49282]] }, function (vx_2r) {
    if (!vx_2r || vx_2r[p[24142]] != p[29963]) {
      window['$a53QV'](p[49356] + vx_2r && vx_2r[p[24142]]);return;
    }$aQV[p[49357]] = String(vx_2r[p[31536]]), $aQV[p[49358]] = String(vx_2r[p[20851]]), setTimeout(function () {
      $aV53Q($aQV[p[49452]][p[27165]] + 0x1, $aQV[p[49452]][p[31553]]);
    }, 0x5dc);
  }, $a3VQ, $aV5, function (zyi9bo) {
    return zyi9bo[p[24142]] == p[29963] || zyi9bo[p[24142]] == p[45683];
  });
}, window['$aV35Q'] = function () {
  ServerLoading[p[20148]][p[49369]]($aQV[p[20630]]), window['$a3V'] = !![], window['$aVQ53']();
}, window['$aV3Q5'] = function () {
  if (window['$aV3'] && window['$aQ3V'] && window[p[49290]] && window[p[49291]] && window['$aQV3'] && window['$aQ3']) {
    if (!window[p[48614]][p[20148]]) {
      console[p[20482]](p[49467] + window[p[48614]][p[20148]]);var oiby$e = wx[p[49468]](),
          ibo$ = oiby$e[p[20776]] ? oiby$e[p[20776]] : 0x0,
          _nv2gx = { 'cdn': window['$aQV'][p[24547]], 'spareCdn': window['$aQV'][p[45052]], 'newRegister': window['$aQV'][p[20630]], 'wxPC': window['$aQV'][p[45055]], 'wxIOS': window['$aQV'][p[21074]], 'wxAndroid': window['$aQV'][p[31375]], 'wxParam': { 'limitLoad': window['$aQV']['$aH53VQ'], 'benchmarkLevel': window['$aQV']['$aH5Q3V'], 'wxFrom': window[p[20557]][p[48631]] == p[49469] ? 0x1 : 0x0, 'wxSDKVersion': window[p[49180]] }, 'configType': window['$aQV'][p[31899]], 'exposeType': window['$aQV'][p[20714]], 'scene': ibo$ };new window[p[48614]](_nv2gx, window['$aQV'][p[20101]], window['$aH53QV']);
    }
  }
}, window['$aVQ53'] = function () {
  if (window['$aV3'] && window['$aQ3V'] && window[p[49290]] && window[p[49291]] && window['$aQV3'] && window['$aQ3'] && window['$a3V'] && window['$a3Q']) {
    $a5QV3();if (!$aV3Q) {
      $aV3Q = !![];if (!window[p[48614]][p[20148]]) window['$aV3Q5']();var apr4w = 0x0,
          gkh_ = wx[p[49470]]();gkh_ && (window['$aQV'][p[49236]] && (apr4w = gkh_[p[20323]]), console[p[20078]](p[49471] + gkh_[p[20323]] + p[49472] + gkh_[p[21216]] + p[49473] + gkh_[p[21218]] + p[49474] + gkh_[p[21217]] + p[49475] + gkh_[p[20176]] + p[49476] + gkh_[p[20177]]));var y$6iek = {};for (const yzio in $aQV[p[45342]]) {
        y$6iek[yzio] = $aQV[p[45342]][yzio];
      }var vxg02 = { 'channel': window['$aQV'][p[45346]], 'account': window['$aQV'][p[45347]], 'userId': window['$aQV'][p[43752]], 'cdn': window['$aQV'][p[24547]], 'data': window['$aQV'][p[20011]], 'package': window['$aQV'][p[45053]], 'newRegister': window['$aQV'][p[20630]], 'pkgName': window['$aQV'][p[45348]], 'partnerId': window['$aQV'][p[43753]], 'platform_uid': window['$aQV'][p[45349]], 'deviceId': window['$aQV'][p[45350]], 'selectedServer': y$6iek, 'configType': window['$aQV'][p[31899]], 'exposeType': window['$aQV'][p[20714]], 'debugUsers': window['$aQV'][p[32297]], 'wxMenuTop': apr4w, 'wxShield': window['$aQV'][p[20738]] };if (window[p[49379]]) for (var panr in window[p[49379]]) {
        vxg02[panr] = window[p[49379]][panr];
      }window[p[48614]][p[20148]]['$aVQH'](vxg02);
    }
  } else console[p[20078]](p[49477] + window['$aV3'] + p[49478] + window['$aQ3V'] + p[49479] + window[p[49290]] + p[49480] + window[p[49291]] + p[49481] + window['$aQV3'] + p[49482] + window['$aQ3'] + p[49483] + window['$a3V'] + p[49484] + window['$a3Q']);
};