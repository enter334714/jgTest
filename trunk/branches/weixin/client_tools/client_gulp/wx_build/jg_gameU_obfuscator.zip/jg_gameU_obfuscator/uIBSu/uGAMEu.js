var o = wx.$U;
console[o[340001]](o[340002]), window[o[340003]], wx[o[340004]](function (vesu$n) {
  if (vesu$n) {
    if (vesu$n[o[340005]]) {
      var zd7g9 = window[o[340006]][o[340007]][o[340008]](new RegExp(/\./, 'g'), '_'),
          qoil = vesu$n[o[340005]],
          su$nv = qoil[o[340009]](/(uuuuuuu\/uGAMEu.js:)[0-9]{1,60}(:)/g);if (su$nv) for (var qxlg = 0x0; qxlg < su$nv[o[340010]]; qxlg++) {
        if (su$nv[qxlg] && su$nv[qxlg][o[340010]] > 0x0) {
          var e$fsp = parseInt(su$nv[qxlg][o[340008]](o[340011], '')[o[340008]](':', ''));qoil = qoil[o[340008]](su$nv[qxlg], su$nv[qxlg][o[340008]](':' + e$fsp + ':', ':' + (e$fsp - 0x2) + ':'));
        }
      }qoil = qoil[o[340008]](new RegExp(o[340012], 'g'), o[340013] + zd7g9 + o[340014]), qoil = qoil[o[340008]](new RegExp(o[340015], 'g'), o[340013] + zd7g9 + o[340014]), vesu$n[o[340005]] = qoil;
    }var z9gdw5 = { 'id': window['u$$8'][o[340016]], 'role': window['u$$8'][o[340017]], 'level': window['u$$8'][o[340018]], 'user': window['u$$8'][o[340019]], 'version': window['u$$8'][o[340020]], 'cdn': window['u$$8'][o[340021]], 'pkgName': window['u$$8'][o[340022]], 'gamever': window[o[340006]][o[340007]], 'serverid': window['u$$8'][o[340023]] ? window['u$$8'][o[340023]][o[340024]] : 0x0, 'systemInfo': window[o[340025]], 'error': o[340026], 'stack': vesu$n ? vesu$n[o[340005]] : '' },
        snuv = JSON[o[340027]](z9gdw5);console[o[340028]](o[340029] + snuv), (!window[o[340003]] || window[o[340003]] != z9gdw5[o[340028]]) && (window[o[340003]] = z9gdw5[o[340028]], window['u$0$'](z9gdw5));
  }
});import 'uufuu.js';import 'uu112uu.js';window[o[340030]] = require(o[340031]);import 'uINDuu.js';import 'uuIB23uu.js';import 'uXMtaduu.js';import 'uuINIuu.js';console[o[340001]](o[340032]), console[o[340001]](o[340033]), u$0$G8({ 'title': o[340034] });var uz5wd = { 'u$708$G': !![] };new window[o[340035]](uz5wd), window[o[340035]][o[340036]]['u$7G$80']();if (window['u$70$8G']) clearInterval(window['u$70$8G']);window['u$70$8G'] = null, window['u$7G80$'] = function (imh4j, nf$us) {
  if (!imh4j || !nf$us) return 0x0;imh4j = imh4j[o[340037]]('.'), nf$us = nf$us[o[340037]]('.');const $fsune = Math[o[340038]](imh4j[o[340010]], nf$us[o[340010]]);while (imh4j[o[340010]] < $fsune) {
    imh4j[o[340039]]('0');
  }while (nf$us[o[340010]] < $fsune) {
    nf$us[o[340039]]('0');
  }for (var xq7ilo = 0x0; xq7ilo < $fsune; xq7ilo++) {
    const p3hf4j = parseInt(imh4j[xq7ilo]),
          homj = parseInt(nf$us[xq7ilo]);if (p3hf4j > homj) return 0x1;else {
      if (p3hf4j < homj) return -0x1;
    }
  }return 0x0;
}, window[o[340040]] = wx[o[340041]]()[o[340040]], console[o[340042]](o[340043] + window[o[340040]]);var ucvk6a = wx[o[340044]]();ucvk6a[o[340045]](function (wqlo7x) {
  console[o[340042]](o[340046] + wqlo7x[o[340047]]);
}), ucvk6a[o[340048]](function () {
  wx[o[340049]]({ 'title': o[340050], 'content': o[340051], 'showCancel': ![], 'success': function (f$ues) {
      ucvk6a[o[340052]]();
    } });
}), ucvk6a[o[340053]](function () {
  console[o[340042]](o[340054]);
}), window['u$7G8$0'] = function () {
  console[o[340042]](o[340055]);var dgw5z9 = wx[o[340056]]({ 'name': o[340057], 'success': function (akcv6) {
      console[o[340042]](o[340058]), console[o[340042]](akcv6), akcv6 && akcv6[o[340059]] == o[340060] ? (window['u$8G'] = !![], window['u$8G$0'](), window['u$8$0G']()) : setTimeout(function () {
        window['u$7G8$0']();
      }, 0x1f4);
    }, 'fail': function (u$sep) {
      console[o[340042]](o[340061]), console[o[340042]](u$sep), setTimeout(function () {
        window['u$7G8$0']();
      }, 0x1f4);
    } });dgw5z9 && dgw5z9[o[340062]](qwg7x => {});
}, window['u$7$08G'] = function () {
  console[o[340042]](o[340063]);var gtd95 = wx[o[340056]]({ 'name': o[340064], 'success': function (r8a6) {
      console[o[340042]](o[340065]), console[o[340042]](r8a6), r8a6 && r8a6[o[340059]] == o[340060] ? (window['u$$G8'] = !![], window['u$8G$0'](), window['u$8$0G']()) : setTimeout(function () {
        window['u$7$08G']();
      }, 0x1f4);
    }, 'fail': function (vs$ne_) {
      console[o[340042]](o[340066]), console[o[340042]](vs$ne_), setTimeout(function () {
        window['u$7$08G']();
      }, 0x1f4);
    } });gtd95 && gtd95[o[340062]](r601c8 => {});
}, window[o[340067]] = function () {
  window['u$7G80$'](window[o[340040]], o[340068]) >= 0x0 ? (console[o[340042]](o[340069] + window[o[340040]] + o[340070]), window['u$$0'](), window['u$7G8$0'](), window['u$7$08G']()) : (window['u$$80'](o[340071], window[o[340040]]), wx[o[340049]]({ 'title': o[340072], 'content': o[340073] }));
}, window[o[340025]] = '', wx[o[340074]]({ 'success'(nvs$_e) {
    window[o[340025]] = o[340075] + nvs$_e[o[340076]] + o[340077] + nvs$_e[o[340078]] + o[340079] + nvs$_e[o[340080]] + o[340081] + nvs$_e[o[340082]] + o[340083] + nvs$_e[o[340084]] + o[340085] + nvs$_e[o[340040]] + o[340086] + nvs$_e[o[340087]], console[o[340042]](window[o[340025]]), console[o[340042]](o[340088] + nvs$_e[o[340089]] + o[340090] + nvs$_e[o[340091]] + o[340092] + nvs$_e[o[340093]] + o[340094] + nvs$_e[o[340095]] + o[340096] + nvs$_e[o[340097]] + o[340098] + nvs$_e[o[340099]] + o[340100] + (nvs$_e[o[340101]] ? nvs$_e[o[340101]][o[340102]] + ',' + nvs$_e[o[340101]][o[340103]] + ',' + nvs$_e[o[340101]][o[340104]] + ',' + nvs$_e[o[340101]][o[340105]] : ''));var u4jfp = nvs$_e[o[340082]] ? nvs$_e[o[340082]][o[340106]]() : '',
        z9dt25 = nvs$_e[o[340078]] ? nvs$_e[o[340078]][o[340106]]()[o[340008]]('\x20', '') : '';window['u$$8'][o[340107]] = u4jfp[o[340108]](o[340109]) != -0x1, window['u$$8'][o[340110]] = u4jfp[o[340108]](o[340111]) != -0x1, window['u$$8'][o[340112]] = u4jfp[o[340108]](o[340109]) != -0x1 || u4jfp[o[340108]](o[340111]) != -0x1, window['u$$8'][o[340113]] = u4jfp[o[340108]](o[340114]) != -0x1 || u4jfp[o[340108]](o[340115]) != -0x1, window['u$$8'][o[340116]] = nvs$_e[o[340084]] ? nvs$_e[o[340084]][o[340106]]() : '', window['u$$8']['u$70G8$'] = ![], window['u$$8']['u$70$G8'] = 0x2;if (u4jfp[o[340108]](o[340111]) != -0x1) {
      if (nvs$_e[o[340087]] >= 0x18) window['u$$8']['u$70$G8'] = 0x3;else window['u$$8']['u$70$G8'] = 0x2;
    } else {
      if (u4jfp[o[340108]](o[340109]) != -0x1) {
        if (nvs$_e[o[340087]] && nvs$_e[o[340087]] >= 0x14) window['u$$8']['u$70$G8'] = 0x3;else {
          if (z9dt25[o[340108]](o[340117]) != -0x1 || z9dt25[o[340108]](o[340118]) != -0x1 || z9dt25[o[340108]](o[340119]) != -0x1 || z9dt25[o[340108]](o[340120]) != -0x1 || z9dt25[o[340108]](o[340121]) != -0x1) window['u$$8']['u$70$G8'] = 0x2;else window['u$$8']['u$70$G8'] = 0x3;
        }
      } else window['u$$8']['u$70$G8'] = 0x2;
    }console[o[340042]](o[340122] + window['u$$8']['u$70G8$'] + o[340123] + window['u$$8']['u$70$G8']);
  } }), wx[o[340124]]({ 'success': function (k6v_ac) {
    console[o[340042]](o[340125] + k6v_ac[o[340126]] + o[340127] + k6v_ac[o[340128]]);
  } }), wx[o[340129]]({ 'success': function (ep$sf) {
    console[o[340042]](o[340130] + ep$sf[o[340131]]);
  } }), wx[o[340132]]({ 'keepScreenOn': !![] }), wx[o[340133]](function (u3fp4) {
  console[o[340042]](o[340130] + u3fp4[o[340131]] + o[340134] + u3fp4[o[340135]]);
}), wx[o[340136]](function (qjoihm) {
  window['u$G0'] = qjoihm, window['u$80G'] && window['u$G0'] && (console[o[340001]](o[340137] + window['u$G0'][o[340138]]), window['u$80G'](window['u$G0']), window['u$G0'] = null);
}), window[o[340139]] = 0x0, window['u$7$G80'] = 0x0, window[o[340140]] = null, wx[o[340141]](function () {
  window['u$7$G80']++;var b018rc = Date[o[340142]]();(window[o[340139]] == 0x0 || b018rc - window[o[340139]] > 0x1d4c0) && (console[o[340143]](o[340144]), wx[o[340145]]());if (window['u$7$G80'] >= 0x2) {
    window['u$7$G80'] = 0x0, console[o[340028]](o[340146]), wx[o[340147]]('0', 0x1);if (window['u$$8'] && window['u$$8'][o[340107]]) window['u$$80'](o[340148], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});