var o = wx.$U;
import ufp43ju from '../uukuuu/u6kuu.js';window[o[340149]] = { 'wxVersion': window[o[340006]][o[340007]] }, window[o[340150]] = ![], window['u$8$'] = 0x1, window[o[340151]] = 0x1, window['u$G$8'] = !![], window[o[340152]] = !![], window['u$70G$8'] = '', window['u$$8'] = { 'base_cdn': o[340153], 'cdn': o[340153] }, u$$8[o[340154]] = {}, u$$8[o[340155]] = '0', u$$8[o[340080]] = window[o[340149]][o[340156]], u$$8[o[340115]] = '', u$$8['os'] = '1', u$$8[o[340157]] = o[340158], u$$8[o[340159]] = o[340160], u$$8[o[340161]] = o[340162], u$$8[o[340163]] = o[340164], u$$8[o[340165]] = o[340166], u$$8[o[340167]] = '1', u$$8[o[340022]] = '', u$$8[o[340168]] = '', u$$8[o[340169]] = 0x0, u$$8[o[340170]] = {}, u$$8[o[340171]] = parseInt(u$$8[o[340167]]), u$$8[o[340172]] = u$$8[o[340167]], u$$8[o[340023]] = {}, u$$8['u$0$'] = o[340173], u$$8[o[340174]] = ![], u$$8[o[340175]] = o[340176], u$$8[o[340177]] = Date[o[340142]](), u$$8[o[340178]] = o[340179], u$$8[o[340180]] = '_a', u$$8[o[340181]] = 0x2, u$$8[o[340020]] = 0x7c1, u$$8[o[340156]] = window[o[340149]][o[340156]], u$$8[o[340182]] = ![], u$$8[o[340107]] = ![], u$$8[o[340110]] = ![], u$$8[o[340113]] = ![], window['u$G8$'] = 0x5, window['u$G8'] = ![], window['u$8G'] = ![], window['u$$G8'] = ![], window[o[340183]] = ![], window[o[340184]] = ![], window['u$$8G'] = ![], window['u$G$'] = ![], window['u$$G'] = ![], window['u$8G$'] = ![], window[o[340185]] = function (j3upf4) {
  console[o[340042]](o[340185], j3upf4), wx[o[340186]]({}), wx[o[340049]]({ 'title': o[340072], 'content': j3upf4, 'success'(zt25d) {
      if (zt25d[o[340187]]) console[o[340042]](o[340188]);else zt25d[o[340189]] && console[o[340042]](o[340190]);
    } });
}, window['u$0G$8'] = function (ijhom3) {
  console[o[340042]](o[340191], ijhom3), u$0$8G(), wx[o[340049]]({ 'title': o[340072], 'content': ijhom3, 'confirmText': o[340192], 'cancelText': o[340193], 'success'(hioj) {
      if (hioj[o[340187]]) window['u$$0']();else hioj[o[340189]] && (console[o[340042]](o[340194]), wx[o[340195]]({}));
    } });
}, window[o[340196]] = function (h4p3j) {
  console[o[340042]](o[340196], h4p3j), wx[o[340049]]({ 'title': o[340072], 'content': h4p3j, 'confirmText': o[340197], 'showCancel': ![], 'complete'(ak6nv) {
      console[o[340042]](o[340194]), wx[o[340195]]({});
    } });
}, window['u$0G8$'] = ![], window['u$0$G8'] = function (jph34m) {
  window['u$0G8$'] = !![], wx[o[340198]](jph34m);
}, window['u$0$8G'] = function () {
  window['u$0G8$'] && (window['u$0G8$'] = ![], wx[o[340186]]({}));
}, window['u$08G$'] = function ($usne) {
  window[o[340035]][o[340036]]['u$08G$']($usne);
}, window[o[340199]] = function (s_kavn, uenf$s) {
  ufp43ju[o[340199]](s_kavn, function (n$efus) {
    n$efus && n$efus[o[340200]] ? n$efus[o[340200]][o[340201]] == 0x1 ? uenf$s(!![]) : (uenf$s(![]), console[o[340001]](o[340202] + n$efus[o[340200]][o[340203]])) : console[o[340042]](o[340199], n$efus);
  });
}, window[o[340204]] = function (qjimo, r10c) {
  qjimo[o[340205]] = window[o[340006]][o[340206]], qjimo[o[340207]] = window[o[340006]][o[340208]], qjimo[o[340209]] = window['u$$8'][o[340107]] ? window[o[340006]][o[340210]] : window[o[340006]][o[340211]], qjimo[o[340212]] = Math[o[340213]]((qjimo[o[340212]] ? qjimo[o[340212]] : Date[o[340142]]()) / 0x3e8), qjimo[o[340214]] = Math[o[340213]]((qjimo[o[340214]] ? qjimo[o[340214]] : Date[o[340142]]()) / 0x3e8), console[o[340001]](o[340215] + JSON[o[340027]](qjimo));var rk_c6a = function (ra06c) {
    if (!ra06c) ra06c = { 'state': 0x1, 'display': 0x1, 'msg': o[340216] };if (!ra06c[o[340203]]) ra06c[o[340203]] = o[340216];console[o[340001]](o[340217] + JSON[o[340027]](ra06c)), r10c && r10c(ra06c);
  },
      f$eusp = function (nvs_$) {
    var zgd95t = { 'state': 0x0, 'display': 0x0, 'msg': o[340216] };console[o[340001]](o[340218] + nvs_$), r10c && r10c(zgd95t);
  };sendApi(u$$8[o[340159]], o[340219], qjimo, rk_c6a, 0x1, f$eusp, function () {
    return !![];
  });
}, window['u$08$G'] = function (wzgd79) {
  console[o[340042]](o[340220], wzgd79);
}, window['u$0$8'] = function (h4mp) {}, window['u$08$'] = function (c0ar8, r1cb80, mpj34) {}, window['u$08'] = function (fs$pu) {
  console[o[340042]](o[340221], fs$pu), window[o[340035]][o[340036]][o[340222]](), window[o[340035]][o[340036]][o[340223]](), window[o[340035]][o[340036]][o[340224]]();
}, window['u$80'] = function (c60a8r) {
  window['u$0G$8'](o[340225]);var j3hmi4 = { 'id': window['u$$8'][o[340016]], 'role': window['u$$8'][o[340017]], 'level': window['u$$8'][o[340018]], 'account': window['u$$8'][o[340019]], 'version': window['u$$8'][o[340020]], 'cdn': window['u$$8'][o[340021]], 'pkgName': window['u$$8'][o[340022]], 'gamever': window[o[340006]][o[340007]], 'serverid': window['u$$8'][o[340023]] ? window['u$$8'][o[340023]][o[340024]] : 0x0, 'systemInfo': window[o[340025]], 'error': o[340226], 'stack': c60a8r ? c60a8r : o[340225] },
      ohij3m = JSON[o[340027]](j3hmi4);console[o[340028]](o[340227] + ohij3m), window['u$0$'](ohij3m);
}, window['u$$08'] = function (nue) {
  var z79wgd = JSON[o[340228]](nue);z79wgd[o[340229]] = window[o[340006]][o[340007]], z79wgd[o[340230]] = window['u$$8'][o[340023]] ? window['u$$8'][o[340023]][o[340024]] : 0x0, z79wgd[o[340025]] = window[o[340025]];var o7lqi = JSON[o[340027]](z79wgd);console[o[340028]](o[340231] + o7lqi), window['u$0$'](o7lqi);
}, window['u$$80'] = function (kc6a_, n_se$v) {
  var gz97d = { 'id': window['u$$8'][o[340016]], 'role': window['u$$8'][o[340017]], 'level': window['u$$8'][o[340018]], 'account': window['u$$8'][o[340019]], 'version': window['u$$8'][o[340020]], 'cdn': window['u$$8'][o[340021]], 'pkgName': window['u$$8'][o[340022]], 'gamever': window[o[340006]][o[340007]], 'serverid': window['u$$8'][o[340023]] ? window['u$$8'][o[340023]][o[340024]] : 0x0, 'systemInfo': window[o[340025]], 'error': kc6a_, 'stack': n_se$v },
      _k6car = JSON[o[340027]](gz97d);console[o[340143]](o[340232] + _k6car), window['u$0$'](_k6car);
}, window['u$0$'] = function (j34puf) {
  if (window['u$$8'][o[340116]] == o[340233]) return;var fp$eus = u$$8['u$0$'] + o[340234] + u$$8[o[340019]];wx[o[340235]]({ 'url': fp$eus, 'method': o[340236], 'data': j34puf, 'header': { 'content-type': o[340237], 'cache-control': o[340238] }, 'success': function (_kcr) {
      DEBUG && console[o[340042]](o[340239], fp$eus, j34puf, _kcr);
    }, 'fail': function (_$nvsk) {
      DEBUG && console[o[340042]](o[340239], fp$eus, j34puf, _$nvsk);
    }, 'complete': function () {} });
}, window[o[340240]] = function () {
  function $v_ksn() {
    return ((0x1 + Math[o[340241]]()) * 0x10000 | 0x0)[o[340242]](0x10)[o[340243]](0x1);
  }return $v_ksn() + $v_ksn() + '-' + $v_ksn() + '-' + $v_ksn() + '-' + $v_ksn() + '+' + $v_ksn() + $v_ksn() + $v_ksn();
}, window['u$$0'] = function () {
  console[o[340042]](o[340244]);var ijmh43 = ufp43ju[o[340245]]();u$$8[o[340172]] = ijmh43[o[340246]], u$$8[o[340171]] = ijmh43[o[340246]], u$$8[o[340167]] = ijmh43[o[340246]], u$$8[o[340022]] = ijmh43[o[340247]];var lwqxo7 = { 'game_ver': u$$8[o[340080]] };u$$8[o[340168]] = this[o[340240]](), u$0$G8({ 'title': o[340248] }), ufp43ju[o[340249]](lwqxo7, this['u$80$'][o[340250]](this));
}, window['u$80$'] = function (xqilo) {
  var $up4ef = xqilo[o[340251]];console[o[340042]](o[340252] + $up4ef + o[340253] + ($up4ef == 0x1) + o[340254] + xqilo[o[340007]] + o[340255] + window[o[340149]][o[340156]]);if (!xqilo[o[340007]] || window['u$7G80$'](window[o[340149]][o[340156]], xqilo[o[340007]]) < 0x0) console[o[340042]](o[340256]), u$$8[o[340159]] = o[340257], u$$8[o[340161]] = o[340258], u$$8[o[340163]] = o[340259], u$$8[o[340021]] = o[340260], u$$8[o[340261]] = o[340262], u$$8[o[340263]] = 'jx', u$$8[o[340182]] = ![];else window['u$7G80$'](window[o[340149]][o[340156]], xqilo[o[340007]]) == 0x0 ? (console[o[340042]](o[340264]), u$$8[o[340159]] = o[340160], u$$8[o[340161]] = o[340162], u$$8[o[340163]] = o[340164], u$$8[o[340021]] = o[340265], u$$8[o[340261]] = o[340262], u$$8[o[340263]] = o[340266], u$$8[o[340182]] = !![]) : (console[o[340042]](o[340267]), u$$8[o[340159]] = o[340160], u$$8[o[340161]] = o[340162], u$$8[o[340163]] = o[340164], u$$8[o[340021]] = o[340265], u$$8[o[340261]] = o[340262], u$$8[o[340263]] = o[340266], u$$8[o[340182]] = ![]);u$$8[o[340169]] = config[o[340268]] ? config[o[340268]] : 0x0, this['u$G$08'](), this['u$G$80'](), window[o[340269]] = 0x5, u$0$G8({ 'title': o[340270] }), ufp43ju[o[340271]](this['u$8$0'][o[340250]](this));
}, window[o[340269]] = 0x5, window['u$8$0'] = function (lohimq, olmhiq) {
  if (lohimq == 0x0 && olmhiq && olmhiq[o[340272]]) {
    u$$8[o[340273]] = olmhiq[o[340272]];var jph43 = this;u$0$G8({ 'title': o[340274] }), sendApi(u$$8[o[340159]], o[340275], { 'platform': u$$8[o[340157]], 'partner_id': u$$8[o[340167]], 'token': olmhiq[o[340272]], 'game_pkg': u$$8[o[340022]], 'deviceId': u$$8[o[340168]], 'scene': o[340276] + u$$8[o[340169]] }, this['u$G0$8'][o[340250]](this), u$G8$, u$80);
  } else olmhiq && olmhiq[o[340059]] && window[o[340269]] > 0x0 && (olmhiq[o[340059]][o[340108]](o[340277]) != -0x1 || olmhiq[o[340059]][o[340108]](o[340278]) != -0x1 || olmhiq[o[340059]][o[340108]](o[340279]) != -0x1 || olmhiq[o[340059]][o[340108]](o[340280]) != -0x1 || olmhiq[o[340059]][o[340108]](o[340281]) != -0x1 || olmhiq[o[340059]][o[340108]](o[340282]) != -0x1) ? (window[o[340269]]--, ufp43ju[o[340271]](this['u$8$0'][o[340250]](this))) : (window['u$$80'](o[340283], JSON[o[340027]]({ 'status': lohimq, 'data': olmhiq })), window['u$0G$8'](o[340284] + (olmhiq && olmhiq[o[340059]] ? '，' + olmhiq[o[340059]] : '')));
}, window['u$G0$8'] = function (l97wg) {
  if (!l97wg) {
    window['u$$80'](o[340285], o[340286]), window['u$0G$8'](o[340287]);return;
  }if (l97wg[o[340201]] != o[340288]) {
    window['u$$80'](o[340285], JSON[o[340027]](l97wg)), window['u$0G$8'](o[340289] + l97wg[o[340201]]);return;
  }u$$8[o[340290]] = String(l97wg[o[340019]]), u$$8[o[340019]] = String(l97wg[o[340019]]), u$$8[o[340084]] = String(l97wg[o[340084]]), u$$8[o[340172]] = String(l97wg[o[340084]]), u$$8[o[340291]] = String(l97wg[o[340291]]), u$$8[o[340292]] = String(l97wg[o[340293]]), u$$8[o[340294]] = String(l97wg[o[340212]]), u$$8[o[340293]] = '';var c0k6 = this;u$0$G8({ 'title': o[340295] }), sendApi(u$$8[o[340159]], o[340296], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, c0k6['u$G08$'][o[340250]](c0k6), u$G8$, u$80);
}, window['u$G08$'] = function (snef$) {
  if (!snef$) {
    window['u$0G$8'](o[340297]);return;
  }if (snef$[o[340201]] != o[340288]) {
    window['u$0G$8'](o[340298] + snef$[o[340201]]);return;
  }if (!snef$[o[340200]] || snef$[o[340200]][o[340010]] == 0x0) {
    window['u$0G$8'](o[340299]);return;
  }u$$8[o[340300]] = snef$[o[340301]], u$$8[o[340023]] = { 'server_id': String(snef$[o[340200]][0x0][o[340024]]), 'server_name': String(snef$[o[340200]][0x0][o[340302]]), 'entry_ip': snef$[o[340200]][0x0][o[340303]], 'entry_port': parseInt(snef$[o[340200]][0x0][o[340304]]), 'status': u$$G0(snef$[o[340200]][0x0]), 'start_time': snef$[o[340200]][0x0][o[340305]], 'cdn': u$$8[o[340021]] }, this['u$8$G0']();
}, window['u$8$G0'] = function () {
  if (u$$8[o[340300]] == 0x1) {
    var efup4$ = u$$8[o[340023]][o[340306]];if (efup4$ === -0x1 || efup4$ === 0x0) {
      window['u$0G$8'](efup4$ === -0x1 ? o[340307] : o[340308]);return;
    }u$80G$(0x0, u$$8[o[340023]][o[340024]]), window[o[340035]][o[340036]][o[340309]](u$$8[o[340300]]);
  } else window[o[340035]][o[340036]][o[340310]](), u$0$8G();window['u$$G'] = !![], window['u$8G$0'](), window['u$8$0G']();
}, window['u$G$08'] = function () {
  sendApi(u$$8[o[340159]], o[340311], { 'game_pkg': u$$8[o[340022]], 'version_name': u$$8[o[340263]] }, this[o[340312]][o[340250]](this), u$G8$, u$80);
}, window[o[340312]] = function (xgwq) {
  if (!xgwq) {
    window['u$0G$8'](o[340313]);return;
  }if (xgwq[o[340201]] != o[340288]) {
    window['u$0G$8'](o[340314] + xgwq[o[340201]]);return;
  }if (!xgwq[o[340200]] || !xgwq[o[340200]][o[340080]]) {
    window['u$0G$8'](o[340315] + (xgwq[o[340200]] && xgwq[o[340200]][o[340080]]));return;
  }xgwq[o[340200]][o[340316]] && xgwq[o[340200]][o[340316]][o[340010]] > 0xa && (u$$8[o[340317]] = xgwq[o[340200]][o[340316]], u$$8[o[340021]] = xgwq[o[340200]][o[340316]]), xgwq[o[340200]][o[340080]] && (u$$8[o[340020]] = xgwq[o[340200]][o[340080]]), console[o[340001]](o[340318] + u$$8[o[340020]] + o[340319] + u$$8[o[340263]]), window['u$$8G'] = !![], window['u$8G$0'](), window['u$8$0G']();
}, window[o[340320]], window['u$G$80'] = function () {
  sendApi(u$$8[o[340159]], o[340321], { 'game_pkg': u$$8[o[340022]] }, this['u$G80$'][o[340250]](this), u$G8$, u$80);
}, window['u$G80$'] = function (p4jhf) {
  if (p4jhf[o[340201]] === o[340288] && p4jhf[o[340200]]) {
    window[o[340320]] = p4jhf[o[340200]];for (var qlxw7 in p4jhf[o[340200]]) {
      u$$8[qlxw7] = p4jhf[o[340200]][qlxw7];
    }
  } else console[o[340001]](o[340322] + p4jhf[o[340201]]);window['u$G$'] = !![], window['u$8$0G']();
}, window[o[340323]] = function (hmiql, _$vesn, s$evn_, moh3ji, b0yr81, fup3e4, ar_6c, io7xlq, c0a8) {
  b0yr81 = String(b0yr81);var eu$ = ar_6c,
      p43jmh = io7xlq;u$$8[o[340154]][b0yr81] = { 'productid': b0yr81, 'productname': eu$, 'productdesc': p43jmh, 'roleid': hmiql, 'rolename': _$vesn, 'rolelevel': s$evn_, 'price': fup3e4, 'callback': c0a8 }, sendApi(u$$8[o[340163]], o[340324], { 'game_pkg': u$$8[o[340022]], 'server_id': u$$8[o[340023]][o[340024]], 'server_name': u$$8[o[340023]][o[340302]], 'level': s$evn_, 'uid': u$$8[o[340019]], 'role_id': hmiql, 'role_name': _$vesn, 'product_id': b0yr81, 'product_name': eu$, 'product_desc': p43jmh, 'money': fup3e4, 'partner_id': u$$8[o[340167]] }, toPayCallBack, u$G8$, u$80);
}, window[o[340325]] = function (lg7xq) {
  if (lg7xq) {
    if (lg7xq[o[340326]] === 0xc8 || lg7xq[o[340201]] == o[340288]) {
      var j34h = u$$8[o[340154]][String(lg7xq[o[340327]])];if (j34h[o[340328]]) j34h[o[340328]](lg7xq[o[340327]], lg7xq[o[340329]], -0x1);ufp43ju[o[340330]]({ 'cpbill': lg7xq[o[340329]], 'productid': lg7xq[o[340327]], 'productname': j34h[o[340331]], 'productdesc': j34h[o[340332]], 'serverid': u$$8[o[340023]][o[340024]], 'servername': u$$8[o[340023]][o[340302]], 'roleid': j34h[o[340333]], 'rolename': j34h[o[340334]], 'rolelevel': j34h[o[340335]], 'price': j34h[o[340336]], 'extension': JSON[o[340027]]({ 'cp_order_id': lg7xq[o[340329]] }) }, function (dzg9w, b0y1) {
        j34h[o[340328]] && dzg9w == 0x0 && j34h[o[340328]](lg7xq[o[340327]], lg7xq[o[340329]], dzg9w);console[o[340001]](JSON[o[340027]]({ 'type': o[340337], 'status': dzg9w, 'data': lg7xq, 'role_name': j34h[o[340334]] }));if (dzg9w === 0x0) {} else {
          if (dzg9w === 0x1) {} else {
            if (dzg9w === 0x2) {}
          }
        }
      });
    } else alert(lg7xq[o[340001]]);
  }
}, window['u$G8$0'] = function () {}, window['u$0G8'] = function (vsk_n$, jh3p4f, fsn$ue, lwg, arc68) {
  ufp43ju[o[340338]](u$$8[o[340023]][o[340024]], u$$8[o[340023]][o[340302]] || u$$8[o[340023]][o[340024]], vsk_n$, jh3p4f, fsn$ue, arc68), sendApi(u$$8[o[340159]], o[340339], { 'game_pkg': u$$8[o[340022]], 'server_id': u$$8[o[340023]][o[340024]], 'role_id': vsk_n$, 'uid': u$$8[o[340019]], 'role_name': jh3p4f, 'role_type': lwg, 'level': fsn$ue });
}, window['u$08G'] = function (c10rb, _v$e, w7x, oqijm, zdw9g5, a06rck, pj34mh, mhqloi, uj43p, olimq) {
  u$$8[o[340016]] = c10rb, u$$8[o[340017]] = _v$e, u$$8[o[340018]] = w7x, ufp43ju[o[340340]](u$$8[o[340023]][o[340024]], u$$8[o[340023]][o[340302]] || u$$8[o[340023]][o[340024]], c10rb, _v$e, w7x, a06rck), sendApi(u$$8[o[340159]], o[340341], { 'game_pkg': u$$8[o[340022]], 'server_id': u$$8[o[340023]][o[340024]], 'role_id': c10rb, 'uid': u$$8[o[340019]], 'role_name': _v$e, 'role_type': oqijm, 'level': w7x, 'evolution': zdw9g5 });
}, window['u$G08'] = function (d59wz, l9x7gw, jm3i4h, p4f3eu, z2t59d, fjup4, v_n$ks, $epu4, ojqmhi, jmoi3h) {
  u$$8[o[340016]] = d59wz, u$$8[o[340017]] = l9x7gw, u$$8[o[340018]] = jm3i4h, ufp43ju[o[340342]](u$$8[o[340023]][o[340024]], u$$8[o[340023]][o[340302]] || u$$8[o[340023]][o[340024]], d59wz, l9x7gw, jm3i4h, fjup4), sendApi(u$$8[o[340159]], o[340341], { 'game_pkg': u$$8[o[340022]], 'server_id': u$$8[o[340023]][o[340024]], 'role_id': d59wz, 'uid': u$$8[o[340019]], 'role_name': l9x7gw, 'role_type': p4f3eu, 'level': jm3i4h, 'evolution': z2t59d });
}, window['u$G80'] = function (n$efsu) {}, window['u$0G'] = function (p4fh) {
  ufp43ju[o[340343]](o[340343], function (xoqmli) {
    p4fh && p4fh(xoqmli);
  });
}, window[o[340344]] = function () {
  ufp43ju[o[340344]]();
}, window[o[340345]] = function () {
  ufp43ju[o[340346]]();
}, window[o[340347]] = function (c01rb, wgdz79, uf4, a_kvsn, r6ac0k, rka_6, fup4$e, k_v$ns) {
  k_v$ns = k_v$ns || u$$8[o[340023]][o[340024]], sendApi(u$$8[o[340159]], o[340348], { 'phone': c01rb, 'role_id': wgdz79, 'uid': u$$8[o[340019]], 'game_pkg': u$$8[o[340022]], 'partner_id': u$$8[o[340167]], 'server_id': k_v$ns }, fup4$e);
}, window[o[340136]] = function (mqxl) {
  window['u$80G'] = mqxl, window['u$80G'] && window['u$G0'] && (console[o[340001]](o[340137] + window['u$G0'][o[340138]]), window['u$80G'](window['u$G0']), window['u$G0'] = null);
}, window['u$8G0'] = function (t95z2d, jho3m, oilxqm, karc06) {
  window[o[340349]](o[340350], { 'game_pkg': window['u$$8'][o[340022]], 'role_id': jho3m, 'server_id': oilxqm }, karc06);
}, window['u$$0G8'] = function (gw95dz, oi3jh) {
  function e4fu3p(g7ql) {
    var yb1r08 = [],
        xoq7wl = [],
        esu = window[o[340006]][o[340351]];for (var ksav_ in esu) {
      var s_kna = Number(ksav_);(!gw95dz || !gw95dz[o[340010]] || gw95dz[o[340108]](s_kna) != -0x1) && (xoq7wl[o[340039]](esu[ksav_]), yb1r08[o[340039]]([s_kna, 0x3]));
    }window['u$7G80$'](window[o[340040]], o[340352]) >= 0x0 ? (console[o[340042]](o[340353]), ufp43ju[o[340354]] && ufp43ju[o[340354]](xoq7wl, function (rc_ak) {
      console[o[340042]](o[340355]), console[o[340042]](rc_ak);if (rc_ak && rc_ak[o[340059]] == o[340356]) for (var pus$ef in esu) {
        if (rc_ak[esu[pus$ef]] == o[340357]) {
          var f$4e = Number(pus$ef);for (var _vks$ = 0x0; _vks$ < yb1r08[o[340010]]; _vks$++) {
            if (yb1r08[_vks$][0x0] == f$4e) {
              yb1r08[_vks$][0x1] = 0x1;break;
            }
          }
        }
      }window['u$7G80$'](window[o[340040]], o[340358]) >= 0x0 ? wx[o[340359]]({ 'withSubscriptions': !![], 'success': function (rc081b) {
          var vkac_ = rc081b[o[340360]][o[340361]];if (vkac_) {
            console[o[340042]](o[340362]), console[o[340042]](vkac_);for (var hjp4f in esu) {
              if (vkac_[esu[hjp4f]] == o[340357]) {
                var crk0a6 = Number(hjp4f);for (var _c6ak = 0x0; _c6ak < yb1r08[o[340010]]; _c6ak++) {
                  if (yb1r08[_c6ak][0x0] == crk0a6) {
                    yb1r08[_c6ak][0x1] = 0x2;break;
                  }
                }
              }
            }console[o[340042]](yb1r08), oi3jh && oi3jh(yb1r08);
          } else console[o[340042]](o[340363]), console[o[340042]](rc081b), console[o[340042]](yb1r08), oi3jh && oi3jh(yb1r08);
        }, 'fail': function () {
          console[o[340042]](o[340364]), console[o[340042]](yb1r08), oi3jh && oi3jh(yb1r08);
        } }) : (console[o[340042]](o[340365] + window[o[340040]]), console[o[340042]](yb1r08), oi3jh && oi3jh(yb1r08));
    })) : (console[o[340042]](o[340366] + window[o[340040]]), console[o[340042]](yb1r08), oi3jh && oi3jh(yb1r08)), wx[o[340367]](e4fu3p);
  }wx[o[340368]](e4fu3p);
}, window['u$$08G'] = { 'isSuccess': ![], 'level': o[340369], 'isCharging': ![] }, window['u$$G08'] = function (su$ev) {
  wx[o[340124]]({ 'success': function (x7gqlw) {
      var cr061 = window['u$$08G'];cr061[o[340370]] = !![], cr061[o[340126]] = Number(x7gqlw[o[340126]])[o[340371]](0x0), cr061[o[340128]] = x7gqlw[o[340128]], su$ev && su$ev(cr061[o[340370]], cr061[o[340126]], cr061[o[340128]]);
    }, 'fail': function (k0ca) {
      console[o[340042]](o[340372], k0ca[o[340059]]);var m4h3ji = window['u$$08G'];su$ev && su$ev(m4h3ji[o[340370]], m4h3ji[o[340126]], m4h3ji[o[340128]]);
    } });
}, window[o[340349]] = function (r6ak_, x9g, ihmqol, $epsfu, vsk$_, m3ihjo, c0a6rk, mjih3o) {
  if ($epsfu == undefined) $epsfu = 0x1;wx[o[340235]]({ 'url': r6ak_, 'method': c0a6rk || o[340373], 'responseType': o[340374], 'data': x9g, 'header': { 'content-type': mjih3o || o[340237] }, 'success': function (unes$) {
      DEBUG && console[o[340042]](o[340375], r6ak_, info, unes$);if (unes$ && unes$[o[340376]] == 0xc8) {
        var kvn6a_ = unes$[o[340200]];!m3ihjo || m3ihjo(kvn6a_) ? ihmqol && ihmqol(kvn6a_) : window[o[340377]](r6ak_, x9g, ihmqol, $epsfu, vsk$_, m3ihjo, unes$);
      } else window[o[340377]](r6ak_, x9g, ihmqol, $epsfu, vsk$_, m3ihjo, unes$);
    }, 'fail': function (ue4$f) {
      DEBUG && console[o[340042]](o[340378], r6ak_, info, ue4$f), window[o[340377]](r6ak_, x9g, ihmqol, $epsfu, vsk$_, m3ihjo, ue4$f);
    }, 'complete': function () {} });
}, window[o[340377]] = function (gz97dw, $seun, uf34, _6akvc, j3uf, k_navs, cvk_) {
  _6akvc - 0x1 > 0x0 ? setTimeout(function () {
    window[o[340349]](gz97dw, $seun, uf34, _6akvc - 0x1, j3uf, k_navs);
  }, 0x3e8) : j3uf && j3uf(JSON[o[340027]]({ 'url': gz97dw, 'response': cvk_ }));
}, window[o[340379]] = function (cakr60, a0k6rc, ak6_r, wl97, lx9gw, g7wqx, avsk_) {
  !ak6_r && (ak6_r = {});var kr_c6 = Math[o[340213]](Date[o[340142]]() / 0x3e8);ak6_r[o[340212]] = kr_c6, ak6_r[o[340380]] = a0k6rc;var qhil = Object[o[340381]](ak6_r)[o[340382]](),
      va6_ck = '',
      w7xlo = '';for (var zg7x9w = 0x0; zg7x9w < qhil[o[340010]]; zg7x9w++) {
    va6_ck = va6_ck + (zg7x9w == 0x0 ? '' : '&') + qhil[zg7x9w] + ak6_r[qhil[zg7x9w]], w7xlo = w7xlo + (zg7x9w == 0x0 ? '' : '&') + qhil[zg7x9w] + '=' + encodeURIComponent(ak6_r[qhil[zg7x9w]]);
  }va6_ck = va6_ck + u$$8[o[340165]];var c0rka6 = o[340383] + md5(va6_ck);send(cakr60 + '?' + w7xlo + (w7xlo == '' ? '' : '&') + c0rka6, null, wl97, lx9gw, g7wqx, avsk_ || function (na_svk) {
    return na_svk[o[340201]] == o[340288];
  }, null, o[340384]);
}, window['u$$G80'] = function (qlxg7w, a6cvk_) {
  var _sknv = 0x0;u$$8[o[340023]] && (_sknv = u$$8[o[340023]][o[340024]]), sendApi(u$$8[o[340161]], o[340385], { 'partnerId': u$$8[o[340167]], 'gamePkg': u$$8[o[340022]], 'logTime': Math[o[340213]](Date[o[340142]]() / 0x3e8), 'platformUid': u$$8[o[340291]], 'type': qlxg7w, 'serverId': _sknv }, null, 0x2, null, function () {
    return !![];
  });
}, window['u$$80G'] = function ($pfse) {
  sendApi(u$$8[o[340159]], o[340386], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, u$$8G0, u$G8$, u$80);
}, window['u$$8G0'] = function (hf3p4) {
  if (hf3p4[o[340201]] === o[340288] && hf3p4[o[340200]]) {
    hf3p4[o[340200]][o[340387]]({ 'id': -0x2, 'name': o[340388] }), hf3p4[o[340200]][o[340387]]({ 'id': -0x1, 'name': o[340389] }), u$$8[o[340390]] = hf3p4[o[340200]];if (window[o[340391]]) window[o[340391]][o[340392]]();
  } else u$$8[o[340393]] = ![], window['u$0G$8'](o[340394] + hf3p4[o[340201]]);
}, window['u$0G$'] = function (hq) {
  sendApi(u$$8[o[340159]], o[340395], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, u$0$G, u$G8$, u$80);
}, window['u$0$G'] = function (ue3fp) {
  u$$8[o[340396]] = ![];if (ue3fp[o[340201]] === o[340288] && ue3fp[o[340200]]) {
    for (var nk$vs_ = 0x0; nk$vs_ < ue3fp[o[340200]][o[340010]]; nk$vs_++) {
      ue3fp[o[340200]][nk$vs_][o[340306]] = u$$G0(ue3fp[o[340200]][nk$vs_]);
    }u$$8[o[340170]][-0x1] = window[o[340397]](ue3fp[o[340200]]), window[o[340391]][o[340398]](-0x1);
  } else window['u$0G$8'](o[340399] + ue3fp[o[340201]]);
}, window[o[340400]] = function (jhpf) {
  sendApi(u$$8[o[340159]], o[340395], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, jhpf, u$G8$, u$80);
}, window['u$G0$'] = function (molqix, ufp$e4) {
  sendApi(u$$8[o[340159]], o[340401], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]], 'server_group_id': ufp$e4 }, u$G$0, u$G8$, u$80);
}, window['u$G$0'] = function ($_ve) {
  u$$8[o[340396]] = ![];if ($_ve[o[340201]] === o[340288] && $_ve[o[340200]] && $_ve[o[340200]][o[340200]]) {
    var u43f = $_ve[o[340200]][o[340402]],
        d9zt2 = [];for (var oi3mj = 0x0; oi3mj < $_ve[o[340200]][o[340200]][o[340010]]; oi3mj++) {
      $_ve[o[340200]][o[340200]][oi3mj][o[340306]] = u$$G0($_ve[o[340200]][o[340200]][oi3mj]), (d9zt2[o[340010]] == 0x0 || $_ve[o[340200]][o[340200]][oi3mj][o[340306]] != 0x0) && (d9zt2[d9zt2[o[340010]]] = $_ve[o[340200]][o[340200]][oi3mj]);
    }u$$8[o[340170]][u43f] = window[o[340397]](d9zt2), window[o[340391]][o[340398]](u43f);
  } else window['u$0G$8'](o[340403] + $_ve[o[340201]]);
}, window['u$7G8$'] = function (lmh) {
  sendApi(u$$8[o[340159]], o[340404], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'version': u$$8[o[340080]], 'game_pkg': u$$8[o[340022]], 'device': u$$8[o[340168]] }, reqServerRecommendCallBack, u$G8$, u$80);
}, window[o[340405]] = function (jiqo) {
  u$$8[o[340396]] = ![];if (jiqo[o[340201]] === o[340288] && jiqo[o[340200]]) {
    for (var wqlgx = 0x0; wqlgx < jiqo[o[340200]][o[340010]]; wqlgx++) {
      jiqo[o[340200]][wqlgx][o[340306]] = u$$G0(jiqo[o[340200]][wqlgx]);
    }u$$8[o[340170]][-0x2] = window[o[340397]](jiqo[o[340200]]), window[o[340391]][o[340398]](-0x2);
  } else alert(o[340406] + jiqo[o[340201]]);
}, window[o[340397]] = function (ens_$) {
  if (!ens_$ && ens_$[o[340010]] <= 0x0) return ens_$;for (let wg9d7 = 0x0; wg9d7 < ens_$[o[340010]]; wg9d7++) {
    ens_$[wg9d7][o[340407]] && ens_$[wg9d7][o[340407]] == 0x1 && (ens_$[wg9d7][o[340302]] += o[340408]);
  }return ens_$;
}, window['u$$0G'] = function (knvas_, zw5d9g) {
  knvas_ = knvas_ || u$$8[o[340023]][o[340024]], sendApi(u$$8[o[340159]], o[340409], { 'type': '4', 'game_pkg': u$$8[o[340022]], 'server_id': knvas_ }, zw5d9g);
}, window[o[340410]] = function (sn$uev, lmqxio, pj4m3, _avkc) {
  pj4m3 = pj4m3 || u$$8[o[340023]][o[340024]], sendApi(u$$8[o[340159]], o[340411], { 'type': sn$uev, 'game_pkg': lmqxio, 'server_id': pj4m3 }, _avkc);
}, window['u$$G0'] = function (cak6_r) {
  if (cak6_r) {
    if (cak6_r[o[340306]] == 0x1) {
      if (cak6_r[o[340412]] == 0x1) return 0x2;else return 0x1;
    } else return cak6_r[o[340306]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['u$80G$'] = function (_6nka, mqoix) {
  u$$8[o[340413]] = { 'step': _6nka, 'server_id': mqoix };var akc6r0 = this;u$0$G8({ 'title': o[340414] }), sendApi(u$$8[o[340159]], o[340415], { 'partner_id': u$$8[o[340167]], 'uid': u$$8[o[340019]], 'game_pkg': u$$8[o[340022]], 'server_id': mqoix, 'platform': u$$8[o[340084]], 'platform_uid': u$$8[o[340291]], 'check_login_time': u$$8[o[340294]], 'check_login_sign': u$$8[o[340292]], 'version_name': u$$8[o[340263]] }, u$80$G, u$G8$, u$80, function (oilx7q) {
    return oilx7q[o[340201]] == o[340288] || oilx7q[o[340001]] == o[340416] || oilx7q[o[340001]] == o[340417];
  });
}, window['u$80$G'] = function (j3hoim) {
  var kr6c_a = this;if (j3hoim[o[340201]] === o[340288] && j3hoim[o[340200]]) {
    var mjo3 = u$$8[o[340023]];mjo3[o[340418]] = u$$8[o[340171]], mjo3[o[340293]] = String(j3hoim[o[340200]][o[340419]]), mjo3[o[340177]] = parseInt(j3hoim[o[340200]][o[340212]]);if (j3hoim[o[340200]][o[340420]]) mjo3[o[340420]] = parseInt(j3hoim[o[340200]][o[340420]]);else mjo3[o[340420]] = parseInt(j3hoim[o[340200]][o[340024]]);mjo3[o[340421]] = 0x0, mjo3[o[340021]] = u$$8[o[340317]], mjo3[o[340422]] = j3hoim[o[340200]][o[340423]], mjo3[o[340424]] = j3hoim[o[340200]][o[340424]], console[o[340042]](o[340425] + JSON[o[340027]](mjo3[o[340424]])), u$$8[o[340300]] == 0x1 && mjo3[o[340424]] && mjo3[o[340424]][o[340426]] == 0x1 && (u$$8[o[340427]] = 0x1, window[o[340035]][o[340036]]['u$78$']()), u$8G0$();
  } else u$$8[o[340413]][o[340428]] >= 0x3 ? (u$80(JSON[o[340027]](j3hoim)), window['u$0G$8'](o[340429] + j3hoim[o[340201]])) : sendApi(u$$8[o[340159]], o[340275], { 'platform': u$$8[o[340157]], 'partner_id': u$$8[o[340167]], 'token': u$$8[o[340273]], 'game_pkg': u$$8[o[340022]], 'deviceId': u$$8[o[340168]], 'scene': o[340276] + u$$8[o[340169]] }, function (i3mhj4) {
    if (!i3mhj4 || i3mhj4[o[340201]] != o[340288]) {
      window['u$0G$8'](o[340289] + i3mhj4 && i3mhj4[o[340201]]);return;
    }u$$8[o[340292]] = String(i3mhj4[o[340293]]), u$$8[o[340294]] = String(i3mhj4[o[340212]]), setTimeout(function () {
      u$80G$(u$$8[o[340413]][o[340428]] + 0x1, u$$8[o[340413]][o[340024]]);
    }, 0x5dc);
  }, u$G8$, u$80, function (d59t2) {
    return d59t2[o[340201]] == o[340288] || d59t2[o[340201]] == o[340430];
  });
}, window['u$8G0$'] = function () {
  ServerLoading[o[340036]][o[340309]](u$$8[o[340300]]), window['u$G8'] = !![], window['u$8$0G']();
}, window['u$8G$0'] = function () {
  if (window['u$8G'] && window['u$$G8'] && window[o[340183]] && window[o[340184]] && window['u$$8G'] && window['u$$G']) {
    if (!window[o[340431]][o[340036]]) {
      console[o[340042]](o[340432] + window[o[340431]][o[340036]]);var v_c = wx[o[340433]](),
          xmlio = v_c[o[340138]] ? v_c[o[340138]] : 0x0,
          envu = { 'cdn': window['u$$8'][o[340021]], 'spareCdn': window['u$$8'][o[340261]], 'newRegister': window['u$$8'][o[340300]], 'wxPC': window['u$$8'][o[340113]], 'wxIOS': window['u$$8'][o[340107]], 'wxAndroid': window['u$$8'][o[340110]], 'wxParam': { 'limitLoad': window['u$$8']['u$70G8$'], 'benchmarkLevel': window['u$$8']['u$70$G8'], 'wxFrom': window[o[340006]][o[340268]] == o[340434] ? 0x1 : 0x0, 'wxSDKVersion': window[o[340040]] }, 'configType': window['u$$8'][o[340178]], 'exposeType': window['u$$8'][o[340180]], 'scene': xmlio };new window[o[340431]](envu, window['u$$8'][o[340020]], window['u$70G$8']);
    }
  }
}, window['u$8$0G'] = function () {
  if (window['u$8G'] && window['u$$G8'] && window[o[340183]] && window[o[340184]] && window['u$$8G'] && window['u$$G'] && window['u$G8'] && window['u$G$']) {
    u$0$8G();if (!u$8G$) {
      u$8G$ = !![];if (!window[o[340431]][o[340036]]) window['u$8G$0']();var lhio = 0x0,
          xwq7lo = wx[o[340435]]();xwq7lo && (window['u$$8'][o[340112]] && (lhio = xwq7lo[o[340102]]), console[o[340001]](o[340436] + xwq7lo[o[340102]] + o[340437] + xwq7lo[o[340103]] + o[340438] + xwq7lo[o[340104]] + o[340439] + xwq7lo[o[340105]] + o[340440] + xwq7lo[o[340441]] + o[340442] + xwq7lo[o[340443]]));var fusen = {};for (const ne_sv$ in u$$8[o[340023]]) {
        fusen[ne_sv$] = u$$8[o[340023]][ne_sv$];
      }var ak_6r = { 'channel': window['u$$8'][o[340172]], 'account': window['u$$8'][o[340019]], 'userId': window['u$$8'][o[340290]], 'cdn': window['u$$8'][o[340021]], 'data': window['u$$8'][o[340200]], 'package': window['u$$8'][o[340155]], 'newRegister': window['u$$8'][o[340300]], 'pkgName': window['u$$8'][o[340022]], 'partnerId': window['u$$8'][o[340167]], 'platform_uid': window['u$$8'][o[340291]], 'deviceId': window['u$$8'][o[340168]], 'selectedServer': fusen, 'configType': window['u$$8'][o[340178]], 'exposeType': window['u$$8'][o[340180]], 'debugUsers': window['u$$8'][o[340175]], 'wxMenuTop': lhio, 'wxShield': window['u$$8'][o[340182]] };if (window[o[340320]]) for (var fse$up in window[o[340320]]) {
        ak_6r[fse$up] = window[o[340320]][fse$up];
      }window[o[340431]][o[340036]]['u$8$7'](ak_6r);
    }
  } else console[o[340001]](o[340444] + window['u$8G'] + o[340445] + window['u$$G8'] + o[340446] + window[o[340183]] + o[340447] + window[o[340184]] + o[340448] + window['u$$8G'] + o[340449] + window['u$$G'] + o[340450] + window['u$G8'] + o[340451] + window['u$G$']);
};