var d = wx.$A;
import Ab4_ from '../AAbasdA/A5sdkA.js';window[d[480541]] = { 'wxVersion': window[d[480005]][d[480006]] }, window[d[480542]] = ![], window['A16Z'] = 0x1, window[d[480543]] = 0x1, window['A17Z6'] = !![], window[d[480544]] = !![], window['A1$87Z6'] = '', window['A1Z6'] = { 'base_cdn': d[480545], 'cdn': d[480545] }, A1Z6[d[480546]] = {}, A1Z6[d[480547]] = '0', A1Z6[d[480079]] = window[d[480541]][d[480329]], A1Z6[d[480114]] = '', A1Z6['os'] = '1', A1Z6[d[480548]] = d[480549], A1Z6[d[480550]] = d[480551], A1Z6[d[480552]] = d[480553], A1Z6[d[480554]] = d[480555], A1Z6[d[480556]] = d[480557], A1Z6[d[480558]] = '1', A1Z6[d[480021]] = '', A1Z6[d[480559]] = '', A1Z6[d[480560]] = 0x0, A1Z6[d[480420]] = {}, A1Z6[d[480561]] = parseInt(A1Z6[d[480558]]), A1Z6[d[480562]] = A1Z6[d[480558]], A1Z6[d[480022]] = {}, A1Z6['A18Z'] = d[480563], A1Z6[d[480564]] = ![], A1Z6[d[480565]] = d[480566], A1Z6[d[480567]] = Date[d[480141]](), A1Z6[d[480568]] = d[480569], A1Z6[d[480570]] = '_a', A1Z6[d[480315]] = 0x2, A1Z6[d[480019]] = 0x7c1, A1Z6[d[480329]] = window[d[480541]][d[480329]], A1Z6[d[480571]] = ![], A1Z6[d[480106]] = ![], A1Z6[d[480109]] = ![], A1Z6[d[480112]] = ![], window['A176Z'] = 0x5, window['A176'] = ![], window['A167'] = ![], window['A1Z76'] = ![], window[d[480492]] = ![], window[d[480495]] = ![], window['A1Z67'] = ![], window['A17Z'] = ![], window['A1Z7'] = ![], window['A167Z'] = ![], window[d[480572]] = function (y1itpx) {
  console[d[480041]](d[480572], y1itpx), wx[d[480573]]({}), wx[d[480048]]({ 'title': d[480071], 'content': y1itpx, 'success'($08v9a) {
      if ($08v9a[d[480574]]) console[d[480041]](d[480575]);else $08v9a[d[480576]] && console[d[480041]](d[480577]);
    } });
}, window['A187Z6'] = function (bgq_) {
  console[d[480041]](d[480578], bgq_), A18Z67(), wx[d[480048]]({ 'title': d[480071], 'content': bgq_, 'confirmText': d[480579], 'cancelText': d[480580], 'success'(_gr4f) {
      if (_gr4f[d[480574]]) window['A1Z8']();else _gr4f[d[480576]] && (console[d[480041]](d[480581]), wx[d[480582]]({}));
    } });
}, window[d[480583]] = function (dns6h) {
  console[d[480041]](d[480583], dns6h), wx[d[480048]]({ 'title': d[480071], 'content': dns6h, 'confirmText': d[480584], 'showCancel': ![], 'complete'(w6shzj) {
      console[d[480041]](d[480581]), wx[d[480582]]({});
    } });
}, window['A1876Z'] = ![], window['A18Z76'] = function (mesdn6) {
  window['A1876Z'] = !![], wx[d[480585]](mesdn6);
}, window['A18Z67'] = function () {
  window['A1876Z'] && (window['A1876Z'] = ![], wx[d[480573]]({}));
}, window['A1867Z'] = function (r_4fg) {
  window[d[480034]][d[480035]]['A1867Z'](r_4fg);
}, window[d[480586]] = function (e$dnm, ku1083) {
  Ab4_[d[480586]](e$dnm, function (zjl2w) {
    zjl2w && zjl2w[d[480429]] ? zjl2w[d[480429]][d[480428]] == 0x1 ? ku1083(!![]) : (ku1083(![]), console[d[480000]](d[480587] + zjl2w[d[480429]][d[480588]])) : console[d[480041]](d[480586], zjl2w);
  });
}, window['A186Z7'] = function (djshz) {
  console[d[480041]](d[480589], djshz);
}, window['A18Z6'] = function (emd6) {}, window['A186Z'] = function (gobq4, d6hjz, ku31ip) {}, window['A186'] = function (r_4gqo) {
  console[d[480041]](d[480590], r_4gqo), window[d[480034]][d[480035]][d[480319]](), window[d[480034]][d[480035]][d[480320]](), window[d[480034]][d[480035]][d[480333]]();
}, window['A168'] = function (mjn6) {
  window['A187Z6'](d[480591]);var iytbxq = { 'id': window['A1Z6'][d[480015]], 'role': window['A1Z6'][d[480016]], 'level': window['A1Z6'][d[480017]], 'account': window['A1Z6'][d[480018]], 'version': window['A1Z6'][d[480019]], 'cdn': window['A1Z6'][d[480020]], 'pkgName': window['A1Z6'][d[480021]], 'gamever': window[d[480005]][d[480006]], 'serverid': window['A1Z6'][d[480022]] ? window['A1Z6'][d[480022]][d[480023]] : 0x0, 'systemInfo': window[d[480024]], 'error': d[480592], 'stack': mjn6 ? mjn6 : d[480591] },
      j6hlzw = JSON[d[480026]](iytbxq);console[d[480027]](d[480593] + j6hlzw), window['A18Z'](j6hlzw);
}, window['A1Z86'] = function (s$n) {
  var wsz6 = JSON[d[480594]](s$n);wsz6[d[480595]] = window[d[480005]][d[480006]], wsz6[d[480596]] = window['A1Z6'][d[480022]] ? window['A1Z6'][d[480022]][d[480023]] : 0x0, wsz6[d[480024]] = window[d[480024]];var r7f4_ = JSON[d[480026]](wsz6);console[d[480027]](d[480597] + r7f4_), window['A18Z'](r7f4_);
}, window['A1Z68'] = function (ea9mn, n$msed) {
  var uk38v = { 'id': window['A1Z6'][d[480015]], 'role': window['A1Z6'][d[480016]], 'level': window['A1Z6'][d[480017]], 'account': window['A1Z6'][d[480018]], 'version': window['A1Z6'][d[480019]], 'cdn': window['A1Z6'][d[480020]], 'pkgName': window['A1Z6'][d[480021]], 'gamever': window[d[480005]][d[480006]], 'serverid': window['A1Z6'][d[480022]] ? window['A1Z6'][d[480022]][d[480023]] : 0x0, 'systemInfo': window[d[480024]], 'error': ea9mn, 'stack': n$msed },
      kpi1x = JSON[d[480026]](uk38v);console[d[480142]](d[480598] + kpi1x), window['A18Z'](kpi1x);
}, window['A18Z'] = function (u03kv) {
  if (window['A1Z6'][d[480115]] == d[480599]) return;var v8$0a9 = A1Z6['A18Z'] + d[480600] + A1Z6[d[480018]];wx[d[480601]]({ 'url': v8$0a9, 'method': d[480602], 'data': u03kv, 'header': { 'content-type': d[480603], 'cache-control': d[480604] }, 'success': function (k308uv) {
      DEBUG && console[d[480041]](d[480605], v8$0a9, u03kv, k308uv);
    }, 'fail': function (ixbtq) {
      DEBUG && console[d[480041]](d[480605], v8$0a9, u03kv, ixbtq);
    }, 'complete': function () {} });
}, window[d[480606]] = function () {
  function up1k8() {
    return ((0x1 + Math[d[480322]]()) * 0x10000 | 0x0)[d[480607]](0x10)[d[480608]](0x1);
  }return up1k8() + up1k8() + '-' + up1k8() + '-' + up1k8() + '-' + up1k8() + '+' + up1k8() + up1k8() + up1k8();
}, window['A1Z8'] = function () {
  console[d[480041]](d[480609]);var mv9e = Ab4_[d[480610]]();A1Z6[d[480562]] = mv9e[d[480611]], A1Z6[d[480561]] = mv9e[d[480611]], A1Z6[d[480558]] = mv9e[d[480611]], A1Z6[d[480021]] = mv9e[d[480612]];var grqo4 = { 'game_ver': A1Z6[d[480079]] };A1Z6[d[480559]] = this[d[480606]](), A18Z76({ 'title': d[480613] }), Ab4_[d[480457]](grqo4, this['A168Z'][d[480326]](this));
}, window['A168Z'] = function (uk0) {
  var edn6 = uk0[d[480614]];console[d[480041]](d[480615] + edn6 + d[480616] + (edn6 == 0x1) + d[480617] + uk0[d[480006]] + d[480618] + window[d[480541]][d[480329]]);if (!uk0[d[480006]] || window['A1$768Z'](window[d[480541]][d[480329]], uk0[d[480006]]) < 0x0) console[d[480041]](d[480619]), A1Z6[d[480550]] = d[480620], A1Z6[d[480552]] = d[480621], A1Z6[d[480554]] = d[480622], A1Z6[d[480020]] = d[480623], A1Z6[d[480624]] = d[480625], A1Z6[d[480626]] = 'lg', A1Z6[d[480571]] = ![];else window['A1$768Z'](window[d[480541]][d[480329]], uk0[d[480006]]) == 0x0 ? (console[d[480041]](d[480627]), A1Z6[d[480550]] = d[480551], A1Z6[d[480552]] = d[480553], A1Z6[d[480554]] = d[480555], A1Z6[d[480020]] = d[480628], A1Z6[d[480624]] = d[480625], A1Z6[d[480626]] = d[480629], A1Z6[d[480571]] = !![]) : (console[d[480041]](d[480630]), A1Z6[d[480550]] = d[480551], A1Z6[d[480552]] = d[480553], A1Z6[d[480554]] = d[480555], A1Z6[d[480020]] = d[480628], A1Z6[d[480624]] = d[480625], A1Z6[d[480626]] = d[480629], A1Z6[d[480571]] = ![]);A1Z6[d[480560]] = config[d[480631]] ? config[d[480631]] : 0x0, this['A17Z86'](), this['A17Z68'](), window[d[480632]] = 0x5, A18Z76({ 'title': d[480633] }), Ab4_[d[480634]](this['A16Z8'][d[480326]](this));
}, window[d[480632]] = 0x5, window['A16Z8'] = function (og4_r, xbyo) {
  if (og4_r == 0x0 && xbyo && xbyo[d[480635]]) {
    A1Z6[d[480636]] = xbyo[d[480635]];var upk38 = this;A18Z76({ 'title': d[480637] }), sendApi(A1Z6[d[480550]], d[480638], { 'platform': A1Z6[d[480548]], 'partner_id': A1Z6[d[480558]], 'token': xbyo[d[480635]], 'game_pkg': A1Z6[d[480021]], 'deviceId': A1Z6[d[480559]], 'scene': d[480639] + A1Z6[d[480560]] }, this['A178Z6'][d[480326]](this), A176Z, A168);
  } else xbyo && xbyo[d[480058]] && window[d[480632]] > 0x0 && (xbyo[d[480058]][d[480107]](d[480640]) != -0x1 || xbyo[d[480058]][d[480107]](d[480641]) != -0x1 || xbyo[d[480058]][d[480107]](d[480642]) != -0x1 || xbyo[d[480058]][d[480107]](d[480643]) != -0x1 || xbyo[d[480058]][d[480107]](d[480644]) != -0x1 || xbyo[d[480058]][d[480107]](d[480645]) != -0x1) ? (window[d[480632]]--, Ab4_[d[480634]](this['A16Z8'][d[480326]](this))) : (window['A1Z68'](d[480646], JSON[d[480026]]({ 'status': og4_r, 'data': xbyo })), window['A187Z6'](d[480647] + (xbyo && xbyo[d[480058]] ? '，' + xbyo[d[480058]] : '')));
}, window['A178Z6'] = function (ma9v) {
  if (!ma9v) {
    window['A1Z68'](d[480648], d[480649]), window['A187Z6'](d[480650]);return;
  }if (ma9v[d[480428]] != d[480427]) {
    window['A1Z68'](d[480648], JSON[d[480026]](ma9v)), window['A187Z6'](d[480651] + ma9v[d[480428]]);return;
  }A1Z6[d[480652]] = String(ma9v[d[480018]]), A1Z6[d[480018]] = String(ma9v[d[480018]]), A1Z6[d[480083]] = String(ma9v[d[480083]]), A1Z6[d[480562]] = String(ma9v[d[480083]]), A1Z6[d[480653]] = String(ma9v[d[480653]]), A1Z6[d[480654]] = String(ma9v[d[480655]]), A1Z6[d[480656]] = String(ma9v[d[480657]]), A1Z6[d[480655]] = '';var n6eds = this;A18Z76({ 'title': d[480658] }), sendApi(A1Z6[d[480550]], d[480659], { 'partner_id': A1Z6[d[480558]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480559]] }, n6eds['A1786Z'][d[480326]](n6eds), A176Z, A168);
}, window['A1786Z'] = function (_q4gro) {
  if (!_q4gro) {
    window['A187Z6'](d[480660]);return;
  }if (_q4gro[d[480428]] != d[480427]) {
    window['A187Z6'](d[480661] + _q4gro[d[480428]]);return;
  }if (!_q4gro[d[480429]] || _q4gro[d[480429]][d[480009]] == 0x0) {
    window['A187Z6'](d[480662]);return;
  }A1Z6[d[480501]] = _q4gro[d[480663]], A1Z6[d[480022]] = { 'server_id': String(_q4gro[d[480429]][0x0][d[480023]]), 'server_name': String(_q4gro[d[480429]][0x0][d[480408]]), 'entry_ip': _q4gro[d[480429]][0x0][d[480664]], 'entry_port': parseInt(_q4gro[d[480429]][0x0][d[480665]]), 'status': A1Z78(_q4gro[d[480429]][0x0]), 'start_time': _q4gro[d[480429]][0x0][d[480666]], 'cdn': A1Z6[d[480020]] }, this['A16Z78']();
}, window['A16Z78'] = function () {
  if (A1Z6[d[480501]] == 0x1) {
    var qg_bt = A1Z6[d[480022]][d[480407]];if (qg_bt === -0x1 || qg_bt === 0x0) {
      window['A187Z6'](qg_bt === -0x1 ? d[480667] : d[480668]);return;
    }A1687Z(0x0, A1Z6[d[480022]][d[480023]]), window[d[480034]][d[480035]][d[480496]](A1Z6[d[480501]]);
  } else window[d[480034]][d[480035]][d[480493]](), A18Z67();window['A1Z7'] = !![], window['A167Z8'](), window['A16Z87']();
}, window['A17Z86'] = function () {
  sendApi(A1Z6[d[480550]], d[480669], { 'game_pkg': A1Z6[d[480021]], 'version_name': A1Z6[d[480626]] }, this[d[480670]][d[480326]](this), A176Z, A168);
}, window[d[480670]] = function (sdhjz6) {
  if (!sdhjz6) {
    window['A187Z6'](d[480671]);return;
  }if (sdhjz6[d[480428]] != d[480427]) {
    window['A187Z6'](d[480672] + sdhjz6[d[480428]]);return;
  }if (!sdhjz6[d[480429]] || !sdhjz6[d[480429]][d[480079]]) {
    window['A187Z6'](d[480673] + (sdhjz6[d[480429]] && sdhjz6[d[480429]][d[480079]]));return;
  }sdhjz6[d[480429]][d[480674]] && sdhjz6[d[480429]][d[480674]][d[480009]] > 0xa && (A1Z6[d[480675]] = sdhjz6[d[480429]][d[480674]], A1Z6[d[480020]] = sdhjz6[d[480429]][d[480674]]), sdhjz6[d[480429]][d[480079]] && (A1Z6[d[480019]] = sdhjz6[d[480429]][d[480079]]), console[d[480000]](d[480676] + A1Z6[d[480019]] + d[480677] + A1Z6[d[480626]]), window['A1Z67'] = !![], window['A167Z8'](), window['A16Z87']();
}, window[d[480678]], window['A17Z68'] = function () {
  sendApi(A1Z6[d[480550]], d[480679], { 'game_pkg': A1Z6[d[480021]] }, this['A1768Z'][d[480326]](this), A176Z, A168);
}, window['A1768Z'] = function (ae$90) {
  if (ae$90[d[480428]] === d[480427] && ae$90[d[480429]]) {
    window[d[480678]] = ae$90[d[480429]];for (var u1038k in ae$90[d[480429]]) {
      A1Z6[u1038k] = ae$90[d[480429]][u1038k];
    }
  } else console[d[480000]](d[480680] + ae$90[d[480428]]);window['A17Z'] = !![], window['A16Z87']();
}, window[d[480681]] = function (qg_tob, gto_qb, n$ame, pui, $9ev, v30u8, pyxi1, tbxip, $a90e) {
  $9ev = String($9ev);var pu3ik = pyxi1,
      otyqb = tbxip;A1Z6[d[480546]][$9ev] = { 'productid': $9ev, 'productname': pu3ik, 'productdesc': otyqb, 'roleid': qg_tob, 'rolename': gto_qb, 'rolelevel': n$ame, 'price': v30u8, 'callback': $a90e }, sendApi(A1Z6[d[480554]], d[480682], { 'game_pkg': A1Z6[d[480021]], 'server_id': A1Z6[d[480022]][d[480023]], 'server_name': A1Z6[d[480022]][d[480408]], 'level': n$ame, 'uid': A1Z6[d[480018]], 'role_id': qg_tob, 'role_name': gto_qb, 'product_id': $9ev, 'product_name': pu3ik, 'product_desc': otyqb, 'money': v30u8, 'partner_id': A1Z6[d[480558]] }, toPayCallBack, A176Z, A168);
}, window[d[480683]] = function (gbqt_) {
  if (gbqt_) {
    if (gbqt_[d[480684]] === 0xc8 || gbqt_[d[480428]] == d[480427]) {
      var uik1yp = A1Z6[d[480546]][String(gbqt_[d[480685]])];if (uik1yp[d[480686]]) uik1yp[d[480686]](gbqt_[d[480685]], gbqt_[d[480687]], -0x1);Ab4_[d[480688]]({ 'cpbill': gbqt_[d[480687]], 'productid': gbqt_[d[480685]], 'productname': uik1yp[d[480689]], 'productdesc': uik1yp[d[480690]], 'serverid': A1Z6[d[480022]][d[480023]], 'servername': A1Z6[d[480022]][d[480408]], 'roleid': uik1yp[d[480691]], 'rolename': uik1yp[d[480692]], 'rolelevel': uik1yp[d[480693]], 'price': uik1yp[d[480694]], 'extension': JSON[d[480026]]({ 'cp_order_id': gbqt_[d[480687]] }) }, function (e6mnsd, uk3801) {
        uik1yp[d[480686]] && e6mnsd == 0x0 && uik1yp[d[480686]](gbqt_[d[480685]], gbqt_[d[480687]], e6mnsd);console[d[480000]](JSON[d[480026]]({ 'type': d[480695], 'status': e6mnsd, 'data': gbqt_, 'role_name': uik1yp[d[480692]] }));if (e6mnsd === 0x0) {} else {
          if (e6mnsd === 0x1) {} else {
            if (e6mnsd === 0x2) {}
          }
        }
      });
    } else alert(gbqt_[d[480000]]);
  }
}, window['A176Z8'] = function () {}, window['A1876'] = function (dn6js, zhj2wl, snmjd6, vm$a9e, bqgto) {
  Ab4_[d[480696]](A1Z6[d[480022]][d[480023]], A1Z6[d[480022]][d[480408]] || A1Z6[d[480022]][d[480023]], dn6js, zhj2wl, snmjd6), sendApi(A1Z6[d[480550]], d[480697], { 'game_pkg': A1Z6[d[480021]], 'server_id': A1Z6[d[480022]][d[480023]], 'role_id': dn6js, 'uid': A1Z6[d[480018]], 'role_name': zhj2wl, 'role_type': vm$a9e, 'level': snmjd6 });
}, window['A1867'] = function (of4g, d$n9e, o_bqgt, bqg_t, btyixp, v9a80, _oqb4g, _grqo, me9av, sdh6n) {
  A1Z6[d[480015]] = of4g, A1Z6[d[480016]] = d$n9e, A1Z6[d[480017]] = o_bqgt, Ab4_[d[480698]](A1Z6[d[480022]][d[480023]], A1Z6[d[480022]][d[480408]] || A1Z6[d[480022]][d[480023]], of4g, d$n9e, o_bqgt), sendApi(A1Z6[d[480550]], d[480699], { 'game_pkg': A1Z6[d[480021]], 'server_id': A1Z6[d[480022]][d[480023]], 'role_id': of4g, 'uid': A1Z6[d[480018]], 'role_name': d$n9e, 'role_type': bqg_t, 'level': o_bqgt, 'evolution': btyixp });
}, window['A1786'] = function (goqtb, m$dn9, u13p8k, u38k1, wsj6h, o_tqg, dnesm, v0k, g4qb_, ibtyx) {
  A1Z6[d[480015]] = goqtb, A1Z6[d[480016]] = m$dn9, A1Z6[d[480017]] = u13p8k, Ab4_[d[480700]](A1Z6[d[480022]][d[480023]], A1Z6[d[480022]][d[480408]] || A1Z6[d[480022]][d[480023]], goqtb, m$dn9, u13p8k), sendApi(A1Z6[d[480550]], d[480699], { 'game_pkg': A1Z6[d[480021]], 'server_id': A1Z6[d[480022]][d[480023]], 'role_id': goqtb, 'uid': A1Z6[d[480018]], 'role_name': m$dn9, 'role_type': u38k1, 'level': u13p8k, 'evolution': wsj6h });
}, window['A1768'] = function (k1pixy) {}, window['A187'] = function (iqbyxt) {
  Ab4_[d[480701]](d[480701], function (e9m$n) {
    iqbyxt && iqbyxt(e9m$n);
  });
}, window[d[480702]] = function () {
  Ab4_[d[480702]]();
}, window[d[480703]] = function () {
  Ab4_[d[480704]]();
}, window[d[480705]] = function (ybxt, jdm6n, uyp1, smde$, jdsn6, h6ndsj, ev0a, _rqg4o) {
  _rqg4o = _rqg4o || A1Z6[d[480022]][d[480023]], sendApi(A1Z6[d[480550]], d[480706], { 'phone': ybxt, 'role_id': jdm6n, 'uid': A1Z6[d[480018]], 'game_pkg': A1Z6[d[480021]], 'partner_id': A1Z6[d[480558]], 'server_id': _rqg4o }, ev0a);
}, window[d[480135]] = function (rf_o4g) {
  window['A1687'] = rf_o4g, window['A1687'] && window['A178'] && (console[d[480000]](d[480136] + window['A178'][d[480137]]), window['A1687'](window['A178']), window['A178'] = null);
}, window['A1678'] = function (up1ik, yobqtx, py1uik, e$mnsd) {
  window[d[480707]](d[480708], { 'game_pkg': window['A1Z6'][d[480021]], 'role_id': yobqtx, 'server_id': py1uik }, e$mnsd);
}, window['A1Z876'] = function (ednm9$, _qtgb) {
  function oyqxb(p1xit) {
    var snj6hd = [],
        tg_qb = [],
        pik1x = window[d[480005]][d[480709]];for (var oyxbq in pik1x) {
      var nd$es = Number(oyxbq);(!ednm9$ || !ednm9$[d[480009]] || ednm9$[d[480107]](nd$es) != -0x1) && (tg_qb[d[480038]](pik1x[oyxbq]), snj6hd[d[480038]]([nd$es, 0x3]));
    }window['A1$768Z'](window[d[480039]], d[480710]) >= 0x0 ? (console[d[480041]](d[480711]), Ab4_[d[480712]] && Ab4_[d[480712]](tg_qb, function (oyxtb) {
      console[d[480041]](d[480713]), console[d[480041]](oyxtb);if (oyxtb && oyxtb[d[480058]] == d[480714]) for (var ypxi1t in pik1x) {
        if (oyxtb[pik1x[ypxi1t]] == d[480715]) {
          var xibqty = Number(ypxi1t);for (var ui1ky = 0x0; ui1ky < snj6hd[d[480009]]; ui1ky++) {
            if (snj6hd[ui1ky][0x0] == xibqty) {
              snj6hd[ui1ky][0x1] = 0x1;break;
            }
          }
        }
      }window['A1$768Z'](window[d[480039]], d[480716]) >= 0x0 ? wx[d[480717]]({ 'withSubscriptions': !![], 'success': function (nmds$e) {
          var _gboq4 = nmds$e[d[480718]][d[480719]];if (_gboq4) {
            console[d[480041]](d[480720]), console[d[480041]](_gboq4);for (var $ensdm in pik1x) {
              if (_gboq4[pik1x[$ensdm]] == d[480715]) {
                var p8u3k1 = Number($ensdm);for (var xtoqy = 0x0; xtoqy < snj6hd[d[480009]]; xtoqy++) {
                  if (snj6hd[xtoqy][0x0] == p8u3k1) {
                    snj6hd[xtoqy][0x1] = 0x2;break;
                  }
                }
              }
            }console[d[480041]](snj6hd), _qtgb && _qtgb(snj6hd);
          } else console[d[480041]](d[480721]), console[d[480041]](nmds$e), console[d[480041]](snj6hd), _qtgb && _qtgb(snj6hd);
        }, 'fail': function () {
          console[d[480041]](d[480722]), console[d[480041]](snj6hd), _qtgb && _qtgb(snj6hd);
        } }) : (console[d[480041]](d[480723] + window[d[480039]]), console[d[480041]](snj6hd), _qtgb && _qtgb(snj6hd));
    })) : (console[d[480041]](d[480724] + window[d[480039]]), console[d[480041]](snj6hd), _qtgb && _qtgb(snj6hd)), wx[d[480725]](oyqxb);
  }wx[d[480726]](oyqxb);
}, window['A1Z867'] = { 'isSuccess': ![], 'level': d[480727], 'isCharging': ![] }, window['A1Z786'] = function (nd6jhs) {
  wx[d[480123]]({ 'success': function (iqtbxy) {
      var $ednsm = window['A1Z867'];$ednsm[d[480728]] = !![], $ednsm[d[480125]] = Number(iqtbxy[d[480125]])[d[480729]](0x0), $ednsm[d[480127]] = iqtbxy[d[480127]], nd6jhs && nd6jhs($ednsm[d[480728]], $ednsm[d[480125]], $ednsm[d[480127]]);
    }, 'fail': function (a0v38) {
      console[d[480041]](d[480730], a0v38[d[480058]]);var nse6dm = window['A1Z867'];nd6jhs && nd6jhs(nse6dm[d[480728]], nse6dm[d[480125]], nse6dm[d[480127]]);
    } });
}, window[d[480707]] = function (o4_frg, jlw6, sme$nd, mden$s, z6lwh, $n9e, hn6sdj, q_rgo4) {
  if (mden$s == undefined) mden$s = 0x1;wx[d[480601]]({ 'url': o4_frg, 'method': hn6sdj || d[480731], 'responseType': d[480324], 'data': jlw6, 'header': { 'content-type': q_rgo4 || d[480603] }, 'success': function (xpkyi) {
      DEBUG && console[d[480041]](d[480732], o4_frg, info, xpkyi);if (xpkyi && xpkyi[d[480733]] == 0xc8) {
        var xqb_t = xpkyi[d[480429]];!$n9e || $n9e(xqb_t) ? sme$nd && sme$nd(xqb_t) : window[d[480734]](o4_frg, jlw6, sme$nd, mden$s, z6lwh, $n9e, xpkyi);
      } else window[d[480734]](o4_frg, jlw6, sme$nd, mden$s, z6lwh, $n9e, xpkyi);
    }, 'fail': function (wh2jzl) {
      DEBUG && console[d[480041]](d[480735], o4_frg, info, wh2jzl), window[d[480734]](o4_frg, jlw6, sme$nd, mden$s, z6lwh, $n9e, wh2jzl);
    }, 'complete': function () {} });
}, window[d[480734]] = function (ikuyp, v30a, u1kyip, av0$e9, g_fro4, $m9ve, $vae09) {
  av0$e9 - 0x1 > 0x0 ? setTimeout(function () {
    window[d[480707]](ikuyp, v30a, u1kyip, av0$e9 - 0x1, g_fro4, $m9ve);
  }, 0x3e8) : g_fro4 && g_fro4(JSON[d[480026]]({ 'url': ikuyp, 'response': $vae09 }));
}, window[d[480736]] = function (lh2jw, tboq_g, yqtbxo, a3908v, qogr4_, lwz2h, fr_g4) {
  !yqtbxo && (yqtbxo = {});var nd6sm = Math[d[480513]](Date[d[480141]]() / 0x3e8);yqtbxo[d[480657]] = nd6sm, yqtbxo[d[480737]] = tboq_g;var v08a9 = Object[d[480738]](yqtbxo)[d[480433]](),
      ogq4b = '',
      grf7_4 = '';for (var q4og_ = 0x0; q4og_ < v08a9[d[480009]]; q4og_++) {
    ogq4b = ogq4b + (q4og_ == 0x0 ? '' : '&') + v08a9[q4og_] + yqtbxo[v08a9[q4og_]], grf7_4 = grf7_4 + (q4og_ == 0x0 ? '' : '&') + v08a9[q4og_] + '=' + encodeURIComponent(yqtbxo[v08a9[q4og_]]);
  }ogq4b = ogq4b + A1Z6[d[480556]];var hdnjs = d[480739] + md5(ogq4b);send(lh2jw + '?' + grf7_4 + (grf7_4 == '' ? '' : '&') + hdnjs, null, a3908v, qogr4_, lwz2h, fr_g4 || function (f4_org) {
    return f4_org[d[480428]] == d[480427];
  }, null, d[480740]);
}, window['A1Z768'] = function (nsh6j, q_tbox) {
  var z6hwjs = 0x0;A1Z6[d[480022]] && (z6hwjs = A1Z6[d[480022]][d[480023]]), sendApi(A1Z6[d[480552]], d[480741], { 'partnerId': A1Z6[d[480558]], 'gamePkg': A1Z6[d[480021]], 'logTime': Math[d[480513]](Date[d[480141]]() / 0x3e8), 'platformUid': A1Z6[d[480653]], 'type': nsh6j, 'serverId': z6hwjs }, null, 0x2, null, function () {
    return !![];
  });
}, window['A1Z687'] = function (yki1u) {
  sendApi(A1Z6[d[480550]], d[480742], { 'partner_id': A1Z6[d[480558]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480559]] }, A1Z678, A176Z, A168);
}, window['A1Z678'] = function (_r4ofg) {
  if (_r4ofg[d[480428]] === d[480427] && _r4ofg[d[480429]]) {
    _r4ofg[d[480429]][d[480743]]({ 'id': -0x2, 'name': d[480744] }), _r4ofg[d[480429]][d[480743]]({ 'id': -0x1, 'name': d[480745] }), A1Z6[d[480381]] = _r4ofg[d[480429]];if (window[d[480373]]) window[d[480373]][d[480414]]();
  } else A1Z6[d[480391]] = ![], window['A187Z6'](d[480746] + _r4ofg[d[480428]]);
}, window['A187Z'] = function (i31pku) {
  sendApi(A1Z6[d[480550]], d[480747], { 'partner_id': A1Z6[d[480558]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480559]] }, A18Z7, A176Z, A168);
}, window['A18Z7'] = function (ev0a9) {
  A1Z6[d[480422]] = ![];if (ev0a9[d[480428]] === d[480427] && ev0a9[d[480429]]) {
    for (var qtibx = 0x0; qtibx < ev0a9[d[480429]][d[480009]]; qtibx++) {
      ev0a9[d[480429]][qtibx][d[480407]] = A1Z78(ev0a9[d[480429]][qtibx]);
    }A1Z6[d[480420]][-0x1] = window[d[480748]](ev0a9[d[480429]]), window[d[480373]][d[480421]](-0x1);
  } else window['A187Z6'](d[480749] + ev0a9[d[480428]]);
}, window[d[480750]] = function (k13pui) {
  sendApi(A1Z6[d[480550]], d[480747], { 'partner_id': A1Z6[d[480558]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480559]] }, k13pui, A176Z, A168);
}, window['A178Z'] = function (de$n, qbo4) {
  sendApi(A1Z6[d[480550]], d[480751], { 'partner_id': A1Z6[d[480558]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480559]], 'server_group_id': qbo4 }, A17Z8, A176Z, A168);
}, window['A17Z8'] = function (g4_qb) {
  A1Z6[d[480422]] = ![];if (g4_qb[d[480428]] === d[480427] && g4_qb[d[480429]] && g4_qb[d[480429]][d[480429]]) {
    var tybip = g4_qb[d[480429]][d[480752]],
        i3up1 = [];for (var amv$9e = 0x0; amv$9e < g4_qb[d[480429]][d[480429]][d[480009]]; amv$9e++) {
      g4_qb[d[480429]][d[480429]][amv$9e][d[480407]] = A1Z78(g4_qb[d[480429]][d[480429]][amv$9e]), (i3up1[d[480009]] == 0x0 || g4_qb[d[480429]][d[480429]][amv$9e][d[480407]] != 0x0) && (i3up1[i3up1[d[480009]]] = g4_qb[d[480429]][d[480429]][amv$9e]);
    }A1Z6[d[480420]][tybip] = window[d[480748]](i3up1), window[d[480373]][d[480421]](tybip);
  } else window['A187Z6'](d[480753] + g4_qb[d[480428]]);
}, window['A1$76Z'] = function (ykpx1i) {
  sendApi(A1Z6[d[480550]], d[480754], { 'partner_id': A1Z6[d[480558]], 'uid': A1Z6[d[480018]], 'version': A1Z6[d[480079]], 'game_pkg': A1Z6[d[480021]], 'device': A1Z6[d[480559]] }, reqServerRecommendCallBack, A176Z, A168);
}, window[d[480755]] = function (kp) {
  A1Z6[d[480422]] = ![];if (kp[d[480428]] === d[480427] && kp[d[480429]]) {
    for (var ibpyt = 0x0; ibpyt < kp[d[480429]][d[480009]]; ibpyt++) {
      kp[d[480429]][ibpyt][d[480407]] = A1Z78(kp[d[480429]][ibpyt]);
    }A1Z6[d[480420]][-0x2] = window[d[480748]](kp[d[480429]]), window[d[480373]][d[480421]](-0x2);
  } else alert(d[480756] + kp[d[480428]]);
}, window[d[480748]] = function (qxity) {
  if (!qxity && qxity[d[480009]] <= 0x0) return qxity;for (let _f4or = 0x0; _f4or < qxity[d[480009]]; _f4or++) {
    qxity[_f4or][d[480757]] && qxity[_f4or][d[480757]] == 0x1 && (qxity[_f4or][d[480408]] += d[480758]);
  }return qxity;
}, window['A1Z87'] = function (pxy, o4gf) {
  pxy = pxy || A1Z6[d[480022]][d[480023]], sendApi(A1Z6[d[480550]], d[480759], { 'type': '4', 'game_pkg': A1Z6[d[480021]], 'server_id': pxy }, o4gf);
}, window[d[480760]] = function (n$9ame, ma$n9e, qybixt, z6hwl) {
  qybixt = qybixt || A1Z6[d[480022]][d[480023]], sendApi(A1Z6[d[480550]], d[480761], { 'type': n$9ame, 'game_pkg': ma$n9e, 'server_id': qybixt }, z6hwl);
}, window['A1Z78'] = function (h6nsd) {
  if (h6nsd) {
    if (h6nsd[d[480407]] == 0x1) {
      if (h6nsd[d[480762]] == 0x1) return 0x2;else return 0x1;
    } else return h6nsd[d[480407]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['A1687Z'] = function (tqyib, hw6zsj) {
  A1Z6[d[480763]] = { 'step': tqyib, 'server_id': hw6zsj };var $na9me = this;A18Z76({ 'title': d[480764] }), sendApi(A1Z6[d[480550]], d[480765], { 'partner_id': A1Z6[d[480558]], 'uid': A1Z6[d[480018]], 'game_pkg': A1Z6[d[480021]], 'server_id': hw6zsj, 'platform': A1Z6[d[480083]], 'platform_uid': A1Z6[d[480653]], 'check_login_time': A1Z6[d[480656]], 'check_login_sign': A1Z6[d[480654]], 'version_name': A1Z6[d[480626]] }, A168Z7, A176Z, A168, function ($v0e9) {
    return $v0e9[d[480428]] == d[480427] || $v0e9[d[480000]] == d[480766] || $v0e9[d[480000]] == d[480767];
  });
}, window['A168Z7'] = function (oq4b_g) {
  var k108u = this;if (oq4b_g[d[480428]] === d[480427] && oq4b_g[d[480429]]) {
    var ik1y = A1Z6[d[480022]];ik1y[d[480768]] = A1Z6[d[480561]], ik1y[d[480655]] = String(oq4b_g[d[480429]][d[480769]]), ik1y[d[480567]] = parseInt(oq4b_g[d[480429]][d[480657]]);if (oq4b_g[d[480429]][d[480770]]) ik1y[d[480770]] = parseInt(oq4b_g[d[480429]][d[480770]]);else ik1y[d[480770]] = parseInt(oq4b_g[d[480429]][d[480023]]);ik1y[d[480771]] = 0x0, ik1y[d[480020]] = A1Z6[d[480675]], ik1y[d[480772]] = oq4b_g[d[480429]][d[480773]], ik1y[d[480774]] = oq4b_g[d[480429]][d[480774]], console[d[480041]](d[480775] + JSON[d[480026]](ik1y[d[480774]])), A1Z6[d[480501]] == 0x1 && ik1y[d[480774]] && ik1y[d[480774]][d[480776]] == 0x1 && (A1Z6[d[480330]] = 0x1, window[d[480034]][d[480035]]['A1$6Z']()), A1678Z();
  } else A1Z6[d[480763]][d[480777]] >= 0x3 ? (A168(JSON[d[480026]](oq4b_g)), window['A187Z6'](d[480778] + oq4b_g[d[480428]])) : sendApi(A1Z6[d[480550]], d[480638], { 'platform': A1Z6[d[480548]], 'partner_id': A1Z6[d[480558]], 'token': A1Z6[d[480636]], 'game_pkg': A1Z6[d[480021]], 'deviceId': A1Z6[d[480559]], 'scene': d[480639] + A1Z6[d[480560]] }, function (qb_otx) {
    if (!qb_otx || qb_otx[d[480428]] != d[480427]) {
      window['A187Z6'](d[480651] + qb_otx && qb_otx[d[480428]]);return;
    }A1Z6[d[480654]] = String(qb_otx[d[480655]]), A1Z6[d[480656]] = String(qb_otx[d[480657]]), setTimeout(function () {
      A1687Z(A1Z6[d[480763]][d[480777]] + 0x1, A1Z6[d[480763]][d[480023]]);
    }, 0x5dc);
  }, A176Z, A168, function (gf7_4) {
    return gf7_4[d[480428]] == d[480427] || gf7_4[d[480428]] == d[480779];
  });
}, window['A1678Z'] = function () {
  ServerLoading[d[480035]][d[480496]](A1Z6[d[480501]]), window['A176'] = !![], window['A16Z87']();
}, window['A167Z8'] = function () {
  if (window['A167'] && window['A1Z76'] && window[d[480492]] && window[d[480495]] && window['A1Z67'] && window['A1Z7']) {
    if (!window[d[480780]][d[480035]]) {
      console[d[480041]](d[480781] + window[d[480780]][d[480035]]);var ixb = wx[d[480782]](),
          i1xyp = ixb[d[480137]] ? ixb[d[480137]] : 0x0,
          v9$e = { 'cdn': window['A1Z6'][d[480020]], 'spareCdn': window['A1Z6'][d[480624]], 'newRegister': window['A1Z6'][d[480501]], 'wxPC': window['A1Z6'][d[480112]], 'wxIOS': window['A1Z6'][d[480106]], 'wxAndroid': window['A1Z6'][d[480109]], 'wxParam': { 'limitLoad': window['A1Z6']['A1$876Z'], 'benchmarkLevel': window['A1Z6']['A1$8Z76'], 'wxFrom': window[d[480005]][d[480631]] == d[480783] ? 0x1 : 0x0, 'wxSDKVersion': window[d[480039]] }, 'configType': window['A1Z6'][d[480568]], 'exposeType': window['A1Z6'][d[480570]], 'scene': i1xyp };new window[d[480780]](v9$e, window['A1Z6'][d[480019]], window['A1$87Z6']);
    }
  }
}, window['A16Z87'] = function () {
  if (window['A167'] && window['A1Z76'] && window[d[480492]] && window[d[480495]] && window['A1Z67'] && window['A1Z7'] && window['A176'] && window['A17Z']) {
    A18Z67();if (!A167Z) {
      A167Z = !![];if (!window[d[480780]][d[480035]]) window['A167Z8']();var dn9e$m = 0x0,
          typx1i = wx[d[480784]]();typx1i && (window['A1Z6'][d[480111]] && (dn9e$m = typx1i[d[480101]]), console[d[480000]](d[480785] + typx1i[d[480101]] + d[480786] + typx1i[d[480102]] + d[480787] + typx1i[d[480103]] + d[480788] + typx1i[d[480104]] + d[480789] + typx1i[d[480297]] + d[480790] + typx1i[d[480299]]));var zwh2jl = {};for (const ea$m in A1Z6[d[480022]]) {
        zwh2jl[ea$m] = A1Z6[d[480022]][ea$m];
      }var k38up1 = { 'channel': window['A1Z6'][d[480562]], 'account': window['A1Z6'][d[480018]], 'userId': window['A1Z6'][d[480652]], 'serverId': zwh2jl[d[480023]], 'cdn': window['A1Z6'][d[480020]], 'data': window['A1Z6'][d[480429]], 'package': window['A1Z6'][d[480547]], 'newRegister': window['A1Z6'][d[480501]], 'pkgName': window['A1Z6'][d[480021]], 'partnerId': window['A1Z6'][d[480558]], 'platform_uid': window['A1Z6'][d[480653]], 'deviceId': window['A1Z6'][d[480559]], 'selectedServer': zwh2jl, 'configType': window['A1Z6'][d[480568]], 'exposeType': window['A1Z6'][d[480570]], 'debugUsers': window['A1Z6'][d[480565]], 'wxMenuTop': dn9e$m, 'wxShield': window['A1Z6'][d[480571]] };if (window[d[480678]]) for (var q_xto in window[d[480678]]) {
        k38up1[q_xto] = window[d[480678]][q_xto];
      }window[d[480780]][d[480035]]['A16Z$'](k38up1);
    }
  } else console[d[480000]](d[480791] + window['A167'] + d[480792] + window['A1Z76'] + d[480793] + window[d[480492]] + d[480794] + window[d[480495]] + d[480795] + window['A1Z67'] + d[480796] + window['A1Z7'] + d[480797] + window['A176'] + d[480798] + window['A17Z']);
};