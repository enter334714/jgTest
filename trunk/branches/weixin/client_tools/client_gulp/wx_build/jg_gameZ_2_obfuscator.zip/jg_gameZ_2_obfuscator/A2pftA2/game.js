var d = wx.$A;
require('ABFAA.js'), window[d[481614]][d[481594]][d[481261]] = null, window['client_pb'] = require('AAIENAA.js'), window[d[481679]] = window[d[481614]][d[481444]][d[481312]](client_pb);