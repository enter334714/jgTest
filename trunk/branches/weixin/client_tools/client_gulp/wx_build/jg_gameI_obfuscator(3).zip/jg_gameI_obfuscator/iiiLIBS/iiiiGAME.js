var Q = wx.$I;
console[Q[120078]](Q[148987]), window[Q[148988]], wx[Q[148989]](function (qsuebk) {
  if (qsuebk) {
    if (qsuebk[Q[124525]]) {
      var ylgoz = window[Q[120555]][Q[148990]][Q[124703]](new RegExp(/\./, 'g'), '_'),
          b3ea7 = qsuebk[Q[124525]],
          seb763 = b3ea7[Q[132050]](/(iiiiiiiii\/iiiiGAME.js:)[0-9]{1,60}(:)/g);if (seb763) for (var pa8_j = 0x0; pa8_j < seb763[Q[120013]]; pa8_j++) {
        if (seb763[pa8_j] && seb763[pa8_j][Q[120013]] > 0x0) {
          var pcf_j = parseInt(seb763[pa8_j][Q[124703]](Q[148991], '')[Q[124703]](':', ''));b3ea7 = b3ea7[Q[124703]](seb763[pa8_j], seb763[pa8_j][Q[124703]](':' + pcf_j + ':', ':' + (pcf_j - 0x2) + ':'));
        }
      }b3ea7 = b3ea7[Q[124703]](new RegExp(Q[148992], 'g'), Q[148993] + ylgoz + Q[145316]), b3ea7 = b3ea7[Q[124703]](new RegExp(Q[148994], 'g'), Q[148993] + ylgoz + Q[145316]), qsuebk[Q[124525]] = b3ea7;
    }var yglz0 = { 'id': window['$iGR'][Q[148995]], 'role': window['$iGR'][Q[124645]], 'level': window['$iGR'][Q[148996]], 'user': window['$iGR'][Q[145216]], 'version': window['$iGR'][Q[120101]], 'cdn': window['$iGR'][Q[124524]], 'pkgName': window['$iGR'][Q[145217]], 'gamever': window[Q[120555]][Q[148990]], 'serverid': window['$iGR'][Q[145211]] ? window['$iGR'][Q[145211]][Q[131508]] : 0x0, 'systemInfo': window[Q[148997]], 'error': Q[148998], 'stack': qsuebk ? qsuebk[Q[124525]] : '' },
        g0zoyl = JSON[Q[124510]](yglz0);console[Q[120125]](Q[148999] + g0zoyl), (!window[Q[148988]] || window[Q[148988]] != yglz0[Q[120125]]) && (window[Q[148988]] = yglz0[Q[120125]], window['$iXG'](yglz0));
  }
});import 'iiiMDFIVEMIN.js';import 'iiiZLIBS.js';window[Q[149000]] = require(Q[149001]);import 'iiiINDEX.js';import 'iiiLIBSMIN.js';import 'iiiWXMINI.js';import 'iiiINITMIN.js';console[Q[120078]](Q[149002]), console[Q[120078]](Q[149003]), $iXGDR({ 'title': Q[149004] });var i_pm_1fc = { '$iEXRGD': !![] };new window[Q[149005]](i_pm_1fc), window[Q[149005]][Q[120148]]['$iEDGRX']();if (window['$iEXGRD']) clearInterval(window['$iEXGRD']);window['$iEXGRD'] = null, window['$iEDRXG'] = function (mv1ct, ek7bus) {
  if (!mv1ct || !ek7bus) return 0x0;mv1ct = mv1ct[Q[120015]]('.'), ek7bus = ek7bus[Q[120015]]('.');const zilg0$ = Math[Q[120851]](mv1ct[Q[120013]], ek7bus[Q[120013]]);while (mv1ct[Q[120013]] < zilg0$) {
    mv1ct[Q[120029]]('0');
  }while (ek7bus[Q[120013]] < zilg0$) {
    ek7bus[Q[120029]]('0');
  }for (var j_63a = 0x0; j_63a < zilg0$; j_63a++) {
    const bsque = parseInt(mv1ct[j_63a]),
          bekqu = parseInt(ek7bus[j_63a]);if (bsque > bekqu) return 0x1;else {
      if (bsque < bekqu) return -0x1;
    }
  }return 0x0;
}, window[Q[149006]] = wx[Q[149007]]()[Q[149006]], console[Q[120480]](Q[149008] + window[Q[149006]]);var i_r$tiv = wx[Q[149009]]();i_r$tiv[Q[149010]](function (t9mvi) {
  console[Q[120480]](Q[149011] + t9mvi[Q[149012]]);
}), i_r$tiv[Q[149013]](function () {
  wx[Q[149014]]({ 'title': Q[149015], 'content': Q[149016], 'showCancel': ![], 'success': function (sb673) {
      i_r$tiv[Q[149017]]();
    } });
}), i_r$tiv[Q[149018]](function () {
  console[Q[120480]](Q[149019]);
}), window['$iEDRGX'] = function () {
  console[Q[120480]](Q[149020]);var _mcpf = wx[Q[149021]]({ 'name': Q[149022], 'success': function (v9tmi) {
      console[Q[120480]](Q[149023]), console[Q[120480]](v9tmi), v9tmi && v9tmi[Q[145402]] == Q[149024] ? (window['$iRD'] = !![], window['$iRDGX'](), window['$iRGXD']()) : setTimeout(function () {
        window['$iEDRGX']();
      }, 0x1f4);
    }, 'fail': function (sbue) {
      console[Q[120480]](Q[149025]), console[Q[120480]](sbue), setTimeout(function () {
        window['$iEDRGX']();
      }, 0x1f4);
    } });_mcpf && _mcpf[Q[149026]](r$9tv => {});
}, window['$iEGXRD'] = function () {
  console[Q[120480]](Q[149027]);var u3s7eb = wx[Q[149021]]({ 'name': Q[149028], 'success': function (e3b67s) {
      console[Q[120480]](Q[149029]), console[Q[120480]](e3b67s), e3b67s && e3b67s[Q[145402]] == Q[149024] ? (window['$iGDR'] = !![], window['$iRDGX'](), window['$iRGXD']()) : setTimeout(function () {
        window['$iEGXRD']();
      }, 0x1f4);
    }, 'fail': function ($izg) {
      console[Q[120480]](Q[149030]), console[Q[120480]]($izg), setTimeout(function () {
        window['$iEGXRD']();
      }, 0x1f4);
    } });u3s7eb && u3s7eb[Q[149026]](kb => {});
}, window[Q[149031]] = function () {
  window['$iEDRXG'](window[Q[149006]], Q[149032]) >= 0x0 ? (console[Q[120480]](Q[149033] + window[Q[149006]] + Q[149034]), window['$iGX'](), window['$iEDRGX'](), window['$iEGXRD']()) : (window['$iGRX'](Q[149035], window[Q[149006]]), wx[Q[149014]]({ 'title': Q[126361], 'content': Q[149036] }));
}, window[Q[148997]] = '', wx[Q[149037]]({ 'success'($tilz) {
    window[Q[148997]] = Q[149038] + $tilz[Q[149039]] + Q[149040] + $tilz[Q[149041]] + Q[149042] + $tilz[Q[124716]] + Q[149043] + $tilz[Q[120473]] + Q[149044] + $tilz[Q[145186]] + Q[149045] + $tilz[Q[149006]] + Q[149046] + $tilz[Q[129309]], console[Q[120480]](window[Q[148997]]), console[Q[120480]](Q[149047] + $tilz[Q[149048]] + Q[149049] + $tilz[Q[149050]] + Q[149051] + $tilz[Q[149052]] + Q[149053] + $tilz[Q[149054]] + Q[149055] + $tilz[Q[149056]] + Q[149057] + $tilz[Q[149058]] + Q[149059] + ($tilz[Q[149060]] ? $tilz[Q[149060]][Q[120320]] + ',' + $tilz[Q[149060]][Q[121213]] + ',' + $tilz[Q[149060]][Q[121215]] + ',' + $tilz[Q[149060]][Q[121214]] : ''));var j67 = $tilz[Q[120473]] ? $tilz[Q[120473]][Q[132337]]() : '',
        bsek = $tilz[Q[149041]] ? $tilz[Q[149041]][Q[132337]]()[Q[124703]]('\x20', '') : '';window['$iGR'][Q[121072]] = j67[Q[120115]](Q[149061]) != -0x1, window['$iGR'][Q[131330]] = j67[Q[120115]](Q[148848]) != -0x1, window['$iGR'][Q[149062]] = j67[Q[120115]](Q[149061]) != -0x1 || j67[Q[120115]](Q[148848]) != -0x1, window['$iGR'][Q[144905]] = j67[Q[120115]](Q[149063]) != -0x1 || j67[Q[120115]](Q[149064]) != -0x1, window['$iGR'][Q[149065]] = $tilz[Q[145186]] ? $tilz[Q[145186]][Q[132337]]() : '', window['$iGR']['$iEXDRG'] = ![], window['$iGR']['$iEXGDR'] = 0x2;if (j67[Q[120115]](Q[148848]) != -0x1) {
      if ($tilz[Q[129309]] >= 0x18) window['$iGR']['$iEXGDR'] = 0x3;else window['$iGR']['$iEXGDR'] = 0x2;
    } else {
      if (j67[Q[120115]](Q[149061]) != -0x1) {
        if ($tilz[Q[129309]] && $tilz[Q[129309]] >= 0x14) window['$iGR']['$iEXGDR'] = 0x3;else {
          if (bsek[Q[120115]](Q[149066]) != -0x1 || bsek[Q[120115]](Q[149067]) != -0x1 || bsek[Q[120115]](Q[149068]) != -0x1 || bsek[Q[120115]](Q[149069]) != -0x1 || bsek[Q[120115]](Q[149070]) != -0x1) window['$iGR']['$iEXGDR'] = 0x2;else window['$iGR']['$iEXGDR'] = 0x3;
        }
      } else window['$iGR']['$iEXGDR'] = 0x2;
    }console[Q[120480]](Q[149071] + window['$iGR']['$iEXDRG'] + Q[149072] + window['$iGR']['$iEXGDR']);
  } }), wx[Q[149073]]({ 'success': function (c1t9mv) {
    console[Q[120480]](Q[149074] + c1t9mv[Q[124621]] + Q[149075] + c1t9mv[Q[149076]]);
  } }), wx[Q[149077]]({ 'success': function (afj6_) {
    console[Q[120480]](Q[149078] + afj6_[Q[149079]]);
  } }), wx[Q[149080]]({ 'keepScreenOn': !![] }), wx[Q[149081]](function (zo$l) {
  console[Q[120480]](Q[149078] + zo$l[Q[149079]] + Q[149082] + zo$l[Q[149083]]);
}), wx[Q[130841]](function (fvc) {
  window['$iDX'] = fvc, window['$iRXD'] && window['$iDX'] && (console[Q[120078]](Q[149084] + window['$iDX'][Q[120774]]), window['$iRXD'](window['$iDX']), window['$iDX'] = null);
}), window[Q[149085]] = 0x0, window['$iEGDRX'] = 0x0, window[Q[149086]] = null, wx[Q[149087]](function () {
  window['$iEGDRX']++;var it$rlz = Date[Q[120083]]();(window[Q[149085]] == 0x0 || it$rlz - window[Q[149085]] > 0x1d4c0) && (console[Q[120096]](Q[149088]), wx[Q[131903]]());if (window['$iEGDRX'] >= 0x2) {
    window['$iEGDRX'] = 0x0, console[Q[120125]](Q[149089]), wx[Q[149090]]('0', 0x1);if (window['$iGR'] && window['$iGR'][Q[121072]]) window['$iGRX'](Q[149091], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});