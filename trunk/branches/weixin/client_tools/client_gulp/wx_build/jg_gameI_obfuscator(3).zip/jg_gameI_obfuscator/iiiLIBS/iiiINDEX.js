var Q = wx.$I;
import i_fj68 from '../iiiiSDK/iiiSDDK.js';window[Q[149092]] = { 'wxVersion': window[Q[120555]][Q[148990]] }, window[Q[149093]] = ![], window['$iRG'] = 0x1, window[Q[149094]] = 0x1, window['$iDGR'] = !![], window[Q[149095]] = !![], window['$iEXDGR'] = '', window['$iGR'] = { 'base_cdn': Q[149096], 'cdn': Q[149096] }, $iGR[Q[149097]] = {}, $iGR[Q[144903]] = '0', $iGR[Q[124716]] = window[Q[149092]][Q[149098]], $iGR[Q[149064]] = '', $iGR['os'] = '1', $iGR[Q[149099]] = Q[149100], $iGR[Q[149101]] = Q[149102], $iGR[Q[149103]] = Q[149104], $iGR[Q[149105]] = Q[149106], $iGR[Q[149107]] = Q[149108], $iGR[Q[143638]] = '1', $iGR[Q[145217]] = '', $iGR[Q[145219]] = '', $iGR[Q[149109]] = 0x0, $iGR[Q[149110]] = {}, $iGR[Q[149111]] = parseInt($iGR[Q[143638]]), $iGR[Q[145215]] = $iGR[Q[143638]], $iGR[Q[145211]] = {}, $iGR['$iXG'] = Q[149112], $iGR[Q[149113]] = ![], $iGR[Q[132242]] = Q[149114], $iGR[Q[145188]] = Date[Q[120083]](), $iGR[Q[131849]] = Q[149115], $iGR[Q[120712]] = '_a', $iGR[Q[149116]] = 0x2, $iGR[Q[120101]] = 0x7c1, $iGR[Q[149098]] = window[Q[149092]][Q[149098]], $iGR[Q[120736]] = ![], $iGR[Q[121072]] = ![], $iGR[Q[131330]] = ![], $iGR[Q[144905]] = ![], window['$iDRG'] = 0x5, window['$iDR'] = ![], window['$iRD'] = ![], window['$iGDR'] = ![], window[Q[149117]] = ![], window[Q[149118]] = ![], window['$iGRD'] = ![], window['$iDG'] = ![], window['$iGD'] = ![], window['$iRDG'] = ![], window[Q[124185]] = function (ltir) {
  console[Q[120480]](Q[124185], ltir), wx[Q[124995]]({}), wx[Q[149014]]({ 'title': Q[126361], 'content': ltir, 'success'(q5k2wn) {
      if (q5k2wn[Q[149119]]) console[Q[120480]](Q[149120]);else q5k2wn[Q[120551]] && console[Q[120480]](Q[149121]);
    } });
}, window['$iXDGR'] = function (hx45w) {
  console[Q[120480]](Q[149122], hx45w), $iXGRD(), wx[Q[149014]]({ 'title': Q[126361], 'content': hx45w, 'confirmText': Q[149123], 'cancelText': Q[138496], 'success'(fvm1cp) {
      if (fvm1cp[Q[149119]]) window['$iGX']();else fvm1cp[Q[120551]] && (console[Q[120480]](Q[149124]), wx[Q[145375]]({}));
    } });
}, window['$iGE'] = function (pf8_cj) {
  console[Q[120480]](Q[149125], pf8_cj), wx[Q[149014]]({ 'title': Q[126361], 'content': pf8_cj, 'confirmText': Q[145347], 'showCancel': ![], 'complete'(wq45) {
      console[Q[120480]](Q[149124]), wx[Q[145375]]({});
    } });
}, window['$iXDRG'] = ![], window['$iXGDR'] = function (u3b7e) {
  window['$iXDRG'] = !![], wx[Q[124994]](u3b7e);
}, window['$iXGRD'] = function () {
  window['$iXDRG'] && (window['$iXDRG'] = ![], wx[Q[124995]]({}));
}, window['$iXRDG'] = function (_fpa8j) {
  window[Q[149005]][Q[120148]]['$iXRDG'](_fpa8j);
}, window[Q[132123]] = function ($r9iv, _j8cfp) {
  i_fj68[Q[132123]]($r9iv, function (jp8fc) {
    jp8fc && jp8fc[Q[120011]] ? jp8fc[Q[120011]][Q[124118]] == 0x1 ? _j8cfp(!![]) : (_j8cfp(![]), console[Q[120078]](Q[149126] + jp8fc[Q[120011]][Q[149127]])) : console[Q[120480]](Q[132123], jp8fc);
  });
}, window['$iXRGD'] = function (abj6) {
  console[Q[120480]](Q[149128], abj6);
}, window['$iXGR'] = function ($o0glz) {}, window['$iXRG'] = function (vmt1r9, b73use, ube7s3) {}, window['$iXR'] = function (l$zo0g) {
  console[Q[120480]](Q[149129], l$zo0g), window[Q[149005]][Q[120148]][Q[149130]](), window[Q[149005]][Q[120148]][Q[149131]](), window[Q[149005]][Q[120148]][Q[149132]]();
}, window['$iRX'] = function ($9rtvi) {
  window['$iXDGR'](Q[149133]);var cmvp1 = { 'id': window['$iGR'][Q[148995]], 'role': window['$iGR'][Q[124645]], 'level': window['$iGR'][Q[148996]], 'account': window['$iGR'][Q[145216]], 'version': window['$iGR'][Q[120101]], 'cdn': window['$iGR'][Q[124524]], 'pkgName': window['$iGR'][Q[145217]], 'gamever': window[Q[120555]][Q[148990]], 'serverid': window['$iGR'][Q[145211]] ? window['$iGR'][Q[145211]][Q[131508]] : 0x0, 'systemInfo': window[Q[148997]], 'error': Q[149134], 'stack': $9rtvi ? $9rtvi : Q[149133] },
      q2keus = JSON[Q[124510]](cmvp1);console[Q[120125]](Q[149135] + q2keus), window['$iXG'](q2keus);
}, window['$iGXR'] = function (j36a78) {
  var tmvr1 = JSON[Q[120525]](j36a78);tmvr1[Q[149136]] = window[Q[120555]][Q[148990]], tmvr1[Q[149137]] = window['$iGR'][Q[145211]] ? window['$iGR'][Q[145211]][Q[131508]] : 0x0, tmvr1[Q[148997]] = window[Q[148997]];var n5xw4h = JSON[Q[124510]](tmvr1);console[Q[120125]](Q[149138] + n5xw4h), window['$iXG'](n5xw4h);
}, window['$iGRX'] = function (gloz$0, glzi0) {
  var ri$zl = { 'id': window['$iGR'][Q[148995]], 'role': window['$iGR'][Q[124645]], 'level': window['$iGR'][Q[148996]], 'account': window['$iGR'][Q[145216]], 'version': window['$iGR'][Q[120101]], 'cdn': window['$iGR'][Q[124524]], 'pkgName': window['$iGR'][Q[145217]], 'gamever': window[Q[120555]][Q[148990]], 'serverid': window['$iGR'][Q[145211]] ? window['$iGR'][Q[145211]][Q[131508]] : 0x0, 'systemInfo': window[Q[148997]], 'error': gloz$0, 'stack': glzi0 },
      qu2n5 = JSON[Q[124510]](ri$zl);console[Q[120096]](Q[149139] + qu2n5), window['$iXG'](qu2n5);
}, window['$iXG'] = function (ukse2q) {
  if (window['$iGR'][Q[149065]] == Q[148847]) return;var v19mc = $iGR['$iXG'] + Q[149140] + $iGR[Q[145216]];wx[Q[120475]]({ 'url': v19mc, 'method': Q[148853], 'data': ukse2q, 'header': { 'content-type': Q[149141], 'cache-control': Q[149142] }, 'success': function (wkqn25) {
      DEBUG && console[Q[120480]](Q[149143], v19mc, ukse2q, wkqn25);
    }, 'fail': function (ubkqse) {
      DEBUG && console[Q[120480]](Q[149143], v19mc, ukse2q, ubkqse);
    }, 'complete': function () {} });
}, window[Q[149144]] = function () {
  function kus7b() {
    return ((0x1 + Math[Q[120119]]()) * 0x10000 | 0x0)[Q[120272]](0x10)[Q[120498]](0x1);
  }return kus7b() + kus7b() + '-' + kus7b() + '-' + kus7b() + '-' + kus7b() + '+' + kus7b() + kus7b() + kus7b();
}, window['$iGX'] = function () {
  console[Q[120480]](Q[149145]);var r19vm = i_fj68[Q[149146]]();$iGR[Q[145215]] = r19vm[Q[149147]], $iGR[Q[149111]] = r19vm[Q[149147]], $iGR[Q[143638]] = r19vm[Q[149147]], $iGR[Q[145217]] = r19vm[Q[149148]];var r$izl0 = { 'game_ver': $iGR[Q[124716]] };$iGR[Q[145219]] = this[Q[149144]](), $iXGDR({ 'title': Q[149149] }), i_fj68[Q[120366]](r$izl0, this['$iRXG'][Q[120074]](this));
}, window['$iRXG'] = function (trmvi9) {
  var rz$ = trmvi9[Q[149150]];console[Q[120480]](Q[149151] + rz$ + Q[149152] + (rz$ == 0x1) + Q[149153] + trmvi9[Q[148990]] + Q[149154] + window[Q[149092]][Q[149098]]);if (!trmvi9[Q[148990]] || window['$iEDRXG'](window[Q[149092]][Q[149098]], trmvi9[Q[148990]]) < 0x0) console[Q[120480]](Q[149155]), $iGR[Q[149101]] = Q[149156], $iGR[Q[149103]] = Q[149157], $iGR[Q[149105]] = Q[149158], $iGR[Q[124524]] = Q[149159], $iGR[Q[144902]] = Q[149160], $iGR[Q[149161]] = 'wd', $iGR[Q[120736]] = ![];else window['$iEDRXG'](window[Q[149092]][Q[149098]], trmvi9[Q[148990]]) == 0x0 ? (console[Q[120480]](Q[149162]), $iGR[Q[149101]] = Q[149102], $iGR[Q[149103]] = Q[149104], $iGR[Q[149105]] = Q[149106], $iGR[Q[124524]] = Q[149163], $iGR[Q[144902]] = Q[149160], $iGR[Q[149161]] = Q[149164], $iGR[Q[120736]] = !![]) : (console[Q[120480]](Q[149165]), $iGR[Q[149101]] = Q[149102], $iGR[Q[149103]] = Q[149104], $iGR[Q[149105]] = Q[149106], $iGR[Q[124524]] = Q[149163], $iGR[Q[144902]] = Q[149160], $iGR[Q[149161]] = Q[149164], $iGR[Q[120736]] = ![]);$iGR[Q[149109]] = config[Q[148463]] ? config[Q[148463]] : 0x0, this['$iDGXR'](), this['$iDGRX'](), window[Q[149166]] = 0x5, $iXGDR({ 'title': Q[149167] }), i_fj68[Q[148924]](this['$iRGX'][Q[120074]](this));
}, window[Q[149166]] = 0x5, window['$iRGX'] = function (vct91, cf18_p) {
  if (vct91 == 0x0 && cf18_p && cf18_p[Q[148554]]) {
    $iGR[Q[149168]] = cf18_p[Q[148554]];var ekq2 = this;$iXGDR({ 'title': Q[149169] }), sendApi($iGR[Q[149101]], Q[149170], { 'platform': $iGR[Q[149099]], 'partner_id': $iGR[Q[143638]], 'token': cf18_p[Q[148554]], 'game_pkg': $iGR[Q[145217]], 'deviceId': $iGR[Q[145219]], 'scene': Q[149171] + $iGR[Q[149109]] }, this['$iDXGR'][Q[120074]](this), $iDRG, $iRX);
  } else cf18_p && cf18_p[Q[145402]] && window[Q[149166]] > 0x0 && (cf18_p[Q[145402]][Q[120115]](Q[149172]) != -0x1 || cf18_p[Q[145402]][Q[120115]](Q[149173]) != -0x1 || cf18_p[Q[145402]][Q[120115]](Q[149174]) != -0x1 || cf18_p[Q[145402]][Q[120115]](Q[149175]) != -0x1 || cf18_p[Q[145402]][Q[120115]](Q[149176]) != -0x1 || cf18_p[Q[145402]][Q[120115]](Q[149177]) != -0x1) ? (window[Q[149166]]--, i_fj68[Q[148924]](this['$iRGX'][Q[120074]](this))) : (window['$iGRX'](Q[149178], JSON[Q[124510]]({ 'status': vct91, 'data': cf18_p })), window['$iXDGR'](Q[149179] + (cf18_p && cf18_p[Q[145402]] ? '，' + cf18_p[Q[145402]] : '')));
}, window['$iDXGR'] = function (rlzi$) {
  if (!rlzi$) {
    window['$iGRX'](Q[149180], Q[149181]), window['$iXDGR'](Q[149182]);return;
  }if (rlzi$[Q[124118]] != Q[129920]) {
    window['$iGRX'](Q[149180], JSON[Q[124510]](rlzi$)), window['$iXDGR'](Q[149183] + rlzi$[Q[124118]]);return;
  }$iGR[Q[143637]] = String(rlzi$[Q[145216]]), $iGR[Q[145216]] = String(rlzi$[Q[145216]]), $iGR[Q[145186]] = String(rlzi$[Q[145186]]), $iGR[Q[145215]] = String(rlzi$[Q[145186]]), $iGR[Q[145218]] = String(rlzi$[Q[145218]]), $iGR[Q[149184]] = String(rlzi$[Q[131491]]), $iGR[Q[149185]] = String(rlzi$[Q[120849]]), $iGR[Q[131491]] = '';var e673ba = this;$iXGDR({ 'title': Q[149186] }), sendApi($iGR[Q[149101]], Q[149187], { 'partner_id': $iGR[Q[143638]], 'uid': $iGR[Q[145216]], 'version': $iGR[Q[124716]], 'game_pkg': $iGR[Q[145217]], 'device': $iGR[Q[145219]] }, e673ba['$iDXRG'][Q[120074]](e673ba), $iDRG, $iRX);
}, window['$iDXRG'] = function (j7a3) {
  if (!j7a3) {
    window['$iXDGR'](Q[149188]);return;
  }if (j7a3[Q[124118]] != Q[129920]) {
    window['$iXDGR'](Q[149189] + j7a3[Q[124118]]);return;
  }if (!j7a3[Q[120011]] || j7a3[Q[120011]][Q[120013]] == 0x0) {
    window['$iXDGR'](Q[149190]);return;
  }$iGR[Q[120628]] = j7a3[Q[149191]], $iGR[Q[145211]] = { 'server_id': String(j7a3[Q[120011]][0x0][Q[131508]]), 'server_name': String(j7a3[Q[120011]][0x0][Q[149192]]), 'entry_ip': j7a3[Q[120011]][0x0][Q[145239]], 'entry_port': parseInt(j7a3[Q[120011]][0x0][Q[145240]]), 'status': $iGDX(j7a3[Q[120011]][0x0]), 'start_time': j7a3[Q[120011]][0x0][Q[149193]], 'cdn': $iGR[Q[124524]] }, this['$iRGDX']();
}, window['$iRGDX'] = function () {
  if ($iGR[Q[120628]] == 0x1) {
    var jf8_a6 = $iGR[Q[145211]][Q[120106]];if (jf8_a6 === -0x1 || jf8_a6 === 0x0) {
      window['$iXDGR'](jf8_a6 === -0x1 ? Q[149194] : Q[149195]);return;
    }$iRXDG(0x0, $iGR[Q[145211]][Q[131508]]), window[Q[149005]][Q[120148]][Q[149196]]($iGR[Q[120628]]);
  } else window[Q[149005]][Q[120148]][Q[149197]](), $iXGRD();window['$iGD'] = !![], window['$iRDGX'](), window['$iRGXD']();
}, window['$iDGXR'] = function () {
  sendApi($iGR[Q[149101]], Q[149198], { 'game_pkg': $iGR[Q[145217]], 'version_name': $iGR[Q[149161]] }, this[Q[149199]][Q[120074]](this), $iDRG, $iRX);
}, window[Q[149199]] = function (_ja63) {
  if (!_ja63) {
    window['$iXDGR'](Q[149200]);return;
  }if (_ja63[Q[124118]] != Q[129920]) {
    window['$iXDGR'](Q[149201] + _ja63[Q[124118]]);return;
  }if (!_ja63[Q[120011]] || !_ja63[Q[120011]][Q[124716]]) {
    window['$iXDGR'](Q[149202] + (_ja63[Q[120011]] && _ja63[Q[120011]][Q[124716]]));return;
  }_ja63[Q[120011]][Q[149203]] && _ja63[Q[120011]][Q[149203]][Q[120013]] > 0xa && ($iGR[Q[149204]] = _ja63[Q[120011]][Q[149203]], $iGR[Q[124524]] = _ja63[Q[120011]][Q[149203]]), _ja63[Q[120011]][Q[124716]] && ($iGR[Q[120101]] = _ja63[Q[120011]][Q[124716]]), console[Q[120078]](Q[145353] + $iGR[Q[120101]] + Q[149205] + $iGR[Q[149161]]), window['$iGRD'] = !![], window['$iRDGX'](), window['$iRGXD']();
}, window[Q[149206]], window['$iDGRX'] = function () {
  sendApi($iGR[Q[149101]], Q[149207], { 'game_pkg': $iGR[Q[145217]] }, this['$iDRXG'][Q[120074]](this), $iDRG, $iRX);
}, window['$iDRXG'] = function (u5q2k) {
  if (u5q2k[Q[124118]] === Q[129920] && u5q2k[Q[120011]]) {
    window[Q[149206]] = u5q2k[Q[120011]];for (var aj783 in u5q2k[Q[120011]]) {
      $iGR[aj783] = u5q2k[Q[120011]][aj783];
    }
  } else console[Q[120078]](Q[149208] + u5q2k[Q[124118]]);window['$iDG'] = !![], window['$iRGXD']();
}, window[Q[149209]] = function (uk7bes, t$lirz, e673s, vm1fcp, aj8_p, qwn452, b763j, kusnq2, esu2) {
  aj8_p = String(aj8_p);var mv1p9c = b763j,
      lg$zo0 = kusnq2;$iGR[Q[149097]][aj8_p] = { 'productid': aj8_p, 'productname': mv1p9c, 'productdesc': lg$zo0, 'roleid': uk7bes, 'rolename': t$lirz, 'rolelevel': e673s, 'price': qwn452, 'callback': esu2 }, sendApi($iGR[Q[149105]], Q[149210], { 'game_pkg': $iGR[Q[145217]], 'server_id': $iGR[Q[145211]][Q[131508]], 'server_name': $iGR[Q[145211]][Q[149192]], 'level': e673s, 'uid': $iGR[Q[145216]], 'role_id': uk7bes, 'role_name': t$lirz, 'product_id': aj8_p, 'product_name': mv1p9c, 'product_desc': lg$zo0, 'money': qwn452, 'partner_id': $iGR[Q[143638]] }, toPayCallBack, $iDRG, $iRX);
}, window[Q[149211]] = function (n2q54w) {
  if (n2q54w) {
    if (n2q54w[Q[149212]] === 0xc8 || n2q54w[Q[124118]] == Q[129920]) {
      var uqk52 = $iGR[Q[149097]][String(n2q54w[Q[149213]])];if (uqk52[Q[120332]]) uqk52[Q[120332]](n2q54w[Q[149213]], n2q54w[Q[149214]], -0x1);i_fj68[Q[148962]]({ 'cpbill': n2q54w[Q[149214]], 'productid': n2q54w[Q[149213]], 'productname': uqk52[Q[149215]], 'productdesc': uqk52[Q[149216]], 'serverid': $iGR[Q[145211]][Q[131508]], 'servername': $iGR[Q[145211]][Q[149192]], 'roleid': uqk52[Q[149217]], 'rolename': uqk52[Q[149218]], 'rolelevel': uqk52[Q[149219]], 'price': uqk52[Q[146910]], 'extension': JSON[Q[124510]]({ 'cp_order_id': n2q54w[Q[149214]] }) }, function (ukseb, irl0$z) {
        uqk52[Q[120332]] && ukseb == 0x0 && uqk52[Q[120332]](n2q54w[Q[149213]], n2q54w[Q[149214]], ukseb);console[Q[120078]](JSON[Q[124510]]({ 'type': Q[149220], 'status': ukseb, 'data': n2q54w, 'role_name': uqk52[Q[149218]] }));if (ukseb === 0x0) {} else {
          if (ukseb === 0x1) {} else {
            if (ukseb === 0x2) {}
          }
        }
      });
    } else alert(n2q54w[Q[120078]]);
  }
}, window['$iDRGX'] = function () {}, window['$iXDR'] = function (j76ab, fp1m_c, ivm9rt, af8_pj, ksnu2) {
  i_fj68[Q[148980]]($iGR[Q[145211]][Q[131508]], $iGR[Q[145211]][Q[149192]] || $iGR[Q[145211]][Q[131508]], j76ab, fp1m_c, ivm9rt), sendApi($iGR[Q[149101]], Q[149221], { 'game_pkg': $iGR[Q[145217]], 'server_id': $iGR[Q[145211]][Q[131508]], 'role_id': j76ab, 'uid': $iGR[Q[145216]], 'role_name': fp1m_c, 'role_type': af8_pj, 'level': ivm9rt });
}, window['$iXRD'] = function (uksb7, n5qu2k, ebs3u, ek2q, beu7ks, u73bes, lgzi$0, l$zrt, nw54hx, r$liz0) {
  $iGR[Q[148995]] = uksb7, $iGR[Q[124645]] = n5qu2k, $iGR[Q[148996]] = ebs3u, i_fj68[Q[148981]]($iGR[Q[145211]][Q[131508]], $iGR[Q[145211]][Q[149192]] || $iGR[Q[145211]][Q[131508]], uksb7, n5qu2k, ebs3u), sendApi($iGR[Q[149101]], Q[149222], { 'game_pkg': $iGR[Q[145217]], 'server_id': $iGR[Q[145211]][Q[131508]], 'role_id': uksb7, 'uid': $iGR[Q[145216]], 'role_name': n5qu2k, 'role_type': ek2q, 'level': ebs3u, 'evolution': beu7ks });
}, window['$iDXR'] = function (nh542, $irlt, l9tir$, n25uk, uqsb, afj, f_ajp, f_pc81, r9vm, cp18_) {
  $iGR[Q[148995]] = nh542, $iGR[Q[124645]] = $irlt, $iGR[Q[148996]] = l9tir$, i_fj68[Q[148982]]($iGR[Q[145211]][Q[131508]], $iGR[Q[145211]][Q[149192]] || $iGR[Q[145211]][Q[131508]], nh542, $irlt, l9tir$), sendApi($iGR[Q[149101]], Q[149222], { 'game_pkg': $iGR[Q[145217]], 'server_id': $iGR[Q[145211]][Q[131508]], 'role_id': nh542, 'uid': $iGR[Q[145216]], 'role_name': $irlt, 'role_type': n25uk, 'level': l9tir$, 'evolution': uqsb });
}, window['$iDRX'] = function (nuqs) {}, window['$iXD'] = function (j_cp) {
  i_fj68[Q[148942]](Q[148942], function (esqk2) {
    j_cp && j_cp(esqk2);
  });
}, window[Q[144886]] = function () {
  i_fj68[Q[144886]]();
}, window[Q[149223]] = function () {
  i_fj68[Q[143531]]();
}, window[Q[130841]] = function (f6j) {
  window['$iRXD'] = f6j, window['$iRXD'] && window['$iDX'] && (console[Q[120078]](Q[149084] + window['$iDX'][Q[120774]]), window['$iRXD'](window['$iDX']), window['$iDX'] = null);
}, window['$iRDX'] = function (goyzl0, i0zl$, vp91, u2nk5q) {
  window[Q[120022]](Q[149224], { 'game_pkg': window['$iGR'][Q[145217]], 'role_id': i0zl$, 'server_id': vp91 }, u2nk5q);
}, window['$iGXDR'] = function (pm9cv1, lgz$o0) {
  function fmcv(uq5) {
    var $tirz = [],
        qw2k5 = [],
        v19tmc = window[Q[120555]][Q[149225]];for (var pmcv in v19tmc) {
      var yzolg0 = Number(pmcv);(!pm9cv1 || !pm9cv1[Q[120013]] || pm9cv1[Q[120115]](yzolg0) != -0x1) && (qw2k5[Q[120029]](v19tmc[pmcv]), $tirz[Q[120029]]([yzolg0, 0x3]));
    }window['$iEDRXG'](window[Q[149006]], Q[149226]) >= 0x0 ? (console[Q[120480]](Q[149227]), i_fj68[Q[149228]] && i_fj68[Q[149228]](qw2k5, function (a83) {
      console[Q[120480]](Q[149229]), console[Q[120480]](a83);if (a83 && a83[Q[145402]] == Q[149230]) for (var o0gzdy in v19tmc) {
        if (a83[v19tmc[o0gzdy]] == Q[149231]) {
          var ig$0zl = Number(o0gzdy);for (var _cp8fj = 0x0; _cp8fj < $tirz[Q[120013]]; _cp8fj++) {
            if ($tirz[_cp8fj][0x0] == ig$0zl) {
              $tirz[_cp8fj][0x1] = 0x1;break;
            }
          }
        }
      }window['$iEDRXG'](window[Q[149006]], Q[149232]) >= 0x0 ? wx[Q[149233]]({ 'withSubscriptions': !![], 'success': function (rzi$lt) {
          var t91cv = rzi$lt[Q[149234]][Q[149235]];if (t91cv) {
            console[Q[120480]](Q[149236]), console[Q[120480]](t91cv);for (var n2wq54 in v19tmc) {
              if (t91cv[v19tmc[n2wq54]] == Q[149231]) {
                var zl$t = Number(n2wq54);for (var wnh452 = 0x0; wnh452 < $tirz[Q[120013]]; wnh452++) {
                  if ($tirz[wnh452][0x0] == zl$t) {
                    $tirz[wnh452][0x1] = 0x2;break;
                  }
                }
              }
            }console[Q[120480]]($tirz), lgz$o0 && lgz$o0($tirz);
          } else console[Q[120480]](Q[149237]), console[Q[120480]](rzi$lt), console[Q[120480]]($tirz), lgz$o0 && lgz$o0($tirz);
        }, 'fail': function () {
          console[Q[120480]](Q[149238]), console[Q[120480]]($tirz), lgz$o0 && lgz$o0($tirz);
        } }) : (console[Q[120480]](Q[149239] + window[Q[149006]]), console[Q[120480]]($tirz), lgz$o0 && lgz$o0($tirz));
    })) : (console[Q[120480]](Q[149240] + window[Q[149006]]), console[Q[120480]]($tirz), lgz$o0 && lgz$o0($tirz)), wx[Q[149241]](fmcv);
  }wx[Q[149242]](fmcv);
}, window['$iGXRD'] = { 'isSuccess': ![], 'level': Q[149243], 'isCharging': ![] }, window['$iGDXR'] = function (f1cmp_) {
  wx[Q[149073]]({ 'success': function (n2w5kq) {
      var vtr9i$ = window['$iGXRD'];vtr9i$[Q[149244]] = !![], vtr9i$[Q[124621]] = Number(n2w5kq[Q[124621]])[Q[124233]](0x0), vtr9i$[Q[149076]] = n2w5kq[Q[149076]], f1cmp_ && f1cmp_(vtr9i$[Q[149244]], vtr9i$[Q[124621]], vtr9i$[Q[149076]]);
    }, 'fail': function (vi9$tr) {
      console[Q[120480]](Q[149245], vi9$tr[Q[145402]]);var tvri$9 = window['$iGXRD'];f1cmp_ && f1cmp_(tvri$9[Q[149244]], tvri$9[Q[124621]], tvri$9[Q[149076]]);
    } });
}, window[Q[120022]] = function (lz$r0, qsek2, n4wq5, e3b7, u25kn, f8_6a, h42, cf_mp) {
  if (e3b7 == undefined) e3b7 = 0x1;wx[Q[120475]]({ 'url': lz$r0, 'method': h42 || Q[145105], 'responseType': Q[124430], 'data': qsek2, 'header': { 'content-type': cf_mp || Q[149141] }, 'success': function (tzi$r) {
      DEBUG && console[Q[120480]](Q[149246], lz$r0, info, tzi$r);if (tzi$r && tzi$r[Q[145468]] == 0xc8) {
        var ueb3s7 = tzi$r[Q[120011]];!f8_6a || f8_6a(ueb3s7) ? n4wq5 && n4wq5(ueb3s7) : window[Q[149247]](lz$r0, qsek2, n4wq5, e3b7, u25kn, f8_6a, tzi$r);
      } else window[Q[149247]](lz$r0, qsek2, n4wq5, e3b7, u25kn, f8_6a, tzi$r);
    }, 'fail': function (n542w) {
      DEBUG && console[Q[120480]](Q[149248], lz$r0, info, n542w), window[Q[149247]](lz$r0, qsek2, n4wq5, e3b7, u25kn, f8_6a, n542w);
    }, 'complete': function () {} });
}, window[Q[149247]] = function (b7j6a3, iz$0g, baj673, j367ba, r9t$l, _p8cj, p1c_) {
  j367ba - 0x1 > 0x0 ? setTimeout(function () {
    window[Q[120022]](b7j6a3, iz$0g, baj673, j367ba - 0x1, r9t$l, _p8cj);
  }, 0x3e8) : r9t$l && r9t$l(JSON[Q[124510]]({ 'url': b7j6a3, 'response': p1c_ }));
}, window[Q[149249]] = function (y0golz, pm1c_, lti$r, e2uqsk, n5q24, r9timv, $l0zri) {
  !lti$r && (lti$r = {});var l0zr = Math[Q[120118]](Date[Q[120083]]() / 0x3e8);lti$r[Q[120849]] = l0zr, lti$r[Q[145026]] = pm1c_;var qse2u = Object[Q[120264]](lti$r)[Q[121076]](),
      p91cm = '',
      ebqu = '';for (var $ril9t = 0x0; $ril9t < qse2u[Q[120013]]; $ril9t++) {
    p91cm = p91cm + ($ril9t == 0x0 ? '' : '&') + qse2u[$ril9t] + lti$r[qse2u[$ril9t]], ebqu = ebqu + ($ril9t == 0x0 ? '' : '&') + qse2u[$ril9t] + '=' + encodeURIComponent(lti$r[qse2u[$ril9t]]);
  }p91cm = p91cm + $iGR[Q[149107]];var _a863 = Q[149250] + md5(p91cm);send(y0golz + '?' + ebqu + (ebqu == '' ? '' : '&') + _a863, null, e2uqsk, n5q24, r9timv, $l0zri || function (ebs73u) {
    return ebs73u[Q[124118]] == Q[129920];
  }, null, Q[148854]);
}, window['$iGDRX'] = function (izr0$, h4x5wn) {
  var olg = 0x0;$iGR[Q[145211]] && (olg = $iGR[Q[145211]][Q[131508]]), sendApi($iGR[Q[149103]], Q[149251], { 'partnerId': $iGR[Q[143638]], 'gamePkg': $iGR[Q[145217]], 'logTime': Math[Q[120118]](Date[Q[120083]]() / 0x3e8), 'platformUid': $iGR[Q[145218]], 'type': izr0$, 'serverId': olg }, null, 0x2, null, function () {
    return !![];
  });
}, window['$iGRXD'] = function (kq2esu) {
  sendApi($iGR[Q[149101]], Q[149252], { 'partner_id': $iGR[Q[143638]], 'uid': $iGR[Q[145216]], 'version': $iGR[Q[124716]], 'game_pkg': $iGR[Q[145217]], 'device': $iGR[Q[145219]] }, $iGRDX, $iDRG, $iRX);
}, window['$iGRDX'] = function (nx54wh) {
  if (nx54wh[Q[124118]] === Q[129920] && nx54wh[Q[120011]]) {
    nx54wh[Q[120011]][Q[125598]]({ 'id': -0x2, 'name': Q[149253] }), nx54wh[Q[120011]][Q[125598]]({ 'id': -0x1, 'name': Q[149254] }), $iGR[Q[149255]] = nx54wh[Q[120011]];if (window[Q[132288]]) window[Q[132288]][Q[149256]]();
  } else $iGR[Q[149257]] = ![], window['$iXDGR'](Q[149258] + nx54wh[Q[124118]]);
}, window['$iXDG'] = function (c1m) {
  sendApi($iGR[Q[149101]], Q[149259], { 'partner_id': $iGR[Q[143638]], 'uid': $iGR[Q[145216]], 'version': $iGR[Q[124716]], 'game_pkg': $iGR[Q[145217]], 'device': $iGR[Q[145219]] }, $iXGD, $iDRG, $iRX);
}, window['$iXGD'] = function (w54n2q) {
  $iGR[Q[149260]] = ![];if (w54n2q[Q[124118]] === Q[129920] && w54n2q[Q[120011]]) {
    for (var gzl$ = 0x0; gzl$ < w54n2q[Q[120011]][Q[120013]]; gzl$++) {
      w54n2q[Q[120011]][gzl$][Q[120106]] = $iGDX(w54n2q[Q[120011]][gzl$]);
    }$iGR[Q[149110]][-0x1] = window[Q[149261]](w54n2q[Q[120011]]), window[Q[132288]][Q[149262]](-0x1);
  } else window['$iXDGR'](Q[149263] + w54n2q[Q[124118]]);
}, window[Q[149264]] = function (h452nw) {
  sendApi($iGR[Q[149101]], Q[149259], { 'partner_id': $iGR[Q[143638]], 'uid': $iGR[Q[145216]], 'version': $iGR[Q[124716]], 'game_pkg': $iGR[Q[145217]], 'device': $iGR[Q[145219]] }, h452nw, $iDRG, $iRX);
}, window['$iDXG'] = function (hn52w, rm1) {
  sendApi($iGR[Q[149101]], Q[149265], { 'partner_id': $iGR[Q[143638]], 'uid': $iGR[Q[145216]], 'version': $iGR[Q[124716]], 'game_pkg': $iGR[Q[145217]], 'device': $iGR[Q[145219]], 'server_group_id': rm1 }, $iDGX, $iDRG, $iRX);
}, window['$iDGX'] = function (q4n2) {
  $iGR[Q[149260]] = ![];if (q4n2[Q[124118]] === Q[129920] && q4n2[Q[120011]] && q4n2[Q[120011]][Q[120011]]) {
    var wknq2 = q4n2[Q[120011]][Q[149266]],
        vmri = [];for (var f8j6_ = 0x0; f8j6_ < q4n2[Q[120011]][Q[120011]][Q[120013]]; f8j6_++) {
      q4n2[Q[120011]][Q[120011]][f8j6_][Q[120106]] = $iGDX(q4n2[Q[120011]][Q[120011]][f8j6_]), (vmri[Q[120013]] == 0x0 || q4n2[Q[120011]][Q[120011]][f8j6_][Q[120106]] != 0x0) && (vmri[vmri[Q[120013]]] = q4n2[Q[120011]][Q[120011]][f8j6_]);
    }$iGR[Q[149110]][wknq2] = window[Q[149261]](vmri), window[Q[132288]][Q[149262]](wknq2);
  } else window['$iXDGR'](Q[149267] + q4n2[Q[124118]]);
}, window['$iEDRG'] = function (bs376) {
  sendApi($iGR[Q[149101]], Q[149268], { 'partner_id': $iGR[Q[143638]], 'uid': $iGR[Q[145216]], 'version': $iGR[Q[124716]], 'game_pkg': $iGR[Q[145217]], 'device': $iGR[Q[145219]] }, reqServerRecommendCallBack, $iDRG, $iRX);
}, window[Q[149269]] = function (a_8jfp) {
  $iGR[Q[149260]] = ![];if (a_8jfp[Q[124118]] === Q[129920] && a_8jfp[Q[120011]]) {
    for (var cpf_1m = 0x0; cpf_1m < a_8jfp[Q[120011]][Q[120013]]; cpf_1m++) {
      a_8jfp[Q[120011]][cpf_1m][Q[120106]] = $iGDX(a_8jfp[Q[120011]][cpf_1m]);
    }$iGR[Q[149110]][-0x2] = window[Q[149261]](a_8jfp[Q[120011]]), window[Q[132288]][Q[149262]](-0x2);
  } else alert(Q[149270] + a_8jfp[Q[124118]]);
}, window[Q[149261]] = function (cpmvf) {
  if (!cpmvf && cpmvf[Q[120013]] <= 0x0) return cpmvf;for (let eus2k = 0x0; eus2k < cpmvf[Q[120013]]; eus2k++) {
    cpmvf[eus2k][Q[149271]] && cpmvf[eus2k][Q[149271]] == 0x1 && (cpmvf[eus2k][Q[149192]] += Q[149272]);
  }return cpmvf;
}, window['$iGXD'] = function (cm9t1, irv9m) {
  cm9t1 = cm9t1 || $iGR[Q[145211]][Q[131508]], sendApi($iGR[Q[149101]], Q[149273], { 'type': '4', 'game_pkg': $iGR[Q[145217]], 'server_id': cm9t1 }, irv9m);
}, window[Q[149274]] = function (keus7, _cjfp8, wnx45h, ba67e) {
  wnx45h = wnx45h || $iGR[Q[145211]][Q[131508]], sendApi($iGR[Q[149101]], Q[149275], { 'type': keus7, 'game_pkg': _cjfp8, 'server_id': wnx45h }, ba67e);
}, window['$iGDX'] = function (qseub) {
  if (qseub) {
    if (qseub[Q[120106]] == 0x1) {
      if (qseub[Q[149276]] == 0x1) return 0x2;else return 0x1;
    } else return qseub[Q[120106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$iRXDG'] = function (ol0z$g, v1tcm9) {
  $iGR[Q[149277]] = { 'step': ol0z$g, 'server_id': v1tcm9 };var qksueb = this;$iXGDR({ 'title': Q[149278] }), sendApi($iGR[Q[149101]], Q[149279], { 'partner_id': $iGR[Q[143638]], 'uid': $iGR[Q[145216]], 'game_pkg': $iGR[Q[145217]], 'server_id': v1tcm9, 'platform': $iGR[Q[145186]], 'platform_uid': $iGR[Q[145218]], 'check_login_time': $iGR[Q[149185]], 'check_login_sign': $iGR[Q[149184]], 'version_name': $iGR[Q[149161]] }, $iRXGD, $iDRG, $iRX, function (c_1mpf) {
    return c_1mpf[Q[124118]] == Q[129920] || c_1mpf[Q[120078]] == Q[149280] || c_1mpf[Q[120078]] == Q[149281];
  });
}, window['$iRXGD'] = function (rzt$) {
  var skqnu2 = this;if (rzt$[Q[124118]] === Q[129920] && rzt$[Q[120011]]) {
    var _aj638 = $iGR[Q[145211]];_aj638[Q[149282]] = $iGR[Q[149111]], _aj638[Q[131491]] = String(rzt$[Q[120011]][Q[149283]]), _aj638[Q[145188]] = parseInt(rzt$[Q[120011]][Q[120849]]);if (rzt$[Q[120011]][Q[145187]]) _aj638[Q[145187]] = parseInt(rzt$[Q[120011]][Q[145187]]);else _aj638[Q[145187]] = parseInt(rzt$[Q[120011]][Q[131508]]);_aj638[Q[149284]] = 0x0, _aj638[Q[124524]] = $iGR[Q[149204]], _aj638[Q[149285]] = rzt$[Q[120011]][Q[149286]], _aj638[Q[149287]] = rzt$[Q[120011]][Q[149287]], console[Q[120480]](Q[149288] + JSON[Q[124510]](_aj638[Q[149287]])), $iGR[Q[120628]] == 0x1 && _aj638[Q[149287]] && _aj638[Q[149287]][Q[149289]] == 0x1 && ($iGR[Q[149290]] = 0x1, window[Q[149005]][Q[120148]]['$iERG']()), $iRDXG();
  } else $iGR[Q[149277]][Q[127118]] >= 0x3 ? ($iRX(JSON[Q[124510]](rzt$)), window['$iXDGR'](Q[149291] + rzt$[Q[124118]])) : sendApi($iGR[Q[149101]], Q[149170], { 'platform': $iGR[Q[149099]], 'partner_id': $iGR[Q[143638]], 'token': $iGR[Q[149168]], 'game_pkg': $iGR[Q[145217]], 'deviceId': $iGR[Q[145219]], 'scene': Q[149171] + $iGR[Q[149109]] }, function (j_8pfa) {
    if (!j_8pfa || j_8pfa[Q[124118]] != Q[129920]) {
      window['$iXDGR'](Q[149183] + j_8pfa && j_8pfa[Q[124118]]);return;
    }$iGR[Q[149184]] = String(j_8pfa[Q[131491]]), $iGR[Q[149185]] = String(j_8pfa[Q[120849]]), setTimeout(function () {
      $iRXDG($iGR[Q[149277]][Q[127118]] + 0x1, $iGR[Q[149277]][Q[131508]]);
    }, 0x5dc);
  }, $iDRG, $iRX, function (i$rt9) {
    return i$rt9[Q[124118]] == Q[129920] || i$rt9[Q[124118]] == Q[145546];
  });
}, window['$iRDXG'] = function () {
  ServerLoading[Q[120148]][Q[149196]]($iGR[Q[120628]]), window['$iDR'] = !![], window['$iRGXD']();
}, window['$iRDGX'] = function () {
  if (window['$iRD'] && window['$iGDR'] && window[Q[149117]] && window[Q[149118]] && window['$iGRD'] && window['$iGD']) {
    if (!window[Q[148442]][Q[120148]]) {
      console[Q[120480]](Q[149292] + window[Q[148442]][Q[120148]]);var bkse7 = wx[Q[149293]](),
          pc_fm = bkse7[Q[120774]] ? bkse7[Q[120774]] : 0x0,
          y0olgz = { 'cdn': window['$iGR'][Q[124524]], 'spareCdn': window['$iGR'][Q[144902]], 'newRegister': window['$iGR'][Q[120628]], 'wxPC': window['$iGR'][Q[144905]], 'wxIOS': window['$iGR'][Q[121072]], 'wxAndroid': window['$iGR'][Q[131330]], 'wxParam': { 'limitLoad': window['$iGR']['$iEXDRG'], 'benchmarkLevel': window['$iGR']['$iEXGDR'], 'wxFrom': window[Q[120555]][Q[148463]] == Q[149294] ? 0x1 : 0x0, 'wxSDKVersion': window[Q[149006]] }, 'configType': window['$iGR'][Q[131849]], 'exposeType': window['$iGR'][Q[120712]], 'scene': pc_fm };new window[Q[148442]](y0olgz, window['$iGR'][Q[120101]], window['$iEXDGR']);
    }
  }
}, window['$iRGXD'] = function () {
  if (window['$iRD'] && window['$iGDR'] && window[Q[149117]] && window[Q[149118]] && window['$iGRD'] && window['$iGD'] && window['$iDR'] && window['$iDG']) {
    $iXGRD();if (!$iRDG) {
      $iRDG = !![];if (!window[Q[148442]][Q[120148]]) window['$iRDGX']();var s3u7b = 0x0,
          glzo0y = wx[Q[149295]]();glzo0y && (window['$iGR'][Q[149062]] && (s3u7b = glzo0y[Q[120320]]), console[Q[120078]](Q[149296] + glzo0y[Q[120320]] + Q[149297] + glzo0y[Q[121213]] + Q[149298] + glzo0y[Q[121215]] + Q[149299] + glzo0y[Q[121214]] + Q[149300] + glzo0y[Q[120176]] + Q[149301] + glzo0y[Q[120177]]));var yod0g = {};for (const a3b76j in $iGR[Q[145211]]) {
        yod0g[a3b76j] = $iGR[Q[145211]][a3b76j];
      }var c1m9v = { 'channel': window['$iGR'][Q[145215]], 'account': window['$iGR'][Q[145216]], 'userId': window['$iGR'][Q[143637]], 'cdn': window['$iGR'][Q[124524]], 'data': window['$iGR'][Q[120011]], 'package': window['$iGR'][Q[144903]], 'newRegister': window['$iGR'][Q[120628]], 'pkgName': window['$iGR'][Q[145217]], 'partnerId': window['$iGR'][Q[143638]], 'platform_uid': window['$iGR'][Q[145218]], 'deviceId': window['$iGR'][Q[145219]], 'selectedServer': yod0g, 'configType': window['$iGR'][Q[131849]], 'exposeType': window['$iGR'][Q[120712]], 'debugUsers': window['$iGR'][Q[132242]], 'wxMenuTop': s3u7b, 'wxShield': window['$iGR'][Q[120736]] };if (window[Q[149206]]) for (var q2ue in window[Q[149206]]) {
        c1m9v[q2ue] = window[Q[149206]][q2ue];
      }window[Q[148442]][Q[120148]]['$iDEGR'](c1m9v);
    }
  } else console[Q[120078]](Q[149302] + window['$iRD'] + Q[149303] + window['$iGDR'] + Q[149304] + window[Q[149117]] + Q[149305] + window[Q[149118]] + Q[149306] + window['$iGRD'] + Q[149307] + window['$iGD'] + Q[149308] + window['$iDR'] + Q[149309] + window['$iDG']);
};