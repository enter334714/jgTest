var Q = wx.$I;
require(Q[148986]);