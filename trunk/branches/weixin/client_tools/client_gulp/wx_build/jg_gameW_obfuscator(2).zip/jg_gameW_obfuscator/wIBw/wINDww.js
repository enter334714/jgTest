var s = wx.$W;
import wya9v$x from '../wwawww/w7ww.js';window[s[380916]] = { 'wxVersion': window[s[380917]][s[380918]] }, window[s[380919]] = ![], window['_w32'] = 0x1, window[s[380920]] = 0x1, window['_w023'] = !![], window[s[380921]] = !![], window['_wBQ023'] = '', window['_w23'] = { 'base_cdn': s[380922], 'cdn': s[380922] }, _w23[s[380923]] = {}, _w23[s[380304]] = '0', _w23[s[380924]] = window[s[380916]][s[380925]], _w23[s[380926]] = '', _w23['os'] = '1', _w23[s[380927]] = s[380928], _w23[s[380929]] = s[380930], _w23[s[380931]] = s[380932], _w23[s[380933]] = s[380934], _w23[s[380935]] = s[380936], _w23[s[380937]] = '1', _w23[s[380938]] = '', _w23[s[380939]] = '', _w23[s[380940]] = 0x0, _w23[s[380941]] = {}, _w23[s[380942]] = parseInt(_w23[s[380937]]), _w23[s[380943]] = _w23[s[380937]], _w23[s[380944]] = {}, _w23['_wQ2'] = s[380945], _w23[s[380946]] = ![], _w23[s[380947]] = s[380948], _w23[s[380949]] = Date[s[380950]](), _w23[s[380951]] = '_weixin', _w23[s[380952]] = '_a', _w23[s[380953]] = 0x2, _w23[s[380954]] = 0x7c1, _w23[s[380925]] = window[s[380916]][s[380925]], _w23[s[380955]] = ![], _w23[s[380956]] = ![], _w23[s[380957]] = ![], _w23[s[380958]] = ![], window['_w032'] = 0x5, window['_w03'] = ![], window['_w30'] = ![], window['_w203'] = ![], window[s[380959]] = ![], window[s[380960]] = ![], window['_w230'] = ![], window['_w02'] = ![], window['_w20'] = ![], window['_w302'] = ![], window[s[380961]] = function (c58bgk) {
  console[s[380225]](s[380961], c58bgk), wx[s[380962]]({}), wx[s[380963]]({ 'title': s[380964], 'content': c58bgk, 'success'(mwnsq) {
      if (mwnsq[s[380965]]) console[s[380225]](s[380966]);else mwnsq[s[380967]] && console[s[380225]](s[380968]);
    } });
}, window['_wQ023'] = function (njofwe) {
  console[s[380225]](s[380969], njofwe), _wQ230(), wx[s[380963]]({ 'title': s[380964], 'content': njofwe, 'confirmText': s[380970], 'cancelText': s[380971], 'success'(phq4) {
      if (phq4[s[380965]]) window['_w2Q']();else phq4[s[380967]] && (console[s[380225]](s[380972]), wx[s[380973]]({}));
    } });
}, window['_w2B'] = function (y$xvra) {
  console[s[380225]](s[380974], y$xvra), wx[s[380963]]({ 'title': s[380964], 'content': y$xvra, 'confirmText': s[380975], 'showCancel': ![], 'complete'(z3e2f) {
      console[s[380225]](s[380972]), wx[s[380973]]({});
    } });
}, window['_wQ032'] = ![], window['_wQ203'] = function (mwsnqo) {
  window['_wQ032'] = !![], wx[s[380976]](mwsnqo);
}, window['_wQ230'] = function () {
  window['_wQ032'] && (window['_wQ032'] = ![], wx[s[380962]]({}));
}, window['_wQ302'] = function (s6oq) {
  window[s[380977]][s[380978]]['_wQ302'](s6oq);
}, window[s[380979]] = function (ry$xv, a$vl_9) {
  wya9v$x[s[380979]](ry$xv, function (hu85t0) {
    hu85t0 && hu85t0[s[380335]] ? hu85t0[s[380335]][s[380980]] == 0x1 ? a$vl_9(!![]) : (a$vl_9(![]), console[s[380981]](s[380982] + hu85t0[s[380335]][s[380983]])) : console[s[380225]](s[380979], hu85t0);
  });
}, window['_wQ320'] = function (tuhp80) {
  console[s[380225]](s[380984], tuhp80);
}, window['_wQ23'] = function (pm6qs4) {}, window['_wQ32'] = function (mwsoqn, krc, vy9$x) {}, window['_wQ3'] = function ($vyxra) {
  console[s[380225]](s[380985], $vyxra), window[s[380977]][s[380978]][s[380986]](), window[s[380977]][s[380978]][s[380987]](), window[s[380977]][s[380978]][s[380988]]();
}, window['_w3Q'] = function ($vyrxa) {
  window['_wQ023'](s[380989]);var thu850 = { 'id': window['_w23'][s[380990]], 'role': window['_w23'][s[380991]], 'level': window['_w23'][s[380992]], 'account': window['_w23'][s[380993]], 'version': window['_w23'][s[380954]], 'cdn': window['_w23'][s[380994]], 'pkgName': window['_w23'][s[380938]], 'gamever': window[s[380917]][s[380918]], 'serverid': window['_w23'][s[380944]] ? window['_w23'][s[380944]][s[380995]] : 0x0, 'systemInfo': window[s[380996]], 'error': s[380997], 'stack': $vyrxa ? $vyrxa : s[380989] },
      j1ez3f = JSON[s[380998]](thu850);console[s[380333]](s[380999] + j1ez3f), window['_wQ2'](j1ez3f);
}, window['_w2Q3'] = function (j1f3z) {
  var t08puh = JSON[s[380223]](j1f3z);t08puh[s[381000]] = window[s[380917]][s[380918]], t08puh[s[381001]] = window['_w23'][s[380944]] ? window['_w23'][s[380944]][s[380995]] : 0x0, t08puh[s[380996]] = window[s[380996]];var ydbk = JSON[s[380998]](t08puh);console[s[380333]](s[381002] + ydbk), window['_wQ2'](ydbk);
}, window['_w23Q'] = function (bg5k, dkc5gb) {
  var c58g0t = { 'id': window['_w23'][s[380990]], 'role': window['_w23'][s[380991]], 'level': window['_w23'][s[380992]], 'account': window['_w23'][s[380993]], 'version': window['_w23'][s[380954]], 'cdn': window['_w23'][s[380994]], 'pkgName': window['_w23'][s[380938]], 'gamever': window[s[380917]][s[380918]], 'serverid': window['_w23'][s[380944]] ? window['_w23'][s[380944]][s[380995]] : 0x0, 'systemInfo': window[s[380996]], 'error': bg5k, 'stack': dkc5gb },
      zfwj1 = JSON[s[380998]](c58g0t);console[s[380383]](s[381003] + zfwj1), window['_wQ2'](zfwj1);
}, window['_wQ2'] = function (kyradx) {
  if (window['_w23'][s[381004]] == s[381005]) return;var mqns4 = _w23['_wQ2'] + s[381006] + _w23[s[380993]];wx[s[381007]]({ 'url': mqns4, 'method': s[381008], 'data': kyradx, 'header': { 'content-type': s[381009], 'cache-control': s[381010] }, 'success': function (rdxy$a) {
      DEBUG && console[s[380225]](s[381011], mqns4, kyradx, rdxy$a);
    }, 'fail': function (uhqp) {
      DEBUG && console[s[380225]](s[381011], mqns4, kyradx, uhqp);
    }, 'complete': function () {} });
}, window[s[381012]] = function () {
  function htu6p() {
    return ((0x1 + Math[s[381013]]()) * 0x10000 | 0x0)[s[380060]](0x10)[s[380234]](0x1);
  }return htu6p() + htu6p() + '-' + htu6p() + '-' + htu6p() + '-' + htu6p() + '+' + htu6p() + htu6p() + htu6p();
}, window['_w2Q'] = function () {
  console[s[380225]](s[381014]);var wzfje1 = wya9v$x[s[381015]]();_w23[s[380943]] = wzfje1[s[381016]], _w23[s[380942]] = wzfje1[s[381016]], _w23[s[380937]] = wzfje1[s[381016]], _w23[s[380938]] = wzfje1[s[381017]];var t6p0h = { 'game_ver': _w23[s[380924]] };_w23[s[380939]] = this[s[381012]](), _wQ203({ 'title': s[381018] }), wya9v$x[s[381019]](t6p0h, this['_w3Q2'][s[380017]](this));
}, window['_w3Q2'] = function (phmq4) {
  var zf31ej = phmq4[s[381020]];console[s[380225]](s[381021] + zf31ej + s[381022] + (zf31ej == 0x1) + s[381023] + phmq4[s[380918]] + s[381024] + window[s[380916]][s[380925]]);if (!phmq4[s[380918]] || window['_wB03Q2'](window[s[380916]][s[380925]], phmq4[s[380918]]) < 0x0) console[s[380225]](s[381025]), _w23[s[380929]] = s[381026], _w23[s[380931]] = s[381027], _w23[s[380933]] = s[381028], _w23[s[380994]] = s[381029], _w23[s[381030]] = s[381031], _w23[s[381032]] = 'xh', _w23[s[380955]] = ![];else window['_wB03Q2'](window[s[380916]][s[380925]], phmq4[s[380918]]) == 0x0 ? (console[s[380225]](s[381033]), _w23[s[380929]] = s[380930], _w23[s[380931]] = s[380932], _w23[s[380933]] = s[380934], _w23[s[380994]] = s[381034], _w23[s[381030]] = s[381031], _w23[s[381032]] = s[381035], _w23[s[380955]] = !![]) : (console[s[380225]](s[381036]), _w23[s[380929]] = s[380930], _w23[s[380931]] = s[380932], _w23[s[380933]] = s[380934], _w23[s[380994]] = s[381034], _w23[s[381030]] = s[381031], _w23[s[381032]] = s[381035], _w23[s[380955]] = ![]);_w23[s[380940]] = config[s[380051]] ? config[s[380051]] : 0x0, this['_w02Q3'](), this['_w023Q'](), window[s[381037]] = 0x5, _wQ203({ 'title': s[381038] }), wya9v$x[s[381039]](this['_w32Q'][s[380017]](this));
}, window[s[381037]] = 0x5, window['_w32Q'] = function (mjsw, bgcdkr) {
  if (mjsw == 0x0 && bgcdkr && bgcdkr[s[380285]]) {
    _w23[s[381040]] = bgcdkr[s[380285]];var ofwje = this;_wQ203({ 'title': s[381041] }), sendApi(_w23[s[380929]], s[381042], { 'platform': _w23[s[380927]], 'partner_id': _w23[s[380937]], 'token': bgcdkr[s[380285]], 'game_pkg': _w23[s[380938]], 'deviceId': _w23[s[380939]], 'scene': s[381043] + _w23[s[380940]] }, this['_w0Q23'][s[380017]](this), _w032, _w3Q);
  } else bgcdkr && bgcdkr[s[381044]] && window[s[381037]] > 0x0 && (bgcdkr[s[381044]][s[380146]](s[381045]) != -0x1 || bgcdkr[s[381044]][s[380146]](s[381046]) != -0x1 || bgcdkr[s[381044]][s[380146]](s[381047]) != -0x1 || bgcdkr[s[381044]][s[380146]](s[381048]) != -0x1 || bgcdkr[s[381044]][s[380146]](s[381049]) != -0x1 || bgcdkr[s[381044]][s[380146]](s[381050]) != -0x1) ? (window[s[381037]]--, wya9v$x[s[381039]](this['_w32Q'][s[380017]](this))) : (window['_w23Q'](s[381051], JSON[s[380998]]({ 'status': mjsw, 'data': bgcdkr })), window['_wQ023'](s[381052] + (bgcdkr && bgcdkr[s[381044]] ? '，' + bgcdkr[s[381044]] : '')));
}, window['_w0Q23'] = function (dgxrb) {
  if (!dgxrb) {
    window['_w23Q'](s[381053], s[381054]), window['_wQ023'](s[381055]);return;
  }if (dgxrb[s[380980]] != s[381056]) {
    window['_w23Q'](s[381053], JSON[s[380998]](dgxrb)), window['_wQ023'](s[381057] + dgxrb[s[380980]]);return;
  }_w23[s[381058]] = String(dgxrb[s[380993]]), _w23[s[380993]] = String(dgxrb[s[380993]]), _w23[s[381059]] = String(dgxrb[s[381059]]), _w23[s[380943]] = String(dgxrb[s[381059]]), _w23[s[381060]] = String(dgxrb[s[381060]]), _w23[s[381061]] = String(dgxrb[s[381062]]), _w23[s[381063]] = String(dgxrb[s[381064]]), _w23[s[381062]] = '';var gcrdbk = this;_wQ203({ 'title': s[381065] }), sendApi(_w23[s[380929]], s[381066], { 'partner_id': _w23[s[380937]], 'uid': _w23[s[380993]], 'version': _w23[s[380924]], 'game_pkg': _w23[s[380938]], 'device': _w23[s[380939]] }, gcrdbk['_w0Q32'][s[380017]](gcrdbk), _w032, _w3Q);
}, window['_w0Q32'] = function (crgdkb) {
  if (!crgdkb) {
    window['_wQ023'](s[381067]);return;
  }if (crgdkb[s[380980]] != s[381056]) {
    window['_wQ023'](s[381068] + crgdkb[s[380980]]);return;
  }if (!crgdkb[s[380335]] || crgdkb[s[380335]][s[380031]] == 0x0) {
    window['_wQ023'](s[381069]);return;
  }_w23[s[381070]] = crgdkb[s[381071]], _w23[s[380944]] = { 'server_id': String(crgdkb[s[380335]][0x0][s[380995]]), 'server_name': String(crgdkb[s[380335]][0x0][s[381072]]), 'entry_ip': crgdkb[s[380335]][0x0][s[381073]], 'entry_port': parseInt(crgdkb[s[380335]][0x0][s[381074]]), 'status': _w20Q(crgdkb[s[380335]][0x0]), 'start_time': crgdkb[s[380335]][0x0][s[381075]], 'cdn': _w23[s[380994]] }, this['_w320Q']();
}, window['_w320Q'] = function () {
  if (_w23[s[381070]] == 0x1) {
    var ejzn = _w23[s[380944]][s[381076]];if (ejzn === -0x1 || ejzn === 0x0) {
      window['_wQ023'](ejzn === -0x1 ? s[381077] : s[381078]);return;
    }_w3Q02(0x0, _w23[s[380944]][s[380995]]), window[s[380977]][s[380978]][s[381079]](_w23[s[381070]]);
  } else window[s[380977]][s[380978]][s[381080]](), _wQ230();window['_w20'] = !![], window['_w302Q'](), window['_w32Q0']();
}, window['_w02Q3'] = function () {
  sendApi(_w23[s[380929]], s[381081], { 'game_pkg': _w23[s[380938]], 'version_name': _w23[s[381032]] }, this[s[381082]][s[380017]](this), _w032, _w3Q);
}, window[s[381082]] = function (ej31z) {
  if (!ej31z) {
    window['_wQ023'](s[381083]);return;
  }if (ej31z[s[380980]] != s[381056]) {
    window['_wQ023'](s[381084] + ej31z[s[380980]]);return;
  }if (!ej31z[s[380335]] || !ej31z[s[380335]][s[380924]]) {
    window['_wQ023'](s[381085] + (ej31z[s[380335]] && ej31z[s[380335]][s[380924]]));return;
  }ej31z[s[380335]][s[381086]] && ej31z[s[380335]][s[381086]][s[380031]] > 0xa && (_w23[s[381087]] = ej31z[s[380335]][s[381086]], _w23[s[380994]] = ej31z[s[380335]][s[381086]]), ej31z[s[380335]][s[380924]] && (_w23[s[380954]] = ej31z[s[380335]][s[380924]]), console[s[380981]](s[381088] + _w23[s[380954]] + s[381089] + _w23[s[381032]]), window['_w230'] = !![], window['_w302Q'](), window['_w32Q0']();
}, window[s[381090]], window['_w023Q'] = function () {
  sendApi(_w23[s[380929]], s[381091], { 'game_pkg': _w23[s[380938]] }, this['_w03Q2'][s[380017]](this), _w032, _w3Q);
}, window['_w03Q2'] = function (_lv$) {
  if (_lv$[s[380980]] === s[381056] && _lv$[s[380335]]) {
    window[s[381090]] = _lv$[s[380335]];for (var uh06p in _lv$[s[380335]]) {
      _w23[uh06p] = _lv$[s[380335]][uh06p];
    }
  } else console[s[380981]](s[381092] + _lv$[s[380980]]);window['_w02'] = !![], window['_w32Q0']();
}, window[s[381093]] = function (y9l$va, g8kb5, dcbkr, nmosjw, gd5, mnwqos, wzf1, fnej, h60t) {
  gd5 = String(gd5);var y$r = wzf1,
      yxv9$a = fnej;_w23[s[380923]][gd5] = { 'productid': gd5, 'productname': y$r, 'productdesc': yxv9$a, 'roleid': y9l$va, 'rolename': g8kb5, 'rolelevel': dcbkr, 'price': mnwqos, 'callback': h60t }, sendApi(_w23[s[380933]], s[381094], { 'game_pkg': _w23[s[380938]], 'server_id': _w23[s[380944]][s[380995]], 'server_name': _w23[s[380944]][s[381072]], 'level': dcbkr, 'uid': _w23[s[380993]], 'role_id': y9l$va, 'role_name': g8kb5, 'product_id': gd5, 'product_name': y$r, 'product_desc': yxv9$a, 'money': mnwqos, 'partner_id': _w23[s[380937]] }, toPayCallBack, _w032, _w3Q);
}, window[s[381095]] = function (v$ry) {
  if (v$ry) {
    if (v$ry[s[381096]] === 0xc8 || v$ry[s[380980]] == s[381056]) {
      var p46qh = _w23[s[380923]][String(v$ry[s[381097]])];if (p46qh[s[381098]]) p46qh[s[381098]](v$ry[s[381097]], v$ry[s[381099]], -0x1);wya9v$x[s[381100]]({ 'cpbill': v$ry[s[381099]], 'productid': v$ry[s[381097]], 'productname': p46qh[s[381101]], 'productdesc': p46qh[s[381102]], 'serverid': _w23[s[380944]][s[380995]], 'servername': _w23[s[380944]][s[381072]], 'roleid': p46qh[s[381103]], 'rolename': p46qh[s[381104]], 'rolelevel': p46qh[s[381105]], 'price': p46qh[s[381106]], 'extension': JSON[s[380998]]({ 'cp_order_id': v$ry[s[381099]] }) }, function (mq46so, gkcbrd) {
        p46qh[s[381098]] && mq46so == 0x0 && p46qh[s[381098]](v$ry[s[381097]], v$ry[s[381099]], mq46so);console[s[380981]](JSON[s[380998]]({ 'type': s[381107], 'status': mq46so, 'data': v$ry, 'role_name': p46qh[s[381104]] }));if (mq46so === 0x0) {} else {
          if (mq46so === 0x1) {} else {
            if (mq46so === 0x2) {}
          }
        }
      });
    } else alert(v$ry[s[380981]]);
  }
}, window['_w032Q'] = function () {}, window['_wQ03'] = function (yxva, m6h4p, nwmojs, fewjno, t0h5u) {
  wya9v$x[s[381108]](_w23[s[380944]][s[380995]], _w23[s[380944]][s[381072]] || _w23[s[380944]][s[380995]], yxva, m6h4p, nwmojs), sendApi(_w23[s[380929]], s[381109], { 'game_pkg': _w23[s[380938]], 'server_id': _w23[s[380944]][s[380995]], 'role_id': yxva, 'uid': _w23[s[380993]], 'role_name': m6h4p, 'role_type': fewjno, 'level': nwmojs });
}, window['_wQ30'] = function ($y9xva, rxkgd, bxgd, u6thp4, s64p, ck8gb5, bkgc5, vy9a, u0t6, $aryxd) {
  _w23[s[380990]] = $y9xva, _w23[s[380991]] = rxkgd, _w23[s[380992]] = bxgd, wya9v$x[s[381110]](_w23[s[380944]][s[380995]], _w23[s[380944]][s[381072]] || _w23[s[380944]][s[380995]], $y9xva, rxkgd, bxgd), sendApi(_w23[s[380929]], s[381111], { 'game_pkg': _w23[s[380938]], 'server_id': _w23[s[380944]][s[380995]], 'role_id': $y9xva, 'uid': _w23[s[380993]], 'role_name': rxkgd, 'role_type': u6thp4, 'level': bxgd, 'evolution': s64p });
}, window['_w0Q3'] = function (wsjfn, kcd5bg, z13jfe, ckgbd, bkgrdx, njzw, xrykd, u85c, f3z1, u85t) {
  _w23[s[380990]] = wsjfn, _w23[s[380991]] = kcd5bg, _w23[s[380992]] = z13jfe, wya9v$x[s[381112]](_w23[s[380944]][s[380995]], _w23[s[380944]][s[381072]] || _w23[s[380944]][s[380995]], wsjfn, kcd5bg, z13jfe), sendApi(_w23[s[380929]], s[381111], { 'game_pkg': _w23[s[380938]], 'server_id': _w23[s[380944]][s[380995]], 'role_id': wsjfn, 'uid': _w23[s[380993]], 'role_name': kcd5bg, 'role_type': ckgbd, 'level': z13jfe, 'evolution': bkgrdx });
}, window['_w03Q'] = function (ph8ut0) {}, window['_wQ0'] = function (h8p0u) {
  wya9v$x[s[381113]](s[381113], function (sojwn) {
    h8p0u && h8p0u(sojwn);
  });
}, window[s[381114]] = function () {
  wya9v$x[s[381114]]();
}, window[s[381115]] = function () {
  wya9v$x[s[381116]]();
}, window[s[381117]] = function (zfe32) {
  window['_w3Q0'] = zfe32, window['_w3Q0'] && window['_w0Q'] && (console[s[380981]](s[381118] + window['_w0Q'][s[381119]]), window['_w3Q0'](window['_w0Q']), window['_w0Q'] = null);
}, window['_w30Q'] = function (yrdkx, fjnzw, m4sp, kgc) {
  window[s[381120]](s[381121], { 'game_pkg': window['_w23'][s[380938]], 'role_id': fjnzw, 'server_id': m4sp }, kgc);
}, window['_w2Q03'] = function (om4q, la$v9_) {
  function yvar$x(nfejwo) {
    var dbck5g = [],
        ax$ryd = [],
        pm4q6 = window[s[380917]][s[381122]];for (var t80gc5 in pm4q6) {
      var cgbk = Number(t80gc5);(!om4q || !om4q[s[380031]] || om4q[s[380146]](cgbk) != -0x1) && (ax$ryd[s[380066]](pm4q6[t80gc5]), dbck5g[s[380066]]([cgbk, 0x3]));
    }window['_wB03Q2'](window[s[381123]], s[381124]) >= 0x0 ? (console[s[380225]](s[381125]), wya9v$x[s[381126]] && wya9v$x[s[381126]](ax$ryd, function (smwon) {
      console[s[380225]](s[381127]), console[s[380225]](smwon);if (smwon && smwon[s[381044]] == s[381128]) for (var u6qh in pm4q6) {
        if (smwon[pm4q6[u6qh]] == s[381129]) {
          var gckdbr = Number(u6qh);for (var nowfe = 0x0; nowfe < dbck5g[s[380031]]; nowfe++) {
            if (dbck5g[nowfe][0x0] == gckdbr) {
              dbck5g[nowfe][0x1] = 0x1;break;
            }
          }
        }
      }window['_wB03Q2'](window[s[381123]], s[381130]) >= 0x0 ? wx[s[381131]]({ 'withSubscriptions': !![], 'success': function (wonqsm) {
          var mspq = wonqsm[s[381132]][s[381133]];if (mspq) {
            console[s[380225]](s[381134]), console[s[380225]](mspq);for (var q4mso in pm4q6) {
              if (mspq[pm4q6[q4mso]] == s[381129]) {
                var v$ay9 = Number(q4mso);for (var gc58kb = 0x0; gc58kb < dbck5g[s[380031]]; gc58kb++) {
                  if (dbck5g[gc58kb][0x0] == v$ay9) {
                    dbck5g[gc58kb][0x1] = 0x2;break;
                  }
                }
              }
            }console[s[380225]](dbck5g), la$v9_ && la$v9_(dbck5g);
          } else console[s[380225]](s[381135]), console[s[380225]](wonqsm), console[s[380225]](dbck5g), la$v9_ && la$v9_(dbck5g);
        }, 'fail': function () {
          console[s[380225]](s[381136]), console[s[380225]](dbck5g), la$v9_ && la$v9_(dbck5g);
        } }) : (console[s[380225]](s[381137] + window[s[381123]]), console[s[380225]](dbck5g), la$v9_ && la$v9_(dbck5g));
    })) : (console[s[380225]](s[381138] + window[s[381123]]), console[s[380225]](dbck5g), la$v9_ && la$v9_(dbck5g)), wx[s[381139]](yvar$x);
  }wx[s[381140]](yvar$x);
}, window['_w2Q30'] = { 'isSuccess': ![], 'level': s[381141], 'isCharging': ![] }, window['_w20Q3'] = function (phu64) {
  wx[s[381142]]({ 'success': function (jownm) {
      var mnq4so = window['_w2Q30'];mnq4so[s[381143]] = !![], mnq4so[s[381144]] = Number(jownm[s[381144]])[s[381145]](0x0), mnq4so[s[381146]] = jownm[s[381146]], phu64 && phu64(mnq4so[s[381143]], mnq4so[s[381144]], mnq4so[s[381146]]);
    }, 'fail': function (_9l$av) {
      console[s[380225]](s[381147], _9l$av[s[381044]]);var tcu805 = window['_w2Q30'];phu64 && phu64(tcu805[s[381143]], tcu805[s[381144]], tcu805[s[381146]]);
    } });
}, window[s[381120]] = function (ht08u5, k8c5g, f3ze2, dbryxk, swfojn, aydxkr, wj1ezf, l_$9va) {
  if (dbryxk == undefined) dbryxk = 0x1;wx[s[381007]]({ 'url': ht08u5, 'method': wj1ezf || s[381148], 'responseType': s[381149], 'data': k8c5g, 'header': { 'content-type': l_$9va || s[381009] }, 'success': function (iz327) {
      DEBUG && console[s[380225]](s[381150], ht08u5, info, iz327);if (iz327 && iz327[s[381151]] == 0xc8) {
        var w1jezf = iz327[s[380335]];!aydxkr || aydxkr(w1jezf) ? f3ze2 && f3ze2(w1jezf) : window[s[381152]](ht08u5, k8c5g, f3ze2, dbryxk, swfojn, aydxkr, iz327);
      } else window[s[381152]](ht08u5, k8c5g, f3ze2, dbryxk, swfojn, aydxkr, iz327);
    }, 'fail': function (i37z1) {
      DEBUG && console[s[380225]](s[381153], ht08u5, info, i37z1), window[s[381152]](ht08u5, k8c5g, f3ze2, dbryxk, swfojn, aydxkr, i37z1);
    }, 'complete': function () {} });
}, window[s[381152]] = function (ejnfo, g5c0, dbrxy, pt80u, dxkry, h4tup, zi1237) {
  pt80u - 0x1 > 0x0 ? setTimeout(function () {
    window[s[381120]](ejnfo, g5c0, dbrxy, pt80u - 0x1, dxkry, h4tup);
  }, 0x3e8) : dxkry && dxkry(JSON[s[380998]]({ 'url': ejnfo, 'response': zi1237 }));
}, window[s[381154]] = function (wznf, h0pt6, e173z2, zfnejw, xad$, xrby, vx) {
  !e173z2 && (e173z2 = {});var zf1je = Math[s[380071]](Date[s[380950]]() / 0x3e8);e173z2[s[381064]] = zf1je, e173z2[s[381155]] = h0pt6;var akxdr = Object[s[380030]](e173z2)[s[380382]](),
      jwz1ef = '',
      kgxdr = '';for (var rbcgdk = 0x0; rbcgdk < akxdr[s[380031]]; rbcgdk++) {
    jwz1ef = jwz1ef + (rbcgdk == 0x0 ? '' : '&') + akxdr[rbcgdk] + e173z2[akxdr[rbcgdk]], kgxdr = kgxdr + (rbcgdk == 0x0 ? '' : '&') + akxdr[rbcgdk] + '=' + encodeURIComponent(e173z2[akxdr[rbcgdk]]);
  }jwz1ef = jwz1ef + _w23[s[380935]];var ef21 = s[381156] + md5(jwz1ef);send(wznf + '?' + kgxdr + (kgxdr == '' ? '' : '&') + ef21, null, zfnejw, xad$, xrby, vx || function (wmonqs) {
    return wmonqs[s[380980]] == s[381056];
  }, null, s[381157]);
}, window['_w203Q'] = function (l$_, k5b8g) {
  var owje = 0x0;_w23[s[380944]] && (owje = _w23[s[380944]][s[380995]]), sendApi(_w23[s[380931]], s[381158], { 'partnerId': _w23[s[380937]], 'gamePkg': _w23[s[380938]], 'logTime': Math[s[380071]](Date[s[380950]]() / 0x3e8), 'platformUid': _w23[s[381060]], 'type': l$_, 'serverId': owje }, null, 0x2, null, function () {
    return !![];
  });
}, window['_w23Q0'] = function (crgbdk) {
  sendApi(_w23[s[380929]], s[381159], { 'partner_id': _w23[s[380937]], 'uid': _w23[s[380993]], 'version': _w23[s[380924]], 'game_pkg': _w23[s[380938]], 'device': _w23[s[380939]] }, _w230Q, _w032, _w3Q);
}, window['_w230Q'] = function (fe1zjw) {
  if (fe1zjw[s[380980]] === s[381056] && fe1zjw[s[380335]]) {
    fe1zjw[s[380335]][s[380174]]({ 'id': -0x2, 'name': s[381160] }), fe1zjw[s[380335]][s[380174]]({ 'id': -0x1, 'name': s[381161] }), _w23[s[381162]] = fe1zjw[s[380335]];if (window[s[381163]]) window[s[381163]][s[381164]]();
  } else _w23[s[381165]] = ![], window['_wQ023'](s[381166] + fe1zjw[s[380980]]);
}, window['_wQ02'] = function (gkdrxb) {
  sendApi(_w23[s[380929]], s[381167], { 'partner_id': _w23[s[380937]], 'uid': _w23[s[380993]], 'version': _w23[s[380924]], 'game_pkg': _w23[s[380938]], 'device': _w23[s[380939]] }, _wQ20, _w032, _w3Q);
}, window['_wQ20'] = function (p4s6qm) {
  _w23[s[381168]] = ![];if (p4s6qm[s[380980]] === s[381056] && p4s6qm[s[380335]]) {
    for (var snqmwo = 0x0; snqmwo < p4s6qm[s[380335]][s[380031]]; snqmwo++) {
      p4s6qm[s[380335]][snqmwo][s[381076]] = _w20Q(p4s6qm[s[380335]][snqmwo]);
    }_w23[s[380941]][-0x1] = window[s[381169]](p4s6qm[s[380335]]), window[s[381163]][s[381170]](-0x1);
  } else window['_wQ023'](s[381171] + p4s6qm[s[380980]]);
}, window[s[381172]] = function ($la9v_) {
  sendApi(_w23[s[380929]], s[381167], { 'partner_id': _w23[s[380937]], 'uid': _w23[s[380993]], 'version': _w23[s[380924]], 'game_pkg': _w23[s[380938]], 'device': _w23[s[380939]] }, $la9v_, _w032, _w3Q);
}, window['_w0Q2'] = function (c05g8, nsjom) {
  sendApi(_w23[s[380929]], s[381173], { 'partner_id': _w23[s[380937]], 'uid': _w23[s[380993]], 'version': _w23[s[380924]], 'game_pkg': _w23[s[380938]], 'device': _w23[s[380939]], 'server_group_id': nsjom }, _w02Q, _w032, _w3Q);
}, window['_w02Q'] = function (kxbdry) {
  _w23[s[381168]] = ![];if (kxbdry[s[380980]] === s[381056] && kxbdry[s[380335]] && kxbdry[s[380335]][s[380335]]) {
    var ms6q4p = kxbdry[s[380335]][s[381174]],
        cg85k = [];for (var cd5kb = 0x0; cd5kb < kxbdry[s[380335]][s[380335]][s[380031]]; cd5kb++) {
      kxbdry[s[380335]][s[380335]][cd5kb][s[381076]] = _w20Q(kxbdry[s[380335]][s[380335]][cd5kb]), (cg85k[s[380031]] == 0x0 || kxbdry[s[380335]][s[380335]][cd5kb][s[381076]] != 0x0) && (cg85k[cg85k[s[380031]]] = kxbdry[s[380335]][s[380335]][cd5kb]);
    }_w23[s[380941]][ms6q4p] = window[s[381169]](cg85k), window[s[381163]][s[381170]](ms6q4p);
  } else window['_wQ023'](s[381175] + kxbdry[s[380980]]);
}, window['_wB032'] = function (ry$vax) {
  sendApi(_w23[s[380929]], s[381176], { 'partner_id': _w23[s[380937]], 'uid': _w23[s[380993]], 'version': _w23[s[380924]], 'game_pkg': _w23[s[380938]], 'device': _w23[s[380939]] }, reqServerRecommendCallBack, _w032, _w3Q);
}, window[s[381177]] = function (e31z27) {
  _w23[s[381168]] = ![];if (e31z27[s[380980]] === s[381056] && e31z27[s[380335]]) {
    for (var dkxary = 0x0; dkxary < e31z27[s[380335]][s[380031]]; dkxary++) {
      e31z27[s[380335]][dkxary][s[381076]] = _w20Q(e31z27[s[380335]][dkxary]);
    }_w23[s[380941]][-0x2] = window[s[381169]](e31z27[s[380335]]), window[s[381163]][s[381170]](-0x2);
  } else alert(s[381178] + e31z27[s[380980]]);
}, window[s[381169]] = function (t8g) {
  if (!t8g && t8g[s[380031]] <= 0x0) return t8g;for (let xkdyar = 0x0; xkdyar < t8g[s[380031]]; xkdyar++) {
    t8g[xkdyar][s[381179]] && t8g[xkdyar][s[381179]] == 0x1 && (t8g[xkdyar][s[381072]] += s[381180]);
  }return t8g;
}, window['_w2Q0'] = function (nmoswj, hpu80t) {
  nmoswj = nmoswj || _w23[s[380944]][s[380995]], sendApi(_w23[s[380929]], s[381181], { 'type': '4', 'game_pkg': _w23[s[380938]], 'server_id': nmoswj }, hpu80t);
}, window[s[381182]] = function (fenzw, drgxb, yakdxr, w1jzf) {
  yakdxr = yakdxr || _w23[s[380944]][s[380995]], sendApi(_w23[s[380929]], s[381183], { 'type': fenzw, 'game_pkg': drgxb, 'server_id': yakdxr }, w1jzf);
}, window['_w20Q'] = function (z2i13) {
  if (z2i13) {
    if (z2i13[s[381076]] == 0x1) {
      if (z2i13[s[381184]] == 0x1) return 0x2;else return 0x1;
    } else return z2i13[s[381076]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_w3Q02'] = function (ofjnw, moq4ns) {
  _w23[s[381185]] = { 'step': ofjnw, 'server_id': moq4ns };var q4mnos = this;_wQ203({ 'title': s[381186] }), sendApi(_w23[s[380929]], s[381187], { 'partner_id': _w23[s[380937]], 'uid': _w23[s[380993]], 'game_pkg': _w23[s[380938]], 'server_id': moq4ns, 'platform': _w23[s[381059]], 'platform_uid': _w23[s[381060]], 'check_login_time': _w23[s[381063]], 'check_login_sign': _w23[s[381061]], 'version_name': _w23[s[381032]] }, _w3Q20, _w032, _w3Q, function (vrxa) {
    return vrxa[s[380980]] == s[381056] || vrxa[s[380981]] == s[381188] || vrxa[s[380981]] == s[381189];
  });
}, window['_w3Q20'] = function (fsonw) {
  var ya$v9l = this;if (fsonw[s[380980]] === s[381056] && fsonw[s[380335]]) {
    var qu6p = _w23[s[380944]];qu6p[s[381190]] = _w23[s[380942]], qu6p[s[381062]] = String(fsonw[s[380335]][s[381191]]), qu6p[s[380949]] = parseInt(fsonw[s[380335]][s[381064]]);if (fsonw[s[380335]][s[381192]]) qu6p[s[381192]] = parseInt(fsonw[s[380335]][s[381192]]);else qu6p[s[381192]] = parseInt(fsonw[s[380335]][s[380995]]);qu6p[s[381193]] = 0x0, qu6p[s[380994]] = _w23[s[381087]], qu6p[s[381194]] = fsonw[s[380335]][s[381195]], qu6p[s[381196]] = fsonw[s[380335]][s[381196]], console[s[380225]](s[381197] + JSON[s[380998]](qu6p[s[381196]])), _w23[s[381070]] == 0x1 && qu6p[s[381196]] && qu6p[s[381196]][s[381198]] == 0x1 && (_w23[s[381199]] = 0x1, window[s[380977]][s[380978]]['_wB32']()), _w30Q2();
  } else _w23[s[381185]][s[381200]] >= 0x3 ? (_w3Q(JSON[s[380998]](fsonw)), window['_wQ023'](s[381201] + fsonw[s[380980]])) : sendApi(_w23[s[380929]], s[381042], { 'platform': _w23[s[380927]], 'partner_id': _w23[s[380937]], 'token': _w23[s[381040]], 'game_pkg': _w23[s[380938]], 'deviceId': _w23[s[380939]], 'scene': s[381043] + _w23[s[380940]] }, function (bkrgdc) {
    if (!bkrgdc || bkrgdc[s[380980]] != s[381056]) {
      window['_wQ023'](s[381057] + bkrgdc && bkrgdc[s[380980]]);return;
    }_w23[s[381061]] = String(bkrgdc[s[381062]]), _w23[s[381063]] = String(bkrgdc[s[381064]]), setTimeout(function () {
      _w3Q02(_w23[s[381185]][s[381200]] + 0x1, _w23[s[381185]][s[380995]]);
    }, 0x5dc);
  }, _w032, _w3Q, function (rakxd) {
    return rakxd[s[380980]] == s[381056] || rakxd[s[380980]] == s[381202];
  });
}, window['_w30Q2'] = function () {
  ServerLoading[s[380978]][s[381079]](_w23[s[381070]]), window['_w03'] = !![], window['_w32Q0']();
}, window['_w302Q'] = function () {
  if (window['_w30'] && window['_w203'] && window[s[380959]] && window[s[380960]] && window['_w230'] && window['_w20']) {
    if (!window[s[381203]][s[380978]]) {
      console[s[380225]](s[381204] + window[s[381203]][s[380978]]);var ryd$xa = wx[s[381205]](),
          vyla = ryd$xa[s[381119]] ? ryd$xa[s[381119]] : 0x0,
          zfnwje = { 'cdn': window['_w23'][s[380994]], 'spareCdn': window['_w23'][s[381030]], 'newRegister': window['_w23'][s[381070]], 'wxPC': window['_w23'][s[380958]], 'wxIOS': window['_w23'][s[380956]], 'wxAndroid': window['_w23'][s[380957]], 'wxParam': { 'limitLoad': window['_w23']['_wBQ032'], 'benchmarkLevel': window['_w23']['_wBQ203'], 'wxFrom': window[s[380917]][s[380051]] == s[381206] ? 0x1 : 0x0, 'wxSDKVersion': window[s[381123]] }, 'configType': window['_w23'][s[380951]], 'exposeType': window['_w23'][s[380952]], 'scene': vyla };new window[s[381203]](zfnwje, window['_w23'][s[380954]], window['_wBQ023']);
    }
  }
}, window['_w32Q0'] = function () {
  if (window['_w30'] && window['_w203'] && window[s[380959]] && window[s[380960]] && window['_w230'] && window['_w20'] && window['_w03'] && window['_w02']) {
    _wQ230();if (!_w302) {
      _w302 = !![];if (!window[s[381203]][s[380978]]) window['_w302Q']();var wnqm = 0x0,
          f1e2 = wx[s[381207]]();f1e2 && (window['_w23'][s[381208]] && (wnqm = f1e2[s[381209]]), console[s[380981]](s[381210] + f1e2[s[381209]] + s[381211] + f1e2[s[381212]] + s[381213] + f1e2[s[381214]] + s[381215] + f1e2[s[381216]] + s[381217] + f1e2[s[381218]] + s[381219] + f1e2[s[381220]]));var bdxk = {};for (const $vlay9 in _w23[s[380944]]) {
        bdxk[$vlay9] = _w23[s[380944]][$vlay9];
      }var drbkgc = { 'channel': window['_w23'][s[380943]], 'account': window['_w23'][s[380993]], 'userId': window['_w23'][s[381058]], 'cdn': window['_w23'][s[380994]], 'data': window['_w23'][s[380335]], 'package': window['_w23'][s[380304]], 'newRegister': window['_w23'][s[381070]], 'pkgName': window['_w23'][s[380938]], 'partnerId': window['_w23'][s[380937]], 'platform_uid': window['_w23'][s[381060]], 'deviceId': window['_w23'][s[380939]], 'selectedServer': bdxk, 'configType': window['_w23'][s[380951]], 'exposeType': window['_w23'][s[380952]], 'debugUsers': window['_w23'][s[380947]], 'wxMenuTop': wnqm, 'wxShield': window['_w23'][s[380955]] };if (window[s[381090]]) for (var x$avyr in window[s[381090]]) {
        drbkgc[x$avyr] = window[s[381090]][x$avyr];
      }window[s[381203]][s[380978]]['_w0B23'](drbkgc), setTimeout(() => {
        wya9v$x[s[381221]]();
      }, 0x2710);
    }
  } else console[s[380981]](s[381222] + window['_w30'] + s[381223] + window['_w203'] + s[381224] + window[s[380959]] + s[381225] + window[s[380960]] + s[381226] + window['_w230'] + s[381227] + window['_w20'] + s[381228] + window['_w03'] + s[381229] + window['_w02']);
};