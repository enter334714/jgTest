module.exports.APP_VERSION = "0.0.3"; // 填写小程序版本 不能为空


module.exports.APP_ID = "wx707bce3bbf832771"; //  必填 填写微信appid  wx00000000000 微信开放后台获取 不可为空
module.exports.GAMEKEY = "IrVXnpyYUQoqNnwo";
module.exports.DEBUG = true; // 是否有log
module.exports.MIDAS_PAY_USABLE = true; // 官方虚拟支付是否可用
module.exports.USE_BIND_ACCOUNT = false; // 是否使用迁移来的绑定账号
module.exports.DOMAIN_NAME = "gztyhd.top"; // 域名