var s = wx.$W;
console[s[380981]](s[381230]), window[s[381231]], wx[s[381232]](function (ut08h) {
  if (ut08h) {
    if (ut08h[s[380056]]) {
      var adkyxr = window[s[380917]][s[380918]][s[380243]](new RegExp(/\./, 'g'), '_'),
          onqms = ut08h[s[380056]],
          p4hm = onqms[s[380067]](/(wwwwwwwww\/WWGAMEW.js:)[0-9]{1,60}(:)/g);if (p4hm) for (var hm64qp = 0x0; hm64qp < p4hm[s[380031]]; hm64qp++) {
        if (p4hm[hm64qp] && p4hm[hm64qp][s[380031]] > 0x0) {
          var g058 = parseInt(p4hm[hm64qp][s[380243]](s[381233], '')[s[380243]](':', ''));onqms = onqms[s[380243]](p4hm[hm64qp], p4hm[hm64qp][s[380243]](':' + g058 + ':', ':' + (g058 - 0x2) + ':'));
        }
      }onqms = onqms[s[380243]](new RegExp(s[381234], 'g'), s[381235] + adkyxr + s[381236]), onqms = onqms[s[380243]](new RegExp(s[381237], 'g'), s[381235] + adkyxr + s[381236]), ut08h[s[380056]] = onqms;
    }var ya$l = { 'id': window['_w23'][s[380990]], 'role': window['_w23'][s[380991]], 'level': window['_w23'][s[380992]], 'user': window['_w23'][s[380993]], 'version': window['_w23'][s[380954]], 'cdn': window['_w23'][s[380994]], 'pkgName': window['_w23'][s[380938]], 'gamever': window[s[380917]][s[380918]], 'serverid': window['_w23'][s[380944]] ? window['_w23'][s[380944]][s[380995]] : 0x0, 'systemInfo': window[s[380996]], 'error': s[381238], 'stack': ut08h ? ut08h[s[380056]] : '' },
        p0h6tu = JSON[s[380998]](ya$l);console[s[380333]](s[381239] + p0h6tu), (!window[s[381231]] || window[s[381231]] != ya$l[s[380333]]) && (window[s[381231]] = ya$l[s[380333]], window['_wQ2'](ya$l));
  }
});import 'wwfww.js';import 'ww11ww.js';window[s[381240]] = require(s[381241]);import 'wINDww.js';import 'wwIB1ww.js';import 'wwMtadww.js';import 'wwINIwww.js';import 'utils/cxui.laya.js';console[s[380981]](s[381242]), console[s[380981]](s[381243]), _wQ203({ 'title': s[381244] });var wu4h6qp = { '_wBQ320': !![] };new window[s[380977]](wu4h6qp), window[s[380977]][s[380978]]['_wB023Q']();if (window['_wBQ230']) clearInterval(window['_wBQ230']);window['_wBQ230'] = null, window['_wB03Q2'] = function (msnjwo, byk) {
  if (!msnjwo || !byk) return 0x0;msnjwo = msnjwo[s[380201]]('.'), byk = byk[s[380201]]('.');const y$axvr = Math[s[380301]](msnjwo[s[380031]], byk[s[380031]]);while (msnjwo[s[380031]] < y$axvr) {
    msnjwo[s[380066]]('0');
  }while (byk[s[380031]] < y$axvr) {
    byk[s[380066]]('0');
  }for (var rxgbd = 0x0; rxgbd < y$axvr; rxgbd++) {
    const wnfze = parseInt(msnjwo[rxgbd]),
          wsojf = parseInt(byk[rxgbd]);if (wnfze > wsojf) return 0x1;else {
      if (wnfze < wsojf) return -0x1;
    }
  }return 0x0;
}, window[s[381123]] = wx[s[381245]]()[s[381123]], console[s[380225]](s[381246] + window[s[381123]]);var wjfwns = wx[s[381247]]();wjfwns[s[381248]](function (gb5k8) {
  console[s[380225]](s[381249] + gb5k8[s[381250]]);
}), wjfwns[s[381251]](function () {
  wx[s[380963]]({ 'title': s[381252], 'content': s[381253], 'showCancel': ![], 'success': function (ezfj1w) {
      wjfwns[s[381254]]();
    } });
}), wjfwns[s[381255]](function () {
  console[s[380225]](s[381256]);
}), window['_wB032Q'] = function () {
  console[s[380225]](s[381257]);var wofjne = wx[s[381258]]({ 'name': s[381259], 'success': function (smwq) {
      console[s[380225]](s[381260]), console[s[380225]](smwq), smwq && smwq[s[381044]] == s[381261] ? (window['_w30'] = !![], window['_w302Q'](), window['_w32Q0']()) : setTimeout(function () {
        window['_wB032Q']();
      }, 0x1f4);
    }, 'fail': function (wjnfe) {
      console[s[380225]](s[381262]), console[s[380225]](wjnfe), setTimeout(function () {
        window['_wB032Q']();
      }, 0x1f4);
    } });wofjne && wofjne[s[381263]](i3127z => {});
}, window['_wB2Q30'] = function () {
  console[s[380225]](s[381264]);var up0t8h = wx[s[381258]]({ 'name': s[381265], 'success': function (e21z3) {
      console[s[380225]](s[381266]), console[s[380225]](e21z3), e21z3 && e21z3[s[381044]] == s[381261] ? (window['_w203'] = !![], window['_w302Q'](), window['_w32Q0']()) : setTimeout(function () {
        window['_wB2Q30']();
      }, 0x1f4);
    }, 'fail': function (t4p6h) {
      console[s[380225]](s[381267]), console[s[380225]](t4p6h), setTimeout(function () {
        window['_wB2Q30']();
      }, 0x1f4);
    } });up0t8h && up0t8h[s[381263]](a$xydr => {});
}, window[s[381268]] = function () {
  window['_wB03Q2'](window[s[381123]], s[381269]) >= 0x0 ? (console[s[380225]](s[381270] + window[s[381123]] + s[381271]), window['_w2Q'](), window['_wB032Q'](), window['_wB2Q30']()) : (window['_w23Q'](s[381272], window[s[381123]]), wx[s[380963]]({ 'title': s[380964], 'content': s[381273] }));
}, window[s[380996]] = '', wx[s[381274]]({ 'success'(vyxr$) {
    window[s[380996]] = s[381275] + vyxr$[s[381276]] + s[381277] + vyxr$[s[381278]] + s[381279] + vyxr$[s[380924]] + s[381280] + vyxr$[s[381281]] + s[381282] + vyxr$[s[381059]] + s[381283] + vyxr$[s[381123]] + s[381284] + vyxr$[s[381285]], console[s[380225]](window[s[380996]]), console[s[380225]](s[381286] + vyxr$[s[381287]] + s[381288] + vyxr$[s[381289]] + s[381290] + vyxr$[s[381291]] + s[381292] + vyxr$[s[381293]] + s[381294] + vyxr$[s[381295]] + s[381296] + vyxr$[s[381297]] + s[381298] + (vyxr$[s[381299]] ? vyxr$[s[381299]][s[381209]] + ',' + vyxr$[s[381299]][s[381212]] + ',' + vyxr$[s[381299]][s[381214]] + ',' + vyxr$[s[381299]][s[381216]] : ''));var nwmsj = vyxr$[s[381281]] ? vyxr$[s[381281]][s[380103]]() : '',
        u8t0h = vyxr$[s[381278]] ? vyxr$[s[381278]][s[380103]]()[s[380243]]('\x20', '') : '';window['_w23'][s[380956]] = nwmsj[s[380146]](s[381300]) != -0x1, window['_w23'][s[380957]] = nwmsj[s[380146]](s[381301]) != -0x1, window['_w23'][s[381208]] = nwmsj[s[380146]](s[381300]) != -0x1 || nwmsj[s[380146]](s[381301]) != -0x1, window['_w23'][s[380958]] = nwmsj[s[380146]](s[381302]) != -0x1 || nwmsj[s[380146]](s[380926]) != -0x1, window['_w23'][s[381004]] = vyxr$[s[381059]] ? vyxr$[s[381059]][s[380103]]() : '', window['_w23']['_wBQ032'] = ![], window['_w23']['_wBQ203'] = 0x2;if (nwmsj[s[380146]](s[381301]) != -0x1) {
      if (vyxr$[s[381285]] >= 0x18) window['_w23']['_wBQ203'] = 0x3;else window['_w23']['_wBQ203'] = 0x2;
    } else {
      if (nwmsj[s[380146]](s[381300]) != -0x1) {
        if (vyxr$[s[381285]] && vyxr$[s[381285]] >= 0x14) window['_w23']['_wBQ203'] = 0x3;else {
          if (u8t0h[s[380146]](s[381303]) != -0x1 || u8t0h[s[380146]](s[381304]) != -0x1 || u8t0h[s[380146]](s[381305]) != -0x1 || u8t0h[s[380146]](s[381306]) != -0x1 || u8t0h[s[380146]](s[381307]) != -0x1) window['_w23']['_wBQ203'] = 0x2;else window['_w23']['_wBQ203'] = 0x3;
        }
      } else window['_w23']['_wBQ203'] = 0x2;
    }console[s[380225]](s[381308] + window['_w23']['_wBQ032'] + s[381309] + window['_w23']['_wBQ203']);
  } }), wx[s[381142]]({ 'success': function (yvr$xa) {
    console[s[380225]](s[381310] + yvr$xa[s[381144]] + s[381311] + yvr$xa[s[381146]]);
  } }), wx[s[381312]]({ 'success': function (p4qhm) {
    console[s[380225]](s[381313] + p4qhm[s[381314]]);
  } }), wx[s[381315]]({ 'keepScreenOn': !![] }), wx[s[381316]](function (rda$x) {
  console[s[380225]](s[381313] + rda$x[s[381314]] + s[381317] + rda$x[s[381318]]);
}), wx[s[381117]](function (sqmo64) {
  window['_w0Q'] = sqmo64, window['_w3Q0'] && window['_w0Q'] && (console[s[380981]](s[381118] + window['_w0Q'][s[381119]]), window['_w3Q0'](window['_w0Q']), window['_w0Q'] = null);
}), window[s[381319]] = 0x0, window['_wB203Q'] = 0x0, window[s[381320]] = null, wx[s[381321]](function () {
  window['_wB203Q']++;var rgdxb = Date[s[380950]]();(window[s[381319]] == 0x0 || rgdxb - window[s[381319]] > 0x1d4c0) && (console[s[380383]](s[381322]), wx[s[381323]]());if (window['_wB203Q'] >= 0x2) {
    window['_wB203Q'] = 0x0, console[s[380333]](s[381324]), wx[s[381325]]('0', 0x1);if (window['_w23'] && window['_w23'][s[380956]]) window['_w23Q'](s[381326], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});