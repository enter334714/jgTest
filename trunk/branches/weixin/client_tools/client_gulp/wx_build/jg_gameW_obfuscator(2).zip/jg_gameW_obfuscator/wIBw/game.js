var s = wx.$W;
require(s[380915]);