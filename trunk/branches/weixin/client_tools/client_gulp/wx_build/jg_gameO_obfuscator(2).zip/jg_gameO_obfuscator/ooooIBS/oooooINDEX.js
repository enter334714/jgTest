var c = wx.$o;
import o_rpczh8 from '../ooosk/oooosdk.js';window[c[248715]] = { 'wxVersion': window[c[220552]][c[248405]] }, window[c[248716]] = ![], window['_oEA'] = 0x1, window[c[248717]] = 0x1, window['_o8AE'] = !![], window[c[248718]] = !![], window['_oQU8AE'] = '', window['_oAE'] = { 'base_cdn': c[248719], 'cdn': c[248719] }, _oAE[c[248720]] = {}, _oAE[c[244872]] = '0', _oAE[c[224707]] = window[c[248715]][c[248622]], _oAE[c[248480]] = '', _oAE['os'] = '1', _oAE[c[248721]] = c[248722], _oAE[c[248723]] = c[248724], _oAE[c[248725]] = c[248726], _oAE[c[248727]] = c[248728], _oAE[c[248729]] = c[248730], _oAE[c[243612]] = '1', _oAE[c[245186]] = '', _oAE[c[245188]] = '', _oAE[c[248731]] = 0x0, _oAE[c[248661]] = {}, _oAE[c[248732]] = parseInt(_oAE[c[243612]]), _oAE[c[245184]] = _oAE[c[243612]], _oAE[c[245180]] = {}, _oAE['_oUA'] = c[248733], _oAE[c[248734]] = ![], _oAE[c[232223]] = c[248735], _oAE[c[245157]] = Date[c[220080]](), _oAE[c[231837]] = c[248736], _oAE[c[220709]] = '_a', _oAE[c[248615]] = 0x2, _oAE[c[220098]] = 0x7c1, _oAE[c[248622]] = window[c[248715]][c[248622]], _oAE[c[220733]] = ![], _oAE[c[221068]] = ![], _oAE[c[231318]] = ![], _oAE[c[244874]] = ![], window['_o8EA'] = 0x5, window['_o8E'] = ![], window['_oE8'] = ![], window['_oA8E'] = ![], window[c[248692]] = ![], window[c[248695]] = ![], window['_oAE8'] = ![], window['_o8A'] = ![], window['_oA8'] = ![], window['_oE8A'] = ![], window[c[224176]] = function (_k0$ye) {
  console[c[220477]](c[224176], _k0$ye), wx[c[224986]]({}), wx[c[248429]]({ 'title': c[226349], 'content': _k0$ye, 'success'(nva3lu) {
      if (nva3lu[c[248737]]) console[c[220477]](c[248738]);else nva3lu[c[220548]] && console[c[220477]](c[248739]);
    } });
}, window['_oU8AE'] = function (v3_yun) {
  console[c[220477]](c[248740], v3_yun), _oUAE8(), wx[c[248429]]({ 'title': c[226349], 'content': v3_yun, 'confirmText': c[248741], 'cancelText': c[238477], 'success'(pbh8zc) {
      if (pbh8zc[c[248737]]) window['_oAU']();else pbh8zc[c[220548]] && (console[c[220477]](c[248742]), wx[c[245344]]({}));
    } });
}, window[c[248743]] = function (ms7tq) {
  console[c[220477]](c[248743], ms7tq), wx[c[248429]]({ 'title': c[226349], 'content': ms7tq, 'confirmText': c[245316], 'showCancel': ![], 'complete'(hg8ob) {
      console[c[220477]](c[248742]), wx[c[245344]]({});
    } });
}, window['_oU8EA'] = ![], window['_oUA8E'] = function (cr8z) {
  window['_oU8EA'] = !![], wx[c[224985]](cr8z);
}, window['_oUAE8'] = function () {
  window['_oU8EA'] && (window['_oU8EA'] = ![], wx[c[224986]]({}));
}, window['_oUE8A'] = function (xb94) {
  window[c[248420]][c[220145]]['_oUE8A'](xb94);
}, window[c[232104]] = function (vlnau3, hgb4xo) {
  o_rpczh8[c[232104]](vlnau3, function (_l3vnu) {
    _l3vnu && _l3vnu[c[220011]] ? _l3vnu[c[220011]][c[224109]] == 0x1 ? hgb4xo(!![]) : (hgb4xo(![]), console[c[220075]](c[248744] + _l3vnu[c[220011]][c[248745]])) : console[c[220477]](c[232104], _l3vnu);
  });
}, window['_oUEA8'] = function (r58p) {
  console[c[220477]](c[248746], r58p);
}, window['_oUAE'] = function (x9bgo4) {}, window['_oUEA'] = function (zp8crh, e_u3yn, fw1di) {}, window['_oUE'] = function (mczpr) {
  console[c[220477]](c[248747], mczpr), window[c[248420]][c[220145]][c[248617]](), window[c[248420]][c[220145]][c[248618]](), window[c[248420]][c[220145]][c[248625]]();
}, window['_oEU'] = function (z8h) {
  window['_oU8AE'](c[248748]);var pcr5m8 = { 'id': window['_oAE'][c[248410]], 'role': window['_oAE'][c[224636]], 'level': window['_oAE'][c[248411]], 'account': window['_oAE'][c[245185]], 'version': window['_oAE'][c[220098]], 'cdn': window['_oAE'][c[224515]], 'pkgName': window['_oAE'][c[245186]], 'gamever': window[c[220552]][c[248405]], 'serverid': window['_oAE'][c[245180]] ? window['_oAE'][c[245180]][c[231496]] : 0x0, 'systemInfo': window[c[248412]], 'error': c[248749], 'stack': z8h ? z8h : c[248748] },
      eyun_k = JSON[c[224501]](pcr5m8);console[c[220122]](c[248750] + eyun_k), window['_oUA'](eyun_k);
}, window['_oAUE'] = function (_u0ye) {
  var v26dal = JSON[c[220522]](_u0ye);v26dal[c[248751]] = window[c[220552]][c[248405]], v26dal[c[248752]] = window['_oAE'][c[245180]] ? window['_oAE'][c[245180]][c[231496]] : 0x0, v26dal[c[248412]] = window[c[248412]];var e_kun = JSON[c[224501]](v26dal);console[c[220122]](c[248753] + e_kun), window['_oUA'](e_kun);
}, window['_oAEU'] = function (v6l3ad, d1i) {
  var di62l = { 'id': window['_oAE'][c[248410]], 'role': window['_oAE'][c[224636]], 'level': window['_oAE'][c[248411]], 'account': window['_oAE'][c[245185]], 'version': window['_oAE'][c[220098]], 'cdn': window['_oAE'][c[224515]], 'pkgName': window['_oAE'][c[245186]], 'gamever': window[c[220552]][c[248405]], 'serverid': window['_oAE'][c[245180]] ? window['_oAE'][c[245180]][c[231496]] : 0x0, 'systemInfo': window[c[248412]], 'error': v6l3ad, 'stack': d1i },
      rczph8 = JSON[c[224501]](di62l);console[c[220093]](c[248754] + rczph8), window['_oUA'](rczph8);
}, window['_oUA'] = function (rs5m) {
  if (window['_oAE'][c[248481]] == c[248755]) return;var w2d16i = _oAE['_oUA'] + c[248756] + _oAE[c[245185]];wx[c[220472]]({ 'url': w2d16i, 'method': c[248757], 'data': rs5m, 'header': { 'content-type': c[248758], 'cache-control': c[248759] }, 'success': function (b8choz) {
      DEBUG && console[c[220477]](c[248760], w2d16i, rs5m, b8choz);
    }, 'fail': function (bczo) {
      DEBUG && console[c[220477]](c[248760], w2d16i, rs5m, bczo);
    }, 'complete': function () {} });
}, window[c[248761]] = function () {
  function i62ld() {
    return ((0x1 + Math[c[220116]]()) * 0x10000 | 0x0)[c[220269]](0x10)[c[220495]](0x1);
  }return i62ld() + i62ld() + '-' + i62ld() + '-' + i62ld() + '-' + i62ld() + '+' + i62ld() + i62ld() + i62ld();
}, window['_oAU'] = function () {
  console[c[220477]](c[248762]);var rzhc = o_rpczh8[c[248763]]();_oAE[c[245184]] = rzhc[c[248764]], _oAE[c[248732]] = rzhc[c[248764]], _oAE[c[243612]] = rzhc[c[248764]], _oAE[c[245186]] = rzhc[c[248765]];var rh8zcp = { 'game_ver': _oAE[c[224707]] };_oAE[c[245188]] = this[c[248761]](), _oUA8E({ 'title': c[248766] }), o_rpczh8[c[220363]](rh8zcp, this['_oEUA'][c[220071]](this));
}, window['_oEUA'] = function (rm5tsq) {
  var b4xogh = rm5tsq[c[248767]];console[c[220477]](c[248768] + b4xogh + c[248769] + (b4xogh == 0x1) + c[248770] + rm5tsq[c[248405]] + c[248771] + window[c[248715]][c[248622]]);if (!rm5tsq[c[248405]] || window['_oQ8EUA'](window[c[248715]][c[248622]], rm5tsq[c[248405]]) < 0x0) console[c[220477]](c[248772]), _oAE[c[248723]] = c[248773], _oAE[c[248725]] = c[248774], _oAE[c[248727]] = c[248775], _oAE[c[224515]] = c[248776], _oAE[c[244871]] = c[248777], _oAE[c[248778]] = c[248779], _oAE[c[220733]] = ![];else window['_oQ8EUA'](window[c[248715]][c[248622]], rm5tsq[c[248405]]) == 0x0 ? (console[c[220477]](c[248780]), _oAE[c[248723]] = c[248724], _oAE[c[248725]] = c[248726], _oAE[c[248727]] = c[248728], _oAE[c[224515]] = c[248781], _oAE[c[244871]] = c[248777], _oAE[c[248778]] = c[248782], _oAE[c[220733]] = !![]) : (console[c[220477]](c[248783]), _oAE[c[248723]] = c[248724], _oAE[c[248725]] = c[248726], _oAE[c[248727]] = c[248728], _oAE[c[224515]] = c[248781], _oAE[c[244871]] = c[248777], _oAE[c[248778]] = c[248782], _oAE[c[220733]] = ![]);_oAE[c[248731]] = config[c[248784]] ? config[c[248784]] : 0x0, this['_o8AUE'](), this['_o8AEU'](), window[c[248785]] = 0x5, _oUA8E({ 'title': c[248786] }), o_rpczh8[c[248787]](this['_oEAU'][c[220071]](this));
}, window[c[248785]] = 0x5, window['_oEAU'] = function (n_3v, p8rcmz) {
  if (n_3v == 0x0 && p8rcmz && p8rcmz[c[248788]]) {
    _oAE[c[248789]] = p8rcmz[c[248788]];var ey0uk = this;_oUA8E({ 'title': c[248790] }), sendApi(_oAE[c[248723]], c[248791], { 'platform': _oAE[c[248721]], 'partner_id': _oAE[c[243612]], 'token': p8rcmz[c[248788]], 'game_pkg': _oAE[c[245186]], 'deviceId': _oAE[c[245188]], 'scene': c[248792] + _oAE[c[248731]] }, this['_o8UAE'][c[220071]](this), _o8EA, _oEU);
  } else p8rcmz && p8rcmz[c[245371]] && window[c[248785]] > 0x0 && (p8rcmz[c[245371]][c[220112]](c[248793]) != -0x1 || p8rcmz[c[245371]][c[220112]](c[248794]) != -0x1 || p8rcmz[c[245371]][c[220112]](c[248795]) != -0x1 || p8rcmz[c[245371]][c[220112]](c[248796]) != -0x1 || p8rcmz[c[245371]][c[220112]](c[248797]) != -0x1 || p8rcmz[c[245371]][c[220112]](c[248798]) != -0x1) ? (window[c[248785]]--, o_rpczh8[c[248787]](this['_oEAU'][c[220071]](this))) : (window['_oAEU'](c[248799], JSON[c[224501]]({ 'status': n_3v, 'data': p8rcmz })), window['_oU8AE'](c[248800] + (p8rcmz && p8rcmz[c[245371]] ? '，' + p8rcmz[c[245371]] : '')));
}, window['_o8UAE'] = function (an3l) {
  if (!an3l) {
    window['_oAEU'](c[248801], c[248802]), window['_oU8AE'](c[248803]);return;
  }if (an3l[c[224109]] != c[229908]) {
    window['_oAEU'](c[248801], JSON[c[224501]](an3l)), window['_oU8AE'](c[248804] + an3l[c[224109]]);return;
  }_oAE[c[243611]] = String(an3l[c[245185]]), _oAE[c[245185]] = String(an3l[c[245185]]), _oAE[c[245155]] = String(an3l[c[245155]]), _oAE[c[245184]] = String(an3l[c[245155]]), _oAE[c[245187]] = String(an3l[c[245187]]), _oAE[c[248805]] = String(an3l[c[231479]]), _oAE[c[248806]] = String(an3l[c[220845]]), _oAE[c[231479]] = '';var zbph = this;_oUA8E({ 'title': c[248807] }), sendApi(_oAE[c[248723]], c[248808], { 'partner_id': _oAE[c[243612]], 'uid': _oAE[c[245185]], 'version': _oAE[c[224707]], 'game_pkg': _oAE[c[245186]], 'device': _oAE[c[245188]] }, zbph['_o8UEA'][c[220071]](zbph), _o8EA, _oEU);
}, window['_o8UEA'] = function (z8chrp) {
  if (!z8chrp) {
    window['_oU8AE'](c[248809]);return;
  }if (z8chrp[c[224109]] != c[229908]) {
    window['_oU8AE'](c[248810] + z8chrp[c[224109]]);return;
  }if (!z8chrp[c[220011]] || z8chrp[c[220011]][c[220013]] == 0x0) {
    window['_oU8AE'](c[248811]);return;
  }_oAE[c[220625]] = z8chrp[c[248812]], _oAE[c[245180]] = { 'server_id': String(z8chrp[c[220011]][0x0][c[231496]]), 'server_name': String(z8chrp[c[220011]][0x0][c[248655]]), 'entry_ip': z8chrp[c[220011]][0x0][c[245208]], 'entry_port': parseInt(z8chrp[c[220011]][0x0][c[245209]]), 'status': _oA8U(z8chrp[c[220011]][0x0]), 'start_time': z8chrp[c[220011]][0x0][c[248813]], 'cdn': _oAE[c[224515]] }, this['_oEA8U']();
}, window['_oEA8U'] = function () {
  if (_oAE[c[220625]] == 0x1) {
    var l_3uvn = _oAE[c[245180]][c[220103]];if (l_3uvn === -0x1 || l_3uvn === 0x0) {
      window['_oU8AE'](l_3uvn === -0x1 ? c[248814] : c[248815]);return;
    }_oEU8A(0x0, _oAE[c[245180]][c[231496]]), window[c[248420]][c[220145]][c[248696]](_oAE[c[220625]]);
  } else window[c[248420]][c[220145]][c[248693]](), _oUAE8();window['_oA8'] = !![], window['_oE8AU'](), window['_oEAU8']();
}, window['_o8AUE'] = function () {
  sendApi(_oAE[c[248723]], c[248816], { 'game_pkg': _oAE[c[245186]], 'version_name': _oAE[c[248778]] }, this[c[248817]][c[220071]](this), _o8EA, _oEU);
}, window[c[248817]] = function (qms5tr) {
  if (!qms5tr) {
    window['_oU8AE'](c[248818]);return;
  }if (qms5tr[c[224109]] != c[229908]) {
    window['_oU8AE'](c[248819] + qms5tr[c[224109]]);return;
  }if (!qms5tr[c[220011]] || !qms5tr[c[220011]][c[224707]]) {
    window['_oU8AE'](c[248820] + (qms5tr[c[220011]] && qms5tr[c[220011]][c[224707]]));return;
  }qms5tr[c[220011]][c[248821]] && qms5tr[c[220011]][c[248821]][c[220013]] > 0xa && (_oAE[c[248822]] = qms5tr[c[220011]][c[248821]], _oAE[c[224515]] = qms5tr[c[220011]][c[248821]]), qms5tr[c[220011]][c[224707]] && (_oAE[c[220098]] = qms5tr[c[220011]][c[224707]]), console[c[220075]](c[245322] + _oAE[c[220098]] + c[248823] + _oAE[c[248778]]), window['_oAE8'] = !![], window['_oE8AU'](), window['_oEAU8']();
}, window[c[248824]], window['_o8AEU'] = function () {
  sendApi(_oAE[c[248723]], 'Common.get_option_pkg', { 'game_pkg': _oAE[c[245186]] }, this['_o8EUA'][c[220071]](this), _o8EA, _oEU);
}, window['_o8EUA'] = function (p85rmc) {
  if (p85rmc[c[224109]] === c[229908] && p85rmc[c[220011]]) {
    window[c[248824]] = p85rmc[c[220011]];for (var _3u in p85rmc[c[220011]]) {
      _oAE[_3u] = p85rmc[c[220011]][_3u];
    }
  } else console[c[220075]](c[248825] + p85rmc[c[224109]]);window['_o8A'] = !![], window['_oEAU8']();
}, window[c[248826]] = function (ue0_ky, pzmc, _yunk, czbh8o, h4zgob, p8chbz, na36l, g9fxo4, y3v) {
  h4zgob = String(h4zgob);var e$0j = na36l,
      cb8zho = g9fxo4;_oAE[c[248720]][h4zgob] = { 'productid': h4zgob, 'productname': e$0j, 'productdesc': cb8zho, 'roleid': ue0_ky, 'rolename': pzmc, 'rolelevel': _yunk, 'price': p8chbz, 'callback': y3v }, sendApi(_oAE[c[248727]], c[248827], { 'game_pkg': _oAE[c[245186]], 'server_id': _oAE[c[245180]][c[231496]], 'server_name': _oAE[c[245180]][c[248655]], 'level': _yunk, 'uid': _oAE[c[245185]], 'role_id': ue0_ky, 'role_name': pzmc, 'product_id': h4zgob, 'product_name': e$0j, 'product_desc': cb8zho, 'money': p8chbz, 'partner_id': _oAE[c[243612]] }, toPayCallBack, _o8EA, _oEU);
}, window[c[248828]] = function (bg4xh) {
  if (bg4xh) {
    if (bg4xh[c[248829]] === 0xc8 || bg4xh[c[224109]] == c[229908]) {
      var $ke0y = _oAE[c[248720]][String(bg4xh[c[248830]])];if ($ke0y[c[220329]]) $ke0y[c[220329]](bg4xh[c[248830]], bg4xh['cp_order_id'], -0x1);o_rpczh8[c[248831]]({ 'cpbill': bg4xh['cp_order_id'], 'productid': bg4xh[c[248830]], 'productname': $ke0y[c[248832]], 'productdesc': $ke0y[c[248833]], 'serverid': _oAE[c[245180]][c[231496]], 'servername': _oAE[c[245180]][c[248655]], 'roleid': $ke0y[c[248834]], 'rolename': $ke0y[c[248835]], 'rolelevel': $ke0y[c[248836]], 'price': $ke0y[c[246868]], 'extension': JSON[c[224501]]({ 'cp_order_id': bg4xh['cp_order_id'] }) }, function (fdwi21, u_nek) {
        $ke0y[c[220329]] && fdwi21 == 0x0 && $ke0y[c[220329]](bg4xh[c[248830]], bg4xh['cp_order_id'], fdwi21);console[c[220075]](JSON[c[224501]]({ 'type': c[248837], 'status': fdwi21, 'data': bg4xh, 'role_name': $ke0y[c[248835]] }));if (fdwi21 === 0x0) {} else {
          if (fdwi21 === 0x1) {} else {
            if (fdwi21 === 0x2) {}
          }
        }
      });
    } else alert(bg4xh[c[220075]]);
  }
}, window['_o8EAU'] = function () {}, window['_oU8E'] = function (b4ox, prctm, chzo8b, wf1di2, e_un3) {
  o_rpczh8[c[248838]](_oAE[c[245180]][c[231496]], _oAE[c[245180]][c[248655]] || _oAE[c[245180]][c[231496]], b4ox, prctm, chzo8b), sendApi(_oAE[c[248723]], c[248839], { 'game_pkg': _oAE[c[245186]], 'server_id': _oAE[c[245180]][c[231496]], 'role_id': b4ox, 'uid': _oAE[c[245185]], 'role_name': prctm, 'role_type': wf1di2, 'level': chzo8b });
}, window['_oUE8'] = function (ejky0, wdi2f, if12w, tp5cmr, uey0_, n3lu, a2dlv6, yun_e3, cobz8h, rpc58) {
  _oAE[c[248410]] = ejky0, _oAE[c[224636]] = wdi2f, _oAE[c[248411]] = if12w, o_rpczh8[c[248840]](_oAE[c[245180]][c[231496]], _oAE[c[245180]][c[248655]] || _oAE[c[245180]][c[231496]], ejky0, wdi2f, if12w), sendApi(_oAE[c[248723]], c[248841], { 'game_pkg': _oAE[c[245186]], 'server_id': _oAE[c[245180]][c[231496]], 'role_id': ejky0, 'uid': _oAE[c[245185]], 'role_name': wdi2f, 'role_type': tp5cmr, 'level': if12w, 'evolution': uey0_ });
}, window['_o8UE'] = function (k_0$e, p8hbc, d63val, bzcho, gob49, phbc8z, p8rzhc, t5crpm, nvy3u, hgozb) {
  _oAE[c[248410]] = k_0$e, _oAE[c[224636]] = p8hbc, _oAE[c[248411]] = d63val, o_rpczh8[c[248842]](_oAE[c[245180]][c[231496]], _oAE[c[245180]][c[248655]] || _oAE[c[245180]][c[231496]], k_0$e, p8hbc, d63val), sendApi(_oAE[c[248723]], c[248841], { 'game_pkg': _oAE[c[245186]], 'server_id': _oAE[c[245180]][c[231496]], 'role_id': k_0$e, 'uid': _oAE[c[245185]], 'role_name': p8hbc, 'role_type': bzcho, 'level': d63val, 'evolution': gob49 });
}, window['_o8EU'] = function (pcmrt5) {}, window['_oU8'] = function (yku_0) {
  o_rpczh8[c[248843]](c[248843], function (st7q5) {
    yku_0 && yku_0(st7q5);
  });
}, window[c[244855]] = function () {
  o_rpczh8[c[244855]]();
}, window[c[248844]] = function () {
  o_rpczh8[c[243505]]();
}, window[c[230829]] = function (uye0_) {
  window['_oEU8'] = uye0_, window['_oEU8'] && window['_o8U'] && (console[c[220075]](c[248500] + window['_o8U'][c[220770]]), window['_oEU8'](window['_o8U']), window['_o8U'] = null);
}, window['_oE8U'] = function (fo49gx, bh8pcz, hcz8bo, _yk) {
  window[c[220021]](c[248845], { 'game_pkg': window['_oAE'][c[245186]], 'role_id': bh8pcz, 'server_id': hcz8bo }, _yk);
}, window['_oAU8E'] = function (zc8hp, hz8cbo) {
  function ny_eu(xgb4o) {
    var f1xw49 = [],
        di1w = [],
        tmpr5c = window[c[220552]][c[248846]];for (var y_k0 in tmpr5c) {
      var c8mp5r = Number(y_k0);(!zc8hp || !zc8hp[c[220013]] || zc8hp[c[220112]](c8mp5r) != -0x1) && (di1w[c[220028]](tmpr5c[y_k0]), f1xw49[c[220028]]([c8mp5r, 0x3]));
    }window['_oQ8EUA'](window[c[248421]], c[248847]) >= 0x0 ? (console[c[220477]](c[248848]), o_rpczh8[c[248849]] && o_rpczh8[c[248849]](di1w, function (u_kny) {
      console[c[220477]](c[248850]), console[c[220477]](u_kny);if (u_kny && u_kny[c[245371]] == c[248851]) for (var y3eun in tmpr5c) {
        if (u_kny[tmpr5c[y3eun]] == c[248852]) {
          var f14 = Number(y3eun);for (var zbhp8 = 0x0; zbhp8 < f1xw49[c[220013]]; zbhp8++) {
            if (f1xw49[zbhp8][0x0] == f14) {
              f1xw49[zbhp8][0x1] = 0x1;break;
            }
          }
        }
      }window['_oQ8EUA'](window[c[248421]], c[248853]) >= 0x0 ? wx[c[248854]]({ 'withSubscriptions': !![], 'success': function (l6va2d) {
          var iad6 = l6va2d[c[248855]][c[248856]];if (iad6) {
            console[c[220477]](c[248857]), console[c[220477]](iad6);for (var ey_kn in tmpr5c) {
              if (iad6[tmpr5c[ey_kn]] == c[248852]) {
                var zpbc = Number(ey_kn);for (var e0$kj = 0x0; e0$kj < f1xw49[c[220013]]; e0$kj++) {
                  if (f1xw49[e0$kj][0x0] == zpbc) {
                    f1xw49[e0$kj][0x1] = 0x2;break;
                  }
                }
              }
            }console[c[220477]](f1xw49), hz8cbo && hz8cbo(f1xw49);
          } else console[c[220477]](c[248858]), console[c[220477]](l6va2d), console[c[220477]](f1xw49), hz8cbo && hz8cbo(f1xw49);
        }, 'fail': function () {
          console[c[220477]](c[248859]), console[c[220477]](f1xw49), hz8cbo && hz8cbo(f1xw49);
        } }) : (console[c[220477]](c[248860] + window[c[248421]]), console[c[220477]](f1xw49), hz8cbo && hz8cbo(f1xw49));
    })) : (console[c[220477]](c[248861] + window[c[248421]]), console[c[220477]](f1xw49), hz8cbo && hz8cbo(f1xw49)), wx[c[248862]](ny_eu);
  }wx[c[248863]](ny_eu);
}, window['_oAUE8'] = { 'isSuccess': ![], 'level': c[248864], 'isCharging': ![] }, window['_oA8UE'] = function (ia6) {
  wx[c[248489]]({ 'success': function (f94g) {
      var aid61 = window['_oAUE8'];aid61[c[248865]] = !![], aid61[c[224612]] = Number(f94g[c[224612]])[c[224224]](0x0), aid61[c[248492]] = f94g[c[248492]], ia6 && ia6(aid61[c[248865]], aid61[c[224612]], aid61[c[248492]]);
    }, 'fail': function (nl3u_v) {
      console[c[220477]](c[248866], nl3u_v[c[245371]]);var val36d = window['_oAUE8'];ia6 && ia6(val36d[c[248865]], val36d[c[224612]], val36d[c[248492]]);
    } });
}, window[c[220021]] = function (enu_y, ue_yn, al6i2d, trq5sm, unlav, xfw4g, uv3lna, a216) {
  if (trq5sm == undefined) trq5sm = 0x1;wx[c[220472]]({ 'url': enu_y, 'method': uv3lna || c[245074], 'responseType': c[224421], 'data': ue_yn, 'header': { 'content-type': a216 || c[248758] }, 'success': function (v_un3) {
      DEBUG && console[c[220477]](c[248867], enu_y, info, v_un3);if (v_un3 && v_un3[c[245437]] == 0xc8) {
        var cbzho = v_un3[c[220011]];!xfw4g || xfw4g(cbzho) ? al6i2d && al6i2d(cbzho) : window[c[248868]](enu_y, ue_yn, al6i2d, trq5sm, unlav, xfw4g, v_un3);
      } else window[c[248868]](enu_y, ue_yn, al6i2d, trq5sm, unlav, xfw4g, v_un3);
    }, 'fail': function (a3ldv6) {
      DEBUG && console[c[220477]](c[248869], enu_y, info, a3ldv6), window[c[248868]](enu_y, ue_yn, al6i2d, trq5sm, unlav, xfw4g, a3ldv6);
    }, 'complete': function () {} });
}, window[c[248868]] = function (a2l6vd, w1fxi9, rstq5, i26a, ynke_, valu3, pcm8z) {
  i26a - 0x1 > 0x0 ? setTimeout(function () {
    window[c[220021]](a2l6vd, w1fxi9, rstq5, i26a - 0x1, ynke_, valu3);
  }, 0x3e8) : ynke_ && ynke_(JSON[c[224501]]({ 'url': a2l6vd, 'response': pcm8z }));
}, window[c[248870]] = function (rmct5p, rmzc, yn_u3e, s5qmtr, nl_3vu, h8zbpc, uyv_) {
  !yn_u3e && (yn_u3e = {});var v_nul = Math[c[220115]](Date[c[220080]]() / 0x3e8);yn_u3e[c[220845]] = v_nul, yn_u3e[c[244995]] = rmzc;var t5qrpm = Object[c[220261]](yn_u3e)[c[221071]](),
      mr5tc = '',
      v6a2ld = '';for (var o4g9b = 0x0; o4g9b < t5qrpm[c[220013]]; o4g9b++) {
    mr5tc = mr5tc + (o4g9b == 0x0 ? '' : '&') + t5qrpm[o4g9b] + yn_u3e[t5qrpm[o4g9b]], v6a2ld = v6a2ld + (o4g9b == 0x0 ? '' : '&') + t5qrpm[o4g9b] + '=' + encodeURIComponent(yn_u3e[t5qrpm[o4g9b]]);
  }mr5tc = mr5tc + _oAE[c[248729]];var o4ghb = c[248871] + md5(mr5tc);send(rmct5p + '?' + v6a2ld + (v6a2ld == '' ? '' : '&') + o4ghb, null, s5qmtr, nl_3vu, h8zbpc, uyv_ || function (ey_nu3) {
    return ey_nu3[c[224109]] == c[229908];
  }, null, c[248872]);
}, window['_oA8EU'] = function (rtp5mq, fgw9) {
  var xi1fw = 0x0;_oAE[c[245180]] && (xi1fw = _oAE[c[245180]][c[231496]]), sendApi(_oAE[c[248725]], c[248873], { 'partnerId': _oAE[c[243612]], 'gamePkg': _oAE[c[245186]], 'logTime': Math[c[220115]](Date[c[220080]]() / 0x3e8), 'platformUid': _oAE[c[245187]], 'type': rtp5mq, 'serverId': xi1fw }, null, 0x2, null, function () {
    return !![];
  });
}, window['_oAEU8'] = function (gfx94) {
  sendApi(_oAE[c[248723]], c[248874], { 'partner_id': _oAE[c[243612]], 'uid': _oAE[c[245185]], 'version': _oAE[c[224707]], 'game_pkg': _oAE[c[245186]], 'device': _oAE[c[245188]] }, _oAE8U, _o8EA, _oEU);
}, window['_oAE8U'] = function (ny_ue3) {
  if (ny_ue3[c[224109]] === c[229908] && ny_ue3[c[220011]]) {
    ny_ue3[c[220011]][c[225589]]({ 'id': -0x2, 'name': c[248875] }), ny_ue3[c[220011]][c[225589]]({ 'id': -0x1, 'name': c[248876] }), _oAE[c[248647]] = ny_ue3[c[220011]];if (window[c[232269]]) window[c[232269]][c[248660]]();
  } else _oAE[c[248651]] = ![], window['_oU8AE'](c[248877] + ny_ue3[c[224109]]);
}, window['_oU8A'] = function (bx94g) {
  sendApi(_oAE[c[248723]], c[248878], { 'partner_id': _oAE[c[243612]], 'uid': _oAE[c[245185]], 'version': _oAE[c[224707]], 'game_pkg': _oAE[c[245186]], 'device': _oAE[c[245188]] }, _oUA8, _o8EA, _oEU);
}, window['_oUA8'] = function (xgof4) {
  _oAE[c[248663]] = ![];if (xgof4[c[224109]] === c[229908] && xgof4[c[220011]]) {
    for (var d1iw26 = 0x0; d1iw26 < xgof4[c[220011]][c[220013]]; d1iw26++) {
      xgof4[c[220011]][d1iw26][c[220103]] = _oA8U(xgof4[c[220011]][d1iw26]);
    }_oAE[c[248661]][-0x1] = window[c[248879]](xgof4[c[220011]]), window[c[232269]][c[248662]](-0x1);
  } else window['_oU8AE'](c[248880] + xgof4[c[224109]]);
}, window['req_server_owner_status'] = function (zpb8) {
  sendApi(_oAE[c[248723]], c[248878], { 'partner_id': _oAE[c[243612]], 'uid': _oAE[c[245185]], 'version': _oAE[c[224707]], 'game_pkg': _oAE[c[245186]], 'device': _oAE[c[245188]] }, zpb8, _o8EA, _oEU);
}, window['_o8UA'] = function (da2i1, hbzg4o) {
  sendApi(_oAE[c[248723]], c[248881], { 'partner_id': _oAE[c[243612]], 'uid': _oAE[c[245185]], 'version': _oAE[c[224707]], 'game_pkg': _oAE[c[245186]], 'device': _oAE[c[245188]], 'server_group_id': hbzg4o }, _o8AU, _o8EA, _oEU);
}, window['_o8AU'] = function (czh8rp) {
  _oAE[c[248663]] = ![];if (czh8rp[c[224109]] === c[229908] && czh8rp[c[220011]] && czh8rp[c[220011]][c[220011]]) {
    var uy3v_ = czh8rp[c[220011]][c[248882]],
        pbhz8 = [];for (var al36dv = 0x0; al36dv < czh8rp[c[220011]][c[220011]][c[220013]]; al36dv++) {
      czh8rp[c[220011]][c[220011]][al36dv][c[220103]] = _oA8U(czh8rp[c[220011]][c[220011]][al36dv]), (pbhz8[c[220013]] == 0x0 || czh8rp[c[220011]][c[220011]][al36dv][c[220103]] != 0x0) && (pbhz8[pbhz8[c[220013]]] = czh8rp[c[220011]][c[220011]][al36dv]);
    }_oAE[c[248661]][uy3v_] = window[c[248879]](pbhz8), window[c[232269]][c[248662]](uy3v_);
  } else window['_oU8AE'](c[248883] + czh8rp[c[224109]]);
}, window['_oQ8EA'] = function (z8prc) {
  sendApi(_oAE[c[248723]], c[248884], { 'partner_id': _oAE[c[243612]], 'uid': _oAE[c[245185]], 'version': _oAE[c[224707]], 'game_pkg': _oAE[c[245186]], 'device': _oAE[c[245188]] }, reqServerRecommendCallBack, _o8EA, _oEU);
}, window[c[248885]] = function (fi219w) {
  _oAE[c[248663]] = ![];if (fi219w[c[224109]] === c[229908] && fi219w[c[220011]]) {
    for (var zb8coh = 0x0; zb8coh < fi219w[c[220011]][c[220013]]; zb8coh++) {
      fi219w[c[220011]][zb8coh][c[220103]] = _oA8U(fi219w[c[220011]][zb8coh]);
    }_oAE[c[248661]][-0x2] = window[c[248879]](fi219w[c[220011]]), window[c[232269]][c[248662]](-0x2);
  } else alert(c[248886] + fi219w[c[224109]]);
}, window[c[248879]] = function (cr8phz) {
  if (!cr8phz && cr8phz[c[220013]] <= 0x0) return cr8phz;for (let dw6 = 0x0; dw6 < cr8phz[c[220013]]; dw6++) {
    cr8phz[dw6][c[248887]] && cr8phz[dw6][c[248887]] == 0x1 && (cr8phz[dw6][c[248655]] += c[248888]);
  }return cr8phz;
}, window['_oAU8'] = function (rmzcp8, w9ifx1) {
  rmzcp8 = rmzcp8 || _oAE[c[245180]][c[231496]], sendApi(_oAE[c[248723]], c[248889], { 'type': '4', 'game_pkg': _oAE[c[245186]], 'server_id': rmzcp8 }, w9ifx1);
}, window[c[248890]] = function (_uvy3n, a1i62, d2l, nyeu_) {
  d2l = d2l || _oAE[c[245180]][c[231496]], sendApi(_oAE[c[248723]], c[248891], { 'type': _uvy3n, 'game_pkg': a1i62, 'server_id': d2l }, nyeu_);
}, window['_oA8U'] = function (_ukyen) {
  if (_ukyen) {
    if (_ukyen[c[220103]] == 0x1) {
      if (_ukyen[c[248892]] == 0x1) return 0x2;else return 0x1;
    } else return _ukyen[c[220103]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_oEU8A'] = function (iwfx19, kuyn_) {
  _oAE[c[248893]] = { 'step': iwfx19, 'server_id': kuyn_ };var dil2a6 = this;_oUA8E({ 'title': c[248894] }), sendApi(_oAE[c[248723]], c[248895], { 'partner_id': _oAE[c[243612]], 'uid': _oAE[c[245185]], 'game_pkg': _oAE[c[245186]], 'server_id': kuyn_, 'platform': _oAE[c[245155]], 'platform_uid': _oAE[c[245187]], 'check_login_time': _oAE[c[248806]], 'check_login_sign': _oAE[c[248805]], 'version_name': _oAE[c[248778]] }, _oEUA8, _o8EA, _oEU, function (uvnl3_) {
    return uvnl3_[c[224109]] == c[229908] || uvnl3_[c[220075]] == c[248896] || uvnl3_[c[220075]] == c[248897];
  });
}, window['_oEUA8'] = function (bxhg) {
  var s5q7 = this;if (bxhg[c[224109]] === c[229908] && bxhg[c[220011]]) {
    var h4xgbo = _oAE[c[245180]];h4xgbo[c[248898]] = _oAE[c[248732]], h4xgbo[c[231479]] = String(bxhg[c[220011]][c[248899]]), h4xgbo[c[245157]] = parseInt(bxhg[c[220011]][c[220845]]);if (bxhg[c[220011]][c[245156]]) h4xgbo[c[245156]] = parseInt(bxhg[c[220011]][c[245156]]);else h4xgbo[c[245156]] = parseInt(bxhg[c[220011]][c[231496]]);h4xgbo[c[248900]] = 0x0, h4xgbo[c[224515]] = _oAE[c[248822]], h4xgbo[c[248901]] = bxhg[c[220011]][c[248902]], h4xgbo['server_options'] = bxhg[c[220011]]['server_options'], console[c[220477]]('server_options\uFF1A' + JSON[c[224501]](h4xgbo['server_options'])), _oAE[c[220625]] == 0x1 && h4xgbo['server_options'] && h4xgbo['server_options'][c[248903]] == 0x1 && (_oAE[c[248623]] = 0x1, window[c[248420]][c[220145]]['_oQEA']()), _oE8UA();
  } else _oAE[c[248893]][c[227105]] >= 0x3 ? (_oEU(JSON[c[224501]](bxhg)), window['_oU8AE'](c[248904] + bxhg[c[224109]])) : sendApi(_oAE[c[248723]], c[248791], { 'platform': _oAE[c[248721]], 'partner_id': _oAE[c[243612]], 'token': _oAE[c[248789]], 'game_pkg': _oAE[c[245186]], 'deviceId': _oAE[c[245188]], 'scene': c[248792] + _oAE[c[248731]] }, function (_l3unv) {
    if (!_l3unv || _l3unv[c[224109]] != c[229908]) {
      window['_oU8AE'](c[248804] + _l3unv && _l3unv[c[224109]]);return;
    }_oAE[c[248805]] = String(_l3unv[c[231479]]), _oAE[c[248806]] = String(_l3unv[c[220845]]), setTimeout(function () {
      _oEU8A(_oAE[c[248893]][c[227105]] + 0x1, _oAE[c[248893]][c[231496]]);
    }, 0x5dc);
  }, _o8EA, _oEU, function (f29w) {
    return f29w[c[224109]] == c[229908] || f29w[c[224109]] == c[245515];
  });
}, window['_oE8UA'] = function () {
  ServerLoading[c[220145]][c[248696]](_oAE[c[220625]]), window['_o8E'] = !![], window['_oEAU8']();
}, window['_oE8AU'] = function () {
  if (window['_oE8'] && window['_oA8E'] && window[c[248692]] && window[c[248695]] && window['_oAE8'] && window['_oA8']) {
    if (!window[c[248400]][c[220145]]) {
      console[c[220477]](c[248905] + window[c[248400]][c[220145]]);var o4f9xg = wx[c[248906]](),
          l3avd = o4f9xg[c[220770]] ? o4f9xg[c[220770]] : 0x0,
          k$0e_ = { 'cdn': window['_oAE'][c[224515]], 'spareCdn': window['_oAE'][c[244871]], 'newRegister': window['_oAE'][c[220625]], 'wxPC': window['_oAE'][c[244874]], 'wxIOS': window['_oAE'][c[221068]], 'wxAndroid': window['_oAE'][c[231318]], 'wxParam': { 'limitLoad': window['_oAE']['_oQU8EA'], 'benchmarkLevel': window['_oAE']['_oQUA8E'], 'wxFrom': window[c[220552]][c[248784]] == c[248907] ? 0x1 : 0x0, 'wxSDKVersion': window[c[248421]] }, 'configType': window['_oAE'][c[231837]], 'exposeType': window['_oAE'][c[220709]], 'scene': l3avd };new window[c[248400]](k$0e_, window['_oAE'][c[220098]], window['_oQU8AE']);
    }
  }
}, window['_oEAU8'] = function () {
  if (window['_oE8'] && window['_oA8E'] && window[c[248692]] && window[c[248695]] && window['_oAE8'] && window['_oA8'] && window['_o8E'] && window['_o8A']) {
    _oUAE8();if (!_oE8A) {
      _oE8A = !![];if (!window[c[248400]][c[220145]]) window['_oE8AU']();var bcpzh8 = 0x0,
          ku = wx[c[248908]]();ku && (window['_oAE'][c[248478]] && (bcpzh8 = ku[c[220317]]), console[c[220075]](c[248909] + ku[c[220317]] + c[248910] + ku[c[221207]] + c[248911] + ku[c[221209]] + c[248912] + ku[c[221208]] + c[248913] + ku[c[220173]] + c[248914] + ku[c[220174]]));var a2lid6 = {};for (const a6i2d1 in _oAE[c[245180]]) {
        a2lid6[a6i2d1] = _oAE[c[245180]][a6i2d1];
      }var u3vn_ = { 'channel': window['_oAE'][c[245184]], 'account': window['_oAE'][c[245185]], 'userId': window['_oAE'][c[243611]], 'cdn': window['_oAE'][c[224515]], 'data': window['_oAE'][c[220011]], 'package': window['_oAE'][c[244872]], 'newRegister': window['_oAE'][c[220625]], 'pkgName': window['_oAE'][c[245186]], 'partnerId': window['_oAE'][c[243612]], 'platform_uid': window['_oAE'][c[245187]], 'deviceId': window['_oAE'][c[245188]], 'selectedServer': a2lid6, 'configType': window['_oAE'][c[231837]], 'exposeType': window['_oAE'][c[220709]], 'debugUsers': window['_oAE'][c[232223]], 'wxMenuTop': bcpzh8, 'wxShield': window['_oAE'][c[220733]] };if (window[c[248824]]) for (var rp8czm in window[c[248824]]) {
        u3vn_[rp8czm] = window[c[248824]][rp8czm];
      }window[c[248400]][c[220145]]['_oEAQ'](u3vn_), setTimeout(() => {
        !_oAE[c[220733]] && new minitool();
      }, 0x2710);
    }
  } else console[c[220075]](c[248915] + window['_oE8'] + c[248916] + window['_oA8E'] + c[248917] + window[c[248692]] + c[248918] + window[c[248695]] + c[248919] + window['_oAE8'] + c[248920] + window['_oA8'] + c[248921] + window['_o8E'] + c[248922] + window['_o8A']);
};