var c = wx.$o;
import 'ooooMAIN.js';