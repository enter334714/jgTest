var c = wx.$o;
require(c[248401]);