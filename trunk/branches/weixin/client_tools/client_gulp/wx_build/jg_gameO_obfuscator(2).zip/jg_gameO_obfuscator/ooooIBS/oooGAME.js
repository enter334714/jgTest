var c = wx.$o;
console[c[220075]](c[248402]), window[c[248403]], wx[c[248404]](function (ix9w1) {
  if (ix9w1) {
    if (ix9w1[c[224516]]) {
      var $ye0j = window[c[220552]][c[248405]][c[224694]](new RegExp(/\./, 'g'), '_'),
          wd61 = ix9w1[c[224516]],
          v_y3u = wd61[c[232031]](/(ooooooo\/oooGAME.js:)[0-9]{1,60}(:)/g);if (v_y3u) for (var ox4gf = 0x0; ox4gf < v_y3u[c[220013]]; ox4gf++) {
        if (v_y3u[ox4gf] && v_y3u[ox4gf][c[220013]] > 0x0) {
          var _ueny3 = parseInt(v_y3u[ox4gf][c[224694]](c[248406], '')[c[224694]](':', ''));wd61 = wd61[c[224694]](v_y3u[ox4gf], v_y3u[ox4gf][c[224694]](':' + _ueny3 + ':', ':' + (_ueny3 - 0x2) + ':'));
        }
      }wd61 = wd61[c[224694]](new RegExp(c[248407], 'g'), c[248408] + $ye0j + c[245285]), wd61 = wd61[c[224694]](new RegExp(c[248409], 'g'), c[248408] + $ye0j + c[245285]), ix9w1[c[224516]] = wd61;
    }var fw1ix = { 'id': window['_oAE'][c[248410]], 'role': window['_oAE'][c[224636]], 'level': window['_oAE'][c[248411]], 'user': window['_oAE'][c[245185]], 'version': window['_oAE'][c[220098]], 'gamever': window[c[220552]][c[248405]], 'cdn': window['_oAE'][c[224515]], 'serverid': window['_oAE'][c[245180]] ? window['_oAE'][c[245180]][c[231496]] : 0x0, 'systemInfo': window[c[248412]], 'error': c[248413], 'stack': ix9w1 ? ix9w1[c[224516]] : '' },
        fdi2w = JSON[c[224501]](fw1ix);console[c[220122]](c[248414] + fdi2w), (!window[c[248403]] || window[c[248403]] != fw1ix[c[220122]]) && (window[c[248403]] = fw1ix[c[220122]], window['_oUA'](fw1ix));
  }
});import 'oooMDadfa.js';import 'oooasdf.js';window[c[248415]] = require(c[248416]);import 'oooooINDEX.js';import 'ooooLIBsdsa.js';import 'oooWXMsad.js';import 'ooooINITMIN.js';import 'SyMiniTool.js';console[c[220075]](c[248417]), console[c[220075]](c[248418]), _oUA8E({ 'title': c[248419] });var o_alvu = { '_oQUEA8': !![] };new window[c[248420]](o_alvu), window[c[248420]][c[220145]]['_oQ8AEU']();if (window['_oQUAE8']) clearInterval(window['_oQUAE8']);window['_oQUAE8'] = null, window['_oQ8EUA'] = function (c5p8rm, ifxw) {
  if (!c5p8rm || !ifxw) return 0x0;c5p8rm = c5p8rm[c[220015]]('.'), ifxw = ifxw[c[220015]]('.');const bho4zg = Math[c[220847]](c5p8rm[c[220013]], ifxw[c[220013]]);while (c5p8rm[c[220013]] < bho4zg) {
    c5p8rm[c[220028]]('0');
  }while (ifxw[c[220013]] < bho4zg) {
    ifxw[c[220028]]('0');
  }for (var hx4gob = 0x0; hx4gob < bho4zg; hx4gob++) {
    const y_uv = parseInt(c5p8rm[hx4gob]),
          id12a = parseInt(ifxw[hx4gob]);if (y_uv > id12a) return 0x1;else {
      if (y_uv < id12a) return -0x1;
    }
  }return 0x0;
}, window[c[248421]] = wx[c[248422]]()[c[248421]], console[c[220477]](c[248423] + window[c[248421]]);var o_n_3eyu = wx[c[248424]]();o_n_3eyu[c[248425]](function (xi9) {
  console[c[220477]](c[248426] + xi9[c[248427]]);
}), o_n_3eyu[c[248428]](function () {
  wx[c[248429]]({ 'title': c[248430], 'content': c[248431], 'showCancel': ![], 'success': function (mc8rz) {
      o_n_3eyu[c[248432]]();
    } });
}), o_n_3eyu[c[248433]](function () {
  console[c[220477]](c[248434]);
}), window['_oQ8EAU'] = function () {
  console[c[220477]](c[248435]);var h8goz = wx[c[248436]]({ 'name': c[248437], 'success': function (x4hbog) {
      console[c[220477]](c[248438]), console[c[220477]](x4hbog), x4hbog && x4hbog[c[245371]] == c[248439] ? (window['_oE8'] = !![], window['_oE8AU'](), window['_oEAU8']()) : setTimeout(function () {
        window['_oQ8EAU']();
      }, 0x1f4);
    }, 'fail': function (nvy_u) {
      console[c[220477]](c[248440]), console[c[220477]](nvy_u), setTimeout(function () {
        window['_oQ8EAU']();
      }, 0x1f4);
    } });h8goz && h8goz[c[248441]](a3vn6 => {});
}, window['_oQAUE8'] = function () {
  console[c[220477]](c[248442]);var l6ida = wx[c[248436]]({ 'name': c[248443], 'success': function (a6nv) {
      console[c[220477]](c[248444]), console[c[220477]](a6nv), a6nv && a6nv[c[245371]] == c[248439] ? (window['_oA8E'] = !![], window['_oE8AU'](), window['_oEAU8']()) : setTimeout(function () {
        window['_oQAUE8']();
      }, 0x1f4);
    }, 'fail': function (hoz4gb) {
      console[c[220477]](c[248445]), console[c[220477]](hoz4gb), setTimeout(function () {
        window['_oQAUE8']();
      }, 0x1f4);
    } });l6ida && l6ida[c[248441]](ogxf => {});
}, window[c[248446]] = function () {
  window['_oQ8EUA'](window[c[248421]], c[248447]) >= 0x0 ? (console[c[220477]](c[248448] + window[c[248421]] + c[248449]), window['_oAU'](), window['_oQ8EAU'](), window['_oQAUE8']()) : (window['_oAEU'](c[248450], window[c[248421]]), wx[c[248429]]({ 'title': c[226349], 'content': c[248451] }));
}, window[c[248412]] = '', wx[c[248452]]({ 'success'(a62ldv) {
    window[c[248412]] = c[248453] + a62ldv[c[248454]] + c[248455] + a62ldv[c[248456]] + c[248457] + a62ldv[c[224707]] + c[248458] + a62ldv[c[220470]] + c[248459] + a62ldv[c[245155]] + c[248460] + a62ldv[c[248421]] + c[248461] + a62ldv[c[229295]], console[c[220477]](window[c[248412]]), console[c[220477]](c[248462] + a62ldv[c[248463]] + c[248464] + a62ldv[c[248465]] + c[248466] + a62ldv[c[248467]] + c[248468] + a62ldv[c[248469]] + c[248470] + a62ldv[c[248471]] + c[248472] + a62ldv[c[248473]] + c[248474] + (a62ldv[c[248475]] ? a62ldv[c[248475]][c[220317]] + ',' + a62ldv[c[248475]][c[221207]] + ',' + a62ldv[c[248475]][c[221209]] + ',' + a62ldv[c[248475]][c[221208]] : ''));var i16w = a62ldv[c[220470]] ? a62ldv[c[220470]][c[232318]]() : '',
        zhc = a62ldv[c[248456]] ? a62ldv[c[248456]][c[232318]]()[c[224694]]('\x20', '') : '';window['_oAE'][c[221068]] = i16w[c[220112]](c[248476]) != -0x1, window['_oAE'][c[231318]] = i16w[c[220112]](c[248477]) != -0x1, window['_oAE'][c[248478]] = i16w[c[220112]](c[248476]) != -0x1 || i16w[c[220112]](c[248477]) != -0x1, window['_oAE'][c[244874]] = i16w[c[220112]](c[248479]) != -0x1 || i16w[c[220112]](c[248480]) != -0x1, window['_oAE'][c[248481]] = a62ldv[c[245155]] ? a62ldv[c[245155]][c[232318]]() : '', window['_oAE']['_oQU8EA'] = ![], window['_oAE']['_oQUA8E'] = 0x2;if (i16w[c[220112]](c[248477]) != -0x1) {
      if (a62ldv[c[229295]] >= 0x18) window['_oAE']['_oQUA8E'] = 0x3;else window['_oAE']['_oQUA8E'] = 0x2;
    } else {
      if (i16w[c[220112]](c[248476]) != -0x1) {
        if (a62ldv[c[229295]] && a62ldv[c[229295]] >= 0x14) window['_oAE']['_oQUA8E'] = 0x3;else {
          if (zhc[c[220112]](c[248482]) != -0x1 || zhc[c[220112]](c[248483]) != -0x1 || zhc[c[220112]](c[248484]) != -0x1 || zhc[c[220112]](c[248485]) != -0x1 || zhc[c[220112]](c[248486]) != -0x1) window['_oAE']['_oQUA8E'] = 0x2;else window['_oAE']['_oQUA8E'] = 0x3;
        }
      } else window['_oAE']['_oQUA8E'] = 0x2;
    }console[c[220477]](c[248487] + window['_oAE']['_oQU8EA'] + c[248488] + window['_oAE']['_oQUA8E']);
  } }), wx[c[248489]]({ 'success': function (_3unyv) {
    console[c[220477]](c[248490] + _3unyv[c[224612]] + c[248491] + _3unyv[c[248492]]);
  } }), wx[c[248493]]({ 'success': function (ohgx) {
    console[c[220477]](c[248494] + ohgx[c[248495]]);
  } }), wx[c[248496]]({ 'keepScreenOn': !![] }), wx[c[248497]](function (i6lda) {
  console[c[220477]](c[248494] + i6lda[c[248495]] + c[248498] + i6lda[c[248499]]);
}), wx[c[230829]](function ($y0e_) {
  window['_o8U'] = $y0e_, window['_oEU8'] && window['_o8U'] && (console[c[220075]](c[248500] + window['_o8U'][c[220770]]), window['_oEU8'](window['_o8U']), window['_o8U'] = null);
}), window['_oQA8EU'] = 0x0, window[c[248501]] = null, wx[c[248502]](function () {
  window['_oQA8EU']++, wx[c[231891]]();if (window['_oQA8EU'] >= 0x2) {
    window['_oQA8EU'] = 0x0, console[c[220122]](c[248503]), wx[c[248504]]('0', 0x1);if (window['_oAE'] && window['_oAE'][c[221068]]) window['_oAEU'](c[248505], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});