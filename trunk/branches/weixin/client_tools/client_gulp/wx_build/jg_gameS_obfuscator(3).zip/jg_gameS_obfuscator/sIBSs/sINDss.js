var K = wx.$S;
import sw0c_xi from '../sskss/ss6ksg.js';window[K[300144]] = { 'wxVersion': window[K[300006]][K[300007]] }, window[K[300145]] = ![], window['s14X'] = 0x1, window[K[300146]] = 0x1, window['s1PX4'] = !![], window[K[300147]] = !![], window['s1MTPX4'] = '', window['s1X4'] = { 'base_cdn': K[300148], 'cdn': K[300148] }, s1X4[K[300149]] = {}, s1X4[K[300150]] = '0', s1X4[K[300079]] = window[K[300144]][K[300151]], s1X4[K[300114]] = '', s1X4['os'] = '1', s1X4[K[300152]] = K[300153], s1X4[K[300154]] = K[300155], s1X4[K[300156]] = K[300157], s1X4[K[300158]] = K[300159], s1X4[K[300160]] = K[300161], s1X4[K[300162]] = '1', s1X4[K[300163]] = '', s1X4[K[300164]] = '', s1X4[K[300165]] = 0x0, s1X4[K[300166]] = {}, s1X4[K[300167]] = parseInt(s1X4[K[300162]]), s1X4[K[300168]] = s1X4[K[300162]], s1X4[K[300022]] = {}, s1X4['s1TX'] = K[300169], s1X4[K[300170]] = ![], s1X4[K[300171]] = K[300172], s1X4[K[300173]] = Date[K[300174]](), s1X4[K[300175]] = K[300176], s1X4[K[300177]] = '_a', s1X4[K[300178]] = 0x2, s1X4[K[300020]] = 0x7c1, s1X4[K[300151]] = window[K[300144]][K[300151]], s1X4[K[300179]] = ![], s1X4[K[300106]] = ![], s1X4[K[300109]] = ![], s1X4[K[300112]] = ![], window['s1P4X'] = 0x5, window['s1P4'] = ![], window['s14P'] = ![], window['s1XP4'] = ![], window[K[300180]] = ![], window[K[300181]] = ![], window['s1X4P'] = ![], window['s1PX'] = ![], window['s1XP'] = ![], window['s14PX'] = ![], window[K[300182]] = function (h$4) {
  console[K[300041]](K[300182], h$4), wx[K[300183]]({}), wx[K[300048]]({ 'title': K[300071], 'content': h$4, 'success'(zo9vk3) {
      if (zo9vk3[K[300184]]) console[K[300041]](K[300185]);else zo9vk3[K[300186]] && console[K[300041]](K[300187]);
    } });
}, window['s1TPX4'] = function (reu34) {
  console[K[300041]](K[300188], reu34), s1TX4P(), wx[K[300048]]({ 'title': K[300071], 'content': reu34, 'confirmText': K[300189], 'cancelText': K[300190], 'success'(_xinm) {
      if (_xinm[K[300184]]) window['s1XT']();else _xinm[K[300186]] && (console[K[300041]](K[300191]), wx[K[300192]]({}));
    } });
}, window[K[300193]] = function (de45$a) {
  console[K[300041]](K[300193], de45$a), wx[K[300048]]({ 'title': K[300071], 'content': de45$a, 'confirmText': K[300194], 'showCancel': ![], 'complete'(sgyjqp) {
      console[K[300041]](K[300191]), wx[K[300192]]({});
    } });
}, window['s1TP4X'] = ![], window['s1TXP4'] = function (kzor3) {
  window['s1TP4X'] = !![], wx[K[300195]](kzor3);
}, window['s1TX4P'] = function () {
  window['s1TP4X'] && (window['s1TP4X'] = ![], wx[K[300183]]({}));
}, window['s1T4PX'] = function (a45ed) {
  window[K[300034]][K[300035]]['s1T4PX'](a45ed);
}, window[K[300196]] = function (s5phqy, sdpyh5) {
  sw0c_xi[K[300196]](s5phqy, function (_2mnx) {
    _2mnx && _2mnx[K[300197]] ? _2mnx[K[300197]][K[300198]] == 0x1 ? sdpyh5(!![]) : (sdpyh5(![]), console[K[300001]](K[300199] + _2mnx[K[300197]][K[300200]])) : console[K[300041]](K[300196], _2mnx);
  });
}, window['s1T4XP'] = function (gpsyjq) {
  console[K[300041]](K[300201], gpsyjq);
}, window['s1TX4'] = function (b8jg6) {}, window['s1T4X'] = function (gjqb, r4ou3e, a4d5e$) {}, window['s1T4'] = function (jbgq8) {
  console[K[300041]](K[300202], jbgq8), window[K[300034]][K[300035]][K[300203]](), window[K[300034]][K[300035]][K[300204]](), window[K[300034]][K[300035]][K[300205]]();
}, window['s14T'] = function (f86lb1) {
  window['s1TPX4'](K[300206]);var w0v9z = { 'id': window['s1X4'][K[300016]], 'role': window['s1X4'][K[300017]], 'level': window['s1X4'][K[300018]], 'account': window['s1X4'][K[300019]], 'version': window['s1X4'][K[300020]], 'cdn': window['s1X4'][K[300021]], 'pkgName': window['s1X4'][K[300163]], 'gamever': window[K[300006]][K[300007]], 'serverid': window['s1X4'][K[300022]] ? window['s1X4'][K[300022]][K[300023]] : 0x0, 'systemInfo': window[K[300024]], 'error': K[300207], 'stack': f86lb1 ? f86lb1 : K[300206] },
      hqygp = JSON[K[300026]](w0v9z);console[K[300027]](K[300208] + hqygp), window['s1TX'](hqygp);
}, window['s1XT4'] = function (uovzr) {
  var jgq81p = JSON[K[300209]](uovzr);jgq81p[K[300210]] = window[K[300006]][K[300007]], jgq81p[K[300211]] = window['s1X4'][K[300022]] ? window['s1X4'][K[300022]][K[300023]] : 0x0, jgq81p[K[300024]] = window[K[300024]];var re43uo = JSON[K[300026]](jgq81p);console[K[300027]](K[300212] + re43uo), window['s1TX'](re43uo);
}, window['s1X4T'] = function ($ad45h, tmx72n) {
  var phsqg = { 'id': window['s1X4'][K[300016]], 'role': window['s1X4'][K[300017]], 'level': window['s1X4'][K[300018]], 'account': window['s1X4'][K[300019]], 'version': window['s1X4'][K[300020]], 'cdn': window['s1X4'][K[300021]], 'pkgName': window['s1X4'][K[300163]], 'gamever': window[K[300006]][K[300007]], 'serverid': window['s1X4'][K[300022]] ? window['s1X4'][K[300022]][K[300023]] : 0x0, 'systemInfo': window[K[300024]], 'error': $ad45h, 'stack': tmx72n },
      ha$y = JSON[K[300026]](phsqg);console[K[300213]](K[300214] + ha$y), window['s1TX'](ha$y);
}, window['s1TX'] = function (pg8j1) {
  if (window['s1X4'][K[300115]] == K[300215]) return;var $ydha = s1X4['s1TX'] + K[300216] + s1X4[K[300019]];wx[K[300217]]({ 'url': $ydha, 'method': K[300218], 'data': pg8j1, 'header': { 'content-type': K[300219], 'cache-control': K[300220] }, 'success': function (i_m2n) {
      DEBUG && console[K[300041]](K[300221], $ydha, pg8j1, i_m2n);
    }, 'fail': function (tm7x2) {
      DEBUG && console[K[300041]](K[300221], $ydha, pg8j1, tm7x2);
    }, 'complete': function () {} });
}, window[K[300222]] = function () {
  function z0vk9() {
    return ((0x1 + Math[K[300223]]()) * 0x10000 | 0x0)[K[300224]](0x10)[K[300225]](0x1);
  }return z0vk9() + z0vk9() + '-' + z0vk9() + '-' + z0vk9() + '-' + z0vk9() + '+' + z0vk9() + z0vk9() + z0vk9();
}, window['s1XT'] = function () {
  console[K[300041]](K[300226]);var p5yhsq = sw0c_xi[K[300227]]();s1X4[K[300168]] = p5yhsq[K[300228]], s1X4[K[300167]] = p5yhsq[K[300228]], s1X4[K[300162]] = p5yhsq[K[300228]], s1X4[K[300163]] = p5yhsq[K[300229]];var ypsqgj = { 'game_ver': s1X4[K[300079]] };s1X4[K[300164]] = this[K[300222]](), s1TXP4({ 'title': K[300230] }), sw0c_xi[K[300231]](ypsqgj, this['s14TX'][K[300232]](this));
}, window['s14TX'] = function (c0_wi9) {
  var sqpg1 = c0_wi9[K[300233]];console[K[300041]](K[300234] + sqpg1 + K[300235] + (sqpg1 == 0x1) + K[300236] + c0_wi9[K[300007]] + K[300237] + window[K[300144]][K[300151]]);if (!c0_wi9[K[300007]] || window['s1MP4TX'](window[K[300144]][K[300151]], c0_wi9[K[300007]]) < 0x0) console[K[300041]](K[300238]), s1X4[K[300154]] = K[300239], s1X4[K[300156]] = K[300240], s1X4[K[300158]] = K[300241], s1X4[K[300021]] = K[300242], s1X4[K[300243]] = K[300244], s1X4[K[300245]] = K[300246], s1X4[K[300179]] = ![];else window['s1MP4TX'](window[K[300144]][K[300151]], c0_wi9[K[300007]]) == 0x0 ? (console[K[300041]](K[300247]), s1X4[K[300154]] = K[300155], s1X4[K[300156]] = K[300157], s1X4[K[300158]] = K[300159], s1X4[K[300021]] = K[300248], s1X4[K[300243]] = K[300244], s1X4[K[300245]] = K[300249], s1X4[K[300179]] = !![]) : (console[K[300041]](K[300250]), s1X4[K[300154]] = K[300155], s1X4[K[300156]] = K[300157], s1X4[K[300158]] = K[300159], s1X4[K[300021]] = K[300248], s1X4[K[300243]] = K[300244], s1X4[K[300245]] = K[300249], s1X4[K[300179]] = ![]);s1X4[K[300165]] = config[K[300251]] ? config[K[300251]] : 0x0, this['s1PXT4'](), this['s1PX4T'](), window[K[300252]] = 0x5, s1TXP4({ 'title': K[300253] }), sw0c_xi[K[300254]](this['s14XT'][K[300232]](this));
}, window[K[300252]] = 0x5, window['s14XT'] = function (wkz9c0, sq5y) {
  if (wkz9c0 == 0x0 && sq5y && sq5y[K[300255]]) {
    s1X4[K[300256]] = sq5y[K[300255]];var uvo3z = this;s1TXP4({ 'title': K[300257] }), sendApi(s1X4[K[300154]], K[300258], { 'platform': s1X4[K[300152]], 'partner_id': s1X4[K[300162]], 'token': sq5y[K[300255]], 'game_pkg': s1X4[K[300163]], 'deviceId': s1X4[K[300164]], 'scene': K[300259] + s1X4[K[300165]] }, this['s1PTX4'][K[300232]](this), s1P4X, s14T);
  } else sq5y && sq5y[K[300058]] && window[K[300252]] > 0x0 && (sq5y[K[300058]][K[300107]](K[300260]) != -0x1 || sq5y[K[300058]][K[300107]](K[300261]) != -0x1 || sq5y[K[300058]][K[300107]](K[300262]) != -0x1 || sq5y[K[300058]][K[300107]](K[300263]) != -0x1 || sq5y[K[300058]][K[300107]](K[300264]) != -0x1 || sq5y[K[300058]][K[300107]](K[300265]) != -0x1) ? (window[K[300252]]--, sw0c_xi[K[300254]](this['s14XT'][K[300232]](this))) : (window['s1X4T'](K[300266], JSON[K[300026]]({ 'status': wkz9c0, 'data': sq5y })), window['s1TPX4'](K[300267] + (sq5y && sq5y[K[300058]] ? '，' + sq5y[K[300058]] : '')));
}, window['s1PTX4'] = function (o3rvk) {
  if (!o3rvk) {
    window['s1X4T'](K[300268], K[300269]), window['s1TPX4'](K[300270]);return;
  }if (o3rvk[K[300198]] != K[300271]) {
    window['s1X4T'](K[300268], JSON[K[300026]](o3rvk)), window['s1TPX4'](K[300272] + o3rvk[K[300198]]);return;
  }s1X4[K[300273]] = String(o3rvk[K[300019]]), s1X4[K[300019]] = String(o3rvk[K[300019]]), s1X4[K[300083]] = String(o3rvk[K[300083]]), s1X4[K[300168]] = String(o3rvk[K[300083]]), s1X4[K[300274]] = String(o3rvk[K[300274]]), s1X4[K[300275]] = String(o3rvk[K[300276]]), s1X4[K[300277]] = String(o3rvk[K[300278]]), s1X4[K[300276]] = '';var f61l = this;s1TXP4({ 'title': K[300279] }), sendApi(s1X4[K[300154]], K[300280], { 'partner_id': s1X4[K[300162]], 'uid': s1X4[K[300019]], 'version': s1X4[K[300079]], 'game_pkg': s1X4[K[300163]], 'device': s1X4[K[300164]] }, f61l['s1PT4X'][K[300232]](f61l), s1P4X, s14T);
}, window['s1PT4X'] = function (pqsjg) {
  if (!pqsjg) {
    window['s1TPX4'](K[300281]);return;
  }if (pqsjg[K[300198]] != K[300271]) {
    window['s1TPX4'](K[300282] + pqsjg[K[300198]]);return;
  }if (!pqsjg[K[300197]] || pqsjg[K[300197]][K[300010]] == 0x0) {
    window['s1TPX4'](K[300283]);return;
  }s1X4[K[300284]] = pqsjg[K[300285]], s1X4[K[300022]] = { 'server_id': String(pqsjg[K[300197]][0x0][K[300023]]), 'server_name': String(pqsjg[K[300197]][0x0][K[300286]]), 'entry_ip': pqsjg[K[300197]][0x0][K[300287]], 'entry_port': parseInt(pqsjg[K[300197]][0x0][K[300288]]), 'status': s1XPT(pqsjg[K[300197]][0x0]), 'start_time': pqsjg[K[300197]][0x0][K[300289]], 'cdn': s1X4[K[300021]] }, this['s14XPT']();
}, window['s14XPT'] = function () {
  if (s1X4[K[300284]] == 0x1) {
    var ad4$ = s1X4[K[300022]][K[300290]];if (ad4$ === -0x1 || ad4$ === 0x0) {
      window['s1TPX4'](ad4$ === -0x1 ? K[300291] : K[300292]);return;
    }s14TPX(0x0, s1X4[K[300022]][K[300023]]), window[K[300034]][K[300035]][K[300293]](s1X4[K[300284]]);
  } else window[K[300034]][K[300035]][K[300294]](), s1TX4P();window['s1XP'] = !![], window['s14PXT'](), window['s14XTP']();
}, window['s1PXT4'] = function () {
  sendApi(s1X4[K[300154]], K[300295], { 'game_pkg': s1X4[K[300163]], 'version_name': s1X4[K[300245]] }, this[K[300296]][K[300232]](this), s1P4X, s14T);
}, window[K[300296]] = function (yshad5) {
  if (!yshad5) {
    window['s1TPX4'](K[300297]);return;
  }if (yshad5[K[300198]] != K[300271]) {
    window['s1TPX4'](K[300298] + yshad5[K[300198]]);return;
  }if (!yshad5[K[300197]] || !yshad5[K[300197]][K[300079]]) {
    window['s1TPX4'](K[300299] + (yshad5[K[300197]] && yshad5[K[300197]][K[300079]]));return;
  }yshad5[K[300197]][K[300300]] && yshad5[K[300197]][K[300300]][K[300010]] > 0xa && (s1X4[K[300301]] = yshad5[K[300197]][K[300300]], s1X4[K[300021]] = yshad5[K[300197]][K[300300]]), yshad5[K[300197]][K[300079]] && (s1X4[K[300020]] = yshad5[K[300197]][K[300079]]), console[K[300001]](K[300302] + s1X4[K[300020]] + K[300303] + s1X4[K[300245]]), window['s1X4P'] = !![], window['s14PXT'](), window['s14XTP']();
}, window[K[300304]], window['s1PX4T'] = function () {
  sendApi(s1X4[K[300154]], K[300305], { 'game_pkg': s1X4[K[300163]] }, this['s1P4TX'][K[300232]](this), s1P4X, s14T);
}, window['s1P4TX'] = function (_9cw) {
  if (_9cw[K[300198]] === K[300271] && _9cw[K[300197]]) {
    window[K[300304]] = _9cw[K[300197]];for (var da4e$u in _9cw[K[300197]]) {
      s1X4[da4e$u] = _9cw[K[300197]][da4e$u];
    }
  } else console[K[300001]](K[300306] + _9cw[K[300198]]);window['s1PX'] = !![], window['s14XTP']();
}, window[K[300307]] = function (jsq1g, as5hy, lfb16, vzr3k, de5$a, _imnx, hsa5yd, gb16j, d4$uae) {
  de5$a = String(de5$a);var oe4r3u = hsa5yd,
      c0w_xi = gb16j;s1X4[K[300149]][de5$a] = { 'productid': de5$a, 'productname': oe4r3u, 'productdesc': c0w_xi, 'roleid': jsq1g, 'rolename': as5hy, 'rolelevel': lfb16, 'price': _imnx, 'callback': d4$uae }, sendApi(s1X4[K[300158]], K[300308], { 'game_pkg': s1X4[K[300163]], 'server_id': s1X4[K[300022]][K[300023]], 'server_name': s1X4[K[300022]][K[300286]], 'level': lfb16, 'uid': s1X4[K[300019]], 'role_id': jsq1g, 'role_name': as5hy, 'product_id': de5$a, 'product_name': oe4r3u, 'product_desc': c0w_xi, 'money': _imnx, 'partner_id': s1X4[K[300162]] }, toPayCallBack, s1P4X, s14T);
}, window[K[300309]] = function (roz3) {
  if (roz3) {
    if (roz3[K[300310]] === 0xc8 || roz3[K[300198]] == K[300271]) {
      var pqh = s1X4[K[300149]][String(roz3[K[300311]])];if (pqh[K[300312]]) pqh[K[300312]](roz3[K[300311]], roz3[K[300313]], -0x1);sw0c_xi[K[300314]]({ 'cpbill': roz3[K[300313]], 'productid': roz3[K[300311]], 'productname': pqh[K[300315]], 'productdesc': pqh[K[300316]], 'serverid': s1X4[K[300022]][K[300023]], 'servername': s1X4[K[300022]][K[300286]], 'roleid': pqh[K[300317]], 'rolename': pqh[K[300318]], 'rolelevel': pqh[K[300319]], 'price': pqh[K[300320]], 'extension': JSON[K[300026]]({ 'cp_order_id': roz3[K[300313]] }) }, function (o9zvkw, mxic_0) {
        pqh[K[300312]] && o9zvkw == 0x0 && pqh[K[300312]](roz3[K[300311]], roz3[K[300313]], o9zvkw);console[K[300001]](JSON[K[300026]]({ 'type': K[300321], 'status': o9zvkw, 'data': roz3, 'role_name': pqh[K[300318]] }));if (o9zvkw === 0x0) {} else {
          if (o9zvkw === 0x1) {} else {
            if (o9zvkw === 0x2) {}
          }
        }
      });
    } else alert(roz3[K[300001]]);
  }
}, window['s1P4XT'] = function () {}, window['s1TP4'] = function (er3uo, j618gb, xmn2it, e$uar4, shyda5) {
  sw0c_xi[K[300322]](s1X4[K[300022]][K[300023]], s1X4[K[300022]][K[300286]] || s1X4[K[300022]][K[300023]], er3uo, j618gb, xmn2it), sendApi(s1X4[K[300154]], K[300323], { 'game_pkg': s1X4[K[300163]], 'server_id': s1X4[K[300022]][K[300023]], 'role_id': er3uo, 'uid': s1X4[K[300019]], 'role_name': j618gb, 'role_type': e$uar4, 'level': xmn2it });
}, window['s1T4P'] = function (h5p, t2x7, ps5, o3uerv, qp81, g61j8, itmxn2, pqshgy, x0_cm, sad5h) {
  s1X4[K[300016]] = h5p, s1X4[K[300017]] = t2x7, s1X4[K[300018]] = ps5, sw0c_xi[K[300324]](s1X4[K[300022]][K[300023]], s1X4[K[300022]][K[300286]] || s1X4[K[300022]][K[300023]], h5p, t2x7, ps5), sendApi(s1X4[K[300154]], K[300325], { 'game_pkg': s1X4[K[300163]], 'server_id': s1X4[K[300022]][K[300023]], 'role_id': h5p, 'uid': s1X4[K[300019]], 'role_name': t2x7, 'role_type': o3uerv, 'level': ps5, 'evolution': qp81 });
}, window['s1PT4'] = function (_2inx, i0xm, xc_w0, b61j8, h5sypq, uae4, kw0z, c_0xwi, $4ha5d, o39k) {
  s1X4[K[300016]] = _2inx, s1X4[K[300017]] = i0xm, s1X4[K[300018]] = xc_w0, sw0c_xi[K[300326]](s1X4[K[300022]][K[300023]], s1X4[K[300022]][K[300286]] || s1X4[K[300022]][K[300023]], _2inx, i0xm, xc_w0), sendApi(s1X4[K[300154]], K[300325], { 'game_pkg': s1X4[K[300163]], 'server_id': s1X4[K[300022]][K[300023]], 'role_id': _2inx, 'uid': s1X4[K[300019]], 'role_name': i0xm, 'role_type': b61j8, 'level': xc_w0, 'evolution': h5sypq });
}, window['s1P4T'] = function (b618jl) {}, window['s1TP'] = function (g8b1qj) {
  sw0c_xi[K[300327]](K[300327], function (_wci09) {
    g8b1qj && g8b1qj(_wci09);
  });
}, window[K[300328]] = function () {
  sw0c_xi[K[300328]]();
}, window[K[300329]] = function () {
  sw0c_xi[K[300330]]();
}, window[K[300135]] = function (p5shyd) {
  window['s14TP'] = p5shyd, window['s14TP'] && window['s1PT'] && (console[K[300001]](K[300136] + window['s1PT'][K[300137]]), window['s14TP'](window['s1PT']), window['s1PT'] = null);
}, window['s14PT'] = function (yhd$5, vozk9w, jq1pg8, y$dah) {
  window[K[300331]](K[300332], { 'game_pkg': window['s1X4'][K[300163]], 'role_id': vozk9w, 'server_id': jq1pg8 }, y$dah);
}, window['s1XTP4'] = function (n2mit, _xcw0i) {
  function h$45d(oe3urv) {
    var k3vzo9 = [],
        wic09 = [],
        k3zovr = window[K[300006]][K[300333]];for (var zw0c9k in k3zovr) {
      var z9vo3 = Number(zw0c9k);(!n2mit || !n2mit[K[300010]] || n2mit[K[300107]](z9vo3) != -0x1) && (wic09[K[300038]](k3zovr[zw0c9k]), k3vzo9[K[300038]]([z9vo3, 0x3]));
    }window['s1MP4TX'](window[K[300039]], K[300334]) >= 0x0 ? (console[K[300041]](K[300335]), sw0c_xi[K[300336]] && sw0c_xi[K[300336]](wic09, function (ayhd5s) {
      console[K[300041]](K[300337]), console[K[300041]](ayhd5s);if (ayhd5s && ayhd5s[K[300058]] == K[300338]) for (var yhdp in k3zovr) {
        if (ayhd5s[k3zovr[yhdp]] == K[300339]) {
          var au$4d = Number(yhdp);for (var n7x2t = 0x0; n7x2t < k3vzo9[K[300010]]; n7x2t++) {
            if (k3vzo9[n7x2t][0x0] == au$4d) {
              k3vzo9[n7x2t][0x1] = 0x1;break;
            }
          }
        }
      }window['s1MP4TX'](window[K[300039]], K[300340]) >= 0x0 ? wx[K[300341]]({ 'withSubscriptions': !![], 'success': function (ar4ue$) {
          var psghq = ar4ue$[K[300342]][K[300343]];if (psghq) {
            console[K[300041]](K[300344]), console[K[300041]](psghq);for (var cim2_ in k3zovr) {
              if (psghq[k3zovr[cim2_]] == K[300339]) {
                var gbj61 = Number(cim2_);for (var i_2cx = 0x0; i_2cx < k3vzo9[K[300010]]; i_2cx++) {
                  if (k3vzo9[i_2cx][0x0] == gbj61) {
                    k3vzo9[i_2cx][0x1] = 0x2;break;
                  }
                }
              }
            }console[K[300041]](k3vzo9), _xcw0i && _xcw0i(k3vzo9);
          } else console[K[300041]](K[300345]), console[K[300041]](ar4ue$), console[K[300041]](k3vzo9), _xcw0i && _xcw0i(k3vzo9);
        }, 'fail': function () {
          console[K[300041]](K[300346]), console[K[300041]](k3vzo9), _xcw0i && _xcw0i(k3vzo9);
        } }) : (console[K[300041]](K[300347] + window[K[300039]]), console[K[300041]](k3vzo9), _xcw0i && _xcw0i(k3vzo9));
    })) : (console[K[300041]](K[300348] + window[K[300039]]), console[K[300041]](k3vzo9), _xcw0i && _xcw0i(k3vzo9)), wx[K[300349]](h$45d);
  }wx[K[300350]](h$45d);
}, window['s1XT4P'] = { 'isSuccess': ![], 'level': K[300351], 'isCharging': ![] }, window['s1XPT4'] = function (e4d$) {
  wx[K[300123]]({ 'success': function (a$5d) {
      var wc0kz9 = window['s1XT4P'];wc0kz9[K[300352]] = !![], wc0kz9[K[300125]] = Number(a$5d[K[300125]])[K[300353]](0x0), wc0kz9[K[300127]] = a$5d[K[300127]], e4d$ && e4d$(wc0kz9[K[300352]], wc0kz9[K[300125]], wc0kz9[K[300127]]);
    }, 'fail': function (w0v9) {
      console[K[300041]](K[300354], w0v9[K[300058]]);var jgpyqs = window['s1XT4P'];e4d$ && e4d$(jgpyqs[K[300352]], jgpyqs[K[300125]], jgpyqs[K[300127]]);
    } });
}, window[K[300331]] = function (adyh5s, j18l6, kr3ovz, b16l, erau4$, vrz3uo, orue3v, s5ypq) {
  if (b16l == undefined) b16l = 0x1;wx[K[300217]]({ 'url': adyh5s, 'method': orue3v || K[300355], 'responseType': K[300356], 'data': j18l6, 'header': { 'content-type': s5ypq || K[300219] }, 'success': function (sa5ydh) {
      DEBUG && console[K[300041]](K[300357], adyh5s, info, sa5ydh);if (sa5ydh && sa5ydh[K[300358]] == 0xc8) {
        var u$era4 = sa5ydh[K[300197]];!vrz3uo || vrz3uo(u$era4) ? kr3ovz && kr3ovz(u$era4) : window[K[300359]](adyh5s, j18l6, kr3ovz, b16l, erau4$, vrz3uo, sa5ydh);
      } else window[K[300359]](adyh5s, j18l6, kr3ovz, b16l, erau4$, vrz3uo, sa5ydh);
    }, 'fail': function (x_w0ic) {
      DEBUG && console[K[300041]](K[300360], adyh5s, info, x_w0ic), window[K[300359]](adyh5s, j18l6, kr3ovz, b16l, erau4$, vrz3uo, x_w0ic);
    }, 'complete': function () {} });
}, window[K[300359]] = function (qhgpsy, kwoz, m2_nxi, ru3vz, g168j, kzvo, a4$d5) {
  ru3vz - 0x1 > 0x0 ? setTimeout(function () {
    window[K[300331]](qhgpsy, kwoz, m2_nxi, ru3vz - 0x1, g168j, kzvo);
  }, 0x3e8) : g168j && g168j(JSON[K[300026]]({ 'url': qhgpsy, 'response': a4$d5 }));
}, window[K[300361]] = function (ur3z, lb8j16, wc09k_, r3zko, h5$ya, a$ud4e, phq5y) {
  !wc09k_ && (wc09k_ = {});var ady$5 = Math[K[300362]](Date[K[300174]]() / 0x3e8);wc09k_[K[300278]] = ady$5, wc09k_[K[300363]] = lb8j16;var w0_9kc = Object[K[300364]](wc09k_)[K[300365]](),
      c_w0k = '',
      phq5 = '';for (var yshd5p = 0x0; yshd5p < w0_9kc[K[300010]]; yshd5p++) {
    c_w0k = c_w0k + (yshd5p == 0x0 ? '' : '&') + w0_9kc[yshd5p] + wc09k_[w0_9kc[yshd5p]], phq5 = phq5 + (yshd5p == 0x0 ? '' : '&') + w0_9kc[yshd5p] + '=' + encodeURIComponent(wc09k_[w0_9kc[yshd5p]]);
  }c_w0k = c_w0k + s1X4[K[300160]];var cx0_i = K[300366] + md5(c_w0k);send(ur3z + '?' + phq5 + (phq5 == '' ? '' : '&') + cx0_i, null, r3zko, h5$ya, a$ud4e, phq5y || function (vkz39) {
    return vkz39[K[300198]] == K[300271];
  }, null, K[300367]);
}, window['s1XP4T'] = function (syhda, yh$5ad) {
  var i_9wc = 0x0;s1X4[K[300022]] && (i_9wc = s1X4[K[300022]][K[300023]]), sendApi(s1X4[K[300156]], K[300368], { 'partnerId': s1X4[K[300162]], 'gamePkg': s1X4[K[300163]], 'logTime': Math[K[300362]](Date[K[300174]]() / 0x3e8), 'platformUid': s1X4[K[300274]], 'type': syhda, 'serverId': i_9wc }, null, 0x2, null, function () {
    return !![];
  });
}, window['s1X4TP'] = function (kw0c) {
  sendApi(s1X4[K[300154]], K[300369], { 'partner_id': s1X4[K[300162]], 'uid': s1X4[K[300019]], 'version': s1X4[K[300079]], 'game_pkg': s1X4[K[300163]], 'device': s1X4[K[300164]] }, s1X4PT, s1P4X, s14T);
}, window['s1X4PT'] = function (cwi9_) {
  if (cwi9_[K[300198]] === K[300271] && cwi9_[K[300197]]) {
    cwi9_[K[300197]][K[300370]]({ 'id': -0x2, 'name': K[300371] }), cwi9_[K[300197]][K[300370]]({ 'id': -0x1, 'name': K[300372] }), s1X4[K[300373]] = cwi9_[K[300197]];if (window[K[300374]]) window[K[300374]][K[300375]]();
  } else s1X4[K[300376]] = ![], window['s1TPX4'](K[300377] + cwi9_[K[300198]]);
}, window['s1TPX'] = function (cw09_) {
  sendApi(s1X4[K[300154]], K[300378], { 'partner_id': s1X4[K[300162]], 'uid': s1X4[K[300019]], 'version': s1X4[K[300079]], 'game_pkg': s1X4[K[300163]], 'device': s1X4[K[300164]] }, s1TXP, s1P4X, s14T);
}, window['s1TXP'] = function (b61) {
  s1X4[K[300379]] = ![];if (b61[K[300198]] === K[300271] && b61[K[300197]]) {
    for (var c_m0i = 0x0; c_m0i < b61[K[300197]][K[300010]]; c_m0i++) {
      b61[K[300197]][c_m0i][K[300290]] = s1XPT(b61[K[300197]][c_m0i]);
    }s1X4[K[300166]][-0x1] = window[K[300380]](b61[K[300197]]), window[K[300374]][K[300381]](-0x1);
  } else window['s1TPX4'](K[300382] + b61[K[300198]]);
}, window[K[300383]] = function (hd5sya) {
  sendApi(s1X4[K[300154]], K[300378], { 'partner_id': s1X4[K[300162]], 'uid': s1X4[K[300019]], 'version': s1X4[K[300079]], 'game_pkg': s1X4[K[300163]], 'device': s1X4[K[300164]] }, hd5sya, s1P4X, s14T);
}, window['s1PTX'] = function (iw_c90, $h4d5a) {
  sendApi(s1X4[K[300154]], K[300384], { 'partner_id': s1X4[K[300162]], 'uid': s1X4[K[300019]], 'version': s1X4[K[300079]], 'game_pkg': s1X4[K[300163]], 'device': s1X4[K[300164]], 'server_group_id': $h4d5a }, s1PXT, s1P4X, s14T);
}, window['s1PXT'] = function (min) {
  s1X4[K[300379]] = ![];if (min[K[300198]] === K[300271] && min[K[300197]] && min[K[300197]][K[300197]]) {
    var j81pg = min[K[300197]][K[300385]],
        ed4ua$ = [];for (var t2mn7x = 0x0; t2mn7x < min[K[300197]][K[300197]][K[300010]]; t2mn7x++) {
      min[K[300197]][K[300197]][t2mn7x][K[300290]] = s1XPT(min[K[300197]][K[300197]][t2mn7x]), (ed4ua$[K[300010]] == 0x0 || min[K[300197]][K[300197]][t2mn7x][K[300290]] != 0x0) && (ed4ua$[ed4ua$[K[300010]]] = min[K[300197]][K[300197]][t2mn7x]);
    }s1X4[K[300166]][j81pg] = window[K[300380]](ed4ua$), window[K[300374]][K[300381]](j81pg);
  } else window['s1TPX4'](K[300386] + min[K[300198]]);
}, window['s1MP4X'] = function (ead$) {
  sendApi(s1X4[K[300154]], K[300387], { 'partner_id': s1X4[K[300162]], 'uid': s1X4[K[300019]], 'version': s1X4[K[300079]], 'game_pkg': s1X4[K[300163]], 'device': s1X4[K[300164]] }, reqServerRecommendCallBack, s1P4X, s14T);
}, window[K[300388]] = function (ua4$d) {
  s1X4[K[300379]] = ![];if (ua4$d[K[300198]] === K[300271] && ua4$d[K[300197]]) {
    for (var hys5p = 0x0; hys5p < ua4$d[K[300197]][K[300010]]; hys5p++) {
      ua4$d[K[300197]][hys5p][K[300290]] = s1XPT(ua4$d[K[300197]][hys5p]);
    }s1X4[K[300166]][-0x2] = window[K[300380]](ua4$d[K[300197]]), window[K[300374]][K[300381]](-0x2);
  } else alert(K[300389] + ua4$d[K[300198]]);
}, window[K[300380]] = function (b81g6j) {
  if (!b81g6j && b81g6j[K[300010]] <= 0x0) return b81g6j;for (let pd5ys = 0x0; pd5ys < b81g6j[K[300010]]; pd5ys++) {
    b81g6j[pd5ys][K[300390]] && b81g6j[pd5ys][K[300390]] == 0x1 && (b81g6j[pd5ys][K[300286]] += K[300391]);
  }return b81g6j;
}, window['s1XTP'] = function (u$3, iw_0x) {
  u$3 = u$3 || s1X4[K[300022]][K[300023]], sendApi(s1X4[K[300154]], K[300392], { 'type': '4', 'game_pkg': s1X4[K[300163]], 'server_id': u$3 }, iw_0x);
}, window[K[300393]] = function (k3vz9o, m7x, dh$ya, z90w) {
  dh$ya = dh$ya || s1X4[K[300022]][K[300023]], sendApi(s1X4[K[300154]], K[300394], { 'type': k3vz9o, 'game_pkg': m7x, 'server_id': dh$ya }, z90w);
}, window['s1XPT'] = function (c2mxi) {
  if (c2mxi) {
    if (c2mxi[K[300290]] == 0x1) {
      if (c2mxi[K[300395]] == 0x1) return 0x2;else return 0x1;
    } else return c2mxi[K[300290]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['s14TPX'] = function (ni2mt, urzv3o) {
  s1X4[K[300396]] = { 'step': ni2mt, 'server_id': urzv3o };var _0ck = this;s1TXP4({ 'title': K[300397] }), sendApi(s1X4[K[300154]], K[300398], { 'partner_id': s1X4[K[300162]], 'uid': s1X4[K[300019]], 'game_pkg': s1X4[K[300163]], 'server_id': urzv3o, 'platform': s1X4[K[300083]], 'platform_uid': s1X4[K[300274]], 'check_login_time': s1X4[K[300277]], 'check_login_sign': s1X4[K[300275]], 'version_name': s1X4[K[300245]] }, s14TXP, s1P4X, s14T, function (_x0icm) {
    return _x0icm[K[300198]] == K[300271] || _x0icm[K[300001]] == K[300399] || _x0icm[K[300001]] == K[300400];
  });
}, window['s14TXP'] = function (a4$e) {
  var cz9k0w = this;if (a4$e[K[300198]] === K[300271] && a4$e[K[300197]]) {
    var ozwk = s1X4[K[300022]];ozwk[K[300401]] = s1X4[K[300167]], ozwk[K[300276]] = String(a4$e[K[300197]][K[300402]]), ozwk[K[300173]] = parseInt(a4$e[K[300197]][K[300278]]);if (a4$e[K[300197]][K[300403]]) ozwk[K[300403]] = parseInt(a4$e[K[300197]][K[300403]]);else ozwk[K[300403]] = parseInt(a4$e[K[300197]][K[300023]]);ozwk[K[300404]] = 0x0, ozwk[K[300021]] = s1X4[K[300301]], ozwk[K[300405]] = a4$e[K[300197]][K[300406]], ozwk[K[300407]] = a4$e[K[300197]][K[300407]], console[K[300041]](K[300408] + JSON[K[300026]](ozwk[K[300407]])), s1X4[K[300284]] == 0x1 && ozwk[K[300407]] && ozwk[K[300407]][K[300409]] == 0x1 && (s1X4[K[300410]] = 0x1, window[K[300034]][K[300035]]['s1M4X']()), s14PTX();
  } else s1X4[K[300396]][K[300411]] >= 0x3 ? (s14T(JSON[K[300026]](a4$e)), window['s1TPX4'](K[300412] + a4$e[K[300198]])) : sendApi(s1X4[K[300154]], K[300258], { 'platform': s1X4[K[300152]], 'partner_id': s1X4[K[300162]], 'token': s1X4[K[300256]], 'game_pkg': s1X4[K[300163]], 'deviceId': s1X4[K[300164]], 'scene': K[300259] + s1X4[K[300165]] }, function (qgj1sp) {
    if (!qgj1sp || qgj1sp[K[300198]] != K[300271]) {
      window['s1TPX4'](K[300272] + qgj1sp && qgj1sp[K[300198]]);return;
    }s1X4[K[300275]] = String(qgj1sp[K[300276]]), s1X4[K[300277]] = String(qgj1sp[K[300278]]), setTimeout(function () {
      s14TPX(s1X4[K[300396]][K[300411]] + 0x1, s1X4[K[300396]][K[300023]]);
    }, 0x5dc);
  }, s1P4X, s14T, function ($dha45) {
    return $dha45[K[300198]] == K[300271] || $dha45[K[300198]] == K[300413];
  });
}, window['s14PTX'] = function () {
  ServerLoading[K[300035]][K[300293]](s1X4[K[300284]]), window['s1P4'] = !![], window['s14XTP']();
}, window['s14PXT'] = function () {
  if (window['s14P'] && window['s1XP4'] && window[K[300180]] && window[K[300181]] && window['s1X4P'] && window['s1XP']) {
    if (!window[K[300414]][K[300035]]) {
      console[K[300041]](K[300415] + window[K[300414]][K[300035]]);var g81qp = wx[K[300416]](),
          ah5$d4 = g81qp[K[300137]] ? g81qp[K[300137]] : 0x0,
          imt2n = { 'cdn': window['s1X4'][K[300021]], 'spareCdn': window['s1X4'][K[300243]], 'newRegister': window['s1X4'][K[300284]], 'wxPC': window['s1X4'][K[300112]], 'wxIOS': window['s1X4'][K[300106]], 'wxAndroid': window['s1X4'][K[300109]], 'wxParam': { 'limitLoad': window['s1X4']['s1MTP4X'], 'benchmarkLevel': window['s1X4']['s1MTXP4'], 'wxFrom': window[K[300006]][K[300251]] == K[300417] ? 0x1 : 0x0, 'wxSDKVersion': window[K[300039]] }, 'configType': window['s1X4'][K[300175]], 'exposeType': window['s1X4'][K[300177]], 'scene': ah5$d4 };new window[K[300414]](imt2n, window['s1X4'][K[300020]], window['s1MTPX4']);
    }
  }
}, window['s14XTP'] = function () {
  if (window['s14P'] && window['s1XP4'] && window[K[300180]] && window[K[300181]] && window['s1X4P'] && window['s1XP'] && window['s1P4'] && window['s1PX']) {
    s1TX4P();if (!s14PX) {
      s14PX = !![];if (!window[K[300414]][K[300035]]) window['s14PXT']();var d$aue = 0x0,
          jspqgy = wx[K[300418]]();jspqgy && (window['s1X4'][K[300111]] && (d$aue = jspqgy[K[300101]]), console[K[300001]](K[300419] + jspqgy[K[300101]] + K[300420] + jspqgy[K[300102]] + K[300421] + jspqgy[K[300103]] + K[300422] + jspqgy[K[300104]] + K[300423] + jspqgy[K[300424]] + K[300425] + jspqgy[K[300426]]));var jl1 = {};for (const pgjsq1 in s1X4[K[300022]]) {
        jl1[pgjsq1] = s1X4[K[300022]][pgjsq1];
      }var zk0c9w = { 'channel': window['s1X4'][K[300168]], 'account': window['s1X4'][K[300019]], 'userId': window['s1X4'][K[300273]], 'cdn': window['s1X4'][K[300021]], 'data': window['s1X4'][K[300197]], 'package': window['s1X4'][K[300150]], 'newRegister': window['s1X4'][K[300284]], 'pkgName': window['s1X4'][K[300163]], 'partnerId': window['s1X4'][K[300162]], 'platform_uid': window['s1X4'][K[300274]], 'deviceId': window['s1X4'][K[300164]], 'selectedServer': jl1, 'configType': window['s1X4'][K[300175]], 'exposeType': window['s1X4'][K[300177]], 'debugUsers': window['s1X4'][K[300171]], 'wxMenuTop': d$aue, 'wxShield': window['s1X4'][K[300179]] };if (window[K[300304]]) for (var zc9wk in window[K[300304]]) {
        zk0c9w[zc9wk] = window[K[300304]][zc9wk];
      }window[K[300414]][K[300035]]['s14XM'](zk0c9w), setTimeout(() => {
        !s1X4[K[300179]] && new minitool();
      }, 0x2710);
    }
  } else console[K[300001]](K[300427] + window['s14P'] + K[300428] + window['s1XP4'] + K[300429] + window[K[300180]] + K[300430] + window[K[300181]] + K[300431] + window['s1X4P'] + K[300432] + window['s1XP'] + K[300433] + window['s1P4'] + K[300434] + window['s1PX']);
};