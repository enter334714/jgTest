var K = wx.$S;
import 'ssMAINrs.js';