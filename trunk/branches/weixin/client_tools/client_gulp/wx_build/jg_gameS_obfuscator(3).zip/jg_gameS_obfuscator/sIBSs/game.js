var K = wx.$S;
require(K[300000]);