var K = wx.$S;
console[K[300001]](K[300002]), window[K[300003]], wx[K[300004]](function (rvk3zo) {
  if (rvk3zo) {
    if (rvk3zo[K[300005]]) {
      var ovz3kr = window[K[300006]][K[300007]][K[300008]](new RegExp(/\./, 'g'), '_'),
          dash5 = rvk3zo[K[300005]],
          yh5pds = dash5[K[300009]](/(smmms\/sGAMEss.js:)[0-9]{1,60}(:)/g);if (yh5pds) for (var zv9wko = 0x0; zv9wko < yh5pds[K[300010]]; zv9wko++) {
        if (yh5pds[zv9wko] && yh5pds[zv9wko][K[300010]] > 0x0) {
          var ysh5d = parseInt(yh5pds[zv9wko][K[300008]](K[300011], '')[K[300008]](':', ''));dash5 = dash5[K[300008]](yh5pds[zv9wko], yh5pds[zv9wko][K[300008]](':' + ysh5d + ':', ':' + (ysh5d - 0x2) + ':'));
        }
      }dash5 = dash5[K[300008]](new RegExp(K[300012], 'g'), K[300013] + ovz3kr + K[300014]), dash5 = dash5[K[300008]](new RegExp(K[300015], 'g'), K[300013] + ovz3kr + K[300014]), rvk3zo[K[300005]] = dash5;
    }var w_9ci = { 'id': window['s1X4'][K[300016]], 'role': window['s1X4'][K[300017]], 'level': window['s1X4'][K[300018]], 'user': window['s1X4'][K[300019]], 'version': window['s1X4'][K[300020]], 'gamever': window[K[300006]][K[300007]], 'cdn': window['s1X4'][K[300021]], 'serverid': window['s1X4'][K[300022]] ? window['s1X4'][K[300022]][K[300023]] : 0x0, 'systemInfo': window[K[300024]], 'error': K[300025], 'stack': rvk3zo ? rvk3zo[K[300005]] : '' },
        icm_2x = JSON[K[300026]](w_9ci);console[K[300027]](K[300028] + icm_2x), (!window[K[300003]] || window[K[300003]] != w_9ci[K[300027]]) && (window[K[300003]] = w_9ci[K[300027]], window['s1TX'](w_9ci));
  }
});import 'ssfss.js';import 'ss12s.js';window[K[300029]] = require(K[300030]);import 'sINDss.js';import 'ssLIB12ss.js';import 'sWXMsadss.js';import 'ssINITsss.js';import 'SyMiniTool.js';console[K[300001]](K[300031]), console[K[300001]](K[300032]), s1TXP4({ 'title': K[300033] });var ssqy5h = { 's1MT4XP': !![] };new window[K[300034]](ssqy5h), window[K[300034]][K[300035]]['s1MPX4T']();if (window['s1MTX4P']) clearInterval(window['s1MTX4P']);window['s1MTX4P'] = null, window['s1MP4TX'] = function (pq18gj, wc90k) {
  if (!pq18gj || !wc90k) return 0x0;pq18gj = pq18gj[K[300036]]('.'), wc90k = wc90k[K[300036]]('.');const ead4$5 = Math[K[300037]](pq18gj[K[300010]], wc90k[K[300010]]);while (pq18gj[K[300010]] < ead4$5) {
    pq18gj[K[300038]]('0');
  }while (wc90k[K[300010]] < ead4$5) {
    wc90k[K[300038]]('0');
  }for (var syjgqp = 0x0; syjgqp < ead4$5; syjgqp++) {
    const sp5h = parseInt(pq18gj[syjgqp]),
          e54$a = parseInt(wc90k[syjgqp]);if (sp5h > e54$a) return 0x1;else {
      if (sp5h < e54$a) return -0x1;
    }
  }return 0x0;
}, window[K[300039]] = wx[K[300040]]()[K[300039]], console[K[300041]](K[300042] + window[K[300039]]);var sc_xmi0 = wx[K[300043]]();sc_xmi0[K[300044]](function (cw09i) {
  console[K[300041]](K[300045] + cw09i[K[300046]]);
}), sc_xmi0[K[300047]](function () {
  wx[K[300048]]({ 'title': K[300049], 'content': K[300050], 'showCancel': ![], 'success': function ($dy5h) {
      sc_xmi0[K[300051]]();
    } });
}), sc_xmi0[K[300052]](function () {
  console[K[300041]](K[300053]);
}), window['s1MP4XT'] = function () {
  console[K[300041]](K[300054]);var q8g1jp = wx[K[300055]]({ 'name': K[300056], 'success': function (qygspj) {
      console[K[300041]](K[300057]), console[K[300041]](qygspj), qygspj && qygspj[K[300058]] == K[300059] ? (window['s14P'] = !![], window['s14PXT'](), window['s14XTP']()) : setTimeout(function () {
        window['s1MP4XT']();
      }, 0x1f4);
    }, 'fail': function (_mx2) {
      console[K[300041]](K[300060]), console[K[300041]](_mx2), setTimeout(function () {
        window['s1MP4XT']();
      }, 0x1f4);
    } });q8g1jp && q8g1jp[K[300061]](cw_x0 => {});
}, window['s1MXT4P'] = function () {
  console[K[300041]](K[300062]);var qs5py = wx[K[300055]]({ 'name': K[300063], 'success': function (in2tx) {
      console[K[300041]](K[300064]), console[K[300041]](in2tx), in2tx && in2tx[K[300058]] == K[300059] ? (window['s1XP4'] = !![], window['s14PXT'](), window['s14XTP']()) : setTimeout(function () {
        window['s1MXT4P']();
      }, 0x1f4);
    }, 'fail': function (mnt27x) {
      console[K[300041]](K[300065]), console[K[300041]](mnt27x), setTimeout(function () {
        window['s1MXT4P']();
      }, 0x1f4);
    } });qs5py && qs5py[K[300061]](j6bl1 => {});
}, window[K[300066]] = function () {
  window['s1MP4TX'](window[K[300039]], K[300067]) >= 0x0 ? (console[K[300041]](K[300068] + window[K[300039]] + K[300069]), window['s1XT'](), window['s1MP4XT'](), window['s1MXT4P']()) : (window['s1X4T'](K[300070], window[K[300039]]), wx[K[300048]]({ 'title': K[300071], 'content': K[300072] }));
}, window[K[300024]] = '', wx[K[300073]]({ 'success'(zok3rv) {
    window[K[300024]] = K[300074] + zok3rv[K[300075]] + K[300076] + zok3rv[K[300077]] + K[300078] + zok3rv[K[300079]] + K[300080] + zok3rv[K[300081]] + K[300082] + zok3rv[K[300083]] + K[300084] + zok3rv[K[300039]] + K[300085] + zok3rv[K[300086]], console[K[300041]](window[K[300024]]), console[K[300041]](K[300087] + zok3rv[K[300088]] + K[300089] + zok3rv[K[300090]] + K[300091] + zok3rv[K[300092]] + K[300093] + zok3rv[K[300094]] + K[300095] + zok3rv[K[300096]] + K[300097] + zok3rv[K[300098]] + K[300099] + (zok3rv[K[300100]] ? zok3rv[K[300100]][K[300101]] + ',' + zok3rv[K[300100]][K[300102]] + ',' + zok3rv[K[300100]][K[300103]] + ',' + zok3rv[K[300100]][K[300104]] : ''));var urev3 = zok3rv[K[300081]] ? zok3rv[K[300081]][K[300105]]() : '',
        f8l1b6 = zok3rv[K[300077]] ? zok3rv[K[300077]][K[300105]]()[K[300008]]('\x20', '') : '';window['s1X4'][K[300106]] = urev3[K[300107]](K[300108]) != -0x1, window['s1X4'][K[300109]] = urev3[K[300107]](K[300110]) != -0x1, window['s1X4'][K[300111]] = urev3[K[300107]](K[300108]) != -0x1 || urev3[K[300107]](K[300110]) != -0x1, window['s1X4'][K[300112]] = urev3[K[300107]](K[300113]) != -0x1 || urev3[K[300107]](K[300114]) != -0x1, window['s1X4'][K[300115]] = zok3rv[K[300083]] ? zok3rv[K[300083]][K[300105]]() : '', window['s1X4']['s1MTP4X'] = ![], window['s1X4']['s1MTXP4'] = 0x2;if (urev3[K[300107]](K[300110]) != -0x1) {
      if (zok3rv[K[300086]] >= 0x18) window['s1X4']['s1MTXP4'] = 0x3;else window['s1X4']['s1MTXP4'] = 0x2;
    } else {
      if (urev3[K[300107]](K[300108]) != -0x1) {
        if (zok3rv[K[300086]] && zok3rv[K[300086]] >= 0x14) window['s1X4']['s1MTXP4'] = 0x3;else {
          if (f8l1b6[K[300107]](K[300116]) != -0x1 || f8l1b6[K[300107]](K[300117]) != -0x1 || f8l1b6[K[300107]](K[300118]) != -0x1 || f8l1b6[K[300107]](K[300119]) != -0x1 || f8l1b6[K[300107]](K[300120]) != -0x1) window['s1X4']['s1MTXP4'] = 0x2;else window['s1X4']['s1MTXP4'] = 0x3;
        }
      } else window['s1X4']['s1MTXP4'] = 0x2;
    }console[K[300041]](K[300121] + window['s1X4']['s1MTP4X'] + K[300122] + window['s1X4']['s1MTXP4']);
  } }), wx[K[300123]]({ 'success': function (okvrz3) {
    console[K[300041]](K[300124] + okvrz3[K[300125]] + K[300126] + okvrz3[K[300127]]);
  } }), wx[K[300128]]({ 'success': function (tx27n) {
    console[K[300041]](K[300129] + tx27n[K[300130]]);
  } }), wx[K[300131]]({ 'keepScreenOn': !![] }), wx[K[300132]](function (sjgyp) {
  console[K[300041]](K[300129] + sjgyp[K[300130]] + K[300133] + sjgyp[K[300134]]);
}), wx[K[300135]](function (z3uo) {
  window['s1PT'] = z3uo, window['s14TP'] && window['s1PT'] && (console[K[300001]](K[300136] + window['s1PT'][K[300137]]), window['s14TP'](window['s1PT']), window['s1PT'] = null);
}), window['s1MXP4T'] = 0x0, window[K[300138]] = null, wx[K[300139]](function () {
  window['s1MXP4T']++, wx[K[300140]]();if (window['s1MXP4T'] >= 0x2) {
    window['s1MXP4T'] = 0x0, console[K[300027]](K[300141]), wx[K[300142]]('0', 0x1);if (window['s1X4'] && window['s1X4'][K[300106]]) window['s1X4T'](K[300143], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});