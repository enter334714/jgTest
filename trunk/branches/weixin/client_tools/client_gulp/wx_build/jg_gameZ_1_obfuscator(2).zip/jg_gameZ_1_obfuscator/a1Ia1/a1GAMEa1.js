var C = wx.$a;
console[C[460000]](C[460001]), window[C[460002]], wx[C[460003]](function (bxo2ph) {
  if (bxo2ph) {
    if (bxo2ph[C[460004]]) {
      var ywu17 = window[C[460005]][C[460006]][C[460007]](new RegExp(/\./, 'g'), '_'),
          hi5tx = bxo2ph[C[460004]],
          uyf167 = hi5tx[C[460008]](/(aaaaa\/a1GAMEa1.js:)[0-9]{1,60}(:)/g);if (uyf167) for (var xtiobh = 0x0; xtiobh < uyf167[C[460009]]; xtiobh++) {
        if (uyf167[xtiobh] && uyf167[xtiobh][C[460009]] > 0x0) {
          var ykl0f6 = parseInt(uyf167[xtiobh][C[460007]]('aaaaa/a1GAMEa1.js:', '')[C[460007]](':', ''));hi5tx = hi5tx[C[460007]](uyf167[xtiobh], uyf167[xtiobh][C[460007]](':' + ykl0f6 + ':', ':' + (ykl0f6 - 0x2) + ':'));
        }
      }hi5tx = hi5tx[C[460007]](new RegExp('aaaaa/a1GAMEa1.js', 'g'), C[460010] + ywu17 + C[460011]), hi5tx = hi5tx[C[460007]](new RegExp('aaaaa/a1MAIa1.js', 'g'), C[460010] + ywu17 + C[460011]), bxo2ph[C[460004]] = hi5tx;
    }var vr_csq = { 'id': window['a14M'][C[460012]], 'role': window['a14M'][C[460013]], 'level': window['a14M'][C[460014]], 'user': window['a14M'][C[460015]], 'version': window['a14M'][C[460016]], 'cdn': window['a14M'][C[460017]], 'pkgName': window['a14M'][C[460018]], 'gamever': window[C[460005]][C[460006]], 'serverid': window['a14M'][C[460019]] ? window['a14M'][C[460019]][C[460020]] : 0x0, 'systemInfo': window[C[460021]], 'error': C[460022], 'stack': bxo2ph ? bxo2ph[C[460004]] : '' },
        _crqs = JSON[C[460023]](vr_csq);console[C[460024]](C[460025] + _crqs), (!window[C[460002]] || window[C[460002]] != vr_csq[C[460024]]) && (window[C[460002]] = vr_csq[C[460024]], window['a1J4'](vr_csq));
  }
});import 'aabfaa.js';import 'aa11aa.js';window[C[460026]] = require(C[460027]);import 'aINDaa.js';import 'aaIB1aa.js';import 'aaMtadaa.js';import 'aaINIaa.js';console[C[460000]](C[460028]), console[C[460000]](C[460029]), a1J48M({ 'title': C[460030] });var acr9s_z = { 'a1CJM48': !![] };new window[C[460031]](acr9s_z), window[C[460031]][C[460032]]['a1C84MJ']();if (window['a1CJ4M8']) clearInterval(window['a1CJ4M8']);window['a1CJ4M8'] = null, window['a1C8MJ4'] = function (qlrv, $cvrqs) {
  if (!qlrv || !$cvrqs) return 0x0;qlrv = qlrv[C[460033]]('.'), $cvrqs = $cvrqs[C[460033]]('.');const f67uy = Math[C[460034]](qlrv[C[460009]], $cvrqs[C[460009]]);while (qlrv[C[460009]] < f67uy) {
    qlrv[C[460035]]('0');
  }while ($cvrqs[C[460009]] < f67uy) {
    $cvrqs[C[460035]]('0');
  }for (var bthxp = 0x0; bthxp < f67uy; bthxp++) {
    const yf61 = parseInt(qlrv[bthxp]),
          $scr = parseInt($cvrqs[bthxp]);if (yf61 > $scr) return 0x1;else {
      if (yf61 < $scr) return -0x1;
    }
  }return 0x0;
}, window[C[460036]] = wx[C[460037]]()[C[460036]], console[C[460038]](C[460039] + window[C[460036]]);var a$fk0y = wx[C[460040]]();a$fk0y[C[460041]](function (lr0$) {
  console[C[460038]](C[460042] + lr0$[C[460043]]);
}), a$fk0y[C[460044]](function () {
  wx[C[460045]]({ 'title': C[460046], 'content': C[460047], 'showCancel': ![], 'success': function (l0f6ky) {
      a$fk0y[C[460048]]();
    } });
}), a$fk0y[C[460049]](function () {
  console[C[460038]](C[460050]);
}), window['a1C8M4J'] = function () {
  console[C[460038]](C[460051]);var p8bo2 = wx[C[460052]]({ 'name': 'a1pfta1', 'success': function (jt4d5i) {
      console[C[460038]](C[460053]), console[C[460038]](jt4d5i), jt4d5i && jt4d5i[C[460054]] == C[460055] ? (window['a1M8'] = !![], window['a1M84J'](), window['a1M4J8']()) : setTimeout(function () {
        window['a1C8M4J']();
      }, 0x1f4);
    }, 'fail': function (yf1k) {
      console[C[460038]](C[460056]), console[C[460038]](yf1k), setTimeout(function () {
        window['a1C8M4J']();
      }, 0x1f4);
    } });p8bo2 && p8bo2[C[460057]](q$vcr => {});
}, window['a1C4JM8'] = function () {
  console[C[460038]](C[460058]);var oibxht = wx[C[460052]]({ 'name': C[460059], 'success': function (cv_qs) {
      console[C[460038]](C[460060]), console[C[460038]](cv_qs), cv_qs && cv_qs[C[460054]] == C[460055] ? (window['a148M'] = !![], window['a1M84J'](), window['a1M4J8']()) : setTimeout(function () {
        window['a1C4JM8']();
      }, 0x1f4);
    }, 'fail': function (ly$f0) {
      console[C[460038]](C[460061]), console[C[460038]](ly$f0), setTimeout(function () {
        window['a1C4JM8']();
      }, 0x1f4);
    } });oibxht && oibxht[C[460057]](ky16 => {});
}, window[C[460062]] = function () {
  window['a1C8MJ4'](window[C[460036]], C[460063]) >= 0x0 ? (console[C[460038]](C[460064] + window[C[460036]] + C[460065]), window['a14J'](), window['a1C8M4J'](), window['a1C4JM8']()) : (window['a14MJ'](C[460066], window[C[460036]]), wx[C[460045]]({ 'title': C[460067], 'content': C[460068] }));
}, window[C[460021]] = '', wx[C[460069]]({ 'success'(xhboti) {
    window[C[460021]] = C[460070] + xhboti[C[460071]] + C[460072] + xhboti[C[460073]] + C[460074] + xhboti[C[460075]] + C[460076] + xhboti[C[460077]] + C[460078] + xhboti[C[460079]] + C[460080] + xhboti[C[460036]] + C[460081] + xhboti[C[460082]], console[C[460038]](window[C[460021]]), console[C[460038]](C[460083] + xhboti[C[460084]] + C[460085] + xhboti[C[460086]] + C[460087] + xhboti[C[460088]] + C[460089] + xhboti[C[460090]] + C[460091] + xhboti[C[460092]] + C[460093] + xhboti[C[460094]] + C[460095] + (xhboti[C[460096]] ? xhboti[C[460096]][C[460097]] + ',' + xhboti[C[460096]][C[460098]] + ',' + xhboti[C[460096]][C[460099]] + ',' + xhboti[C[460096]][C[460100]] : ''));var enp283 = xhboti[C[460077]] ? xhboti[C[460077]][C[460101]]() : '',
        rzc_s9 = xhboti[C[460073]] ? xhboti[C[460073]][C[460101]]()[C[460007]]('\x20', '') : '';window['a14M'][C[460102]] = enp283[C[460103]](C[460104]) != -0x1, window['a14M'][C[460105]] = enp283[C[460103]](C[460106]) != -0x1, window['a14M'][C[460107]] = enp283[C[460103]](C[460104]) != -0x1 || enp283[C[460103]](C[460106]) != -0x1, window['a14M'][C[460108]] = enp283[C[460103]](C[460109]) != -0x1 || enp283[C[460103]](C[460110]) != -0x1, window['a14M'][C[460111]] = xhboti[C[460079]] ? xhboti[C[460079]][C[460101]]() : '', window['a14M']['a1CJ8M4'] = ![], window['a14M']['a1CJ48M'] = 0x2;if (enp283[C[460103]](C[460106]) != -0x1) {
      if (xhboti[C[460082]] >= 0x18) window['a14M']['a1CJ48M'] = 0x3;else window['a14M']['a1CJ48M'] = 0x2;
    } else {
      if (enp283[C[460103]](C[460104]) != -0x1) {
        if (xhboti[C[460082]] && xhboti[C[460082]] >= 0x14) window['a14M']['a1CJ48M'] = 0x3;else {
          if (rzc_s9[C[460103]](C[460112]) != -0x1 || rzc_s9[C[460103]](C[460113]) != -0x1 || rzc_s9[C[460103]](C[460114]) != -0x1 || rzc_s9[C[460103]](C[460115]) != -0x1 || rzc_s9[C[460103]](C[460116]) != -0x1) window['a14M']['a1CJ48M'] = 0x2;else window['a14M']['a1CJ48M'] = 0x3;
        }
      } else window['a14M']['a1CJ48M'] = 0x2;
    }console[C[460038]](C[460117] + window['a14M']['a1CJ8M4'] + C[460118] + window['a14M']['a1CJ48M']);
  } }), wx[C[460119]]({ 'success': function (_rcsq9) {
    console[C[460038]](C[460120] + _rcsq9[C[460121]] + C[460122] + _rcsq9[C[460123]]);
  } }), wx[C[460124]]({ 'success': function (kf70) {
    console[C[460038]](C[460125] + kf70[C[460126]]);
  } }), wx[C[460127]]({ 'keepScreenOn': !![] }), wx[C[460128]](function (i5dho) {
  console[C[460038]](C[460125] + i5dho[C[460126]] + C[460129] + i5dho[C[460130]]);
}), wx[C[460131]](function (j5m4z) {
  window['a18J'] = j5m4z, window['a1MJ8'] && window['a18J'] && (console[C[460000]](C[460132] + window['a18J'][C[460133]]), window['a1MJ8'](window['a18J']), window['a18J'] = null);
}), window[C[460134]] = 0x0, window['a1C48MJ'] = 0x0, window[C[460135]] = null, wx[C[460136]](function () {
  window['a1C48MJ']++;var en832p = Date[C[460137]]();(window[C[460134]] == 0x0 || en832p - window[C[460134]] > 0x1d4c0) && (console[C[460138]](C[460139]), wx[C[460140]]());if (window['a1C48MJ'] >= 0x2) {
    window['a1C48MJ'] = 0x0, console[C[460024]](C[460141]), wx[C[460142]]('0', 0x1);if (window['a14M'] && window['a14M'][C[460102]]) window['a14MJ'](C[460143], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});