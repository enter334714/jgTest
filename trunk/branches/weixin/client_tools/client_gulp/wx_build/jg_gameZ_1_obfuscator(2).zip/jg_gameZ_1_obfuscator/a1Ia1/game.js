var C = wx.$a;
require('a1GAMEa1.js');