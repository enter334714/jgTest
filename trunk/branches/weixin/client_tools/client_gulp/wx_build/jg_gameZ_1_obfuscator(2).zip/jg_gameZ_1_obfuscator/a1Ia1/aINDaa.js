var C = wx.$a;
import ad4ith from '../aaabasdk/a5sdka.js';window[C[460539]] = { 'wxVersion': window[C[460005]][C[460006]] }, window[C[460540]] = ![], window['a1M4'] = 0x1, window[C[460541]] = 0x1, window['a184M'] = !![], window[C[460542]] = !![], window['a1CJ84M'] = '', window['a14M'] = { 'base_cdn': C[460543], 'cdn': C[460543] }, a14M[C[460544]] = {}, a14M[C[460545]] = '0', a14M[C[460075]] = window[C[460539]][C[460326]], a14M[C[460110]] = '', a14M['os'] = '1', a14M[C[460546]] = C[460547], a14M[C[460548]] = C[460549], a14M[C[460550]] = C[460551], a14M[C[460552]] = C[460553], a14M[C[460554]] = C[460555], a14M[C[460556]] = '1', a14M[C[460018]] = '', a14M[C[460557]] = '', a14M[C[460558]] = 0x0, a14M[C[460417]] = {}, a14M[C[460559]] = parseInt(a14M[C[460556]]), a14M[C[460560]] = a14M[C[460556]], a14M[C[460019]] = {}, a14M['a1J4'] = C[460561], a14M[C[460562]] = ![], a14M[C[460563]] = C[460564], a14M[C[460565]] = Date[C[460137]](), a14M[C[460566]] = C[460567], a14M[C[460568]] = '_a', a14M[C[460312]] = 0x2, a14M[C[460016]] = 0x7c1, a14M[C[460326]] = window[C[460539]][C[460326]], a14M[C[460569]] = ![], a14M[C[460102]] = ![], a14M[C[460105]] = ![], a14M[C[460108]] = ![], window['a18M4'] = 0x5, window['a18M'] = ![], window['a1M8'] = ![], window['a148M'] = ![], window[C[460490]] = ![], window[C[460493]] = ![], window['a14M8'] = ![], window['a184'] = ![], window['a148'] = ![], window['a1M84'] = ![], window[C[460570]] = function (y671) {
  console[C[460038]](C[460570], y671), wx[C[460571]]({}), wx[C[460045]]({ 'title': C[460067], 'content': y671, 'success'(v$csr) {
      if (v$csr[C[460572]]) console[C[460038]](C[460573]);else v$csr[C[460574]] && console[C[460038]](C[460575]);
    } });
}, window['a1J84M'] = function (qc_vr) {
  console[C[460038]](C[460576], qc_vr), a1J4M8(), wx[C[460045]]({ 'title': C[460067], 'content': qc_vr, 'confirmText': C[460577], 'cancelText': C[460578], 'success'(fv0k$) {
      if (fv0k$[C[460572]]) window['a14J']();else fv0k$[C[460574]] && (console[C[460038]](C[460579]), wx[C[460580]]({}));
    } });
}, window[C[460581]] = function (c_9smz) {
  console[C[460038]](C[460581], c_9smz), wx[C[460045]]({ 'title': C[460067], 'content': c_9smz, 'confirmText': C[460582], 'showCancel': ![], 'complete'(_rs9zc) {
      console[C[460038]](C[460579]), wx[C[460580]]({});
    } });
}, window['a1J8M4'] = ![], window['a1J48M'] = function (pbx2h) {
  window['a1J8M4'] = !![], wx[C[460583]](pbx2h);
}, window['a1J4M8'] = function () {
  window['a1J8M4'] && (window['a1J8M4'] = ![], wx[C[460571]]({}));
}, window['a1JM84'] = function (p2b8nx) {
  window[C[460031]][C[460032]]['a1JM84'](p2b8nx);
}, window[C[460584]] = function (g2n38e, q0$vlk) {
  ad4ith[C[460584]](g2n38e, function ($rqvl0) {
    $rqvl0 && $rqvl0[C[460426]] ? $rqvl0[C[460426]][C[460425]] == 0x1 ? q0$vlk(!![]) : (q0$vlk(![]), console[C[460000]](C[460585] + $rqvl0[C[460426]][C[460586]])) : console[C[460038]](C[460584], $rqvl0);
  });
}, window['a1JM48'] = function (thbpo) {
  console[C[460038]](C[460587], thbpo);
}, window['a1J4M'] = function (oit5hx) {}, window['a1JM4'] = function (h5idot, y60k, ti4dj) {}, window['a1JM'] = function (gne82) {
  console[C[460038]](C[460588], gne82), window[C[460031]][C[460032]][C[460316]](), window[C[460031]][C[460032]][C[460317]](), window[C[460031]][C[460032]][C[460330]]();
}, window['a1MJ'] = function (rsvq$) {
  window['a1J84M'](C[460589]);var m49_zj = { 'id': window['a14M'][C[460012]], 'role': window['a14M'][C[460013]], 'level': window['a14M'][C[460014]], 'account': window['a14M'][C[460015]], 'version': window['a14M'][C[460016]], 'cdn': window['a14M'][C[460017]], 'pkgName': window['a14M'][C[460018]], 'gamever': window[C[460005]][C[460006]], 'serverid': window['a14M'][C[460019]] ? window['a14M'][C[460019]][C[460020]] : 0x0, 'systemInfo': window[C[460021]], 'error': C[460590], 'stack': rsvq$ ? rsvq$ : C[460589] },
      f0yl$ = JSON[C[460023]](m49_zj);console[C[460024]](C[460591] + f0yl$), window['a1J4'](f0yl$);
}, window['a14JM'] = function (k67y0) {
  var obp82 = JSON[C[460592]](k67y0);obp82[C[460593]] = window[C[460005]][C[460006]], obp82[C[460594]] = window['a14M'][C[460019]] ? window['a14M'][C[460019]][C[460020]] : 0x0, obp82[C[460021]] = window[C[460021]];var v$l0fk = JSON[C[460023]](obp82);console[C[460024]](C[460595] + v$l0fk), window['a1J4'](v$l0fk);
}, window['a14MJ'] = function (r_vq, wy7u) {
  var ql$sr = { 'id': window['a14M'][C[460012]], 'role': window['a14M'][C[460013]], 'level': window['a14M'][C[460014]], 'account': window['a14M'][C[460015]], 'version': window['a14M'][C[460016]], 'cdn': window['a14M'][C[460017]], 'pkgName': window['a14M'][C[460018]], 'gamever': window[C[460005]][C[460006]], 'serverid': window['a14M'][C[460019]] ? window['a14M'][C[460019]][C[460020]] : 0x0, 'systemInfo': window[C[460021]], 'error': r_vq, 'stack': wy7u },
      fk61y = JSON[C[460023]](ql$sr);console[C[460138]](C[460596] + fk61y), window['a1J4'](fk61y);
}, window['a1J4'] = function (yk$f) {
  if (window['a14M'][C[460111]] == C[460597]) return;var p28o = a14M['a1J4'] + C[460598] + a14M[C[460015]];wx[C[460599]]({ 'url': p28o, 'method': C[460600], 'data': yk$f, 'header': { 'content-type': C[460601], 'cache-control': C[460602] }, 'success': function (rq9_cs) {
      DEBUG && console[C[460038]](C[460603], p28o, yk$f, rq9_cs);
    }, 'fail': function (o2bpxh) {
      DEBUG && console[C[460038]](C[460603], p28o, yk$f, o2bpxh);
    }, 'complete': function () {} });
}, window[C[460604]] = function () {
  function g2e3n8() {
    return ((0x1 + Math[C[460319]]()) * 0x10000 | 0x0)[C[460605]](0x10)[C[460606]](0x1);
  }return g2e3n8() + g2e3n8() + '-' + g2e3n8() + '-' + g2e3n8() + '-' + g2e3n8() + '+' + g2e3n8() + g2e3n8() + g2e3n8();
}, window['a14J'] = function () {
  console[C[460038]](C[460607]);var r0$ = ad4ith[C[460608]]();a14M[C[460560]] = r0$[C[460609]], a14M[C[460559]] = r0$[C[460609]], a14M[C[460556]] = r0$[C[460609]], a14M[C[460018]] = r0$[C[460610]];var yf61k = { 'game_ver': a14M[C[460075]] };a14M[C[460557]] = this[C[460604]](), a1J48M({ 'title': C[460611] }), ad4ith[C[460455]](yf61k, this['a1MJ4'][C[460323]](this));
}, window['a1MJ4'] = function (ix5oht) {
  var xpo8b2 = ix5oht[C[460612]];console[C[460038]](C[460613] + xpo8b2 + C[460614] + (xpo8b2 == 0x1) + C[460615] + ix5oht[C[460006]] + C[460616] + window[C[460539]][C[460326]]);if (!ix5oht[C[460006]] || window['a1C8MJ4'](window[C[460539]][C[460326]], ix5oht[C[460006]]) < 0x0) console[C[460038]](C[460617]), a14M[C[460548]] = C[460618], a14M[C[460550]] = C[460619], a14M[C[460552]] = C[460620], a14M[C[460017]] = C[460621], a14M[C[460622]] = C[460623], a14M[C[460624]] = 'jy', a14M[C[460569]] = ![];else window['a1C8MJ4'](window[C[460539]][C[460326]], ix5oht[C[460006]]) == 0x0 ? (console[C[460038]](C[460625]), a14M[C[460548]] = C[460549], a14M[C[460550]] = C[460551], a14M[C[460552]] = C[460553], a14M[C[460017]] = C[460626], a14M[C[460622]] = C[460623], a14M[C[460624]] = C[460627], a14M[C[460569]] = !![]) : (console[C[460038]](C[460628]), a14M[C[460548]] = C[460549], a14M[C[460550]] = C[460551], a14M[C[460552]] = C[460553], a14M[C[460017]] = C[460626], a14M[C[460622]] = C[460623], a14M[C[460624]] = C[460627], a14M[C[460569]] = ![]);a14M[C[460558]] = config[C[460629]] ? config[C[460629]] : 0x0, this['a184JM'](), this['a184MJ'](), window[C[460630]] = 0x5, a1J48M({ 'title': C[460631] }), ad4ith[C[460632]](this['a1M4J'][C[460323]](this));
}, window[C[460630]] = 0x5, window['a1M4J'] = function (zc_9m, j9zm_4) {
  if (zc_9m == 0x0 && j9zm_4 && j9zm_4[C[460633]]) {
    a14M[C[460634]] = j9zm_4[C[460633]];var fy617k = this;a1J48M({ 'title': C[460635] }), sendApi(a14M[C[460548]], C[460636], { 'platform': a14M[C[460546]], 'partner_id': a14M[C[460556]], 'token': j9zm_4[C[460633]], 'game_pkg': a14M[C[460018]], 'deviceId': a14M[C[460557]], 'scene': C[460637] + a14M[C[460558]] }, this['a18J4M'][C[460323]](this), a18M4, a1MJ);
  } else j9zm_4 && j9zm_4[C[460054]] && window[C[460630]] > 0x0 && (j9zm_4[C[460054]][C[460103]](C[460638]) != -0x1 || j9zm_4[C[460054]][C[460103]](C[460639]) != -0x1 || j9zm_4[C[460054]][C[460103]](C[460640]) != -0x1 || j9zm_4[C[460054]][C[460103]](C[460641]) != -0x1 || j9zm_4[C[460054]][C[460103]](C[460642]) != -0x1 || j9zm_4[C[460054]][C[460103]](C[460643]) != -0x1) ? (window[C[460630]]--, ad4ith[C[460632]](this['a1M4J'][C[460323]](this))) : (window['a14MJ'](C[460644], JSON[C[460023]]({ 'status': zc_9m, 'data': j9zm_4 })), window['a1J84M'](C[460645] + (j9zm_4 && j9zm_4[C[460054]] ? '，' + j9zm_4[C[460054]] : '')));
}, window['a18J4M'] = function (qv_rs) {
  if (!qv_rs) {
    window['a14MJ'](C[460646], C[460647]), window['a1J84M'](C[460648]);return;
  }if (qv_rs[C[460425]] != C[460424]) {
    window['a14MJ'](C[460646], JSON[C[460023]](qv_rs)), window['a1J84M'](C[460649] + qv_rs[C[460425]]);return;
  }a14M[C[460650]] = String(qv_rs[C[460015]]), a14M[C[460015]] = String(qv_rs[C[460015]]), a14M[C[460079]] = String(qv_rs[C[460079]]), a14M[C[460560]] = String(qv_rs[C[460079]]), a14M[C[460651]] = String(qv_rs[C[460651]]), a14M[C[460652]] = String(qv_rs[C[460653]]), a14M[C[460654]] = String(qv_rs[C[460655]]), a14M[C[460653]] = '';var im4j5d = this;a1J48M({ 'title': C[460656] }), sendApi(a14M[C[460548]], C[460657], { 'partner_id': a14M[C[460556]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460557]] }, im4j5d['a18JM4'][C[460323]](im4j5d), a18M4, a1MJ);
}, window['a18JM4'] = function (i5txh) {
  if (!i5txh) {
    window['a1J84M'](C[460658]);return;
  }if (i5txh[C[460425]] != C[460424]) {
    window['a1J84M'](C[460659] + i5txh[C[460425]]);return;
  }if (!i5txh[C[460426]] || i5txh[C[460426]][C[460009]] == 0x0) {
    window['a1J84M'](C[460660]);return;
  }a14M[C[460499]] = i5txh[C[460661]], a14M[C[460019]] = { 'server_id': String(i5txh[C[460426]][0x0][C[460020]]), 'server_name': String(i5txh[C[460426]][0x0][C[460405]]), 'entry_ip': i5txh[C[460426]][0x0][C[460662]], 'entry_port': parseInt(i5txh[C[460426]][0x0][C[460663]]), 'status': a148J(i5txh[C[460426]][0x0]), 'start_time': i5txh[C[460426]][0x0][C[460664]], 'cdn': a14M[C[460017]] }, this['a1M48J']();
}, window['a1M48J'] = function () {
  if (a14M[C[460499]] == 0x1) {
    var ykf0l$ = a14M[C[460019]][C[460404]];if (ykf0l$ === -0x1 || ykf0l$ === 0x0) {
      window['a1J84M'](ykf0l$ === -0x1 ? C[460665] : C[460666]);return;
    }a1MJ84(0x0, a14M[C[460019]][C[460020]]), window[C[460031]][C[460032]][C[460494]](a14M[C[460499]]);
  } else window[C[460031]][C[460032]][C[460491]](), a1J4M8();window['a148'] = !![], window['a1M84J'](), window['a1M4J8']();
}, window['a184JM'] = function () {
  sendApi(a14M[C[460548]], C[460667], { 'game_pkg': a14M[C[460018]], 'version_name': a14M[C[460624]] }, this[C[460668]][C[460323]](this), a18M4, a1MJ);
}, window[C[460668]] = function (u6w1y) {
  if (!u6w1y) {
    window['a1J84M'](C[460669]);return;
  }if (u6w1y[C[460425]] != C[460424]) {
    window['a1J84M'](C[460670] + u6w1y[C[460425]]);return;
  }if (!u6w1y[C[460426]] || !u6w1y[C[460426]][C[460075]]) {
    window['a1J84M'](C[460671] + (u6w1y[C[460426]] && u6w1y[C[460426]][C[460075]]));return;
  }u6w1y[C[460426]][C[460672]] && u6w1y[C[460426]][C[460672]][C[460009]] > 0xa && (a14M[C[460673]] = u6w1y[C[460426]][C[460672]], a14M[C[460017]] = u6w1y[C[460426]][C[460672]]), u6w1y[C[460426]][C[460075]] && (a14M[C[460016]] = u6w1y[C[460426]][C[460075]]), console[C[460000]](C[460674] + a14M[C[460016]] + C[460675] + a14M[C[460624]]), window['a14M8'] = !![], window['a1M84J'](), window['a1M4J8']();
}, window[C[460676]], window['a184MJ'] = function () {
  sendApi(a14M[C[460548]], C[460677], { 'game_pkg': a14M[C[460018]] }, this['a18MJ4'][C[460323]](this), a18M4, a1MJ);
}, window['a18MJ4'] = function (v0ql$) {
  if (v0ql$[C[460425]] === C[460424] && v0ql$[C[460426]]) {
    window[C[460676]] = v0ql$[C[460426]];for (var z5jdm in v0ql$[C[460426]]) {
      a14M[z5jdm] = v0ql$[C[460426]][z5jdm];
    }
  } else console[C[460000]](C[460678] + v0ql$[C[460425]]);window['a184'] = !![], window['a1M4J8']();
}, window[C[460679]] = function (id4jt5, o8bxp, np82e, $crq, k760y, od5tih, jm5i, c_9zms, f1y6k7) {
  k760y = String(k760y);var nxp28 = jm5i,
      eg8n32 = c_9zms;a14M[C[460544]][k760y] = { 'productid': k760y, 'productname': nxp28, 'productdesc': eg8n32, 'roleid': id4jt5, 'rolename': o8bxp, 'rolelevel': np82e, 'price': od5tih, 'callback': f1y6k7 }, sendApi(a14M[C[460552]], C[460680], { 'game_pkg': a14M[C[460018]], 'server_id': a14M[C[460019]][C[460020]], 'server_name': a14M[C[460019]][C[460405]], 'level': np82e, 'uid': a14M[C[460015]], 'role_id': id4jt5, 'role_name': o8bxp, 'product_id': k760y, 'product_name': nxp28, 'product_desc': eg8n32, 'money': od5tih, 'partner_id': a14M[C[460556]] }, toPayCallBack, a18M4, a1MJ);
}, window[C[460681]] = function (d5hi4t) {
  if (d5hi4t) {
    if (d5hi4t[C[460682]] === 0xc8 || d5hi4t[C[460425]] == C[460424]) {
      var pxbo = a14M[C[460544]][String(d5hi4t[C[460683]])];if (pxbo[C[460684]]) pxbo[C[460684]](d5hi4t[C[460683]], d5hi4t[C[460685]], -0x1);ad4ith[C[460686]]({ 'cpbill': d5hi4t[C[460685]], 'productid': d5hi4t[C[460683]], 'productname': pxbo[C[460687]], 'productdesc': pxbo[C[460688]], 'serverid': a14M[C[460019]][C[460020]], 'servername': a14M[C[460019]][C[460405]], 'roleid': pxbo[C[460689]], 'rolename': pxbo[C[460690]], 'rolelevel': pxbo[C[460691]], 'price': pxbo[C[460692]], 'extension': JSON[C[460023]]({ 'cp_order_id': d5hi4t[C[460685]] }) }, function (zms9, rql$) {
        pxbo[C[460684]] && zms9 == 0x0 && pxbo[C[460684]](d5hi4t[C[460683]], d5hi4t[C[460685]], zms9);console[C[460000]](JSON[C[460023]]({ 'type': C[460693], 'status': zms9, 'data': d5hi4t, 'role_name': pxbo[C[460690]] }));if (zms9 === 0x0) {} else {
          if (zms9 === 0x1) {} else {
            if (zms9 === 0x2) {}
          }
        }
      });
    } else alert(d5hi4t[C[460000]]);
  }
}, window['a18M4J'] = function () {}, window['a1J8M'] = function (yk167f, y6u, jti45d, ixtbh, crvq$) {
  ad4ith[C[460694]](a14M[C[460019]][C[460020]], a14M[C[460019]][C[460405]] || a14M[C[460019]][C[460020]], yk167f, y6u, jti45d), sendApi(a14M[C[460548]], C[460695], { 'game_pkg': a14M[C[460018]], 'server_id': a14M[C[460019]][C[460020]], 'role_id': yk167f, 'uid': a14M[C[460015]], 'role_name': y6u, 'role_type': ixtbh, 'level': jti45d });
}, window['a1JM8'] = function (cq_rs, zd, $0vlqr, vlf0k, scr9z_, lf$0y, it5hx, k$vq, j5m4i, qvkl$) {
  a14M[C[460012]] = cq_rs, a14M[C[460013]] = zd, a14M[C[460014]] = $0vlqr, ad4ith[C[460696]](a14M[C[460019]][C[460020]], a14M[C[460019]][C[460405]] || a14M[C[460019]][C[460020]], cq_rs, zd, $0vlqr), sendApi(a14M[C[460548]], C[460697], { 'game_pkg': a14M[C[460018]], 'server_id': a14M[C[460019]][C[460020]], 'role_id': cq_rs, 'uid': a14M[C[460015]], 'role_name': zd, 'role_type': vlf0k, 'level': $0vlqr, 'evolution': scr9z_ });
}, window['a18JM'] = function (yu7f6, j_4m, ptbx, $sqlv, y0kf67, hbto, q9r_cs, q_r9c, ky60, oxh5i) {
  a14M[C[460012]] = yu7f6, a14M[C[460013]] = j_4m, a14M[C[460014]] = ptbx, ad4ith[C[460698]](a14M[C[460019]][C[460020]], a14M[C[460019]][C[460405]] || a14M[C[460019]][C[460020]], yu7f6, j_4m, ptbx), sendApi(a14M[C[460548]], C[460697], { 'game_pkg': a14M[C[460018]], 'server_id': a14M[C[460019]][C[460020]], 'role_id': yu7f6, 'uid': a14M[C[460015]], 'role_name': j_4m, 'role_type': $sqlv, 'level': ptbx, 'evolution': y0kf67 });
}, window['a18MJ'] = function (_9mjz) {}, window['a1J8'] = function (ibxoh) {
  ad4ith[C[460699]](C[460699], function (fy760k) {
    ibxoh && ibxoh(fy760k);
  });
}, window[C[460700]] = function () {
  ad4ith[C[460700]]();
}, window[C[460701]] = function () {
  ad4ith[C[460702]]();
}, window[C[460131]] = function ($0vk) {
  window['a1MJ8'] = $0vk, window['a1MJ8'] && window['a18J'] && (console[C[460000]](C[460132] + window['a18J'][C[460133]]), window['a1MJ8'](window['a18J']), window['a18J'] = null);
}, window['a1M8J'] = function (fk0l$, tjd4i5, $rvcs, mj5i4) {
  window[C[460703]](C[460704], { 'game_pkg': window['a14M'][C[460018]], 'role_id': tjd4i5, 'server_id': $rvcs }, mj5i4);
}, window['a14J8M'] = function (yl$0, ge328n) {
  function e2p38(vq_sc) {
    var y6w1u7 = [],
        j4idm = [],
        vrq0l$ = window[C[460005]][C[460705]];for (var botxhp in vrq0l$) {
      var o2hx = Number(botxhp);(!yl$0 || !yl$0[C[460009]] || yl$0[C[460103]](o2hx) != -0x1) && (j4idm[C[460035]](vrq0l$[botxhp]), y6w1u7[C[460035]]([o2hx, 0x3]));
    }window['a1C8MJ4'](window[C[460036]], C[460706]) >= 0x0 ? (console[C[460038]](C[460707]), ad4ith[C[460708]] && ad4ith[C[460708]](j4idm, function (m_jc9) {
      console[C[460038]](C[460709]), console[C[460038]](m_jc9);if (m_jc9 && m_jc9[C[460054]] == C[460710]) for (var qrvc_s in vrq0l$) {
        if (m_jc9[vrq0l$[qrvc_s]] == C[460711]) {
          var k06lf = Number(qrvc_s);for (var td4ij = 0x0; td4ij < y6w1u7[C[460009]]; td4ij++) {
            if (y6w1u7[td4ij][0x0] == k06lf) {
              y6w1u7[td4ij][0x1] = 0x1;break;
            }
          }
        }
      }window['a1C8MJ4'](window[C[460036]], C[460712]) >= 0x0 ? wx[C[460713]]({ 'withSubscriptions': !![], 'success': function (qvlk0) {
          var v$rsc = qvlk0[C[460714]][C[460715]];if (v$rsc) {
            console[C[460038]](C[460716]), console[C[460038]](v$rsc);for (var lfy$0 in vrq0l$) {
              if (v$rsc[vrq0l$[lfy$0]] == C[460711]) {
                var jmzd49 = Number(lfy$0);for (var xpbo8 = 0x0; xpbo8 < y6w1u7[C[460009]]; xpbo8++) {
                  if (y6w1u7[xpbo8][0x0] == jmzd49) {
                    y6w1u7[xpbo8][0x1] = 0x2;break;
                  }
                }
              }
            }console[C[460038]](y6w1u7), ge328n && ge328n(y6w1u7);
          } else console[C[460038]](C[460717]), console[C[460038]](qvlk0), console[C[460038]](y6w1u7), ge328n && ge328n(y6w1u7);
        }, 'fail': function () {
          console[C[460038]](C[460718]), console[C[460038]](y6w1u7), ge328n && ge328n(y6w1u7);
        } }) : (console[C[460038]](C[460719] + window[C[460036]]), console[C[460038]](y6w1u7), ge328n && ge328n(y6w1u7));
    })) : (console[C[460038]](C[460720] + window[C[460036]]), console[C[460038]](y6w1u7), ge328n && ge328n(y6w1u7)), wx[C[460721]](e2p38);
  }wx[C[460722]](e2p38);
}, window['a14JM8'] = { 'isSuccess': ![], 'level': C[460723], 'isCharging': ![] }, window['a148JM'] = function (d4jm) {
  wx[C[460119]]({ 'success': function (fyu1) {
      var z_9mj4 = window['a14JM8'];z_9mj4[C[460724]] = !![], z_9mj4[C[460121]] = Number(fyu1[C[460121]])[C[460725]](0x0), z_9mj4[C[460123]] = fyu1[C[460123]], d4jm && d4jm(z_9mj4[C[460724]], z_9mj4[C[460121]], z_9mj4[C[460123]]);
    }, 'fail': function (fk6y70) {
      console[C[460038]](C[460726], fk6y70[C[460054]]);var e238np = window['a14JM8'];d4jm && d4jm(e238np[C[460724]], e238np[C[460121]], e238np[C[460123]]);
    } });
}, window[C[460703]] = function (hi45td, c_sr9z, sq_rc, yf6k7, y07k, it5j4, bep82, np83e) {
  if (yf6k7 == undefined) yf6k7 = 0x1;wx[C[460599]]({ 'url': hi45td, 'method': bep82 || C[460727], 'responseType': C[460321], 'data': c_sr9z, 'header': { 'content-type': np83e || C[460601] }, 'success': function (txobh) {
      DEBUG && console[C[460038]](C[460728], hi45td, info, txobh);if (txobh && txobh[C[460729]] == 0xc8) {
        var z94_jm = txobh[C[460426]];!it5j4 || it5j4(z94_jm) ? sq_rc && sq_rc(z94_jm) : window[C[460730]](hi45td, c_sr9z, sq_rc, yf6k7, y07k, it5j4, txobh);
      } else window[C[460730]](hi45td, c_sr9z, sq_rc, yf6k7, y07k, it5j4, txobh);
    }, 'fail': function (np83) {
      DEBUG && console[C[460038]](C[460731], hi45td, info, np83), window[C[460730]](hi45td, c_sr9z, sq_rc, yf6k7, y07k, it5j4, np83);
    }, 'complete': function () {} });
}, window[C[460730]] = function (k$0fy, m9z_s, pxob82, klf0y, ith45, v0f$kl, zr_9sc) {
  klf0y - 0x1 > 0x0 ? setTimeout(function () {
    window[C[460703]](k$0fy, m9z_s, pxob82, klf0y - 0x1, ith45, v0f$kl);
  }, 0x3e8) : ith45 && ith45(JSON[C[460023]]({ 'url': k$0fy, 'response': zr_9sc }));
}, window[C[460732]] = function (u71y6f, l0rv$q, f17k, flyk$, j5z4dm, csrqv_, b28op) {
  !f17k && (f17k = {});var o8b = Math[C[460511]](Date[C[460137]]() / 0x3e8);f17k[C[460655]] = o8b, f17k[C[460733]] = l0rv$q;var $0v = Object[C[460734]](f17k)[C[460430]](),
      _scz9m = '',
      vqlk$ = '';for (var j94mz = 0x0; j94mz < $0v[C[460009]]; j94mz++) {
    _scz9m = _scz9m + (j94mz == 0x0 ? '' : '&') + $0v[j94mz] + f17k[$0v[j94mz]], vqlk$ = vqlk$ + (j94mz == 0x0 ? '' : '&') + $0v[j94mz] + '=' + encodeURIComponent(f17k[$0v[j94mz]]);
  }_scz9m = _scz9m + a14M[C[460554]];var $vcrqs = C[460735] + md5(_scz9m);send(u71y6f + '?' + vqlk$ + (vqlk$ == '' ? '' : '&') + $vcrqs, null, flyk$, j5z4dm, csrqv_, b28op || function (y1uf7) {
    return y1uf7[C[460425]] == C[460424];
  }, null, C[460736]);
}, window['a148MJ'] = function (_cqvs, sqrvc) {
  var f67uy = 0x0;a14M[C[460019]] && (f67uy = a14M[C[460019]][C[460020]]), sendApi(a14M[C[460550]], C[460737], { 'partnerId': a14M[C[460556]], 'gamePkg': a14M[C[460018]], 'logTime': Math[C[460511]](Date[C[460137]]() / 0x3e8), 'platformUid': a14M[C[460651]], 'type': _cqvs, 'serverId': f67uy }, null, 0x2, null, function () {
    return !![];
  });
}, window['a14MJ8'] = function (odhit5) {
  sendApi(a14M[C[460548]], C[460738], { 'partner_id': a14M[C[460556]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460557]] }, a14M8J, a18M4, a1MJ);
}, window['a14M8J'] = function (bnpx82) {
  if (bnpx82[C[460425]] === C[460424] && bnpx82[C[460426]]) {
    bnpx82[C[460426]][C[460739]]({ 'id': -0x2, 'name': C[460740] }), bnpx82[C[460426]][C[460739]]({ 'id': -0x1, 'name': C[460741] }), a14M[C[460378]] = bnpx82[C[460426]];if (window[C[460370]]) window[C[460370]][C[460411]]();
  } else a14M[C[460388]] = ![], window['a1J84M'](C[460742] + bnpx82[C[460425]]);
}, window['a1J84'] = function (npe2) {
  sendApi(a14M[C[460548]], C[460743], { 'partner_id': a14M[C[460556]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460557]] }, a1J48, a18M4, a1MJ);
}, window['a1J48'] = function (jzm) {
  a14M[C[460419]] = ![];if (jzm[C[460425]] === C[460424] && jzm[C[460426]]) {
    for (var k0yf76 = 0x0; k0yf76 < jzm[C[460426]][C[460009]]; k0yf76++) {
      jzm[C[460426]][k0yf76][C[460404]] = a148J(jzm[C[460426]][k0yf76]);
    }a14M[C[460417]][-0x1] = window[C[460744]](jzm[C[460426]]), window[C[460370]][C[460418]](-0x1);
  } else window['a1J84M'](C[460745] + jzm[C[460425]]);
}, window[C[460746]] = function (cqv$s) {
  sendApi(a14M[C[460548]], C[460743], { 'partner_id': a14M[C[460556]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460557]] }, cqv$s, a18M4, a1MJ);
}, window['a18J4'] = function (oxhbti, lf0k$) {
  sendApi(a14M[C[460548]], C[460747], { 'partner_id': a14M[C[460556]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460557]], 'server_group_id': lf0k$ }, a184J, a18M4, a1MJ);
}, window['a184J'] = function (qklv0) {
  a14M[C[460419]] = ![];if (qklv0[C[460425]] === C[460424] && qklv0[C[460426]] && qklv0[C[460426]][C[460426]]) {
    var r0lqv = qklv0[C[460426]][C[460748]],
        mzd9 = [];for (var k0l6y = 0x0; k0l6y < qklv0[C[460426]][C[460426]][C[460009]]; k0l6y++) {
      qklv0[C[460426]][C[460426]][k0l6y][C[460404]] = a148J(qklv0[C[460426]][C[460426]][k0l6y]), (mzd9[C[460009]] == 0x0 || qklv0[C[460426]][C[460426]][k0l6y][C[460404]] != 0x0) && (mzd9[mzd9[C[460009]]] = qklv0[C[460426]][C[460426]][k0l6y]);
    }a14M[C[460417]][r0lqv] = window[C[460744]](mzd9), window[C[460370]][C[460418]](r0lqv);
  } else window['a1J84M'](C[460749] + qklv0[C[460425]]);
}, window['a1C8M4'] = function (bo28) {
  sendApi(a14M[C[460548]], C[460750], { 'partner_id': a14M[C[460556]], 'uid': a14M[C[460015]], 'version': a14M[C[460075]], 'game_pkg': a14M[C[460018]], 'device': a14M[C[460557]] }, reqServerRecommendCallBack, a18M4, a1MJ);
}, window[C[460751]] = function (kf0y7) {
  a14M[C[460419]] = ![];if (kf0y7[C[460425]] === C[460424] && kf0y7[C[460426]]) {
    for (var qcsr = 0x0; qcsr < kf0y7[C[460426]][C[460009]]; qcsr++) {
      kf0y7[C[460426]][qcsr][C[460404]] = a148J(kf0y7[C[460426]][qcsr]);
    }a14M[C[460417]][-0x2] = window[C[460744]](kf0y7[C[460426]]), window[C[460370]][C[460418]](-0x2);
  } else alert(C[460752] + kf0y7[C[460425]]);
}, window[C[460744]] = function (xtoih5) {
  if (!xtoih5 && xtoih5[C[460009]] <= 0x0) return xtoih5;for (let b2pxo8 = 0x0; b2pxo8 < xtoih5[C[460009]]; b2pxo8++) {
    xtoih5[b2pxo8][C[460753]] && xtoih5[b2pxo8][C[460753]] == 0x1 && (xtoih5[b2pxo8][C[460405]] += C[460754]);
  }return xtoih5;
}, window['a14J8'] = function (pbhtox, i5mj4) {
  pbhtox = pbhtox || a14M[C[460019]][C[460020]], sendApi(a14M[C[460548]], C[460755], { 'type': '4', 'game_pkg': a14M[C[460018]], 'server_id': pbhtox }, i5mj4);
}, window[C[460756]] = function (l0fy$k, d49zm, msz9_, jm5i4d) {
  msz9_ = msz9_ || a14M[C[460019]][C[460020]], sendApi(a14M[C[460548]], C[460757], { 'type': l0fy$k, 'game_pkg': d49zm, 'server_id': msz9_ }, jm5i4d);
}, window['a148J'] = function (p28n) {
  if (p28n) {
    if (p28n[C[460404]] == 0x1) {
      if (p28n[C[460758]] == 0x1) return 0x2;else return 0x1;
    } else return p28n[C[460404]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['a1MJ84'] = function (o8px, p82e3n) {
  a14M[C[460759]] = { 'step': o8px, 'server_id': p82e3n };var p28bn = this;a1J48M({ 'title': C[460760] }), sendApi(a14M[C[460548]], C[460761], { 'partner_id': a14M[C[460556]], 'uid': a14M[C[460015]], 'game_pkg': a14M[C[460018]], 'server_id': p82e3n, 'platform': a14M[C[460079]], 'platform_uid': a14M[C[460651]], 'check_login_time': a14M[C[460654]], 'check_login_sign': a14M[C[460652]], 'version_name': a14M[C[460624]] }, a1MJ48, a18M4, a1MJ, function (qvsrc) {
    return qvsrc[C[460425]] == C[460424] || qvsrc[C[460000]] == C[460762] || qvsrc[C[460000]] == C[460763];
  });
}, window['a1MJ48'] = function (m_c) {
  var k$q = this;if (m_c[C[460425]] === C[460424] && m_c[C[460426]]) {
    var np832 = a14M[C[460019]];np832[C[460764]] = a14M[C[460559]], np832[C[460653]] = String(m_c[C[460426]][C[460765]]), np832[C[460565]] = parseInt(m_c[C[460426]][C[460655]]);if (m_c[C[460426]][C[460766]]) np832[C[460766]] = parseInt(m_c[C[460426]][C[460766]]);else np832[C[460766]] = parseInt(m_c[C[460426]][C[460020]]);np832[C[460767]] = 0x0, np832[C[460017]] = a14M[C[460673]], np832[C[460768]] = m_c[C[460426]][C[460769]], np832[C[460770]] = m_c[C[460426]][C[460770]], console[C[460038]](C[460771] + JSON[C[460023]](np832[C[460770]])), a14M[C[460499]] == 0x1 && np832[C[460770]] && np832[C[460770]][C[460772]] == 0x1 && (a14M[C[460327]] = 0x1, window[C[460031]][C[460032]]['a1CM4']()), a1M8J4();
  } else a14M[C[460759]][C[460773]] >= 0x3 ? (a1MJ(JSON[C[460023]](m_c)), window['a1J84M'](C[460774] + m_c[C[460425]])) : sendApi(a14M[C[460548]], C[460636], { 'platform': a14M[C[460546]], 'partner_id': a14M[C[460556]], 'token': a14M[C[460634]], 'game_pkg': a14M[C[460018]], 'deviceId': a14M[C[460557]], 'scene': C[460637] + a14M[C[460558]] }, function (idm54) {
    if (!idm54 || idm54[C[460425]] != C[460424]) {
      window['a1J84M'](C[460649] + idm54 && idm54[C[460425]]);return;
    }a14M[C[460652]] = String(idm54[C[460653]]), a14M[C[460654]] = String(idm54[C[460655]]), setTimeout(function () {
      a1MJ84(a14M[C[460759]][C[460773]] + 0x1, a14M[C[460759]][C[460020]]);
    }, 0x5dc);
  }, a18M4, a1MJ, function (djit5) {
    return djit5[C[460425]] == C[460424] || djit5[C[460425]] == C[460775];
  });
}, window['a1M8J4'] = function () {
  ServerLoading[C[460032]][C[460494]](a14M[C[460499]]), window['a18M'] = !![], window['a1M4J8']();
}, window['a1M84J'] = function () {
  if (window['a1M8'] && window['a148M'] && window[C[460490]] && window[C[460493]] && window['a14M8'] && window['a148']) {
    if (!window[C[460776]][C[460032]]) {
      console[C[460038]](C[460777] + window[C[460776]][C[460032]]);var yf1k = wx[C[460778]](),
          sq_r9 = yf1k[C[460133]] ? yf1k[C[460133]] : 0x0,
          itbxh = { 'cdn': window['a14M'][C[460017]], 'spareCdn': window['a14M'][C[460622]], 'newRegister': window['a14M'][C[460499]], 'wxPC': window['a14M'][C[460108]], 'wxIOS': window['a14M'][C[460102]], 'wxAndroid': window['a14M'][C[460105]], 'wxParam': { 'limitLoad': window['a14M']['a1CJ8M4'], 'benchmarkLevel': window['a14M']['a1CJ48M'], 'wxFrom': window[C[460005]][C[460629]] == C[460779] ? 0x1 : 0x0, 'wxSDKVersion': window[C[460036]] }, 'configType': window['a14M'][C[460566]], 'exposeType': window['a14M'][C[460568]], 'scene': sq_r9 };new window[C[460776]](itbxh, window['a14M'][C[460016]], window['a1CJ84M']);
    }
  }
}, window['a1M4J8'] = function () {
  if (window['a1M8'] && window['a148M'] && window[C[460490]] && window[C[460493]] && window['a14M8'] && window['a148'] && window['a18M'] && window['a184']) {
    a1J4M8();if (!a1M84) {
      a1M84 = !![];if (!window[C[460776]][C[460032]]) window['a1M84J']();var d9zjm = 0x0,
          rqs9_ = wx[C[460780]]();rqs9_ && (window['a14M'][C[460107]] && (d9zjm = rqs9_[C[460097]]), console[C[460000]](C[460781] + rqs9_[C[460097]] + C[460782] + rqs9_[C[460098]] + C[460783] + rqs9_[C[460099]] + C[460784] + rqs9_[C[460100]] + C[460785] + rqs9_[C[460294]] + C[460786] + rqs9_[C[460296]]));var r9s_c = {};for (const o5idht in a14M[C[460019]]) {
        r9s_c[o5idht] = a14M[C[460019]][o5idht];
      }var $0fky = { 'channel': window['a14M'][C[460560]], 'account': window['a14M'][C[460015]], 'userId': window['a14M'][C[460650]], 'serverId': r9s_c[C[460020]], 'cdn': window['a14M'][C[460017]], 'data': window['a14M'][C[460426]], 'package': window['a14M'][C[460545]], 'newRegister': window['a14M'][C[460499]], 'pkgName': window['a14M'][C[460018]], 'partnerId': window['a14M'][C[460556]], 'platform_uid': window['a14M'][C[460651]], 'deviceId': window['a14M'][C[460557]], 'selectedServer': r9s_c, 'configType': window['a14M'][C[460566]], 'exposeType': window['a14M'][C[460568]], 'debugUsers': window['a14M'][C[460563]], 'wxMenuTop': d9zjm, 'wxShield': window['a14M'][C[460569]] };if (window[C[460676]]) for (var b2ph in window[C[460676]]) {
        $0fky[b2ph] = window[C[460676]][b2ph];
      }window[C[460776]][C[460032]]['a1M4C']($0fky);
    }
  } else console[C[460000]](C[460787] + window['a1M8'] + C[460788] + window['a148M'] + C[460789] + window[C[460490]] + C[460790] + window[C[460493]] + C[460791] + window['a14M8'] + C[460792] + window['a148'] + C[460793] + window['a18M'] + C[460794] + window['a184']);
};