var C = wx.$a;
import 'a1MAIa1.js';