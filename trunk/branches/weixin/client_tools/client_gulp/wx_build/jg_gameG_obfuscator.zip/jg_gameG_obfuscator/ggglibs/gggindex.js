var m = wx.$g;
import gslgc9 from '../gggsdk/gggsdk.js';window[m[27931]] = { 'wxVersion': window[m[540]][m[27829]] }, window['DEBUG'] = ![], window['G$J3'] = 0x1, window[m[27932]] = 0x1, window['G$03J'] = !![], window[m[27933]] = !![], window['G$V203J'] = '', window['G$3J'] = { 'base_cdn': m[27934], 'cdn': m[27934] }, G$3J[m[27935]] = {}, G$3J[m[23960]] = '0', G$3J[m[4349]] = window[m[27931]][m[27936]], G$3J[m[27904]] = '', G$3J['os'] = '1', G$3J[m[27937]] = m[27938], G$3J[m[27939]] = m[27940], G$3J[m[27941]] = m[27942], G$3J[m[27943]] = m[27944], G$3J[m[27945]] = 'MQx0mYlUWO5XYKvgAIPKWgK1w722GKih', G$3J[m[22679]] = '1', G$3J[m[24239]] = '', G$3J[m[24241]] = '', G$3J[m[27946]] = 0x0, G$3J[m[27947]] = {}, G$3J[m[27948]] = parseInt(G$3J[m[22679]]), G$3J[m[24237]] = G$3J[m[22679]], G$3J[m[24233]] = {}, G$3J['G$23'] = m[27949], G$3J[m[27950]] = ![], G$3J[m[11464]] = m[27951], G$3J[m[24212]] = Date[m[77]](), G$3J[m[11076]] = m[27952], G$3J[m[695]] = '_a', G$3J[m[27953]] = 0x2, G$3J[m[95]] = 0x7c1, G$3J[m[27936]] = window[m[27931]][m[27936]], G$3J[m[709]] = ![], G$3J[m[989]] = ![], G$3J[m[10616]] = ![], G$3J[m[23962]] = ![], window['G$0J3'] = 0x5, window['G$0J'] = ![], window['G$J0'] = ![], window['G$30J'] = ![], window[m[27954]] = ![], window[m[27955]] = ![], window['G$3J0'] = ![], window['G$03'] = ![], window['G$30'] = ![], window['G$J03'] = ![], window[m[27956]] = {}, window[m[3826]] = function (_ibp50) {
  console[m[467]](m[3826], _ibp50), wx[m[4618]]({}), wx[m[27853]]({ 'title': m[5960], 'content': _ibp50, 'success'(vew) {
      if (vew[m[27957]]) console[m[467]](m[27958]);else vew[m[536]] && console[m[467]](m[27959]);
    } });
}, window['G$203J'] = function (apxi) {
  console[m[467]](m[27960], apxi), G$23J0(), wx[m[27853]]({ 'title': m[5960], 'content': apxi, 'confirmText': m[27961], 'cancelText': m[17647], 'success'($2ujr6) {
      if ($2ujr6[m[27957]]) window['G$32']();else $2ujr6[m[536]] && (console[m[467]](m[27962]), wx[m[23955]]({}));
    } });
}, window[m[27963]] = function (evy7wq) {
  console[m[467]](m[27963], evy7wq), wx[m[27853]]({ 'title': m[5960], 'content': evy7wq, 'confirmText': m[24365], 'showCancel': ![], 'complete'(wa1kh) {
      console[m[467]](m[27962]), wx[m[23955]]({});
    } });
}, window['G$20J3'] = ![], window['G$230J'] = function (gcs8) {
  window['G$20J3'] = !![], wx[m[4617]](gcs8);
}, window['G$23J0'] = function () {
  window['G$20J3'] && (window['G$20J3'] = ![], wx[m[4618]]({}));
}, window['G$2J03'] = function (kwyhe1) {
  window[m[27844]][m[141]]['G$2J03'](kwyhe1);
}, window[m[11345]] = function (p0_tf4, f_t4) {
  gslgc9[m[11345]](p0_tf4, function (l8sgc) {
    l8sgc && l8sgc[m[11]] ? l8sgc[m[11]][m[3761]] == 0x1 ? f_t4(!![]) : (f_t4(![]), console[m[72]](m[27964] + l8sgc[m[11]][m[27965]])) : console[m[467]](m[11345], l8sgc);
  });
}, window['G$2J30'] = function (wyk7ve) {
  console[m[467]](m[27966], wyk7ve);
}, window['G$23J'] = function (k1hxwa) {}, window['G$2J3'] = function (_03t4f, fd3ot4, ia0b) {}, window['G$2J'] = function (od243) {
  console[m[467]]('toEnterGame', od243), window[m[27844]][m[141]][m[27967]](), window[m[27844]][m[141]][m[27968]](), window[m[27844]][m[141]][m[27969]]();
}, window['G$J2'] = function (tb_pf0) {
  window['G$203J'](m[27970]);var cqg7s8 = { 'id': window['G$3J'][m[27834]], 'role': window['G$3J'][m[4280]], 'level': window['G$3J'][m[27835]], 'account': window['G$3J'][m[24238]], 'version': window['G$3J'][m[95]], 'cdn': window['G$3J'][m[4157]], 'pkgName': window['G$3J'][m[24239]], 'gamever': window[m[540]][m[27829]], 'serverid': window['G$3J'][m[24233]] ? window['G$3J'][m[24233]][m[10787]] : 0x0, 'systemInfo': window[m[27836]], 'error': m[27971], 'stack': tb_pf0 ? tb_pf0 : m[27970] },
      gs8q = JSON[m[4143]](cqg7s8);console[m[119]](m[27972] + gs8q), window['G$23'](gs8q);
}, window['G$32J'] = function (todz4) {
  var sc8g7q = JSON[m[512]](todz4);sc8g7q[m[27973]] = window[m[540]][m[27829]], sc8g7q[m[27974]] = window['G$3J'][m[24233]] ? window['G$3J'][m[24233]][m[10787]] : 0x0, sc8g7q[m[27836]] = window[m[27836]];var z2r$6 = JSON[m[4143]](sc8g7q);console[m[119]](m[27975] + z2r$6), window['G$23'](z2r$6);
}, window['G$3J2'] = function (vy7qge, z$6r) {
  var i1xa = { 'id': window['G$3J'][m[27834]], 'role': window['G$3J'][m[4280]], 'level': window['G$3J'][m[27835]], 'account': window['G$3J'][m[24238]], 'version': window['G$3J'][m[95]], 'cdn': window['G$3J'][m[4157]], 'pkgName': window['G$3J'][m[24239]], 'gamever': window[m[540]][m[27829]], 'serverid': window['G$3J'][m[24233]] ? window['G$3J'][m[24233]][m[10787]] : 0x0, 'systemInfo': window[m[27836]], 'error': vy7qge, 'stack': z$6r },
      xa51h = JSON[m[4143]](i1xa);console[m[90]](m[27976] + xa51h), window['G$23'](xa51h);
}, window['G$23'] = function (vweq7) {
  if (window['G$3J'][m[27905]] == m[27977]) return;var pba0i5 = G$3J['G$23'] + m[27978] + G$3J[m[24238]];wx[m[462]]({ 'url': pba0i5, 'method': m[27979], 'data': vweq7, 'header': { 'content-type': m[27980], 'cache-control': m[27981] }, 'success': function (xhk1y) {
      DEBUG && console[m[467]](m[27982], pba0i5, vweq7, xhk1y);
    }, 'fail': function (f4o3_) {
      DEBUG && console[m[467]](m[27982], pba0i5, vweq7, f4o3_);
    }, 'complete': function () {} });
}, window[m[27983]] = function () {
  function r6d2jz() {
    return ((0x1 + Math[m[113]]()) * 0x10000 | 0x0)[m[266]](0x10)[m[485]](0x1);
  }return r6d2jz() + r6d2jz() + '-' + r6d2jz() + '-' + r6d2jz() + '-' + r6d2jz() + '+' + r6d2jz() + r6d2jz() + r6d2jz();
}, window['G$32'] = function () {
  console[m[467]](m[27984]);var _0b5pi = gslgc9[m[27985]]();G$3J[m[24237]] = _0b5pi[m[27986]], G$3J[m[27948]] = _0b5pi[m[27986]], G$3J[m[22679]] = _0b5pi[m[27986]], G$3J[m[24239]] = _0b5pi[m[27987]];var rj62z = { 'game_ver': G$3J[m[4349]] };G$3J[m[24241]] = this[m[27983]](), G$230J({ 'title': m[27988] }), gslgc9[m[359]](rj62z, this['G$J23'][m[68]](this));
}, window['G$J23'] = function (r2zo6) {
  var e7vqw = r2zo6[m[27989]];sdk_info = r2zo6, console[m[467]](m[27990] + e7vqw + m[27991] + (e7vqw == 0x1) + m[27992] + r2zo6[m[27829]] + m[27993] + window[m[27931]][m[27936]]);if (!r2zo6[m[27829]] || window['G$V0J23'](window[m[27931]][m[27936]], r2zo6[m[27829]]) < 0x0) console[m[467]](m[27994]), G$3J[m[27939]] = m[27995], G$3J[m[27941]] = m[27996], G$3J[m[27943]] = m[27997], G$3J[m[4157]] = m[27998], G$3J[m[23959]] = m[27999], G$3J[m[28000]] = 'ws', G$3J[m[709]] = ![];else window['G$V0J23'](window[m[27931]][m[27936]], r2zo6[m[27829]]) == 0x0 ? (console[m[467]](m[28001]), G$3J[m[27939]] = m[27940], G$3J[m[27941]] = m[27942], G$3J[m[27943]] = m[27944], G$3J[m[4157]] = m[28002], G$3J[m[23959]] = m[27999], G$3J[m[28000]] = m[28003], G$3J[m[709]] = !![]) : (console[m[467]](m[28004]), G$3J[m[27939]] = m[27940], G$3J[m[27941]] = m[27942], G$3J[m[27943]] = m[27944], G$3J[m[4157]] = m[28002], G$3J[m[23959]] = m[27999], G$3J[m[28000]] = m[28003], G$3J[m[709]] = ![]);G$3J[m[27946]] = config[m[27707]] ? config[m[27707]] : 0x0, this['G$032J'](), this['G$03J2'](), window[m[28005]] = 0x5, G$230J({ 'title': m[28006] }), gslgc9[m[28007]](this['G$J32'][m[68]](this));
}, window[m[28005]] = 0x5, window['G$J32'] = function (xih1a5, rdz6) {
  if (xih1a5 == 0x0 && rdz6 && rdz6[m[27800]]) {
    G$3J[m[28008]] = rdz6[m[27800]], G$3J[m[28009]] = rdz6[m[28009]];var h1xky = this;G$230J({ 'title': m[28010] }), sendApi(G$3J[m[27939]], m[28011], { 'platform': G$3J[m[27937]], 'partner_id': G$3J[m[22679]], 'token': rdz6[m[27800]], 'game_pkg': G$3J[m[24239]], 'deviceId': G$3J[m[24241]], 'scene': m[28012] + G$3J[m[27946]] }, this['G$023J'][m[68]](this), G$0J3, G$J2);
  } else rdz6 && rdz6[m[24417]] && window[m[28005]] > 0x0 && (rdz6[m[24417]][m[109]](m[28013]) != -0x1 || rdz6[m[24417]][m[109]](m[28014]) != -0x1 || rdz6[m[24417]][m[109]](m[28015]) != -0x1 || rdz6[m[24417]][m[109]](m[28016]) != -0x1 || rdz6[m[24417]][m[109]](m[28017]) != -0x1 || rdz6[m[24417]][m[109]](m[28018]) != -0x1) ? (window[m[28005]]--, gslgc9[m[28007]](this['G$J32'][m[68]](this))) : (window['G$3J2'](m[28019], JSON[m[4143]]({ 'status': xih1a5, 'data': rdz6 })), window['G$203J'](m[28020] + (rdz6 && rdz6[m[24417]] ? '，' + rdz6[m[24417]] : '')));
}, window['G$023J'] = function (ve7qyg) {
  if (!ve7qyg) {
    window['G$3J2'](m[28021], m[28022]), window['G$203J'](m[28023]);return;
  }if (ve7qyg[m[3761]] != m[9318]) {
    window['G$3J2'](m[28021], JSON[m[4143]](ve7qyg)), window['G$203J'](m[28024] + ve7qyg[m[3761]]);return;
  }G$3J[m[22678]] = String(ve7qyg[m[24238]]), G$3J[m[24238]] = String(ve7qyg[m[24238]]), G$3J[m[24210]] = String(ve7qyg[m[24210]]), G$3J[m[24237]] = String(ve7qyg[m[24210]]), G$3J[m[24240]] = String(ve7qyg[m[24240]]), G$3J[m[28025]] = String(ve7qyg[m[10772]]), G$3J[m[28026]] = String(ve7qyg[m[811]]), G$3J[m[10772]] = '';var glqsc8 = this;G$230J({ 'title': m[28027] }), sendApi(G$3J[m[27939]], m[28028], { 'partner_id': G$3J[m[22679]], 'uid': G$3J[m[24238]], 'version': G$3J[m[4349]], 'game_pkg': G$3J[m[24239]], 'device': G$3J[m[24241]] }, glqsc8['G$02J3'][m[68]](glqsc8), G$0J3, G$J2);
}, window['G$02J3'] = function (qcgls8) {
  if (!qcgls8) {
    window['G$203J'](m[28029]);return;
  }if (qcgls8[m[3761]] != m[9318]) {
    window['G$203J'](m[28030] + qcgls8[m[3761]]);return;
  }if (!qcgls8[m[11]] || qcgls8[m[11]][m[13]] == 0x0) {
    window['G$203J'](m[28031]);return;
  }G$3J[m[613]] = qcgls8[m[28032]], G$3J[m[24233]] = { 'server_id': String(qcgls8[m[11]][0x0][m[10787]]), 'server_name': String(qcgls8[m[11]][0x0][m[28033]]), 'entry_ip': qcgls8[m[11]][0x0][m[24261]], 'entry_port': parseInt(qcgls8[m[11]][0x0][m[24262]]), 'status': G$302(qcgls8[m[11]][0x0]), 'start_time': qcgls8[m[11]][0x0][m[28034]], 'cdn': G$3J[m[4157]] }, this['G$J302']();
}, window['G$J302'] = function () {
  if (G$3J[m[613]] == 0x1) {
    var h1wey = G$3J[m[24233]][m[100]];if (h1wey === -0x1 || h1wey === 0x0) {
      window['G$203J'](h1wey === -0x1 ? m[28035] : m[28036]);return;
    }G$J203(0x0, G$3J[m[24233]][m[10787]]), window[m[27844]][m[141]][m[28037]](G$3J[m[613]]);
  } else window[m[27844]][m[141]][m[28038]](), G$23J0();window['G$30'] = !![], window['G$J032'](), window['G$J320']();
}, window['G$032J'] = function () {
  sendApi(G$3J[m[27939]], m[28039], { 'game_pkg': G$3J[m[24239]], 'version_name': G$3J[m[28000]] }, this[m[28040]][m[68]](this), G$0J3, G$J2);
}, window[m[28040]] = function (t4f_03) {
  if (!t4f_03) {
    window['G$203J'](m[28041]);return;
  }if (t4f_03[m[3761]] != m[9318]) {
    window['G$203J'](m[28042] + t4f_03[m[3761]]);return;
  }if (!t4f_03[m[11]] || !t4f_03[m[11]][m[4349]]) {
    window['G$203J'](m[28043] + (t4f_03[m[11]] && t4f_03[m[11]][m[4349]]));return;
  }t4f_03[m[11]][m[28044]] && t4f_03[m[11]][m[28044]][m[13]] > 0xa && (G$3J[m[28045]] = t4f_03[m[11]][m[28044]], G$3J[m[4157]] = t4f_03[m[11]][m[28044]]), t4f_03[m[11]][m[4349]] && (G$3J[m[95]] = t4f_03[m[11]][m[4349]]), console[m[72]](m[24371] + G$3J[m[95]] + m[28046] + G$3J[m[28000]]), window['G$3J0'] = !![], window['G$J032'](), window['G$J320']();
}, window[m[28047]], window['G$03J2'] = function () {
  sendApi(G$3J[m[27939]], m[28048], { 'game_pkg': G$3J[m[24239]] }, this['G$0J23'][m[68]](this), G$0J3, G$J2);
}, window['G$0J23'] = function (yehw1) {
  if (yehw1[m[3761]] === m[9318] && yehw1[m[11]]) {
    window[m[28047]] = yehw1[m[11]];for (var $2j6r in yehw1[m[11]]) {
      G$3J[$2j6r] = yehw1[m[11]][$2j6r];
    }
  } else console[m[72]](m[28049] + yehw1[m[3761]]);window['G$03'] = !![], window['G$J320']();
}, window[m[28050]] = function (zo32d, zd2o4, ek7wyv, xkh1w, ye7kw, b_0tf, zj6r, p5b, f0pt4) {
  ye7kw = String(ye7kw);var _ftp4 = zj6r,
      d6o23z = p5b;G$3J[m[27935]][ye7kw] = { 'productid': ye7kw, 'productname': _ftp4, 'productdesc': d6o23z, 'roleid': zo32d, 'rolename': zd2o4, 'rolelevel': ek7wyv, 'price': b_0tf, 'callback': f0pt4 }, sendApi(G$3J[m[27943]], m[28051], { 'game_pkg': G$3J[m[24239]], 'server_id': G$3J[m[24233]][m[10787]], 'server_name': G$3J[m[24233]][m[28033]], 'level': ek7wyv, 'uid': G$3J[m[24238]], 'role_id': zo32d, 'role_name': zd2o4, 'product_id': ye7kw, 'product_name': _ftp4, 'product_desc': d6o23z, 'money': b_0tf, 'partner_id': G$3J[m[22679]] }, toPayCallBack, G$0J3, G$J2);
}, window[m[28052]] = function (fd4to3) {
  if (fd4to3) {
    if (fd4to3[m[28053]] === 0xc8 || fd4to3[m[3761]] == m[9318]) {
      var do3ft4 = G$3J[m[27935]][String(fd4to3[m[28054]])];if (do3ft4[m[326]]) do3ft4[m[326]](fd4to3[m[28054]], fd4to3[m[28055]], -0x1);gslgc9[m[28056]]({ 'cpbill': fd4to3[m[28055]], 'productid': fd4to3[m[28054]], 'productname': do3ft4[m[28057]], 'productdesc': do3ft4[m[28058]], 'serverid': G$3J[m[24233]][m[10787]], 'servername': G$3J[m[24233]][m[28033]], 'roleid': do3ft4[m[28059]], 'rolename': do3ft4[m[28060]], 'rolelevel': do3ft4[m[28061]], 'price': do3ft4[m[25921]], 'extension': JSON[m[4143]]({ 'cp_order_id': fd4to3[m[28055]] }) }, function (hwak1x, lgcs8q) {
        do3ft4[m[326]] && hwak1x == 0x0 && do3ft4[m[326]](fd4to3[m[28054]], fd4to3[m[28055]], hwak1x);console[m[72]](JSON[m[4143]]({ 'type': m[28062], 'status': hwak1x, 'data': fd4to3, 'role_name': do3ft4[m[28060]] }));if (hwak1x === 0x0) {} else {
          if (hwak1x === 0x1) {} else {
            if (hwak1x === 0x2) {}
          }
        }
      });
    } else alert(fd4to3[m[72]]);
  }
}, window['G$0J32'] = function () {}, window['G$20J'] = function (aihxb5, a1xhwk, z2j6r, keh1, _f0pt4) {
  gslgc9[m[28063]](G$3J[m[24233]][m[10787]], G$3J[m[24233]][m[28033]] || G$3J[m[24233]][m[10787]], aihxb5, a1xhwk, z2j6r), sendApi(G$3J[m[27939]], m[28064], { 'game_pkg': G$3J[m[24239]], 'server_id': G$3J[m[24233]][m[10787]], 'role_id': aihxb5, 'uid': G$3J[m[24238]], 'role_name': a1xhwk, 'role_type': keh1, 'level': z2j6r });
}, window['G$2J0'] = function (xi5a1, egvcq7, zor2d, abhxi, hy1wke, to4dz3, qs7vc, jmu$6, d3zot, bi5a0p) {
  G$3J[m[27834]] = xi5a1, G$3J[m[4280]] = egvcq7, G$3J[m[27835]] = zor2d, gslgc9['logEnterGame'](G$3J[m[24233]][m[10787]], G$3J[m[24233]][m[28033]] || G$3J[m[24233]][m[10787]], xi5a1, egvcq7, zor2d, to4dz3, { 'rolepower': qs7vc }), sendApi(G$3J[m[27939]], m[28065], { 'game_pkg': G$3J[m[24239]], 'server_id': G$3J[m[24233]][m[10787]], 'role_id': xi5a1, 'uid': G$3J[m[24238]], 'role_name': egvcq7, 'role_type': abhxi, 'level': zor2d, 'evolution': hy1wke });
}, window['G$02J'] = function (i5haxb, pbi0, to34_, f_bp0t, w1kyxh, t_043f, $rj2u6, wye7, ap5i0, s8cgql) {
  G$3J[m[27834]] = i5haxb, G$3J[m[4280]] = pbi0, G$3J[m[27835]] = to34_, gslgc9[m[28066]](G$3J[m[24233]][m[10787]], G$3J[m[24233]][m[28033]] || G$3J[m[24233]][m[10787]], i5haxb, pbi0, to34_), sendApi(G$3J[m[27939]], m[28065], { 'game_pkg': G$3J[m[24239]], 'server_id': G$3J[m[24233]][m[10787]], 'role_id': i5haxb, 'uid': G$3J[m[24238]], 'role_name': pbi0, 'role_type': f_bp0t, 'level': to34_, 'evolution': w1kyxh });
}, window['G$0J2'] = function (c8q7g) {}, window['G$20'] = function (b05i_p) {
  gslgc9[m[28067]](m[28067], function (ywe7q) {
    b05i_p && b05i_p(ywe7q);
  });
}, window[m[23939]] = function () {
  gslgc9[m[28068]](G$3J[m[24233]][m[10787]], G$3J[m[24233]][m[28033]] || G$3J[m[24233]][m[10787]], G$3J[m[27834]], G$3J[m[4280]], G$3J[m[27835]]);
}, window['microPortGuide'] = function () {
  gslgc9[m[22580]]();
}, window[m[28069]] = function (s8lgc, p0b_5f, b0t_fp, pi5abx, h1kew, rdzj2, z24do, geqvy7) {
  geqvy7 = geqvy7 || G$3J[m[24233]][m[10787]], sendApi(G$3J[m[27939]], m[28070], { 'phone': s8lgc, 'role_id': p0b_5f, 'uid': G$3J[m[24238]], 'game_pkg': G$3J[m[24239]], 'partner_id': G$3J[m[22679]], 'server_id': geqvy7 }, z24do);
}, window[m[10172]] = function (y7wq) {
  window['G$J20'] = y7wq, window['G$J20'] && window['G$02'] && (console[m[72]](m[27924] + window['G$02'][m[742]]), window['G$J20'](window['G$02']), window['G$02'] = null);
}, window['G$J02'] = function (wev7q, kxy, otdz, pi0) {
  window[m[22]](m[28071], { 'game_pkg': window['G$3J'][m[24239]], 'role_id': kxy, 'server_id': otdz }, pi0);
}, window['G$320J'] = function (aikhx, jr6) {
  function bixp5(_ftb) {
    var _0pi5b = [],
        j2r$ = [],
        _t0fbp = window[m[540]][m[28072]];for (var $2z6jr in _t0fbp) {
      var o34dt = Number($2z6jr);(!aikhx || !aikhx[m[13]] || aikhx[m[109]](o34dt) != -0x1) && (j2r$[m[29]](_t0fbp[$2z6jr]), _0pi5b[m[29]]([o34dt, 0x3]));
    }window['G$V0J23'](window[m[27845]], m[28073]) >= 0x0 ? (console[m[467]](m[28074]), gslgc9[m[28075]] && gslgc9[m[28075]](j2r$, function (t4zod3) {
      console[m[467]](m[28076]), console[m[467]](t4zod3);if (t4zod3 && t4zod3[m[24417]] == m[28077]) for (var ygqe7v in _t0fbp) {
        if (t4zod3[_t0fbp[ygqe7v]] == m[28078]) {
          var eqcg7 = Number(ygqe7v);for (var scg98 = 0x0; scg98 < _0pi5b[m[13]]; scg98++) {
            if (_0pi5b[scg98][0x0] == eqcg7) {
              _0pi5b[scg98][0x1] = 0x1;break;
            }
          }
        }
      }window['G$V0J23'](window[m[27845]], m[28079]) >= 0x0 ? wx[m[28080]]({ 'withSubscriptions': !![], 'success': function (p05_bf) {
          var f0_p5 = p05_bf[m[28081]][m[28082]];if (f0_p5) {
            console[m[467]](m[28083]), console[m[467]](f0_p5);for (var ru6$jm in _t0fbp) {
              if (f0_p5[_t0fbp[ru6$jm]] == m[28078]) {
                var dzo4t3 = Number(ru6$jm);for (var cl98g = 0x0; cl98g < _0pi5b[m[13]]; cl98g++) {
                  if (_0pi5b[cl98g][0x0] == dzo4t3) {
                    _0pi5b[cl98g][0x1] = 0x2;break;
                  }
                }
              }
            }console[m[467]](_0pi5b), jr6 && jr6(_0pi5b);
          } else console[m[467]](m[28084]), console[m[467]](p05_bf), console[m[467]](_0pi5b), jr6 && jr6(_0pi5b);
        }, 'fail': function () {
          console[m[467]](m[28085]), console[m[467]](_0pi5b), jr6 && jr6(_0pi5b);
        } }) : (console[m[467]](m[28086] + window[m[27845]]), console[m[467]](_0pi5b), jr6 && jr6(_0pi5b));
    })) : (console[m[467]](m[28087] + window[m[27845]]), console[m[467]](_0pi5b), jr6 && jr6(_0pi5b)), wx[m[28088]](bixp5);
  }wx[m[28089]](bixp5);
}, window['G$32J0'] = { 'isSuccess': ![], 'level': m[28090], 'isCharging': ![] }, window['G$302J'] = function (tzo43) {
  wx[m[27913]]({ 'success': function (vyek1) {
      var we7vyk = window['G$32J0'];we7vyk[m[28091]] = !![], we7vyk[m[4256]] = Number(vyek1[m[4256]])[m[3871]](0x0), we7vyk[m[27916]] = vyek1[m[27916]], tzo43 && tzo43(we7vyk[m[28091]], we7vyk[m[4256]], we7vyk[m[27916]]);
    }, 'fail': function (yvq7g) {
      console[m[467]](m[28092], yvq7g[m[24417]]);var ykhe1w = window['G$32J0'];tzo43 && tzo43(ykhe1w[m[28091]], ykhe1w[m[4256]], ykhe1w[m[27916]]);
    } });
}, window[m[22]] = function (p_f4, h1xkw, _0pt, yev1k, r2zj6d, x1aihk, do423, qe7yvw) {
  if (yev1k == undefined) yev1k = 0x1;wx[m[462]]({ 'url': p_f4, 'method': do423 || 'GET', 'responseType': m[4064], 'data': h1xkw, 'header': { 'content-type': qe7yvw || m[27980] }, 'success': function (qc8lgs) {
      DEBUG && console[m[467]](m[28093], p_f4, info, qc8lgs);if (qc8lgs && qc8lgs[m[24488]] == 0xc8) {
        var x1yw = qc8lgs[m[11]];!x1aihk || x1aihk(x1yw) ? _0pt && _0pt(x1yw) : window[m[28094]](p_f4, h1xkw, _0pt, yev1k, r2zj6d, x1aihk, qc8lgs);
      } else window[m[28094]](p_f4, h1xkw, _0pt, yev1k, r2zj6d, x1aihk, qc8lgs);
    }, 'fail': function (y1khw) {
      DEBUG && console[m[467]](m[28095], p_f4, info, y1khw), window[m[28094]](p_f4, h1xkw, _0pt, yev1k, r2zj6d, x1aihk, y1khw);
    }, 'complete': function () {} });
}, window[m[28094]] = function (zo62dr, _t03f4, bft0_, o2d36, haixk, b_i50p, kv7eyw) {
  o2d36 - 0x1 > 0x0 ? setTimeout(function () {
    window[m[22]](zo62dr, _t03f4, bft0_, o2d36 - 0x1, haixk, b_i50p);
  }, 0x3e8) : haixk && haixk(JSON[m[4143]]({ 'url': zo62dr, 'response': kv7eyw }));
}, window[m[28096]] = function (bpi5xa, pbft0, ruj2$6, tof34_, h1aikx, kh1wax, hk1x) {
  !ruj2$6 && (ruj2$6 = {});var _4f3ot = Math[m[112]](Date[m[77]]() / 0x3e8);ruj2$6[m[811]] = _4f3ot, ruj2$6[m[28097]] = pbft0;var eyq7v = Object[m[259]](ruj2$6)[m[993]](),
      ew7y = '',
      dr2zo = '';for (var g9c8ls = 0x0; g9c8ls < eyq7v[m[13]]; g9c8ls++) {
    ew7y = ew7y + (g9c8ls == 0x0 ? '' : '&') + eyq7v[g9c8ls] + ruj2$6[eyq7v[g9c8ls]], dr2zo = dr2zo + (g9c8ls == 0x0 ? '' : '&') + eyq7v[g9c8ls] + '=' + encodeURIComponent(ruj2$6[eyq7v[g9c8ls]]);
  }ew7y = ew7y + G$3J[m[27945]];var o243z = m[28098] + md5(ew7y);send(bpi5xa + '?' + dr2zo + (dr2zo == '' ? '' : '&') + o243z, null, tof34_, h1aikx, kh1wax, hk1x || function (r2jzd) {
    return r2jzd[m[3761]] == m[9318];
  }, null, m[28099]);
}, window['G$30J2'] = function (i5bpax, y1kvew) {
  var h5i1 = 0x0;G$3J[m[24233]] && (h5i1 = G$3J[m[24233]][m[10787]]), sendApi(G$3J[m[27941]], m[28100], { 'partnerId': G$3J[m[22679]], 'gamePkg': G$3J[m[24239]], 'logTime': Math[m[112]](Date[m[77]]() / 0x3e8), 'platformUid': G$3J[m[24240]], 'type': i5bpax, 'serverId': h5i1 }, null, 0x2, null, function () {
    return !![];
  });
}, window['G$3J20'] = function (hi1ka) {
  sendApi(G$3J[m[27939]], 'Server.getServerGroup', { 'partner_id': G$3J[m[22679]], 'uid': G$3J[m[24238]], 'version': G$3J[m[4349]], 'game_pkg': G$3J[m[24239]], 'device': G$3J[m[24241]] }, G$3J02, G$0J3, G$J2);
}, window['G$3J02'] = function (e7vg) {
  if (e7vg[m[3761]] === m[9318] && e7vg[m[11]]) {
    e7vg[m[11]][m[5203]]({ 'id': -0x2, 'name': m[28101] }), e7vg[m[11]][m[5203]]({ 'id': -0x1, 'name': m[28102] }), G$3J[m[28103]] = e7vg[m[11]];if (window[m[11511]]) window[m[11511]]['showGroupList']();
  } else G$3J['hasGroupReq'] = ![], window['G$203J']('reqServerGroupCallBack ' + e7vg[m[3761]]);
}, window['G$203'] = function (w7eyvq) {
  sendApi(G$3J[m[27939]], m[28104], { 'partner_id': G$3J[m[22679]], 'uid': G$3J[m[24238]], 'version': G$3J[m[4349]], 'game_pkg': G$3J[m[24239]], 'device': G$3J[m[24241]] }, G$230, G$0J3, G$J2);
}, window['G$230'] = function (_pt0bf) {
  G$3J[m[28105]] = ![];if (_pt0bf[m[3761]] === m[9318] && _pt0bf[m[11]]) {
    for (var qvgs7c = 0x0; qvgs7c < _pt0bf[m[11]][m[13]]; qvgs7c++) {
      _pt0bf[m[11]][qvgs7c][m[100]] = G$302(_pt0bf[m[11]][qvgs7c]);
    }G$3J[m[27947]][-0x1] = window[m[28106]](_pt0bf[m[11]]), window[m[11511]][m[28107]](-0x1);
  } else window['G$203J'](m[28108] + _pt0bf[m[3761]]);
}, window[m[28109]] = function (o3z4) {
  sendApi(G$3J[m[27939]], m[28104], { 'partner_id': G$3J[m[22679]], 'uid': G$3J[m[24238]], 'version': G$3J[m[4349]], 'game_pkg': G$3J[m[24239]], 'device': G$3J[m[24241]] }, o3z4, G$0J3, G$J2);
}, window['G$023'] = function (xai5bh, a1ix5h) {
  sendApi(G$3J[m[27939]], 'Server.getServerByGroup', { 'partner_id': G$3J[m[22679]], 'uid': G$3J[m[24238]], 'version': G$3J[m[4349]], 'game_pkg': G$3J[m[24239]], 'device': G$3J[m[24241]], 'server_group_id': a1ix5h }, G$032, G$0J3, G$J2);
}, window['G$032'] = function (y1wek) {
  G$3J[m[28105]] = ![];if (y1wek[m[3761]] === m[9318] && y1wek[m[11]] && y1wek[m[11]][m[11]]) {
    var ab0i5 = y1wek[m[11]][m[28110]],
        s98l = [];for (var eyh1kw = 0x0; eyh1kw < y1wek[m[11]][m[11]][m[13]]; eyh1kw++) {
      y1wek[m[11]][m[11]][eyh1kw][m[100]] = G$302(y1wek[m[11]][m[11]][eyh1kw]), (s98l[m[13]] == 0x0 || y1wek[m[11]][m[11]][eyh1kw][m[100]] != 0x0) && (s98l[s98l[m[13]]] = y1wek[m[11]][m[11]][eyh1kw]);
    }G$3J[m[27947]][ab0i5] = window[m[28106]](s98l), window[m[11511]][m[28107]](ab0i5);
  } else window['G$203J'](m[28111] + y1wek[m[3761]]);
}, window['G$V0J3'] = function (_4t3o) {
  sendApi(G$3J[m[27939]], m[28112], { 'partner_id': G$3J[m[22679]], 'uid': G$3J[m[24238]], 'version': G$3J[m[4349]], 'game_pkg': G$3J[m[24239]], 'device': G$3J[m[24241]] }, reqServerRecommendCallBack, G$0J3, G$J2);
}, window[m[28113]] = function (h1xkaw) {
  G$3J[m[28105]] = ![];if (h1xkaw[m[3761]] === m[9318] && h1xkaw[m[11]]) {
    for (var p_fb0t = 0x0; p_fb0t < h1xkaw[m[11]][m[13]]; p_fb0t++) {
      h1xkaw[m[11]][p_fb0t][m[100]] = G$302(h1xkaw[m[11]][p_fb0t]);
    }G$3J[m[27947]][-0x2] = window[m[28106]](h1xkaw[m[11]]), window[m[11511]][m[28107]](-0x2);
  } else alert(m[28114] + h1xkaw[m[3761]]);
}, window[m[28106]] = function (to4fd) {
  if (!to4fd && to4fd[m[13]] <= 0x0) return to4fd;for (let ce7qg = 0x0; ce7qg < to4fd[m[13]]; ce7qg++) {
    to4fd[ce7qg][m[28115]] && to4fd[ce7qg][m[28115]] == 0x1 && (to4fd[ce7qg][m[28033]] += m[28116]);
  }return to4fd;
}, window['G$320'] = function (u6r2$j, u$2rj6) {
  u6r2$j = u6r2$j || G$3J[m[24233]][m[10787]], sendApi(G$3J[m[27939]], m[28117], { 'type': '4', 'game_pkg': G$3J[m[24239]], 'server_id': u6r2$j }, u$2rj6);
}, window[m[28118]] = function ($62rzj, q7eyvg, k1hwy, qcve7) {
  k1hwy = k1hwy || G$3J[m[24233]][m[10787]], sendApi(G$3J[m[27939]], m[28119], { 'type': $62rzj, 'game_pkg': q7eyvg, 'server_id': k1hwy }, qcve7);
}, window['G$302'] = function (iab5px) {
  if (iab5px) {
    if (iab5px[m[100]] == 0x1) {
      if (iab5px[m[28120]] == 0x1) return 0x2;else return 0x1;
    } else return iab5px[m[100]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['G$J203'] = function (to4z3, eqgyv) {
  G$3J[m[28121]] = { 'step': to4z3, 'server_id': eqgyv };var z6rj2$ = this;G$230J({ 'title': m[28122] }), sendApi(G$3J[m[27939]], m[28123], { 'partner_id': G$3J[m[22679]], 'uid': G$3J[m[24238]], 'game_pkg': G$3J[m[24239]], 'server_id': eqgyv, 'platform': G$3J[m[24210]], 'platform_uid': G$3J[m[24240]], 'check_login_time': G$3J[m[28026]], 'check_login_sign': G$3J[m[28025]], 'version_name': G$3J[m[28000]] }, G$J230, G$0J3, G$J2, function (sqgl8) {
    return sqgl8[m[3761]] == m[9318] || sqgl8[m[72]] == m[28124] || sqgl8[m[72]] == m[28125];
  });
}, window['G$J230'] = function (ev7gc) {
  var cge7qv = this;if (ev7gc[m[3761]] === m[9318] && ev7gc[m[11]]) {
    var apbx5 = G$3J[m[24233]];apbx5[m[28126]] = G$3J[m[27948]], apbx5[m[10772]] = String(ev7gc[m[11]][m[28127]]), apbx5[m[24212]] = parseInt(ev7gc[m[11]][m[811]]);if (ev7gc[m[11]][m[24211]]) apbx5[m[24211]] = parseInt(ev7gc[m[11]][m[24211]]);else apbx5[m[24211]] = parseInt(ev7gc[m[11]][m[10787]]);apbx5[m[28128]] = 0x0, apbx5[m[4157]] = G$3J[m[28045]], apbx5[m[28129]] = ev7gc[m[11]][m[28130]], apbx5[m[28131]] = ev7gc[m[11]][m[28131]], console[m[467]](m[28132] + JSON[m[4143]](apbx5[m[28131]])), G$3J[m[613]] == 0x1 && apbx5[m[28131]] && apbx5[m[28131]][m[28133]] == 0x1 && (G$3J['showGetBtn'] = 0x1, window[m[27844]][m[141]]['G$VJ3']()), G$J023();
  } else G$3J[m[28121]][m[6696]] >= 0x3 ? (G$J2(JSON[m[4143]](ev7gc)), window['G$203J'](m[28134] + ev7gc[m[3761]])) : sendApi(G$3J[m[27939]], m[28011], { 'platform': G$3J[m[27937]], 'partner_id': G$3J[m[22679]], 'token': G$3J[m[28008]], 'game_pkg': G$3J[m[24239]], 'deviceId': G$3J[m[24241]], 'scene': m[28012] + G$3J[m[27946]] }, function (rjz2) {
    if (!rjz2 || rjz2[m[3761]] != m[9318]) {
      window['G$203J'](m[28024] + rjz2 && rjz2[m[3761]]);return;
    }G$3J[m[28025]] = String(rjz2[m[10772]]), G$3J[m[28026]] = String(rjz2[m[811]]), setTimeout(function () {
      G$J203(G$3J[m[28121]][m[6696]] + 0x1, G$3J[m[28121]][m[10787]]);
    }, 0x5dc);
  }, G$0J3, G$J2, function (dot4f) {
    return dot4f[m[3761]] == m[9318] || dot4f[m[3761]] == m[24567];
  });
}, window['G$J023'] = function () {
  ServerLoading[m[141]][m[28037]](G$3J[m[613]]), window['G$0J'] = !![], window['G$J320']();
}, window['G$J032'] = function () {
  if (window['G$J0'] && window['G$30J'] && window[m[27954]] && window[m[27955]] && window['G$3J0'] && window['G$30']) {
    if (!window[m[27456]][m[141]]) {
      console[m[467]](m[28135] + window[m[27456]][m[141]]);var t0f3 = wx[m[28136]](),
          a1hi5 = t0f3[m[742]] ? t0f3[m[742]] : 0x0,
          x1hak = { 'cdn': window['G$3J'][m[4157]], 'spareCdn': window['G$3J'][m[23959]], 'newRegister': window['G$3J'][m[613]], 'wxPC': window['G$3J'][m[23962]], 'wxIOS': window['G$3J'][m[989]], 'wxAndroid': window['G$3J'][m[10616]], 'wxParam': { 'limitLoad': window['G$3J']['G$V20J3'], 'benchmarkLevel': window['G$3J']['G$V230J'], 'wxFrom': window[m[540]][m[27707]] == m[28137] ? 0x1 : 0x0, 'wxSDKVersion': window[m[27845]] }, 'configType': window['G$3J'][m[11076]], 'exposeType': window['G$3J'][m[695]], 'scene': a1hi5 };new window[m[27456]](x1hak, window['G$3J'][m[95]], window['G$V203J']);
    }
  }
}, window['G$J320'] = function () {
  if (window['G$J0'] && window['G$30J'] && window[m[27954]] && window[m[27955]] && window['G$3J0'] && window['G$30'] && window['G$0J'] && window['G$03']) {
    G$23J0();if (!G$J03) {
      G$J03 = !![];if (!window[m[27456]][m[141]]) window['G$J032']();var a51hix = 0x0,
          xabh = wx[m[28138]]();xabh && (window['G$3J'][m[27902]] && (a51hix = xabh[m[314]]), console[m[72]](m[28139] + xabh[m[314]] + m[28140] + xabh[m[1125]] + m[28141] + xabh[m[1127]] + m[28142] + xabh[m[1126]] + m[28143] + xabh[m[169]] + m[28144] + xabh[m[170]]));var o4td3f = {};for (const ewh1y in G$3J[m[24233]]) {
        o4td3f[ewh1y] = G$3J[m[24233]][ewh1y];
      }var hix1a = { 'channel': window['G$3J'][m[24237]], 'account': window['G$3J'][m[24238]], 'userId': window['G$3J'][m[22678]], 'cdn': window['G$3J'][m[4157]], 'data': window['G$3J'][m[11]], 'package': window['G$3J'][m[23960]], 'newRegister': window['G$3J'][m[613]], 'pkgName': window['G$3J'][m[24239]], 'partnerId': window['G$3J'][m[22679]], 'platform_uid': window['G$3J'][m[24240]], 'deviceId': window['G$3J'][m[24241]], 'selectedServer': o4td3f, 'configType': window['G$3J'][m[11076]], 'exposeType': window['G$3J'][m[695]], 'debugUsers': window['G$3J'][m[11464]], 'wxMenuTop': a51hix, 'wxShield': window['G$3J'][m[709]] };if (window[m[28047]]) for (var fo4 in window[m[28047]]) {
        hix1a[fo4] = window[m[28047]][fo4];
      }window[m[27456]][m[141]]['G$J3V'](hix1a), setTimeout(() => {
        new XingJuBoxMain();
      }, 0x1388);
    }
  } else console[m[72]](m[28145] + window['G$J0'] + m[28146] + window['G$30J'] + m[28147] + window[m[27954]] + m[28148] + window[m[27955]] + m[28149] + window['G$3J0'] + m[28150] + window['G$30'] + m[28151] + window['G$0J'] + m[28152] + window['G$03']);
};