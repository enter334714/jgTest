var m = wx.$g;
require('ggggBuff.js'), window[m[27457]][m[27458]][m[27459]] = null, window['client_pb'] = require('gggcleintpb.js'), window[m[24375]] = window[m[27457]][m[24267]][m[24268]](client_pb);