var m = wx.$g;
import 'gggmain.js';