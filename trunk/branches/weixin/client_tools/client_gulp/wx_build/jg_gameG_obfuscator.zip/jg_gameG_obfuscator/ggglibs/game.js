var m = wx.$g;
require(m[27825]);