var m = wx.$g;
console[m[72]](m[27826]), window[m[27827]], wx[m[27828]](function (t3o_f) {
  if (t3o_f) {
    if (t3o_f[m[4159]]) {
      var gcsl8q = window[m[540]][m[27829]][m[4336]](new RegExp(/\./, 'g'), '_'),
          t30_ = t3o_f[m[4159]],
          yvgqe = t30_[m[11271]](/(gggggggg\/gggggame.js:)[0-9]{1,60}(:)/g);if (yvgqe) for (var ptbf_ = 0x0; ptbf_ < yvgqe[m[13]]; ptbf_++) {
        if (yvgqe[ptbf_] && yvgqe[ptbf_][m[13]] > 0x0) {
          var hakix = parseInt(yvgqe[ptbf_][m[4336]](m[27830], '')[m[4336]](':', ''));t30_ = t30_[m[4336]](yvgqe[ptbf_], yvgqe[ptbf_][m[4336]](':' + hakix + ':', ':' + (hakix - 0x2) + ':'));
        }
      }t30_ = t30_[m[4336]](new RegExp(m[27831], 'g'), m[27832] + gcsl8q + m[24334]), t30_ = t30_[m[4336]](new RegExp(m[27833], 'g'), m[27832] + gcsl8q + m[24334]), t3o_f[m[4159]] = t30_;
    }var zjd2 = { 'id': window['G$3J'][m[27834]], 'role': window['G$3J'][m[4280]], 'level': window['G$3J'][m[27835]], 'user': window['G$3J'][m[24238]], 'version': window['G$3J'][m[95]], 'cdn': window['G$3J'][m[4157]], 'pkgName': window['G$3J'][m[24239]], 'gamever': window[m[540]][m[27829]], 'serverid': window['G$3J'][m[24233]] ? window['G$3J'][m[24233]][m[10787]] : 0x0, 'systemInfo': window[m[27836]], 'error': m[27837], 'stack': t3o_f ? t3o_f[m[4159]] : '' },
        xi5abh = JSON[m[4143]](zjd2);console[m[119]](m[27838] + xi5abh), (!window[m[27827]] || window[m[27827]] != zjd2[m[119]]) && (window[m[27827]] = zjd2[m[119]], window['G$23'](zjd2));
  }
});import 'gggmd5min.js';import 'gggzlibs.js';window[m[27839]] = require(m[27840]);import 'gggindex.js';import 'ggglibsmin.js';import 'gggwxmini.js';import 'ggginitmin.js';import 'XingJuBox.js';console[m[72]](m[27841]), console[m[72]](m[27842]), G$230J({ 'title': m[27843] });var gahib = { 'G$V2J30': !![] };new window[m[27844]](gahib), window[m[27844]][m[141]]['G$V03J2']();if (window['G$V23J0']) clearInterval(window['G$V23J0']);window['G$V23J0'] = null, window['G$V0J23'] = function (p_f04t, j2r6zd) {
  if (!p_f04t || !j2r6zd) return 0x0;p_f04t = p_f04t[m[15]]('.'), j2r6zd = j2r6zd[m[15]]('.');const o34tf_ = Math[m[813]](p_f04t[m[13]], j2r6zd[m[13]]);while (p_f04t[m[13]] < o34tf_) {
    p_f04t[m[29]]('0');
  }while (j2r6zd[m[13]] < o34tf_) {
    j2r6zd[m[29]]('0');
  }for (var kw1ye = 0x0; kw1ye < o34tf_; kw1ye++) {
    const o3d26 = parseInt(p_f04t[kw1ye]),
          z2$ = parseInt(j2r6zd[kw1ye]);if (o3d26 > z2$) return 0x1;else {
      if (o3d26 < z2$) return -0x1;
    }
  }return 0x0;
}, window[m[27845]] = wx[m[27846]]()[m[27845]], console[m[467]](m[27847] + window[m[27845]]);var gkvw7 = wx[m[27848]]();gkvw7[m[27849]](function (c9sg8) {
  console[m[467]](m[27850] + c9sg8[m[27851]]);
}), gkvw7[m[27852]](function () {
  wx[m[27853]]({ 'title': m[27854], 'content': m[27855], 'showCancel': ![], 'success': function (tpf4_) {
      gkvw7[m[27856]]();
    } });
}), gkvw7[m[27857]](function () {
  console[m[467]](m[27858]);
}), window['G$V0J32'] = function () {
  console[m[467]](m[27859]);var ahk1xw = wx[m[27860]]({ 'name': m[27861], 'success': function (f4_3o) {
      console[m[467]](m[27862]), console[m[467]](f4_3o), f4_3o && f4_3o[m[24417]] == m[27863] ? (window['G$J0'] = !![], window['G$J032'](), window['G$J320']()) : setTimeout(function () {
        window['G$V0J32']();
      }, 0x1f4);
    }, 'fail': function (ahx5bi) {
      console[m[467]](m[27864]), console[m[467]](ahx5bi), setTimeout(function () {
        window['G$V0J32']();
      }, 0x1f4);
    } });ahk1xw && ahk1xw[m[27865]](vqwe7 => {});
}, window['G$V32J0'] = function () {
  console[m[467]](m[27866]);var hia51 = wx[m[27860]]({ 'name': m[27867], 'success': function (tz34do) {
      console[m[467]](m[27868]), console[m[467]](tz34do), tz34do && tz34do[m[24417]] == m[27863] ? (window['G$30J'] = !![], window['G$J032'](), window['G$J320']()) : setTimeout(function () {
        window['G$V32J0']();
      }, 0x1f4);
    }, 'fail': function (df43to) {
      console[m[467]](m[27869]), console[m[467]](df43to), setTimeout(function () {
        window['G$V32J0']();
      }, 0x1f4);
    } });hia51 && hia51[m[27865]](hx1kia => {});
}, window[m[27870]] = function () {
  window['G$V0J23'](window[m[27845]], m[27871]) >= 0x0 ? (console[m[467]](m[27872] + window[m[27845]] + m[27873]), window['G$32'](), window['G$V0J32'](), window['G$V32J0']()) : (window['G$3J2'](m[27874], window[m[27845]]), wx[m[27853]]({ 'title': m[5960], 'content': m[27875] }));
}, window[m[27836]] = '', wx[m[27876]]({ 'success'(b0_tfp) {
    window[m[27836]] = m[27877] + b0_tfp[m[27878]] + m[27879] + b0_tfp[m[27880]] + m[27881] + b0_tfp[m[4349]] + m[27882] + b0_tfp[m[460]] + m[27883] + b0_tfp[m[24210]] + m[27884] + b0_tfp[m[27845]] + m[27885] + b0_tfp[m[8770]], console[m[467]](window[m[27836]]), console[m[467]](m[27886] + b0_tfp[m[27887]] + m[27888] + b0_tfp[m[27889]] + m[27890] + b0_tfp[m[27891]] + m[27892] + b0_tfp[m[27893]] + m[27894] + b0_tfp[m[27895]] + m[27896] + b0_tfp[m[27897]] + m[27898] + (b0_tfp[m[27899]] ? b0_tfp[m[27899]][m[314]] + ',' + b0_tfp[m[27899]][m[1125]] + ',' + b0_tfp[m[27899]][m[1127]] + ',' + b0_tfp[m[27899]][m[1126]] : ''));var pb05_ = b0_tfp[m[460]] ? b0_tfp[m[460]][m[11556]]() : '',
        wev7k = b0_tfp[m[27880]] ? b0_tfp[m[27880]][m[11556]]()[m[4336]]('\x20', '') : '';window['G$3J'][m[989]] = pb05_[m[109]](m[27900]) != -0x1, window['G$3J'][m[10616]] = pb05_[m[109]](m[27901]) != -0x1, window['G$3J'][m[27902]] = pb05_[m[109]](m[27900]) != -0x1 || pb05_[m[109]](m[27901]) != -0x1, window['G$3J'][m[23962]] = pb05_[m[109]](m[27903]) != -0x1 || pb05_[m[109]](m[27904]) != -0x1, window['G$3J'][m[27905]] = b0_tfp[m[24210]] ? b0_tfp[m[24210]][m[11556]]() : '', window['G$3J']['G$V20J3'] = ![], window['G$3J']['G$V230J'] = 0x2;if (pb05_[m[109]](m[27901]) != -0x1) {
      if (b0_tfp[m[8770]] >= 0x18) window['G$3J']['G$V230J'] = 0x3;else window['G$3J']['G$V230J'] = 0x2;
    } else {
      if (pb05_[m[109]](m[27900]) != -0x1) {
        if (b0_tfp[m[8770]] && b0_tfp[m[8770]] >= 0x14) window['G$3J']['G$V230J'] = 0x3;else {
          if (wev7k[m[109]](m[27906]) != -0x1 || wev7k[m[109]](m[27907]) != -0x1 || wev7k[m[109]](m[27908]) != -0x1 || wev7k[m[109]](m[27909]) != -0x1 || wev7k[m[109]](m[27910]) != -0x1) window['G$3J']['G$V230J'] = 0x2;else window['G$3J']['G$V230J'] = 0x3;
        }
      } else window['G$3J']['G$V230J'] = 0x2;
    }console[m[467]](m[27911] + window['G$3J']['G$V20J3'] + m[27912] + window['G$3J']['G$V230J']);
  } }), wx[m[27913]]({ 'success': function (_pib) {
    console[m[467]](m[27914] + _pib[m[4256]] + m[27915] + _pib[m[27916]]);
  } }), wx[m[27917]]({ 'success': function (hki1ax) {
    console[m[467]](m[27918] + hki1ax[m[27919]]);
  } }), wx[m[27920]]({ 'keepScreenOn': !![] }), wx[m[27921]](function (zj2$6r) {
  console[m[467]](m[27918] + zj2$6r[m[27919]] + m[27922] + zj2$6r[m[27923]]);
}), wx[m[10172]](function (qgy7e) {
  window['G$02'] = qgy7e, window['G$J20'] && window['G$02'] && (console[m[72]](m[27924] + window['G$02'][m[742]]), window['G$J20'](window['G$02']), window['G$02'] = null);
}), window['memoryGCTime'] = 0x0, window['G$V30J2'] = 0x0, window[m[27925]] = null, wx[m[27926]](function () {
  window['G$V30J2']++;var i50p_ = Date[m[77]]();(window['memoryGCTime'] == 0x0 || i50p_ - window['memoryGCTime'] > 0x1d4c0) && (console[m[90]](m[27927]), wx['triggerGC']());if (window['G$V30J2'] >= 0x2) {
    window['G$V30J2'] = 0x0, console[m[119]](m[27928]), wx[m[27929]]('0', 0x1);if (window['G$3J'] && window['G$3J'][m[989]]) window['G$3J2'](m[27930], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});