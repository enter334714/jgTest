var e = wx.$F;
require(e[600000]);