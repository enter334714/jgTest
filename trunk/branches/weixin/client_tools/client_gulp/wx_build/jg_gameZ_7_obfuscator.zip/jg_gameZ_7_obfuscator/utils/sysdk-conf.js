var e = wx.$F;
module.exports.APP_ID = 'wx51c0cdb47d2df807'; // 小游戏appid
module.exports.APP_VERSION = '1001.0.0'; // 小游戏版本
module.exports.GAME_KEY = '52f9cc378522fb80c77cbb3d43a58a2d'; // 小游戏key
module.exports.offerId = '1450032542'; // 米大师offerId，支付应用ID
module.exports.commitId = '163';