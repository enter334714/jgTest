var e = wx.$F;
import lc9zwu from '../zh44zh44basdzh44/zh445sdkzh44.js';window[e[600139]] = { 'wxVersion': window[e[600006]][e[600007]] }, window[e[600140]] = ![], window['kE$'] = 0x1, window[e[600141]] = 0x1, window['kT$E'] = !![], window[e[600142]] = !![], window['kBIT$E'] = '', window['k$E'] = { 'base_cdn': 'https://cdn-tjqy.shzbkj.com/weixin_0/', 'cdn': 'https://cdn-tjqy.shzbkj.com/weixin_0/' }, k$E[e[600143]] = {}, k$E['package'] = '0', k$E[e[600075]] = window[e[600139]][e[600144]], k$E[e[600109]] = '', k$E['os'] = '1', k$E['sdk_name'] = e[600145], k$E[e[600146]] = 'https://api-tjqytest.shzbkj.com', k$E[e[600147]] = 'https://log-tjqytest.shzbkj.com', k$E[e[600148]] = 'https://pay-tjqytest.shzbkj.com', k$E['apikey'] = e[600149], k$E[e[600150]] = '1', k$E['pkgName'] = '', k$E[e[600151]] = '', k$E[e[600152]] = 0x0, k$E[e[600153]] = {}, k$E[e[600154]] = parseInt(k$E[e[600150]]), k$E[e[600155]] = k$E[e[600150]], k$E[e[600022]] = {}, k$E['kI$'] = e[600156], k$E[e[600157]] = ![], k$E[e[600158]] = e[600159], k$E['tick'] = Date[e[600132]](), k$E[e[600160]] = e[600161], k$E[e[600162]] = '_a', k$E[e[600163]] = 0x2, k$E[e[600020]] = 0x7c1, k$E[e[600144]] = window[e[600139]][e[600144]], k$E[e[600164]] = ![], k$E[e[600101]] = ![], k$E[e[600104]] = ![], k$E[e[600107]] = ![], window['kTE$'] = 0x5, window['kTE'] = ![], window['kET'] = ![], window['k$TE'] = ![], window[e[600165]] = ![], window[e[600166]] = ![], window['k$ET'] = ![], window['kT$'] = ![], window['k$T'] = ![], window['kET$'] = ![], window[e[600167]] = function (miyx8r) {
  console[e[600041]](e[600167], miyx8r), wx[e[600168]]({}), wx[e[600047]]({ 'title': e[600067], 'content': miyx8r, 'success'(r7oq0) {
      if (r7oq0[e[600169]]) console[e[600041]](e[600170]);else r7oq0[e[600171]] && console[e[600041]](e[600172]);
    } });
}, window['kIT$E'] = function (npd4zc) {
  console[e[600041]](e[600173], npd4zc), kI$ET(), wx[e[600047]]({ 'title': e[600067], 'content': npd4zc, 'confirmText': e[600174], 'cancelText': e[600175], 'success'(tmgyi) {
      if (tmgyi[e[600169]]) window['k$I']();else tmgyi[e[600171]] && (console[e[600041]](e[600176]), wx[e[600177]]({}));
    } });
}, window[e[600178]] = function (qo705a) {
  console[e[600041]](e[600178], qo705a), wx[e[600047]]({ 'title': e[600067], 'content': qo705a, 'confirmText': e[600179], 'showCancel': ![], 'complete'(duz9c4) {
      console[e[600041]](e[600176]), wx[e[600177]]({});
    } });
}, window['kITE$'] = ![], window['kI$TE'] = function (bva2$6) {
  window['kITE$'] = !![], wx[e[600180]](bva2$6);
}, window['kI$ET'] = function () {
  window['kITE$'] && (window['kITE$'] = ![], wx[e[600168]]({}));
}, window['kIET$'] = function (kv6b$) {
  window[e[600034]][e[600035]]['kIET$'](kv6b$);
}, window['msgCheck'] = function (zn4cp, _2v$) {
  lc9zwu['msgCheck'](zn4cp, function ($vb_k) {
    $vb_k && $vb_k[e[600181]] ? $vb_k[e[600181]][e[600182]] == 0x1 ? _2v$(!![]) : (_2v$(![]), console[e[600001]](e[600183] + $vb_k[e[600181]][e[600184]])) : console[e[600041]]('msgCheck', $vb_k);
  });
}, window['kIE$T'] = function (myi8r3) {
  console[e[600041]](e[600185], myi8r3);
}, window['kI$E'] = function (jnesdp) {}, window['kIE$'] = function (rxiom, p_sje, u9zf1) {}, window['kIE'] = function (f9uw1l) {
  console[e[600041]](e[600186], f9uw1l), window[e[600034]][e[600035]][e[600187]](), window[e[600034]][e[600035]][e[600188]](), window[e[600034]][e[600035]][e[600189]]();
}, window['kEI'] = function (q7o50) {
  window['kIT$E'](e[600190]);var oxr780 = { 'id': window['k$E'][e[600016]], 'role': window['k$E'][e[600017]], 'level': window['k$E'][e[600018]], 'account': window['k$E'][e[600019]], 'version': window['k$E'][e[600020]], 'cdn': window['k$E'][e[600021]], 'pkgName': window['k$E']['pkgName'], 'gamever': window[e[600006]][e[600007]], 'serverid': window['k$E'][e[600022]] ? window['k$E'][e[600022]][e[600023]] : 0x0, 'systemInfo': window[e[600024]], 'error': e[600191], 'stack': q7o50 ? q7o50 : e[600190] },
      s$e_k = JSON[e[600026]](oxr780);console[e[600027]](e[600192] + s$e_k), window['kI$'](s$e_k);
}, window['k$IE'] = function (xo70q) {
  var ep4 = JSON[e[600193]](xo70q);ep4[e[600194]] = window[e[600006]][e[600007]], ep4[e[600195]] = window['k$E'][e[600022]] ? window['k$E'][e[600022]][e[600023]] : 0x0, ep4[e[600024]] = window[e[600024]];var mgti3 = JSON[e[600026]](ep4);console[e[600027]](e[600196] + mgti3), window['kI$'](mgti3);
}, window['k$EI'] = function (rox0, b5v6qa) {
  var $2ks_e = { 'id': window['k$E'][e[600016]], 'role': window['k$E'][e[600017]], 'level': window['k$E'][e[600018]], 'account': window['k$E'][e[600019]], 'version': window['k$E'][e[600020]], 'cdn': window['k$E'][e[600021]], 'pkgName': window['k$E']['pkgName'], 'gamever': window[e[600006]][e[600007]], 'serverid': window['k$E'][e[600022]] ? window['k$E'][e[600022]][e[600023]] : 0x0, 'systemInfo': window[e[600024]], 'error': rox0, 'stack': b5v6qa },
      c4pdnz = JSON[e[600026]]($2ks_e);console[e[600133]](e[600197] + c4pdnz), window['kI$'](c4pdnz);
}, window['kI$'] = function (r3y8) {
  if (window['k$E'][e[600110]] == e[600198]) return;var s_pnje = k$E['kI$'] + e[600199] + k$E[e[600019]];wx[e[600200]]({ 'url': s_pnje, 'method': e[600201], 'data': r3y8, 'header': { 'content-type': e[600202], 'cache-control': e[600203] }, 'success': function (y83gi) {
      DEBUG && console[e[600041]](e[600204], s_pnje, r3y8, y83gi);
    }, 'fail': function (u9wf1z) {
      DEBUG && console[e[600041]](e[600204], s_pnje, r3y8, u9wf1z);
    }, 'complete': function () {} });
}, window[e[600205]] = function () {
  function yig3m8() {
    return ((0x1 + Math[e[600206]]()) * 0x10000 | 0x0)[e[600207]](0x10)[e[600208]](0x1);
  }return yig3m8() + yig3m8() + '-' + yig3m8() + '-' + yig3m8() + '-' + yig3m8() + '+' + yig3m8() + yig3m8() + yig3m8();
}, window['k$I'] = function () {
  console[e[600041]](e[600209]);var v2ab$6 = lc9zwu[e[600210]]();k$E[e[600155]] = v2ab$6[e[600211]], k$E[e[600154]] = v2ab$6[e[600211]], k$E[e[600150]] = v2ab$6[e[600211]], k$E['pkgName'] = v2ab$6['game_pkg'];var e4nj = { 'game_ver': k$E[e[600075]] };k$E[e[600151]] = this[e[600205]](), kI$TE({ 'title': e[600212] }), lc9zwu[e[600213]](e4nj, this['kEI$'][e[600214]](this));
}, window['kEI$'] = function (vb56aq) {
  var z91wuf = vb56aq[e[600215]];console[e[600041]](e[600216] + z91wuf + e[600217] + (z91wuf == 0x1) + e[600218] + vb56aq[e[600007]] + e[600219] + window[e[600139]][e[600144]]);if (!vb56aq[e[600007]] || window['kBTEI$'](window[e[600139]][e[600144]], vb56aq[e[600007]]) < 0x0) console[e[600041]](e[600220]), k$E[e[600146]] = 'https://api-tjqy.shzbkj.com', k$E[e[600147]] = 'https://log-tjqy.shzbkj.com', k$E[e[600148]] = 'https://pay-tjqy.shzbkj.com', k$E[e[600021]] = 'https://cdn-tjqy-fx.shzbkj.com/weixin_1/', k$E[e[600221]] = 'https://cdn-tjqy-ali.shzbkj.com/weixin_1/', k$E[e[600222]] = e[600223], k$E[e[600164]] = ![];else window['kBTEI$'](window[e[600139]][e[600144]], vb56aq[e[600007]]) == 0x0 ? (console[e[600041]](e[600224]), k$E[e[600146]] = 'https://api-tjqytest.shzbkj.com', k$E[e[600147]] = 'https://log-tjqytest.shzbkj.com', k$E[e[600148]] = 'https://pay-tjqytest.shzbkj.com', k$E[e[600021]] = 'https://cdn-tjqy-fx.shzbkj.com/weixin_0/', k$E[e[600221]] = 'https://cdn-tjqy-ali.shzbkj.com/weixin_1/', k$E[e[600222]] = e[600225], k$E[e[600164]] = !![]) : (console[e[600041]](e[600226]), k$E[e[600146]] = 'https://api-tjqytest.shzbkj.com', k$E[e[600147]] = 'https://log-tjqytest.shzbkj.com', k$E[e[600148]] = 'https://pay-tjqytest.shzbkj.com', k$E[e[600021]] = 'https://cdn-tjqy-fx.shzbkj.com/weixin_0/', k$E[e[600221]] = 'https://cdn-tjqy-ali.shzbkj.com/weixin_1/', k$E[e[600222]] = e[600225], k$E[e[600164]] = ![]);k$E[e[600152]] = config[e[600227]] ? config[e[600227]] : 0x0, this['kT$IE'](), this['kT$EI'](), window['sdkLoginRetry'] = 0x5, kI$TE({ 'title': e[600228] }), lc9zwu[e[600229]](this['kE$I'][e[600214]](this));
}, window['sdkLoginRetry'] = 0x5, window['kE$I'] = function (mg8, $_es2) {
  if (mg8 == 0x0 && $_es2 && $_es2['token']) {
    k$E['sdk_token'] = $_es2['token'];var d4epjn = this;kI$TE({ 'title': e[600230] }), sendApi(k$E[e[600146]], e[600231], { 'platform': k$E['sdk_name'], 'partner_id': k$E[e[600150]], 'token': $_es2['token'], 'game_pkg': k$E['pkgName'], 'deviceId': k$E[e[600151]], 'scene': e[600232] + k$E[e[600152]] }, this['kTI$E'][e[600214]](this), kTE$, kEI);
  } else $_es2 && $_es2[e[600056]] && window['sdkLoginRetry'] > 0x0 && ($_es2[e[600056]][e[600102]](e[600233]) != -0x1 || $_es2[e[600056]][e[600102]]('network api interrupted') != -0x1 || $_es2[e[600056]][e[600102]]('Network Error') != -0x1 || $_es2[e[600056]][e[600102]](e[600234]) != -0x1 || $_es2[e[600056]][e[600102]](e[600235]) != -0x1 || $_es2[e[600056]][e[600102]](e[600236]) != -0x1) ? (window['sdkLoginRetry']--, lc9zwu[e[600229]](this['kE$I'][e[600214]](this))) : (window['k$EI']('sdkOnLoginError', JSON[e[600026]]({ 'status': mg8, 'data': $_es2 })), window['kIT$E'](e[600237] + ($_es2 && $_es2[e[600056]] ? '，' + $_es2[e[600056]] : '')));
}, window['kTI$E'] = function (k$_e2s) {
  if (!k$_e2s) {
    window['k$EI'](e[600238], e[600239]), window['kIT$E'](e[600240]);return;
  }if (k$_e2s[e[600182]] != e[600241]) {
    window['k$EI'](e[600238], JSON[e[600026]](k$_e2s)), window['kIT$E'](e[600242] + k$_e2s[e[600182]]);return;
  }k$E[e[600243]] = String(k$_e2s[e[600019]]), k$E[e[600019]] = String(k$_e2s[e[600019]]), k$E[e[600079]] = String(k$_e2s[e[600079]]), k$E[e[600155]] = String(k$_e2s[e[600079]]), k$E[e[600244]] = String(k$_e2s[e[600244]]), k$E[e[600245]] = String(k$_e2s[e[600246]]), k$E[e[600247]] = String(k$_e2s[e[600248]]), k$E[e[600246]] = '';var skjen_ = this;kI$TE({ 'title': e[600249] }), sendApi(k$E[e[600146]], e[600250], { 'partner_id': k$E[e[600150]], 'uid': k$E[e[600019]], 'version': k$E[e[600075]], 'game_pkg': k$E['pkgName'], 'device': k$E[e[600151]] }, skjen_['kTIE$'][e[600214]](skjen_), kTE$, kEI);
}, window['kTIE$'] = function (_pj) {
  if (!_pj) {
    window['kIT$E'](e[600251]);return;
  }if (_pj[e[600182]] != e[600241]) {
    window['kIT$E'](e[600252] + _pj[e[600182]]);return;
  }if (!_pj[e[600181]] || _pj[e[600181]][e[600010]] == 0x0) {
    window['kIT$E'](e[600253]);return;
  }k$E[e[600254]] = _pj[e[600255]], k$E[e[600022]] = { 'server_id': String(_pj[e[600181]][0x0][e[600023]]), 'server_name': String(_pj[e[600181]][0x0][e[600256]]), 'entry_ip': _pj[e[600181]][0x0][e[600257]], 'entry_port': parseInt(_pj[e[600181]][0x0][e[600258]]), 'status': k$TI(_pj[e[600181]][0x0]), 'start_time': _pj[e[600181]][0x0][e[600259]], 'cdn': k$E[e[600021]] }, this['kE$TI']();
}, window['kE$TI'] = function () {
  if (k$E[e[600254]] == 0x1) {
    var bq5av6 = k$E[e[600022]][e[600260]];if (bq5av6 === -0x1 || bq5av6 === 0x0) {
      window['kIT$E'](bq5av6 === -0x1 ? e[600261] : e[600262]);return;
    }kEIT$(0x0, k$E[e[600022]][e[600023]]), window[e[600034]][e[600035]][e[600263]](k$E[e[600254]]);
  } else window[e[600034]][e[600035]][e[600264]](), kI$ET();window['k$T'] = !![], window['kET$I'](), window['kE$IT']();
}, window['kT$IE'] = function () {
  sendApi(k$E[e[600146]], e[600265], { 'game_pkg': k$E['pkgName'], 'version_name': k$E[e[600222]] }, this['reqVersionConfigCallBack'][e[600214]](this), kTE$, kEI);
}, window['reqVersionConfigCallBack'] = function (c49zw) {
  if (!c49zw) {
    window['kIT$E'](e[600266]);return;
  }if (c49zw[e[600182]] != e[600241]) {
    window['kIT$E'](e[600267] + c49zw[e[600182]]);return;
  }if (!c49zw[e[600181]] || !c49zw[e[600181]][e[600075]]) {
    window['kIT$E'](e[600268] + (c49zw[e[600181]] && c49zw[e[600181]][e[600075]]));return;
  }c49zw[e[600181]][e[600269]] && c49zw[e[600181]][e[600269]][e[600010]] > 0xa && (k$E[e[600270]] = c49zw[e[600181]][e[600269]], k$E[e[600021]] = c49zw[e[600181]][e[600269]]), c49zw[e[600181]][e[600075]] && (k$E[e[600020]] = c49zw[e[600181]][e[600075]]), console[e[600001]](e[600271] + k$E[e[600020]] + e[600272] + k$E[e[600222]]), window['k$ET'] = !![], window['kET$I'](), window['kE$IT']();
}, window['pkgOptions'], window['kT$EI'] = function () {
  sendApi(k$E[e[600146]], 'Common.get_option_pkg', { 'game_pkg': k$E['pkgName'] }, this['kTEI$'][e[600214]](this), kTE$, kEI);
}, window['kTEI$'] = function (a6b5q0) {
  if (a6b5q0[e[600182]] === e[600241] && a6b5q0[e[600181]]) {
    window['pkgOptions'] = a6b5q0[e[600181]];for (var lwf9u1 in a6b5q0[e[600181]]) {
      k$E[lwf9u1] = a6b5q0[e[600181]][lwf9u1];
    }
  } else console[e[600001]]('reqPkgOptionsCallBack ' + a6b5q0[e[600182]]);window['kT$'] = !![], window['kE$IT']();
}, window[e[600273]] = function (jnp4de, jesdp, rm3y, bv6a$2, bv, pjcdn, _sjekn, t3ig, cufz9) {
  bv = String(bv);var dp4cz9 = _sjekn,
      $e_2s = t3ig;k$E[e[600143]][bv] = { 'productid': bv, 'productname': dp4cz9, 'productdesc': $e_2s, 'roleid': jnp4de, 'rolename': jesdp, 'rolelevel': rm3y, 'price': pjcdn, 'callback': cufz9 }, sendApi(k$E[e[600148]], e[600274], { 'game_pkg': k$E['pkgName'], 'server_id': k$E[e[600022]][e[600023]], 'server_name': k$E[e[600022]][e[600256]], 'level': rm3y, 'uid': k$E[e[600019]], 'role_id': jnp4de, 'role_name': jesdp, 'product_id': bv, 'product_name': dp4cz9, 'product_desc': $e_2s, 'money': pjcdn, 'partner_id': k$E[e[600150]] }, toPayCallBack, kTE$, kEI);
}, window['toPayCallBack'] = function (gm3iy) {
  if (gm3iy) {
    if (gm3iy[e[600275]] === 0xc8 || gm3iy[e[600182]] == e[600241]) {
      var v$2b_k = k$E[e[600143]][String(gm3iy[e[600276]])];if (v$2b_k['callback']) v$2b_k['callback'](gm3iy[e[600276]], gm3iy[e[600277]], -0x1);lc9zwu[e[600278]]({ 'cpbill': gm3iy[e[600277]], 'productid': gm3iy[e[600276]], 'productname': v$2b_k[e[600279]], 'productdesc': v$2b_k[e[600280]], 'serverid': k$E[e[600022]][e[600023]], 'servername': k$E[e[600022]][e[600256]], 'roleid': v$2b_k[e[600281]], 'rolename': v$2b_k[e[600282]], 'rolelevel': v$2b_k[e[600283]], 'price': v$2b_k[e[600284]], 'extension': JSON[e[600026]]({ 'cp_order_id': gm3iy[e[600277]] }) }, function (yig8m, or0qx7) {
        v$2b_k['callback'] && yig8m == 0x0 && v$2b_k['callback'](gm3iy[e[600276]], gm3iy[e[600277]], yig8m);console[e[600001]](JSON[e[600026]]({ 'type': 'paycallback', 'status': yig8m, 'data': gm3iy, 'role_name': v$2b_k[e[600282]] }));if (yig8m === 0x0) {} else {
          if (yig8m === 0x1) {} else {
            if (yig8m === 0x2) {}
          }
        }
      });
    } else alert(gm3iy[e[600001]]);
  }
}, window['kTE$I'] = function () {}, window['kITE'] = function (q65a70, s_kenj, ks$e2_, s2$e, rim8y3) {
  lc9zwu[e[600285]](k$E[e[600022]][e[600023]], k$E[e[600022]][e[600256]] || k$E[e[600022]][e[600023]], q65a70, s_kenj, ks$e2_), sendApi(k$E[e[600146]], e[600286], { 'game_pkg': k$E['pkgName'], 'server_id': k$E[e[600022]][e[600023]], 'role_id': q65a70, 'uid': k$E[e[600019]], 'role_name': s_kenj, 'role_type': s2$e, 'level': ks$e2_ });
}, window['kIET'] = function ($s_ek2, v2$ab6, bvq5a6, pdne, jdpsen, q0x5o7, snep, z4du9, imty3g, kesnj_) {
  k$E[e[600016]] = $s_ek2, k$E[e[600017]] = v2$ab6, k$E[e[600018]] = bvq5a6, lc9zwu[e[600287]](k$E[e[600022]][e[600023]], k$E[e[600022]][e[600256]] || k$E[e[600022]][e[600023]], $s_ek2, v2$ab6, bvq5a6), sendApi(k$E[e[600146]], e[600288], { 'game_pkg': k$E['pkgName'], 'server_id': k$E[e[600022]][e[600023]], 'role_id': $s_ek2, 'uid': k$E[e[600019]], 'role_name': v2$ab6, 'role_type': pdne, 'level': bvq5a6, 'evolution': jdpsen });
}, window['kTIE'] = function (_nkesj, kv_$s, ao7q0, e_np, ymg8i3, g8iy3m, svk_$2, njp_s, enj_ps, qo50) {
  k$E[e[600016]] = _nkesj, k$E[e[600017]] = kv_$s, k$E[e[600018]] = ao7q0, lc9zwu[e[600289]](k$E[e[600022]][e[600023]], k$E[e[600022]][e[600256]] || k$E[e[600022]][e[600023]], _nkesj, kv_$s, ao7q0), sendApi(k$E[e[600146]], e[600288], { 'game_pkg': k$E['pkgName'], 'server_id': k$E[e[600022]][e[600023]], 'role_id': _nkesj, 'uid': k$E[e[600019]], 'role_name': kv_$s, 'role_type': e_np, 'level': ao7q0, 'evolution': ymg8i3 });
}, window['kTEI'] = function (cu9z) {}, window['kIT'] = function (a06qb5) {
  lc9zwu[e[600290]](e[600290], function (fwu) {
    a06qb5 && a06qb5(fwu);
  });
}, window[e[600291]] = function () {
  lc9zwu[e[600291]]();
}, window[e[600292]] = function () {
  lc9zwu[e[600293]]();
}, window[e[600294]] = function ($sje_, o07qrx, c9zuw, oirx7, jd4n, q0o57x, _eks$, rix8mo) {
  rix8mo = rix8mo || k$E[e[600022]][e[600023]], sendApi(k$E[e[600146]], e[600295], { 'phone': $sje_, 'role_id': o07qrx, 'uid': k$E[e[600019]], 'game_pkg': k$E['pkgName'], 'partner_id': k$E[e[600150]], 'server_id': rix8mo }, _eks$);
}, window[e[600127]] = function (nd4jcp) {
  window['kEIT'] = nd4jcp, window['kEIT'] && window['kTI'] && (console[e[600001]](e[600128] + window['kTI'][e[600129]]), window['kEIT'](window['kTI']), window['kTI'] = null);
}, window['kETI'] = function (npcz4, pnj4c, cp9d, zc4nd) {
  window[e[600296]]('https://sdk.sh9130.com/game/?ct=min&ac=getInviter', { 'game_pkg': window['k$E']['pkgName'], 'role_id': pnj4c, 'server_id': cp9d }, zc4nd);
}, window['k$ITE'] = function (sjnpde, vaqb56) {
  function miyg(_jpnse) {
    var qxr0o = [],
        xqo05 = [],
        udc49 = window[e[600006]][e[600297]];for (var wuc49z in udc49) {
      var i7x8r = Number(wuc49z);(!sjnpde || !sjnpde[e[600010]] || sjnpde[e[600102]](i7x8r) != -0x1) && (xqo05[e[600038]](udc49[wuc49z]), qxr0o[e[600038]]([i7x8r, 0x3]));
    }window['kBTEI$'](window[e[600039]], e[600298]) >= 0x0 ? (console[e[600041]](e[600299]), lc9zwu[e[600300]] && lc9zwu[e[600300]](xqo05, function (wzu94c) {
      console[e[600041]](e[600301]), console[e[600041]](wzu94c);if (wzu94c && wzu94c[e[600056]] == 'requestSubscribeMessage:ok') for (var ixorm8 in udc49) {
        if (wzu94c[udc49[ixorm8]] == e[600302]) {
          var sk$2_e = Number(ixorm8);for (var m3ri = 0x0; m3ri < qxr0o[e[600010]]; m3ri++) {
            if (qxr0o[m3ri][0x0] == sk$2_e) {
              qxr0o[m3ri][0x1] = 0x1;break;
            }
          }
        }
      }window['kBTEI$'](window[e[600039]], e[600303]) >= 0x0 ? wx[e[600304]]({ 'withSubscriptions': !![], 'success': function (a67q0) {
          var uzw19 = a67q0[e[600305]][e[600306]];if (uzw19) {
            console[e[600041]](e[600307]), console[e[600041]](uzw19);for (var o0xq57 in udc49) {
              if (uzw19[udc49[o0xq57]] == e[600302]) {
                var t3iy = Number(o0xq57);for (var v_b$ = 0x0; v_b$ < qxr0o[e[600010]]; v_b$++) {
                  if (qxr0o[v_b$][0x0] == t3iy) {
                    qxr0o[v_b$][0x1] = 0x2;break;
                  }
                }
              }
            }console[e[600041]](qxr0o), vaqb56 && vaqb56(qxr0o);
          } else console[e[600041]](e[600308]), console[e[600041]](a67q0), console[e[600041]](qxr0o), vaqb56 && vaqb56(qxr0o);
        }, 'fail': function () {
          console[e[600041]](e[600309]), console[e[600041]](qxr0o), vaqb56 && vaqb56(qxr0o);
        } }) : (console[e[600041]](e[600310] + window[e[600039]]), console[e[600041]](qxr0o), vaqb56 && vaqb56(qxr0o));
    })) : (console[e[600041]](e[600311] + window[e[600039]]), console[e[600041]](qxr0o), vaqb56 && vaqb56(qxr0o)), wx[e[600312]](miyg);
  }wx[e[600313]](miyg);
}, window['k$IET'] = { 'isSuccess': ![], 'level': e[600314], 'isCharging': ![] }, window['k$TIE'] = function (spejnd) {
  wx[e[600118]]({ 'success': function (x8ryim) {
      var aq60b5 = window['k$IET'];aq60b5[e[600315]] = !![], aq60b5[e[600120]] = Number(x8ryim[e[600120]])[e[600316]](0x0), aq60b5[e[600122]] = x8ryim[e[600122]], spejnd && spejnd(aq60b5[e[600315]], aq60b5[e[600120]], aq60b5[e[600122]]);
    }, 'fail': function (sdpjne) {
      console[e[600041]](e[600317], sdpjne[e[600056]]);var i38gy = window['k$IET'];spejnd && spejnd(i38gy[e[600315]], i38gy[e[600120]], i38gy[e[600122]]);
    } });
}, window[e[600296]] = function (wl1uf9, igm3y, cw49zu, se_$2, ryim38, denpjs, v_$2, pcdn4j) {
  if (se_$2 == undefined) se_$2 = 0x1;wx[e[600200]]({ 'url': wl1uf9, 'method': v_$2 || e[600318], 'responseType': e[600319], 'data': igm3y, 'header': { 'content-type': pcdn4j || e[600202] }, 'success': function (d4pcz) {
      DEBUG && console[e[600041]](e[600320], wl1uf9, info, d4pcz);if (d4pcz && d4pcz[e[600321]] == 0xc8) {
        var k2$_vb = d4pcz[e[600181]];!denpjs || denpjs(k2$_vb) ? cw49zu && cw49zu(k2$_vb) : window[e[600322]](wl1uf9, igm3y, cw49zu, se_$2, ryim38, denpjs, d4pcz);
      } else window[e[600322]](wl1uf9, igm3y, cw49zu, se_$2, ryim38, denpjs, d4pcz);
    }, 'fail': function (ks$2e) {
      DEBUG && console[e[600041]](e[600323], wl1uf9, info, ks$2e), window[e[600322]](wl1uf9, igm3y, cw49zu, se_$2, ryim38, denpjs, ks$2e);
    }, 'complete': function () {} });
}, window[e[600322]] = function (q0567, cdu9z4, z9u1fw, b52a, o8x, roxi8, m8r) {
  b52a - 0x1 > 0x0 ? setTimeout(function () {
    window[e[600296]](q0567, cdu9z4, z9u1fw, b52a - 0x1, o8x, roxi8);
  }, 0x3e8) : o8x && o8x(JSON[e[600026]]({ 'url': q0567, 'response': m8r }));
}, window[e[600324]] = function (av6b, uwcf9, ro70x, cd49pz, $v_s2k, x50oq, fuz9w) {
  !ro70x && (ro70x = {});var yt = Math[e[600325]](Date[e[600132]]() / 0x3e8);ro70x[e[600248]] = yt, ro70x[e[600326]] = uwcf9;var jn_pes = Object['keys'](ro70x)[e[600327]](),
      orix87 = '',
      nsk_e = '';for (var va26b5 = 0x0; va26b5 < jn_pes[e[600010]]; va26b5++) {
    orix87 = orix87 + (va26b5 == 0x0 ? '' : '&') + jn_pes[va26b5] + ro70x[jn_pes[va26b5]], nsk_e = nsk_e + (va26b5 == 0x0 ? '' : '&') + jn_pes[va26b5] + '=' + encodeURIComponent(ro70x[jn_pes[va26b5]]);
  }orix87 = orix87 + k$E['apikey'];var zdpc = e[600328] + md5(orix87);send(av6b + '?' + nsk_e + (nsk_e == '' ? '' : '&') + zdpc, null, cd49pz, $v_s2k, x50oq, fuz9w || function (ksnj) {
    return ksnj[e[600182]] == e[600241];
  }, null, e[600329]);
}, window['k$TEI'] = function (ym3g, v26b) {
  var x07qr = 0x0;k$E[e[600022]] && (x07qr = k$E[e[600022]][e[600023]]), sendApi(k$E[e[600147]], e[600330], { 'partnerId': k$E[e[600150]], 'gamePkg': k$E['pkgName'], 'logTime': Math[e[600325]](Date[e[600132]]() / 0x3e8), 'platformUid': k$E[e[600244]], 'type': ym3g, 'serverId': x07qr }, null, 0x2, null, function () {
    return !![];
  });
}, window['k$EIT'] = function (_2kes) {
  sendApi(k$E[e[600146]], e[600331], { 'partner_id': k$E[e[600150]], 'uid': k$E[e[600019]], 'version': k$E[e[600075]], 'game_pkg': k$E['pkgName'], 'device': k$E[e[600151]] }, k$ETI, kTE$, kEI);
}, window['k$ETI'] = function (pn_jse) {
  if (pn_jse[e[600182]] === e[600241] && pn_jse[e[600181]]) {
    pn_jse[e[600181]][e[600332]]({ 'id': -0x2, 'name': e[600333] }), pn_jse[e[600181]][e[600332]]({ 'id': -0x1, 'name': e[600334] }), k$E[e[600335]] = pn_jse[e[600181]];if (window[e[600336]]) window[e[600336]][e[600337]]();
  } else k$E[e[600338]] = ![], window['kIT$E']('reqServerGroupCallBack ' + pn_jse[e[600182]]);
}, window['kIT$'] = function (wl91) {
  sendApi(k$E[e[600146]], e[600339], { 'partner_id': k$E[e[600150]], 'uid': k$E[e[600019]], 'version': k$E[e[600075]], 'game_pkg': k$E['pkgName'], 'device': k$E[e[600151]] }, kI$T, kTE$, kEI);
}, window['kI$T'] = function (va26b) {
  k$E[e[600340]] = ![];if (va26b[e[600182]] === e[600241] && va26b[e[600181]]) {
    for (var _ek$s = 0x0; _ek$s < va26b[e[600181]][e[600010]]; _ek$s++) {
      va26b[e[600181]][_ek$s][e[600260]] = k$TI(va26b[e[600181]][_ek$s]);
    }k$E[e[600153]][-0x1] = window[e[600341]](va26b[e[600181]]), window[e[600336]][e[600342]](-0x1);
  } else window['kIT$E']('reqServerOwnerCallBack ' + va26b[e[600182]]);
}, window[e[600343]] = function (v2ab6$) {
  sendApi(k$E[e[600146]], e[600339], { 'partner_id': k$E[e[600150]], 'uid': k$E[e[600019]], 'version': k$E[e[600075]], 'game_pkg': k$E['pkgName'], 'device': k$E[e[600151]] }, v2ab6$, kTE$, kEI);
}, window['kTI$'] = function (aq576, pd4nej) {
  sendApi(k$E[e[600146]], e[600344], { 'partner_id': k$E[e[600150]], 'uid': k$E[e[600019]], 'version': k$E[e[600075]], 'game_pkg': k$E['pkgName'], 'device': k$E[e[600151]], 'server_group_id': pd4nej }, kT$I, kTE$, kEI);
}, window['kT$I'] = function (bav25) {
  k$E[e[600340]] = ![];if (bav25[e[600182]] === e[600241] && bav25[e[600181]] && bav25[e[600181]][e[600181]]) {
    var l9fu1 = bav25[e[600181]][e[600345]],
        k2$s = [];for (var _s2$v = 0x0; _s2$v < bav25[e[600181]][e[600181]][e[600010]]; _s2$v++) {
      bav25[e[600181]][e[600181]][_s2$v][e[600260]] = k$TI(bav25[e[600181]][e[600181]][_s2$v]), (k2$s[e[600010]] == 0x0 || bav25[e[600181]][e[600181]][_s2$v][e[600260]] != 0x0) && (k2$s[k2$s[e[600010]]] = bav25[e[600181]][e[600181]][_s2$v]);
    }k$E[e[600153]][l9fu1] = window[e[600341]](k2$s), window[e[600336]][e[600342]](l9fu1);
  } else window['kIT$E']('reqServerListCallBack ' + bav25[e[600182]]);
}, window['kBTE$'] = function (m3iyr) {
  sendApi(k$E[e[600146]], e[600346], { 'partner_id': k$E[e[600150]], 'uid': k$E[e[600019]], 'version': k$E[e[600075]], 'game_pkg': k$E['pkgName'], 'device': k$E[e[600151]] }, reqServerRecommendCallBack, kTE$, kEI);
}, window['reqServerRecommendCallBack'] = function (sednjp) {
  k$E[e[600340]] = ![];if (sednjp[e[600182]] === e[600241] && sednjp[e[600181]]) {
    for (var d9czu4 = 0x0; d9czu4 < sednjp[e[600181]][e[600010]]; d9czu4++) {
      sednjp[e[600181]][d9czu4][e[600260]] = k$TI(sednjp[e[600181]][d9czu4]);
    }k$E[e[600153]][-0x2] = window[e[600341]](sednjp[e[600181]]), window[e[600336]][e[600342]](-0x2);
  } else alert('reqServerRecommendCallBack ' + sednjp[e[600182]]);
}, window[e[600341]] = function (avb$6) {
  if (!avb$6 && avb$6[e[600010]] <= 0x0) return avb$6;for (let ud4z9 = 0x0; ud4z9 < avb$6[e[600010]]; ud4z9++) {
    avb$6[ud4z9][e[600347]] && avb$6[ud4z9][e[600347]] == 0x1 && (avb$6[ud4z9][e[600256]] += e[600348]);
  }return avb$6;
}, window['k$IT'] = function (lu9f1, pjdnc4) {
  lu9f1 = lu9f1 || k$E[e[600022]][e[600023]], sendApi(k$E[e[600146]], e[600349], { 'type': '4', 'game_pkg': k$E['pkgName'], 'server_id': lu9f1 }, pjdnc4);
}, window[e[600350]] = function (q60a57, v$s2, z4dpc9, k2v$b6) {
  z4dpc9 = z4dpc9 || k$E[e[600022]][e[600023]], sendApi(k$E[e[600146]], e[600351], { 'type': q60a57, 'game_pkg': v$s2, 'server_id': z4dpc9 }, k2v$b6);
}, window['k$TI'] = function (esnjp_) {
  if (esnjp_) {
    if (esnjp_[e[600260]] == 0x1) {
      if (esnjp_[e[600352]] == 0x1) return 0x2;else return 0x1;
    } else return esnjp_[e[600260]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['kEIT$'] = function (b2$_k, i8r3my) {
  k$E['last_check_ban'] = { 'step': b2$_k, 'server_id': i8r3my };var x78r0o = this;kI$TE({ 'title': e[600353] }), sendApi(k$E[e[600146]], 'User.checkInfo', { 'partner_id': k$E[e[600150]], 'uid': k$E[e[600019]], 'game_pkg': k$E['pkgName'], 'server_id': i8r3my, 'platform': k$E[e[600079]], 'platform_uid': k$E[e[600244]], 'check_login_time': k$E[e[600247]], 'check_login_sign': k$E[e[600245]], 'version_name': k$E[e[600222]] }, kEI$T, kTE$, kEI, function (qb56v) {
    return qb56v[e[600182]] == e[600241] || qb56v[e[600001]] == e[600354] || qb56v[e[600001]] == e[600355];
  });
}, window['kEI$T'] = function (f91w) {
  var mr8i3 = this;if (f91w[e[600182]] === e[600241] && f91w[e[600181]]) {
    var ek$ = k$E[e[600022]];ek$[e[600356]] = k$E[e[600154]], ek$[e[600246]] = String(f91w[e[600181]][e[600357]]), ek$['tick'] = parseInt(f91w[e[600181]][e[600248]]);if (f91w[e[600181]][e[600358]]) ek$[e[600358]] = parseInt(f91w[e[600181]][e[600358]]);else ek$[e[600358]] = parseInt(f91w[e[600181]][e[600023]]);ek$[e[600359]] = 0x0, ek$[e[600021]] = k$E[e[600270]], ek$[e[600360]] = f91w[e[600181]][e[600361]], ek$[e[600362]] = f91w[e[600181]][e[600362]], console[e[600041]](e[600363] + JSON[e[600026]](ek$[e[600362]])), k$E[e[600254]] == 0x1 && ek$[e[600362]] && ek$[e[600362]][e[600364]] == 0x1 && (k$E[e[600365]] = 0x1, window[e[600034]][e[600035]]['kBE$']()), kETI$();
  } else k$E['last_check_ban'][e[600366]] >= 0x3 ? (kEI(JSON[e[600026]](f91w)), window['kIT$E']('User.checkInfo failed: ' + f91w[e[600182]])) : sendApi(k$E[e[600146]], e[600231], { 'platform': k$E['sdk_name'], 'partner_id': k$E[e[600150]], 'token': k$E['sdk_token'], 'game_pkg': k$E['pkgName'], 'deviceId': k$E[e[600151]], 'scene': e[600232] + k$E[e[600152]] }, function (fzuc) {
    if (!fzuc || fzuc[e[600182]] != e[600241]) {
      window['kIT$E'](e[600242] + fzuc && fzuc[e[600182]]);return;
    }k$E[e[600245]] = String(fzuc[e[600246]]), k$E[e[600247]] = String(fzuc[e[600248]]), setTimeout(function () {
      kEIT$(k$E['last_check_ban'][e[600366]] + 0x1, k$E['last_check_ban'][e[600023]]);
    }, 0x5dc);
  }, kTE$, kEI, function ($kv_b) {
    return $kv_b[e[600182]] == e[600241] || $kv_b[e[600182]] == e[600367];
  });
}, window['kETI$'] = function () {
  ServerLoading[e[600035]][e[600263]](k$E[e[600254]]), window['kTE'] = !![], window['kE$IT']();
}, window['kET$I'] = function () {
  if (window['kET'] && window['k$TE'] && window[e[600165]] && window[e[600166]] && window['k$ET'] && window['k$T']) {
    if (!window[e[600368]][e[600035]]) {
      console[e[600041]](e[600369] + window[e[600368]][e[600035]]);var q57o0x = wx[e[600370]](),
          a650b = q57o0x[e[600129]] ? q57o0x[e[600129]] : 0x0,
          rymi8x = { 'cdn': window['k$E'][e[600021]], 'spareCdn': window['k$E'][e[600221]], 'newRegister': window['k$E'][e[600254]], 'wxPC': window['k$E'][e[600107]], 'wxIOS': window['k$E'][e[600101]], 'wxAndroid': window['k$E'][e[600104]], 'wxParam': { 'limitLoad': window['k$E']['kBITE$'], 'benchmarkLevel': window['k$E']['kBI$TE'], 'wxFrom': window[e[600006]][e[600227]] == e[600371] ? 0x1 : 0x0, 'wxSDKVersion': window[e[600039]] }, 'configType': window['k$E'][e[600160]], 'exposeType': window['k$E'][e[600162]], 'scene': a650b };new window[e[600368]](rymi8x, window['k$E'][e[600020]], window['kBIT$E']);
    }
  }
}, window['kE$IT'] = function () {
  if (window['kET'] && window['k$TE'] && window[e[600165]] && window[e[600166]] && window['k$ET'] && window['k$T'] && window['kTE'] && window['kT$']) {
    kI$ET();if (!kET$) {
      kET$ = !![];if (!window[e[600368]][e[600035]]) window['kET$I']();var uw1l9 = 0x0,
          _esnpj = wx[e[600372]]();_esnpj && (window['k$E'][e[600106]] && (uw1l9 = _esnpj[e[600096]]), console[e[600001]](e[600373] + _esnpj[e[600096]] + e[600374] + _esnpj[e[600097]] + e[600375] + _esnpj[e[600098]] + e[600376] + _esnpj[e[600099]] + e[600377] + _esnpj[e[600378]] + e[600379] + _esnpj[e[600380]]));var q706 = {};for (const se2k$ in k$E[e[600022]]) {
        q706[se2k$] = k$E[e[600022]][se2k$];
      }var k$b_ = { 'channel': window['k$E'][e[600155]], 'account': window['k$E'][e[600019]], 'userId': window['k$E'][e[600243]], 'cdn': window['k$E'][e[600021]], 'data': window['k$E'][e[600181]], 'package': window['k$E']['package'], 'newRegister': window['k$E'][e[600254]], 'pkgName': window['k$E']['pkgName'], 'partnerId': window['k$E'][e[600150]], 'platform_uid': window['k$E'][e[600244]], 'deviceId': window['k$E'][e[600151]], 'selectedServer': q706, 'configType': window['k$E'][e[600160]], 'exposeType': window['k$E'][e[600162]], 'debugUsers': window['k$E'][e[600158]], 'wxMenuTop': uw1l9, 'wxShield': window['k$E'][e[600164]] };if (window['pkgOptions']) for (var u9zc4d in window['pkgOptions']) {
        k$b_[u9zc4d] = window['pkgOptions'][u9zc4d];
      }window[e[600368]][e[600035]]['kE$B'](k$b_), setTimeout(() => {
        !k$E[e[600164]] && new minitool();
      }, 0x2710);
    }
  } else console[e[600001]]('\u3010登录\u3011loadProbPkg:' + window['kET'] + ',loadMainPkg:' + window['k$TE'] + e[600381] + window[e[600165]] + e[600382] + window[e[600166]] + e[600383] + window['k$ET'] + e[600384] + window['k$T'] + ',isCheckBan:' + window['kTE'] + e[600385] + window['kT$']);
};