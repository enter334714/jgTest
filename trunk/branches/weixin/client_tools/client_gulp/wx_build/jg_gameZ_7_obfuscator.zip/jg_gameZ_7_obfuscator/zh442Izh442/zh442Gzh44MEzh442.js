var e = wx.$F;
console[e[600001]](e[600002]), window[e[600003]], wx[e[600004]](function (fw19ul) {
  if (fw19ul) {
    if (fw19ul[e[600005]]) {
      var pnd4j = window[e[600006]][e[600007]][e[600008]](new RegExp(/\./, 'g'), '_'),
          ne = fw19ul[e[600005]],
          psendj = ne[e[600009]](/(zh44zh44zh44zh44zh44\/zh442Gzh44MEzh442.js:)[0-9]{1,60}(:)/g);if (psendj) for (var qv56ab = 0x0; qv56ab < psendj[e[600010]]; qv56ab++) {
        if (psendj[qv56ab] && psendj[qv56ab][e[600010]] > 0x0) {
          var ixry = parseInt(psendj[qv56ab][e[600008]](e[600011], '')[e[600008]](':', ''));ne = ne[e[600008]](psendj[qv56ab], psendj[qv56ab][e[600008]](':' + ixry + ':', ':' + (ixry - 0x2) + ':'));
        }
      }ne = ne[e[600008]](new RegExp(e[600012], 'g'), e[600013] + pnd4j + e[600014]), ne = ne[e[600008]](new RegExp(e[600015], 'g'), e[600013] + pnd4j + e[600014]), fw19ul[e[600005]] = ne;
    }var dcznp4 = { 'id': window['k$E'][e[600016]], 'role': window['k$E'][e[600017]], 'level': window['k$E'][e[600018]], 'user': window['k$E'][e[600019]], 'version': window['k$E'][e[600020]], 'cdn': window['k$E'][e[600021]], 'pkgName': window['k$E']['pkgName'], 'gamever': window[e[600006]][e[600007]], 'serverid': window['k$E'][e[600022]] ? window['k$E'][e[600022]][e[600023]] : 0x0, 'systemInfo': window[e[600024]], 'error': e[600025], 'stack': fw19ul ? fw19ul[e[600005]] : '' },
        _esnk = JSON[e[600026]](dcznp4);console[e[600027]](e[600028] + _esnk), (!window[e[600003]] || window[e[600003]] != dcznp4[e[600027]]) && (window[e[600003]] = dcznp4[e[600027]], window['kI$'](dcznp4));
  }
});import 'zh44zh44bfzh44zh44.js';import 'zh44zh4411zh44zh44.js';window[e[600029]] = require(e[600030]);import 'zh44INDzh44zh44.js';import 'zh44zh44Izh441zh44zh44.js';import 'zh44zh44Mtadzh44zh44.js';import 'zh44zh44INIzh44azh44.js';import 'SyMiniTool.js';console[e[600001]](e[600031]), console[e[600001]](e[600032]), kI$TE({ 'title': e[600033] });var lmiyx8r = { 'kBIE$T': !![] };new window[e[600034]](lmiyx8r), window[e[600034]][e[600035]]['kBT$EI']();if (window['kBI$ET']) clearInterval(window['kBI$ET']);window['kBI$ET'] = null, window['kBTEI$'] = function (b$vk2, a06qb5) {
  if (!b$vk2 || !a06qb5) return 0x0;b$vk2 = b$vk2[e[600036]]('.'), a06qb5 = a06qb5[e[600036]]('.');const av5b62 = Math[e[600037]](b$vk2[e[600010]], a06qb5[e[600010]]);while (b$vk2[e[600010]] < av5b62) {
    b$vk2[e[600038]]('0');
  }while (a06qb5[e[600010]] < av5b62) {
    a06qb5[e[600038]]('0');
  }for (var x0or7q = 0x0; x0or7q < av5b62; x0or7q++) {
    const uzw91 = parseInt(b$vk2[x0or7q]),
          r8my = parseInt(a06qb5[x0or7q]);if (uzw91 > r8my) return 0x1;else {
      if (uzw91 < r8my) return -0x1;
    }
  }return 0x0;
}, window[e[600039]] = wx[e[600040]]()[e[600039]], console[e[600041]](e[600042] + window[e[600039]]);var lk2_v$ = wx[e[600043]]();lk2_v$['onCheckForUpdate'](function (uwfz19) {
  console[e[600041]](e[600044] + uwfz19[e[600045]]);
}), lk2_v$[e[600046]](function () {
  wx[e[600047]]({ 'title': e[600048], 'content': e[600049], 'showCancel': ![], 'success': function (yrmx) {
      lk2_v$[e[600050]]();
    } });
}), lk2_v$[e[600051]](function () {
  console[e[600041]](e[600052]);
}), window['kBTE$I'] = function () {
  console[e[600041]](e[600053]);var igym = wx['loadSubpackage']({ 'name': e[600054], 'success': function (lf19wu) {
      console[e[600041]](e[600055]), console[e[600041]](lf19wu), lf19wu && lf19wu[e[600056]] == 'loadSubpackage:ok' ? (window['kET'] = !![], window['kET$I'](), window['kE$IT']()) : setTimeout(function () {
        window['kBTE$I']();
      }, 0x1f4);
    }, 'fail': function (q5a6b) {
      console[e[600041]](e[600057]), console[e[600041]](q5a6b), setTimeout(function () {
        window['kBTE$I']();
      }, 0x1f4);
    } });igym && igym[e[600058]](_enkjs => {});
}, window['kB$IET'] = function () {
  console[e[600041]](e[600059]);var e$j_k = wx['loadSubpackage']({ 'name': e[600060], 'success': function (i8mxr) {
      console[e[600041]](e[600061]), console[e[600041]](i8mxr), i8mxr && i8mxr[e[600056]] == 'loadSubpackage:ok' ? (window['k$TE'] = !![], window['kET$I'](), window['kE$IT']()) : setTimeout(function () {
        window['kB$IET']();
      }, 0x1f4);
    }, 'fail': function (jes_$k) {
      console[e[600041]](e[600062]), console[e[600041]](jes_$k), setTimeout(function () {
        window['kB$IET']();
      }, 0x1f4);
    } });e$j_k && e$j_k[e[600058]](a$vb2 => {});
}, window['loadSubpackages'] = function () {
  window['kBTEI$'](window[e[600039]], e[600063]) >= 0x0 ? (console[e[600041]](e[600064] + window[e[600039]] + e[600065]), window['k$I'](), window['kBTE$I'](), window['kB$IET']()) : (window['k$EI'](e[600066], window[e[600039]]), wx[e[600047]]({ 'title': e[600067], 'content': e[600068] }));
}, window[e[600024]] = '', wx[e[600069]]({ 'success'(i3myg) {
    window[e[600024]] = e[600070] + i3myg[e[600071]] + e[600072] + i3myg[e[600073]] + e[600074] + i3myg[e[600075]] + e[600076] + i3myg[e[600077]] + e[600078] + i3myg[e[600079]] + e[600080] + i3myg[e[600039]] + e[600081] + i3myg['benchmarkLevel'], console[e[600041]](window[e[600024]]), console[e[600041]](e[600082] + i3myg[e[600083]] + e[600084] + i3myg[e[600085]] + e[600086] + i3myg[e[600087]] + e[600088] + i3myg[e[600089]] + e[600090] + i3myg[e[600091]] + e[600092] + i3myg[e[600093]] + e[600094] + (i3myg[e[600095]] ? i3myg[e[600095]][e[600096]] + ',' + i3myg[e[600095]][e[600097]] + ',' + i3myg[e[600095]][e[600098]] + ',' + i3myg[e[600095]][e[600099]] : ''));var e_jn = i3myg[e[600077]] ? i3myg[e[600077]][e[600100]]() : '',
        u4c9w = i3myg[e[600073]] ? i3myg[e[600073]][e[600100]]()[e[600008]]('\x20', '') : '';window['k$E'][e[600101]] = e_jn[e[600102]](e[600103]) != -0x1, window['k$E'][e[600104]] = e_jn[e[600102]](e[600105]) != -0x1, window['k$E'][e[600106]] = e_jn[e[600102]](e[600103]) != -0x1 || e_jn[e[600102]](e[600105]) != -0x1, window['k$E'][e[600107]] = e_jn[e[600102]](e[600108]) != -0x1 || e_jn[e[600102]](e[600109]) != -0x1, window['k$E'][e[600110]] = i3myg[e[600079]] ? i3myg[e[600079]][e[600100]]() : '', window['k$E']['kBITE$'] = ![], window['k$E']['kBI$TE'] = 0x2;if (e_jn[e[600102]](e[600105]) != -0x1) {
      if (i3myg['benchmarkLevel'] >= 0x18) window['k$E']['kBI$TE'] = 0x3;else window['k$E']['kBI$TE'] = 0x2;
    } else {
      if (e_jn[e[600102]](e[600103]) != -0x1) {
        if (i3myg['benchmarkLevel'] && i3myg['benchmarkLevel'] >= 0x14) window['k$E']['kBI$TE'] = 0x3;else {
          if (u4c9w[e[600102]](e[600111]) != -0x1 || u4c9w[e[600102]](e[600112]) != -0x1 || u4c9w[e[600102]](e[600113]) != -0x1 || u4c9w[e[600102]](e[600114]) != -0x1 || u4c9w[e[600102]](e[600115]) != -0x1) window['k$E']['kBI$TE'] = 0x2;else window['k$E']['kBI$TE'] = 0x3;
        }
      } else window['k$E']['kBI$TE'] = 0x2;
    }console[e[600041]](e[600116] + window['k$E']['kBITE$'] + e[600117] + window['k$E']['kBI$TE']);
  } }), wx[e[600118]]({ 'success': function (rom8) {
    console[e[600041]](e[600119] + rom8[e[600120]] + e[600121] + rom8[e[600122]]);
  } }), wx['getNetworkType']({ 'success': function (ri8m3y) {
    console[e[600041]](e[600123] + ri8m3y['networkType']);
  } }), wx[e[600124]]({ 'keepScreenOn': !![] }), wx['onNetworkStatusChange'](function (cpz9) {
  console[e[600041]](e[600123] + cpz9['networkType'] + e[600125] + cpz9[e[600126]]);
}), wx[e[600127]](function (cdzn) {
  window['kTI'] = cdzn, window['kEIT'] && window['kTI'] && (console[e[600001]](e[600128] + window['kTI'][e[600129]]), window['kEIT'](window['kTI']), window['kTI'] = null);
}), window[e[600130]] = 0x0, window['kB$TEI'] = 0x0, window['onMemoryWarningCallBack'] = null, wx[e[600131]](function () {
  window['kB$TEI']++;var sv$2_ = Date[e[600132]]();(window[e[600130]] == 0x0 || sv$2_ - window[e[600130]] > 0x1d4c0) && (console[e[600133]](e[600134]), wx[e[600135]]());if (window['kB$TEI'] >= 0x2) {
    window['kB$TEI'] = 0x0, console[e[600027]](e[600136]), wx[e[600137]]('0', 0x1);if (window['k$E'] && window['k$E'][e[600101]]) window['k$EI'](e[600138], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});