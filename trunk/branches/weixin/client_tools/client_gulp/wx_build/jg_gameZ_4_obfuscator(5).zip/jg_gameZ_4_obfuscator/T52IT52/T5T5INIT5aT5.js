'use strict';

var B = wx.$B;
var Bsun7h6,
    Bk9lb = this && this[B[520433]] || function () {
  var fr3j8 = Object[B[520434]] || { '__proto__': [] } instanceof Array && function (spugen, y4lvbz) {
    spugen[B[520435]] = y4lvbz;
  } || function (t0$_dx, qx$dt_) {
    for (var ly$tv in qx$dt_) qx$dt_[B[520436]](ly$tv) && (t0$_dx[ly$tv] = qx$dt_[ly$tv]);
  };return function (jf1, ep2gia) {
    function unshg() {
      this[B[520437]] = jf1;
    }fr3j8(jf1, ep2gia), jf1[B[520438]] = null === ep2gia ? Object[B[520439]](ep2gia) : (unshg[B[520438]] = ep2gia[B[520438]], new unshg());
  };
}(),
    Bd$0 = laya['ui'][B[520440]],
    Bl$0v4 = laya['ui'][B[520441]];!function (f283wa) {
  var d_0tx$ = function (y4v0l$) {
    function r58j() {
      return y4v0l$[B[520442]](this) || this;
    }return Bk9lb(r58j, y4v0l$), r58j[B[520438]][B[520443]] = function () {
      y4v0l$[B[520438]][B[520443]][B[520442]](this), this[B[520444]](f283wa['B$O'][B[520445]]);
    }, r58j[B[520445]] = { 'type': B[520440], 'props': { 'width': 0x2d0, 'name': B[520446], 'height': 0x500 }, 'child': [{ 'type': B[520447], 'props': { 'width': 0x2d0, 'var': B[520448], 'skin': B[520449], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': B[520450], 'props': { 'y': 0x0, 'width': 0x2d0, 'right': 0x0, 'height': 0x500 }, 'child': [{ 'type': B[520447], 'props': { 'width': 0x2d0, 'var': B[520451], 'top': -0x8b, 'skin': B[520452], 'height': 0x8b, 'centerX': 0x0, 'anchorY': 0x1 } }, { 'type': B[520447], 'props': { 'width': 0x2d0, 'var': B[520453], 'top': 0x500, 'skin': B[520454], 'height': 0x8b, 'centerX': 0x0 } }, { 'type': B[520447], 'props': { 'x': -0xdc, 'width': 0xdc, 'var': B[520455], 'skin': B[520456], 'left': -0xdc, 'height': 0x500, 'centerY': 0x0 } }, { 'type': B[520447], 'props': { 'width': 0xdc, 'var': B[520457], 'skin': B[520458], 'left': 0x2d0, 'height': 0x500, 'centerY': 0x0 } }] }] }, r58j;
  }(Bd$0);f283wa['B$O'] = d_0tx$;
}(Bsun7h6 || (Bsun7h6 = {})), function (kh9s76) {
  var epgu2i = function (u7nshg) {
    function ipw2a() {
      return u7nshg[B[520442]](this) || this;
    }return Bk9lb(ipw2a, u7nshg), ipw2a[B[520438]][B[520443]] = function () {
      u7nshg[B[520438]][B[520443]][B[520442]](this), this[B[520444]](kh9s76['B$J'][B[520445]]);
    }, ipw2a[B[520445]] = { 'type': B[520440], 'props': { 'width': 0x2d0, 'name': B[520459], 'height': 0x500 }, 'child': [{ 'type': B[520447], 'props': { 'width': 0x2d0, 'var': B[520448], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': B[520450], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x2d0, 'height': 0x500 }, 'child': [{ 'type': B[520447], 'props': { 'var': B[520451], 'centerX': 0x0, 'bottom': 0x500, 'anchorY': 0x1 } }, { 'type': B[520447], 'props': { 'var': B[520453], 'top': 0x500, 'centerX': 0x0 } }, { 'type': B[520447], 'props': { 'var': B[520455], 'right': 0x2d0, 'pivotX': 0x1, 'centerY': 0x0 } }, { 'type': B[520447], 'props': { 'var': B[520457], 'left': 0x2d0, 'centerY': 0x0 } }] }, { 'type': B[520447], 'props': { 'var': B[520460], 'skin': B[520461], 'centerX': 0x0, 'bottom': 0xa } }, { 'type': B[520450], 'props': { 'y': 0x3c3, 'x': 0x0, 'width': 0x2d0, 'var': B[520462], 'name': B[520462], 'height': 0x82 }, 'child': [{ 'type': B[520447], 'props': { 'y': 0x2e, 'x': 0x3e, 'width': 0x254, 'var': B[520463], 'skin': B[520464], 'height': 0x1b, 'centerX': 0x0 } }, { 'type': B[520447], 'props': { 'y': 0x31, 'x': 0x40, 'width': 0x24e, 'var': B[520465], 'skin': B[520466], 'height': 0x15 } }, { 'type': B[520447], 'props': { 'y': 0x37, 'x': 0x1fb, 'width': 0xd0, 'var': B[520467], 'skin': B[520468], 'height': 0xb } }, { 'type': B[520447], 'props': { 'y': 0x6, 'x': 0x274, 'width': 0x27, 'var': B[520469], 'skin': B[520470], 'height': 0x74 } }, { 'type': B[520471], 'props': { 'y': 0x30, 'x': 0x125, 'width': 0x86, 'var': B[520472], 'valign': B[520473], 'text': B[520474], 'strokeColor': B[520475], 'stroke': 0x3, 'height': 0x18, 'fontSize': 0x18, 'color': B[520476], 'centerX': 0x0, 'bold': !0x1, 'align': B[520477] } }] }, { 'type': B[520450], 'props': { 'y': 0x429, 'x': 0x0, 'width': 0x2d0, 'var': B[520478], 'name': B[520478], 'height': 0x11 }, 'child': [{ 'type': B[520447], 'props': { 'y': 0x0, 'x': 0x133, 'var': B[520479], 'skin': B[520480], 'centerX': -0x2d } }, { 'type': B[520447], 'props': { 'y': 0x0, 'x': 0x151, 'var': B[520481], 'skin': B[520482], 'centerX': -0xf } }, { 'type': B[520447], 'props': { 'y': 0x0, 'x': 0x16f, 'var': B[520483], 'skin': B[520484], 'centerX': 0xf } }, { 'type': B[520447], 'props': { 'y': 0x0, 'x': 0x18d, 'var': B[520485], 'skin': B[520484], 'centerX': 0x2d } }] }, { 'type': B[520486], 'props': { 'y': 0x316, 'x': 0x37, 'visible': !0x1, 'var': B[520487], 'stateNum': 0x1, 'skin': B[520488], 'name': B[520487], 'labelSize': 0x1e, 'labelFont': B[520489], 'labelColors': B[520490] }, 'child': [{ 'type': B[520471], 'props': { 'y': 0x9b, 'x': 0x92, 'width': 0x143, 'var': B[520491], 'text': B[520492], 'name': B[520491], 'height': 0x1e, 'fontSize': 0x1e, 'color': B[520493], 'align': B[520477] } }] }, { 'type': B[520471], 'props': { 'y': 0x453, 'width': 0x1f4, 'var': B[520494], 'valign': B[520473], 'text': B[520495], 'height': 0x1a, 'fontSize': 0x1a, 'color': B[520496], 'centerX': 0x0, 'bold': !0x1, 'align': B[520477] } }, { 'type': B[520471], 'props': { 'y': 0xa, 'x': 0xa, 'width': 0x156, 'var': B[520497], 'valign': B[520473], 'top': 0x14, 'text': B[520498], 'strokeColor': B[520499], 'stroke': 0x2, 'right': 0x14, 'height': 0x20, 'fontSize': 0x18, 'color': B[520500], 'bold': !0x1, 'align': B[520104] } }] }, ipw2a;
  }(Bd$0);kh9s76['B$J'] = epgu2i;
}(Bsun7h6 || (Bsun7h6 = {})), function (guenip) {
  var jf815 = function (g7shnu) {
    function spnegu() {
      return g7shnu[B[520442]](this) || this;
    }return Bk9lb(spnegu, g7shnu), spnegu[B[520438]][B[520443]] = function () {
      Bd$0[B[520501]](B[520502], laya[B[520503]][B[520504]][B[520502]]), Bd$0[B[520501]](B[520505], laya[B[520506]][B[520505]]), g7shnu[B[520438]][B[520443]][B[520442]](this), this[B[520444]](guenip['B$D'][B[520445]]);
    }, spnegu[B[520445]] = { 'type': B[520440], 'props': { 'width': 0x2d0, 'name': B[520507], 'height': 0x500 }, 'child': [{ 'type': B[520447], 'props': { 'width': 0x2d0, 'var': B[520448], 'skin': B[520449], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': B[520450], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x2d0, 'height': 0x500 }, 'child': [{ 'type': B[520447], 'props': { 'width': 0x2d0, 'var': B[520451], 'skin': B[520452], 'bottom': 0x4ff } }, { 'type': B[520447], 'props': { 'width': 0x2d0, 'var': B[520453], 'top': 0x4ff, 'skin': B[520454] } }, { 'type': B[520447], 'props': { 'var': B[520455], 'skin': B[520456], 'right': 0x2cf, 'height': 0x500 } }, { 'type': B[520447], 'props': { 'var': B[520457], 'skin': B[520458], 'left': 0x2cf, 'height': 0x500 } }] }, { 'type': B[520447], 'props': { 'y': 0x34d, 'var': B[520508], 'skin': B[520509], 'centerX': 0x0 } }, { 'type': B[520447], 'props': { 'y': 0x44e, 'var': B[520510], 'skin': B[520511], 'name': B[520510], 'centerX': 0x0 } }, { 'type': B[520447], 'props': { 'y': 0x3a2, 'x': 0xa2, 'var': B[520512], 'skin': B[520513] } }, { 'type': B[520447], 'props': { 'var': B[520460], 'skin': B[520461], 'centerX': 0x0, 'bottom': 0x1e } }, { 'type': B[520447], 'props': { 'y': 0x3f7, 'var': B[520514], 'stateNum': 0x1, 'skin': B[520515], 'name': B[520514], 'centerX': 0x0 } }, { 'type': B[520447], 'props': { 'x': 0xc4, 'visible': !0x1, 'var': B[520516], 'skin': B[520517], 'bottom': 0x4 } }, { 'type': B[520471], 'props': { 'y': 0x280, 'x': 0x0, 'width': 0x2d0, 'var': B[520518], 'valign': B[520473], 'text': B[520519], 'strokeColor': B[520520], 'stroke': 0x2, 'height': 0x20, 'fontSize': 0x20, 'color': B[520521], 'bold': !0x1, 'align': B[520477] } }, { 'type': B[520471], 'props': { 'y': 0x3a4, 'x': 0x209, 'var': B[520522], 'valign': B[520473], 'text': B[520523], 'height': 0x20, 'fontSize': 0x1e, 'color': B[520524], 'bold': !0x1, 'align': B[520477] } }, { 'type': B[520471], 'props': { 'y': 0x3a4, 'width': 0x156, 'var': B[520525], 'valign': B[520473], 'text': B[520526], 'height': 0x20, 'fontSize': 0x1e, 'color': B[520524], 'centerX': 0x0, 'bold': !0x1, 'align': B[520477] } }, { 'type': B[520471], 'props': { 'width': 0x156, 'var': B[520497], 'valign': B[520473], 'top': 0x14, 'text': B[520498], 'strokeColor': B[520499], 'stroke': 0x2, 'right': 0x14, 'height': 0x20, 'fontSize': 0x18, 'color': B[520500], 'bold': !0x1, 'align': B[520104] } }, { 'type': B[520502], 'props': { 'y': 0x4e7, 'x': 0x100, 'visible': !0x1, 'var': B[520527], 'height': 0x10 } }, { 'type': B[520447], 'props': { 'y': 0x7f, 'x': 593.5, 'var': B[520528], 'skin': B[520529] } }, { 'type': B[520447], 'props': { 'y': 0x101, 'x': 0x252, 'visible': !0x1, 'var': B[520530], 'skin': B[520531], 'name': B[520530] } }, { 'type': B[520447], 'props': { 'y': 0x47, 'x': -0x2, 'visible': !0x1, 'var': B[520532], 'skin': B[520533], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': B[520447], 'props': { 'y': 36.5, 'x': 0x268, 'var': B[520534], 'skin': B[520535] } }, { 'type': B[520471], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': B[520536], 'valign': B[520473], 'text': B[520537], 'height': 0x23, 'fontSize': 0x1e, 'color': B[520520], 'bold': !0x1, 'align': B[520477] } }, { 'type': B[520505], 'props': { 'y': 0x8e, 'x': 0x3d, 'wordWrap': !0x0, 'width': 0x221, 'var': B[520538], 'valign': B[520101], 'overflow': B[520539], 'mouseEnabled': !0x0, 'leading': 0x4, 'height': 0x366, 'fontSize': 0x1a, 'color': B[520540] } }] }, { 'type': B[520447], 'props': { 'y': 0x71, 'x': 0x21, 'visible': !0x1, 'var': B[520541], 'skin': B[520542], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': B[520447], 'props': { 'y': 36.5, 'x': 0x268, 'var': B[520543], 'skin': B[520535] } }, { 'type': B[520486], 'props': { 'y': 0x388, 'x': 0xbe, 'var': B[520544], 'stateNum': 0x1, 'skin': B[520545], 'labelSize': 0x1e, 'labelColors': B[520546], 'label': B[520547] } }, { 'type': B[520450], 'props': { 'y': 0x388, 'x': 0x22, 'width': 0x254, 'var': B[520548], 'height': 0x3b } }, { 'type': B[520471], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': B[520549], 'valign': B[520473], 'text': B[520537], 'height': 0x23, 'fontSize': 0x1e, 'color': B[520520], 'bold': !0x1, 'align': B[520477] } }, { 'type': B[520550], 'props': { 'y': 0x8e, 'x': 0x3d, 'width': 0x221, 'var': B[520551], 'height': 0x2dd }, 'child': [{ 'type': B[520502], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x221, 'var': B[520552], 'height': 0x2dd } }] }] }, { 'type': B[520447], 'props': { 'visible': !0x1, 'var': B[520553], 'skin': B[520542], 'name': B[520553], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': B[520447], 'props': { 'y': 36.5, 'x': 0x268, 'var': B[520554], 'skin': B[520535] } }, { 'type': B[520486], 'props': { 'y': 0x388, 'x': 0xbe, 'var': B[520555], 'stateNum': 0x1, 'skin': B[520545], 'labelSize': 0x1e, 'labelColors': B[520546], 'label': B[520547] } }, { 'type': B[520450], 'props': { 'y': 0x388, 'x': 0x22, 'width': 0x254, 'var': B[520556], 'height': 0x3b } }, { 'type': B[520471], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': B[520557], 'valign': B[520473], 'text': B[520537], 'height': 0x23, 'fontSize': 0x1e, 'color': B[520520], 'bold': !0x1, 'align': B[520477] } }, { 'type': B[520550], 'props': { 'y': 0x8e, 'x': 0x3d, 'width': 0x221, 'var': B[520558], 'height': 0x2dd }, 'child': [{ 'type': B[520502], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x221, 'var': B[520559], 'height': 0x2dd } }] }] }, { 'type': B[520447], 'props': { 'visible': !0x1, 'var': B[520560], 'skin': B[520561], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': B[520450], 'props': { 'y': 0x75, 'x': 0x3d, 'width': 0xc8, 'var': B[520562], 'height': 0x389 } }, { 'type': B[520450], 'props': { 'y': 0x75, 'x': 0x125, 'width': 0x166, 'var': B[520563], 'height': 0x389 } }, { 'type': B[520447], 'props': { 'y': 0xd, 'x': 0x282, 'var': B[520564], 'skin': B[520565] } }] }] }, spnegu;
  }(Bd$0);guenip['B$D'] = jf815;
}(Bsun7h6 || (Bsun7h6 = {})), function (fw85) {
  var x0ty$v, psnuge;x0ty$v = fw85['B$p'] || (fw85['B$p'] = {}), psnuge = function (wr83) {
    function xqtd() {
      return wr83[B[520442]](this) || this;
    }return Bk9lb(xqtd, wr83), xqtd[B[520438]][B[520566]] = function () {
      wr83[B[520438]][B[520566]][B[520442]](this), this[B[520567]] = 0x0, this[B[520568]] = 0x0, this[B[520569]](), this[B[520570]]();
    }, xqtd[B[520438]][B[520569]] = function () {
      this['on'](Laya[B[520571]][B[520572]], this, this['B$m']);
    }, xqtd[B[520438]][B[520573]] = function () {
      this[B[520574]](Laya[B[520571]][B[520572]], this, this['B$m']);
    }, xqtd[B[520438]][B[520570]] = function () {
      this['B$C'] = Date[B[520174]](), Bzl4kb9[B[520035]]['B12LSN_'](), Bzl4kb9[B[520035]][B[520575]]();
    }, xqtd[B[520438]][B[520576]] = function (j8f15) {
      void 0x0 === j8f15 && (j8f15 = !0x0), this[B[520573]](), wr83[B[520438]][B[520576]][B[520442]](this, j8f15);
    }, xqtd[B[520438]]['B$m'] = function () {
      0x2710 < Date[B[520174]]() - this['B$C'] && (this['B$C'] -= 0x3e8, Bb67h9k[B[520577]]['B1NL'][B[520022]][B[520023]] && (Bzl4kb9[B[520035]][B[520578]](), Bzl4kb9[B[520035]][B[520579]]()));
    }, xqtd;
  }(Bsun7h6['B$O']), x0ty$v[B[520580]] = psnuge;
}(modules || (modules = {})), function (zvbk4) {
  var zbv4lk, yl4z0, y0_tx$, _$tq, guie2p, khb679;zbv4lk = zvbk4['B$i'] || (zvbk4['B$i'] = {}), yl4z0 = Laya[B[520571]], y0_tx$ = Laya[B[520447]], _$tq = Laya[B[520581]], guie2p = Laya[B[520582]], khb679 = function (yv$l4) {
    function p2eigu() {
      var blyzv4 = yv$l4[B[520442]](this) || this;return blyzv4['B$k'] = new y0_tx$(), blyzv4[B[520583]](blyzv4['B$k']), blyzv4['B$_'] = null, blyzv4['B$L'] = [], blyzv4['B$r'] = !0x1, blyzv4['B$H'] = 0x0, blyzv4['B$Y'] = !0x0, blyzv4['B$G'] = 0x6, blyzv4['B$X'] = !0x1, blyzv4['on'](yl4z0[B[520584]], blyzv4, blyzv4['B$c']), blyzv4['on'](yl4z0[B[520585]], blyzv4, blyzv4['B$h']), blyzv4;
    }return Bk9lb(p2eigu, yv$l4), p2eigu[B[520439]] = function (bkh97, $tvxy0, a83iw2, jm5r1, ghus, sk96h, y4l0v$) {
      void 0x0 === jm5r1 && (jm5r1 = 0x0), void 0x0 === ghus && (ghus = 0x6), void 0x0 === sk96h && (sk96h = !0x0), void 0x0 === y4l0v$ && (y4l0v$ = !0x1);var vtly0$ = new p2eigu();return vtly0$[B[520586]]($tvxy0, a83iw2, jm5r1), vtly0$[B[520587]] = ghus, vtly0$[B[520588]] = sk96h, vtly0$[B[520589]] = y4l0v$, bkh97 && bkh97[B[520583]](vtly0$), vtly0$;
    }, p2eigu[B[520590]] = function (w2a3i8) {
      w2a3i8 && (w2a3i8[B[520591]] = !0x0, w2a3i8[B[520590]]());
    }, p2eigu[B[520592]] = function (aep2i) {
      aep2i && (aep2i[B[520591]] = !0x1, aep2i[B[520592]]());
    }, p2eigu[B[520438]][B[520576]] = function (eiup2) {
      Laya[B[520593]][B[520594]](this, this['B$y']), this[B[520574]](yl4z0[B[520584]], this, this['B$c']), this[B[520574]](yl4z0[B[520585]], this, this['B$h']), yv$l4[B[520438]][B[520576]][B[520442]](this, eiup2);
    }, p2eigu[B[520438]]['B$c'] = function () {}, p2eigu[B[520438]]['B$h'] = function () {}, p2eigu[B[520438]][B[520586]] = function (vby4, ytv$l, zlvby4) {
      if (this['B$_'] != vby4) {
        this['B$_'] = vby4, this['B$L'] = [];for (var uigpe2 = 0x0, v4zklb = zlvby4; v4zklb <= ytv$l; v4zklb++) this['B$L'][uigpe2++] = vby4 + '/' + v4zklb + B[520595];var jr85f3 = guie2p[B[520596]](this['B$L'][0x0]);jr85f3 && (this[B[520422]] = jr85f3[B[520597]], this[B[520424]] = jr85f3[B[520598]]), this['B$y']();
      }
    }, Object[B[520599]](p2eigu[B[520438]], B[520589], { 'get': function () {
        return this['B$X'];
      }, 'set': function (lyv04) {
        this['B$X'] = lyv04;
      }, 'enumerable': !0x0, 'configurable': !0x0 }), Object[B[520599]](p2eigu[B[520438]], B[520587], { 'set': function (s67un) {
        this['B$G'] != s67un && (this['B$G'] = s67un, this['B$r'] && (Laya[B[520593]][B[520594]](this, this['B$y']), Laya[B[520593]][B[520588]](this['B$G'] * (0x3e8 / 0x3c), this, this['B$y'])));
      }, 'enumerable': !0x0, 'configurable': !0x0 }), Object[B[520599]](p2eigu[B[520438]], B[520588], { 'set': function (zklbv) {
        this['B$Y'] = zklbv;
      }, 'enumerable': !0x0, 'configurable': !0x0 }), p2eigu[B[520438]][B[520590]] = function () {
      this['B$r'] && this[B[520592]](), this['B$r'] = !0x0, this['B$H'] = 0x0, Laya[B[520593]][B[520588]](this['B$G'] * (0x3e8 / 0x3c), this, this['B$y']), this['B$y']();
    }, p2eigu[B[520438]][B[520592]] = function () {
      this['B$r'] = !0x1, this['B$H'] = 0x0, this['B$y'](), Laya[B[520593]][B[520594]](this, this['B$y']);
    }, p2eigu[B[520438]][B[520600]] = function () {
      this['B$r'] && (this['B$r'] = !0x1, Laya[B[520593]][B[520594]](this, this['B$y']));
    }, p2eigu[B[520438]][B[520601]] = function () {
      this['B$r'] || (this['B$r'] = !0x0, Laya[B[520593]][B[520588]](this['B$G'] * (0x3e8 / 0x3c), this, this['B$y']), this['B$y']());
    }, Object[B[520599]](p2eigu[B[520438]], B[520602], { 'get': function () {
        return this['B$r'];
      }, 'enumerable': !0x0, 'configurable': !0x0 }), p2eigu[B[520438]]['B$y'] = function () {
      this['B$L'] && 0x0 != this['B$L'][B[520010]] && (this['B$k'][B[520586]] = this['B$L'][this['B$H']], this['B$r'] && (this['B$H']++, this['B$H'] == this['B$L'][B[520010]] && (this['B$Y'] ? this['B$H'] = 0x0 : (Laya[B[520593]][B[520594]](this, this['B$y']), this['B$r'] = !0x1, this['B$X'] && (this[B[520591]] = !0x1), this[B[520603]](yl4z0[B[520604]])))));
    }, p2eigu;
  }(_$tq), zbv4lk[B[520605]] = khb679;
}(modules || (modules = {})), function (ylv$04) {
  var h9n7s6, giune, nh6s79;h9n7s6 = ylv$04['B$p'] || (ylv$04['B$p'] = {}), giune = ylv$04['B$i'][B[520605]], nh6s79 = function (sh7ugn) {
    function w32aei(eugpni) {
      void 0x0 === eugpni && (eugpni = 0x0);var t_d$x0 = sh7ugn[B[520442]](this) || this;return t_d$x0['B$v'] = { 'bgImgSkin': B[520606], 'topImgSkin': B[520607], 'btmImgSkin': B[520608], 'leftImgSkin': B[520609], 'rightImgSkin': B[520610], 'loadingBarBgSkin': B[520464], 'copyRightImgBottom': 0xa, 'processBox1Y': 0x3c3, 'processBox2Y': 0x429, 'loadingTipsSize': 0x1a, 'getTipsBtnVisible': !0x1 }, t_d$x0['B$A'] = { 'bgImgSkin': B[520611], 'topImgSkin': B[520612], 'btmImgSkin': B[520613], 'leftImgSkin': B[520614], 'rightImgSkin': B[520615], 'loadingBarBgSkin': B[520616], 'copyRightImgBottom': 0xa, 'processBox1Y': 0x3c3, 'processBox2Y': 0x429, 'loadingTipsSize': 0x1a, 'getTipsBtnVisible': !0x1 }, t_d$x0['B$q'] = 0x0, t_d$x0['B$d'](0x1 == eugpni ? t_d$x0['B$A'] : t_d$x0['B$v']), t_d$x0;
    }return Bk9lb(w32aei, sh7ugn), w32aei[B[520438]][B[520566]] = function () {
      if (sh7ugn[B[520438]][B[520566]][B[520442]](this), Bzl4kb9[B[520035]][B[520575]](), this['B$M'] = Bb67h9k[B[520577]]['B1NL'], this[B[520567]] = 0x0, this[B[520568]] = 0x0, this['B$M']) {
        var f38wr = this['B$M'][B[520178]];this[B[520494]][B[520617]] = 0x1 == f38wr ? B[520496] : 0x2 == f38wr ? B[520618] : 0x65 == f38wr ? B[520618] : B[520496];
      }this['B$a'] = [this[B[520479]], this[B[520481]], this[B[520483]], this[B[520485]]], Bb67h9k[B[520577]][B[520619]] = this, B1_NLS(), Bzl4kb9[B[520035]][B[520203]](), Bzl4kb9[B[520035]][B[520204]](), this[B[520570]]();
    }, w32aei[B[520438]]['B1_NL'] = function (q$_dtx) {
      var n7ug = this;if (-0x1 === q$_dtx) return n7ug['B$q'] = 0x0, Laya[B[520593]][B[520594]](this, this['B1_NL']), void Laya[B[520593]][B[520620]](0x1, this, this['B1_NL']);if (-0x2 !== q$_dtx) {
        n7ug['B$q'] < 0.9 ? n7ug['B$q'] += (0.15 * Math[B[520223]]() + 0.01) / (0x64 * Math[B[520223]]() + 0x32) : n7ug['B$q'] < 0x1 && (n7ug['B$q'] += 0.0001), 0.9999 < n7ug['B$q'] && (n7ug['B$q'] = 0.9999, Laya[B[520593]][B[520594]](this, this['B1_NL']), Laya[B[520593]][B[520621]](0xbb8, this, function () {
          0.9 < n7ug['B$q'] && B1_NL(-0x1);
        }));var lv4z0y = n7ug['B$q'],
            _t$dx0 = 0x24e * lv4z0y;n7ug['B$q'] = n7ug['B$q'] > lv4z0y ? n7ug['B$q'] : lv4z0y, n7ug[B[520465]][B[520422]] = _t$dx0;var hsu6n7 = n7ug[B[520465]]['x'] + _t$dx0;n7ug[B[520469]]['x'] = hsu6n7 - 0xf, 0x16c <= hsu6n7 ? (n7ug[B[520467]][B[520591]] = !0x0, n7ug[B[520467]]['x'] = hsu6n7 - 0xca) : n7ug[B[520467]][B[520591]] = !0x1, n7ug[B[520472]][B[520355]] = (0x64 * lv4z0y >> 0x0) + '%', n7ug['B$q'] < 0.9999 && Laya[B[520593]][B[520620]](0x1, this, this['B1_NL']);
      } else Laya[B[520593]][B[520594]](this, this['B1_NL']);
    }, w32aei[B[520438]]['B1_LN'] = function (tx_, k9bh, b9zh6k) {
      0x1 < tx_ && (tx_ = 0x1);var pun7s = 0x24e * tx_;this['B$q'] = this['B$q'] > tx_ ? this['B$q'] : tx_, this[B[520465]][B[520422]] = pun7s;var y_x$0t = this[B[520465]]['x'] + pun7s;this[B[520469]]['x'] = y_x$0t - 0xf, 0x16c <= y_x$0t ? (this[B[520467]][B[520591]] = !0x0, this[B[520467]]['x'] = y_x$0t - 0xca) : this[B[520467]][B[520591]] = !0x1, this[B[520472]][B[520355]] = (0x64 * tx_ >> 0x0) + '%', this[B[520494]][B[520355]] = k9bh;for (var r1mf5 = b9zh6k - 0x1, q_$xtd = 0x0; q_$xtd < this['B$a'][B[520010]]; q_$xtd++) this['B$a'][q_$xtd][B[520586]] = q_$xtd < r1mf5 ? B[520480] : r1mf5 === q_$xtd ? B[520482] : B[520484];
    }, w32aei[B[520438]][B[520570]] = function () {
      this['B1_LN'](0.1, B[520622], 0x1), this['B1_NL'](-0x1), Bb67h9k[B[520577]]['B1_NL'] = this['B1_NL'][B[520232]](this), Bb67h9k[B[520577]]['B1_LN'] = this['B1_LN'][B[520232]](this), this[B[520497]][B[520355]] = B[520623] + this['B$M'][B[520020]] + B[520624] + this['B$M'][B[520151]], this[B[520409]]();
    }, w32aei[B[520438]][B[520625]] = function (vty) {
      this[B[520626]](), Laya[B[520593]][B[520594]](this, this['B1_NL']), Laya[B[520593]][B[520594]](this, this['B$e']), Bzl4kb9[B[520035]][B[520205]](), this[B[520487]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$t']);
    }, w32aei[B[520438]][B[520626]] = function () {
      Bb67h9k[B[520577]]['B1_NL'] = function () {}, Bb67h9k[B[520577]]['B1_LN'] = function () {};
    }, w32aei[B[520438]][B[520576]] = function (r83wa) {
      void 0x0 === r83wa && (r83wa = !0x0), this[B[520626]](), sh7ugn[B[520438]][B[520576]][B[520442]](this, r83wa);
    }, w32aei[B[520438]][B[520409]] = function () {
      this['B$M'][B[520409]] && 0x1 == this['B$M'][B[520409]] && (this[B[520487]][B[520591]] = !0x0, this[B[520487]][B[520627]] = !0x0, this[B[520487]][B[520586]] = B[520488], this[B[520487]]['on'](Laya[B[520571]][B[520572]], this, this['B$t']), this['B$z'](), this['B$g'](!0x0));
    }, w32aei[B[520438]]['B$t'] = function () {
      this[B[520487]][B[520627]] && (this[B[520487]][B[520627]] = !0x1, this[B[520487]][B[520586]] = B[520628], this['B$s'](), this['B$g'](!0x1));
    }, w32aei[B[520438]]['B$d'] = function (j835rf) {
      this[B[520448]][B[520586]] = j835rf[B[520629]], this[B[520451]][B[520586]] = j835rf[B[520630]], this[B[520453]][B[520586]] = j835rf[B[520631]], this[B[520455]][B[520586]] = j835rf[B[520632]], this[B[520457]][B[520586]] = j835rf[B[520633]], this[B[520460]][B[520102]] = j835rf[B[520634]], this[B[520462]]['y'] = j835rf[B[520635]], this[B[520478]]['y'] = j835rf[B[520636]], this[B[520463]][B[520586]] = j835rf[B[520637]], this[B[520494]][B[520638]] = j835rf[B[520639]], this[B[520487]][B[520591]] = this['B$M'][B[520409]] && 0x1 == this['B$M'][B[520409]], this[B[520487]][B[520591]] ? this['B$z']() : this['B$s'](), this['B$g'](this[B[520487]][B[520591]]);
    }, w32aei[B[520438]]['B$z'] = function () {
      this['B$P'] || (this['B$P'] = giune[B[520439]](this[B[520487]], B[520640], 0x4, 0x0, 0xc), this['B$P'][B[520641]](0xa1, 0x6a), this['B$P'][B[520642]](1.14, 1.15)), giune[B[520590]](this['B$P']);
    }, w32aei[B[520438]]['B$s'] = function () {
      this['B$P'] && giune[B[520592]](this['B$P']);
    }, w32aei[B[520438]]['B$g'] = function (v4y0l$) {
      Laya[B[520593]][B[520594]](this, this['B$e']), v4y0l$ ? (this['B$E'] = 0x9, this[B[520491]][B[520591]] = !0x0, this['B$e'](), Laya[B[520593]][B[520588]](0x3e8, this, this['B$e'])) : this[B[520491]][B[520591]] = !0x1;
    }, w32aei[B[520438]]['B$e'] = function () {
      0x0 < this['B$E'] ? (this[B[520491]][B[520355]] = B[520643] + this['B$E'] + 's)', this['B$E']--) : (this[B[520491]][B[520355]] = '', Laya[B[520593]][B[520594]](this, this['B$e']), this['B$t']());
    }, w32aei;
  }(Bsun7h6['B$J']), h9n7s6[B[520644]] = nh6s79;
}(modules || (modules = {})), function (ae3w2i) {
  var x$y0vt, x0$d, uenip, eig2up;x$y0vt = ae3w2i['B$p'] || (ae3w2i['B$p'] = {}), x0$d = Laya[B[520645]], uenip = Laya[B[520571]], eig2up = function (bkzl94) {
    function neg() {
      var kh6z9b = bkzl94[B[520442]](this) || this;return kh6z9b['B$o'] = 0x0, kh6z9b['B$W'] = B[520646], kh6z9b['B$N'] = 0x0, kh6z9b['B$F'] = 0x0, kh6z9b['B$R'] = B[520647], kh6z9b;
    }return Bk9lb(neg, bkzl94), neg[B[520438]][B[520566]] = function () {
      bkzl94[B[520438]][B[520566]][B[520442]](this), this[B[520567]] = 0x0, this[B[520568]] = 0x0, Bzl4kb9[B[520035]]['B12LSN_'](), this['B$M'] = Bb67h9k[B[520577]]['B1NL'], this['B$j'] = new x0$d(), this['B$j'][B[520648]] = '', this['B$j'][B[520649]] = x$y0vt[B[520650]], this['B$j'][B[520101]] = 0x5, this['B$j'][B[520651]] = 0x1, this['B$j'][B[520652]] = 0x5, this['B$j'][B[520422]] = this[B[520562]][B[520422]], this['B$j'][B[520424]] = this[B[520562]][B[520424]] - 0x8, this[B[520562]][B[520583]](this['B$j']), this['B$u'] = new x0$d(), this['B$u'][B[520648]] = '', this['B$u'][B[520649]] = x$y0vt[B[520653]], this['B$u'][B[520101]] = 0x5, this['B$u'][B[520651]] = 0x1, this['B$u'][B[520652]] = 0x5, this['B$u'][B[520422]] = this[B[520563]][B[520422]], this['B$u'][B[520424]] = this[B[520563]][B[520424]] - 0x8, this[B[520563]][B[520583]](this['B$u']), this['B$l'] = new x0$d(), this['B$l'][B[520654]] = '', this['B$l'][B[520649]] = x$y0vt[B[520655]], this['B$l'][B[520656]] = 0x1, this['B$l'][B[520422]] = this[B[520548]][B[520422]], this['B$l'][B[520424]] = this[B[520548]][B[520424]], this[B[520548]][B[520583]](this['B$l']), this['B$$'] = new x0$d(), this['B$$'][B[520654]] = '', this['B$$'][B[520649]] = x$y0vt[B[520657]], this['B$$'][B[520656]] = 0x1, this['B$$'][B[520422]] = this[B[520548]][B[520422]], this['B$$'][B[520424]] = this[B[520548]][B[520424]], this[B[520556]][B[520583]](this['B$$']);var bkvl = this['B$M'][B[520178]];this['B$x'] = 0x1 == bkvl ? B[520524] : 0x2 == bkvl ? B[520524] : 0x3 == bkvl ? B[520524] : 0x65 == bkvl ? B[520524] : B[520658], this[B[520514]][B[520659]](0x1fa, 0x58), this['B$V'] = [], this[B[520528]][B[520591]] = !0x1, this[B[520552]][B[520617]] = B[520540], this[B[520552]][B[520660]][B[520638]] = 0x1a, this[B[520552]][B[520660]][B[520661]] = 0x1c, this[B[520552]][B[520662]] = !0x1, this[B[520559]][B[520617]] = B[520540], this[B[520559]][B[520660]][B[520638]] = 0x1a, this[B[520559]][B[520660]][B[520661]] = 0x1c, this[B[520559]][B[520662]] = !0x1, this[B[520527]][B[520617]] = B[520520], this[B[520527]][B[520660]][B[520638]] = 0x12, this[B[520527]][B[520660]][B[520661]] = 0x12, this[B[520527]][B[520660]][B[520663]] = 0x2, this[B[520527]][B[520660]][B[520664]] = B[520618], this[B[520527]][B[520660]][B[520665]] = !0x1, Bb67h9k[B[520577]][B[520373]] = this, B1_NLS(), this[B[520569]](), this[B[520570]]();
    }, neg[B[520438]][B[520576]] = function (t_$qdx) {
      void 0x0 === t_$qdx && (t_$qdx = !0x0), this[B[520573]](), this['B$T'](), this['B$I'](), this['B$w'](), this['B$j'] && (this['B$j'][B[520666]](), this['B$j'][B[520576]](), this['B$j'] = null), this['B$u'] && (this['B$u'][B[520666]](), this['B$u'][B[520576]](), this['B$u'] = null), this['B$l'] && (this['B$l'][B[520666]](), this['B$l'][B[520576]](), this['B$l'] = null), this['B$$'] && (this['B$$'][B[520666]](), this['B$$'][B[520576]](), this['B$$'] = null), Laya[B[520593]][B[520594]](this, this['B$U']), bkzl94[B[520438]][B[520576]][B[520442]](this, t_$qdx);
    }, neg[B[520438]][B[520569]] = function () {
      this[B[520448]]['on'](Laya[B[520571]][B[520572]], this, this['B$Z']), this[B[520514]]['on'](Laya[B[520571]][B[520572]], this, this['B$n']), this[B[520508]]['on'](Laya[B[520571]][B[520572]], this, this['B$B']), this[B[520508]]['on'](Laya[B[520571]][B[520572]], this, this['B$B']), this[B[520564]]['on'](Laya[B[520571]][B[520572]], this, this['B$S']), this[B[520528]]['on'](Laya[B[520571]][B[520572]], this, this['B$Q']), this[B[520534]]['on'](Laya[B[520571]][B[520572]], this, this['B$b']), this[B[520538]]['on'](Laya[B[520571]][B[520667]], this, this['B$K']), this[B[520543]]['on'](Laya[B[520571]][B[520572]], this, this['B$f']), this[B[520544]]['on'](Laya[B[520571]][B[520572]], this, this['B$f']), this[B[520551]]['on'](Laya[B[520571]][B[520667]], this, this['B$OO']), this[B[520530]]['on'](Laya[B[520571]][B[520572]], this, this['B$JO']), this[B[520554]]['on'](Laya[B[520571]][B[520572]], this, this['B$DO']), this[B[520555]]['on'](Laya[B[520571]][B[520572]], this, this['B$DO']), this[B[520558]]['on'](Laya[B[520571]][B[520667]], this, this['B$pO']), this[B[520516]]['on'](Laya[B[520571]][B[520572]], this, this['B$mO']), this[B[520527]]['on'](Laya[B[520571]][B[520668]], this, this['B$CO']), this['B$l'][B[520669]] = !0x0, this['B$l'][B[520670]] = Laya[B[520671]][B[520439]](this, this['B$iO'], null, !0x1), this['B$$'][B[520669]] = !0x0, this['B$$'][B[520670]] = Laya[B[520671]][B[520439]](this, this['B$kO'], null, !0x1);
    }, neg[B[520438]][B[520573]] = function () {
      this[B[520448]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$Z']), this[B[520514]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$n']), this[B[520508]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$B']), this[B[520508]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$B']), this[B[520564]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$S']), this[B[520528]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$Q']), this[B[520534]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$b']), this[B[520538]][B[520574]](Laya[B[520571]][B[520667]], this, this['B$K']), this[B[520543]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$f']), this[B[520544]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$f']), this[B[520551]][B[520574]](Laya[B[520571]][B[520667]], this, this['B$OO']), this[B[520530]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$JO']), this[B[520554]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$DO']), this[B[520555]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$DO']), this[B[520558]][B[520574]](Laya[B[520571]][B[520667]], this, this['B$pO']), this[B[520516]][B[520574]](Laya[B[520571]][B[520572]], this, this['B$mO']), this[B[520527]][B[520574]](Laya[B[520571]][B[520668]], this, this['B$CO']), this['B$l'][B[520669]] = !0x1, this['B$l'][B[520670]] = null, this['B$$'][B[520669]] = !0x1, this['B$$'][B[520670]] = null;
    }, neg[B[520438]][B[520570]] = function () {
      var p7gusn = this;this['B$C'] = Date[B[520174]](), this['B$_O'] = this['B$M'][B[520022]][B[520023]], this['B$LO'](this['B$M'][B[520022]]), this['B$j'][B[520672]] = this['B$M'][B[520372]], this['B$B'](), req_multi_server_notice(0x4, this['B$M'][B[520163]], this['B$M'][B[520022]][B[520023]], this['B$rO'][B[520232]](this)), Laya[B[520593]][B[520673]](0x2, this, function () {
        p7gusn['B$HO'] = p7gusn['B$M'][B[520674]] && p7gusn['B$M'][B[520674]][B[520675]] ? p7gusn['B$M'][B[520674]][B[520675]] : [], p7gusn['B$YO'] = null != p7gusn['B$M'][B[520676]] ? p7gusn['B$M'][B[520676]] : 0x0;var zb946 = '1' == localStorage[B[520677]](p7gusn['B$R']),
            $xtv0y = 0x0 != B1NL[B[520678]],
            sup7gn = 0x0 == p7gusn['B$YO'] || 0x1 == p7gusn['B$YO'];p7gusn['B$GO'] = $xtv0y && zb946 || sup7gn, p7gusn['B$XO']();
      }), this[B[520497]][B[520355]] = B[520623] + this['B$M'][B[520020]] + B[520624] + this['B$M'][B[520151]], this[B[520525]][B[520617]] = this[B[520522]][B[520617]] = this['B$x'], this[B[520510]][B[520591]] = 0x1 == this['B$M'][B[520679]], this[B[520518]][B[520591]] = !0x1;
    }, neg[B[520438]][B[520680]] = function () {}, neg[B[520438]]['B$Z'] = function () {
      this['B$GO'] ? 0x2710 < Date[B[520174]]() - this['B$C'] && (this['B$C'] -= 0x7d0, Bzl4kb9[B[520035]][B[520578]]()) : this['B$cO'](B[520681]);
    }, neg[B[520438]]['B$n'] = function () {
      this['B$GO'] ? this['B$hO'](this['B$M'][B[520022]]) && (Bb67h9k[B[520577]]['B1NL'][B[520022]] = this['B$M'][B[520022]], B1L_SN(0x0, this['B$M'][B[520022]][B[520023]])) : this['B$cO'](B[520681]);
    }, neg[B[520438]]['B$B'] = function () {
      this['B$M'][B[520375]] ? this[B[520560]][B[520591]] = !0x0 : (this['B$M'][B[520375]] = !0x0, B1NL_S(0x0));
    }, neg[B[520438]]['B$S'] = function () {
      this[B[520560]][B[520591]] = !0x1;
    }, neg[B[520438]]['B$Q'] = function () {
      this['B$yO']();
    }, neg[B[520438]]['B$f'] = function () {
      this[B[520541]][B[520591]] = !0x1;
    }, neg[B[520438]]['B$b'] = function () {
      this[B[520532]][B[520591]] = !0x1;
    }, neg[B[520438]]['B$JO'] = function () {
      this['B$vO']();
    }, neg[B[520438]]['B$DO'] = function () {
      this[B[520553]][B[520591]] = !0x1;
    }, neg[B[520438]]['B$mO'] = function () {
      this['B$GO'] = !this['B$GO'], this['B$GO'] && localStorage[B[520682]](this['B$R'], '1'), this[B[520516]][B[520586]] = B[520683] + (this['B$GO'] ? B[520684] : B[520685]);
    }, neg[B[520438]]['B$CO'] = function ($tyvx0) {
      this['B$vO'](Number($tyvx0));
    }, neg[B[520438]]['B$K'] = function () {
      this['B$o'] = this[B[520538]][B[520686]], Laya[B[520687]]['on'](uenip[B[520688]], this, this['B$AO']), Laya[B[520687]]['on'](uenip[B[520689]], this, this['B$T']), Laya[B[520687]]['on'](uenip[B[520690]], this, this['B$T']);
    }, neg[B[520438]]['B$AO'] = function () {
      if (this[B[520538]]) {
        var wa2pe = this['B$o'] - this[B[520538]][B[520686]];this[B[520538]][B[520691]] += wa2pe, this['B$o'] = this[B[520538]][B[520686]];
      }
    }, neg[B[520438]]['B$T'] = function () {
      Laya[B[520687]][B[520574]](uenip[B[520688]], this, this['B$AO']), Laya[B[520687]][B[520574]](uenip[B[520689]], this, this['B$T']), Laya[B[520687]][B[520574]](uenip[B[520690]], this, this['B$T']);
    }, neg[B[520438]]['B$OO'] = function () {
      this['B$N'] = this[B[520551]][B[520686]], Laya[B[520687]]['on'](uenip[B[520688]], this, this['B$qO']), Laya[B[520687]]['on'](uenip[B[520689]], this, this['B$I']), Laya[B[520687]]['on'](uenip[B[520690]], this, this['B$I']);
    }, neg[B[520438]]['B$qO'] = function () {
      if (this[B[520552]]) {
        var g2eapi = this['B$N'] - this[B[520551]][B[520686]];this[B[520552]]['y'] -= g2eapi, this[B[520551]][B[520424]] < this[B[520552]][B[520692]] ? this[B[520552]]['y'] < this[B[520551]][B[520424]] - this[B[520552]][B[520692]] ? this[B[520552]]['y'] = this[B[520551]][B[520424]] - this[B[520552]][B[520692]] : 0x0 < this[B[520552]]['y'] && (this[B[520552]]['y'] = 0x0) : this[B[520552]]['y'] = 0x0, this['B$N'] = this[B[520551]][B[520686]];
      }
    }, neg[B[520438]]['B$I'] = function () {
      Laya[B[520687]][B[520574]](uenip[B[520688]], this, this['B$qO']), Laya[B[520687]][B[520574]](uenip[B[520689]], this, this['B$I']), Laya[B[520687]][B[520574]](uenip[B[520690]], this, this['B$I']);
    }, neg[B[520438]]['B$pO'] = function () {
      this['B$F'] = this[B[520558]][B[520686]], Laya[B[520687]]['on'](uenip[B[520688]], this, this['B$dO']), Laya[B[520687]]['on'](uenip[B[520689]], this, this['B$w']), Laya[B[520687]]['on'](uenip[B[520690]], this, this['B$w']);
    }, neg[B[520438]]['B$dO'] = function () {
      if (this[B[520559]]) {
        var _$tx0y = this['B$F'] - this[B[520558]][B[520686]];this[B[520559]]['y'] -= _$tx0y, this[B[520558]][B[520424]] < this[B[520559]][B[520692]] ? this[B[520559]]['y'] < this[B[520558]][B[520424]] - this[B[520559]][B[520692]] ? this[B[520559]]['y'] = this[B[520558]][B[520424]] - this[B[520559]][B[520692]] : 0x0 < this[B[520559]]['y'] && (this[B[520559]]['y'] = 0x0) : this[B[520559]]['y'] = 0x0, this['B$F'] = this[B[520558]][B[520686]];
      }
    }, neg[B[520438]]['B$w'] = function () {
      Laya[B[520687]][B[520574]](uenip[B[520688]], this, this['B$dO']), Laya[B[520687]][B[520574]](uenip[B[520689]], this, this['B$w']), Laya[B[520687]][B[520574]](uenip[B[520690]], this, this['B$w']);
    }, neg[B[520438]]['B$iO'] = function () {
      if (this['B$l'][B[520672]]) {
        for (var pa, lz4y0 = 0x0; lz4y0 < this['B$l'][B[520672]][B[520010]]; lz4y0++) {
          var hsgn = this['B$l'][B[520672]][lz4y0];hsgn[0x1] = lz4y0 == this['B$l'][B[520693]], lz4y0 == this['B$l'][B[520693]] && (pa = hsgn[0x0]);
        }pa && pa[B[520694]] && (pa[B[520694]] = pa[B[520694]][B[520008]](/(<)(?!(br)).[a-zA-Z]{0,10}(>)/g, '')), this[B[520549]][B[520355]] = pa && pa[B[520695]] ? pa[B[520695]] : '', this[B[520552]][B[520696]] = pa && pa[B[520694]] ? pa[B[520694]] : '', this[B[520552]]['y'] = 0x0;
      }
    }, neg[B[520438]]['B$kO'] = function () {
      if (this['B$$'][B[520672]]) {
        for (var vxt0, by4vzl = 0x0; by4vzl < this['B$$'][B[520672]][B[520010]]; by4vzl++) {
          var pesg = this['B$$'][B[520672]][by4vzl];pesg[0x1] = by4vzl == this['B$$'][B[520693]], by4vzl == this['B$$'][B[520693]] && (vxt0 = pesg[0x0]);
        }vxt0 && vxt0[B[520694]] && (vxt0[B[520694]] = vxt0[B[520694]][B[520008]](/(<)(?!(br)).[a-zA-Z]{0,10}(>)/g, '')), this[B[520557]][B[520355]] = vxt0 && vxt0[B[520695]] ? vxt0[B[520695]] : '', this[B[520559]][B[520696]] = vxt0 && vxt0[B[520694]] ? vxt0[B[520694]] : '', this[B[520559]]['y'] = 0x0;
      }
    }, neg[B[520438]]['B$LO'] = function (bkz4) {
      this[B[520525]][B[520355]] = -0x1 === bkz4[B[520289]] ? bkz4[B[520285]] + B[520697] : 0x0 === bkz4[B[520289]] ? bkz4[B[520285]] + B[520698] : bkz4[B[520285]], this[B[520525]][B[520617]] = -0x1 === bkz4[B[520289]] ? B[520699] : 0x0 === bkz4[B[520289]] ? B[520700] : this['B$x'], this[B[520512]][B[520586]] = this[B[520701]](bkz4[B[520289]]), this['B$M'][B[520021]] = bkz4[B[520021]] || '', this['B$M'][B[520022]] = bkz4, this[B[520528]][B[520591]] = !0x0;
    }, neg[B[520438]]['B$MO'] = function (i2wa3e) {
      this[B[520374]](i2wa3e);
    }, neg[B[520438]]['B$aO'] = function (_xt0y) {
      this['B$LO'](_xt0y), this[B[520560]][B[520591]] = !0x1;
    }, neg[B[520438]][B[520374]] = function (su7ngp) {
      if (void 0x0 === su7ngp && (su7ngp = 0x0), this[B[520702]]) {
        var f328 = this['B$M'][B[520372]];if (f328 && 0x0 !== f328[B[520010]]) {
          for (var lv4yzb = f328[B[520010]], $v0ytx = 0x0; $v0ytx < lv4yzb; $v0ytx++) f328[$v0ytx][B[520703]] = this['B$MO'][B[520232]](this), f328[$v0ytx][B[520704]] = $v0ytx == su7ngp, f328[$v0ytx][B[520705]] = $v0ytx;var pugein = (this['B$j'][B[520706]] = f328)[su7ngp]['id'];this['B$M'][B[520166]][pugein] ? this[B[520380]](pugein) : this['B$M'][B[520378]] || (this['B$M'][B[520378]] = !0x0, -0x1 == pugein ? B1_SN(0x0) : -0x2 == pugein ? B12SLN(0x0) : B1S_N(0x0, pugein));
        }
      }
    }, neg[B[520438]][B[520380]] = function (wai2pe) {
      if (this[B[520702]] && this['B$M'][B[520166]][wai2pe]) {
        for (var xy$0t_ = this['B$M'][B[520166]][wai2pe], ia23 = xy$0t_[B[520010]], lbzy4 = 0x0; lbzy4 < ia23; lbzy4++) xy$0t_[lbzy4][B[520703]] = this['B$aO'][B[520232]](this);this['B$u'][B[520706]] = xy$0t_;
      }
    }, neg[B[520438]]['B$hO'] = function (fr3a) {
      return -0x1 == fr3a[B[520289]] ? (alert(B[520707]), !0x1) : 0x0 != fr3a[B[520289]] || (alert(B[520708]), !0x1);
    }, neg[B[520438]][B[520701]] = function (lyz4b) {
      var l$y4v0 = '';return 0x2 === lyz4b ? l$y4v0 = B[520513] : 0x1 === lyz4b ? l$y4v0 = B[520709] : -0x1 !== lyz4b && 0x0 !== lyz4b || (l$y4v0 = B[520710]), l$y4v0;
    }, neg[B[520438]]['B$rO'] = function (rf3j58) {
      console[B[520041]](B[520711], rf3j58);var lkz9b4 = Date[B[520174]]() / 0x3e8,
          uigpn = localStorage[B[520677]](this['B$W']),
          p2eia = !(this['B$V'] = []);if (B[520270] == rf3j58[B[520198]]) for (var h6s7nu in rf3j58[B[520197]]) {
        var $td_qx = rf3j58[B[520197]][h6s7nu],
            l0$4yv = lkz9b4 < $td_qx[B[520712]],
            sgunp = 0x1 == $td_qx[B[520713]],
            s67unh = 0x2 == $td_qx[B[520713]] && $td_qx[B[520714]] + '' != uigpn;!p2eia && l0$4yv && (sgunp || s67unh) && (p2eia = !0x0), l0$4yv && this['B$V'][B[520038]]($td_qx), s67unh && localStorage[B[520682]](this['B$W'], $td_qx[B[520714]] + '');
      }this['B$V'][B[520364]](function (nus7p, b6kh9) {
        return nus7p[B[520715]] - b6kh9[B[520715]];
      }), console[B[520041]](B[520716], this['B$V']), p2eia && this['B$yO']();
    }, neg[B[520438]]['B$yO'] = function () {
      if (this['B$l']) {
        if (this['B$V']) {
          this['B$l']['x'] = 0x2 < this['B$V'][B[520010]] ? 0x0 : (this[B[520548]][B[520422]] - 0x112 * this['B$V'][B[520010]]) / 0x2;for (var kh967s = [], kz6hb9 = 0x0; kz6hb9 < this['B$V'][B[520010]]; kz6hb9++) {
            var vt0y = this['B$V'][kz6hb9];kh967s[B[520038]]([vt0y, kz6hb9 == this['B$l'][B[520693]]]);
          }0x0 < (this['B$l'][B[520672]] = kh967s)[B[520010]] ? (this['B$l'][B[520693]] = 0x0, this['B$l'][B[520717]](0x0)) : (this[B[520549]][B[520355]] = B[520537], this[B[520552]][B[520355]] = ''), this[B[520544]][B[520591]] = this['B$V'][B[520010]] <= 0x1, this[B[520548]][B[520591]] = 0x1 < this['B$V'][B[520010]];
        }this[B[520541]][B[520591]] = !0x0;
      }
    }, neg[B[520438]]['B$XO'] = function () {
      for (var nh67s = '', v4ybz = 0x0; v4ybz < this['B$HO'][B[520010]]; v4ybz++) {
        nh67s += B[520718] + v4ybz + B[520719] + this['B$HO'][v4ybz][B[520695]] + B[520720], v4ybz < this['B$HO'][B[520010]] - 0x1 && (nh67s += '、');
      }this[B[520527]][B[520696]] = B[520721] + nh67s, this[B[520516]][B[520586]] = B[520683] + (this['B$GO'] ? B[520684] : B[520685]), this[B[520527]]['x'] = (0x2d0 - this[B[520527]][B[520422]]) / 0x2, this[B[520516]]['x'] = this[B[520527]]['x'] - 0x1e, this[B[520530]][B[520591]] = 0x0 < this['B$HO'][B[520010]], this[B[520516]][B[520591]] = this[B[520527]][B[520591]] = 0x0 < this['B$HO'][B[520010]] && 0x0 != this['B$YO'];
    }, neg[B[520438]]['B$vO'] = function (tv$) {
      if (void 0x0 === tv$ && (tv$ = 0x0), this['B$$']) {
        if (this['B$HO']) {
          this['B$$']['x'] = 0x2 < this['B$HO'][B[520010]] ? 0x0 : (this[B[520548]][B[520422]] - 0x112 * this['B$HO'][B[520010]]) / 0x2;for (var mrf51 = [], rj18 = 0x0; rj18 < this['B$HO'][B[520010]]; rj18++) {
            var f3a8r = this['B$HO'][rj18];mrf51[B[520038]]([f3a8r, rj18 == this['B$$'][B[520693]]]);
          }0x0 < (this['B$$'][B[520672]] = mrf51)[B[520010]] ? (this['B$$'][B[520693]] = tv$, this['B$$'][B[520717]](tv$)) : (this[B[520557]][B[520355]] = B[520722], this[B[520559]][B[520355]] = ''), this[B[520555]][B[520591]] = this['B$HO'][B[520010]] <= 0x1, this[B[520556]][B[520591]] = 0x1 < this['B$HO'][B[520010]];
        }this[B[520553]][B[520591]] = !0x0;
      }
    }, neg[B[520438]]['B$cO'] = function (_d$) {
      this[B[520518]][B[520355]] = _d$, this[B[520518]]['y'] = 0x280, this[B[520518]][B[520591]] = !0x0, this['B$eO'] = 0x1, Laya[B[520593]][B[520594]](this, this['B$U']), this['B$U'](), Laya[B[520593]][B[520620]](0x1, this, this['B$U']);
    }, neg[B[520438]]['B$U'] = function () {
      this[B[520518]]['y'] -= this['B$eO'], this['B$eO'] *= 1.1, this[B[520518]]['y'] <= 0x24e && (this[B[520518]][B[520591]] = !0x1, Laya[B[520593]][B[520594]](this, this['B$U']));
    }, neg;
  }(Bsun7h6['B$D']), x$y0vt[B[520723]] = eig2up;
}(modules || (modules = {}));var modules,
    Bb67h9k = Laya[B[520724]],
    Bw3e2i = Laya[B[520725]],
    Bwa38fr = Laya[B[520726]],
    Bt$0_dx = Laya[B[520727]],
    Bpgu7s = Laya[B[520671]],
    Bshu67n = modules['B$p'][B[520580]],
    Bby4zvl = modules['B$p'][B[520644]],
    Benpsg = modules['B$p'][B[520723]],
    Bzl4kb9 = function () {
  function e32aw(y0tx) {
    this[B[520728]] = [B[520464], B[520616], B[520466], B[520468], B[520470], B[520484], B[520482], B[520480], B[520729], B[520730], B[520731], B[520732], B[520733], B[520606], B[520611], B[520488], B[520628], B[520608], B[520609], B[520610], B[520607], B[520613], B[520614], B[520615], B[520612]], this['B12LSN'] = [B[520535], B[520529], B[520515], B[520531], B[520734], B[520735], B[520736], B[520565], B[520513], B[520709], B[520710], B[520509], B[520449], B[520454], B[520456], B[520458], B[520452], B[520461], B[520533], B[520561], B[520737], B[520545], B[520738], B[520542], B[520511], B[520517], B[520739]], this[B[520740]] = !0x1, this[B[520741]] = !0x1, this['B$tO'] = !0x1, this['B$zO'] = '', e32aw[B[520035]] = this, Laya[B[520742]][B[520231]](), Laya3D[B[520231]](0x0, 0x0, !0x1, !0x1, !0x1), DecodeTools[B[520231]](), Laya[B[520687]][B[520743]] = Laya[B[520744]][B[520745]], Laya[B[520687]][B[520746]] = Laya[B[520744]][B[520747]], Laya[B[520687]][B[520748]] = Laya[B[520744]][B[520749]], Laya[B[520687]][B[520750]] = Laya[B[520744]][B[520751]], Laya[B[520687]][B[520752]] = Laya[B[520744]][B[520753]];var bk69h7 = Laya[B[520754]];bk69h7[B[520755]] = 0x6, bk69h7[B[520756]] = bk69h7[B[520757]] = 0x400, bk69h7[B[520758]](), Laya[B[520759]][B[520760]] = Laya[B[520759]][B[520761]] = '', Laya[B[520724]][B[520577]][B[520762]](Laya[B[520571]][B[520763]], this['B$gO'][B[520232]](this)), Laya[B[520582]][B[520764]][B[520765]] = { 'frames': { 'btn_chuangjue_kaishi.png': { 'frame': { 'h': 0x58, 'idx': 0x0, 'w': 0x1fa, 'x': 0x0, 'y': 0x0 }, 'sourceSize': { 'h': 0x58, 'w': 0x1fa }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'btn_chuangjue_nan.png': { 'frame': { 'h': 0x62, 'idx': 0x0, 'w': 0x6c, 'x': 0x14f, 'y': 0x59 }, 'sourceSize': { 'h': 0x62, 'w': 0x6c }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'btn_chuangjue_nv.png': { 'frame': { 'h': 0x62, 'idx': 0x0, 'w': 0x6b, 'x': 0x0, 'y': 0xa4 }, 'sourceSize': { 'h': 0x62, 'w': 0x6b }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'image_chuangjue_mingbg.png': { 'frame': { 'h': 0x4a, 'idx': 0x0, 'w': 0x14e, 'x': 0x0, 'y': 0x59 }, 'sourceSize': { 'h': 0x4a, 'w': 0x14e }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'image_chuangjue_suiji.png': { 'frame': { 'h': 0x38, 'idx': 0x0, 'w': 0x34, 'x': 0x1bc, 'y': 0x59 }, 'sourceSize': { 'h': 0x38, 'w': 0x34 }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'T5T528b.png': { 'frame': { 'h': 0x19, 'idx': 0x0, 'w': 0x19, 'x': 0x1bc, 'y': 0x92 }, 'sourceSize': { 'h': 0x1b, 'w': 0x1a }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x2 } }, 'T5T529b.png': { 'frame': { 'h': 0x1b, 'idx': 0x0, 'w': 0x1a, 'x': 0x1d6, 'y': 0x92 }, 'sourceSize': { 'h': 0x1b, 'w': 0x1a }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } } }, 'meta': { 'image': B[520766], 'prefix': B[520767] } }, Bb67h9k[B[520577]][B[520768]] = e32aw[B[520035]]['B12NL'], Bb67h9k[B[520577]][B[520769]] = e32aw[B[520035]]['B12NL'], this[B[520770]] = new Laya[B[520581]](), this[B[520770]][B[520771]] = B[520772], Laya[B[520687]][B[520583]](this[B[520770]]), this['B$gO']();
  }return e32aw[B[520438]]['B1_LSN'] = function (w3fa28) {
    e32aw[B[520035]][B[520770]][B[520591]] = w3fa28;
  }, e32aw[B[520438]]['B12SNL_'] = function () {
    e32aw[B[520035]][B[520773]] || (e32aw[B[520035]][B[520773]] = new Bshu67n()), e32aw[B[520035]][B[520773]][B[520702]] || e32aw[B[520035]][B[520770]][B[520583]](e32aw[B[520035]][B[520773]]), e32aw[B[520035]]['B$sO']();
  }, e32aw[B[520438]][B[520203]] = function () {
    this[B[520773]] && this[B[520773]][B[520702]] && (Laya[B[520687]][B[520774]](this[B[520773]]), this[B[520773]][B[520576]](!0x0), this[B[520773]] = null);
  }, e32aw[B[520438]]['B12LSN_'] = function () {
    this[B[520740]] || (this[B[520740]] = !0x0, Laya[B[520775]][B[520776]](this['B12LSN'], Bpgu7s[B[520439]](this, function () {
      Bb67h9k[B[520577]][B[520180]] = !0x0, Bb67h9k[B[520577]]['B1LSN_'](), Bb67h9k[B[520577]]['B1LN_S']();
    })));
  }, e32aw[B[520438]][B[520293]] = function () {
    for (var eawpi2 = function () {
      e32aw[B[520035]][B[520777]] || (e32aw[B[520035]][B[520777]] = new Benpsg()), e32aw[B[520035]][B[520777]][B[520702]] || e32aw[B[520035]][B[520770]][B[520583]](e32aw[B[520035]][B[520777]]), e32aw[B[520035]]['B$sO']();
    }, eaiw = !0x0, ginpu = 0x0, ks7h6 = this['B12LSN']; ginpu < ks7h6[B[520010]]; ginpu++) {
      var _$xy0 = ks7h6[ginpu];if (null == Laya[B[520582]][B[520596]](_$xy0)) {
        eaiw = !0x1;break;
      }
    }eaiw ? eawpi2() : Laya[B[520775]][B[520776]](this['B12LSN'], Bpgu7s[B[520439]](this, eawpi2));
  }, e32aw[B[520438]][B[520204]] = function () {
    this[B[520777]] && this[B[520777]][B[520702]] && (Laya[B[520687]][B[520774]](this[B[520777]]), this[B[520777]][B[520576]](!0x0), this[B[520777]] = null);
  }, e32aw[B[520438]][B[520575]] = function () {
    this[B[520741]] || (this[B[520741]] = !0x0, Laya[B[520775]][B[520776]](this[B[520728]], Bpgu7s[B[520439]](this, function () {
      Bb67h9k[B[520577]][B[520181]] = !0x0, Bb67h9k[B[520577]]['B1LSN_'](), Bb67h9k[B[520577]]['B1LN_S']();
    })));
  }, e32aw[B[520438]][B[520292]] = function (h76kb) {
    void 0x0 === h76kb && (h76kb = 0x0), Laya[B[520775]][B[520776]](this[B[520728]], Bpgu7s[B[520439]](this, function () {
      e32aw[B[520035]][B[520778]] || (e32aw[B[520035]][B[520778]] = new Bby4zvl(h76kb)), e32aw[B[520035]][B[520778]][B[520702]] || e32aw[B[520035]][B[520770]][B[520583]](e32aw[B[520035]][B[520778]]), e32aw[B[520035]]['B$sO']();
    }));
  }, e32aw[B[520438]][B[520205]] = function () {
    this[B[520778]] && this[B[520778]][B[520702]] && (Laya[B[520687]][B[520774]](this[B[520778]]), this[B[520778]][B[520576]](!0x0), this[B[520778]] = null);for (var xty_ = 0x0, k9z4l = this['B12LSN']; xty_ < k9z4l[B[520010]]; xty_++) {
      var frj18 = k9z4l[xty_];Laya[B[520582]][B[520779]](e32aw[B[520035]], frj18), Laya[B[520582]][B[520780]](frj18, !0x0);
    }for (var u2peg = 0x0, _dt$x = this[B[520728]]; u2peg < _dt$x[B[520010]]; u2peg++) {
      frj18 = _dt$x[u2peg], (Laya[B[520582]][B[520779]](e32aw[B[520035]], frj18), Laya[B[520582]][B[520780]](frj18, !0x0));
    }this[B[520770]][B[520702]] && this[B[520770]][B[520702]][B[520774]](this[B[520770]]);
  }, e32aw[B[520438]]['B12LN'] = function () {
    this[B[520778]] && this[B[520778]][B[520702]] && e32aw[B[520035]][B[520778]][B[520409]]();
  }, e32aw[B[520438]][B[520578]] = function () {
    var p2aeig = Bb67h9k[B[520577]]['B1NL'][B[520022]];this['B$tO'] || -0x1 == p2aeig[B[520289]] || 0x0 == p2aeig[B[520289]] || (this['B$tO'] = !0x0, Bb67h9k[B[520577]]['B1NL'][B[520022]] = p2aeig, B1L_SN(0x0, p2aeig[B[520023]]));
  }, e32aw[B[520438]][B[520579]] = function () {
    var td$_x0 = '';td$_x0 += B[520781] + Bb67h9k[B[520577]]['B1NL'][B[520283]], td$_x0 += B[520782] + this[B[520740]], td$_x0 += B[520783] + (null != e32aw[B[520035]][B[520777]]), td$_x0 += B[520784] + this[B[520741]], td$_x0 += B[520785] + (null != e32aw[B[520035]][B[520778]]), td$_x0 += B[520786] + (Bb67h9k[B[520577]][B[520768]] == e32aw[B[520035]]['B12NL']), td$_x0 += B[520787] + (Bb67h9k[B[520577]][B[520769]] == e32aw[B[520035]]['B12NL']), td$_x0 += B[520788] + e32aw[B[520035]]['B$zO'];for (var z6k4 = 0x0, iew2ap = this['B12LSN']; z6k4 < iew2ap[B[520010]]; z6k4++) {
      td$_x0 += ',\x20' + (w82fa3 = iew2ap[z6k4]) + '=' + (null != Laya[B[520582]][B[520596]](w82fa3));
    }for (var ipgeun = 0x0, epiug = this[B[520728]]; ipgeun < epiug[B[520010]]; ipgeun++) {
      var w82fa3;td$_x0 += ',\x20' + (w82fa3 = epiug[ipgeun]) + '=' + (null != Laya[B[520582]][B[520596]](w82fa3));
    }var tx0$yv = Bb67h9k[B[520577]]['B1NL'][B[520022]];tx0$yv && (td$_x0 += B[520789] + tx0$yv[B[520289]], td$_x0 += B[520790] + tx0$yv[B[520023]], td$_x0 += B[520791] + tx0$yv[B[520285]]);var x$0y = JSON[B[520026]]({ 'error': B[520792], 'stack': td$_x0 });console[B[520027]](x$0y), this['B$PO'] && this['B$PO'] == td$_x0 || (this['B$PO'] = td$_x0, B1N_L(x$0y));
  }, e32aw[B[520438]]['B$EO'] = function () {
    var l0vy$4 = Laya[B[520687]],
        $v0x = Math[B[520361]](l0vy$4[B[520422]]),
        z9b4k6 = Math[B[520361]](l0vy$4[B[520424]]);z9b4k6 / $v0x < 1.7777778 ? (this[B[520793]] = Math[B[520361]]($v0x / (z9b4k6 / 0x500)), this[B[520794]] = 0x500, this[B[520795]] = z9b4k6 / 0x500) : (this[B[520793]] = 0x2d0, this[B[520794]] = Math[B[520361]](z9b4k6 / ($v0x / 0x2d0)), this[B[520795]] = $v0x / 0x2d0);var sn9h76 = Math[B[520361]](l0vy$4[B[520422]]),
        t_$ = Math[B[520361]](l0vy$4[B[520424]]);t_$ / sn9h76 < 1.7777778 ? (this[B[520793]] = Math[B[520361]](sn9h76 / (t_$ / 0x500)), this[B[520794]] = 0x500, this[B[520795]] = t_$ / 0x500) : (this[B[520793]] = 0x2d0, this[B[520794]] = Math[B[520361]](t_$ / (sn9h76 / 0x2d0)), this[B[520795]] = sn9h76 / 0x2d0), this['B$sO']();
  }, e32aw[B[520438]]['B$sO'] = function () {
    this[B[520770]] && (this[B[520770]][B[520659]](this[B[520793]], this[B[520794]]), this[B[520770]][B[520642]](this[B[520795]], this[B[520795]], !0x0));
  }, e32aw[B[520438]]['B$gO'] = function () {
    if (Bwa38fr[B[520796]] && Bb67h9k[B[520797]]) {
      var w3a82 = parseInt(Bwa38fr[B[520798]][B[520660]][B[520101]][B[520008]]('px', '')),
          aw3f2 = parseInt(Bwa38fr[B[520799]][B[520660]][B[520424]][B[520008]]('px', '')) * this[B[520795]],
          gu2ep = Bb67h9k[B[520800]] / Bt$0_dx[B[520801]][B[520422]];return 0x0 < (w3a82 = Bb67h9k[B[520802]] - aw3f2 * gu2ep - w3a82) && (w3a82 = 0x0), void (Bb67h9k[B[520803]][B[520660]][B[520101]] = w3a82 + 'px');
    }Bb67h9k[B[520803]][B[520660]][B[520101]] = B[520804];var upgie2 = Math[B[520361]](Bb67h9k[B[520422]]),
        hn796 = Math[B[520361]](Bb67h9k[B[520424]]);upgie2 = upgie2 + 0x1 & 0x7ffffffe, hn796 = hn796 + 0x1 & 0x7ffffffe;var _tx$ = Laya[B[520687]];0x3 == ENV ? (_tx$[B[520743]] = Laya[B[520744]][B[520805]], _tx$[B[520422]] = upgie2, _tx$[B[520424]] = hn796) : hn796 < upgie2 ? (_tx$[B[520743]] = Laya[B[520744]][B[520805]], _tx$[B[520422]] = upgie2, _tx$[B[520424]] = hn796) : (_tx$[B[520743]] = Laya[B[520744]][B[520745]], _tx$[B[520422]] = 0x348, _tx$[B[520424]] = Math[B[520361]](hn796 / (upgie2 / 0x348)) + 0x1 & 0x7ffffffe), this['B$EO']();
  }, e32aw[B[520438]]['B12NL'] = function ($dtx_0, j1r8f5) {
    function piugne() {
      wia2p[B[520806]] = null, wia2p[B[520807]] = null;
    }var wia2p,
        qxtd$_ = $dtx_0;(wia2p = new Bb67h9k[B[520577]][B[520447]]())[B[520806]] = function () {
      piugne(), j1r8f5(qxtd$_, 0xc8, wia2p);
    }, wia2p[B[520807]] = function () {
      console[B[520213]](B[520808], qxtd$_), e32aw[B[520035]]['B$zO'] += qxtd$_ + '|', piugne(), j1r8f5(qxtd$_, 0x194, null);
    }, wia2p[B[520809]] = qxtd$_, -0x1 == e32aw[B[520035]]['B12LSN'][B[520107]](qxtd$_) && -0x1 == e32aw[B[520035]][B[520728]][B[520107]](qxtd$_) || Laya[B[520582]][B[520810]](e32aw[B[520035]], qxtd$_);
  }, e32aw[B[520438]]['B$oO'] = function (f35jr8, xv$yt) {
    return -0x1 != f35jr8[B[520107]](xv$yt, f35jr8[B[520010]] - xv$yt[B[520010]]);
  }, e32aw;
}();!function (h9n6) {
  var w8ar, f53r8w;w8ar = h9n6['B$p'] || (h9n6['B$p'] = {}), f53r8w = function (vbkz4l) {
    function h9bk7() {
      var w2e3a = vbkz4l[B[520442]](this) || this;return w2e3a['B$WO'] = B[520811], w2e3a['B$NO'] = B[520812], w2e3a[B[520422]] = 0x112, w2e3a[B[520424]] = 0x3b, w2e3a['B$FO'] = new Laya[B[520447]](), w2e3a[B[520583]](w2e3a['B$FO']), w2e3a['B$RO'] = new Laya[B[520471]](), w2e3a['B$RO'][B[520638]] = 0x1e, w2e3a['B$RO'][B[520617]] = w2e3a['B$NO'], w2e3a[B[520583]](w2e3a['B$RO']), w2e3a['B$RO'][B[520567]] = 0x0, w2e3a['B$RO'][B[520568]] = 0x0, w2e3a;
    }return Bk9lb(h9bk7, vbkz4l), h9bk7[B[520438]][B[520566]] = function () {
      vbkz4l[B[520438]][B[520566]][B[520442]](this), this['B$M'] = Bb67h9k[B[520577]]['B1NL'], this['B$M'][B[520178]], this[B[520569]]();
    }, Object[B[520599]](h9bk7[B[520438]], B[520672], { 'set': function (npeus) {
        npeus && this[B[520813]](npeus);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), h9bk7[B[520438]][B[520813]] = function (klb4v) {
      this['B$jO'] = klb4v[0x0], this['B$uO'] = klb4v[0x1], this['B$RO'][B[520355]] = this['B$jO'][B[520695]], this['B$RO'][B[520617]] = this['B$uO'] ? this['B$WO'] : this['B$NO'], this['B$FO'][B[520586]] = this['B$uO'] ? B[520545] : B[520737];
    }, h9bk7[B[520438]][B[520576]] = function (kbz) {
      void 0x0 === kbz && (kbz = !0x0), this[B[520573]](), vbkz4l[B[520438]][B[520576]][B[520442]](this, kbz);
    }, h9bk7[B[520438]][B[520569]] = function () {}, h9bk7[B[520438]][B[520573]] = function () {}, h9bk7;
  }(Laya[B[520440]]), w8ar[B[520655]] = f53r8w;
}(modules || (modules = {})), function (dxtq) {
  var l0y, zk96hb;l0y = dxtq['B$p'] || (dxtq['B$p'] = {}), zk96hb = function (l4y$0v) {
    function u7psn() {
      var psgenu = l4y$0v[B[520442]](this) || this;return psgenu['B$WO'] = B[520811], psgenu['B$NO'] = B[520812], psgenu[B[520422]] = 0x112, psgenu[B[520424]] = 0x3b, psgenu['B$FO'] = new Laya[B[520447]](), psgenu[B[520583]](psgenu['B$FO']), psgenu['B$RO'] = new Laya[B[520471]](), psgenu['B$RO'][B[520638]] = 0x1e, psgenu['B$RO'][B[520617]] = psgenu['B$NO'], psgenu[B[520583]](psgenu['B$RO']), psgenu['B$RO'][B[520567]] = 0x0, psgenu['B$RO'][B[520568]] = 0x0, psgenu;
    }return Bk9lb(u7psn, l4y$0v), u7psn[B[520438]][B[520566]] = function () {
      l4y$0v[B[520438]][B[520566]][B[520442]](this), this['B$M'] = Bb67h9k[B[520577]]['B1NL'], this['B$M'][B[520178]], this[B[520569]]();
    }, Object[B[520599]](u7psn[B[520438]], B[520672], { 'set': function (qdx_t) {
        qdx_t && this[B[520813]](qdx_t);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), u7psn[B[520438]][B[520813]] = function (k964zb) {
      this['B$jO'] = k964zb[0x0], this['B$uO'] = k964zb[0x1], this['B$RO'][B[520355]] = this['B$jO'][B[520695]], this['B$RO'][B[520617]] = this['B$uO'] ? this['B$WO'] : this['B$NO'], this['B$FO'][B[520586]] = this['B$uO'] ? B[520545] : B[520737];
    }, u7psn[B[520438]][B[520576]] = function (pewa2) {
      void 0x0 === pewa2 && (pewa2 = !0x0), this[B[520573]](), l4y$0v[B[520438]][B[520576]][B[520442]](this, pewa2);
    }, u7psn[B[520438]][B[520569]] = function () {}, u7psn[B[520438]][B[520573]] = function () {}, u7psn;
  }(Laya[B[520440]]), l0y[B[520657]] = zk96hb;
}(modules || (modules = {})), function (upgie) {
  var nu7sgp, kh679;nu7sgp = upgie['B$p'] || (upgie['B$p'] = {}), kh679 = function (k7bh) {
    function g2() {
      var v4y0$l = k7bh[B[520442]](this) || this;return v4y0$l[B[520422]] = 0xc0, v4y0$l[B[520424]] = 0x46, v4y0$l['B$FO'] = new Laya[B[520447]](), v4y0$l[B[520583]](v4y0$l['B$FO']), v4y0$l['B$RO'] = new Laya[B[520471]](), v4y0$l['B$RO'][B[520638]] = 0x1e, v4y0$l['B$RO'][B[520617]] = v4y0$l['B$x'], v4y0$l[B[520583]](v4y0$l['B$RO']), v4y0$l['B$RO'][B[520567]] = 0x0, v4y0$l['B$RO'][B[520568]] = 0x0, v4y0$l;
    }return Bk9lb(g2, k7bh), g2[B[520438]][B[520566]] = function () {
      k7bh[B[520438]][B[520566]][B[520442]](this), this['B$M'] = Bb67h9k[B[520577]]['B1NL'];var wrfa38 = this['B$M'][B[520178]];this['B$x'] = 0x1 == wrfa38 ? B[520812] : 0x2 == wrfa38 ? B[520812] : 0x3 == wrfa38 ? B[520814] : B[520812], this[B[520569]]();
    }, Object[B[520599]](g2[B[520438]], B[520672], { 'set': function (x_td0) {
        x_td0 && this[B[520813]](x_td0);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), g2[B[520438]][B[520813]] = function (vly0$) {
      this['B$jO'] = vly0$, this['B$RO'][B[520355]] = vly0$[B[520771]], this['B$FO'][B[520586]] = vly0$[B[520704]] ? B[520734] : B[520735];
    }, g2[B[520438]][B[520576]] = function (dt_x0) {
      void 0x0 === dt_x0 && (dt_x0 = !0x0), this[B[520573]](), k7bh[B[520438]][B[520576]][B[520442]](this, dt_x0);
    }, g2[B[520438]][B[520569]] = function () {
      this['on'](Laya[B[520571]][B[520689]], this, this[B[520815]]);
    }, g2[B[520438]][B[520573]] = function () {
      this[B[520574]](Laya[B[520571]][B[520689]], this, this[B[520815]]);
    }, g2[B[520438]][B[520815]] = function () {
      this['B$jO'] && this['B$jO'][B[520703]] && this['B$jO'][B[520703]](this['B$jO'][B[520705]]);
    }, g2;
  }(Laya[B[520440]]), nu7sgp[B[520650]] = kh679;
}(modules || (modules = {})), function (weap2) {
  var xqt$_, r8wf35;xqt$_ = weap2['B$p'] || (weap2['B$p'] = {}), r8wf35 = function (rjo1m) {
    function wi82a3() {
      var ig2ue = rjo1m[B[520442]](this) || this;return ig2ue['B$FO'] = new Laya[B[520447]](B[520736]), ig2ue['B$RO'] = new Laya[B[520471]](), ig2ue['B$RO'][B[520638]] = 0x1e, ig2ue['B$RO'][B[520617]] = ig2ue['B$x'], ig2ue[B[520583]](ig2ue['B$FO']), ig2ue['B$lO'] = new Laya[B[520447]](), ig2ue[B[520583]](ig2ue['B$lO']), ig2ue[B[520422]] = 0x166, ig2ue[B[520424]] = 0x46, ig2ue[B[520583]](ig2ue['B$RO']), ig2ue['B$lO'][B[520568]] = 0x0, ig2ue['B$lO']['x'] = 0x12, ig2ue['B$RO']['x'] = 0x50, ig2ue['B$RO'][B[520568]] = 0x0, ig2ue['B$FO'][B[520816]][B[520817]](0x0, 0x0, ig2ue[B[520422]], ig2ue[B[520424]], B[520818]), ig2ue;
    }return Bk9lb(wi82a3, rjo1m), wi82a3[B[520438]][B[520566]] = function () {
      rjo1m[B[520438]][B[520566]][B[520442]](this), this['B$M'] = Bb67h9k[B[520577]]['B1NL'];var o5rmj1 = this['B$M'][B[520178]];this['B$x'] = 0x1 == o5rmj1 ? B[520819] : 0x2 == o5rmj1 ? B[520819] : 0x3 == o5rmj1 ? B[520814] : B[520819], this[B[520569]]();
    }, Object[B[520599]](wi82a3[B[520438]], B[520672], { 'set': function (yl$40) {
        yl$40 && this[B[520813]](yl$40);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), wi82a3[B[520438]][B[520813]] = function (spng) {
      this['B$jO'] = spng, this['B$RO'][B[520617]] = -0x1 === spng[B[520289]] ? B[520699] : 0x0 === spng[B[520289]] ? B[520700] : this['B$x'], this['B$RO'][B[520355]] = -0x1 === spng[B[520289]] ? spng[B[520285]] + B[520697] : 0x0 === spng[B[520289]] ? spng[B[520285]] + B[520698] : spng[B[520285]], this['B$lO'][B[520586]] = this[B[520701]](spng[B[520289]]);
    }, wi82a3[B[520438]][B[520576]] = function ($_tx) {
      void 0x0 === $_tx && ($_tx = !0x0), this[B[520573]](), rjo1m[B[520438]][B[520576]][B[520442]](this, $_tx);
    }, wi82a3[B[520438]][B[520569]] = function () {
      this['on'](Laya[B[520571]][B[520689]], this, this[B[520815]]);
    }, wi82a3[B[520438]][B[520573]] = function () {
      this[B[520574]](Laya[B[520571]][B[520689]], this, this[B[520815]]);
    }, wi82a3[B[520438]][B[520815]] = function () {
      this['B$jO'] && this['B$jO'][B[520703]] && this['B$jO'][B[520703]](this['B$jO']);
    }, wi82a3[B[520438]][B[520701]] = function (bz4vk) {
      var wfr35 = '';return 0x2 === bz4vk ? wfr35 = B[520513] : 0x1 === bz4vk ? wfr35 = B[520709] : -0x1 !== bz4vk && 0x0 !== bz4vk || (wfr35 = B[520710]), wfr35;
    }, wi82a3;
  }(Laya[B[520440]]), xqt$_[B[520653]] = r8wf35;
}(modules || (modules = {})), window[B[520034]] = Bzl4kb9;