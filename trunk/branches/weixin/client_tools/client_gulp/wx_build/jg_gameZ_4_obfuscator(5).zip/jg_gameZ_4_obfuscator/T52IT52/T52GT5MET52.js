var B = wx.$B;
console[B[520001]](B[520002]), window[B[520003]], wx[B[520004]](function (gnhsu) {
  if (gnhsu) {
    if (gnhsu[B[520005]]) {
      var bzkvl = window[B[520006]][B[520007]][B[520008]](new RegExp(/\./, 'g'), '_'),
          nh69s = gnhsu[B[520005]],
          pnsuge = nh69s[B[520009]](/(T5T5T5T5T5\/T52GT5MET52.js:)[0-9]{1,60}(:)/g);if (pnsuge) for (var piewa2 = 0x0; piewa2 < pnsuge[B[520010]]; piewa2++) {
        if (pnsuge[piewa2] && pnsuge[piewa2][B[520010]] > 0x0) {
          var gipu2 = parseInt(pnsuge[piewa2][B[520008]](B[520011], '')[B[520008]](':', ''));nh69s = nh69s[B[520008]](pnsuge[piewa2], pnsuge[piewa2][B[520008]](':' + gipu2 + ':', ':' + (gipu2 - 0x2) + ':'));
        }
      }nh69s = nh69s[B[520008]](new RegExp(B[520012], 'g'), B[520013] + bzkvl + B[520014]), nh69s = nh69s[B[520008]](new RegExp(B[520015], 'g'), B[520013] + bzkvl + B[520014]), gnhsu[B[520005]] = nh69s;
    }var vzly4b = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'user': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'gamever': window[B[520006]][B[520007]], 'cdn': window['B1NL'][B[520021]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': B[520025], 'stack': gnhsu ? gnhsu[B[520005]] : '' },
        rj1 = JSON[B[520026]](vzly4b);console[B[520027]](B[520028] + rj1), (!window[B[520003]] || window[B[520003]] != vzly4b[B[520027]]) && (window[B[520003]] = vzly4b[B[520027]], window['B1_N'](vzly4b));
  }
});import 'T5T5bfT5T5.js';import 'T5T511T5T5.js';window[B[520029]] = require(B[520030]);import 'T5INDT5T5.js';import 'T5T5IT51T5T5.js';import 'T5T5MtadT5T5.js';import 'T5T5INIT5aT5.js';console[B[520001]](B[520031]), console[B[520001]](B[520032]), B1_NSL({ 'title': B[520033] });var B$_0xyt = { 'B12_LNS': !![] };new window[B[520034]](B$_0xyt), window[B[520034]][B[520035]]['B12SNL_']();if (window['B12_NLS']) clearInterval(window['B12_NLS']);window['B12_NLS'] = null, window['B12SL_N'] = function (ngseu, r8wf3) {
  if (!ngseu || !r8wf3) return 0x0;ngseu = ngseu[B[520036]]('.'), r8wf3 = r8wf3[B[520036]]('.');const gipa2e = Math[B[520037]](ngseu[B[520010]], r8wf3[B[520010]]);while (ngseu[B[520010]] < gipa2e) {
    ngseu[B[520038]]('0');
  }while (r8wf3[B[520010]] < gipa2e) {
    r8wf3[B[520038]]('0');
  }for (var snhgu7 = 0x0; snhgu7 < gipa2e; snhgu7++) {
    const vb4kzl = parseInt(ngseu[snhgu7]),
          zlvkb4 = parseInt(r8wf3[snhgu7]);if (vb4kzl > zlvkb4) return 0x1;else {
      if (vb4kzl < zlvkb4) return -0x1;
    }
  }return 0x0;
}, window[B[520039]] = wx[B[520040]]()[B[520039]], console[B[520041]](B[520042] + window[B[520039]]);var B_0$ytx = wx[B[520043]]();B_0$ytx[B[520044]](function (inupg) {
  console[B[520041]](B[520045] + inupg[B[520046]]);
}), B_0$ytx[B[520047]](function () {
  wx[B[520048]]({ 'title': B[520049], 'content': B[520050], 'showCancel': ![], 'success': function (n6s97h) {
      B_0$ytx[B[520051]]();
    } });
}), B_0$ytx[B[520052]](function () {
  console[B[520041]](B[520053]);
}), window['B12SLN_'] = function () {
  console[B[520041]](B[520054]);var nh67su = wx[B[520055]]({ 'name': B[520056], 'success': function (h97ns6) {
      console[B[520041]](B[520057]), console[B[520041]](h97ns6), h97ns6 && h97ns6[B[520058]] == B[520059] ? (window['B1LS'] = !![], window['B1LSN_'](), window['B1LN_S']()) : setTimeout(function () {
        window['B12SLN_']();
      }, 0x1f4);
    }, 'fail': function (aiwpe) {
      console[B[520041]](B[520060]), console[B[520041]](aiwpe), setTimeout(function () {
        window['B12SLN_']();
      }, 0x1f4);
    } });nh67su && nh67su[B[520061]](kbl94 => {});
}, window['B12N_LS'] = function () {
  console[B[520041]](B[520062]);var dtqx = wx[B[520055]]({ 'name': B[520063], 'success': function (wf8r53) {
      console[B[520041]](B[520064]), console[B[520041]](wf8r53), wf8r53 && wf8r53[B[520058]] == B[520059] ? (window['B1NSL'] = !![], window['B1LSN_'](), window['B1LN_S']()) : setTimeout(function () {
        window['B12N_LS']();
      }, 0x1f4);
    }, 'fail': function (ia2w3) {
      console[B[520041]](B[520065]), console[B[520041]](ia2w3), setTimeout(function () {
        window['B12N_LS']();
      }, 0x1f4);
    } });dtqx && dtqx[B[520061]](pw2eia => {});
}, window[B[520066]] = function () {
  window['B12SL_N'](window[B[520039]], B[520067]) >= 0x0 ? (console[B[520041]](B[520068] + window[B[520039]] + B[520069]), window['B1N_'](), window['B12SLN_'](), window['B12N_LS']()) : (window['B1NL_'](B[520070], window[B[520039]]), wx[B[520048]]({ 'title': B[520071], 'content': B[520072] }));
}, window[B[520024]] = '', wx[B[520073]]({ 'success'(j1ro) {
    window[B[520024]] = B[520074] + j1ro[B[520075]] + B[520076] + j1ro[B[520077]] + B[520078] + j1ro[B[520079]] + B[520080] + j1ro[B[520081]] + B[520082] + j1ro[B[520083]] + B[520084] + j1ro[B[520039]] + B[520085] + j1ro[B[520086]], console[B[520041]](window[B[520024]]), console[B[520041]](B[520087] + j1ro[B[520088]] + B[520089] + j1ro[B[520090]] + B[520091] + j1ro[B[520092]] + B[520093] + j1ro[B[520094]] + B[520095] + j1ro[B[520096]] + B[520097] + j1ro[B[520098]] + B[520099] + (j1ro[B[520100]] ? j1ro[B[520100]][B[520101]] + ',' + j1ro[B[520100]][B[520102]] + ',' + j1ro[B[520100]][B[520103]] + ',' + j1ro[B[520100]][B[520104]] : ''));var peuig = j1ro[B[520081]] ? j1ro[B[520081]][B[520105]]() : '',
        ghsn7u = j1ro[B[520077]] ? j1ro[B[520077]][B[520105]]()[B[520008]]('\x20', '') : '';window['B1NL'][B[520106]] = peuig[B[520107]](B[520108]) != -0x1, window['B1NL'][B[520109]] = peuig[B[520107]](B[520110]) != -0x1, window['B1NL'][B[520111]] = peuig[B[520107]](B[520108]) != -0x1 || peuig[B[520107]](B[520110]) != -0x1, window['B1NL'][B[520112]] = peuig[B[520107]](B[520113]) != -0x1 || peuig[B[520107]](B[520114]) != -0x1, window['B1NL'][B[520115]] = j1ro[B[520083]] ? j1ro[B[520083]][B[520105]]() : '', window['B1NL']['B12_SLN'] = ![], window['B1NL']['B12_NSL'] = 0x2;if (peuig[B[520107]](B[520110]) != -0x1) {
      if (j1ro[B[520086]] >= 0x18) window['B1NL']['B12_NSL'] = 0x3;else window['B1NL']['B12_NSL'] = 0x2;
    } else {
      if (peuig[B[520107]](B[520108]) != -0x1) {
        if (j1ro[B[520086]] && j1ro[B[520086]] >= 0x14) window['B1NL']['B12_NSL'] = 0x3;else {
          if (ghsn7u[B[520107]](B[520116]) != -0x1 || ghsn7u[B[520107]](B[520117]) != -0x1 || ghsn7u[B[520107]](B[520118]) != -0x1 || ghsn7u[B[520107]](B[520119]) != -0x1 || ghsn7u[B[520107]](B[520120]) != -0x1) window['B1NL']['B12_NSL'] = 0x2;else window['B1NL']['B12_NSL'] = 0x3;
        }
      } else window['B1NL']['B12_NSL'] = 0x2;
    }console[B[520041]](B[520121] + window['B1NL']['B12_SLN'] + B[520122] + window['B1NL']['B12_NSL']);
  } }), wx[B[520123]]({ 'success': function (hg7un) {
    console[B[520041]](B[520124] + hg7un[B[520125]] + B[520126] + hg7un[B[520127]]);
  } }), wx[B[520128]]({ 'success': function (hb967) {
    console[B[520041]](B[520129] + hb967[B[520130]]);
  } }), wx[B[520131]]({ 'keepScreenOn': !![] }), wx[B[520132]](function (yvl$0) {
  console[B[520041]](B[520129] + yvl$0[B[520130]] + B[520133] + yvl$0[B[520134]]);
}), wx[B[520135]](function (_dxq$) {
  window['B1S_'] = _dxq$, window['B1L_S'] && window['B1S_'] && (console[B[520001]](B[520136] + window['B1S_'][B[520137]]), window['B1L_S'](window['B1S_']), window['B1S_'] = null);
}), window['B12NSL_'] = 0x0, window[B[520138]] = null, wx[B[520139]](function () {
  window['B12NSL_']++, wx[B[520140]]();if (window['B12NSL_'] >= 0x2) {
    window['B12NSL_'] = 0x0, console[B[520027]](B[520141]), wx[B[520142]]('0', 0x1);if (window['B1NL'] && window['B1NL'][B[520106]]) window['B1NL_'](B[520143], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});