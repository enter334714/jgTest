var B = wx.$B;
import Bv0$tl from '../T5T5basdT5/T55sdkT5.js';window[B[520144]] = { 'wxVersion': window[B[520006]][B[520007]] }, window[B[520145]] = ![], window['B1LN'] = 0x1, window[B[520146]] = 0x1, window['B1SNL'] = !![], window[B[520147]] = !![], window['B12_SNL'] = '', window['B1NL'] = { 'base_cdn': B[520148], 'cdn': B[520148] }, B1NL[B[520149]] = {}, B1NL[B[520150]] = '0', B1NL[B[520079]] = window[B[520144]][B[520151]], B1NL[B[520114]] = '', B1NL['os'] = '1', B1NL[B[520152]] = B[520153], B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520160]] = B[520161], B1NL[B[520162]] = '1', B1NL[B[520163]] = '', B1NL[B[520164]] = '', B1NL[B[520165]] = 0x0, B1NL[B[520166]] = {}, B1NL[B[520167]] = parseInt(B1NL[B[520162]]), B1NL[B[520168]] = B1NL[B[520162]], B1NL[B[520022]] = {}, B1NL['B1_N'] = B[520169], B1NL[B[520170]] = ![], B1NL[B[520171]] = B[520172], B1NL[B[520173]] = Date[B[520174]](), B1NL[B[520175]] = B[520176], B1NL[B[520177]] = '_a', B1NL[B[520178]] = 0x2, B1NL[B[520020]] = 0x7c1, B1NL[B[520151]] = window[B[520144]][B[520151]], B1NL[B[520179]] = ![], B1NL[B[520106]] = ![], B1NL[B[520109]] = ![], B1NL[B[520112]] = ![], window['B1SLN'] = 0x5, window['B1SL'] = ![], window['B1LS'] = ![], window['B1NSL'] = ![], window[B[520180]] = ![], window[B[520181]] = ![], window['B1NLS'] = ![], window['B1SN'] = ![], window['B1NS'] = ![], window['B1LSN'] = ![], window[B[520182]] = function (k9zlb) {
  console[B[520041]](B[520182], k9zlb), wx[B[520183]]({}), wx[B[520048]]({ 'title': B[520071], 'content': k9zlb, 'success'(yv$) {
      if (yv$[B[520184]]) console[B[520041]](B[520185]);else yv$[B[520186]] && console[B[520041]](B[520187]);
    } });
}, window['B1_SNL'] = function (bk46) {
  console[B[520041]](B[520188], bk46), B1_NLS(), wx[B[520048]]({ 'title': B[520071], 'content': bk46, 'confirmText': B[520189], 'cancelText': B[520190], 'success'(f8aw2) {
      if (f8aw2[B[520184]]) window['B1N_']();else f8aw2[B[520186]] && (console[B[520041]](B[520191]), wx[B[520192]]({}));
    } });
}, window[B[520193]] = function (eip2ug) {
  console[B[520041]](B[520193], eip2ug), wx[B[520048]]({ 'title': B[520071], 'content': eip2ug, 'confirmText': B[520194], 'showCancel': ![], 'complete'(v0$x) {
      console[B[520041]](B[520191]), wx[B[520192]]({});
    } });
}, window['B1_SLN'] = ![], window['B1_NSL'] = function (ylzv04) {
  window['B1_SLN'] = !![], wx[B[520195]](ylzv04);
}, window['B1_NLS'] = function () {
  window['B1_SLN'] && (window['B1_SLN'] = ![], wx[B[520183]]({}));
}, window['B1_LSN'] = function (pag2i) {
  window[B[520034]][B[520035]]['B1_LSN'](pag2i);
}, window[B[520196]] = function (mrjo5, ly0v$) {
  Bv0$tl[B[520196]](mrjo5, function (j1f58) {
    j1f58 && j1f58[B[520197]] ? j1f58[B[520197]][B[520198]] == 0x1 ? ly0v$(!![]) : (ly0v$(![]), console[B[520001]](B[520199] + j1f58[B[520197]][B[520200]])) : console[B[520041]](B[520196], j1f58);
  });
}, window['B1_LNS'] = function (v0t$yl) {
  console[B[520041]](B[520201], v0t$yl);
}, window['B1_NL'] = function (yv0l$t) {}, window['B1_LN'] = function (zv0l, eguin, ugp2ie) {}, window['B1_L'] = function (khz69) {
  console[B[520041]](B[520202], khz69), window[B[520034]][B[520035]][B[520203]](), window[B[520034]][B[520035]][B[520204]](), window[B[520034]][B[520035]][B[520205]]();
}, window['B1L_'] = function (pnguse) {
  window['B1_SNL'](B[520206]);var sh7un = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'account': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'cdn': window['B1NL'][B[520021]], 'pkgName': window['B1NL'][B[520163]], 'gamever': window[B[520006]][B[520007]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': B[520207], 'stack': pnguse ? pnguse : B[520206] },
      h6bk79 = JSON[B[520026]](sh7un);console[B[520027]](B[520208] + h6bk79), window['B1_N'](h6bk79);
}, window['B1N_L'] = function (g2piea) {
  var aewi3 = JSON[B[520209]](g2piea);aewi3[B[520210]] = window[B[520006]][B[520007]], aewi3[B[520211]] = window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, aewi3[B[520024]] = window[B[520024]];var td_q$ = JSON[B[520026]](aewi3);console[B[520027]](B[520212] + td_q$), window['B1_N'](td_q$);
}, window['B1NL_'] = function (w82ia3, $v40yl) {
  var h7nug = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'account': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'cdn': window['B1NL'][B[520021]], 'pkgName': window['B1NL'][B[520163]], 'gamever': window[B[520006]][B[520007]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': w82ia3, 'stack': $v40yl },
      a83rfw = JSON[B[520026]](h7nug);console[B[520213]](B[520214] + a83rfw), window['B1_N'](a83rfw);
}, window['B1_N'] = function (nps7ug) {
  if (window['B1NL'][B[520115]] == B[520215]) return;var dxt$_ = B1NL['B1_N'] + B[520216] + B1NL[B[520019]];wx[B[520217]]({ 'url': dxt$_, 'method': B[520218], 'data': nps7ug, 'header': { 'content-type': B[520219], 'cache-control': B[520220] }, 'success': function (sh976) {
      DEBUG && console[B[520041]](B[520221], dxt$_, nps7ug, sh976);
    }, 'fail': function (gpen) {
      DEBUG && console[B[520041]](B[520221], dxt$_, nps7ug, gpen);
    }, 'complete': function () {} });
}, window[B[520222]] = function () {
  function klbz4() {
    return ((0x1 + Math[B[520223]]()) * 0x10000 | 0x0)[B[520224]](0x10)[B[520225]](0x1);
  }return klbz4() + klbz4() + '-' + klbz4() + '-' + klbz4() + '-' + klbz4() + '+' + klbz4() + klbz4() + klbz4();
}, window['B1N_'] = function () {
  console[B[520041]](B[520226]);var eginp = Bv0$tl[B[520227]]();B1NL[B[520168]] = eginp[B[520228]], B1NL[B[520167]] = eginp[B[520228]], B1NL[B[520162]] = eginp[B[520228]], B1NL[B[520163]] = eginp[B[520229]];var esun = { 'game_ver': B1NL[B[520079]] };B1NL[B[520164]] = this[B[520222]](), B1_NSL({ 'title': B[520230] }), Bv0$tl[B[520231]](esun, this['B1L_N'][B[520232]](this));
};var wx_develop = ![];window['B1L_N'] = function (lb4zk) {
  var t$0xyv = lb4zk[B[520233]];wx_develop = t$0xyv == 0x1, console[B[520041]](B[520234] + t$0xyv + B[520235] + (t$0xyv == 0x1) + B[520236] + lb4zk[B[520007]] + B[520237] + window[B[520144]][B[520151]]);if (!lb4zk[B[520007]] || window['B12SL_N'](window[B[520144]][B[520151]], lb4zk[B[520007]]) < 0x0) console[B[520041]](B[520238]), B1NL[B[520154]] = B[520239], B1NL[B[520156]] = B[520240], B1NL[B[520158]] = B[520241], B1NL[B[520021]] = B[520242], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = 'fs', B1NL[B[520179]] = ![];else window['B12SL_N'](window[B[520144]][B[520151]], lb4zk[B[520007]]) == 0x0 ? (console[B[520041]](B[520246]), B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520021]] = B[520247], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = B[520248], B1NL[B[520179]] = !![]) : (console[B[520041]](B[520249]), B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520021]] = B[520247], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = B[520248], B1NL[B[520179]] = ![]);B1NL[B[520165]] = config[B[520250]] ? config[B[520250]] : 0x0, this['B1SN_L'](), this['B1SNL_'](), window[B[520251]] = 0x5, B1_NSL({ 'title': B[520252] }), Bv0$tl[B[520253]](this['B1LN_'][B[520232]](this));
}, window[B[520251]] = 0x5, window['B1LN_'] = function (_yx, oj1r5m) {
  if (_yx == 0x0 && oj1r5m && oj1r5m[B[520254]]) {
    B1NL[B[520255]] = oj1r5m[B[520254]];var lvzbk = this;B1_NSL({ 'title': B[520256] }), sendApi(B1NL[B[520154]], B[520257], { 'platform': B1NL[B[520152]], 'partner_id': B1NL[B[520162]], 'token': oj1r5m[B[520254]], 'game_pkg': B1NL[B[520163]], 'deviceId': B1NL[B[520164]], 'scene': B[520258] + B1NL[B[520165]] }, this['B1S_NL'][B[520232]](this), B1SLN, B1L_);
  } else oj1r5m && oj1r5m[B[520058]] && window[B[520251]] > 0x0 && (oj1r5m[B[520058]][B[520107]](B[520259]) != -0x1 || oj1r5m[B[520058]][B[520107]](B[520260]) != -0x1 || oj1r5m[B[520058]][B[520107]](B[520261]) != -0x1 || oj1r5m[B[520058]][B[520107]](B[520262]) != -0x1 || oj1r5m[B[520058]][B[520107]](B[520263]) != -0x1 || oj1r5m[B[520058]][B[520107]](B[520264]) != -0x1) ? (window[B[520251]]--, Bv0$tl[B[520253]](this['B1LN_'][B[520232]](this))) : (window['B1NL_'](B[520265], JSON[B[520026]]({ 'status': _yx, 'data': oj1r5m })), window['B1_SNL'](B[520266] + (oj1r5m && oj1r5m[B[520058]] ? '，' + oj1r5m[B[520058]] : '')));
}, window['B1S_NL'] = function (t_$d0x) {
  if (!t_$d0x) {
    window['B1NL_'](B[520267], B[520268]), window['B1_SNL'](B[520269]);return;
  }if (t_$d0x[B[520198]] != B[520270]) {
    window['B1NL_'](B[520267], JSON[B[520026]](t_$d0x)), window['B1_SNL'](B[520271] + t_$d0x[B[520198]]);return;
  }B1NL[B[520272]] = String(t_$d0x[B[520019]]), B1NL[B[520019]] = String(t_$d0x[B[520019]]), B1NL[B[520083]] = String(t_$d0x[B[520083]]), B1NL[B[520168]] = String(t_$d0x[B[520083]]), B1NL[B[520273]] = String(t_$d0x[B[520273]]), B1NL[B[520274]] = String(t_$d0x[B[520275]]), B1NL[B[520276]] = String(t_$d0x[B[520277]]), B1NL[B[520275]] = '';var hung = this;B1_NSL({ 'title': B[520278] }), sendApi(B1NL[B[520154]], B[520279], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, hung['B1S_LN'][B[520232]](hung), B1SLN, B1L_);
}, window['B1S_LN'] = function (zh96b) {
  if (!zh96b) {
    window['B1_SNL'](B[520280]);return;
  }if (zh96b[B[520198]] != B[520270]) {
    window['B1_SNL'](B[520281] + zh96b[B[520198]]);return;
  }if (!zh96b[B[520197]] || zh96b[B[520197]][B[520010]] == 0x0) {
    window['B1_SNL'](B[520282]);return;
  }B1NL[B[520283]] = zh96b[B[520284]], B1NL[B[520022]] = { 'server_id': String(zh96b[B[520197]][0x0][B[520023]]), 'server_name': String(zh96b[B[520197]][0x0][B[520285]]), 'entry_ip': zh96b[B[520197]][0x0][B[520286]], 'entry_port': parseInt(zh96b[B[520197]][0x0][B[520287]]), 'status': B1NS_(zh96b[B[520197]][0x0]), 'start_time': zh96b[B[520197]][0x0][B[520288]], 'cdn': B1NL[B[520021]] }, this['B1LNS_']();
}, window['B1LNS_'] = function () {
  if (B1NL[B[520283]] == 0x1) {
    var s7pn = B1NL[B[520022]][B[520289]];if (s7pn === -0x1 || s7pn === 0x0) {
      window['B1_SNL'](s7pn === -0x1 ? B[520290] : B[520291]);return;
    }B1L_SN(0x0, B1NL[B[520022]][B[520023]]), window[B[520034]][B[520035]][B[520292]](B1NL[B[520283]]);
  } else window[B[520034]][B[520035]][B[520293]](), B1_NLS();window['B1NS'] = !![], window['B1LSN_'](), window['B1LN_S']();
}, window['B1SN_L'] = function () {
  sendApi(B1NL[B[520154]], B[520294], { 'game_pkg': B1NL[B[520163]], 'version_name': B1NL[B[520245]] }, this[B[520295]][B[520232]](this), B1SLN, B1L_);
}, window[B[520295]] = function ($qxd) {
  if (!$qxd) {
    window['B1_SNL'](B[520296]);return;
  }if ($qxd[B[520198]] != B[520270]) {
    window['B1_SNL'](B[520297] + $qxd[B[520198]]);return;
  }if (!$qxd[B[520197]] || !$qxd[B[520197]][B[520079]]) {
    window['B1_SNL'](B[520298] + ($qxd[B[520197]] && $qxd[B[520197]][B[520079]]));return;
  }$qxd[B[520197]][B[520299]] && $qxd[B[520197]][B[520299]][B[520010]] > 0xa && (B1NL[B[520300]] = $qxd[B[520197]][B[520299]], B1NL[B[520021]] = $qxd[B[520197]][B[520299]]), $qxd[B[520197]][B[520079]] && (B1NL[B[520020]] = $qxd[B[520197]][B[520079]]), console[B[520001]](B[520301] + B1NL[B[520020]] + B[520302] + B1NL[B[520245]]), window['B1NLS'] = !![], window['B1LSN_'](), window['B1LN_S']();
}, window[B[520303]], window['B1SNL_'] = function () {
  sendApi(B1NL[B[520154]], B[520304], { 'game_pkg': B1NL[B[520163]] }, this['B1SL_N'][B[520232]](this), B1SLN, B1L_);
}, window['B1SL_N'] = function (_x$qd) {
  if (_x$qd[B[520198]] === B[520270] && _x$qd[B[520197]]) {
    window[B[520303]] = _x$qd[B[520197]];for (var jmrf1 in _x$qd[B[520197]]) {
      B1NL[jmrf1] = _x$qd[B[520197]][jmrf1];
    }
  } else console[B[520001]](B[520305] + _x$qd[B[520198]]);window['B1SN'] = !![], window['B1LN_S']();
}, window[B[520306]] = function (snh67u, spngu7, egip2u, f5rm1, sgp7un, ksh7, d0x_t, zv4byl, f8jr1) {
  sgp7un = String(sgp7un);var u7gns = d0x_t,
      jr53 = zv4byl;B1NL[B[520149]][sgp7un] = { 'productid': sgp7un, 'productname': u7gns, 'productdesc': jr53, 'roleid': snh67u, 'rolename': spngu7, 'rolelevel': egip2u, 'price': ksh7, 'callback': f8jr1 }, sendApi(B1NL[B[520158]], B[520307], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'server_name': B1NL[B[520022]][B[520285]], 'level': egip2u, 'uid': B1NL[B[520019]], 'role_id': snh67u, 'role_name': spngu7, 'product_id': sgp7un, 'product_name': u7gns, 'product_desc': jr53, 'money': ksh7, 'partner_id': B1NL[B[520162]] }, toPayCallBack, B1SLN, B1L_);
}, window[B[520308]] = function (dt$0_) {
  if (dt$0_) {
    if (dt$0_[B[520309]] === 0xc8 || dt$0_[B[520198]] == B[520270]) {
      var zl4b9k = B1NL[B[520149]][String(dt$0_[B[520310]])];if (zl4b9k[B[520311]]) zl4b9k[B[520311]](dt$0_[B[520310]], dt$0_[B[520312]], -0x1);Bv0$tl[B[520313]]({ 'cpbill': dt$0_[B[520312]], 'productid': dt$0_[B[520310]], 'productname': zl4b9k[B[520314]], 'productdesc': zl4b9k[B[520315]], 'serverid': B1NL[B[520022]][B[520023]], 'servername': B1NL[B[520022]][B[520285]], 'roleid': zl4b9k[B[520316]], 'rolename': zl4b9k[B[520317]], 'rolelevel': zl4b9k[B[520318]], 'price': zl4b9k[B[520319]], 'extension': JSON[B[520026]]({ 'cp_order_id': dt$0_[B[520312]] }) }, function (ensug, m1r5oj) {
        zl4b9k[B[520311]] && ensug == 0x0 && zl4b9k[B[520311]](dt$0_[B[520310]], dt$0_[B[520312]], ensug);console[B[520001]](JSON[B[520026]]({ 'type': B[520320], 'status': ensug, 'data': dt$0_, 'role_name': zl4b9k[B[520317]] }));if (ensug === 0x0) {} else {
          if (ensug === 0x1) {} else {
            if (ensug === 0x2) {}
          }
        }
      });
    } else alert(dt$0_[B[520001]]);
  }
}, window['B1SLN_'] = function () {}, window['B1_SL'] = function (pnu7gs, dq$t_x, xdq$t, egsnp, l0y4) {
  Bv0$tl[B[520321]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], pnu7gs, dq$t_x, xdq$t), sendApi(B1NL[B[520154]], B[520322], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': pnu7gs, 'uid': B1NL[B[520019]], 'role_name': dq$t_x, 'role_type': egsnp, 'level': xdq$t });
}, window['B1_LS'] = function (m5rfj1, j5r81, fjm51r, a8r3wf, ns769, j3f5, u7psng, t$dqx, ghs7n, zy4lv) {
  B1NL[B[520016]] = m5rfj1, B1NL[B[520017]] = j5r81, B1NL[B[520018]] = fjm51r, Bv0$tl[B[520323]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], m5rfj1, j5r81, fjm51r), sendApi(B1NL[B[520154]], B[520324], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': m5rfj1, 'uid': B1NL[B[520019]], 'role_name': j5r81, 'role_type': a8r3wf, 'level': fjm51r, 'evolution': ns769 });
}, window['B1S_L'] = function (ai2egp, ns96, w2e3a, ltv0$, r5fw8, fr58j3, iwea23, ghs7, n7husg, mjfr1) {
  B1NL[B[520016]] = ai2egp, B1NL[B[520017]] = ns96, B1NL[B[520018]] = w2e3a, Bv0$tl[B[520325]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], ai2egp, ns96, w2e3a), sendApi(B1NL[B[520154]], B[520324], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': ai2egp, 'uid': B1NL[B[520019]], 'role_name': ns96, 'role_type': ltv0$, 'level': w2e3a, 'evolution': r5fw8 });
}, window['B1SL_'] = function (zlb4vy) {}, window['B1_S'] = function (gea2pi) {
  Bv0$tl[B[520326]](B[520326], function (yvzl40) {
    gea2pi && gea2pi(yvzl40);
  });
}, window[B[520327]] = function () {
  Bv0$tl[B[520327]]();
}, window[B[520328]] = function () {
  Bv0$tl[B[520329]]();
}, window[B[520135]] = function (n97h) {
  window['B1L_S'] = n97h, window['B1L_S'] && window['B1S_'] && (console[B[520001]](B[520136] + window['B1S_'][B[520137]]), window['B1L_S'](window['B1S_']), window['B1S_'] = null);
}, window['B1LS_'] = function (w2fa38, yl0v, m1rj5, apig2) {
  window[B[520330]](B[520331], { 'game_pkg': window['B1NL'][B[520163]], 'role_id': yl0v, 'server_id': m1rj5 }, apig2);
}, window['B1N_SL'] = function (g7nh, ep2gi) {
  function j1fm(gnus) {
    var y4l0$ = [],
        gepa2i = [],
        hs97k = window[B[520006]][B[520332]];for (var unigp in hs97k) {
      var nupgi = Number(unigp);(!g7nh || !g7nh[B[520010]] || g7nh[B[520107]](nupgi) != -0x1) && (gepa2i[B[520038]](hs97k[unigp]), y4l0$[B[520038]]([nupgi, 0x3]));
    }window['B12SL_N'](window[B[520039]], B[520333]) >= 0x0 ? (console[B[520041]](B[520334]), Bv0$tl[B[520335]] && Bv0$tl[B[520335]](gepa2i, function (wrfa) {
      console[B[520041]](B[520336]), console[B[520041]](wrfa);if (wrfa && wrfa[B[520058]] == B[520337]) for (var v$ytl0 in hs97k) {
        if (wrfa[hs97k[v$ytl0]] == B[520338]) {
          var x0_y = Number(v$ytl0);for (var d$x0_t = 0x0; d$x0_t < y4l0$[B[520010]]; d$x0_t++) {
            if (y4l0$[d$x0_t][0x0] == x0_y) {
              y4l0$[d$x0_t][0x1] = 0x1;break;
            }
          }
        }
      }window['B12SL_N'](window[B[520039]], B[520339]) >= 0x0 ? wx[B[520340]]({ 'withSubscriptions': !![], 'success': function (yz4v0l) {
          var shk67 = yz4v0l[B[520341]][B[520342]];if (shk67) {
            console[B[520041]](B[520343]), console[B[520041]](shk67);for (var k4z9b in hs97k) {
              if (shk67[hs97k[k4z9b]] == B[520338]) {
                var o5rj1m = Number(k4z9b);for (var x_0td = 0x0; x_0td < y4l0$[B[520010]]; x_0td++) {
                  if (y4l0$[x_0td][0x0] == o5rj1m) {
                    y4l0$[x_0td][0x1] = 0x2;break;
                  }
                }
              }
            }console[B[520041]](y4l0$), ep2gi && ep2gi(y4l0$);
          } else console[B[520041]](B[520344]), console[B[520041]](yz4v0l), console[B[520041]](y4l0$), ep2gi && ep2gi(y4l0$);
        }, 'fail': function () {
          console[B[520041]](B[520345]), console[B[520041]](y4l0$), ep2gi && ep2gi(y4l0$);
        } }) : (console[B[520041]](B[520346] + window[B[520039]]), console[B[520041]](y4l0$), ep2gi && ep2gi(y4l0$));
    })) : (console[B[520041]](B[520347] + window[B[520039]]), console[B[520041]](y4l0$), ep2gi && ep2gi(y4l0$)), wx[B[520348]](j1fm);
  }wx[B[520349]](j1fm);
}, window['B1N_LS'] = { 'isSuccess': ![], 'level': B[520350], 'isCharging': ![] }, window['B1NS_L'] = function ($_0txd) {
  wx[B[520123]]({ 'success': function (hk6zb9) {
      var ugnh7 = window['B1N_LS'];ugnh7[B[520351]] = !![], ugnh7[B[520125]] = Number(hk6zb9[B[520125]])[B[520352]](0x0), ugnh7[B[520127]] = hk6zb9[B[520127]], $_0txd && $_0txd(ugnh7[B[520351]], ugnh7[B[520125]], ugnh7[B[520127]]);
    }, 'fail': function (lkzb4v) {
      console[B[520041]](B[520353], lkzb4v[B[520058]]);var hkb7 = window['B1N_LS'];$_0txd && $_0txd(hkb7[B[520351]], hkb7[B[520125]], hkb7[B[520127]]);
    } });
}, window[B[520330]] = function (zbkl4, n7ugsp, lzbk4v, y4vzb, vy4zl, vlbk4, rj8f3, n7sh6) {
  if (y4vzb == undefined) y4vzb = 0x1;wx[B[520217]]({ 'url': zbkl4, 'method': rj8f3 || B[520354], 'responseType': B[520355], 'data': n7ugsp, 'header': { 'content-type': n7sh6 || B[520219] }, 'success': function (epugsn) {
      DEBUG && console[B[520041]](B[520356], zbkl4, info, epugsn);if (epugsn && epugsn[B[520357]] == 0xc8) {
        var h6ns7u = epugsn[B[520197]];!vlbk4 || vlbk4(h6ns7u) ? lzbk4v && lzbk4v(h6ns7u) : window[B[520358]](zbkl4, n7ugsp, lzbk4v, y4vzb, vy4zl, vlbk4, epugsn);
      } else window[B[520358]](zbkl4, n7ugsp, lzbk4v, y4vzb, vy4zl, vlbk4, epugsn);
    }, 'fail': function (ty0_) {
      DEBUG && console[B[520041]](B[520359], zbkl4, info, ty0_), window[B[520358]](zbkl4, n7ugsp, lzbk4v, y4vzb, vy4zl, vlbk4, ty0_);
    }, 'complete': function () {} });
}, window[B[520358]] = function (l4byz, u7sh, iea2gp, pngu7, j18f5, fj53r8, u67h) {
  pngu7 - 0x1 > 0x0 ? setTimeout(function () {
    window[B[520330]](l4byz, u7sh, iea2gp, pngu7 - 0x1, j18f5, fj53r8);
  }, 0x3e8) : j18f5 && j18f5(JSON[B[520026]]({ 'url': l4byz, 'response': u67h }));
}, window[B[520360]] = function (ugpi2, z6k4, jr5f3, egpsn, ignup, usgh7n, kh69) {
  !jr5f3 && (jr5f3 = {});var bz69h = Math[B[520361]](Date[B[520174]]() / 0x3e8);jr5f3[B[520277]] = bz69h, jr5f3[B[520362]] = z6k4;var moj15 = Object[B[520363]](jr5f3)[B[520364]](),
      waf382 = '',
      r35fj = '';for (var kvbzl = 0x0; kvbzl < moj15[B[520010]]; kvbzl++) {
    waf382 = waf382 + (kvbzl == 0x0 ? '' : '&') + moj15[kvbzl] + jr5f3[moj15[kvbzl]], r35fj = r35fj + (kvbzl == 0x0 ? '' : '&') + moj15[kvbzl] + '=' + encodeURIComponent(jr5f3[moj15[kvbzl]]);
  }waf382 = waf382 + B1NL[B[520160]];var w3iea2 = B[520365] + md5(waf382);send(ugpi2 + '?' + r35fj + (r35fj == '' ? '' : '&') + w3iea2, null, egpsn, ignup, usgh7n, kh69 || function (w8fa) {
    return w8fa[B[520198]] == B[520270];
  }, null, B[520366]);
}, window['B1NSL_'] = function (geniup, ty0xv$) {
  var spegnu = 0x0;B1NL[B[520022]] && (spegnu = B1NL[B[520022]][B[520023]]), sendApi(B1NL[B[520156]], B[520367], { 'partnerId': B1NL[B[520162]], 'gamePkg': B1NL[B[520163]], 'logTime': Math[B[520361]](Date[B[520174]]() / 0x3e8), 'platformUid': B1NL[B[520273]], 'type': geniup, 'serverId': spegnu }, null, 0x2, null, function () {
    return !![];
  });
}, window['B1NL_S'] = function (eipaw) {
  sendApi(B1NL[B[520154]], B[520368], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, B1NLS_, B1SLN, B1L_);
}, window['B1NLS_'] = function (i3ea2w) {
  if (i3ea2w[B[520198]] === B[520270] && i3ea2w[B[520197]]) {
    i3ea2w[B[520197]][B[520369]]({ 'id': -0x2, 'name': B[520370] }), i3ea2w[B[520197]][B[520369]]({ 'id': -0x1, 'name': B[520371] }), B1NL[B[520372]] = i3ea2w[B[520197]];if (window[B[520373]]) window[B[520373]][B[520374]]();
  } else B1NL[B[520375]] = ![], window['B1_SNL'](B[520376] + i3ea2w[B[520198]]);
}, window['B1_SN'] = function (k96hzb) {
  sendApi(B1NL[B[520154]], B[520377], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, B1_NS, B1SLN, B1L_);
}, window['B1_NS'] = function (y0t_$x) {
  B1NL[B[520378]] = ![];if (y0t_$x[B[520198]] === B[520270] && y0t_$x[B[520197]]) {
    for (var wfr83 = 0x0; wfr83 < y0t_$x[B[520197]][B[520010]]; wfr83++) {
      y0t_$x[B[520197]][wfr83][B[520289]] = B1NS_(y0t_$x[B[520197]][wfr83]);
    }B1NL[B[520166]][-0x1] = window[B[520379]](y0t_$x[B[520197]]), window[B[520373]][B[520380]](-0x1);
  } else window['B1_SNL'](B[520381] + y0t_$x[B[520198]]);
}, window[B[520382]] = function (ig2pe) {
  sendApi(B1NL[B[520154]], B[520377], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, ig2pe, B1SLN, B1L_);
}, window['B1S_N'] = function (z4lbvy, td$0) {
  sendApi(B1NL[B[520154]], B[520383], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]], 'server_group_id': td$0 }, B1SN_, B1SLN, B1L_);
}, window['B1SN_'] = function (lzkvb) {
  B1NL[B[520378]] = ![];if (lzkvb[B[520198]] === B[520270] && lzkvb[B[520197]] && lzkvb[B[520197]][B[520197]]) {
    var v0$tx = lzkvb[B[520197]][B[520384]],
        gesupn = [];for (var w8a2f = 0x0; w8a2f < lzkvb[B[520197]][B[520197]][B[520010]]; w8a2f++) {
      lzkvb[B[520197]][B[520197]][w8a2f][B[520289]] = B1NS_(lzkvb[B[520197]][B[520197]][w8a2f]), (gesupn[B[520010]] == 0x0 || lzkvb[B[520197]][B[520197]][w8a2f][B[520289]] != 0x0) && (gesupn[gesupn[B[520010]]] = lzkvb[B[520197]][B[520197]][w8a2f]);
    }B1NL[B[520166]][v0$tx] = window[B[520379]](gesupn), window[B[520373]][B[520380]](v0$tx);
  } else window['B1_SNL'](B[520385] + lzkvb[B[520198]]);
}, window['B12SLN'] = function (yt$0_x) {
  sendApi(B1NL[B[520154]], B[520386], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, reqServerRecommendCallBack, B1SLN, B1L_);
}, window[B[520387]] = function (i328w) {
  B1NL[B[520378]] = ![];if (i328w[B[520198]] === B[520270] && i328w[B[520197]]) {
    for (var upns7g = 0x0; upns7g < i328w[B[520197]][B[520010]]; upns7g++) {
      i328w[B[520197]][upns7g][B[520289]] = B1NS_(i328w[B[520197]][upns7g]);
    }B1NL[B[520166]][-0x2] = window[B[520379]](i328w[B[520197]]), window[B[520373]][B[520380]](-0x2);
  } else alert(B[520388] + i328w[B[520198]]);
}, window[B[520379]] = function (e2paiw) {
  if (!e2paiw && e2paiw[B[520010]] <= 0x0) return e2paiw;for (let xd0t_$ = 0x0; xd0t_$ < e2paiw[B[520010]]; xd0t_$++) {
    e2paiw[xd0t_$][B[520389]] && e2paiw[xd0t_$][B[520389]] == 0x1 && (e2paiw[xd0t_$][B[520285]] += B[520390]);
  }return e2paiw;
}, window['B1N_S'] = function (n76hu, yl0zv4) {
  n76hu = n76hu || B1NL[B[520022]][B[520023]], sendApi(B1NL[B[520154]], B[520391], { 'type': '4', 'game_pkg': B1NL[B[520163]], 'server_id': n76hu }, yl0zv4);
}, window[B[520392]] = function (ar3wf, $0xyvt, $_qt, ngsuh7) {
  $_qt = $_qt || B1NL[B[520022]][B[520023]], sendApi(B1NL[B[520154]], B[520393], { 'type': ar3wf, 'game_pkg': $0xyvt, 'server_id': $_qt }, ngsuh7);
}, window['B1NS_'] = function (j38f) {
  if (j38f) {
    if (j38f[B[520289]] == 0x1) {
      if (j38f[B[520394]] == 0x1) return 0x2;else return 0x1;
    } else return j38f[B[520289]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['B1L_SN'] = function (upn7sg, orj5m) {
  B1NL[B[520395]] = { 'step': upn7sg, 'server_id': orj5m };var ngpus = this;B1_NSL({ 'title': B[520396] }), sendApi(B1NL[B[520154]], B[520397], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'game_pkg': B1NL[B[520163]], 'server_id': orj5m, 'platform': B1NL[B[520083]], 'platform_uid': B1NL[B[520273]], 'check_login_time': B1NL[B[520276]], 'check_login_sign': B1NL[B[520274]], 'version_name': B1NL[B[520245]] }, B1L_NS, B1SLN, B1L_, function (ghns) {
    return ghns[B[520198]] == B[520270] || ghns[B[520001]] == B[520398] || ghns[B[520001]] == B[520399];
  });
}, window['B1L_NS'] = function (vyz0l) {
  var lk4bv = this;if (vyz0l[B[520198]] === B[520270] && vyz0l[B[520197]]) {
    var agpe2i = B1NL[B[520022]];agpe2i[B[520400]] = B1NL[B[520167]], agpe2i[B[520275]] = String(vyz0l[B[520197]][B[520401]]), agpe2i[B[520173]] = parseInt(vyz0l[B[520197]][B[520277]]);if (vyz0l[B[520197]][B[520402]]) agpe2i[B[520402]] = parseInt(vyz0l[B[520197]][B[520402]]);else agpe2i[B[520402]] = parseInt(vyz0l[B[520197]][B[520023]]);agpe2i[B[520403]] = 0x0, agpe2i[B[520021]] = B1NL[B[520300]], agpe2i[B[520404]] = vyz0l[B[520197]][B[520405]], agpe2i[B[520406]] = vyz0l[B[520197]][B[520406]], console[B[520041]](B[520407] + JSON[B[520026]](agpe2i[B[520406]])), B1NL[B[520283]] == 0x1 && agpe2i[B[520406]] && agpe2i[B[520406]][B[520408]] == 0x1 && (B1NL[B[520409]] = 0x1, window[B[520034]][B[520035]]['B12LN']()), B1LS_N();
  } else sendApi(B1NL[B[520154]], B[520257], { 'platform': B1NL[B[520152]], 'partner_id': B1NL[B[520162]], 'token': B1NL[B[520255]], 'game_pkg': B1NL[B[520163]], 'deviceId': B1NL[B[520164]], 'scene': B[520258] + B1NL[B[520165]] }, function (lv4y$) {
    if (lv4y$[B[520198]] == B[520410]) {
      window['B1_SNL'](B[520271] + lv4y$[B[520198]]);return;
    }B1NL[B[520274]] = String(lv4y$[B[520275]]), B1NL[B[520276]] = String(lv4y$[B[520277]]), setTimeout(function () {
      B1L_SN(B1NL[B[520395]][B[520411]], B1NL[B[520395]][B[520023]]);
    }, 0x5dc);
  }, B1SLN, B1L_, function (r8fw5) {
    return r8fw5[B[520198]] == B[520270] || r8fw5[B[520198]] == B[520410];
  });
}, window['B1LS_N'] = function () {
  ServerLoading[B[520035]][B[520292]](B1NL[B[520283]]), window['B1SL'] = !![], window['B1LN_S']();
}, window['B1LSN_'] = function () {
  if (window['B1LS'] && window['B1NSL'] && window[B[520180]] && window[B[520181]] && window['B1NLS'] && window['B1NS']) {
    if (!window[B[520412]][B[520035]]) {
      console[B[520041]](B[520413] + window[B[520412]][B[520035]]);var lv$0 = wx[B[520414]](),
          wia23 = lv$0[B[520137]] ? lv$0[B[520137]] : 0x0,
          ewaip2 = { 'cdn': window['B1NL'][B[520021]], 'spareCdn': window['B1NL'][B[520243]], 'newRegister': window['B1NL'][B[520283]], 'wxPC': window['B1NL'][B[520112]], 'wxIOS': window['B1NL'][B[520106]], 'wxAndroid': window['B1NL'][B[520109]], 'wxParam': { 'limitLoad': window['B1NL']['B12_SLN'], 'benchmarkLevel': window['B1NL']['B12_NSL'], 'wxFrom': window[B[520006]][B[520250]] == B[520415] ? 0x1 : 0x0, 'wxSDKVersion': window[B[520039]] }, 'configType': window['B1NL'][B[520175]], 'exposeType': window['B1NL'][B[520177]], 'scene': wia23 };new window[B[520412]](ewaip2, window['B1NL'][B[520020]], window['B12_SNL']);
    }
  }
}, window['B1LN_S'] = function () {
  if (window['B1LS'] && window['B1NSL'] && window[B[520180]] && window[B[520181]] && window['B1NLS'] && window['B1NS'] && window['B1SL'] && window['B1SN']) {
    B1_NLS();if (!B1LSN) {
      B1LSN = !![];if (!window[B[520412]][B[520035]]) window['B1LSN_']();var upgine = 0x0,
          pugn = wx[B[520416]]();pugn && (window['B1NL'][B[520111]] && (upgine = pugn[B[520101]]), console[B[520001]](B[520417] + pugn[B[520101]] + B[520418] + pugn[B[520102]] + B[520419] + pugn[B[520103]] + B[520420] + pugn[B[520104]] + B[520421] + pugn[B[520422]] + B[520423] + pugn[B[520424]]));var kzl94 = {};for (const gpiuen in B1NL[B[520022]]) {
        kzl94[gpiuen] = B1NL[B[520022]][gpiuen];
      }var k4b6z9 = { 'channel': window['B1NL'][B[520168]], 'account': window['B1NL'][B[520019]], 'userId': window['B1NL'][B[520272]], 'cdn': window['B1NL'][B[520021]], 'data': window['B1NL'][B[520197]], 'package': window['B1NL'][B[520150]], 'newRegister': window['B1NL'][B[520283]], 'pkgName': window['B1NL'][B[520163]], 'partnerId': window['B1NL'][B[520162]], 'platform_uid': window['B1NL'][B[520273]], 'deviceId': window['B1NL'][B[520164]], 'selectedServer': kzl94, 'configType': window['B1NL'][B[520175]], 'exposeType': window['B1NL'][B[520177]], 'debugUsers': window['B1NL'][B[520171]], 'wxMenuTop': upgine, 'wxShield': window['B1NL'][B[520179]] };if (window[B[520303]]) for (var y4bzv in window[B[520303]]) {
        k4b6z9[y4bzv] = window[B[520303]][y4bzv];
      }window[B[520412]][B[520035]]['B1LN2'](k4b6z9);
    }
  } else console[B[520001]](B[520425] + window['B1LS'] + B[520426] + window['B1NSL'] + B[520427] + window[B[520180]] + B[520428] + window[B[520181]] + B[520429] + window['B1NLS'] + B[520430] + window['B1NS'] + B[520431] + window['B1SL'] + B[520432] + window['B1SN']);
};