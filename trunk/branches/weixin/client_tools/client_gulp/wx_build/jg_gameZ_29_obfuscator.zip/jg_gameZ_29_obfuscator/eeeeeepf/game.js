var b = wx.$e;
require('eeeeBuff.js'), window[b[37336]][b[30537]][b[37219]] = null, window['client_pb'] = require('eeecleintpb.js'), window[b[28534]] = window[b[37336]][b[28410]][b[28411]](client_pb);