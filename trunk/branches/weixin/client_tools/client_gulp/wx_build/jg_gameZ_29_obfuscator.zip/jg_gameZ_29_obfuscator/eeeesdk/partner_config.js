var b = wx.$e;
var sdk_conf = {
  game_id: b[37429],
  game_pkg: b[37430],
  partner_id: b[37431],
  game_ver: b[37432],
  is_auth: false, //授权登录
  partner_app_id: b[37433],
  partner_app_key: b[37434]
};
window.config = sdk_conf;
module.exports = sdk_conf;