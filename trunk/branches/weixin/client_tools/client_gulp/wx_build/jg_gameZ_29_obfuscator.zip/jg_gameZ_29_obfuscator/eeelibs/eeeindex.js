var b = wx.$e;
import ezpd9m from '../eeeesdk/eeesdk.js';
window[b[27942]] = { 'wxVersion': window[b[619]][b[37438]] }, window[b[37537]] = ![], window[b[37538]] = 0x1, window[b[37539]] = 0x1, window[b[37540]] = !![], window[b[37541]] = !![], window['e1F$YGM'] = '', window[b[37542]] = !![], window[b[4664]] = {
    'base_cdn': b[37543],
    'cdn': b[37543]
}, e1GM[b[37544]] = {}, e1GM[b[28005]] = '0', e1GM[b[5498]] = window[b[27942]][b[37545]], e1GM[b[37512]] = '', e1GM['os'] = '1', e1GM[b[37546]] = b[37547], e1GM[b[37548]] = b[37549], e1GM[b[37550]] = b[37551], e1GM[b[37552]] = b[37553], e1GM[b[37554]] = b[37555], e1GM[b[13167]] = '1', e1GM[b[28382]] = '', e1GM[b[28384]] = '', e1GM[b[37556]] = 0x0, e1GM[b[37557]] = {}, e1GM[b[37558]] = parseInt(e1GM[b[13167]]), e1GM[b[13176]] = e1GM[b[13167]], e1GM[b[28376]] = {}, e1GM['e1$G'] = b[37559], e1GM[b[37560]] = ![], e1GM[b[13313]] = b[37561], e1GM[b[28336]] = Date[b[87]](), e1GM[b[4663]] = b[37562], e1GM[b[809]] = '_a', e1GM[b[28531]] = '', e1GM[b[37563]] = 0x2, e1GM[b[110]] = 0x7c1, e1GM[b[37545]] = window[b[27942]][b[37545]], e1GM[b[831]] = ![], e1GM[b[1189]] = ![], e1GM[b[11966]] = ![], e1GM[b[28007]] = ![], window[b[37564]] = 0x5, window[b[37565]] = ![], window[b[37473]] = ![], window[b[37478]] = ![], window[b[37566]] = ![], window[b[37567]] = ![], window[b[37568]] = ![], window[b[37569]] = ![], window[b[37570]] = ![], window[b[37571]] = ![], window[b[37572]] = null, window[b[713]] = function (tagew4) {
    console[b[543]](b[713], tagew4), wx[b[5008]]({}), wx[b[37462]]({
        'title': b[6257],
        'content': tagew4,
        'success'($pox) {
            if ($pox[b[37573]]) console[b[543]](b[37574]);else $pox[b[615]] && console[b[543]](b[37575]);
        }
    });
}, window['e1$YGM'] = function (hq638s) {
    console[b[543]](b[37576], hq638s), e1$GMY(), wx[b[37462]]({
        'title': b[6257],
        'content': hq638s,
        'confirmText': b[37577],
        'cancelText': b[20449],
        'success'(agf4) {
            if (agf4[b[37573]]) window['e1G$']();else agf4[b[615]] && (console[b[543]](b[37578]), wx[b[27979]]({}));
        }
    });
}, window[b[37579]] = function ($jox2) {
    console[b[543]](b[37579], $jox2), wx[b[37462]]({
        'title': b[6257],
        'content': $jox2,
        'confirmText': b[28515],
        'showCancel': ![],
        'complete'(s8qhl6) {
            console[b[543]](b[37578]), wx[b[27979]]({});
        }
    });
}, window['e1$YMG'] = ![], window['e1$GYM'] = function (zxmpo2) {
    window['e1$YMG'] = !![], wx[b[5007]](zxmpo2);
}, window['e1$GMY'] = function () {
    window['e1$YMG'] && (window['e1$YMG'] = ![], wx[b[5008]]({}));
}, window['e1$MYG'] = function (zodmpx) {
    window[b[37453]][b[167]]['e1$MYG'](zodmpx);
}, window[b[13183]] = function (dzop9, c7y_) {
    ezpd9m[b[13183]](dzop9, function (fkjg$t) {
        fkjg$t && fkjg$t[b[11]] ? fkjg$t[b[11]][b[1386]] == 0x1 ? c7y_(!![]) : (c7y_(![]), console[b[82]](b[37580] + fkjg$t[b[11]][b[37581]])) : console[b[543]](b[13183], fkjg$t);
    });
}, window['e1$MGY'] = function (t4jfgk) {
    console[b[543]](b[37582], t4jfgk);
}, window['e1$GM'] = function (px$2m) {}, window['e1$MG'] = function (c5ry0, pozxd, m9dpzo) {}, window['e1$M'] = function (ieqv) {
    console[b[543]](b[37583], ieqv), window[b[37453]][b[167]][b[37584]](), window[b[37453]][b[167]][b[37585]](), window[b[37453]][b[167]][b[37586]](), window[b[37587]]();
}, window['e1M$'] = function (rcy750) {
    window[b[37588]](0xe, b[37589] + rcy750), window['e1$YGM'](b[37590]);
    var $jfx2k = {
        'id': window[b[4664]][b[37443]],
        'role': window[b[4664]][b[4797]],
        'level': window[b[4664]][b[37444]],
        'account': window[b[4664]][b[28380]],
        'version': window[b[4664]][b[110]],
        'cdn': window[b[4664]][b[4661]],
        'pkgName': window[b[4664]][b[28382]],
        'gamever': window[b[619]][b[37438]],
        'serverid': window[b[4664]][b[28376]] ? window[b[4664]][b[28376]][b[12142]] : 0x0,
        'systemInfo': window[b[37445]],
        'error': b[37591],
        'stack': rcy750 ? rcy750 : b[37590]
    },
        dxzpmo = JSON[b[4647]]($jfx2k);
    console[b[144]](b[37592] + dxzpmo), window['e1$G'](dxzpmo);
}, window[b[37588]] = function (ebliqv, iv) {
    sendApi(e1GM[b[37550]], b[37593], {
        'game_pkg': e1GM[b[28382]],
        'partner_id': e1GM[b[13167]],
        'server_id': e1GM[b[28376]] && e1GM[b[28376]][b[12142]] > 0x0 ? e1GM[b[28376]][b[12142]] : 0x0,
        'uid': e1GM[b[28380]] > 0x0 ? e1GM[b[28380]] : 0x0,
        'type': ebliqv,
        'info': iv
    });
}, window['e1G$M'] = function (ewg4b) {
    var bwliev = JSON[b[587]](ewg4b);
    bwliev[b[37594]] = window[b[619]][b[37438]], bwliev[b[37595]] = window[b[4664]][b[28376]] ? window[b[4664]][b[28376]][b[12142]] : 0x0, bwliev[b[37445]] = window[b[37445]];
    var wabevi = JSON[b[4647]](bwliev);
    console[b[144]](b[37596] + wabevi), window['e1$G'](wabevi);
}, window['e1GM$'] = function (iwe, hiq) {
    var iabvwe = {
        'id': window[b[4664]][b[37443]],
        'role': window[b[4664]][b[4797]],
        'level': window[b[4664]][b[37444]],
        'account': window[b[4664]][b[28380]],
        'version': window[b[4664]][b[110]],
        'cdn': window[b[4664]][b[4661]],
        'pkgName': window[b[4664]][b[28382]],
        'gamever': window[b[619]][b[37438]],
        'serverid': window[b[4664]][b[28376]] ? window[b[4664]][b[28376]][b[12142]] : 0x0,
        'systemInfo': window[b[37445]],
        'error': iwe,
        'stack': hiq
    },
        k$fgt = JSON[b[4647]](iabvwe);
    console[b[103]](b[37597] + k$fgt), window['e1$G'](k$fgt);
}, window['e1$G'] = function (ewbag) {
    if (window[b[4664]][b[37513]] == b[37598]) return;
    var leqbv = e1GM['e1$G'] + b[37599] + e1GM[b[28380]];
    wx[b[538]]({
        'url': leqbv,
        'method': b[37360],
        'data': ewbag,
        'header': {
            'content-type': b[37600],
            'cache-control': b[27987]
        },
        'success': function (eiabvw) {
            DEBUG && console[b[543]](b[37601], leqbv, ewbag, eiabvw);
        },
        'fail': function (vhiqlb) {
            DEBUG && console[b[543]](b[37601], leqbv, ewbag, vhiqlb);
        },
        'complete': function () {}
    });
}, window[b[37602]] = function () {
    function hlqsi6() {
        return ((0x1 + Math[b[131]]()) * 0x10000 | 0x0)[b[297]](0x10)[b[558]](0x1);
    }
    return hlqsi6() + hlqsi6() + '-' + hlqsi6() + '-' + hlqsi6() + '-' + hlqsi6() + '+' + hlqsi6() + hlqsi6() + hlqsi6();
}, window['e1G$'] = function () {
    console[b[543]](b[37603]);
    var eqb = ezpd9m[b[35063]]();
    e1GM[b[13176]] = eqb[b[37604]], e1GM[b[37558]] = eqb[b[37604]], e1GM[b[13167]] = eqb[b[37604]], e1GM[b[28382]] = eqb[b[37605]];
    var iqhsv = { 'game_ver': e1GM[b[5498]] };
    e1GM[b[28384]] = this[b[37602]](), e1$GYM({ 'title': b[37606] }), ezpd9m[b[424]](iqhsv, this['e1M$G'][b[78]](this));
}, window['e1M$G'] = function (hs6q38) {
    var uzm1d = hs6q38[b[37607]];
    sdkInitRes = hs6q38, console[b[543]](b[37608] + uzm1d + b[37609] + (uzm1d == 0x1) + b[37610] + hs6q38[b[37438]] + b[37611] + window[b[27942]][b[37545]]);
    if (!hs6q38[b[37438]] || window['e1FYM$G'](window[b[27942]][b[37545]], hs6q38[b[37438]]) < 0x0) console[b[543]](b[37612]), e1GM[b[37548]] = b[37613], e1GM[b[37550]] = b[37614], e1GM[b[37552]] = b[37615], e1GM[b[4661]] = b[37616], e1GM[b[28004]] = b[37617], e1GM[b[4665]] = 'fj', e1GM[b[831]] = ![];else window['e1FYM$G'](window[b[27942]][b[37545]], hs6q38[b[37438]]) == 0x0 ? (console[b[543]](b[37618]), e1GM[b[37548]] = b[37549], e1GM[b[37550]] = b[37551], e1GM[b[37552]] = b[37553], e1GM[b[4661]] = b[37619], e1GM[b[28004]] = b[37617], e1GM[b[4665]] = b[37620], e1GM[b[831]] = !![]) : (console[b[543]](b[37621]), e1GM[b[37548]] = b[37549], e1GM[b[37550]] = b[37551], e1GM[b[37552]] = b[37553], e1GM[b[4661]] = b[37619], e1GM[b[28004]] = b[37617], e1GM[b[4665]] = b[37620], e1GM[b[831]] = ![]);
    e1GM[b[37556]] = config[b[32611]] ? config[b[32611]] : 0x0, this['e1YG$M'](), this['e1YGM$'](), window[b[37622]] = 0x5, e1$GYM({ 'title': b[37623] }), ezpd9m[b[37352]](this['e1MG$'][b[78]](this));
}, window[b[37622]] = 0x5, window['e1MG$'] = function (r63870, svhilq) {
    if (r63870 == 0x0 && svhilq && svhilq[b[37321]]) {
        e1GM[b[37624]] = svhilq[b[37321]], e1GM[b[28529]] = svhilq[b[28529]], e1GM[b[28524]] = svhilq[b[28524]], e1GM[b[28530]] = svhilq[b[28530]], e1GM[b[28523]] = svhilq[b[28523]];
        var vlhi = this;
        e1$GYM({ 'title': b[37625] }), sendApi(e1GM[b[37548]], b[37626], {
            'platform': e1GM[b[37546]],
            'partner_id': e1GM[b[13167]],
            'token': svhilq[b[37321]],
            'game_pkg': e1GM[b[28382]],
            'deviceId': e1GM[b[28384]],
            'scene': b[37627] + e1GM[b[37556]]
        }, this['e1Y$GM'][b[78]](this), e1YMG, e1M$);
    } else svhilq && svhilq[b[27995]] && window[b[37622]] > 0x0 && (svhilq[b[27995]][b[125]](b[37628]) != -0x1 || svhilq[b[27995]][b[125]](b[37629]) != -0x1 || svhilq[b[27995]][b[125]](b[37630]) != -0x1 || svhilq[b[27995]][b[125]](b[37631]) != -0x1 || svhilq[b[27995]][b[125]](b[37632]) != -0x1 || svhilq[b[27995]][b[125]](b[37633]) != -0x1) ? (window[b[37622]]--, ezpd9m[b[37352]](this['e1MG$'][b[78]](this))) : (window[b[37588]](0x1, b[37634] + r63870 + b[37635] + (svhilq ? svhilq[b[27995]] : '')), window['e1GM$'](b[37636], JSON[b[4647]]({
        'status': r63870,
        'data': svhilq
    })), window['e1$YGM'](b[37637] + (svhilq && svhilq[b[27995]] ? '，' + svhilq[b[27995]] : '')));
}, window['e1Y$GM'] = function (pxm2o) {
    if (!pxm2o) {
        window[b[37588]](0x2, b[37638]), window['e1GM$'](b[37639], b[37640]), window['e1$YGM'](b[37641]);
        return;
    }
    if (pxm2o[b[1386]] != b[10246]) {
        window[b[37588]](0x2, b[37642] + pxm2o[b[1386]]), window['e1GM$'](b[37639], JSON[b[4647]](pxm2o)), window['e1$YGM'](b[37643] + pxm2o[b[1386]]);
        return;
    }
    if (pxm2o[b[37644]] == 0x1) {
        window['e1$YGM'](b[37645]);
        return;
    }
    e1GM[b[13165]] = String(pxm2o[b[28380]]), e1GM[b[28380]] = String(pxm2o[b[28380]]), e1GM[b[28334]] = String(pxm2o[b[28334]]), e1GM[b[13176]] = String(pxm2o[b[28334]]), e1GM[b[28383]] = String(pxm2o[b[28383]]), e1GM[b[37646]] = String(pxm2o[b[12125]]), e1GM[b[37647]] = String(pxm2o[b[962]]), e1GM[b[12125]] = '';
    var zmud9 = this;
    e1$GYM({ 'title': b[37648] });
    var gbea4w = localStorage[b[541]](b[37649] + e1GM[b[28382]] + e1GM[b[28380]]);
    if (gbea4w && gbea4w != '') {
        var s386qh = Number(gbea4w);
        zmud9[b[37650]](s386qh);
    } else zmud9[b[37651]]();
}, window[b[37651]] = function () {
    var vbiqh = this;
    sendApi(e1GM[b[37548]], b[37652], {
        'partner_id': e1GM[b[13167]],
        'uid': e1GM[b[28380]],
        'version': e1GM[b[5498]],
        'game_pkg': e1GM[b[28382]],
        'device': e1GM[b[28384]]
    }, vbiqh['e1Y$MG'][b[78]](vbiqh), e1YMG, e1M$);
}, window['e1Y$MG'] = function (ivlhq) {
    if (!ivlhq) {
        window[b[37588]](0x3, b[37653]), window['e1$YGM'](b[37653]);
        return;
    }
    if (ivlhq[b[1386]] != b[10246]) {
        window[b[37588]](0x3, b[37654] + ivlhq[b[1386]]), window['e1$YGM'](b[37654] + ivlhq[b[1386]]);
        return;
    }
    if (!ivlhq[b[11]] || ivlhq[b[11]][b[13]] == 0x0) {
        window[b[37588]](0x3, b[37655]), window['e1$YGM'](b[37656]);
        return;
    }
    this[b[37657]](ivlhq);
}, window[b[37650]] = function (xp2fj$) {
    var fgkt4 = this;
    sendApi(e1GM[b[37548]], b[37658], {
        'server_id': xp2fj$,
        'time': Date[b[87]]() / 0x3e8
    }, fgkt4[b[37659]][b[78]](fgkt4), e1YMG, e1M$);
}, window[b[37659]] = function (lbwi) {
    if (!lbwi) {
        window[b[37588]](0x4, b[37660]), this[b[37651]]();
        return;
    }
    if (lbwi[b[1386]] != b[10246]) {
        window[b[37588]](0x4, b[37661] + lbwi[b[1386]]), this[b[37651]]();
        return;
    }
    if (!lbwi[b[11]] || lbwi[b[11]][b[13]] == 0x0) {
        window[b[37588]](0x4, b[37662]), this[b[37651]]();
        return;
    }
    this[b[37657]](lbwi);
}, window[b[37657]] = function (lhq6s) {
    e1GM[b[726]] = lhq6s[b[37663]] != undefined ? lhq6s[b[37663]] : 0x0, e1GM[b[28376]] = {
        'server_id': String(lhq6s[b[11]][0x0][b[12142]]),
        'server_name': String(lhq6s[b[11]][0x0][b[28381]]),
        'entry_ip': lhq6s[b[11]][0x0][b[27985]],
        'entry_port': parseInt(lhq6s[b[11]][0x0][b[28404]]),
        'status': e1GY$(lhq6s[b[11]][0x0]),
        'start_time': lhq6s[b[11]][0x0][b[37664]],
        'maintain_time': lhq6s[b[11]][0x0][b[37665]] ? lhq6s[b[11]][0x0][b[37665]] : '',
        'is_recommend': lhq6s[b[11]][0x0][b[37666]],
        'cdn': e1GM[b[4661]]
    }, this[b[37667]](), window[b[37453]] && window[b[37453]][b[167]][b[37668]] && window[b[37453]][b[167]][b[37668]](sdkInitRes[b[37669]], sdkInitRes[b[37670]], sdkInitRes[b[37671]], sdkInitRes[b[37672]], sdkInitRes[b[37673]]);
}, window[b[37667]] = function () {
    window[b[37570]] = !![], window['e1MGY$']();
}, window[b[37674]] = null, window['e1MGY$'] = function () {
    var jt4 = this;
    ezpd9m[b[37426]](function (iabw) {
        console[b[543]](b[37675] + JSON[b[4647]](iabw)), youYiCofig = iabw;
        window[b[37674]] && window[b[37674]][b[37676]] == 0x1 && (e1GM[b[726]] = 0x0);
        if (window[b[37570]] && window[b[37569]]) {
            var gt$kjf = e1GM[b[37677]] != undefined ? e1GM[b[37677]] : 0x0,
                zpmod = e1GM[b[28523]] == undefined ? 0x0 : e1GM[b[28523]],
                xdmzop = gt$kjf == 0x1 && zpmod == 0x1 || gt$kjf == 0x2 && zpmod != 0x1 || gt$kjf == 0x3;
            console[b[82]](b[37678] + e1GM[b[726]] + b[37679] + xdmzop + b[37680] + e1GM[b[28523]] + b[37681] + e1GM[b[37677]]);
            if (!xdmzop && e1GM[b[726]] == 0x1) {
                var d19omz = e1GM[b[28376]][b[116]];
                if (d19omz === -0x1 || d19omz === 0x0) {
                    window[b[37588]](0xf, b[37682] + e1GM[b[28376]]['id'] + b[37683] + e1GM[b[28376]][b[116]]), window['e1$YGM'](d19omz === -0x1 ? b[37684] : b[37685]);
                    return;
                }
                e1M$YG(0x0, e1GM[b[28376]][b[12142]]), window[b[37453]][b[167]][b[37686]](e1GM[b[726]]);
            } else window[b[37453]][b[167]][b[37687]](() => {
                var l68qs = window[b[37674]][b[37688]],
                    xj2f = window[b[37674]][b[37676]] == 0x1;
                xj2f && window[b[37453]][b[167]][b[37689]](b[37690], l68qs, b[37691]);
            }, jt4), e1$GMY();
            window[b[37692]](), window['e1MYG$'](), window['e1MG$Y']();
        }
    });
}, window[b[37693]] = function () {
    ezpd9m[b[37427]](function (m1zu9) {
        console[b[543]](b[37694] + JSON[b[4647]](m1zu9));
    });
}, window['e1YG$M'] = function () {
    sendApi(e1GM[b[37548]], b[37695], {
        'game_pkg': e1GM[b[28382]],
        'version_name': e1GM[b[4665]]
    }, this[b[37696]][b[78]](this), e1YMG, e1M$);
}, window[b[37696]] = function (z9du) {
    if (!z9du) {
        window[b[37588]](0x5, b[37697]), window['e1$YGM'](b[37697]);
        return;
    }
    if (z9du[b[1386]] != b[10246]) {
        window[b[37588]](0x5, b[37698] + z9du[b[1386]]), window['e1$YGM'](b[37698] + z9du[b[1386]]);
        return;
    }
    if (!z9du[b[11]] || !z9du[b[11]][b[5498]]) {
        window[b[37588]](0x5, b[37699] + (z9du[b[11]] && z9du[b[11]][b[5498]])), window['e1$YGM'](b[37699] + (z9du[b[11]] && z9du[b[11]][b[5498]]));
        return;
    }
    z9du[b[11]][b[37700]] && z9du[b[11]][b[37700]][b[13]] > 0xa && (e1GM[b[37701]] = z9du[b[11]][b[37700]], e1GM[b[4661]] = z9du[b[11]][b[37700]]), z9du[b[11]][b[5498]] && (e1GM[b[110]] = z9du[b[11]][b[5498]]), console[b[82]](b[28526] + e1GM[b[110]] + b[37702] + e1GM[b[4665]]), window[b[37568]] = !![], window['e1MYG$'](), window['e1MG$Y']();
}, window[b[37703]], window['e1YGM$'] = function () {
    sendApi(e1GM[b[37548]], b[37704], { 'game_pkg': e1GM[b[28382]] }, this['e1YM$G'][b[78]](this), e1YMG, e1M$);
}, window['e1YM$G'] = function (s8l6q) {
    if (s8l6q && s8l6q[b[1386]] === b[10246] && s8l6q[b[11]]) {
        window[b[37703]] = s8l6q[b[11]];
        for (var h6lis in s8l6q[b[11]]) {
            e1GM[h6lis] = s8l6q[b[11]][h6lis];
        }
    } else window[b[37588]](0xb, b[37705]), console[b[82]](b[37706] + s8l6q[b[1386]]);
    window[b[37569]] = !![], window['e1MGY$']();
}, window[b[37692]] = function () {
    if (!window[b[37570]] || !window[b[37569]]) return;
    var eba4w = e1GM[b[726]] == 0x1,
        sqvli = e1GM[b[831]],
        a4ftg = e1GM[b[28245]] && e1GM[b[28245]] > 0x0;
    if (sqvli || eba4w && a4ftg) {
        var c7r5y = e1GM[b[28246]],
            ebil = c7r5y && c7r5y[b[13]] == 0x9;
        ebil && (window[b[31370]] = c7r5y);
        var jt2$k = e1GM[b[28247]],
            y5n_c7 = jt2$k && jt2$k[b[15]]('#')[b[13]] == 0x4;
        y5n_c7 && (window[b[31371]] = jt2$k);
    }
}, window[b[37587]] = function () {
    window[b[31370]] = null, window[b[31371]] = null;
}, window[b[37707]] = function (sh6083, dop9zm, dzomp, d1mu9, ktwga4, ktfj$2, lsiq6h, lbvihq, kf$xj2, z2xmop) {
    ktwga4 = String(ktwga4);
    var _5yn = lsiq6h,
        mo9pd = lbvihq;
    e1GM[b[37544]][ktwga4] = {
        'productid': ktwga4,
        'productname': _5yn,
        'productdesc': mo9pd,
        'roleid': sh6083,
        'rolename': dop9zm,
        'rolelevel': dzomp,
        'price': ktfj$2,
        'callback': kf$xj2
    }, sendApi(e1GM[b[37552]], b[37708], {
        'game_pkg': e1GM[b[28382]],
        'server_id': e1GM[b[28376]][b[12142]],
        'server_name': e1GM[b[28376]][b[28381]],
        'level': dzomp,
        'uid': e1GM[b[28380]],
        'role_id': sh6083,
        'role_name': dop9zm,
        'product_id': ktwga4,
        'product_name': _5yn,
        'product_desc': mo9pd,
        'money': ktfj$2,
        'partner_id': e1GM[b[13167]]
    }, toPayCallBack, e1YMG, e1M$);
}, window[b[37709]] = function (aeg) {
    if (aeg && (aeg[b[37710]] === 0xc8 || aeg[b[1386]] == b[10246])) {
        var r573y0 = e1GM[b[37544]][String(aeg[b[37711]])];
        if (r573y0[b[389]]) r573y0[b[389]](aeg[b[37711]], aeg[b[37712]], -0x1);
        ezpd9m[b[37387]]({
            'cpbill': aeg[b[37712]],
            'productid': aeg[b[37711]],
            'productname': r573y0[b[37713]],
            'productdesc': r573y0[b[37714]],
            'serverid': e1GM[b[28376]][b[12142]],
            'servername': e1GM[b[28376]][b[28381]],
            'roleid': r573y0[b[13171]],
            'rolename': r573y0[b[13172]],
            'rolelevel': r573y0[b[37715]],
            'price': r573y0[b[30600]],
            'extension': JSON[b[4647]]({ 'cp_order_id': aeg[b[37712]] })
        }, function (duz91m, fxk2$j) {
            r573y0[b[389]] && duz91m == 0x0 && r573y0[b[389]](aeg[b[37711]], aeg[b[37712]], duz91m);
            console[b[82]](JSON[b[4647]]({
                'type': b[37716],
                'status': duz91m,
                'data': aeg,
                'role_name': r573y0[b[13172]]
            }));
            if (duz91m === 0x0) {} else {
                if (duz91m === 0x1) {} else {
                    if (duz91m === 0x2) {}
                }
            }
        });
    } else {
        var qsvi = aeg ? b[37717] + aeg[b[37710]] + b[37718] + aeg[b[1386]] + b[37719] + aeg[b[82]] : b[37720];
        window[b[37588]](0xd, b[37721] + qsvi), alert(qsvi);
    }
}, window['e1YMG$'] = function () {}, window['e1$YM'] = function (pomd, tj4kfg, li6hs, qivbel, ebwaiv) {
    ezpd9m[b[37422]](e1GM[b[28376]][b[12142]], e1GM[b[28376]][b[28381]] || e1GM[b[28376]][b[12142]], pomd, tj4kfg, li6hs), sendApi(e1GM[b[37548]], b[37722], {
        'game_pkg': e1GM[b[28382]],
        'server_id': e1GM[b[28376]][b[12142]],
        'role_id': pomd,
        'uid': e1GM[b[28380]],
        'role_name': tj4kfg,
        'role_type': qivbel,
        'level': li6hs
    });
}, window['e1$MY'] = function (ihvqlb, jg4kft, um1d, x$f2k, xmzpo, p$jx2f, $tfkg, qsl6h, n_7y5, kfx$2j) {
    e1GM[b[37443]] = ihvqlb, e1GM[b[4797]] = jg4kft, e1GM[b[37444]] = um1d, ezpd9m[b[37423]](e1GM[b[28376]][b[12142]], e1GM[b[28376]][b[28381]] || e1GM[b[28376]][b[12142]], ihvqlb, jg4kft, um1d), sendApi(e1GM[b[37548]], b[37723], {
        'game_pkg': e1GM[b[28382]],
        'server_id': e1GM[b[28376]][b[12142]],
        'role_id': ihvqlb,
        'uid': e1GM[b[28380]],
        'role_name': jg4kft,
        'role_type': x$f2k,
        'level': um1d,
        'evolution': xmzpo
    });
}, window['e1Y$M'] = function (bawive, ry750c, cn7y, hlqs68, r08y73, xodzm, sq638h, zu1dm, f4jk, ompx$) {
    e1GM[b[37443]] = bawive, e1GM[b[4797]] = ry750c, e1GM[b[37444]] = cn7y, ezpd9m[b[37424]](e1GM[b[28376]][b[12142]], e1GM[b[28376]][b[28381]] || e1GM[b[28376]][b[12142]], bawive, ry750c, cn7y), sendApi(e1GM[b[37548]], b[37723], {
        'game_pkg': e1GM[b[28382]],
        'server_id': e1GM[b[28376]][b[12142]],
        'role_id': bawive,
        'uid': e1GM[b[28380]],
        'role_name': ry750c,
        'role_type': hlqs68,
        'level': cn7y,
        'evolution': r08y73
    });
}, window['e1YM$'] = function (ka4g) {}, window['e1$Y'] = function (gweat4, s8h36) {
    ezpd9m[b[37370]](b[37370], { 'activity_id': s8h36 }, function (bvqlei) {
        gweat4 && gweat4(bvqlei);
    });
}, window[b[26033]] = function () {
    ezpd9m[b[26033]]();
}, window[b[37724]] = function () {
    ezpd9m[b[25903]]();
}, window[b[37725]] = function (sqli6, p2zm, k4ft, lqvbi, r0cy7, o9dz1m, r306s8, dz9mu) {
    dz9mu = dz9mu || e1GM[b[28376]][b[12142]], sendApi(e1GM[b[37548]], b[37726], {
        'phone': sqli6,
        'role_id': p2zm,
        'uid': e1GM[b[28380]],
        'game_pkg': e1GM[b[28382]],
        'partner_id': e1GM[b[13167]],
        'server_id': dz9mu
    }, r306s8, 0x2, null, function () {
        return !![];
    });
}, window[b[11455]] = function (d9mop) {
    window['e1M$Y'] = d9mop, window['e1M$Y'] && window['e1Y$'] && (console[b[82]](b[37529] + window['e1Y$'][b[887]]), window['e1M$Y'](window['e1Y$']), window['e1Y$'] = null);
}, window['e1MY$'] = function (fkx, jfx2$p, mozpdx, leqvb) {
    window[b[23]](b[37727], {
        'game_pkg': window[b[4664]][b[28382]],
        'role_id': jfx2$p,
        'server_id': mozpdx
    }, leqvb);
}, window['e1G$YM'] = function (bavew4, h6s38q, sl6h) {
    function ozpxm(r50) {
        var ewaiv = [],
            f2kxj = [],
            z9pmdo = sl6h || window[b[619]][b[37728]];
        for (var cy570r in z9pmdo) {
            var cy7n5 = Number(cy570r);
            (!bavew4 || !bavew4[b[13]] || bavew4[b[125]](cy7n5) != -0x1) && (f2kxj[b[30]](z9pmdo[cy570r]), ewaiv[b[30]]([cy7n5, 0x3]));
        }
        window['e1FYM$G'](window[b[37454]], b[37729]) >= 0x0 ? (console[b[543]](b[37730]), ezpd9m[b[37417]] && ezpd9m[b[37417]](f2kxj, function (f$k2) {
            console[b[543]](b[37731]), console[b[543]](f$k2);
            if (f$k2 && f$k2[b[27995]] == b[37732]) for (var q6lh in z9pmdo) {
                if (f$k2[z9pmdo[q6lh]] == b[37733]) {
                    var wlvie = Number(q6lh);
                    for (var bweg4a = 0x0; bweg4a < ewaiv[b[13]]; bweg4a++) {
                        if (ewaiv[bweg4a][0x0] == wlvie) {
                            ewaiv[bweg4a][0x1] = 0x1;
                            break;
                        }
                    }
                }
            }
            window['e1FYM$G'](window[b[37454]], b[37734]) >= 0x0 ? wx[b[37735]]({
                'withSubscriptions': !![],
                'success': function (gtf4ak) {
                    var iewlb = gtf4ak[b[37736]][b[37737]];
                    if (iewlb) {
                        console[b[543]](b[37738]), console[b[543]](iewlb);
                        for (var r3087y in z9pmdo) {
                            if (iewlb[z9pmdo[r3087y]] == b[37733]) {
                                var jf2k$x = Number(r3087y);
                                for (var c507 = 0x0; c507 < ewaiv[b[13]]; c507++) {
                                    if (ewaiv[c507][0x0] == jf2k$x) {
                                        ewaiv[c507][0x1] = 0x2;
                                        break;
                                    }
                                }
                            }
                        }
                        console[b[543]](ewaiv), h6s38q && h6s38q(ewaiv);
                    } else console[b[543]](b[37739]), console[b[543]](gtf4ak), console[b[543]](ewaiv), h6s38q && h6s38q(ewaiv);
                },
                'fail': function () {
                    console[b[543]](b[37740]), console[b[543]](ewaiv), h6s38q && h6s38q(ewaiv);
                }
            }) : (console[b[543]](b[37741] + window[b[37454]]), console[b[543]](ewaiv), h6s38q && h6s38q(ewaiv));
        })) : (console[b[543]](b[37742] + window[b[37454]]), console[b[543]](ewaiv), h6s38q && h6s38q(ewaiv)), wx[b[37743]](ozpxm);
    }
    wx[b[37744]](ozpxm);
}, window['e1G$MY'] = {
    'isSuccess': ![],
    'level': b[32621],
    'isCharging': ![]
}, window['e1GY$M'] = function (m2pox$) {
    wx[b[37521]]({
        'success': function (iwab) {
            var p2jo$ = window['e1G$MY'];
            p2jo$[b[37745]] = !![], p2jo$[b[4773]] = Number(iwab[b[4773]])[b[4351]](0x0), p2jo$[b[37524]] = iwab[b[37524]], m2pox$ && m2pox$(p2jo$[b[37745]], p2jo$[b[4773]], p2jo$[b[37524]]);
        },
        'fail': function (odxz) {
            console[b[543]](b[37746], odxz[b[27995]]);
            var bge4wa = window['e1G$MY'];
            m2pox$ && m2pox$(bge4wa[b[37745]], bge4wa[b[4773]], bge4wa[b[37524]]);
        }
    });
}, window[b[12527]] = function (jx$kf2) {
    wx[b[12527]]({
        'success': function (do9zp) {
            jx$kf2 && jx$kf2(!![], do9zp);
        },
        'fail': function (xjo2) {
            jx$kf2 && jx$kf2(![], xjo2);
        }
    });
}, window[b[12529]] = function (_c75ny) {
    if (_c75ny) wx[b[12529]](_c75ny);
}, window[b[27974]] = function (his6ql) {
    wx[b[27974]](his6ql);
}, window[b[23]] = function (tjgf4k, q8lsh, ilebwv, belwvi, $xjo2p, kgft$, wae4tg, liqhbv) {
    if (belwvi == undefined) belwvi = 0x1;
    wx[b[538]]({
        'url': tjgf4k,
        'method': wae4tg || b[27986],
        'responseType': b[4555],
        'data': q8lsh,
        'header': { 'content-type': liqhbv || b[37600] },
        'success': function (ivbeq) {
            DEBUG && console[b[543]](b[37747], tjgf4k, info, ivbeq);
            if (ivbeq && ivbeq[b[27993]] == 0xc8) {
                var tg4aw = ivbeq[b[11]];
                !kgft$ || kgft$(tg4aw) ? ilebwv && ilebwv(tg4aw) : window[b[37748]](tjgf4k, q8lsh, ilebwv, belwvi, $xjo2p, kgft$, ivbeq);
            } else window[b[37748]](tjgf4k, q8lsh, ilebwv, belwvi, $xjo2p, kgft$, ivbeq);
        },
        'fail': function (tagf) {
            DEBUG && console[b[543]](b[37749], tjgf4k, info, tagf), window[b[37748]](tjgf4k, q8lsh, ilebwv, belwvi, $xjo2p, kgft$, tagf);
        },
        'complete': function () {}
    });
}, window[b[37748]] = function ($fk2tj, o$mxp2, h6qlsi, iewa, jft2$, geaw4t, h8603) {
    iewa - 0x1 > 0x0 ? setTimeout(function () {
        window[b[23]]($fk2tj, o$mxp2, h6qlsi, iewa - 0x1, jft2$, geaw4t);
    }, 0x3e8) : jft2$ && jft2$(JSON[b[4647]]({
        'url': $fk2tj,
        'response': h8603
    }));
}, window[b[37750]] = function (m1dzo, iaew, tkjfg, lvbiq, $2kxfj, $t2kjf, q86sl) {
    !tkjfg && (tkjfg = {});
    var hiqsvl = Math[b[130]](Date[b[87]]() / 0x3e8);
    tkjfg[b[962]] = hiqsvl, tkjfg[b[37751]] = iaew;
    var tg4w = Object[b[288]](tkjfg)[b[1194]](),
        pfxj2 = '',
        xom2zp = '';
    for (var lhiq6s = 0x0; lhiq6s < tg4w[b[13]]; lhiq6s++) {
        pfxj2 = pfxj2 + (lhiq6s == 0x0 ? '' : '&') + tg4w[lhiq6s] + tkjfg[tg4w[lhiq6s]], xom2zp = xom2zp + (lhiq6s == 0x0 ? '' : '&') + tg4w[lhiq6s] + '=' + encodeURIComponent(tkjfg[tg4w[lhiq6s]]);
    }
    pfxj2 = pfxj2 + e1GM[b[37554]];
    var lhi6 = b[37752] + md5(pfxj2);
    send(m1dzo + '?' + xom2zp + (xom2zp == '' ? '' : '&') + lhi6, null, lvbiq, $2kxfj, $t2kjf, q86sl || function (lvqis) {
        return lvqis[b[1386]] == b[10246];
    }, null, b[37361]);
}, window['e1GYM$'] = function (q6s8h, od9mpz) {
    var e4aw = 0x0;
    e1GM[b[28376]] && (e4aw = e1GM[b[28376]][b[12142]]), sendApi(e1GM[b[37550]], b[37753], {
        'partnerId': e1GM[b[13167]],
        'gamePkg': e1GM[b[28382]],
        'logTime': Math[b[130]](Date[b[87]]() / 0x3e8),
        'platformUid': e1GM[b[28383]],
        'type': q6s8h,
        'serverId': e4aw
    }, null, 0x2, null, function () {
        return !![];
    });
}, window['e1GM$Y'] = function (tkj4g) {
    sendApi(e1GM[b[37548]], b[37754], {
        'partner_id': e1GM[b[13167]],
        'uid': e1GM[b[28380]],
        'version': e1GM[b[5498]],
        'game_pkg': e1GM[b[28382]],
        'device': e1GM[b[28384]]
    }, e1GMY$, e1YMG, e1M$);
}, window['e1GMY$'] = function (ihs) {
    if (ihs && ihs[b[1386]] === b[10246] && ihs[b[11]]) {
        ihs[b[11]][b[5689]]({
            'id': -0x2,
            'name': b[37755]
        }), ihs[b[11]][b[5689]]({
            'id': -0x1,
            'name': b[37756]
        }), e1GM[b[37757]] = ihs[b[11]];
        if (window[b[13360]]) window[b[13360]][b[37758]]();
    } else {
        e1GM[b[37759]] = ![];
        var z9m1d = ihs ? ihs[b[1386]] : '';
        window[b[37588]](0x7, b[37760] + z9m1d), window['e1$YGM'](b[37761] + z9m1d);
    }
}, window['e1$YG'] = function (ivweb) {
    sendApi(e1GM[b[37548]], b[37762], {
        'partner_id': e1GM[b[13167]],
        'uid': e1GM[b[28380]],
        'version': e1GM[b[5498]],
        'game_pkg': e1GM[b[28382]],
        'device': e1GM[b[28384]]
    }, e1$GY, e1YMG, e1M$);
}, window['e1$GY'] = function (op$2xj) {
    e1GM[b[37763]] = ![];
    if (op$2xj && op$2xj[b[1386]] === b[10246] && op$2xj[b[11]]) {
        for (var h8s30 = 0x0; h8s30 < op$2xj[b[11]][b[13]]; h8s30++) {
            op$2xj[b[11]][h8s30][b[116]] = e1GY$(op$2xj[b[11]][h8s30]);
        }
        e1GM[b[37557]][-0x1] = window[b[37764]](op$2xj[b[11]]), window[b[13360]][b[37765]](-0x1);
    } else {
        var wbaevi = op$2xj ? op$2xj[b[1386]] : '';
        window[b[37588]](0x8, b[37766] + wbaevi), window['e1$YGM'](b[37767] + wbaevi);
    }
}, window[b[37768]] = function (vbwli) {
    sendApi(e1GM[b[37548]], b[37762], {
        'partner_id': e1GM[b[13167]],
        'uid': e1GM[b[28380]],
        'version': e1GM[b[5498]],
        'game_pkg': e1GM[b[28382]],
        'device': e1GM[b[28384]]
    }, vbwli, e1YMG, e1M$);
}, window['e1Y$G'] = function ($k2tfj, is6qh) {
    sendApi(e1GM[b[37548]], b[37769], {
        'partner_id': e1GM[b[13167]],
        'uid': e1GM[b[28380]],
        'version': e1GM[b[5498]],
        'game_pkg': e1GM[b[28382]],
        'device': e1GM[b[28384]],
        'server_group_id': is6qh
    }, e1YG$, e1YMG, e1M$);
}, window['e1YG$'] = function (pmzo) {
    e1GM[b[37763]] = ![];
    if (pmzo && pmzo[b[1386]] === b[10246] && pmzo[b[11]] && pmzo[b[11]][b[11]]) {
        var tg$fjk = pmzo[b[11]][b[37770]],
            omxdp = [];
        for (var k$jtf = 0x0; k$jtf < pmzo[b[11]][b[11]][b[13]]; k$jtf++) {
            pmzo[b[11]][b[11]][k$jtf][b[116]] = e1GY$(pmzo[b[11]][b[11]][k$jtf]), (omxdp[b[13]] == 0x0 || pmzo[b[11]][b[11]][k$jtf][b[116]] != 0x0) && (omxdp[omxdp[b[13]]] = pmzo[b[11]][b[11]][k$jtf]);
        }
        e1GM[b[37557]][tg$fjk] = window[b[37764]](omxdp), window[b[13360]][b[37765]](tg$fjk);
    } else {
        var r5cy7n = pmzo ? pmzo[b[1386]] : '';
        window[b[37588]](0x9, b[37771] + r5cy7n), window['e1$YGM'](b[37772] + r5cy7n);
    }
}, window[b[37773]] = function (dxpomz) {
    sendApi(e1GM[b[37548]], b[37774], {
        'partner_id': e1GM[b[13167]],
        'uid': e1GM[b[28380]],
        'version': e1GM[b[5498]],
        'game_pkg': e1GM[b[28382]],
        'device': e1GM[b[28384]]
    }, reqServerRecommendCallBack, e1YMG, e1M$);
}, window[b[37775]] = function (p2zmo) {
    e1GM[b[37763]] = ![];
    if (p2zmo && p2zmo[b[1386]] === b[10246] && p2zmo[b[11]]) {
        for (var bawvei = 0x0; bawvei < p2zmo[b[11]][b[13]]; bawvei++) {
            p2zmo[b[11]][bawvei][b[116]] = e1GY$(p2zmo[b[11]][bawvei]);
        }
        e1GM[b[37557]][-0x2] = window[b[37764]](p2zmo[b[11]]), window[b[13360]][b[37765]](-0x2);
    } else {
        var e4ba = p2zmo ? p2zmo[b[1386]] : '';
        window[b[37588]](0xa, b[37776] + e4ba), alert(b[37777] + e4ba);
    }
}, window[b[37764]] = function (gtkj4f) {
    return gtkj4f;
}, window['e1G$Y'] = function ($mo2xp, kfgj$) {
    $mo2xp = $mo2xp || e1GM[b[28376]][b[12142]], sendApi(e1GM[b[37548]], b[37778], {
        'type': '4',
        'game_pkg': e1GM[b[28382]],
        'server_id': $mo2xp
    }, kfgj$);
}, window[b[37779]] = function (hbil, ftkag, ewva, c_7ny) {
    ewva = ewva || e1GM[b[28376]][b[12142]], sendApi(e1GM[b[37548]], b[37780], {
        'type': hbil,
        'game_pkg': ftkag,
        'server_id': ewva
    }, c_7ny);
}, window[b[37781]] = function (ktfag, ihqls) {
    sendApi(e1GM[b[37548]], b[37782], { 'game_pkg': ktfag }, ihqls);
}, window['e1GY$'] = function (wak4t) {
    if (wak4t) {
        if (wak4t[b[116]] == 0x1) {
            if (wak4t[b[37783]] == 0x3) return 0x3;else return wak4t[b[37783]] == 0x1 ? 0x2 : 0x1;
        } else return wak4t[b[116]] == 0x0 ? 0x0 : -0x1;
    }
    return -0x1;
}, window['e1M$YG'] = function (r7y53, qbeilv) {
    var jfg$ = window[b[37674]][b[37676]] == 0x1;
    if (jfg$) {
        var abiev = window[b[37674]][b[37688]],
            jfg$ = window[b[37674]][b[37676]] == 0x1;
        window[b[37453]][b[167]][b[37689]](b[37690], abiev, b[37691]);
        return;
    }
    e1GM[b[37784]] = {
        'step': r7y53,
        'server_id': qbeilv
    };
    var biqhv = this;
    e1$GYM({ 'title': b[37785] }), sendApi(e1GM[b[37548]], b[37786], {
        'partner_id': e1GM[b[13167]],
        'uid': e1GM[b[28380]],
        'game_pkg': e1GM[b[28382]],
        'server_id': qbeilv,
        'platform': e1GM[b[28334]],
        'platform_uid': e1GM[b[28383]],
        'check_login_time': e1GM[b[37647]],
        'check_login_sign': e1GM[b[37646]],
        'version_name': e1GM[b[4665]]
    }, e1M$GY, e1YMG, e1M$, function (qhilvb) {
        return qhilvb[b[1386]] == b[10246] || qhilvb[b[82]] == b[37787] || qhilvb[b[82]] == b[37788];
    });
}, window['e1M$GY'] = function (veqbli) {
    var hqlsvi = this;
    if (veqbli && veqbli[b[1386]] === b[10246] && veqbli[b[11]]) {
        var jop2x = e1GM[b[28376]];
        jop2x[b[37789]] = e1GM[b[37558]], jop2x[b[12125]] = String(veqbli[b[11]][b[37790]]), jop2x[b[28336]] = parseInt(veqbli[b[11]][b[962]]);
        if (veqbli[b[11]][b[28335]]) jop2x[b[28335]] = parseInt(veqbli[b[11]][b[28335]]);else jop2x[b[28335]] = parseInt(veqbli[b[11]][b[12142]]);
        jop2x[b[37791]] = 0x0, jop2x[b[4661]] = e1GM[b[37701]], jop2x[b[37792]] = veqbli[b[11]][b[37793]], jop2x[b[37794]] = veqbli[b[11]][b[37794]];
        if (veqbli[b[11]][b[28340]]) jop2x[b[28340]] = parseInt(veqbli[b[11]][b[28340]]);
        console[b[543]](b[37795] + JSON[b[4647]](jop2x[b[37794]])), e1GM[b[726]] == 0x1 && jop2x[b[37794]] && jop2x[b[37794]][b[37796]] == 0x1 && (e1GM[b[37797]] = 0x1, window[b[37453]][b[167]][b[37798]]()), e1MY$G();
    } else {
        if (e1GM[b[37784]][b[4578]] >= 0x3) {
            var lhbq = veqbli ? veqbli[b[1386]] : '';
            window[b[37588]](0xc, b[37799] + lhbq), e1M$(JSON[b[4647]](veqbli)), window['e1$YGM'](b[37800] + lhbq);
        } else sendApi(e1GM[b[37548]], b[37626], {
            'platform': e1GM[b[37546]],
            'partner_id': e1GM[b[13167]],
            'token': e1GM[b[37624]],
            'game_pkg': e1GM[b[28382]],
            'deviceId': e1GM[b[28384]],
            'scene': b[37627] + e1GM[b[37556]]
        }, function (q6ihls) {
            if (!q6ihls || q6ihls[b[1386]] != b[10246]) {
                window['e1$YGM'](b[37643] + q6ihls && q6ihls[b[1386]]);
                return;
            }
            e1GM[b[37646]] = String(q6ihls[b[12125]]), e1GM[b[37647]] = String(q6ihls[b[962]]), setTimeout(function () {
                e1M$YG(e1GM[b[37784]][b[4578]] + 0x1, e1GM[b[37784]][b[12142]]);
            }, 0x5dc);
        }, e1YMG, e1M$, function (ftkj$) {
            return ftkj$[b[1386]] == b[10246] || ftkj$[b[1386]] == b[28731];
        });
    }
}, window['e1MY$G'] = function () {
    ServerLoading[b[167]][b[37686]](e1GM[b[726]]), window[b[37565]] = !![], window['e1MG$Y']();
}, window['e1MYG$'] = function () {
    if (window[b[37473]] && window[b[37478]] && window[b[37566]] && window[b[37567]] && window[b[37568]] && window[b[37570]]) {
        if (!window[b[36907]][b[167]]) {
            console[b[543]](b[37801] + window[b[36907]][b[167]]);
            var zmxpdo = wx[b[27957]](),
                opz2m = zmxpdo[b[887]] ? zmxpdo[b[887]] : 0x0,
                hq8l = {
                'cdn': window[b[4664]][b[4661]],
                'spareCdn': window[b[4664]][b[28004]],
                'newRegister': window[b[4664]][b[726]],
                'wxPC': window[b[4664]][b[28007]],
                'wxIOS': window[b[4664]][b[1189]],
                'wxAndroid': window[b[4664]][b[11966]],
                'wxParam': {
                    'limitLoad': window[b[4664]]['e1F$YMG'],
                    'benchmarkLevel': window[b[4664]]['e1F$GYM'],
                    'wxFrom': window[b[619]][b[32611]] == b[37802] ? 0x1 : 0x0,
                    'wxSDKVersion': window[b[37454]],
                    'qudao': b[37803]
                },
                'configType': window[b[4664]][b[4663]],
                'exposeType': window[b[4664]][b[809]],
                'scene': opz2m,
                'video_type': window[b[4664]][b[28524]],
                'ad_flag': window[b[4664]][b[28523]]
            };
            if (window[b[37703]]) for (var gab4ew in window[b[37703]]) {
                if (!hq8l[gab4ew]) hq8l[gab4ew] = window[b[37703]][gab4ew];
            }
            new window[b[36907]](hq8l, window[b[4664]][b[110]], window['e1F$YGM']);
        }
    }
}, window['e1MG$Y'] = function () {
    if (window[b[37473]] && window[b[37478]] && window[b[37566]] && window[b[37567]] && window[b[37568]] && window[b[37570]] && window[b[37565]] && window[b[37569]]) {
        e1$GMY();
        if (!e1MYG) {
            e1MYG = !![];
            if (!window[b[36907]][b[167]]) window['e1MYG$']();
            var avwibe = 0x0,
                etwga4 = wx[b[37804]]();
            etwga4 && (window[b[4664]][b[37510]] && (avwibe = etwga4[b[373]]), console[b[82]](b[37805] + etwga4[b[373]] + b[37806] + etwga4[b[1406]] + b[37807] + etwga4[b[1408]] + b[37808] + etwga4[b[1407]] + b[37809] + etwga4[b[204]] + b[37810] + etwga4[b[205]]));
            var hs308 = {};
            for (const afgt4 in e1GM[b[28376]]) {
                hs308[afgt4] = e1GM[b[28376]][afgt4];
            }
            var vbawe = {
                'channel': window[b[4664]][b[13176]],
                'account': window[b[4664]][b[28380]],
                'userId': window[b[4664]][b[13165]],
                'cdn': window[b[4664]][b[4661]],
                'data': window[b[4664]][b[11]],
                'package': window[b[4664]][b[28005]],
                'newRegister': window[b[4664]][b[726]],
                'pkgName': window[b[4664]][b[28382]],
                'partnerId': window[b[4664]][b[13167]],
                'platform_uid': window[b[4664]][b[28383]],
                'deviceId': window[b[4664]][b[28384]],
                'selectedServer': hs308,
                'configType': window[b[4664]][b[4663]],
                'exposeType': window[b[4664]][b[809]],
                'debugUsers': window[b[4664]][b[13313]],
                'wxMenuTop': avwibe,
                'wxShield': window[b[4664]][b[831]],
                'encryptParam': window[b[4664]][b[28531]],
                'wx_channel': window[b[4664]][b[28529]],
                'zsy_tp_state': window[b[4664]][b[28530]]
            };
            if (window[b[37703]]) for (var mpz2 in window[b[37703]]) {
                vbawe[mpz2] = window[b[37703]][mpz2];
            }
            window[b[36907]][b[167]][b[28398]](vbawe);
            if (e1GM[b[28376]] && e1GM[b[28376]][b[12142]]) localStorage[b[546]](b[37649] + e1GM[b[28382]] + e1GM[b[28380]], e1GM[b[28376]][b[12142]]);
        }
    } else console[b[82]](b[37811] + window[b[37473]] + b[37812] + window[b[37478]] + b[37813] + window[b[37566]] + b[37814] + window[b[37567]] + b[37815] + window[b[37568]] + b[37816] + window[b[37570]] + b[37817] + window[b[37565]] + b[37818] + window[b[37569]]);
};