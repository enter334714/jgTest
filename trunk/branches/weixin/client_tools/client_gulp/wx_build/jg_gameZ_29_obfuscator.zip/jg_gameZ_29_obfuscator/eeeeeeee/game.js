var b = wx.$e;
import 'eeemain.js';