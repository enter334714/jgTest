var b = wx.$e;
require(b[38048]);