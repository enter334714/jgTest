var A = wx.$N;
console[A[200138]](A[200139]), window[A[200140]], wx[A[200141]](function (p90qi) {
  if (p90qi) {
    if (p90qi[A[200142]]) {
      var jfy9iq = window[A[200143]][A[200144]][A[200145]](new RegExp(/\./, 'g'), '_'),
          tb2w6 = p90qi[A[200142]],
          jfiqgy = tb2w6[A[200146]](/(nnnnnnnnn\/nnnGAME.js:)[0-9]{1,60}(:)/g);if (jfiqgy) for (var hldmkx = 0x0; hldmkx < jfiqgy[A[200147]]; hldmkx++) {
        if (jfiqgy[hldmkx] && jfiqgy[hldmkx][A[200147]] > 0x0) {
          var oa83e = parseInt(jfiqgy[hldmkx][A[200145]](A[200148], '')[A[200145]](':', ''));tb2w6 = tb2w6[A[200145]](jfiqgy[hldmkx], jfiqgy[hldmkx][A[200145]](':' + oa83e + ':', ':' + (oa83e - 0x2) + ':'));
        }
      }tb2w6 = tb2w6[A[200145]](new RegExp(A[200149], 'g'), A[200150] + jfy9iq + A[200151]), tb2w6 = tb2w6[A[200145]](new RegExp(A[200152], 'g'), A[200150] + jfy9iq + A[200151]), p90qi[A[200142]] = tb2w6;
    }var eawo26 = { 'id': window['_nWZ'][A[200153]], 'role': window['_nWZ'][A[200154]], 'level': window['_nWZ'][A[200155]], 'user': window['_nWZ'][A[200156]], 'version': window['_nWZ'][A[200157]], 'cdn': window['_nWZ'][A[200158]], 'pkgName': window['_nWZ'][A[200159]], 'gamever': window[A[200143]][A[200144]], 'serverid': window['_nWZ'][A[200160]] ? window['_nWZ'][A[200160]][A[200108]] : 0x0, 'systemInfo': window[A[200161]], 'error': A[200162], 'stack': p90qi ? p90qi[A[200142]] : '' },
        fgvyr3 = JSON[A[200163]](eawo26);console[A[200164]](A[200165] + fgvyr3), (!window[A[200140]] || window[A[200140]] != eawo26[A[200164]]) && (window[A[200140]] = eawo26[A[200164]], window['_n5W'](eawo26));
  }
});import 'nnnnMDadfa.js';import 'nnnasdf.js';window[A[200166]] = require(A[200167]);import 'nnnnnINDEX.js';import 'nnnLIBsdsa.js';import 'nnnnnWXMsad.js';import 'nnnnINITMIN.js';console[A[200138]](A[200168]), console[A[200138]](A[200169]), _n5W8Z({ 'title': A[200170] });var n_lmxkdh = { '_nK5ZW8': !![] };new window[A[200171]](n_lmxkdh), window[A[200171]][A[200172]]['_nK8WZ5']();if (window['_nK5WZ8']) clearInterval(window['_nK5WZ8']);window['_nK5WZ8'] = null, window['_nK8Z5W'] = function (vifyjg, hmkx_l) {
  if (!vifyjg || !hmkx_l) return 0x0;vifyjg = vifyjg[A[200173]]('.'), hmkx_l = hmkx_l[A[200173]]('.');const b2wo = Math[A[200174]](vifyjg[A[200147]], hmkx_l[A[200147]]);while (vifyjg[A[200147]] < b2wo) {
    vifyjg[A[200175]]('0');
  }while (hmkx_l[A[200147]] < b2wo) {
    hmkx_l[A[200175]]('0');
  }for (var w6b2ao = 0x0; w6b2ao < b2wo; w6b2ao++) {
    const qfijy = parseInt(vifyjg[w6b2ao]),
          gqifj = parseInt(hmkx_l[w6b2ao]);if (qfijy > gqifj) return 0x1;else {
      if (qfijy < gqifj) return -0x1;
    }
  }return 0x0;
}, window[A[200176]] = wx[A[200177]]()[A[200176]], console[A[200178]](A[200179] + window[A[200176]]);var n_sc075 = wx[A[200180]]();n_sc075[A[200181]](function (k_) {
  console[A[200178]](A[200182] + k_[A[200183]]);
}), n_sc075[A[200184]](function () {
  wx[A[200185]]({ 'title': A[200186], 'content': A[200187], 'showCancel': ![], 'success': function (jqfiyg) {
      n_sc075[A[200188]]();
    } });
}), n_sc075[A[200189]](function () {
  console[A[200178]](A[200190]);
}), window['_nK8ZW5'] = function () {
  console[A[200178]](A[200191]);var v8or = wx[A[200192]]({ 'name': A[200193], 'success': function (ijpq9) {
      console[A[200178]](A[200194]), console[A[200178]](ijpq9), ijpq9 && ijpq9[A[200195]] == A[200196] ? (window['_nZ8'] = !![], window['_nZ8W5'](), window['_nZW58']()) : setTimeout(function () {
        window['_nK8ZW5']();
      }, 0x1f4);
    }, 'fail': function (nmldzx) {
      console[A[200178]](A[200197]), console[A[200178]](nmldzx), setTimeout(function () {
        window['_nK8ZW5']();
      }, 0x1f4);
    } });v8or && v8or[A[200198]](v8fr3g => {});
}, window['_nKW5Z8'] = function () {
  console[A[200178]](A[200199]);var cs50p7 = wx[A[200192]]({ 'name': A[200200], 'success': function (lh_mk) {
      console[A[200178]](A[200201]), console[A[200178]](lh_mk), lh_mk && lh_mk[A[200195]] == A[200196] ? (window['_nW8Z'] = !![], window['_nZ8W5'](), window['_nZW58']()) : setTimeout(function () {
        window['_nKW5Z8']();
      }, 0x1f4);
    }, 'fail': function (_mkx) {
      console[A[200178]](A[200202]), console[A[200178]](_mkx), setTimeout(function () {
        window['_nKW5Z8']();
      }, 0x1f4);
    } });cs50p7 && cs50p7[A[200198]](qj9iyf => {});
}, window[A[200203]] = function () {
  window['_nK8Z5W'](window[A[200176]], A[200204]) >= 0x0 ? (console[A[200178]](A[200205] + window[A[200176]] + A[200206]), window['_nW5'](), window['_nK8ZW5'](), window['_nKW5Z8']()) : (window['_nWZ5'](A[200207], window[A[200176]]), wx[A[200185]]({ 'title': A[200208], 'content': A[200209] }));
}, window[A[200161]] = '', wx[A[200210]]({ 'success'(hzxdml) {
    window[A[200161]] = A[200211] + hzxdml[A[200212]] + A[200213] + hzxdml[A[200214]] + A[200215] + hzxdml[A[200216]] + A[200217] + hzxdml[A[200218]] + A[200219] + hzxdml[A[200220]] + A[200221] + hzxdml[A[200176]] + A[200222] + hzxdml[A[200223]], console[A[200178]](window[A[200161]]), console[A[200178]](A[200224] + hzxdml[A[200225]] + A[200226] + hzxdml[A[200227]] + A[200228] + hzxdml[A[200229]] + A[200230] + hzxdml[A[200231]] + A[200232] + hzxdml[A[200233]] + A[200234] + hzxdml[A[200235]] + A[200236] + (hzxdml[A[200237]] ? hzxdml[A[200237]][A[200238]] + ',' + hzxdml[A[200237]][A[200239]] + ',' + hzxdml[A[200237]][A[200240]] + ',' + hzxdml[A[200237]][A[200241]] : ''));var k1u$ = hzxdml[A[200218]] ? hzxdml[A[200218]][A[200242]]() : '',
        gve = hzxdml[A[200214]] ? hzxdml[A[200214]][A[200242]]()[A[200145]]('\x20', '') : '';window['_nWZ'][A[200243]] = k1u$[A[200244]](A[200245]) != -0x1, window['_nWZ'][A[200246]] = k1u$[A[200244]](A[200033]) != -0x1, window['_nWZ'][A[200247]] = k1u$[A[200244]](A[200245]) != -0x1 || k1u$[A[200244]](A[200033]) != -0x1, window['_nWZ'][A[200248]] = k1u$[A[200244]](A[200047]) != -0x1 || k1u$[A[200244]](A[200249]) != -0x1, window['_nWZ'][A[200250]] = hzxdml[A[200220]] ? hzxdml[A[200220]][A[200242]]() : '', window['_nWZ']['_nK58ZW'] = ![], window['_nWZ']['_nK5W8Z'] = 0x2;if (k1u$[A[200244]](A[200033]) != -0x1) {
      if (hzxdml[A[200223]] >= 0x18) window['_nWZ']['_nK5W8Z'] = 0x3;else window['_nWZ']['_nK5W8Z'] = 0x2;
    } else {
      if (k1u$[A[200244]](A[200245]) != -0x1) {
        if (hzxdml[A[200223]] && hzxdml[A[200223]] >= 0x14) window['_nWZ']['_nK5W8Z'] = 0x3;else {
          if (gve[A[200244]](A[200251]) != -0x1 || gve[A[200244]](A[200252]) != -0x1 || gve[A[200244]](A[200253]) != -0x1 || gve[A[200244]](A[200254]) != -0x1 || gve[A[200244]](A[200255]) != -0x1) window['_nWZ']['_nK5W8Z'] = 0x2;else window['_nWZ']['_nK5W8Z'] = 0x3;
        }
      } else window['_nWZ']['_nK5W8Z'] = 0x2;
    }console[A[200178]](A[200256] + window['_nWZ']['_nK58ZW'] + A[200257] + window['_nWZ']['_nK5W8Z']);
  } }), wx[A[200258]]({ 'success': function (dznlsx) {
    console[A[200178]](A[200259] + dznlsx[A[200260]] + A[200261] + dznlsx[A[200262]]);
  } }), wx[A[200263]]({ 'success': function (r3fvy) {
    console[A[200178]](A[200264] + r3fvy[A[200265]]);
  } }), wx[A[200266]]({ 'keepScreenOn': !![] }), wx[A[200267]](function (ns75c0) {
  console[A[200178]](A[200264] + ns75c0[A[200265]] + A[200268] + ns75c0[A[200269]]);
}), wx[A[200270]](function (nslzx) {
  window['_n85'] = nslzx, window['_nZ58'] && window['_n85'] && (console[A[200138]](A[200271] + window['_n85'][A[200272]]), window['_nZ58'](window['_n85']), window['_n85'] = null);
}), window[A[200273]] = 0x0, window['_nKW8Z5'] = 0x0, window[A[200274]] = null, wx[A[200275]](function () {
  window['_nKW8Z5']++;var j90pq = Date[A[200276]]();(window[A[200273]] == 0x0 || j90pq - window[A[200273]] > 0x1d4c0) && (console[A[200277]](A[200278]), wx[A[200279]]());if (window['_nKW8Z5'] >= 0x2) {
    window['_nKW8Z5'] = 0x0, console[A[200164]](A[200280]), wx[A[200281]]('0', 0x1);if (window['_nWZ'] && window['_nWZ'][A[200243]]) window['_nWZ5'](A[200282], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});