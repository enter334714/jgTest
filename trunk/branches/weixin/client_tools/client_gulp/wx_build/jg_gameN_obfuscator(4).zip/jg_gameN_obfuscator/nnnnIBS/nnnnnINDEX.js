var A = wx.$N;
import n_k$u1_ from '../nnnkkk/nnnnSsdk.js';window[A[200696]] = { 'wxVersion': window[A[200143]][A[200144]] }, window[A[200697]] = ![], window['_nZW'] = 0x1, window[A[200698]] = 0x1, window['_n8WZ'] = !![], window[A[200699]] = !![], window['_nK58WZ'] = '', window['_nWZ'] = { 'base_cdn': A[200700], 'cdn': A[200700] }, _nWZ[A[200701]] = {}, _nWZ[A[200702]] = '0', _nWZ[A[200216]] = window[A[200696]][A[200482]], _nWZ[A[200249]] = '', _nWZ['os'] = '1', _nWZ['sdk_name'] = A[200703], _nWZ[A[200704]] = A[200705], _nWZ[A[200706]] = A[200707], _nWZ[A[200708]] = A[200709], _nWZ[A[200710]] = A[200711], _nWZ[A[200712]] = '1', _nWZ[A[200159]] = '', _nWZ[A[200713]] = '', _nWZ[A[200714]] = 0x0, _nWZ[A[200571]] = {}, _nWZ[A[200715]] = parseInt(_nWZ[A[200712]]), _nWZ[A[200716]] = _nWZ[A[200712]], _nWZ[A[200160]] = {}, _nWZ['_n5W'] = A[200717], _nWZ[A[200718]] = ![], _nWZ[A[200719]] = A[200720], _nWZ[A[200721]] = Date[A[200276]](), _nWZ[A[200722]] = A[200723], _nWZ[A[200724]] = '_a', _nWZ[A[200468]] = 0x2, _nWZ[A[200157]] = 0x7c1, _nWZ[A[200482]] = window[A[200696]][A[200482]], _nWZ[A[200725]] = ![], _nWZ[A[200243]] = ![], _nWZ[A[200246]] = ![], _nWZ[A[200248]] = ![], window['_n8ZW'] = 0x5, window['_n8Z'] = ![], window['_nZ8'] = ![], window['_nW8Z'] = ![], window[A[200648]] = ![], window[A[200651]] = ![], window['_nWZ8'] = ![], window['_n8W'] = ![], window['_nW8'] = ![], window['_nZ8W'] = ![], window[A[200726]] = function (s75czn) {
  console[A[200178]](A[200726], s75czn), wx[A[200727]]({}), wx[A[200185]]({ 'title': A[200208], 'content': s75czn, 'success'(c09) {
      if (c09[A[200728]]) console[A[200178]](A[200729]);else c09[A[200730]] && console[A[200178]](A[200731]);
    } });
}, window['_n58WZ'] = function (jiygfq) {
  console[A[200178]](A[200732], jiygfq), _n5WZ8(), wx[A[200185]]({ 'title': A[200208], 'content': jiygfq, 'confirmText': A[200733], 'cancelText': A[200734], 'success'(dzlhxm) {
      if (dzlhxm[A[200728]]) window['_nW5']();else dzlhxm[A[200730]] && (console[A[200178]](A[200735]), wx[A[200736]]({}));
    } });
}, window[A[200737]] = function (dhxzml) {
  console[A[200178]](A[200737], dhxzml), wx[A[200185]]({ 'title': A[200208], 'content': dhxzml, 'confirmText': A[200738], 'showCancel': ![], 'complete'(nd7sz) {
      console[A[200178]](A[200735]), wx[A[200736]]({});
    } });
}, window['_n58ZW'] = ![], window['_n5W8Z'] = function (dcnzs) {
  window['_n58ZW'] = !![], wx[A[200739]](dcnzs);
}, window['_n5WZ8'] = function () {
  window['_n58ZW'] && (window['_n58ZW'] = ![], wx[A[200727]]({}));
}, window['_n5Z8W'] = function ($_4khm) {
  window[A[200171]][A[200172]]['_n5Z8W']($_4khm);
}, window[A[200131]] = function (vyfijg, zn7cd) {
  n_k$u1_[A[200131]](vyfijg, function (k_hxml) {
    k_hxml && k_hxml[A[200581]] ? k_hxml[A[200581]][A[200580]] == 0x1 ? zn7cd(!![]) : (zn7cd(![]), console[A[200138]](A[200740] + k_hxml[A[200581]][A[200741]])) : console[A[200178]](A[200131], k_hxml);
  });
}, window['_n5ZW8'] = function (woa6) {
  console[A[200178]](A[200742], woa6);
}, window['_n5WZ'] = function (mxlkhd) {}, window['_n5ZW'] = function (kmxhdl, yfrgvi, ver8o) {}, window['_n5Z'] = function (mkl) {
  console[A[200178]](A[200743], mkl), window[A[200171]][A[200172]][A[200472]](), window[A[200171]][A[200172]][A[200473]](), window[A[200171]][A[200172]][A[200486]]();
}, window['_nZ5'] = function (ae23o) {
  window['_n58WZ'](A[200744]);var ygfv3r = { 'id': window['_nWZ'][A[200153]], 'role': window['_nWZ'][A[200154]], 'level': window['_nWZ'][A[200155]], 'account': window['_nWZ'][A[200156]], 'version': window['_nWZ'][A[200157]], 'cdn': window['_nWZ'][A[200158]], 'pkgName': window['_nWZ'][A[200159]], 'gamever': window[A[200143]][A[200144]], 'serverid': window['_nWZ'][A[200160]] ? window['_nWZ'][A[200160]][A[200108]] : 0x0, 'systemInfo': window[A[200161]], 'error': A[200745], 'stack': ae23o ? ae23o : A[200744] },
      _$4uh = JSON[A[200163]](ygfv3r);console[A[200164]](A[200746] + _$4uh), window['_n5W'](_$4uh);
}, window['_nW5Z'] = function (sncxd) {
  var aw2t = JSON[A[200747]](sncxd);aw2t[A[200748]] = window[A[200143]][A[200144]], aw2t[A[200749]] = window['_nWZ'][A[200160]] ? window['_nWZ'][A[200160]][A[200108]] : 0x0, aw2t[A[200161]] = window[A[200161]];var h4_$k = JSON[A[200163]](aw2t);console[A[200164]](A[200750] + h4_$k), window['_n5W'](h4_$k);
}, window['_nWZ5'] = function (mlh$k_, $_4k) {
  var cnzdx = { 'id': window['_nWZ'][A[200153]], 'role': window['_nWZ'][A[200154]], 'level': window['_nWZ'][A[200155]], 'account': window['_nWZ'][A[200156]], 'version': window['_nWZ'][A[200157]], 'cdn': window['_nWZ'][A[200158]], 'pkgName': window['_nWZ'][A[200159]], 'gamever': window[A[200143]][A[200144]], 'serverid': window['_nWZ'][A[200160]] ? window['_nWZ'][A[200160]][A[200108]] : 0x0, 'systemInfo': window[A[200161]], 'error': mlh$k_, 'stack': $_4k },
      sxd = JSON[A[200163]](cnzdx);console[A[200277]](A[200751] + sxd), window['_n5W'](sxd);
}, window['_n5W'] = function (r3yvfg) {
  if (window['_nWZ'][A[200250]] == A[200752]) return;var csnzd = _nWZ['_n5W'] + A[200753] + _nWZ[A[200156]];wx[A[200754]]({ 'url': csnzd, 'method': A[200004], 'data': r3yvfg, 'header': { 'content-type': A[200755], 'cache-control': A[200756] }, 'success': function (kh$) {
      DEBUG && console[A[200178]](A[200757], csnzd, r3yvfg, kh$);
    }, 'fail': function (ow6ae2) {
      DEBUG && console[A[200178]](A[200757], csnzd, r3yvfg, ow6ae2);
    }, 'complete': function () {} });
}, window[A[200758]] = function () {
  function ba2o6() {
    return ((0x1 + Math[A[200475]]()) * 0x10000 | 0x0)[A[200759]](0x10)[A[200760]](0x1);
  }return ba2o6() + ba2o6() + '-' + ba2o6() + '-' + ba2o6() + '-' + ba2o6() + '+' + ba2o6() + ba2o6() + ba2o6();
}, window['_nW5'] = function () {
  console[A[200178]](A[200761]);var iqyj9 = n_k$u1_[A[200762]]();_nWZ[A[200716]] = iqyj9[A[200763]], _nWZ[A[200715]] = iqyj9[A[200763]], _nWZ[A[200712]] = iqyj9[A[200763]], _nWZ[A[200159]] = iqyj9[A[200764]];var gf8vr3 = { 'game_ver': _nWZ[A[200216]] };_nWZ[A[200713]] = this[A[200758]](), _n5W8Z({ 'title': A[200765] }), n_k$u1_[A[200126]](gf8vr3, this['_nZ5W'][A[200479]](this));
}, window['_nZ5W'] = function (j0qp5) {
  var qp9iyj = j0qp5[A[200766]];console[A[200178]](A[200767] + qp9iyj + A[200768] + (qp9iyj == 0x1) + A[200769] + j0qp5[A[200144]] + A[200770] + window[A[200696]][A[200482]]);if (!j0qp5[A[200144]] || window['_nK8Z5W'](window[A[200696]][A[200482]], j0qp5[A[200144]]) < 0x0) console[A[200178]](A[200771]), _nWZ[A[200704]] = A[200772], _nWZ[A[200706]] = A[200773], _nWZ[A[200708]] = A[200774], _nWZ[A[200158]] = A[200775], _nWZ[A[200776]] = A[200777], _nWZ['version_name'] = 'kl', _nWZ[A[200725]] = ![];else window['_nK8Z5W'](window[A[200696]][A[200482]], j0qp5[A[200144]]) == 0x0 ? (console[A[200178]](A[200778]), _nWZ[A[200704]] = A[200705], _nWZ[A[200706]] = A[200707], _nWZ[A[200708]] = A[200709], _nWZ[A[200158]] = A[200779], _nWZ[A[200776]] = A[200777], _nWZ['version_name'] = A[200780], _nWZ[A[200725]] = !![]) : (console[A[200178]](A[200781]), _nWZ[A[200704]] = A[200705], _nWZ[A[200706]] = A[200707], _nWZ[A[200708]] = A[200709], _nWZ[A[200158]] = A[200779], _nWZ[A[200776]] = A[200777], _nWZ['version_name'] = A[200780], _nWZ[A[200725]] = ![]);_nWZ[A[200714]] = config[A[200782]] ? config[A[200782]] : 0x0, this['_n8W5Z'](), this['_n8WZ5'](), window[A[200783]] = 0x5, _n5W8Z({ 'title': A[200784] }), n_k$u1_[A[200056]](this['_nZW5'][A[200479]](this));
}, window[A[200783]] = 0x5, window['_nZW5'] = function (ip0, xdhm) {
  if (ip0 == 0x0 && xdhm && xdhm[A[200785]]) {
    _nWZ[A[200786]] = xdhm[A[200785]];var cz7snd = this;_n5W8Z({ 'title': A[200787] }), sendApi(_nWZ[A[200704]], A[200788], { 'platform': _nWZ['sdk_name'], 'partner_id': _nWZ[A[200712]], 'token': xdhm[A[200785]], 'game_pkg': _nWZ[A[200159]], 'deviceId': _nWZ[A[200713]], 'scene': A[200789] + _nWZ[A[200714]] }, this['_n85WZ'][A[200479]](this), _n8ZW, _nZ5);
  } else xdhm && xdhm[A[200195]] && window[A[200783]] > 0x0 && (xdhm[A[200195]][A[200244]](A[200790]) != -0x1 || xdhm[A[200195]][A[200244]](A[200791]) != -0x1 || xdhm[A[200195]][A[200244]](A[200792]) != -0x1 || xdhm[A[200195]][A[200244]](A[200793]) != -0x1 || xdhm[A[200195]][A[200244]](A[200794]) != -0x1 || xdhm[A[200195]][A[200244]](A[200795]) != -0x1) ? (window[A[200783]]--, n_k$u1_[A[200056]](this['_nZW5'][A[200479]](this))) : (window['_nWZ5'](A[200796], JSON[A[200163]]({ 'status': ip0, 'data': xdhm })), window['_n58WZ'](A[200797] + (xdhm && xdhm[A[200195]] ? '，' + xdhm[A[200195]] : '')));
}, window['_n85WZ'] = function (pq50j) {
  if (!pq50j) {
    window['_nWZ5'](A[200798], A[200799]), window['_n58WZ'](A[200800]);return;
  }if (pq50j[A[200580]] != A[200579]) {
    window['_nWZ5'](A[200798], JSON[A[200163]](pq50j)), window['_n58WZ'](A[200801] + pq50j[A[200580]]);return;
  }_nWZ[A[200802]] = String(pq50j[A[200156]]), _nWZ[A[200156]] = String(pq50j[A[200156]]), _nWZ[A[200220]] = String(pq50j[A[200220]]), _nWZ[A[200716]] = String(pq50j[A[200220]]), _nWZ[A[200803]] = String(pq50j[A[200803]]), _nWZ[A[200804]] = String(pq50j[A[200019]]), _nWZ[A[200805]] = String(pq50j[A[200806]]), _nWZ[A[200019]] = '';var nszc = this;_n5W8Z({ 'title': A[200807] }), sendApi(_nWZ[A[200704]], A[200808], { 'partner_id': _nWZ[A[200712]], 'uid': _nWZ[A[200156]], 'version': _nWZ[A[200216]], 'game_pkg': _nWZ[A[200159]], 'device': _nWZ[A[200713]] }, nszc['_n85ZW'][A[200479]](nszc), _n8ZW, _nZ5);
}, window['_n85ZW'] = function (iyjfgq) {
  if (!iyjfgq) {
    window['_n58WZ'](A[200809]);return;
  }if (iyjfgq[A[200580]] != A[200579]) {
    window['_n58WZ'](A[200810] + iyjfgq[A[200580]]);return;
  }if (!iyjfgq[A[200581]] || iyjfgq[A[200581]][A[200147]] == 0x0) {
    window['_n58WZ'](A[200811]);return;
  }_nWZ[A[200657]] = iyjfgq['is_new'], _nWZ[A[200160]] = { 'server_id': String(iyjfgq[A[200581]][0x0][A[200108]]), 'server_name': String(iyjfgq[A[200581]][0x0]['server_name']), 'entry_ip': iyjfgq[A[200581]][0x0][A[200812]], 'entry_port': parseInt(iyjfgq[A[200581]][0x0][A[200813]]), 'status': _nW85(iyjfgq[A[200581]][0x0]), 'start_time': iyjfgq[A[200581]][0x0][A[200814]], 'cdn': _nWZ[A[200158]] }, this['_nZW85']();
}, window['_nZW85'] = function () {
  if (_nWZ[A[200657]] == 0x1) {
    var dxlzn = _nWZ[A[200160]][A[200559]];if (dxlzn === -0x1 || dxlzn === 0x0) {
      window['_n58WZ'](dxlzn === -0x1 ? A[200815] : A[200816]);return;
    }_nZ58W(0x0, _nWZ[A[200160]][A[200108]]), window[A[200171]][A[200172]][A[200652]](_nWZ[A[200657]]);
  } else window[A[200171]][A[200172]][A[200649]](), _n5WZ8();window['_nW8'] = !![], window['_nZ8W5'](), window['_nZW58']();
}, window['_n8W5Z'] = function () {
  sendApi(_nWZ[A[200704]], A[200817], { 'game_pkg': _nWZ[A[200159]], 'version_name': _nWZ['version_name'] }, this[A[200818]][A[200479]](this), _n8ZW, _nZ5);
}, window[A[200818]] = function (xznml) {
  if (!xznml) {
    window['_n58WZ'](A[200819]);return;
  }if (xznml[A[200580]] != A[200579]) {
    window['_n58WZ'](A[200820] + xznml[A[200580]]);return;
  }if (!xznml[A[200581]] || !xznml[A[200581]][A[200216]]) {
    window['_n58WZ'](A[200821] + (xznml[A[200581]] && xznml[A[200581]][A[200216]]));return;
  }xznml[A[200581]][A[200822]] && xznml[A[200581]][A[200822]][A[200147]] > 0xa && (_nWZ[A[200823]] = xznml[A[200581]][A[200822]], _nWZ[A[200158]] = xznml[A[200581]][A[200822]]), xznml[A[200581]][A[200216]] && (_nWZ[A[200157]] = xznml[A[200581]][A[200216]]), console[A[200138]](A[200824] + _nWZ[A[200157]] + ', version_name:' + _nWZ['version_name']), window['_nWZ8'] = !![], window['_nZ8W5'](), window['_nZW58']();
}, window[A[200825]], window['_n8WZ5'] = function () {
  sendApi(_nWZ[A[200704]], A[200826], { 'game_pkg': _nWZ[A[200159]] }, this['_n8Z5W'][A[200479]](this), _n8ZW, _nZ5);
}, window['_n8Z5W'] = function (c905p7) {
  if (c905p7[A[200580]] === A[200579] && c905p7[A[200581]]) {
    window[A[200825]] = c905p7[A[200581]];for (var vfgiry in c905p7[A[200581]]) {
      _nWZ[vfgiry] = c905p7[A[200581]][vfgiry];
    }
  } else console[A[200138]](A[200827] + c905p7[A[200580]]);window['_n8W'] = !![], window['_nZW58']();
}, window[A[200828]] = function (cnzs7d, pji0, _4hm$k, ml$_hk, v3eor8, dhkm, nzldsx, pj0, zsdln) {
  v3eor8 = String(v3eor8);var klmx_h = nzldsx,
      nmzd = pj0;_nWZ[A[200701]][v3eor8] = { 'productid': v3eor8, 'productname': klmx_h, 'productdesc': nmzd, 'roleid': cnzs7d, 'rolename': pji0, 'rolelevel': _4hm$k, 'price': dhkm, 'callback': zsdln }, sendApi(_nWZ[A[200708]], A[200829], { 'game_pkg': _nWZ[A[200159]], 'server_id': _nWZ[A[200160]][A[200108]], 'server_name': _nWZ[A[200160]]['server_name'], 'level': _4hm$k, 'uid': _nWZ[A[200156]], 'role_id': cnzs7d, 'role_name': pji0, 'product_id': v3eor8, 'product_name': klmx_h, 'product_desc': nmzd, 'money': dhkm, 'partner_id': _nWZ[A[200712]] }, toPayCallBack, _n8ZW, _nZ5);
}, window[A[200830]] = function (jp9y) {
  if (jp9y) {
    if (jp9y[A[200831]] === 0xc8 || jp9y[A[200580]] == A[200579]) {
      var a2o8e6 = _nWZ[A[200701]][String(jp9y[A[200832]])];if (a2o8e6[A[200833]]) a2o8e6[A[200833]](jp9y[A[200832]], jp9y[A[200834]], -0x1);n_k$u1_[A[200095]]({ 'cpbill': jp9y[A[200834]], 'productid': jp9y[A[200832]], 'productname': a2o8e6[A[200835]], 'productdesc': a2o8e6[A[200836]], 'serverid': _nWZ[A[200160]][A[200108]], 'servername': _nWZ[A[200160]]['server_name'], 'roleid': a2o8e6[A[200837]], 'rolename': a2o8e6[A[200838]], 'rolelevel': a2o8e6[A[200839]], 'price': a2o8e6[A[200840]], 'extension': JSON[A[200163]]({ 'cp_order_id': jp9y[A[200834]] }) }, function (dlnmzx, j9iqp0) {
        a2o8e6[A[200833]] && dlnmzx == 0x0 && a2o8e6[A[200833]](jp9y[A[200832]], jp9y[A[200834]], dlnmzx);console[A[200138]](JSON[A[200163]]({ 'type': A[200841], 'status': dlnmzx, 'data': jp9y, 'role_name': a2o8e6[A[200838]] }));if (dlnmzx === 0x0) {} else {
          if (dlnmzx === 0x1) {} else {
            if (dlnmzx === 0x2) {}
          }
        }
      });
    } else alert(jp9y[A[200138]]);
  }
}, window['_n8ZW5'] = function () {}, window['_n58Z'] = function (p05q97, s0pc75, ns057c, y3fvgr, q95j) {
  n_k$u1_[A[200128]](_nWZ[A[200160]][A[200108]], _nWZ[A[200160]]['server_name'] || _nWZ[A[200160]][A[200108]], p05q97, s0pc75, ns057c), sendApi(_nWZ[A[200704]], A[200842], { 'game_pkg': _nWZ[A[200159]], 'server_id': _nWZ[A[200160]][A[200108]], 'role_id': p05q97, 'uid': _nWZ[A[200156]], 'role_name': s0pc75, 'role_type': y3fvgr, 'level': ns057c });
}, window['_n5Z8'] = function (ivgjy, nmldx, km_lhx, hdlk, hxld, slzndx, evg83, ev3or, fqg, dlxs) {
  _nWZ[A[200153]] = ivgjy, _nWZ[A[200154]] = nmldx, _nWZ[A[200155]] = km_lhx, n_k$u1_[A[200129]](_nWZ[A[200160]][A[200108]], _nWZ[A[200160]]['server_name'] || _nWZ[A[200160]][A[200108]], ivgjy, nmldx, km_lhx), sendApi(_nWZ[A[200704]], A[200843], { 'game_pkg': _nWZ[A[200159]], 'server_id': _nWZ[A[200160]][A[200108]], 'role_id': ivgjy, 'uid': _nWZ[A[200156]], 'role_name': nmldx, 'role_type': hdlk, 'level': km_lhx, 'evolution': hxld });
}, window['_n85Z'] = function (lhzdmx, qyj9if, yjgvf, nldsz, gyfrv3, reo, u_4k$h, c70p5, q7950p, dnsz7c) {
  _nWZ[A[200153]] = lhzdmx, _nWZ[A[200154]] = qyj9if, _nWZ[A[200155]] = yjgvf, n_k$u1_[A[200130]](_nWZ[A[200160]][A[200108]], _nWZ[A[200160]]['server_name'] || _nWZ[A[200160]][A[200108]], lhzdmx, qyj9if, yjgvf), sendApi(_nWZ[A[200704]], A[200843], { 'game_pkg': _nWZ[A[200159]], 'server_id': _nWZ[A[200160]][A[200108]], 'role_id': lhzdmx, 'uid': _nWZ[A[200156]], 'role_name': qyj9if, 'role_type': nldsz, 'level': yjgvf, 'evolution': gyfrv3 });
}, window['_n8Z5'] = function (snldxz) {}, window['_n58'] = function (j9ifqy) {
  n_k$u1_[A[200076]](A[200076], function (aw2e6) {
    j9ifqy && j9ifqy(aw2e6);
  });
}, window[A[200127]] = function () {
  n_k$u1_[A[200127]]();
}, window[A[200844]] = function () {
  n_k$u1_[A[200134]]();
}, window[A[200270]] = function (oa38e2) {
  window['_nZ58'] = oa38e2, window['_nZ58'] && window['_n85'] && (console[A[200138]](A[200271] + window['_n85'][A[200272]]), window['_nZ58'](window['_n85']), window['_n85'] = null);
}, window['_nZ85'] = function (czsdx, _lkhx, oea68, mzhldx) {
  window[A[200845]](A[200846], { 'game_pkg': window['_nWZ'][A[200159]], 'role_id': _lkhx, 'server_id': oea68 }, mzhldx);
}, window['_nW58Z'] = function (i0j9pq, lmhz) {
  function hk_u4$(jify) {
    var mk$lh = [],
        qyj9ip = [],
        eg8vr3 = window[A[200143]][A[200847]];for (var szc7 in eg8vr3) {
      var p09ij = Number(szc7);(!i0j9pq || !i0j9pq[A[200147]] || i0j9pq[A[200244]](p09ij) != -0x1) && (qyj9ip[A[200175]](eg8vr3[szc7]), mk$lh[A[200175]]([p09ij, 0x3]));
    }window['_nK8Z5W'](window[A[200176]], A[200848]) >= 0x0 ? (console[A[200178]](A[200849]), n_k$u1_[A[200850]] && n_k$u1_[A[200850]](qyj9ip, function (r3gfv8) {
      console[A[200178]](A[200851]), console[A[200178]](r3gfv8);if (r3gfv8 && r3gfv8[A[200195]] == A[200852]) for (var sz7ncd in eg8vr3) {
        if (r3gfv8[eg8vr3[sz7ncd]] == A[200853]) {
          var jvgf = Number(sz7ncd);for (var mhxzd = 0x0; mhxzd < mk$lh[A[200147]]; mhxzd++) {
            if (mk$lh[mhxzd][0x0] == jvgf) {
              mk$lh[mhxzd][0x1] = 0x1;break;
            }
          }
        }
      }window['_nK8Z5W'](window[A[200176]], A[200854]) >= 0x0 ? wx[A[200855]]({ 'withSubscriptions': !![], 'success': function (q9jif) {
          var tw6b = q9jif[A[200856]][A[200857]];if (tw6b) {
            console[A[200178]](A[200858]), console[A[200178]](tw6b);for (var s5c7n0 in eg8vr3) {
              if (tw6b[eg8vr3[s5c7n0]] == A[200853]) {
                var gifjyq = Number(s5c7n0);for (var jgyi = 0x0; jgyi < mk$lh[A[200147]]; jgyi++) {
                  if (mk$lh[jgyi][0x0] == gifjyq) {
                    mk$lh[jgyi][0x1] = 0x2;break;
                  }
                }
              }
            }console[A[200178]](mk$lh), lmhz && lmhz(mk$lh);
          } else console[A[200178]](A[200859]), console[A[200178]](q9jif), console[A[200178]](mk$lh), lmhz && lmhz(mk$lh);
        }, 'fail': function () {
          console[A[200178]](A[200860]), console[A[200178]](mk$lh), lmhz && lmhz(mk$lh);
        } }) : (console[A[200178]](A[200861] + window[A[200176]]), console[A[200178]](mk$lh), lmhz && lmhz(mk$lh));
    })) : (console[A[200178]](A[200862] + window[A[200176]]), console[A[200178]](mk$lh), lmhz && lmhz(mk$lh)), wx[A[200863]](hk_u4$);
  }wx[A[200864]](hk_u4$);
}, window['_nW5Z8'] = { 'isSuccess': ![], 'level': A[200865], 'isCharging': ![] }, window['_nW85Z'] = function (_1$u4) {
  wx[A[200258]]({ 'success': function (khl_) {
      var dszc = window['_nW5Z8'];dszc[A[200866]] = !![], dszc[A[200260]] = Number(khl_[A[200260]])[A[200867]](0x0), dszc[A[200262]] = khl_[A[200262]], _1$u4 && _1$u4(dszc[A[200866]], dszc[A[200260]], dszc[A[200262]]);
    }, 'fail': function (k_hm$l) {
      console[A[200178]](A[200868], k_hm$l[A[200195]]);var cns5z = window['_nW5Z8'];_1$u4 && _1$u4(cns5z[A[200866]], cns5z[A[200260]], cns5z[A[200262]]);
    } });
}, window[A[200845]] = function (ar83eo, _lhm, rea38, jpq509, dkmhlx, yfgjq, cdsx, a2ob6) {
  if (jpq509 == undefined) jpq509 = 0x1;wx[A[200754]]({ 'url': ar83eo, 'method': cdsx || A[200869], 'responseType': A[200477], 'data': _lhm, 'header': { 'content-type': a2ob6 || A[200755] }, 'success': function (dmlxhz) {
      DEBUG && console[A[200178]](A[200870], ar83eo, info, dmlxhz);if (dmlxhz && dmlxhz[A[200871]] == 0xc8) {
        var q0975 = dmlxhz[A[200581]];!yfgjq || yfgjq(q0975) ? rea38 && rea38(q0975) : window[A[200872]](ar83eo, _lhm, rea38, jpq509, dkmhlx, yfgjq, dmlxhz);
      } else window[A[200872]](ar83eo, _lhm, rea38, jpq509, dkmhlx, yfgjq, dmlxhz);
    }, 'fail': function (sndcx) {
      DEBUG && console[A[200178]](A[200873], ar83eo, info, sndcx), window[A[200872]](ar83eo, _lhm, rea38, jpq509, dkmhlx, yfgjq, sndcx);
    }, 'complete': function () {} });
}, window[A[200872]] = function (ds7cnz, o32a8e, jgyqfi, hlxmdz, f8gv3, kh_xlm, nd) {
  hlxmdz - 0x1 > 0x0 ? setTimeout(function () {
    window[A[200845]](ds7cnz, o32a8e, jgyqfi, hlxmdz - 0x1, f8gv3, kh_xlm);
  }, 0x3e8) : f8gv3 && f8gv3(JSON[A[200163]]({ 'url': ds7cnz, 'response': nd }));
}, window[A[200874]] = function (_u1$k4, fvgiy, e3v8, vifj, s5c7p0, owa6e2, $k14_) {
  !e3v8 && (e3v8 = {});var cz7s5 = Math[A[200668]](Date[A[200276]]() / 0x3e8);e3v8[A[200806]] = cz7s5, e3v8[A[200875]] = fvgiy;var jgviy = Object[A[200876]](e3v8)[A[200585]](),
      t6bw2 = '',
      _$mhl = '';for (var dmxlzh = 0x0; dmxlzh < jgviy[A[200147]]; dmxlzh++) {
    t6bw2 = t6bw2 + (dmxlzh == 0x0 ? '' : '&') + jgviy[dmxlzh] + e3v8[jgviy[dmxlzh]], _$mhl = _$mhl + (dmxlzh == 0x0 ? '' : '&') + jgviy[dmxlzh] + '=' + encodeURIComponent(e3v8[jgviy[dmxlzh]]);
  }t6bw2 = t6bw2 + _nWZ[A[200710]];var yrgv3f = A[200877] + md5(t6bw2);send(_u1$k4 + '?' + _$mhl + (_$mhl == '' ? '' : '&') + yrgv3f, null, vifj, s5c7p0, owa6e2, $k14_ || function (f3v8r) {
    return f3v8r[A[200580]] == A[200579];
  }, null, A[200003]);
}, window['_nW8Z5'] = function (xmdhk, ijvfg) {
  var pj05 = 0x0;_nWZ[A[200160]] && (pj05 = _nWZ[A[200160]][A[200108]]), sendApi(_nWZ[A[200706]], A[200878], { 'partnerId': _nWZ[A[200712]], 'gamePkg': _nWZ[A[200159]], 'logTime': Math[A[200668]](Date[A[200276]]() / 0x3e8), 'platformUid': _nWZ[A[200803]], 'type': xmdhk, 'serverId': pj05 }, null, 0x2, null, function () {
    return !![];
  });
}, window['_nWZ58'] = function (c0sp7) {
  sendApi(_nWZ[A[200704]], A[200879], { 'partner_id': _nWZ[A[200712]], 'uid': _nWZ[A[200156]], 'version': _nWZ[A[200216]], 'game_pkg': _nWZ[A[200159]], 'device': _nWZ[A[200713]] }, _nWZ85, _n8ZW, _nZ5);
}, window['_nWZ85'] = function (u14k) {
  if (u14k[A[200580]] === A[200579] && u14k[A[200581]]) {
    u14k[A[200581]][A[200880]]({ 'id': -0x2, 'name': A[200881] }), u14k[A[200581]][A[200880]]({ 'id': -0x1, 'name': A[200882] }), _nWZ[A[200533]] = u14k[A[200581]];if (window[A[200525]]) window[A[200525]][A[200565]]();
  } else _nWZ[A[200543]] = ![], window['_n58WZ'](A[200883] + u14k[A[200580]]);
}, window['_n58W'] = function (yijfg) {
  sendApi(_nWZ[A[200704]], A[200884], { 'partner_id': _nWZ[A[200712]], 'uid': _nWZ[A[200156]], 'version': _nWZ[A[200216]], 'game_pkg': _nWZ[A[200159]], 'device': _nWZ[A[200713]] }, _n5W8, _n8ZW, _nZ5);
}, window['_n5W8'] = function ($4km_h) {
  _nWZ[A[200573]] = ![];if ($4km_h[A[200580]] === A[200579] && $4km_h[A[200581]]) {
    for (var pc70s = 0x0; pc70s < $4km_h[A[200581]][A[200147]]; pc70s++) {
      $4km_h[A[200581]][pc70s][A[200559]] = _nW85($4km_h[A[200581]][pc70s]);
    }_nWZ[A[200571]][-0x1] = window[A[200885]]($4km_h[A[200581]]), window[A[200525]][A[200572]](-0x1);
  } else window['_n58WZ'](A[200886] + $4km_h[A[200580]]);
}, window[A[200887]] = function (oaew26) {
  sendApi(_nWZ[A[200704]], A[200884], { 'partner_id': _nWZ[A[200712]], 'uid': _nWZ[A[200156]], 'version': _nWZ[A[200216]], 'game_pkg': _nWZ[A[200159]], 'device': _nWZ[A[200713]] }, oaew26, _n8ZW, _nZ5);
}, window['_n85W'] = function (m4kh$_, iqpy9j) {
  sendApi(_nWZ[A[200704]], A[200888], { 'partner_id': _nWZ[A[200712]], 'uid': _nWZ[A[200156]], 'version': _nWZ[A[200216]], 'game_pkg': _nWZ[A[200159]], 'device': _nWZ[A[200713]], 'server_group_id': iqpy9j }, _n8W5, _n8ZW, _nZ5);
}, window['_n8W5'] = function (zdscnx) {
  _nWZ[A[200573]] = ![];if (zdscnx[A[200580]] === A[200579] && zdscnx[A[200581]] && zdscnx[A[200581]][A[200581]]) {
    var dlxkm = zdscnx[A[200581]][A[200889]],
        $14k = [];for (var ku_h$4 = 0x0; ku_h$4 < zdscnx[A[200581]][A[200581]][A[200147]]; ku_h$4++) {
      zdscnx[A[200581]][A[200581]][ku_h$4][A[200559]] = _nW85(zdscnx[A[200581]][A[200581]][ku_h$4]), ($14k[A[200147]] == 0x0 || zdscnx[A[200581]][A[200581]][ku_h$4][A[200559]] != 0x0) && ($14k[$14k[A[200147]]] = zdscnx[A[200581]][A[200581]][ku_h$4]);
    }_nWZ[A[200571]][dlxkm] = window[A[200885]]($14k), window[A[200525]][A[200572]](dlxkm);
  } else window['_n58WZ'](A[200890] + zdscnx[A[200580]]);
}, window['_nK8ZW'] = function (bw62t) {
  sendApi(_nWZ[A[200704]], A[200891], { 'partner_id': _nWZ[A[200712]], 'uid': _nWZ[A[200156]], 'version': _nWZ[A[200216]], 'game_pkg': _nWZ[A[200159]], 'device': _nWZ[A[200713]] }, reqServerRecommendCallBack, _n8ZW, _nZ5);
}, window[A[200892]] = function (mxlhdz) {
  _nWZ[A[200573]] = ![];if (mxlhdz[A[200580]] === A[200579] && mxlhdz[A[200581]]) {
    for (var fjqy9 = 0x0; fjqy9 < mxlhdz[A[200581]][A[200147]]; fjqy9++) {
      mxlhdz[A[200581]][fjqy9][A[200559]] = _nW85(mxlhdz[A[200581]][fjqy9]);
    }_nWZ[A[200571]][-0x2] = window[A[200885]](mxlhdz[A[200581]]), window[A[200525]][A[200572]](-0x2);
  } else alert(A[200893] + mxlhdz[A[200580]]);
}, window[A[200885]] = function (ldkmh) {
  if (!ldkmh && ldkmh[A[200147]] <= 0x0) return ldkmh;for (let zs7cnd = 0x0; zs7cnd < ldkmh[A[200147]]; zs7cnd++) {
    ldkmh[zs7cnd][A[200894]] && ldkmh[zs7cnd][A[200894]] == 0x1 && (ldkmh[zs7cnd]['server_name'] += A[200895]);
  }return ldkmh;
}, window['_nW58'] = function (h_km4, zlhm) {
  h_km4 = h_km4 || _nWZ[A[200160]][A[200108]], sendApi(_nWZ[A[200704]], A[200896], { 'type': '4', 'game_pkg': _nWZ[A[200159]], 'server_id': h_km4 }, zlhm);
}, window['req_multi_server_notice'] = function (_lmhkx, zxsnc, jivfg, iqyjp9) {
  jivfg = jivfg || _nWZ[A[200160]][A[200108]], sendApi(_nWZ[A[200704]], 'Common.get_new_anno', { 'type': _lmhkx, 'game_pkg': zxsnc, 'server_id': jivfg }, iqyjp9);
}, window['_nW85'] = function (k_4hm) {
  if (k_4hm) {
    if (k_4hm[A[200559]] == 0x1) {
      if (k_4hm[A[200897]] == 0x1) return 0x2;else return 0x1;
    } else return k_4hm[A[200559]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['_nZ58W'] = function (wt6b2, zxns) {
  _nWZ[A[200898]] = { 'step': wt6b2, 'server_id': zxns };var jyigqf = this;_n5W8Z({ 'title': A[200899] }), sendApi(_nWZ[A[200704]], A[200900], { 'partner_id': _nWZ[A[200712]], 'uid': _nWZ[A[200156]], 'game_pkg': _nWZ[A[200159]], 'server_id': zxns, 'platform': _nWZ[A[200220]], 'platform_uid': _nWZ[A[200803]], 'check_login_time': _nWZ[A[200805]], 'check_login_sign': _nWZ[A[200804]], 'version_name': _nWZ['version_name'] }, _nZ5W8, _n8ZW, _nZ5, function (x_hk) {
    return x_hk[A[200580]] == A[200579] || x_hk[A[200138]] == A[200901] || x_hk[A[200138]] == A[200902];
  });
}, window['_nZ5W8'] = function (s0n57) {
  var jiy9f = this;if (s0n57[A[200580]] === A[200579] && s0n57[A[200581]]) {
    var k$_lm = _nWZ[A[200160]];k$_lm['channel_num'] = _nWZ[A[200715]], k$_lm[A[200019]] = String(s0n57[A[200581]][A[200903]]), k$_lm[A[200721]] = parseInt(s0n57[A[200581]][A[200806]]);if (s0n57[A[200581]]['server_num']) k$_lm['server_num'] = parseInt(s0n57[A[200581]]['server_num']);else k$_lm['server_num'] = parseInt(s0n57[A[200581]][A[200108]]);k$_lm[A[200904]] = 0x0, k$_lm[A[200158]] = _nWZ[A[200823]], k$_lm[A[200905]] = s0n57[A[200581]][A[200906]], k$_lm[A[200907]] = s0n57[A[200581]][A[200907]], console[A[200178]](A[200908] + JSON[A[200163]](k$_lm[A[200907]])), _nWZ[A[200657]] == 0x1 && k$_lm[A[200907]] && k$_lm[A[200907]][A[200909]] == 0x1 && (_nWZ[A[200483]] = 0x1, window[A[200171]][A[200172]]['_nKZW']()), _nZ85W();
  } else _nWZ[A[200898]][A[200910]] >= 0x3 ? (_nZ5(JSON[A[200163]](s0n57)), window['_n58WZ'](A[200911] + s0n57[A[200580]])) : sendApi(_nWZ[A[200704]], A[200788], { 'platform': _nWZ['sdk_name'], 'partner_id': _nWZ[A[200712]], 'token': _nWZ[A[200786]], 'game_pkg': _nWZ[A[200159]], 'deviceId': _nWZ[A[200713]], 'scene': A[200789] + _nWZ[A[200714]] }, function (o28a3) {
    if (!o28a3 || o28a3[A[200580]] != A[200579]) {
      window['_n58WZ'](A[200801] + o28a3 && o28a3[A[200580]]);return;
    }_nWZ[A[200804]] = String(o28a3[A[200019]]), _nWZ[A[200805]] = String(o28a3[A[200806]]), setTimeout(function () {
      _nZ58W(_nWZ[A[200898]][A[200910]] + 0x1, _nWZ[A[200898]][A[200108]]);
    }, 0x5dc);
  }, _n8ZW, _nZ5, function (pq09j) {
    return pq09j[A[200580]] == A[200579] || pq09j[A[200580]] == A[200912];
  });
}, window['_nZ85W'] = function () {
  ServerLoading[A[200172]][A[200652]](_nWZ[A[200657]]), window['_n8Z'] = !![], window['_nZW58']();
}, window['_nZ8W5'] = function () {
  if (window['_nZ8'] && window['_nW8Z'] && window[A[200648]] && window[A[200651]] && window['_nWZ8'] && window['_nW8']) {
    if (!window[A[200913]][A[200172]]) {
      console[A[200178]](A[200914] + window[A[200913]][A[200172]]);var zcnd7s = wx[A[200915]](),
          if9yqj = zcnd7s[A[200272]] ? zcnd7s[A[200272]] : 0x0,
          ldhxk = { 'cdn': window['_nWZ'][A[200158]], 'spareCdn': window['_nWZ'][A[200776]], 'newRegister': window['_nWZ'][A[200657]], 'wxPC': window['_nWZ'][A[200248]], 'wxIOS': window['_nWZ'][A[200243]], 'wxAndroid': window['_nWZ'][A[200246]], 'wxParam': { 'limitLoad': window['_nWZ']['_nK58ZW'], 'benchmarkLevel': window['_nWZ']['_nK5W8Z'], 'wxFrom': window[A[200143]][A[200782]] == A[200916] ? 0x1 : 0x0, 'wxSDKVersion': window[A[200176]] }, 'configType': window['_nWZ'][A[200722]], 'exposeType': window['_nWZ'][A[200724]], 'scene': if9yqj };new window[A[200913]](ldhxk, window['_nWZ'][A[200157]], window['_nK58WZ']);
    }
  }
}, window['_nZW58'] = function () {
  if (window['_nZ8'] && window['_nW8Z'] && window[A[200648]] && window[A[200651]] && window['_nWZ8'] && window['_nW8'] && window['_n8Z'] && window['_n8W']) {
    _n5WZ8();if (!_nZ8W) {
      _nZ8W = !![];if (!window[A[200913]][A[200172]]) window['_nZ8W5']();var r3aeo8 = 0x0,
          hxdlk = wx[A[200917]]();hxdlk && (window['_nWZ'][A[200247]] && (r3aeo8 = hxdlk[A[200238]]), console[A[200138]](A[200918] + hxdlk[A[200238]] + A[200919] + hxdlk[A[200239]] + A[200920] + hxdlk[A[200240]] + A[200921] + hxdlk[A[200241]] + A[200922] + hxdlk[A[200446]] + A[200923] + hxdlk[A[200448]]));var ijyp9 = {};for (const km$l_ in _nWZ[A[200160]]) {
        ijyp9[km$l_] = _nWZ[A[200160]][km$l_];
      }var r8o = { 'channel': window['_nWZ'][A[200716]], 'account': window['_nWZ'][A[200156]], 'userId': window['_nWZ'][A[200802]], 'cdn': window['_nWZ'][A[200158]], 'data': window['_nWZ'][A[200581]], 'package': window['_nWZ'][A[200702]], 'newRegister': window['_nWZ'][A[200657]], 'pkgName': window['_nWZ'][A[200159]], 'partnerId': window['_nWZ'][A[200712]], 'platform_uid': window['_nWZ'][A[200803]], 'deviceId': window['_nWZ'][A[200713]], 'selectedServer': ijyp9, 'configType': window['_nWZ'][A[200722]], 'exposeType': window['_nWZ'][A[200724]], 'debugUsers': window['_nWZ'][A[200719]], 'wxMenuTop': r3aeo8, 'wxShield': window['_nWZ'][A[200725]] };if (window[A[200825]]) for (var z7nscd in window[A[200825]]) {
        r8o[z7nscd] = window[A[200825]][z7nscd];
      }window[A[200913]][A[200172]]['_nZWK'](r8o);
    }
  } else console[A[200138]](A[200924] + window['_nZ8'] + A[200925] + window['_nW8Z'] + A[200926] + window[A[200648]] + A[200927] + window[A[200651]] + A[200928] + window['_nWZ8'] + A[200929] + window['_nW8'] + A[200930] + window['_n8Z'] + A[200931] + window['_n8W']);
};