var _ = wx.y$;
require('bbbbBuff.js'), window[_[28737]][_[28727]][_[28615]] = null, window['client_pb'] = require('bbbcleintpb.js'), window[_[25483]] = window[_[28737]][_[25371]][_[25372]](client_pb);