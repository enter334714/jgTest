var _ = wx.y$;
import _d_x0y$z from '../bbbk/bbbsdk.js';window[_[29249]] = { 'wxVersion': window[_[557]][_[29148]] }, window[_[29250]] = ![], window['p$ED'] = 0x1, window[_[29251]] = 0x1, window['p$CDE'] = !![], window[_[29252]] = !![], window['p$ABCDE'] = '', window['p$DE'] = { 'base_cdn': _[29253], 'cdn': _[29253] }, p$DE[_[29254]] = {}, p$DE[_[25048]] = '0', p$DE[_[4740]] = window[_[29249]][_[29255]], p$DE[_[29221]] = '', p$DE['os'] = '1', p$DE[_[29256]] = _[29257], p$DE[_[29258]] = _[29259], p$DE[_[29260]] = _[29261], p$DE[_[29262]] = _[29263], p$DE[_[29264]] = _[29265], p$DE[_[23748]] = '1', p$DE[_[25343]] = '', p$DE[_[25345]] = '', p$DE[_[29266]] = 0x0, p$DE[_[29267]] = {}, p$DE[_[29268]] = parseInt(p$DE[_[23748]]), p$DE[_[25341]] = p$DE[_[23748]], p$DE[_[25337]] = {}, p$DE['p$BD'] = _[29269], p$DE[_[29270]] = ![], p$DE[_[12295]] = _[29271], p$DE[_[25316]] = Date[_[83]](), p$DE[_[11897]] = _[29272], p$DE[_[714]] = '_a', p$DE[_[29273]] = 0x2, p$DE[_[101]] = 0x7c1, p$DE[_[29255]] = window[_[29249]][_[29255]], p$DE[_[738]] = ![], p$DE[_[1074]] = ![], p$DE[_[11373]] = ![], p$DE[_[25050]] = ![], window['p$CED'] = 0x5, window['p$CE'] = ![], window['p$EC'] = ![], window['p$DCE'] = ![], window[_[29274]] = ![], window[_[29275]] = ![], window['p$DEC'] = ![], window['p$CD'] = ![], window['p$DC'] = ![], window['p$ECD'] = ![], window[_[4208]] = function (lnok) {
  console[_[482]](_[4208], lnok), wx[_[5020]]({}), wx[_[29172]]({ 'title': _[6394], 'content': lnok, 'success'(sxvu) {
      if (sxvu[_[29276]]) console[_[482]](_[29277]);else sxvu[_[553]] && console[_[482]](_[29278]);
    } });
}, window['p$BCDE'] = function (mlnopq) {
  console[_[482]](_[29279], mlnopq), p$BDEC(), wx[_[29172]]({ 'title': _[6394], 'content': mlnopq, 'confirmText': _[29280], 'cancelText': _[18583], 'success'(pturs) {
      if (pturs[_[29276]]) window['p$DB']();else pturs[_[553]] && (console[_[482]](_[29281]), wx[_[25043]]({}));
    } });
}, window[_[29282]] = function (pqornm) {
  console[_[482]](_[29282], pqornm), wx[_[29172]]({ 'title': _[6394], 'content': pqornm, 'confirmText': _[25473], 'showCancel': ![], 'complete'(qplm) {
      console[_[482]](_[29281]), wx[_[25043]]({});
    } });
}, window['p$BCED'] = ![], window['p$BDCE'] = function (edgbcf) {
  window['p$BCED'] = !![], wx[_[5019]](edgbcf);
}, window['p$BDEC'] = function () {
  window['p$BCED'] && (window['p$BCED'] = ![], wx[_[5020]]({}));
}, window['p$BECD'] = function (qsort) {
  window[_[29163]][_[148]]['p$BECD'](qsort);
}, window[_[12173]] = function (begcdf, gljh) {
  _d_x0y$z[_[12173]](begcdf, function (nmrqo) {
    nmrqo && nmrqo[_[11]] ? nmrqo[_[11]][_[4141]] == 0x1 ? gljh(!![]) : (gljh(![]), console[_[78]](_[29283] + nmrqo[_[11]][_[29284]])) : console[_[482]](_[12173], nmrqo);
  });
}, window['p$BEDC'] = function (figde) {
  console[_[482]](_[29285], figde);
}, window['p$BDE'] = function (mljhi) {}, window['p$BED'] = function (fgiej, wutxvy, hljgk) {}, window['p$BE'] = function (pomnlk) {
  console[_[482]](_[29286], pomnlk), window[_[29163]][_[148]][_[29287]](), window[_[29163]][_[148]][_[29288]](), window[_[29163]][_[148]][_[29289]]();
}, window['p$EB'] = function (wvxuz) {
  window['p$BCDE'](_[29290]);var kplmon = { 'id': window['p$DE'][_[29153]], 'role': window['p$DE'][_[4669]], 'level': window['p$DE'][_[29154]], 'account': window['p$DE'][_[25342]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4546]], 'pkgName': window['p$DE'][_[25343]], 'gamever': window[_[557]][_[29148]], 'serverid': window['p$DE'][_[25337]] ? window['p$DE'][_[25337]][_[11551]] : 0x0, 'systemInfo': window[_[29155]], 'error': _[29291], 'stack': wvxuz ? wvxuz : _[29290] },
      qonl = JSON[_[4532]](kplmon);console[_[125]](_[29292] + qonl), window['p$BD'](qonl);
}, window['p$DBE'] = function (wvxyu) {
  var ihfeg = JSON[_[527]](wvxyu);ihfeg[_[29293]] = window[_[557]][_[29148]], ihfeg[_[29294]] = window['p$DE'][_[25337]] ? window['p$DE'][_[25337]][_[11551]] : 0x0, ihfeg[_[29155]] = window[_[29155]];var $2_310 = JSON[_[4532]](ihfeg);console[_[125]](_[29295] + $2_310), window['p$BD']($2_310);
}, window['p$DEB'] = function (gdei, ilgjhk) {
  var ebfad = { 'id': window['p$DE'][_[29153]], 'role': window['p$DE'][_[4669]], 'level': window['p$DE'][_[29154]], 'account': window['p$DE'][_[25342]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4546]], 'pkgName': window['p$DE'][_[25343]], 'gamever': window[_[557]][_[29148]], 'serverid': window['p$DE'][_[25337]] ? window['p$DE'][_[25337]][_[11551]] : 0x0, 'systemInfo': window[_[29155]], 'error': gdei, 'stack': ilgjhk },
      fhdecg = JSON[_[4532]](ebfad);console[_[96]](_[29296] + fhdecg), window['p$BD'](fhdecg);
}, window['p$BD'] = function (wtvyx) {
  if (window['p$DE'][_[29222]] == _[29297]) return;var $zy_x0 = p$DE['p$BD'] + _[29298] + p$DE[_[25342]];wx[_[477]]({ 'url': $zy_x0, 'method': _[29013], 'data': wtvyx, 'header': { 'content-type': _[29299], 'cache-control': _[29300] }, 'success': function (lkjnmo) {
      DEBUG && console[_[482]](_[29301], $zy_x0, wtvyx, lkjnmo);
    }, 'fail': function (hgkji) {
      DEBUG && console[_[482]](_[29301], $zy_x0, wtvyx, hgkji);
    }, 'complete': function () {} });
}, window[_[29302]] = function () {
  function pqosrt() {
    return ((0x1 + Math[_[119]]()) * 0x10000 | 0x0)[_[275]](0x10)[_[500]](0x1);
  }return pqosrt() + pqosrt() + '-' + pqosrt() + '-' + pqosrt() + '-' + pqosrt() + '+' + pqosrt() + pqosrt() + pqosrt();
}, window['p$DB'] = function () {
  console[_[482]](_[29303]);var ebdf = _d_x0y$z[_[29304]]();p$DE[_[25341]] = ebdf[_[29305]], p$DE[_[29268]] = ebdf[_[29305]], p$DE[_[23748]] = ebdf[_[29305]], p$DE[_[25343]] = ebdf[_[29306]];var nmjkil = { 'game_ver': p$DE[_[4740]] };p$DE[_[25345]] = this[_[29302]](), p$BDCE({ 'title': _[29307] }), _d_x0y$z[_[368]](nmjkil, this['p$EBD'][_[74]](this));
}, window['p$EBD'] = function (qrtusp) {
  var hedgf = qrtusp[_[29308]];console[_[482]](_[29309] + hedgf + _[29310] + (hedgf == 0x1) + _[29311] + qrtusp[_[29148]] + _[29312] + window[_[29249]][_[29255]]);if (!qrtusp[_[29148]] || window['p$ACEBD'](window[_[29249]][_[29255]], qrtusp[_[29148]]) < 0x0) console[_[482]](_[29313]), p$DE[_[29258]] = _[29314], p$DE[_[29260]] = _[29315], p$DE[_[29262]] = _[29316], p$DE[_[4546]] = _[29317], p$DE[_[25047]] = _[29318], p$DE[_[29319]] = _[29320], p$DE[_[738]] = ![];else window['p$ACEBD'](window[_[29249]][_[29255]], qrtusp[_[29148]]) == 0x0 ? (console[_[482]](_[29321]), p$DE[_[29258]] = _[29259], p$DE[_[29260]] = _[29261], p$DE[_[29262]] = _[29263], p$DE[_[4546]] = _[29253], p$DE[_[25047]] = _[29318], p$DE[_[29319]] = _[29320], p$DE[_[738]] = !![]) : (console[_[482]](_[29322]), p$DE[_[29258]] = _[29259], p$DE[_[29260]] = _[29261], p$DE[_[29262]] = _[29263], p$DE[_[4546]] = _[29253], p$DE[_[25047]] = _[29318], p$DE[_[29319]] = _[29320], p$DE[_[738]] = ![]);p$DE[_[29266]] = config[_[28628]] ? config[_[28628]] : 0x0, this['p$CDBE'](), this['p$CDEB'](), window[_[29323]] = 0x5, p$BDCE({ 'title': _[29324] }), _d_x0y$z[_[29036]](this['p$EDB'][_[74]](this));
}, window[_[29323]] = 0x5, window['p$EDB'] = function ($xywv, jklmn) {
  if ($xywv == 0x0 && jklmn && jklmn[_[28721]]) {
    p$DE[_[29325]] = jklmn[_[28721]];var y$vw = this;p$BDCE({ 'title': _[29326] }), sendApi(p$DE[_[29258]], _[29327], { 'platform': p$DE[_[29256]], 'partner_id': p$DE[_[23748]], 'token': jklmn[_[28721]], 'game_pkg': p$DE[_[25343]], 'deviceId': p$DE[_[25345]], 'scene': _[29328] + p$DE[_[29266]] }, this['p$CBDE'][_[74]](this), p$CED, p$EB);
  } else jklmn && jklmn[_[25531]] && window[_[29323]] > 0x0 && (jklmn[_[25531]][_[115]](_[29329]) != -0x1 || jklmn[_[25531]][_[115]](_[29330]) != -0x1 || jklmn[_[25531]][_[115]](_[29331]) != -0x1 || jklmn[_[25531]][_[115]](_[29332]) != -0x1 || jklmn[_[25531]][_[115]](_[29333]) != -0x1 || jklmn[_[25531]][_[115]](_[29334]) != -0x1) ? (window[_[29323]]--, _d_x0y$z[_[29036]](this['p$EDB'][_[74]](this))) : (window['p$DEB'](_[29335], JSON[_[4532]]({ 'status': $xywv, 'data': jklmn })), window['p$BCDE'](_[29336] + (jklmn && jklmn[_[25531]] ? '，' + jklmn[_[25531]] : '')));
}, window['p$CBDE'] = function (pnokm) {
  if (!pnokm) {
    window['p$DEB'](_[29337], _[29338]), window['p$BCDE'](_[29339]);return;
  }if (pnokm[_[4141]] != _[9961]) {
    window['p$DEB'](_[29337], JSON[_[4532]](pnokm)), window['p$BCDE'](_[29340] + pnokm[_[4141]]);return;
  }p$DE[_[23747]] = String(pnokm[_[25342]]), p$DE[_[25342]] = String(pnokm[_[25342]]), p$DE[_[25314]] = String(pnokm[_[25314]]), p$DE[_[25341]] = String(pnokm[_[25314]]), p$DE[_[25344]] = String(pnokm[_[25344]]), p$DE[_[29341]] = String(pnokm[_[11534]]), p$DE[_[29342]] = String(pnokm[_[851]]), p$DE[_[11534]] = '';var _21$03 = this;p$BDCE({ 'title': _[29343] }), sendApi(p$DE[_[29258]], _[29344], { 'partner_id': p$DE[_[23748]], 'uid': p$DE[_[25342]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25343]], 'device': p$DE[_[25345]] }, _21$03['p$CBED'][_[74]](_21$03), p$CED, p$EB);
}, window['p$CBED'] = function (_x$z) {
  if (!_x$z) {
    window['p$BCDE'](_[29345]);return;
  }if (_x$z[_[4141]] != _[9961]) {
    window['p$BCDE'](_[29346] + _x$z[_[4141]]);return;
  }if (!_x$z[_[11]] || _x$z[_[11]][_[13]] == 0x0) {
    window['p$BCDE'](_[29347]);return;
  }p$DE[_[630]] = _x$z[_[29348]], p$DE[_[25337]] = { 'server_id': String(_x$z[_[11]][0x0][_[11551]]), 'server_name': String(_x$z[_[11]][0x0][_[29349]]), 'entry_ip': _x$z[_[11]][0x0][_[25365]], 'entry_port': parseInt(_x$z[_[11]][0x0][_[25366]]), 'status': p$DCB(_x$z[_[11]][0x0]), 'start_time': _x$z[_[11]][0x0][_[29350]], 'cdn': p$DE[_[4546]] }, this['p$EDCB']();
}, window['p$EDCB'] = function () {
  if (p$DE[_[630]] == 0x1) {
    var imkjh = p$DE[_[25337]][_[106]];if (imkjh === -0x1 || imkjh === 0x0) {
      window['p$BCDE'](imkjh === -0x1 ? _[29351] : _[29352]);return;
    }p$EBCD(0x0, p$DE[_[25337]][_[11551]]), window[_[29163]][_[148]][_[29353]](p$DE[_[630]]);
  } else window[_[29163]][_[148]][_[29354]](), p$BDEC();window['p$DC'] = !![], window['p$ECDB'](), window['p$EDBC']();
}, window['p$CDBE'] = function () {
  sendApi(p$DE[_[29258]], _[29355], { 'game_pkg': p$DE[_[25343]], 'version_name': p$DE[_[29319]] }, this[_[29356]][_[74]](this), p$CED, p$EB);
}, window[_[29356]] = function (gefij) {
  if (!gefij) {
    window['p$BCDE'](_[29357]);return;
  }if (gefij[_[4141]] != _[9961]) {
    window['p$BCDE'](_[29358] + gefij[_[4141]]);return;
  }if (!gefij[_[11]] || !gefij[_[11]][_[4740]]) {
    window['p$BCDE'](_[29359] + (gefij[_[11]] && gefij[_[11]][_[4740]]));return;
  }gefij[_[11]][_[29360]] && gefij[_[11]][_[29360]][_[13]] > 0xa && (p$DE[_[29361]] = gefij[_[11]][_[29360]], p$DE[_[4546]] = gefij[_[11]][_[29360]]), gefij[_[11]][_[4740]] && (p$DE[_[101]] = gefij[_[11]][_[4740]]), console[_[78]](_[25479] + p$DE[_[101]] + _[29362] + p$DE[_[29319]]), window['p$DEC'] = !![], window['p$ECDB'](), window['p$EDBC']();
}, window[_[29363]], window['p$CDEB'] = function () {
  sendApi(p$DE[_[29258]], _[29364], { 'game_pkg': p$DE[_[25343]] }, this['p$CEBD'][_[74]](this), p$CED, p$EB);
}, window['p$CEBD'] = function (srptqo) {
  if (srptqo[_[4141]] === _[9961] && srptqo[_[11]]) {
    window[_[29363]] = srptqo[_[11]];for (var ikjnml in srptqo[_[11]]) {
      p$DE[ikjnml] = srptqo[_[11]][ikjnml];
    }
  } else console[_[78]](_[29365] + srptqo[_[4141]]);window['p$CD'] = !![], window['p$EDBC']();
}, window[_[29366]] = function (okmlpn, fdebcg, uqprt, opmnl, ighlkj, rputq, usrqtp, _xy$0, efij) {
  ighlkj = String(ighlkj);var uvsrtq = usrqtp,
      qrvu = _xy$0;p$DE[_[29254]][ighlkj] = { 'productid': ighlkj, 'productname': uvsrtq, 'productdesc': qrvu, 'roleid': okmlpn, 'rolename': fdebcg, 'rolelevel': uqprt, 'price': rputq, 'callback': efij }, sendApi(p$DE[_[29262]], _[29367], { 'game_pkg': p$DE[_[25343]], 'server_id': p$DE[_[25337]][_[11551]], 'server_name': p$DE[_[25337]][_[29349]], 'level': uqprt, 'uid': p$DE[_[25342]], 'role_id': okmlpn, 'role_name': fdebcg, 'product_id': ighlkj, 'product_name': uvsrtq, 'product_desc': qrvu, 'money': rputq, 'partner_id': p$DE[_[23748]] }, toPayCallBack, p$CED, p$EB);
}, window[_[29368]] = function (iknm) {
  if (iknm) {
    if (iknm[_[29369]] === 0xc8 || iknm[_[4141]] == _[9961]) {
      var glkjhi = p$DE[_[29254]][String(iknm[_[29370]])];if (glkjhi[_[335]]) glkjhi[_[335]](iknm[_[29370]], iknm[_[29371]], -0x1);_d_x0y$z[_[29094]]({ 'cpbill': iknm[_[29371]], 'productid': iknm[_[29370]], 'productname': glkjhi[_[29372]], 'productdesc': glkjhi[_[29373]], 'serverid': p$DE[_[25337]][_[11551]], 'servername': p$DE[_[25337]][_[29349]], 'roleid': glkjhi[_[29374]], 'rolename': glkjhi[_[29375]], 'rolelevel': glkjhi[_[29376]], 'price': glkjhi[_[27048]], 'extension': JSON[_[4532]]({ 'cp_order_id': iknm[_[29371]] }) }, function (rqpnso, chfegd) {
        glkjhi[_[335]] && rqpnso == 0x0 && glkjhi[_[335]](iknm[_[29370]], iknm[_[29371]], rqpnso);console[_[78]](JSON[_[4532]]({ 'type': _[29377], 'status': rqpnso, 'data': iknm, 'role_name': glkjhi[_[29375]] }));if (rqpnso === 0x0) {} else {
          if (rqpnso === 0x1) {} else {
            if (rqpnso === 0x2) {}
          }
        }
      });
    } else alert(iknm[_[78]]);
  }
}, window['p$CEDB'] = function () {}, window['p$BCE'] = function (lkjgih, rqos, lighk, aecfdb, pol) {
  _d_x0y$z[_[29140]](p$DE[_[25337]][_[11551]], p$DE[_[25337]][_[29349]] || p$DE[_[25337]][_[11551]], lkjgih, rqos, lighk), sendApi(p$DE[_[29258]], _[29378], { 'game_pkg': p$DE[_[25343]], 'server_id': p$DE[_[25337]][_[11551]], 'role_id': lkjgih, 'uid': p$DE[_[25342]], 'role_name': rqos, 'role_type': aecfdb, 'level': lighk });
}, window['p$BEC'] = function (dbcefg, rpnmq, vrtu, omlkjn, turvw, rutq, wy$vzx, hgjkfi, cebadf, ebca) {
  p$DE[_[29153]] = dbcefg, p$DE[_[4669]] = rpnmq, p$DE[_[29154]] = vrtu, _d_x0y$z[_[29141]](p$DE[_[25337]][_[11551]], p$DE[_[25337]][_[29349]] || p$DE[_[25337]][_[11551]], dbcefg, rpnmq, vrtu), sendApi(p$DE[_[29258]], _[29379], { 'game_pkg': p$DE[_[25343]], 'server_id': p$DE[_[25337]][_[11551]], 'role_id': dbcefg, 'uid': p$DE[_[25342]], 'role_name': rpnmq, 'role_type': omlkjn, 'level': vrtu, 'evolution': turvw });
}, window['p$CBE'] = function (lnkom, xyw$z_, xy$0_z, suxtw, kljmi, zxw, srutvq, $y0_, mlknop, yz$_10) {
  p$DE[_[29153]] = lnkom, p$DE[_[4669]] = xyw$z_, p$DE[_[29154]] = xy$0_z, _d_x0y$z[_[29142]](p$DE[_[25337]][_[11551]], p$DE[_[25337]][_[29349]] || p$DE[_[25337]][_[11551]], lnkom, xyw$z_, xy$0_z), sendApi(p$DE[_[29258]], _[29379], { 'game_pkg': p$DE[_[25343]], 'server_id': p$DE[_[25337]][_[11551]], 'role_id': lnkom, 'uid': p$DE[_[25342]], 'role_name': xyw$z_, 'role_type': suxtw, 'level': xy$0_z, 'evolution': kljmi });
}, window['p$CEB'] = function (twu) {}, window['p$BC'] = function (jlhig) {
  _d_x0y$z[_[29073]](_[29073], function (qoprs) {
    jlhig && jlhig(qoprs);
  });
}, window[_[25027]] = function () {
  _d_x0y$z[_[25027]]();
}, window[_[29380]] = function () {
  _d_x0y$z[_[23640]]();
}, window[_[29381]] = function (jhkgli, efjihg, vwuzy, yzx$, dfgh, qsrut, rnmqop, $_2310) {
  $_2310 = $_2310 || p$DE[_[25337]][_[11551]], sendApi(p$DE[_[29258]], _[29382], { 'phone': jhkgli, 'role_id': efjihg, 'uid': p$DE[_[25342]], 'game_pkg': p$DE[_[25343]], 'partner_id': p$DE[_[23748]], 'server_id': $_2310 }, rnmqop);
}, window[_[10883]] = function (sqnrop) {
  window['p$EBC'] = sqnrop, window['p$EBC'] && window['p$CB'] && (console[_[78]](_[29241] + window['p$CB'][_[776]]), window['p$EBC'](window['p$CB']), window['p$CB'] = null);
}, window['p$ECB'] = function (x_y, ceadf, vtwusx, kplo) {
  window[_[22]](_[29383], { 'game_pkg': window['p$DE'][_[25343]], 'role_id': ceadf, 'server_id': vtwusx }, kplo);
}, window['p$DBCE'] = function (dgfi, iknml) {
  function qsvt(rvqt) {
    var ceabf = [],
        rsqtv = [],
        bcegd = window[_[557]][_[29384]];for (var utrqsp in bcegd) {
      var fhjge = Number(utrqsp);(!dgfi || !dgfi[_[13]] || dgfi[_[115]](fhjge) != -0x1) && (rsqtv[_[29]](bcegd[utrqsp]), ceabf[_[29]]([fhjge, 0x3]));
    }window['p$ACEBD'](window[_[29164]], _[29385]) >= 0x0 ? (console[_[482]](_[29386]), _d_x0y$z[_[29137]](rsqtv, function (vutxwy) {
      console[_[482]](_[29387]), console[_[482]](vutxwy);if (vutxwy && vutxwy[_[25531]] == _[29388]) for (var kjihgl in bcegd) {
        if (vutxwy[bcegd[kjihgl]] == _[29389]) {
          var _xyzw = Number(kjihgl);for (var qvsurt = 0x0; qvsurt < ceabf[_[13]]; qvsurt++) {
            if (ceabf[qvsurt][0x0] == _xyzw) {
              ceabf[qvsurt][0x1] = 0x1;break;
            }
          }
        }
      }window['p$ACEBD'](window[_[29164]], _[29390]) >= 0x0 ? wx[_[29391]]({ 'withSubscriptions': !![], 'success': function (z_yw) {
          var vurswt = z_yw[_[29392]][_[29393]];if (vurswt) {
            console[_[482]](_[29394]), console[_[482]](vurswt);for (var jomln in bcegd) {
              if (vurswt[bcegd[jomln]] == _[29389]) {
                var wtrvs = Number(jomln);for (var hjkgli = 0x0; hjkgli < ceabf[_[13]]; hjkgli++) {
                  if (ceabf[hjkgli][0x0] == wtrvs) {
                    ceabf[hjkgli][0x1] = 0x2;break;
                  }
                }
              }
            }console[_[482]](ceabf), iknml && iknml(ceabf);
          } else console[_[482]](_[29395]), console[_[482]](z_yw), console[_[482]](ceabf), iknml && iknml(ceabf);
        }, 'fail': function () {
          console[_[482]](_[29396]), console[_[482]](ceabf), iknml && iknml(ceabf);
        } }) : (console[_[482]](_[29397] + window[_[29164]]), console[_[482]](ceabf), iknml && iknml(ceabf));
    })) : (console[_[482]](_[29398] + window[_[29164]]), console[_[482]](ceabf), iknml && iknml(ceabf)), wx[_[29399]](qsvt);
  }wx[_[29400]](qsvt);
}, window['p$DBEC'] = { 'isSuccess': ![], 'level': _[29401], 'isCharging': ![] }, window['p$DCBE'] = function (xzv) {
  wx[_[29230]]({ 'success': function (daecb) {
      var hgde = window['p$DBEC'];hgde[_[29402]] = !![], hgde[_[4645]] = Number(daecb[_[4645]])[_[4256]](0x0), hgde[_[29233]] = daecb[_[29233]], xzv && xzv(hgde[_[29402]], hgde[_[4645]], hgde[_[29233]]);
    }, 'fail': function (ghejif) {
      console[_[482]](_[29403], ghejif[_[25531]]);var molnkp = window['p$DBEC'];xzv && xzv(molnkp[_[29402]], molnkp[_[4645]], molnkp[_[29233]]);
    } });
}, window[_[22]] = function (qptso, x_wz, ropst, $01_, qsropn, echdg, lhig, rospqn) {
  if ($01_ == undefined) $01_ = 0x1;wx[_[477]]({ 'url': qptso, 'method': lhig || _[25233], 'responseType': _[4453], 'data': x_wz, 'header': { 'content-type': rospqn || _[29299] }, 'success': function (vtsurq) {
      DEBUG && console[_[482]](_[29404], qptso, info, vtsurq);if (vtsurq && vtsurq[_[25596]] == 0xc8) {
        var fdea = vtsurq[_[11]];!echdg || echdg(fdea) ? ropst && ropst(fdea) : window[_[29405]](qptso, x_wz, ropst, $01_, qsropn, echdg, vtsurq);
      } else window[_[29405]](qptso, x_wz, ropst, $01_, qsropn, echdg, vtsurq);
    }, 'fail': function (wuzvy) {
      DEBUG && console[_[482]](_[29406], qptso, info, wuzvy), window[_[29405]](qptso, x_wz, ropst, $01_, qsropn, echdg, wuzvy);
    }, 'complete': function () {} });
}, window[_[29405]] = function (oq, usvtqr, _1yz$, ihljkm, nqosrp, y$wvx, tyvxwu) {
  ihljkm - 0x1 > 0x0 ? setTimeout(function () {
    window[_[22]](oq, usvtqr, _1yz$, ihljkm - 0x1, nqosrp, y$wvx);
  }, 0x3e8) : nqosrp && nqosrp(JSON[_[4532]]({ 'url': oq, 'response': tyvxwu }));
}, window[_[29407]] = function (fgehid, hcfed, fjgeh, qmpnl, tvurq, wutx, ploqn) {
  !fjgeh && (fjgeh = {});var _y$z1 = Math[_[118]](Date[_[83]]() / 0x3e8);fjgeh[_[851]] = _y$z1, fjgeh[_[29408]] = hcfed;var vwsutx = Object[_[267]](fjgeh)[_[1078]](),
      trwsvu = '',
      dfcae = '';for (var imkh = 0x0; imkh < vwsutx[_[13]]; imkh++) {
    trwsvu = trwsvu + (imkh == 0x0 ? '' : '&') + vwsutx[imkh] + fjgeh[vwsutx[imkh]], dfcae = dfcae + (imkh == 0x0 ? '' : '&') + vwsutx[imkh] + '=' + encodeURIComponent(fjgeh[vwsutx[imkh]]);
  }trwsvu = trwsvu + p$DE[_[29264]];var uvrtw = _[29409] + md5(trwsvu);send(fgehid + '?' + dfcae + (dfcae == '' ? '' : '&') + uvrtw, null, qmpnl, tvurq, wutx, ploqn || function (efdb) {
    return efdb[_[4141]] == _[9961];
  }, null, _[29014]);
}, window['p$DCEB'] = function (_3$102, mpr) {
  var wrutv = 0x0;p$DE[_[25337]] && (wrutv = p$DE[_[25337]][_[11551]]), sendApi(p$DE[_[29260]], _[29410], { 'partnerId': p$DE[_[23748]], 'gamePkg': p$DE[_[25343]], 'logTime': Math[_[118]](Date[_[83]]() / 0x3e8), 'platformUid': p$DE[_[25344]], 'type': _3$102, 'serverId': wrutv }, null, 0x2, null, function () {
    return !![];
  });
}, window['p$DEBC'] = function (_34) {
  sendApi(p$DE[_[29258]], _[29411], { 'partner_id': p$DE[_[23748]], 'uid': p$DE[_[25342]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25343]], 'device': p$DE[_[25345]] }, p$DECB, p$CED, p$EB);
}, window['p$DECB'] = function (vxwuy) {
  if (vxwuy[_[4141]] === _[9961] && vxwuy[_[11]]) {
    vxwuy[_[11]][_[5623]]({ 'id': -0x2, 'name': _[29412] }), vxwuy[_[11]][_[5623]]({ 'id': -0x1, 'name': _[29413] }), p$DE[_[29414]] = vxwuy[_[11]];if (window[_[12345]]) window[_[12345]][_[29415]]();
  } else p$DE[_[29416]] = ![], window['p$BCDE'](_[29417] + vxwuy[_[4141]]);
}, window['p$BCD'] = function (yz_x0) {
  sendApi(p$DE[_[29258]], _[29418], { 'partner_id': p$DE[_[23748]], 'uid': p$DE[_[25342]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25343]], 'device': p$DE[_[25345]] }, p$BDC, p$CED, p$EB);
}, window['p$BDC'] = function (gecfb) {
  p$DE[_[29419]] = ![];if (gecfb[_[4141]] === _[9961] && gecfb[_[11]]) {
    for (var facbed = 0x0; facbed < gecfb[_[11]][_[13]]; facbed++) {
      gecfb[_[11]][facbed][_[106]] = p$DCB(gecfb[_[11]][facbed]);
    }p$DE[_[29267]][-0x1] = window[_[29420]](gecfb[_[11]]), window[_[12345]][_[29421]](-0x1);
  } else window['p$BCDE'](_[29422] + gecfb[_[4141]]);
}, window[_[29423]] = function (ojnklm) {
  sendApi(p$DE[_[29258]], _[29418], { 'partner_id': p$DE[_[23748]], 'uid': p$DE[_[25342]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25343]], 'device': p$DE[_[25345]] }, ojnklm, p$CED, p$EB);
}, window['p$CBD'] = function (onmplk, wzu) {
  sendApi(p$DE[_[29258]], _[29424], { 'partner_id': p$DE[_[23748]], 'uid': p$DE[_[25342]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25343]], 'device': p$DE[_[25345]], 'server_group_id': wzu }, p$CDB, p$CED, p$EB);
}, window['p$CDB'] = function (oqrt) {
  p$DE[_[29419]] = ![];if (oqrt[_[4141]] === _[9961] && oqrt[_[11]] && oqrt[_[11]][_[11]]) {
    var _2$z0 = oqrt[_[11]][_[29425]],
        cedabf = [];for (var _yzx$w = 0x0; _yzx$w < oqrt[_[11]][_[11]][_[13]]; _yzx$w++) {
      oqrt[_[11]][_[11]][_yzx$w][_[106]] = p$DCB(oqrt[_[11]][_[11]][_yzx$w]), (cedabf[_[13]] == 0x0 || oqrt[_[11]][_[11]][_yzx$w][_[106]] != 0x0) && (cedabf[cedabf[_[13]]] = oqrt[_[11]][_[11]][_yzx$w]);
    }p$DE[_[29267]][_2$z0] = window[_[29420]](cedabf), window[_[12345]][_[29421]](_2$z0);
  } else window['p$BCDE'](_[29426] + oqrt[_[4141]]);
}, window['p$ACED'] = function (xwz_y$) {
  sendApi(p$DE[_[29258]], _[29427], { 'partner_id': p$DE[_[23748]], 'uid': p$DE[_[25342]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25343]], 'device': p$DE[_[25345]] }, reqServerRecommendCallBack, p$CED, p$EB);
}, window[_[29428]] = function (hijfg) {
  p$DE[_[29419]] = ![];if (hijfg[_[4141]] === _[9961] && hijfg[_[11]]) {
    for (var _$x0yz = 0x0; _$x0yz < hijfg[_[11]][_[13]]; _$x0yz++) {
      hijfg[_[11]][_$x0yz][_[106]] = p$DCB(hijfg[_[11]][_$x0yz]);
    }p$DE[_[29267]][-0x2] = window[_[29420]](hijfg[_[11]]), window[_[12345]][_[29421]](-0x2);
  } else alert(_[29429] + hijfg[_[4141]]);
}, window[_[29420]] = function (rustv) {
  if (!rustv && rustv[_[13]] <= 0x0) return rustv;for (let y0z$1_ = 0x0; y0z$1_ < rustv[_[13]]; y0z$1_++) {
    rustv[y0z$1_][_[29430]] && rustv[y0z$1_][_[29430]] == 0x1 && (rustv[y0z$1_][_[29349]] += _[29431]);
  }return rustv;
}, window['p$DBC'] = function (ponm, prmo) {
  ponm = ponm || p$DE[_[25337]][_[11551]], sendApi(p$DE[_[29258]], _[29432], { 'type': '4', 'game_pkg': p$DE[_[25343]], 'server_id': ponm }, prmo);
}, window[_[29433]] = function (tsxvw, kjilg, qrspto, efhid) {
  qrspto = qrspto || p$DE[_[25337]][_[11551]], sendApi(p$DE[_[29258]], _[29434], { 'type': tsxvw, 'game_pkg': kjilg, 'server_id': qrspto }, efhid);
}, window['p$DCB'] = function (nlmjki) {
  if (nlmjki) {
    if (nlmjki[_[106]] == 0x1) {
      if (nlmjki[_[29435]] == 0x1) return 0x2;else return 0x1;
    } else return nlmjki[_[106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['p$EBCD'] = function (hfecd, dcfghe) {
  p$DE[_[29436]] = { 'step': hfecd, 'server_id': dcfghe };var edhgcf = this;p$BDCE({ 'title': _[29437] }), sendApi(p$DE[_[29258]], _[29438], { 'partner_id': p$DE[_[23748]], 'uid': p$DE[_[25342]], 'game_pkg': p$DE[_[25343]], 'server_id': dcfghe, 'platform': p$DE[_[25314]], 'platform_uid': p$DE[_[25344]], 'check_login_time': p$DE[_[29342]], 'check_login_sign': p$DE[_[29341]], 'version_name': p$DE[_[29319]] }, p$EBDC, p$CED, p$EB, function (yx_$0) {
    return yx_$0[_[4141]] == _[9961] || yx_$0[_[78]] == _[29439] || yx_$0[_[78]] == _[29440];
  });
}, window['p$EBDC'] = function (igjefh) {
  var hifegd = this;if (igjefh[_[4141]] === _[9961] && igjefh[_[11]]) {
    var sqprot = p$DE[_[25337]];sqprot[_[29441]] = p$DE[_[29268]], sqprot[_[11534]] = String(igjefh[_[11]][_[29442]]), sqprot[_[25316]] = parseInt(igjefh[_[11]][_[851]]);if (igjefh[_[11]][_[25315]]) sqprot[_[25315]] = parseInt(igjefh[_[11]][_[25315]]);else sqprot[_[25315]] = parseInt(igjefh[_[11]][_[11551]]);sqprot[_[29443]] = 0x0, sqprot[_[4546]] = p$DE[_[29361]], sqprot[_[29444]] = igjefh[_[11]][_[29445]], sqprot[_[29446]] = igjefh[_[11]][_[29446]], console[_[482]](_[29447] + JSON[_[4532]](sqprot[_[29446]])), p$DE[_[630]] == 0x1 && sqprot[_[29446]] && sqprot[_[29446]][_[29448]] == 0x1 && (p$DE[_[29449]] = 0x1, window[_[29163]][_[148]]['p$AED']()), p$ECBD();
  } else p$DE[_[29436]][_[7163]] >= 0x3 ? (p$EB(JSON[_[4532]](igjefh)), window['p$BCDE'](_[29450] + igjefh[_[4141]])) : sendApi(p$DE[_[29258]], _[29327], { 'platform': p$DE[_[29256]], 'partner_id': p$DE[_[23748]], 'token': p$DE[_[29325]], 'game_pkg': p$DE[_[25343]], 'deviceId': p$DE[_[25345]], 'scene': _[29328] + p$DE[_[29266]] }, function (y$zw_x) {
    if (!y$zw_x || y$zw_x[_[4141]] != _[9961]) {
      window['p$BCDE'](_[29340] + y$zw_x && y$zw_x[_[4141]]);return;
    }p$DE[_[29341]] = String(y$zw_x[_[11534]]), p$DE[_[29342]] = String(y$zw_x[_[851]]), setTimeout(function () {
      p$EBCD(p$DE[_[29436]][_[7163]] + 0x1, p$DE[_[29436]][_[11551]]);
    }, 0x5dc);
  }, p$CED, p$EB, function (xz_) {
    return xz_[_[4141]] == _[9961] || xz_[_[4141]] == _[25674];
  });
}, window['p$ECBD'] = function () {
  ServerLoading[_[148]][_[29353]](p$DE[_[630]]), window['p$CE'] = !![], window['p$EDBC']();
}, window['p$ECDB'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[29274]] && window[_[29275]] && window['p$DEC'] && window['p$DC']) {
    if (!window[_[28611]][_[148]]) {
      console[_[482]](_[29451] + window[_[28611]][_[148]]);var hkifj = wx[_[29452]](),
          portsq = hkifj[_[776]] ? hkifj[_[776]] : 0x0,
          vtus = { 'cdn': window['p$DE'][_[4546]], 'spareCdn': window['p$DE'][_[25047]], 'newRegister': window['p$DE'][_[630]], 'wxPC': window['p$DE'][_[25050]], 'wxIOS': window['p$DE'][_[1074]], 'wxAndroid': window['p$DE'][_[11373]], 'wxParam': { 'limitLoad': window['p$DE']['p$ABCED'], 'benchmarkLevel': window['p$DE']['p$ABDCE'], 'wxFrom': window[_[557]][_[28628]] == _[29453] ? 0x1 : 0x0, 'wxSDKVersion': window[_[29164]] }, 'configType': window['p$DE'][_[11897]], 'exposeType': window['p$DE'][_[714]], 'scene': portsq };new window[_[28611]](vtus, window['p$DE'][_[101]], window['p$ABCDE']);
    }
  }
}, window['p$EDBC'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[29274]] && window[_[29275]] && window['p$DEC'] && window['p$DC'] && window['p$CE'] && window['p$CD']) {
    p$BDEC();if (!p$ECD) {
      p$ECD = !![];if (!window[_[28611]][_[148]]) window['p$ECDB']();var xwtu = 0x0,
          sxwt = wx[_[29454]]();sxwt && (window['p$DE'][_[29220]] && (xwtu = sxwt[_[323]]), console[_[78]](_[29455] + sxwt[_[323]] + _[29456] + sxwt[_[1216]] + _[29457] + sxwt[_[1218]] + _[29458] + sxwt[_[1217]] + _[29459] + sxwt[_[176]] + _[29460] + sxwt[_[177]]));var trpqo = {};for (const kmolnj in p$DE[_[25337]]) {
        trpqo[kmolnj] = p$DE[_[25337]][kmolnj];
      }var zwuvyx = { 'channel': window['p$DE'][_[25341]], 'account': window['p$DE'][_[25342]], 'userId': window['p$DE'][_[23747]], 'cdn': window['p$DE'][_[4546]], 'data': window['p$DE'][_[11]], 'package': window['p$DE'][_[25048]], 'newRegister': window['p$DE'][_[630]], 'pkgName': window['p$DE'][_[25343]], 'partnerId': window['p$DE'][_[23748]], 'platform_uid': window['p$DE'][_[25344]], 'deviceId': window['p$DE'][_[25345]], 'selectedServer': trpqo, 'configType': window['p$DE'][_[11897]], 'exposeType': window['p$DE'][_[714]], 'debugUsers': window['p$DE'][_[12295]], 'wxMenuTop': xwtu, 'wxShield': window['p$DE'][_[738]] };if (window[_[29363]]) for (var mojkln in window[_[29363]]) {
        zwuvyx[mojkln] = window[_[29363]][mojkln];
      }window[_[28611]][_[148]]['p$EDA'](zwuvyx);
    }
  } else console[_[78]](_[29461] + window['p$EC'] + _[29462] + window['p$DCE'] + _[29463] + window[_[29274]] + _[29464] + window[_[29275]] + _[29465] + window['p$DEC'] + _[29466] + window['p$DC'] + _[29467] + window['p$CE'] + _[29468] + window['p$CD']);
};