var M = wx.$T;
console[M[916]](M[917]), window[M[918]], wx[M[919]](function (yxqo0) {
  if (yxqo0) {
    if (yxqo0[M[56]]) {
      var agbjrn = window[M[920]][M[921]][M[243]](new RegExp(/\./, 'g'), '_'),
          nba = yxqo0[M[56]],
          m5_ywh = nba[M[67]](/(ttttttt\/tGAMEtt.js:)[0-9]{1,60}(:)/g);if (m5_ywh) for (var rgnaj = 0x0; rgnaj < m5_ywh[M[31]]; rgnaj++) {
        if (m5_ywh[rgnaj] && m5_ywh[rgnaj][M[31]] > 0x0) {
          var fpz$dv = parseInt(m5_ywh[rgnaj][M[243]](M[922], '')[M[243]](':', ''));nba = nba[M[243]](m5_ywh[rgnaj], m5_ywh[rgnaj][M[243]](':' + fpz$dv + ':', ':' + (fpz$dv - 0x2) + ':'));
        }
      }nba = nba[M[243]](new RegExp(M[923], 'g'), M[924] + agbjrn + M[925]), nba = nba[M[243]](new RegExp(M[926], 'g'), M[924] + agbjrn + M[925]), yxqo0[M[56]] = nba;
    }var xq7oe = { 'id': window['t_ZK'][M[927]], 'role': window['t_ZK'][M[928]], 'level': window['t_ZK'][M[929]], 'user': window['t_ZK'][M[930]], 'version': window['t_ZK'][M[931]], 'cdn': window['t_ZK'][M[932]], 'pkgName': window['t_ZK'][M[933]], 'gamever': window[M[920]][M[921]], 'serverid': window['t_ZK'][M[934]] ? window['t_ZK'][M[934]][M[935]] : 0x0, 'systemInfo': window[M[936]], 'error': M[937], 'stack': yxqo0 ? yxqo0[M[56]] : '' },
        ajkubs = JSON[M[938]](xq7oe);console[M[333]](M[939] + ajkubs), (!window[M[918]] || window[M[918]] != xq7oe[M[333]]) && (window[M[918]] = xq7oe[M[333]], window['t_MZ'](xq7oe));
  }
});import 'ttfttt.js';import 'tt112tt.js';window[M[940]] = require(M[941]);import 'tINDtt.js';import 'ttLIB23tt.js';import 'tWXMtadtt.js';import 'ttINItt.js';console[M[916]](M[942]), console[M[916]](M[943]), t_MZ6K({ 'title': M[944] });var tjagk = { 't_FMKZ6': !![] };new window[M[945]](tjagk), window[M[945]][M[946]]['t_F6ZKM']();if (window['t_FMZK6']) clearInterval(window['t_FMZK6']);window['t_FMZK6'] = null, window['t_F6KMZ'] = function (di9cv, jkuas) {
  if (!di9cv || !jkuas) return 0x0;di9cv = di9cv[M[201]]('.'), jkuas = jkuas[M[201]]('.');const c4i9 = Math[M[301]](di9cv[M[31]], jkuas[M[31]]);while (di9cv[M[31]] < c4i9) {
    di9cv[M[66]]('0');
  }while (jkuas[M[31]] < c4i9) {
    jkuas[M[66]]('0');
  }for (var rabjgn = 0x0; rabjgn < c4i9; rabjgn++) {
    const xhm0y_ = parseInt(di9cv[rabjgn]),
          g3n8jr = parseInt(jkuas[rabjgn]);if (xhm0y_ > g3n8jr) return 0x1;else {
      if (xhm0y_ < g3n8jr) return -0x1;
    }
  }return 0x0;
}, window[M[947]] = wx[M[948]]()[M[947]], console[M[225]](M[949] + window[M[947]]);var tj3b = wx[M[950]]();tj3b[M[951]](function (i9$v) {
  console[M[225]](M[952] + i9$v[M[953]]);
}), tj3b[M[954]](function () {
  wx[M[955]]({ 'title': M[956], 'content': M[957], 'showCancel': ![], 'success': function (g83nr) {
      tj3b[M[958]]();
    } });
}), tj3b[M[959]](function () {
  console[M[225]](M[960]);
}), window['t_F6KZM'] = function () {
  console[M[225]](M[961]);var ragbn = wx[M[962]]({ 'name': M[963], 'success': function (eyq0xo) {
      console[M[225]](M[964]), console[M[225]](eyq0xo), eyq0xo && eyq0xo[M[965]] == M[966] ? (window['t_K6'] = !![], window['t_K6ZM'](), window['t_KZM6']()) : setTimeout(function () {
        window['t_F6KZM']();
      }, 0x1f4);
    }, 'fail': function (c9ti2v) {
      console[M[225]](M[967]), console[M[225]](c9ti2v), setTimeout(function () {
        window['t_F6KZM']();
      }, 0x1f4);
    } });ragbn && ragbn[M[968]](zdv$f => {});
}, window['t_FZMK6'] = function () {
  console[M[225]](M[969]);var opzdf = wx[M[962]]({ 'name': M[970], 'success': function (i492t) {
      console[M[225]](M[971]), console[M[225]](i492t), i492t && i492t[M[965]] == M[966] ? (window['t_Z6K'] = !![], window['t_K6ZM'](), window['t_KZM6']()) : setTimeout(function () {
        window['t_FZMK6']();
      }, 0x1f4);
    }, 'fail': function (whm_x) {
      console[M[225]](M[972]), console[M[225]](whm_x), setTimeout(function () {
        window['t_FZMK6']();
      }, 0x1f4);
    } });opzdf && opzdf[M[968]](mwh651 => {});
}, window[M[973]] = function () {
  window['t_F6KMZ'](window[M[947]], M[974]) >= 0x0 ? (console[M[225]](M[975] + window[M[947]] + M[976]), window['t_ZM'](), window['t_F6KZM'](), window['t_FZMK6']()) : (window['t_ZKM'](M[977], window[M[947]]), wx[M[955]]({ 'title': M[978], 'content': M[979] }));
}, window[M[936]] = '', wx[M[980]]({ 'success'(qex0y_) {
    window[M[936]] = M[981] + qex0y_[M[982]] + M[983] + qex0y_[M[984]] + M[985] + qex0y_[M[986]] + M[987] + qex0y_[M[988]] + M[989] + qex0y_[M[990]] + M[991] + qex0y_[M[947]] + M[992] + qex0y_[M[993]], console[M[225]](window[M[936]]), console[M[225]](M[994] + qex0y_[M[995]] + M[996] + qex0y_[M[997]] + M[998] + qex0y_[M[999]] + M[1000] + qex0y_[M[1001]] + M[1002] + qex0y_[M[1003]] + M[1004] + qex0y_[M[1005]] + M[1006] + (qex0y_[M[1007]] ? qex0y_[M[1007]][M[1008]] + ',' + qex0y_[M[1007]][M[1009]] + ',' + qex0y_[M[1007]][M[1010]] + ',' + qex0y_[M[1007]][M[1011]] : ''));var w5m_yh = qex0y_[M[988]] ? qex0y_[M[988]][M[103]]() : '',
        barnj = qex0y_[M[984]] ? qex0y_[M[984]][M[103]]()[M[243]]('\x20', '') : '';window['t_ZK'][M[1012]] = w5m_yh[M[146]](M[1013]) != -0x1, window['t_ZK'][M[1014]] = w5m_yh[M[146]](M[1015]) != -0x1, window['t_ZK'][M[1016]] = w5m_yh[M[146]](M[1013]) != -0x1 || w5m_yh[M[146]](M[1015]) != -0x1, window['t_ZK'][M[1017]] = w5m_yh[M[146]](M[1018]) != -0x1 || w5m_yh[M[146]](M[1019]) != -0x1, window['t_ZK'][M[1020]] = qex0y_[M[990]] ? qex0y_[M[990]][M[103]]() : '', window['t_ZK']['t_FM6KZ'] = ![], window['t_ZK']['t_FMZ6K'] = 0x2;if (w5m_yh[M[146]](M[1015]) != -0x1) {
      if (qex0y_[M[993]] >= 0x18) window['t_ZK']['t_FMZ6K'] = 0x3;else window['t_ZK']['t_FMZ6K'] = 0x2;
    } else {
      if (w5m_yh[M[146]](M[1013]) != -0x1) {
        if (qex0y_[M[993]] && qex0y_[M[993]] >= 0x14) window['t_ZK']['t_FMZ6K'] = 0x3;else {
          if (barnj[M[146]](M[1021]) != -0x1 || barnj[M[146]](M[1022]) != -0x1 || barnj[M[146]](M[1023]) != -0x1 || barnj[M[146]](M[1024]) != -0x1 || barnj[M[146]](M[1025]) != -0x1) window['t_ZK']['t_FMZ6K'] = 0x2;else window['t_ZK']['t_FMZ6K'] = 0x3;
        }
      } else window['t_ZK']['t_FMZ6K'] = 0x2;
    }console[M[225]](M[1026] + window['t_ZK']['t_FM6KZ'] + M[1027] + window['t_ZK']['t_FMZ6K']);
  } }), wx[M[1028]]({ 'success': function (bauskj) {
    console[M[225]](M[1029] + bauskj[M[1030]] + M[1031] + bauskj[M[1032]]);
  } }), wx[M[1033]]({ 'success': function (ipdv$9) {
    console[M[225]](M[1034] + ipdv$9[M[1035]]);
  } }), wx[M[1036]]({ 'keepScreenOn': !![] }), wx[M[1037]](function (wym5h_) {
  console[M[225]](M[1034] + wym5h_[M[1035]] + M[1038] + wym5h_[M[1039]]);
}), wx[M[1040]](function (gbj3n) {
  window['t_6M'] = gbj3n, window['t_KM6'] && window['t_6M'] && (console[M[916]](M[1041] + window['t_6M'][M[1042]]), window['t_KM6'](window['t_6M']), window['t_6M'] = null);
}), window[M[1043]] = 0x0, window['t_FZ6KM'] = 0x0, window[M[1044]] = null, wx[M[1045]](function () {
  window['t_FZ6KM']++;var _h56 = Date[M[1046]]();(window[M[1043]] == 0x0 || _h56 - window[M[1043]] > 0x1d4c0) && (console[M[383]](M[1047]), wx[M[1048]]());if (window['t_FZ6KM'] >= 0x2) {
    window['t_FZ6KM'] = 0x0, console[M[333]](M[1049]), wx[M[1050]]('0', 0x1);if (window['t_ZK'] && window['t_ZK'][M[1012]]) window['t_ZKM'](M[1051], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});