var M = wx.$T;
import ttvci$ from '../ttkttt/t6ktgt.js';window[M[1052]] = { 'wxVersion': window[M[920]][M[921]] }, window[M[1053]] = ![], window['t_KZ'] = 0x1, window[M[1054]] = 0x1, window['t_6ZK'] = !![], window[M[1055]] = !![], window['t_FM6ZK'] = '', window['t_ZK'] = { 'base_cdn': M[1056], 'cdn': M[1056] }, t_ZK[M[1057]] = {}, t_ZK[M[304]] = '0', t_ZK[M[986]] = window[M[1052]][M[1058]], t_ZK[M[1019]] = '', t_ZK['os'] = '1', t_ZK[M[1059]] = M[1060], t_ZK[M[1061]] = M[1062], t_ZK[M[1063]] = M[1064], t_ZK[M[1065]] = M[1066], t_ZK[M[1067]] = M[1068], t_ZK[M[1069]] = '1', t_ZK[M[933]] = '', t_ZK[M[1070]] = '', t_ZK[M[1071]] = 0x0, t_ZK[M[1072]] = {}, t_ZK[M[1073]] = parseInt(t_ZK[M[1069]]), t_ZK[M[1074]] = t_ZK[M[1069]], t_ZK[M[934]] = {}, t_ZK['t_MZ'] = M[1075], t_ZK[M[1076]] = ![], t_ZK[M[1077]] = M[1078], t_ZK[M[1079]] = Date[M[1046]](), t_ZK[M[1080]] = M[1081], t_ZK[M[1082]] = '_a', t_ZK[M[1083]] = 0x1, t_ZK[M[931]] = 0x7c1, t_ZK[M[1058]] = window[M[1052]][M[1058]], t_ZK[M[1084]] = ![], t_ZK[M[1012]] = ![], t_ZK[M[1014]] = ![], t_ZK[M[1017]] = ![], window['t_6KZ'] = 0x5, window['t_6K'] = ![], window['t_K6'] = ![], window['t_Z6K'] = ![], window[M[1085]] = ![], window[M[1086]] = ![], window['t_ZK6'] = ![], window['t_6Z'] = ![], window['t_Z6'] = ![], window['t_K6Z'] = ![], window[M[1087]] = function (l24c) {
  console[M[225]](M[1087], l24c), wx[M[1088]]({}), wx[M[955]]({ 'title': M[978], 'content': l24c, 'success'(c4ti2l) {
      if (c4ti2l[M[1089]]) console[M[225]](M[1090]);else c4ti2l[M[1091]] && console[M[225]](M[1092]);
    } });
}, window['t_M6ZK'] = function (xhmw_y) {
  console[M[225]](M[1093], xhmw_y), t_MZK6(), wx[M[955]]({ 'title': M[978], 'content': xhmw_y, 'confirmText': M[1094], 'cancelText': M[1095], 'success'(p7$zd) {
      if (p7$zd[M[1089]]) window['t_ZM']();else p7$zd[M[1091]] && (console[M[225]](M[1096]), wx[M[1097]]({}));
    } });
}, window[M[1098]] = function (ranjb) {
  console[M[225]](M[1098], ranjb), wx[M[955]]({ 'title': M[978], 'content': ranjb, 'confirmText': M[1099], 'showCancel': ![], 'complete'(ipdv$9) {
      console[M[225]](M[1096]), wx[M[1097]]({});
    } });
}, window['t_M6KZ'] = ![], window['t_MZ6K'] = function (vpz$fd) {
  window['t_M6KZ'] = !![], wx[M[1100]](vpz$fd);
}, window['t_MZK6'] = function () {
  window['t_M6KZ'] && (window['t_M6KZ'] = ![], wx[M[1088]]({}));
}, window['t_MK6Z'] = function (jrgn8) {
  window[M[945]][M[946]]['t_MK6Z'](jrgn8);
}, window[M[1101]] = function (bgjn3, bgjkr) {
  ttvci$[M[1101]](bgjn3, function (_mhw5) {
    _mhw5 && _mhw5[M[335]] ? _mhw5[M[335]][M[1102]] == 0x1 ? bgjkr(!![]) : (bgjkr(![]), console[M[916]](M[1103] + _mhw5[M[335]][M[1104]])) : console[M[225]](M[1101], _mhw5);
  });
}, window['t_MKZ6'] = function ($fpvz) {
  console[M[225]](M[1105], $fpvz);
}, window['t_MZK'] = function (n613g8) {}, window['t_MKZ'] = function (bjnrag, pze7f, kar) {}, window['t_MK'] = function (ngj38r) {
  console[M[225]](M[1106], ngj38r), window[M[945]][M[946]][M[1107]](), window[M[945]][M[946]][M[1108]](), window[M[945]][M[946]][M[1109]]();
}, window['t_KM'] = function (qfo7ez) {
  window['t_M6ZK'](M[1110]);var v$9d = { 'id': window['t_ZK'][M[927]], 'role': window['t_ZK'][M[928]], 'level': window['t_ZK'][M[929]], 'account': window['t_ZK'][M[930]], 'version': window['t_ZK'][M[931]], 'cdn': window['t_ZK'][M[932]], 'pkgName': window['t_ZK'][M[933]], 'gamever': window[M[920]][M[921]], 'serverid': window['t_ZK'][M[934]] ? window['t_ZK'][M[934]][M[935]] : 0x0, 'systemInfo': window[M[936]], 'error': M[1111], 'stack': qfo7ez ? qfo7ez : M[1110] },
      vd$p = JSON[M[938]](v$9d);console[M[333]](M[1112] + vd$p), window['t_MZ'](vd$p);
}, window['t_ZMK'] = function (o0q7xe) {
  var eo0x7q = JSON[M[223]](o0q7xe);eo0x7q[M[1113]] = window[M[920]][M[921]], eo0x7q[M[1114]] = window['t_ZK'][M[934]] ? window['t_ZK'][M[934]][M[935]] : 0x0, eo0x7q[M[936]] = window[M[936]];var nragj = JSON[M[938]](eo0x7q);console[M[333]](M[1115] + nragj), window['t_MZ'](nragj);
}, window['t_ZKM'] = function (vc9di, ic49t2) {
  var ofzd = { 'id': window['t_ZK'][M[927]], 'role': window['t_ZK'][M[928]], 'level': window['t_ZK'][M[929]], 'account': window['t_ZK'][M[930]], 'version': window['t_ZK'][M[931]], 'cdn': window['t_ZK'][M[932]], 'pkgName': window['t_ZK'][M[933]], 'gamever': window[M[920]][M[921]], 'serverid': window['t_ZK'][M[934]] ? window['t_ZK'][M[934]][M[935]] : 0x0, 'systemInfo': window[M[936]], 'error': vc9di, 'stack': ic49t2 },
      zpeof = JSON[M[938]](ofzd);console[M[383]](M[1116] + zpeof), window['t_MZ'](zpeof);
}, window['t_MZ'] = function (qe0x7) {
  if (window['t_ZK'][M[1020]] == M[1117]) return;var oz7fp = t_ZK['t_MZ'] + M[1118] + t_ZK[M[930]];wx[M[1119]]({ 'url': oz7fp, 'method': M[1120], 'data': qe0x7, 'header': { 'content-type': M[1121], 'cache-control': M[1122] }, 'success': function (_yhxm) {
      DEBUG && console[M[225]](M[1123], oz7fp, qe0x7, _yhxm);
    }, 'fail': function (vic9) {
      DEBUG && console[M[225]](M[1123], oz7fp, qe0x7, vic9);
    }, 'complete': function () {} });
}, window[M[1124]] = function () {
  function i9vt() {
    return ((0x1 + Math[M[1125]]()) * 0x10000 | 0x0)[M[60]](0x10)[M[234]](0x1);
  }return i9vt() + i9vt() + '-' + i9vt() + '-' + i9vt() + '-' + i9vt() + '+' + i9vt() + i9vt() + i9vt();
}, window['t_ZM'] = function () {
  console[M[225]](M[1126]);var zo = ttvci$[M[1127]]();t_ZK[M[1074]] = zo[M[1128]], t_ZK[M[1073]] = zo[M[1128]], t_ZK[M[1069]] = zo[M[1128]], t_ZK[M[933]] = zo[M[1129]];var wmy5_ = { 'game_ver': t_ZK[M[986]] };t_ZK[M[1070]] = this[M[1124]](), t_MZ6K({ 'title': M[1130] }), ttvci$[M[1131]](wmy5_, this['t_KMZ'][M[17]](this));
}, window['t_KMZ'] = function (vp$fd) {
  var oxeq0 = vp$fd[M[1132]];console[M[225]](M[1133] + oxeq0 + M[1134] + (oxeq0 == 0x1) + M[1135] + vp$fd[M[921]] + M[1136] + window[M[1052]][M[1058]]);if (!vp$fd[M[921]] || window['t_F6KMZ'](window[M[1052]][M[1058]], vp$fd[M[921]]) < 0x0) console[M[225]](M[1137]), t_ZK[M[1061]] = M[1138], t_ZK[M[1063]] = M[1139], t_ZK[M[1065]] = M[1140], t_ZK[M[932]] = M[1141], t_ZK[M[1142]] = M[1143], t_ZK[M[1144]] = M[1145], t_ZK[M[1084]] = ![];else window['t_F6KMZ'](window[M[1052]][M[1058]], vp$fd[M[921]]) == 0x0 ? (console[M[225]](M[1146]), t_ZK[M[1061]] = M[1062], t_ZK[M[1063]] = M[1064], t_ZK[M[1065]] = M[1066], t_ZK[M[932]] = M[1056], t_ZK[M[1142]] = M[1143], t_ZK[M[1144]] = M[1145], t_ZK[M[1084]] = !![]) : (console[M[225]](M[1147]), t_ZK[M[1061]] = M[1062], t_ZK[M[1063]] = M[1064], t_ZK[M[1065]] = M[1066], t_ZK[M[932]] = M[1056], t_ZK[M[1142]] = M[1143], t_ZK[M[1144]] = M[1145], t_ZK[M[1084]] = ![]);t_ZK[M[1071]] = config[M[51]] ? config[M[51]] : 0x0, this['t_6ZMK'](), this['t_6ZKM'](), window[M[1148]] = 0x5, t_MZ6K({ 'title': M[1149] }), ttvci$[M[1150]](this['t_KZM'][M[17]](this));
}, window[M[1148]] = 0x5, window['t_KZM'] = function (hmyx0_, pz7do) {
  if (hmyx0_ == 0x0 && pz7do && pz7do[M[285]]) {
    t_ZK[M[1151]] = pz7do[M[285]];var n3g8rj = this;t_MZ6K({ 'title': M[1152] }), sendApi(t_ZK[M[1061]], M[1153], { 'platform': t_ZK[M[1059]], 'partner_id': t_ZK[M[1069]], 'token': pz7do[M[285]], 'game_pkg': t_ZK[M[933]], 'deviceId': t_ZK[M[1070]], 'scene': M[1154] + t_ZK[M[1071]] }, this['t_6MZK'][M[17]](this), t_6KZ, t_KM);
  } else pz7do && pz7do[M[965]] && window[M[1148]] > 0x0 && (pz7do[M[965]][M[146]](M[1155]) != -0x1 || pz7do[M[965]][M[146]](M[1156]) != -0x1 || pz7do[M[965]][M[146]](M[1157]) != -0x1 || pz7do[M[965]][M[146]](M[1158]) != -0x1 || pz7do[M[965]][M[146]](M[1159]) != -0x1 || pz7do[M[965]][M[146]](M[1160]) != -0x1) ? (window[M[1148]]--, ttvci$[M[1150]](this['t_KZM'][M[17]](this))) : (window['t_ZKM'](M[1161], JSON[M[938]]({ 'status': hmyx0_, 'data': pz7do })), window['t_M6ZK'](M[1162] + (pz7do && pz7do[M[965]] ? '，' + pz7do[M[965]] : '')));
}, window['t_6MZK'] = function (z$f7) {
  if (!z$f7) {
    window['t_ZKM'](M[1163], M[1164]), window['t_M6ZK'](M[1165]);return;
  }if (z$f7[M[1102]] != M[1166]) {
    window['t_ZKM'](M[1163], JSON[M[938]](z$f7)), window['t_M6ZK'](M[1167] + z$f7[M[1102]]);return;
  }t_ZK[M[1168]] = String(z$f7[M[930]]), t_ZK[M[930]] = String(z$f7[M[930]]), t_ZK[M[990]] = String(z$f7[M[990]]), t_ZK[M[1074]] = String(z$f7[M[990]]), t_ZK[M[1169]] = String(z$f7[M[1169]]), t_ZK[M[1170]] = String(z$f7[M[1171]]), t_ZK[M[1172]] = String(z$f7[M[1173]]), t_ZK[M[1171]] = '';var kasbj = this;t_MZ6K({ 'title': M[1174] }), sendApi(t_ZK[M[1061]], M[1175], { 'partner_id': t_ZK[M[1069]], 'uid': t_ZK[M[930]], 'version': t_ZK[M[986]], 'game_pkg': t_ZK[M[933]], 'device': t_ZK[M[1070]] }, kasbj['t_6MKZ'][M[17]](kasbj), t_6KZ, t_KM);
}, window['t_6MKZ'] = function (jkbsau) {
  if (!jkbsau) {
    window['t_M6ZK'](M[1176]);return;
  }if (jkbsau[M[1102]] != M[1166]) {
    window['t_M6ZK'](M[1177] + jkbsau[M[1102]]);return;
  }if (!jkbsau[M[335]] || jkbsau[M[335]][M[31]] == 0x0) {
    window['t_M6ZK'](M[1178]);return;
  }t_ZK[M[1179]] = jkbsau[M[1180]], t_ZK[M[934]] = { 'server_id': String(jkbsau[M[335]][0x0][M[935]]), 'server_name': String(jkbsau[M[335]][0x0][M[1181]]), 'entry_ip': jkbsau[M[335]][0x0][M[1182]], 'entry_port': parseInt(jkbsau[M[335]][0x0][M[1183]]), 'status': t_Z6M(jkbsau[M[335]][0x0]), 'start_time': jkbsau[M[335]][0x0]['start_time'], 'cdn': t_ZK[M[932]] }, this['t_KZ6M']();
}, window['t_KZ6M'] = function () {
  if (t_ZK[M[1179]] == 0x1) {
    var dpf7z = t_ZK[M[934]][M[1184]];if (dpf7z === -0x1 || dpf7z === 0x0) {
      window['t_M6ZK'](dpf7z === -0x1 ? M[1185] : M[1186]);return;
    }t_KM6Z(0x0, t_ZK[M[934]][M[935]]), window[M[945]][M[946]][M[1187]](t_ZK[M[1179]]);
  } else window[M[945]][M[946]][M[1188]](), t_MZK6();window['t_Z6'] = !![], window['t_K6ZM'](), window['t_KZM6']();
}, window['t_6ZMK'] = function () {
  sendApi(t_ZK[M[1061]], M[1189], { 'game_pkg': t_ZK[M[933]], 'version_name': t_ZK[M[1144]] }, this[M[1190]][M[17]](this), t_6KZ, t_KM);
}, window[M[1190]] = function (xhwy_m) {
  if (!xhwy_m) {
    window['t_M6ZK'](M[1191]);return;
  }if (xhwy_m[M[1102]] != M[1166]) {
    window['t_M6ZK'](M[1192] + xhwy_m[M[1102]]);return;
  }if (!xhwy_m[M[335]] || !xhwy_m[M[335]][M[986]]) {
    window['t_M6ZK'](M[1193] + (xhwy_m[M[335]] && xhwy_m[M[335]][M[986]]));return;
  }xhwy_m[M[335]][M[1194]] && xhwy_m[M[335]][M[1194]][M[31]] > 0xa && (t_ZK[M[1195]] = xhwy_m[M[335]][M[1194]], t_ZK[M[932]] = xhwy_m[M[335]][M[1194]]), xhwy_m[M[335]][M[986]] && (t_ZK[M[931]] = xhwy_m[M[335]][M[986]]), console[M[916]](M[1196] + t_ZK[M[931]] + M[1197] + t_ZK[M[1144]]), window['t_ZK6'] = !![], window['t_K6ZM'](), window['t_KZM6']();
}, window[M[1198]], window['t_6ZKM'] = function () {
  sendApi(t_ZK[M[1061]], 'Common.get_option_pkg', { 'game_pkg': t_ZK[M[933]] }, this['t_6KMZ'][M[17]](this), t_6KZ, t_KM);
}, window['t_6KMZ'] = function (ozefq) {
  if (ozefq[M[1102]] === M[1166] && ozefq[M[335]]) {
    window[M[1198]] = ozefq[M[335]];for (var piv9$ in ozefq[M[335]]) {
      t_ZK[piv9$] = ozefq[M[335]][piv9$];
    }
  } else console[M[916]](M[1199] + ozefq[M[1102]]);window['t_6Z'] = !![], window['t_KZM6']();
}, window[M[1200]] = function (brasj, zpodf, p$z7d, n1836, m6h_w5, bsjrk, rbkasj, n3561, jbagkr) {
  m6h_w5 = String(m6h_w5);var y_x0mh = rbkasj,
      df$pz7 = n3561;t_ZK[M[1057]][m6h_w5] = { 'productid': m6h_w5, 'productname': y_x0mh, 'productdesc': df$pz7, 'roleid': brasj, 'rolename': zpodf, 'rolelevel': p$z7d, 'price': bsjrk, 'callback': jbagkr }, sendApi(t_ZK[M[1065]], M[1201], { 'game_pkg': t_ZK[M[933]], 'server_id': t_ZK[M[934]][M[935]], 'server_name': t_ZK[M[934]][M[1181]], 'level': p$z7d, 'uid': t_ZK[M[930]], 'role_id': brasj, 'role_name': zpodf, 'product_id': m6h_w5, 'product_name': y_x0mh, 'product_desc': df$pz7, 'money': bsjrk, 'partner_id': t_ZK[M[1069]] }, toPayCallBack, t_6KZ, t_KM);
}, window[M[1202]] = function (ofpd) {
  if (ofpd) {
    if (ofpd[M[1203]] === 0xc8 || ofpd[M[1102]] == M[1166]) {
      var $7dpzf = t_ZK[M[1057]][String(ofpd['product_id'])];if ($7dpzf[M[1204]]) $7dpzf[M[1204]](ofpd['product_id'], ofpd[M[1205]], -0x1);ttvci$[M[1206]]({ 'cpbill': ofpd[M[1205]], 'productid': ofpd['product_id'], 'productname': $7dpzf[M[1207]], 'productdesc': $7dpzf[M[1208]], 'serverid': t_ZK[M[934]][M[935]], 'servername': t_ZK[M[934]][M[1181]], 'roleid': $7dpzf[M[1209]], 'rolename': $7dpzf[M[1210]], 'rolelevel': $7dpzf[M[1211]], 'price': $7dpzf[M[1212]], 'extension': JSON[M[938]]({ 'cp_order_id': ofpd[M[1205]] }) }, function (zod7fp, q0y_m) {
        $7dpzf[M[1204]] && zod7fp == 0x0 && $7dpzf[M[1204]](ofpd['product_id'], ofpd[M[1205]], zod7fp);console[M[916]](JSON[M[938]]({ 'type': M[1213], 'status': zod7fp, 'data': ofpd, 'role_name': $7dpzf[M[1210]] }));if (zod7fp === 0x0) {} else {
          if (zod7fp === 0x1) {} else {
            if (zod7fp === 0x2) {}
          }
        }
      });
    } else alert(ofpd[M[916]]);
  }
}, window['t_6KZM'] = function () {}, window['t_M6K'] = function (vzdp$f, c2ilt, ivd9c$, b3jn, myxw_) {
  ttvci$[M[1214]](t_ZK[M[934]][M[935]], t_ZK[M[934]][M[1181]] || t_ZK[M[934]][M[935]], vzdp$f, c2ilt, ivd9c$), sendApi(t_ZK[M[1061]], M[1215], { 'game_pkg': t_ZK[M[933]], 'server_id': t_ZK[M[934]][M[935]], 'role_id': vzdp$f, 'uid': t_ZK[M[930]], 'role_name': c2ilt, 'role_type': b3jn, 'level': ivd9c$ });
}, window['t_MK6'] = function (jrks, pf$dz, _ym0qx, _y5w, qxeo0, n68351, r813ng, $pi9v, my0h_x, gjabn) {
  t_ZK[M[927]] = jrks, t_ZK[M[928]] = pf$dz, t_ZK[M[929]] = _ym0qx, ttvci$[M[1216]](t_ZK[M[934]][M[935]], t_ZK[M[934]][M[1181]] || t_ZK[M[934]][M[935]], jrks, pf$dz, _ym0qx), sendApi(t_ZK[M[1061]], M[1217], { 'game_pkg': t_ZK[M[933]], 'server_id': t_ZK[M[934]][M[935]], 'role_id': jrks, 'uid': t_ZK[M[930]], 'role_name': pf$dz, 'role_type': _y5w, 'level': _ym0qx, 'evolution': qxeo0 });
}, window['t_6MK'] = function (m5hw_6, ctiv$, e7xq0o, tcvi9$, p$z7f, fzop7, wh1865, t49, xq_y, ng1r3) {
  t_ZK[M[927]] = m5hw_6, t_ZK[M[928]] = ctiv$, t_ZK[M[929]] = e7xq0o, ttvci$[M[1218]](t_ZK[M[934]][M[935]], t_ZK[M[934]][M[1181]] || t_ZK[M[934]][M[935]], m5hw_6, ctiv$, e7xq0o), sendApi(t_ZK[M[1061]], M[1217], { 'game_pkg': t_ZK[M[933]], 'server_id': t_ZK[M[934]][M[935]], 'role_id': m5hw_6, 'uid': t_ZK[M[930]], 'role_name': ctiv$, 'role_type': tcvi9$, 'level': e7xq0o, 'evolution': p$z7f });
}, window['t_6KM'] = function (w813) {}, window['t_M6'] = function (e_qy0x) {
  ttvci$[M[1219]](M[1219], function (x0_yh) {
    e_qy0x && e_qy0x(x0_yh);
  });
}, window[M[1220]] = function () {
  ttvci$[M[1220]]();
}, window[M[1221]] = function () {
  ttvci$[M[1222]]();
}, window[M[1223]] = function (gnr31, ym0x_, bjrn, wh1m65, yw_hxm, ksajb, pod7f, qezof7) {
  qezof7 = qezof7 || t_ZK[M[934]][M[935]], sendApi(t_ZK[M[1061]], 'User.get_code', { 'phone': gnr31, 'role_id': ym0x_, 'uid': t_ZK[M[930]], 'game_pkg': t_ZK[M[933]], 'partner_id': t_ZK[M[1069]], 'server_id': qezof7 }, pod7f);
}, window[M[1040]] = function (il2c) {
  window['t_KM6'] = il2c, window['t_KM6'] && window['t_6M'] && (console[M[916]](M[1041] + window['t_6M'][M[1042]]), window['t_KM6'](window['t_6M']), window['t_6M'] = null);
}, window['t_K6M'] = function (x0m_q, m5yw_, _0yqxe, fvd$zp) {
  window[M[1224]](M[1225], { 'game_pkg': window['t_ZK'][M[933]], 'role_id': m5yw_, 'server_id': _0yqxe }, fvd$zp);
}, window['t_ZM6K'] = function (my_h5, _mw6) {
  function pofzd(ticv$9) {
    var f7qeoz = [],
        i9vct2 = [],
        krjbs = window[M[920]][M[1226]];for (var qy0oxe in krjbs) {
      var ajkubs = Number(qy0oxe);(!my_h5 || !my_h5[M[31]] || my_h5[M[146]](ajkubs) != -0x1) && (i9vct2[M[66]](krjbs[qy0oxe]), f7qeoz[M[66]]([ajkubs, 0x3]));
    }window['t_F6KMZ'](window[M[947]], M[1227]) >= 0x0 ? (console[M[225]](M[1228]), ttvci$[M[1229]](i9vct2, function (bkaj) {
      console[M[225]](M[1230]), console[M[225]](bkaj);if (bkaj && bkaj[M[965]] == M[1231]) for (var jagk in krjbs) {
        if (bkaj[krjbs[jagk]] == M[1232]) {
          var fod7zp = Number(jagk);for (var fzpo = 0x0; fzpo < f7qeoz[M[31]]; fzpo++) {
            if (f7qeoz[fzpo][0x0] == fod7zp) {
              f7qeoz[fzpo][0x1] = 0x1;break;
            }
          }
        }
      }window['t_F6KMZ'](window[M[947]], M[1233]) >= 0x0 ? wx[M[1234]]({ 'withSubscriptions': !![], 'success': function (jb3rng) {
          var iv2c = jb3rng[M[1235]][M[1236]];if (iv2c) {
            console[M[225]](M[1237]), console[M[225]](iv2c);for (var rskab in krjbs) {
              if (iv2c[krjbs[rskab]] == M[1232]) {
                var h0yxm_ = Number(rskab);for (var pzod7 = 0x0; pzod7 < f7qeoz[M[31]]; pzod7++) {
                  if (f7qeoz[pzod7][0x0] == h0yxm_) {
                    f7qeoz[pzod7][0x1] = 0x2;break;
                  }
                }
              }
            }console[M[225]](f7qeoz), _mw6 && _mw6(f7qeoz);
          } else console[M[225]](M[1238]), console[M[225]](jb3rng), console[M[225]](f7qeoz), _mw6 && _mw6(f7qeoz);
        }, 'fail': function () {
          console[M[225]](M[1239]), console[M[225]](f7qeoz), _mw6 && _mw6(f7qeoz);
        } }) : (console[M[225]](M[1240] + window[M[947]]), console[M[225]](f7qeoz), _mw6 && _mw6(f7qeoz));
    })) : (console[M[225]](M[1241] + window[M[947]]), console[M[225]](f7qeoz), _mw6 && _mw6(f7qeoz)), wx[M[1242]](pofzd);
  }wx[M[1243]](pofzd);
}, window['t_ZMK6'] = { 'isSuccess': ![], 'level': M[1244], 'isCharging': ![] }, window['t_Z6MK'] = function (_ymwh5) {
  wx[M[1028]]({ 'success': function (n385) {
      var xy0qoe = window['t_ZMK6'];xy0qoe[M[1245]] = !![], xy0qoe[M[1030]] = Number(n385[M[1030]])[M[1246]](0x0), xy0qoe[M[1032]] = n385[M[1032]], _ymwh5 && _ymwh5(xy0qoe[M[1245]], xy0qoe[M[1030]], xy0qoe[M[1032]]);
    }, 'fail': function (i4tc9) {
      console[M[225]](M[1247], i4tc9[M[965]]);var kjsba = window['t_ZMK6'];_ymwh5 && _ymwh5(kjsba[M[1245]], kjsba[M[1030]], kjsba[M[1032]]);
    } });
}, window[M[1224]] = function (kubsa, w_5hm, rkagbj, bsjuka, bjagnr, gnr3bj, whmy_x, p7fze) {
  if (bsjuka == undefined) bsjuka = 0x1;wx[M[1119]]({ 'url': kubsa, 'method': whmy_x || M[1248], 'responseType': M[1249], 'data': w_5hm, 'header': { 'content-type': p7fze || M[1121] }, 'success': function (qxe0o) {
      DEBUG && console[M[225]](M[1250], kubsa, info, qxe0o);if (qxe0o && qxe0o[M[1251]] == 0xc8) {
        var i4tl2c = qxe0o[M[335]];!gnr3bj || gnr3bj(i4tl2c) ? rkagbj && rkagbj(i4tl2c) : window[M[1252]](kubsa, w_5hm, rkagbj, bsjuka, bjagnr, gnr3bj, qxe0o);
      } else window[M[1252]](kubsa, w_5hm, rkagbj, bsjuka, bjagnr, gnr3bj, qxe0o);
    }, 'fail': function (vc29) {
      DEBUG && console[M[225]](M[1253], kubsa, info, vc29), window[M[1252]](kubsa, w_5hm, rkagbj, bsjuka, bjagnr, gnr3bj, vc29);
    }, 'complete': function () {} });
}, window[M[1252]] = function (jasbk, y0xeqo, rnjg8, jrg8, xqo07e, j8n3g, $dz7p) {
  jrg8 - 0x1 > 0x0 ? setTimeout(function () {
    window[M[1224]](jasbk, y0xeqo, rnjg8, jrg8 - 0x1, xqo07e, j8n3g);
  }, 0x3e8) : xqo07e && xqo07e(JSON[M[938]]({ 'url': jasbk, 'response': $dz7p }));
}, window[M[1254]] = function (clt, krbaj, bsjark, krjsb, zof, z07qe, hx_w) {
  !bsjark && (bsjark = {});var f7pzod = Math[M[71]](Date[M[1046]]() / 0x3e8);bsjark[M[1173]] = f7pzod, bsjark[M[1255]] = krbaj;var yq_ex0 = Object[M[30]](bsjark)[M[382]](),
      $dzvfp = '',
      fqe7oz = '';for (var ajksb = 0x0; ajksb < yq_ex0[M[31]]; ajksb++) {
    $dzvfp = $dzvfp + (ajksb == 0x0 ? '' : '&') + yq_ex0[ajksb] + bsjark[yq_ex0[ajksb]], fqe7oz = fqe7oz + (ajksb == 0x0 ? '' : '&') + yq_ex0[ajksb] + '=' + encodeURIComponent(bsjark[yq_ex0[ajksb]]);
  }$dzvfp = $dzvfp + t_ZK[M[1067]];var h16wm5 = M[1256] + md5($dzvfp);send(clt + '?' + fqe7oz + (fqe7oz == '' ? '' : '&') + h16wm5, null, krjsb, zof, z07qe, hx_w || function (m165h) {
    return m165h[M[1102]] == M[1166];
  }, null, M[1257]);
}, window['t_Z6KM'] = function (brnj3, rabnjg) {
  var zef7o = 0x0;t_ZK[M[934]] && (zef7o = t_ZK[M[934]][M[935]]), sendApi(t_ZK[M[1063]], M[1258], { 'partnerId': t_ZK[M[1069]], 'gamePkg': t_ZK[M[933]], 'logTime': Math[M[71]](Date[M[1046]]() / 0x3e8), 'platformUid': t_ZK[M[1169]], 'type': brnj3, 'serverId': zef7o }, null, 0x2, null, function () {
    return !![];
  });
}, window['t_ZKM6'] = function (my_w5h) {
  sendApi(t_ZK[M[1061]], M[1259], { 'partner_id': t_ZK[M[1069]], 'uid': t_ZK[M[930]], 'version': t_ZK[M[986]], 'game_pkg': t_ZK[M[933]], 'device': t_ZK[M[1070]] }, t_ZK6M, t_6KZ, t_KM);
}, window['t_ZK6M'] = function (hw65) {
  if (hw65[M[1102]] === M[1166] && hw65[M[335]]) {
    hw65[M[335]][M[174]]({ 'id': -0x2, 'name': M[1260] }), hw65[M[335]][M[174]]({ 'id': -0x1, 'name': M[1261] }), t_ZK[M[1262]] = hw65[M[335]];if (window[M[1263]]) window[M[1263]][M[1264]]();
  } else t_ZK[M[1265]] = ![], window['t_M6ZK'](M[1266] + hw65[M[1102]]);
}, window['t_M6Z'] = function (pf7eoz) {
  sendApi(t_ZK[M[1061]], M[1267], { 'partner_id': t_ZK[M[1069]], 'uid': t_ZK[M[930]], 'version': t_ZK[M[986]], 'game_pkg': t_ZK[M[933]], 'device': t_ZK[M[1070]] }, t_MZ6, t_6KZ, t_KM);
}, window['t_MZ6'] = function (vd$c) {
  t_ZK[M[1268]] = ![];if (vd$c[M[1102]] === M[1166] && vd$c[M[335]]) {
    for (var kasjub = 0x0; kasjub < vd$c[M[335]][M[31]]; kasjub++) {
      vd$c[M[335]][kasjub][M[1184]] = t_Z6M(vd$c[M[335]][kasjub]);
    }t_ZK[M[1072]][-0x1] = window[M[1269]](vd$c[M[335]]), window[M[1263]][M[1270]](-0x1);
  } else window['t_M6ZK'](M[1271] + vd$c[M[1102]]);
}, window[M[1272]] = function (mw61) {
  sendApi(t_ZK[M[1061]], M[1267], { 'partner_id': t_ZK[M[1069]], 'uid': t_ZK[M[930]], 'version': t_ZK[M[986]], 'game_pkg': t_ZK[M[933]], 'device': t_ZK[M[1070]] }, mw61, t_6KZ, t_KM);
}, window['t_6MZ'] = function (qxy0oe, qz7of) {
  sendApi(t_ZK[M[1061]], M[1273], { 'partner_id': t_ZK[M[1069]], 'uid': t_ZK[M[930]], 'version': t_ZK[M[986]], 'game_pkg': t_ZK[M[933]], 'device': t_ZK[M[1070]], 'server_group_id': qz7of }, t_6ZM, t_6KZ, t_KM);
}, window['t_6ZM'] = function (fp$9vd) {
  t_ZK[M[1268]] = ![];if (fp$9vd[M[1102]] === M[1166] && fp$9vd[M[335]] && fp$9vd[M[335]][M[335]]) {
    var o0ye = fp$9vd[M[335]][M[1274]],
        qoe70z = [];for (var jg83nr = 0x0; jg83nr < fp$9vd[M[335]][M[335]][M[31]]; jg83nr++) {
      fp$9vd[M[335]][M[335]][jg83nr][M[1184]] = t_Z6M(fp$9vd[M[335]][M[335]][jg83nr]), (qoe70z[M[31]] == 0x0 || fp$9vd[M[335]][M[335]][jg83nr][M[1184]] != 0x0) && (qoe70z[qoe70z[M[31]]] = fp$9vd[M[335]][M[335]][jg83nr]);
    }t_ZK[M[1072]][o0ye] = window[M[1269]](qoe70z), window[M[1263]][M[1270]](o0ye);
  } else window['t_M6ZK'](M[1275] + fp$9vd[M[1102]]);
}, window['t_F6KZ'] = function (o0qz7e) {
  sendApi(t_ZK[M[1061]], M[1276], { 'partner_id': t_ZK[M[1069]], 'uid': t_ZK[M[930]], 'version': t_ZK[M[986]], 'game_pkg': t_ZK[M[933]], 'device': t_ZK[M[1070]] }, reqServerRecommendCallBack, t_6KZ, t_KM);
}, window[M[1277]] = function (d7pofz) {
  t_ZK[M[1268]] = ![];if (d7pofz[M[1102]] === M[1166] && d7pofz[M[335]]) {
    for (var qe7o0z = 0x0; qe7o0z < d7pofz[M[335]][M[31]]; qe7o0z++) {
      d7pofz[M[335]][qe7o0z][M[1184]] = t_Z6M(d7pofz[M[335]][qe7o0z]);
    }t_ZK[M[1072]][-0x2] = window[M[1269]](d7pofz[M[335]]), window[M[1263]][M[1270]](-0x2);
  } else alert(M[1278] + d7pofz[M[1102]]);
}, window[M[1269]] = function (r3gjn) {
  if (!r3gjn && r3gjn[M[31]] <= 0x0) return r3gjn;for (let p$dfzv = 0x0; p$dfzv < r3gjn[M[31]]; p$dfzv++) {
    r3gjn[p$dfzv][M[1279]] && r3gjn[p$dfzv][M[1279]] == 0x1 && (r3gjn[p$dfzv][M[1181]] += M[1280]);
  }return r3gjn;
}, window['t_ZM6'] = function (rjng3, i9dp$v) {
  rjng3 = rjng3 || t_ZK[M[934]][M[935]], sendApi(t_ZK[M[1061]], 'Common.get_anno', { 'type': '4', 'game_pkg': t_ZK[M[933]], 'server_id': rjng3 }, i9dp$v);
}, window[M[1281]] = function (q7z0eo, yqo0x, mw_yxh, w15m6h) {
  mw_yxh = mw_yxh || t_ZK[M[934]][M[935]], sendApi(t_ZK[M[1061]], 'Common.get_new_anno', { 'type': q7z0eo, 'game_pkg': yqo0x, 'server_id': mw_yxh }, w15m6h);
}, window['t_Z6M'] = function (vf$pzd) {
  if (vf$pzd) {
    if (vf$pzd[M[1184]] == 0x1) {
      if (vf$pzd[M[1282]] == 0x1) return 0x2;else return 0x1;
    } else return vf$pzd[M[1184]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['t_KM6Z'] = function (epz7fo, bkusj) {
  t_ZK['last_check_ban'] = { 'step': epz7fo, 'server_id': bkusj };var _h5ywm = this;t_MZ6K({ 'title': M[1283] }), sendApi(t_ZK[M[1061]], M[1284], { 'partner_id': t_ZK[M[1069]], 'uid': t_ZK[M[930]], 'game_pkg': t_ZK[M[933]], 'server_id': bkusj, 'platform': t_ZK[M[990]], 'platform_uid': t_ZK[M[1169]], 'check_login_time': t_ZK[M[1172]], 'check_login_sign': t_ZK[M[1170]], 'version_name': t_ZK[M[1144]] }, t_KMZ6, t_6KZ, t_KM, function (pd$vi9) {
    return pd$vi9[M[1102]] == M[1166] || pd$vi9[M[916]] == M[1285] || pd$vi9[M[916]] == M[1286];
  });
}, window['t_KMZ6'] = function (gn138) {
  var yoeq0x = this;if (gn138[M[1102]] === M[1166] && gn138[M[335]]) {
    var ubksj = t_ZK[M[934]];ubksj[M[1287]] = t_ZK[M[1073]], ubksj[M[1171]] = String(gn138[M[335]][M[1288]]), ubksj[M[1079]] = parseInt(gn138[M[335]][M[1173]]);if (gn138[M[335]][M[1289]]) ubksj[M[1289]] = parseInt(gn138[M[335]][M[1289]]);else ubksj[M[1289]] = parseInt(gn138[M[335]][M[935]]);ubksj[M[1290]] = 0x0, ubksj[M[932]] = t_ZK[M[1195]], ubksj[M[1291]] = gn138[M[335]][M[1292]], ubksj[M[1293]] = gn138[M[335]][M[1293]], console[M[225]](M[1294] + JSON[M[938]](ubksj[M[1293]])), t_ZK[M[1179]] == 0x1 && ubksj[M[1293]] && ubksj[M[1293]][M[1295]] == 0x1 && (t_ZK[M[1296]] = 0x1, window[M[945]][M[946]]['t_FKZ']()), t_K6MZ();
  } else t_ZK['last_check_ban'][M[1297]] >= 0x3 ? (t_KM(JSON[M[938]](gn138)), window['t_M6ZK'](M[1298] + gn138[M[1102]])) : sendApi(t_ZK[M[1061]], M[1153], { 'platform': t_ZK[M[1059]], 'partner_id': t_ZK[M[1069]], 'token': t_ZK[M[1151]], 'game_pkg': t_ZK[M[933]], 'deviceId': t_ZK[M[1070]], 'scene': M[1154] + t_ZK[M[1071]] }, function (ujbkas) {
    if (!ujbkas || ujbkas[M[1102]] != M[1166]) {
      window['t_M6ZK'](M[1167] + ujbkas && ujbkas[M[1102]]);return;
    }t_ZK[M[1170]] = String(ujbkas[M[1171]]), t_ZK[M[1172]] = String(ujbkas[M[1173]]), setTimeout(function () {
      t_KM6Z(t_ZK['last_check_ban'][M[1297]] + 0x1, t_ZK['last_check_ban'][M[935]]);
    }, 0x5dc);
  }, t_6KZ, t_KM, function (n3jgr) {
    return n3jgr[M[1102]] == M[1166] || n3jgr[M[1102]] == M[1299];
  });
}, window['t_K6MZ'] = function () {
  ServerLoading[M[946]][M[1187]](t_ZK[M[1179]]), window['t_6K'] = !![], window['t_KZM6']();
}, window['t_K6ZM'] = function () {
  if (window['t_K6'] && window['t_Z6K'] && window[M[1085]] && window[M[1086]] && window['t_ZK6'] && window['t_Z6']) {
    if (!window[M[1300]][M[946]]) {
      console[M[225]](M[1301] + window[M[1300]][M[946]]);var d$fvpz = wx[M[1302]](),
          exq0_y = d$fvpz[M[1042]] ? d$fvpz[M[1042]] : 0x0,
          i9pvd = { 'cdn': window['t_ZK'][M[932]], 'spareCdn': window['t_ZK'][M[1142]], 'newRegister': window['t_ZK'][M[1179]], 'wxPC': window['t_ZK'][M[1017]], 'wxIOS': window['t_ZK'][M[1012]], 'wxAndroid': window['t_ZK'][M[1014]], 'wxParam': { 'limitLoad': window['t_ZK']['t_FM6KZ'], 'benchmarkLevel': window['t_ZK']['t_FMZ6K'], 'wxFrom': window[M[920]][M[51]] == M[1303] ? 0x1 : 0x0, 'wxSDKVersion': window[M[947]] }, 'configType': window['t_ZK'][M[1080]], 'exposeType': window['t_ZK'][M[1082]], 'scene': exq0_y };new window[M[1300]](i9pvd, window['t_ZK'][M[931]], window['t_FM6ZK']);
    }
  }
}, window['t_KZM6'] = function () {
  if (window['t_K6'] && window['t_Z6K'] && window[M[1085]] && window[M[1086]] && window['t_ZK6'] && window['t_Z6'] && window['t_6K'] && window['t_6Z']) {
    t_MZK6();if (!t_K6Z) {
      t_K6Z = !![];if (!window[M[1300]][M[946]]) window['t_K6ZM']();var pe7zof = 0x0,
          iv$c9 = wx[M[1304]]();iv$c9 && (window['t_ZK'][M[1016]] && (pe7zof = iv$c9[M[1008]]), console[M[916]](M[1305] + iv$c9[M[1008]] + M[1306] + iv$c9[M[1009]] + M[1307] + iv$c9[M[1010]] + M[1308] + iv$c9[M[1011]] + M[1309] + iv$c9[M[1310]] + M[1311] + iv$c9[M[1312]]));var _qyxm = {};for (const oz7pfe in t_ZK[M[934]]) {
        _qyxm[oz7pfe] = t_ZK[M[934]][oz7pfe];
      }var bkjasr = { 'channel': window['t_ZK'][M[1074]], 'account': window['t_ZK'][M[930]], 'userId': window['t_ZK'][M[1168]], 'cdn': window['t_ZK'][M[932]], 'data': window['t_ZK'][M[335]], 'package': window['t_ZK'][M[304]], 'newRegister': window['t_ZK'][M[1179]], 'pkgName': window['t_ZK'][M[933]], 'partnerId': window['t_ZK'][M[1069]], 'platform_uid': window['t_ZK'][M[1169]], 'deviceId': window['t_ZK'][M[1070]], 'selectedServer': _qyxm, 'configType': window['t_ZK'][M[1080]], 'exposeType': window['t_ZK'][M[1082]], 'debugUsers': window['t_ZK'][M[1077]], 'wxMenuTop': pe7zof, 'wxShield': window['t_ZK'][M[1084]] };if (window[M[1198]]) for (var c9$vd in window[M[1198]]) {
        bkjasr[c9$vd] = window[M[1198]][c9$vd];
      }window[M[1300]][M[946]]['t_KZF'](bkjasr);
    }
  } else console[M[916]](M[1313] + window['t_K6'] + M[1314] + window['t_Z6K'] + M[1315] + window[M[1085]] + M[1316] + window[M[1086]] + M[1317] + window['t_ZK6'] + M[1318] + window['t_Z6'] + M[1319] + window['t_6K'] + M[1320] + window['t_6Z']);
};