var M = wx.$T;
require(M[915]);