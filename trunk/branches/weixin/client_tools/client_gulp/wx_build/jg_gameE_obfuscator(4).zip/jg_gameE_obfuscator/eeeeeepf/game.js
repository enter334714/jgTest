var b = wx.$e;
require('eeeeBuff.js'), window[b[40485]][b[40471]][b[40275]] = null, window['client_pb'] = require('eeecleintpb.js'), window[b[40507]] = window[b[40485]][b[40412]][b[40316]](client_pb);