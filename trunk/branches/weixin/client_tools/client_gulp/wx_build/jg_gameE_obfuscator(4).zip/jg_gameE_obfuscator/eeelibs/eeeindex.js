var b = wx.$e;
import emav4_ from '../eeeesdk/eeesdk.js';window[b[69116]] = { 'wxVersion': window[b[41004]][b[69016]] }, window[b[69117]] = ![], window['e10U'] = 0x1, window[b[69118]] = 0x1, window['e1GU0'] = !![], window[b[69119]] = !![], window['e1I1GU0'] = '', window['e1U0'] = { 'base_cdn': b[69120], 'cdn': b[69120] }, e1U0[b[69121]] = {}, e1U0[b[40453]] = '0', e1U0[b[45115]] = window[b[69116]][b[69122]], e1U0[b[68722]] = '', e1U0['os'] = '1', e1U0[b[69123]] = b[69124], e1U0[b[69125]] = b[69126], e1U0[b[69127]] = b[69128], e1U0[b[69129]] = b[69130], e1U0[b[69131]] = b[69132], e1U0[b[63933]] = '1', e1U0[b[65508]] = '', e1U0[b[65510]] = '', e1U0[b[69133]] = 0x0, e1U0[b[69134]] = {}, e1U0[b[69135]] = parseInt(e1U0[b[63933]]), e1U0[b[65506]] = e1U0[b[63933]], e1U0[b[65502]] = {}, e1U0['e11U'] = b[69136], e1U0[b[69137]] = ![], e1U0[b[52626]] = b[69138], e1U0[b[65479]] = Date[b[40574]](), e1U0[b[52236]] = b[69139], e1U0[b[41159]] = '_a', e1U0[b[69140]] = 0x2, e1U0[b[40587]] = 0x7c1, e1U0[b[69122]] = window[b[69116]][b[69122]], e1U0[b[41183]] = ![], e1U0[b[41515]] = ![], e1U0[b[51717]] = ![], e1U0[b[65199]] = ![], window['e1G0U'] = 0x5, window['e1G0'] = ![], window['e10G'] = ![], window['e1UG0'] = ![], window[b[69141]] = ![], window[b[69142]] = ![], window['e1U0G'] = ![], window['e1GU'] = ![], window['e1UG'] = ![], window['e10GU'] = ![], window[b[44593]] = function ($j3ixq) {
  console[b[40417]](b[44593], $j3ixq), wx[b[45392]]({}), wx[b[69040]]({ 'title': b[46749], 'content': $j3ixq, 'success'(qus9k) {
      if (qus9k[b[69143]]) console[b[40417]](b[69144]);else qus9k[b[41000]] && console[b[40417]](b[68874]);
    } });
}, window['e11GU0'] = function ($xgtij) {
  console[b[40417]](b[69145], $xgtij), e11U0G(), wx[b[69040]]({ 'title': b[46749], 'content': $xgtij, 'confirmText': b[69146], 'cancelText': b[58837], 'success'(oac7m) {
      if (oac7m[b[69143]]) window['e1U1']();else oac7m[b[41000]] && (console[b[40417]](b[69147]), wx[b[65663]]({}));
    } });
}, window['e1UI'] = function (un6sk) {
  console[b[40417]](b[69148], un6sk), wx[b[69040]]({ 'title': b[46749], 'content': un6sk, 'confirmText': b[65636], 'showCancel': ![], 'complete'(s09k) {
      console[b[40417]](b[69147]), wx[b[65663]]({});
    } });
}, window['e11G0U'] = ![], window['e11UG0'] = function (fvrzy4) {
  window['e11G0U'] = !![], wx[b[45391]](fvrzy4);
}, window['e11U0G'] = function () {
  window['e11G0U'] && (window['e11G0U'] = ![], wx[b[45392]]({}));
}, window['e110GU'] = function (j$i3g) {
  window[b[69031]][b[40623]]['e110GU'](j$i3g);
}, window[b[52507]] = function (zf_y4, xi$3j) {
  emav4_[b[52507]](zf_y4, function (fva47) {
    fva47 && fva47[b[40462]] ? fva47[b[40462]][b[44526]] == 0x1 ? xi$3j(!![]) : (xi$3j(![]), console[b[40569]](b[69149] + fva47[b[40462]][b[69150]])) : console[b[40417]](b[52507], fva47);
  });
}, window['e110UG'] = function ($xlitg) {
  console[b[40417]](b[69151], $xlitg);
}, window['e11U0'] = function (d65kb0) {}, window['e110U'] = function (hltzyr, qiun3j, uj3sqn) {}, window['e110'] = function (b6d9k0) {
  console[b[40417]](b[69152], b6d9k0), window[b[69031]][b[40623]][b[69153]](), window[b[69031]][b[40623]][b[69154]](), window[b[69031]][b[40623]][b[69155]]();
}, window['e101'] = function (b0k6s) {
  window['e11GU0'](b[69156]);var pcma = { 'id': window['e1U0'][b[69021]], 'role': window['e1U0'][b[45045]], 'level': window['e1U0'][b[69022]], 'account': window['e1U0'][b[65507]], 'version': window['e1U0'][b[40587]], 'cdn': window['e1U0'][b[44928]], 'pkgName': window['e1U0'][b[65508]], 'gamever': window[b[41004]][b[69016]], 'serverid': window['e1U0'][b[65502]] ? window['e1U0'][b[65502]][b[51895]] : 0x0, 'systemInfo': window[b[69023]], 'error': b[69157], 'stack': b0k6s ? b0k6s : b[69156] },
      snku69 = JSON[b[44914]](pcma);console[b[40460]](b[69158] + snku69), window['e11U'](snku69);
}, window['e1U10'] = function (aeopmc) {
  var db865 = JSON[b[40416]](aeopmc);db865[b[69159]] = window[b[41004]][b[69016]], db865[b[69160]] = window['e1U0'][b[65502]] ? window['e1U0'][b[65502]][b[51895]] : 0x0, db865[b[69023]] = window[b[69023]];var ztlhry = JSON[b[44914]](db865);console[b[40460]](b[69161] + ztlhry), window['e11U'](ztlhry);
}, window['e1U01'] = function (pocma, rhgtzl) {
  var jni$q = { 'id': window['e1U0'][b[69021]], 'role': window['e1U0'][b[45045]], 'level': window['e1U0'][b[69022]], 'account': window['e1U0'][b[65507]], 'version': window['e1U0'][b[40587]], 'cdn': window['e1U0'][b[44928]], 'pkgName': window['e1U0'][b[65508]], 'gamever': window[b[41004]][b[69016]], 'serverid': window['e1U0'][b[65502]] ? window['e1U0'][b[65502]][b[51895]] : 0x0, 'systemInfo': window[b[69023]], 'error': pocma, 'stack': rhgtzl },
      d08w = JSON[b[44914]](jni$q);console[b[40473]](b[69162] + d08w), window['e11U'](d08w);
}, window['e11U'] = function (gtix) {
  if (window['e1U0'][b[69089]] == b[69163]) return;var f47_va = e1U0['e11U'] + b[69164] + e1U0[b[65507]];wx[b[40929]]({ 'url': f47_va, 'method': b[68957], 'data': gtix, 'header': { 'content-type': b[69165], 'cache-control': b[69166] }, 'success': function (gjix$t) {
      DEBUG && console[b[40417]](b[69167], f47_va, gtix, gjix$t);
    }, 'fail': function (rglxh) {
      DEBUG && console[b[40417]](b[69167], f47_va, gtix, rglxh);
    }, 'complete': function () {} });
}, window[b[69168]] = function () {
  function thryz() {
    return ((0x1 + Math[b[40599]]()) * 0x10000 | 0x0)[b[40301]](0x10)[b[40423]](0x1);
  }return thryz() + thryz() + '-' + thryz() + '-' + thryz() + '-' + thryz() + '+' + thryz() + thryz() + thryz();
}, window['e1U1'] = function () {
  console[b[40417]](b[69169]);var v_f7a = emav4_[b[69170]]();e1U0[b[65506]] = v_f7a[b[69171]], e1U0[b[69135]] = v_f7a[b[69171]], e1U0[b[63933]] = v_f7a[b[69171]], e1U0[b[65508]] = v_f7a[b[69172]];var iqjx3$ = { 'game_ver': e1U0[b[45115]] };e1U0[b[65510]] = this[b[69168]](), e11UG0({ 'title': b[69173] }), emav4_[b[40823]](iqjx3$, this['e101U'][b[40271]](this));
}, window['e101U'] = function (un3iqj) {
  var lrhgzt = un3iqj[b[69174]];console[b[40417]](b[69175] + lrhgzt + b[69176] + (lrhgzt == 0x1) + b[69177] + un3iqj[b[69016]] + b[69178] + window[b[69116]][b[69122]]);if (!un3iqj[b[69016]] || window['e1IG01U'](window[b[69116]][b[69122]], un3iqj[b[69016]]) < 0x0) console[b[40417]](b[69179]), e1U0[b[69125]] = b[69180], e1U0[b[69127]] = b[69181], e1U0[b[69129]] = b[69182], e1U0[b[44928]] = b[69183], e1U0[b[65197]] = b[69184], e1U0[b[69185]] = 'fj', e1U0[b[41183]] = ![];else window['e1IG01U'](window[b[69116]][b[69122]], un3iqj[b[69016]]) == 0x0 ? (console[b[40417]](b[69186]), e1U0[b[69125]] = b[69126], e1U0[b[69127]] = b[69128], e1U0[b[69129]] = b[69130], e1U0[b[44928]] = b[69187], e1U0[b[65197]] = b[69184], e1U0[b[69185]] = b[69188], e1U0[b[41183]] = !![]) : (console[b[40417]](b[69189]), e1U0[b[69125]] = b[69126], e1U0[b[69127]] = b[69128], e1U0[b[69129]] = b[69130], e1U0[b[44928]] = b[69187], e1U0[b[65197]] = b[69184], e1U0[b[69185]] = b[69188], e1U0[b[41183]] = ![]);e1U0[b[69133]] = config[b[40296]] ? config[b[40296]] : 0x0, this['e1GU10'](), this['e1GU01'](), window[b[69190]] = 0x5, e11UG0({ 'title': b[69191] }), emav4_[b[68804]](this['e10U1'][b[40271]](this));
}, window[b[69190]] = 0x5, window['e10U1'] = function (itjg$x, i$) {
  if (itjg$x == 0x0 && i$ && i$[b[40448]]) {
    e1U0[b[69192]] = i$[b[40448]];var u6nsk = this;e11UG0({ 'title': b[69193] }), sendApi(e1U0[b[69125]], b[69194], { 'platform': e1U0[b[69123]], 'partner_id': e1U0[b[63933]], 'token': i$[b[40448]], 'game_pkg': e1U0[b[65508]], 'deviceId': e1U0[b[65510]], 'scene': b[69195] + e1U0[b[69133]] }, this['e1G1U0'][b[40271]](this), e1G0U, e101);
  } else i$ && i$[b[65689]] && window[b[69190]] > 0x0 && (i$[b[65689]][b[40364]](b[69196]) != -0x1 || i$[b[65689]][b[40364]](b[69197]) != -0x1 || i$[b[65689]][b[40364]](b[69198]) != -0x1 || i$[b[65689]][b[40364]](b[69199]) != -0x1 || i$[b[65689]][b[40364]](b[69200]) != -0x1 || i$[b[65689]][b[40364]](b[69201]) != -0x1) ? (window[b[69190]]--, emav4_[b[68804]](this['e10U1'][b[40271]](this))) : (window['e1U01'](b[69202], JSON[b[44914]]({ 'status': itjg$x, 'data': i$ })), window['e11GU0'](b[69203] + (i$ && i$[b[65689]] ? '，' + i$[b[65689]] : '')));
}, window['e1G1U0'] = function (w281) {
  if (!w281) {
    window['e1U01'](b[69204], b[69205]), window['e11GU0'](b[69206]);return;
  }if (w281[b[44526]] != b[50307]) {
    window['e1U01'](b[69204], JSON[b[44914]](w281)), window['e11GU0'](b[69207] + w281[b[44526]]);return;
  }e1U0[b[63932]] = String(w281[b[65507]]), e1U0[b[65507]] = String(w281[b[65507]]), e1U0[b[65477]] = String(w281[b[65477]]), e1U0[b[65506]] = String(w281[b[65477]]), e1U0[b[65509]] = String(w281[b[65509]]), e1U0[b[69208]] = String(w281[b[51878]]), e1U0[b[69209]] = String(w281[b[41295]]), e1U0[b[51878]] = '';var tlgix = this;e11UG0({ 'title': b[69210] }), sendApi(e1U0[b[69125]], b[69211], { 'partner_id': e1U0[b[63933]], 'uid': e1U0[b[65507]], 'version': e1U0[b[45115]], 'game_pkg': e1U0[b[65508]], 'device': e1U0[b[65510]] }, tlgix['e1G10U'][b[40271]](tlgix), e1G0U, e101);
}, window['e1G10U'] = function (ecpamo) {
  if (!ecpamo) {
    window['e11GU0'](b[69212]);return;
  }if (ecpamo[b[44526]] != b[50307]) {
    window['e11GU0'](b[69213] + ecpamo[b[44526]]);return;
  }if (!ecpamo[b[40462]] || ecpamo[b[40462]][b[40282]] == 0x0) {
    window['e11GU0'](b[69214]);return;
  }e1U0[b[41075]] = ecpamo[b[69215]], e1U0[b[65502]] = { 'server_id': String(ecpamo[b[40462]][0x0][b[51895]]), 'server_name': String(ecpamo[b[40462]][0x0][b[69216]]), 'entry_ip': ecpamo[b[40462]][0x0][b[65530]], 'entry_port': parseInt(ecpamo[b[40462]][0x0][b[65531]]), 'status': e1UG1(ecpamo[b[40462]][0x0]), 'start_time': ecpamo[b[40462]][0x0][b[69217]], 'cdn': e1U0[b[44928]] }, this['e10UG1']();
}, window['e10UG1'] = function () {
  if (e1U0[b[41075]] == 0x1) {
    var w05d8b = e1U0[b[65502]][b[40591]];if (w05d8b === -0x1 || w05d8b === 0x0) {
      window['e11GU0'](w05d8b === -0x1 ? b[69218] : b[69219]);return;
    }e101GU(0x0, e1U0[b[65502]][b[51895]]), window[b[69031]][b[40623]][b[69220]](e1U0[b[41075]]);
  } else window[b[69031]][b[40623]][b[69221]](), e11U0G();window['e1UG'] = !![], window['e10GU1'](), window['e10U1G']();
}, window['e1GU10'] = function () {
  sendApi(e1U0[b[69125]], b[69222], { 'game_pkg': e1U0[b[65508]], 'version_name': e1U0[b[69185]] }, this[b[69223]][b[40271]](this), e1G0U, e101);
}, window[b[69223]] = function (n9k6us) {
  if (!n9k6us) {
    window['e11GU0'](b[69224]);return;
  }if (n9k6us[b[44526]] != b[50307]) {
    window['e11GU0'](b[69225] + n9k6us[b[44526]]);return;
  }if (!n9k6us[b[40462]] || !n9k6us[b[40462]][b[45115]]) {
    window['e11GU0'](b[69226] + (n9k6us[b[40462]] && n9k6us[b[40462]][b[45115]]));return;
  }n9k6us[b[40462]][b[69227]] && n9k6us[b[40462]][b[69227]][b[40282]] > 0xa && (e1U0[b[69228]] = n9k6us[b[40462]][b[69227]], e1U0[b[44928]] = n9k6us[b[40462]][b[69227]]), n9k6us[b[40462]][b[45115]] && (e1U0[b[40587]] = n9k6us[b[40462]][b[45115]]), console[b[40569]](b[65642] + e1U0[b[40587]] + b[69229] + e1U0[b[69185]]), window['e1U0G'] = !![], window['e10GU1'](), window['e10U1G']();
}, window[b[69230]], window['e1GU01'] = function () {
  sendApi(e1U0[b[69125]], b[69231], { 'game_pkg': e1U0[b[65508]] }, this['e1G01U'][b[40271]](this), e1G0U, e101);
}, window['e1G01U'] = function (x3qij) {
  if (x3qij[b[44526]] === b[50307] && x3qij[b[40462]]) {
    window[b[69230]] = x3qij[b[40462]];for (var oapcme in x3qij[b[40462]]) {
      e1U0[oapcme] = x3qij[b[40462]][oapcme];
    }
  } else console[b[40569]](b[69232] + x3qij[b[44526]]);window['e1GU'] = !![], window['e10U1G']();
}, window[b[69233]] = function (i$g3jx, _7ca4, sb69ku, jquin, yhlzr, fvzy4_, a4m_7, gtxlh, mpeaco) {
  yhlzr = String(yhlzr);var iltxg$ = a4m_7,
      cmep = gtxlh;e1U0[b[69121]][yhlzr] = { 'productid': yhlzr, 'productname': iltxg$, 'productdesc': cmep, 'roleid': i$g3jx, 'rolename': _7ca4, 'rolelevel': sb69ku, 'price': fvzy4_, 'callback': mpeaco }, sendApi(e1U0[b[69129]], b[69234], { 'game_pkg': e1U0[b[65508]], 'server_id': e1U0[b[65502]][b[51895]], 'server_name': e1U0[b[65502]][b[69216]], 'level': sb69ku, 'uid': e1U0[b[65507]], 'role_id': i$g3jx, 'role_name': _7ca4, 'product_id': yhlzr, 'product_name': iltxg$, 'product_desc': cmep, 'money': fvzy4_, 'partner_id': e1U0[b[63933]] }, toPayCallBack, e1G0U, e101);
}, window[b[69235]] = function (tgxil) {
  if (tgxil) {
    if (tgxil[b[69236]] === 0xc8 || tgxil[b[44526]] == b[50307]) {
      var k09d6 = e1U0[b[69121]][String(tgxil[b[69237]])];if (k09d6[b[40789]]) k09d6[b[40789]](tgxil[b[69237]], tgxil[b[69238]], -0x1);emav4_[b[68989]]({ 'cpbill': tgxil[b[69238]], 'productid': tgxil[b[69237]], 'productname': k09d6[b[69239]], 'productdesc': k09d6[b[69240]], 'serverid': e1U0[b[65502]][b[51895]], 'servername': e1U0[b[65502]][b[69216]], 'roleid': k09d6[b[69241]], 'rolename': k09d6[b[69242]], 'rolelevel': k09d6[b[69243]], 'price': k09d6[b[67185]], 'extension': JSON[b[44914]]({ 'cp_order_id': tgxil[b[69238]] }) }, function (b056d, g$ixj) {
        k09d6[b[40789]] && b056d == 0x0 && k09d6[b[40789]](tgxil[b[69237]], tgxil[b[69238]], b056d);console[b[40569]](JSON[b[44914]]({ 'type': b[69244], 'status': b056d, 'data': tgxil, 'role_name': k09d6[b[69242]] }));if (b056d === 0x0) {} else {
          if (b056d === 0x1) {} else {
            if (b056d === 0x2) {}
          }
        }
      });
    } else alert(tgxil[b[40569]]);
  }
}, window['e1G0U1'] = function () {}, window['e11G0'] = function (nusq9, rzyv, hvzyr, u9nks6, _47yf) {
  emav4_[b[69008]](e1U0[b[65502]][b[51895]], e1U0[b[65502]][b[69216]] || e1U0[b[65502]][b[51895]], nusq9, rzyv, hvzyr), sendApi(e1U0[b[69125]], b[69245], { 'game_pkg': e1U0[b[65508]], 'server_id': e1U0[b[65502]][b[51895]], 'role_id': nusq9, 'uid': e1U0[b[65507]], 'role_name': rzyv, 'role_type': u9nks6, 'level': hvzyr });
}, window['e110G'] = function (om7ap, _oa7, gtji$, sk9b6, w1d2, yzhlrt, cmo7a, _vma47, m_7ca, it$gx) {
  e1U0[b[69021]] = om7ap, e1U0[b[45045]] = _oa7, e1U0[b[69022]] = gtji$, emav4_[b[69009]](e1U0[b[65502]][b[51895]], e1U0[b[65502]][b[69216]] || e1U0[b[65502]][b[51895]], om7ap, _oa7, gtji$), sendApi(e1U0[b[69125]], b[69246], { 'game_pkg': e1U0[b[65508]], 'server_id': e1U0[b[65502]][b[51895]], 'role_id': om7ap, 'uid': e1U0[b[65507]], 'role_name': _oa7, 'role_type': sk9b6, 'level': gtji$, 'evolution': w1d2 });
}, window['e1G10'] = function (ubks9, $txgl, $hglx, skn69u, pocme, ukns9, iqn3u, camo_7, _y74v, grtz) {
  e1U0[b[69021]] = ubks9, e1U0[b[45045]] = $txgl, e1U0[b[69022]] = $hglx, emav4_[b[69010]](e1U0[b[65502]][b[51895]], e1U0[b[65502]][b[69216]] || e1U0[b[65502]][b[51895]], ubks9, $txgl, $hglx), sendApi(e1U0[b[69125]], b[69246], { 'game_pkg': e1U0[b[65508]], 'server_id': e1U0[b[65502]][b[51895]], 'role_id': ubks9, 'uid': e1U0[b[65507]], 'role_name': $txgl, 'role_type': skn69u, 'level': $hglx, 'evolution': pocme });
}, window['e1G01'] = function (ryzl) {}, window['e11G'] = function (qij3$) {
  emav4_[b[68928]](b[68928], function (rhtxg) {
    qij3$ && qij3$(rhtxg);
  });
}, window[b[65181]] = function () {
  emav4_[b[65181]]();
}, window[b[69247]] = function () {
  emav4_[b[63826]]();
}, window[b[51228]] = function (dk065b) {
  window['e101G'] = dk065b, window['e101G'] && window['e1G1'] && (console[b[40569]](b[69108] + window['e1G1'][b[41221]]), window['e101G'](window['e1G1']), window['e1G1'] = null);
}, window['e10G1'] = function (qi, opm7c, coam7_, qn9uks) {
  window[b[40519]](b[69248], { 'game_pkg': window['e1U0'][b[65508]], 'role_id': opm7c, 'server_id': coam7_ }, qn9uks);
}, window['e1U1G0'] = function (p7cmoa, vyhzrf) {
  function a_4vm(po7am) {
    var ns3u9q = [],
        cpoea = [],
        mao7 = window[b[41004]][b[69249]];for (var rzlyt in mao7) {
      var $n3qij = Number(rzlyt);(!p7cmoa || !p7cmoa[b[40282]] || p7cmoa[b[40364]]($n3qij) != -0x1) && (cpoea[b[40304]](mao7[rzlyt]), ns3u9q[b[40304]]([$n3qij, 0x3]));
    }window['e1IG01U'](window[b[69032]], b[69250]) >= 0x0 ? (console[b[40417]](b[69251]), emav4_[b[69252]] && emav4_[b[69252]](cpoea, function (yzf4rv) {
      console[b[40417]](b[69253]), console[b[40417]](yzf4rv);if (yzf4rv && yzf4rv[b[65689]] == b[69254]) for (var su3qnj in mao7) {
        if (yzf4rv[mao7[su3qnj]] == b[69255]) {
          var $tlghx = Number(su3qnj);for (var zlryt = 0x0; zlryt < ns3u9q[b[40282]]; zlryt++) {
            if (ns3u9q[zlryt][0x0] == $tlghx) {
              ns3u9q[zlryt][0x1] = 0x1;break;
            }
          }
        }
      }window['e1IG01U'](window[b[69032]], b[69256]) >= 0x0 ? wx[b[69257]]({ 'withSubscriptions': !![], 'success': function (q3jx) {
          var s6ub9 = q3jx[b[69258]][b[69259]];if (s6ub9) {
            console[b[40417]](b[69260]), console[b[40417]](s6ub9);for (var rz4y in mao7) {
              if (s6ub9[mao7[rz4y]] == b[69255]) {
                var gj$3xi = Number(rz4y);for (var gi3j$x = 0x0; gi3j$x < ns3u9q[b[40282]]; gi3j$x++) {
                  if (ns3u9q[gi3j$x][0x0] == gj$3xi) {
                    ns3u9q[gi3j$x][0x1] = 0x2;break;
                  }
                }
              }
            }console[b[40417]](ns3u9q), vyhzrf && vyhzrf(ns3u9q);
          } else console[b[40417]](b[69261]), console[b[40417]](q3jx), console[b[40417]](ns3u9q), vyhzrf && vyhzrf(ns3u9q);
        }, 'fail': function () {
          console[b[40417]](b[69262]), console[b[40417]](ns3u9q), vyhzrf && vyhzrf(ns3u9q);
        } }) : (console[b[40417]](b[69263] + window[b[69032]]), console[b[40417]](ns3u9q), vyhzrf && vyhzrf(ns3u9q));
    })) : (console[b[40417]](b[69264] + window[b[69032]]), console[b[40417]](ns3u9q), vyhzrf && vyhzrf(ns3u9q)), wx[b[69265]](a_4vm);
  }wx[b[69266]](a_4vm);
}, window['e1U10G'] = { 'isSuccess': ![], 'level': b[69267], 'isCharging': ![] }, window['e1UG10'] = function (rztgl) {
  wx[b[69097]]({ 'success': function (zvfyrh) {
      var jqu3ns = window['e1U10G'];jqu3ns[b[69268]] = !![], jqu3ns[b[45022]] = Number(zvfyrh[b[45022]])[b[44641]](0x0), jqu3ns[b[69100]] = zvfyrh[b[69100]], rztgl && rztgl(jqu3ns[b[69268]], jqu3ns[b[45022]], jqu3ns[b[69100]]);
    }, 'fail': function (hrtz) {
      console[b[40417]](b[69269], hrtz[b[65689]]);var n3sq = window['e1U10G'];rztgl && rztgl(n3sq[b[69268]], n3sq[b[45022]], n3sq[b[69100]]);
    } });
}, window[b[40519]] = function (amoc_, hyzfl, j3qn, l$gtix, s3ujn, vhyzrf, lxig$t, yrz4fv) {
  if (l$gtix == undefined) l$gtix = 0x1;wx[b[40929]]({ 'url': amoc_, 'method': lxig$t || b[65397], 'responseType': b[44837], 'data': hyzfl, 'header': { 'content-type': yrz4fv || b[69165] }, 'success': function (fy_) {
      DEBUG && console[b[40417]](b[69270], amoc_, info, fy_);if (fy_ && fy_[b[65752]] == 0xc8) {
        var a4_m7v = fy_[b[40462]];!vhyzrf || vhyzrf(a4_m7v) ? j3qn && j3qn(a4_m7v) : window[b[69271]](amoc_, hyzfl, j3qn, l$gtix, s3ujn, vhyzrf, fy_);
      } else window[b[69271]](amoc_, hyzfl, j3qn, l$gtix, s3ujn, vhyzrf, fy_);
    }, 'fail': function (d85bw0) {
      DEBUG && console[b[40417]](b[69272], amoc_, info, d85bw0), window[b[69271]](amoc_, hyzfl, j3qn, l$gtix, s3ujn, vhyzrf, d85bw0);
    }, 'complete': function () {} });
}, window[b[69271]] = function (d6b9k0, d1, tglh$x, hrlztg, qn$j3, vyzfhr, nuqks) {
  hrlztg - 0x1 > 0x0 ? setTimeout(function () {
    window[b[40519]](d6b9k0, d1, tglh$x, hrlztg - 0x1, qn$j3, vyzfhr);
  }, 0x3e8) : qn$j3 && qn$j3(JSON[b[44914]]({ 'url': d6b9k0, 'response': nuqks }));
}, window[b[69273]] = function (rflh, xtlg$, gtx$l, q9unks, snj, kq9su, nusqk9) {
  !gtx$l && (gtx$l = {});var j3qi$ = Math[b[40309]](Date[b[40574]]() / 0x3e8);gtx$l[b[41295]] = j3qi$, gtx$l[b[65319]] = xtlg$;var mapoce = Object[b[40281]](gtx$l)[b[40472]](),
      snu93q = '',
      nq$3ij = '';for (var emcpoa = 0x0; emcpoa < mapoce[b[40282]]; emcpoa++) {
    snu93q = snu93q + (emcpoa == 0x0 ? '' : '&') + mapoce[emcpoa] + gtx$l[mapoce[emcpoa]], nq$3ij = nq$3ij + (emcpoa == 0x0 ? '' : '&') + mapoce[emcpoa] + '=' + encodeURIComponent(gtx$l[mapoce[emcpoa]]);
  }snu93q = snu93q + e1U0[b[69131]];var itgj$ = b[69274] + md5(snu93q);send(rflh + '?' + nq$3ij + (nq$3ij == '' ? '' : '&') + itgj$, null, q9unks, snj, kq9su, nusqk9 || function (ji$3g) {
    return ji$3g[b[44526]] == b[50307];
  }, null, b[68830]);
}, window['e1UG01'] = function ($tjxgi, eampco) {
  var zfv_y4 = 0x0;e1U0[b[65502]] && (zfv_y4 = e1U0[b[65502]][b[51895]]), sendApi(e1U0[b[69127]], b[69275], { 'partnerId': e1U0[b[63933]], 'gamePkg': e1U0[b[65508]], 'logTime': Math[b[40309]](Date[b[40574]]() / 0x3e8), 'platformUid': e1U0[b[65509]], 'type': $tjxgi, 'serverId': zfv_y4 }, null, 0x2, null, function () {
    return !![];
  });
}, window['e1U01G'] = function (wd125) {
  sendApi(e1U0[b[69125]], b[69276], { 'partner_id': e1U0[b[63933]], 'uid': e1U0[b[65507]], 'version': e1U0[b[45115]], 'game_pkg': e1U0[b[65508]], 'device': e1U0[b[65510]] }, e1U0G1, e1G0U, e101);
}, window['e1U0G1'] = function (rzhylt) {
  if (rzhylt[b[44526]] === b[50307] && rzhylt[b[40462]]) {
    rzhylt[b[40462]][b[40387]]({ 'id': -0x2, 'name': b[69277] }), rzhylt[b[40462]][b[40387]]({ 'id': -0x1, 'name': b[69278] }), e1U0[b[69279]] = rzhylt[b[40462]];if (window[b[52672]]) window[b[52672]][b[69280]]();
  } else e1U0[b[69281]] = ![], window['e11GU0'](b[69282] + rzhylt[b[44526]]);
}, window['e11GU'] = function (acmo) {
  sendApi(e1U0[b[69125]], b[69283], { 'partner_id': e1U0[b[63933]], 'uid': e1U0[b[65507]], 'version': e1U0[b[45115]], 'game_pkg': e1U0[b[65508]], 'device': e1U0[b[65510]] }, e11UG, e1G0U, e101);
}, window['e11UG'] = function (junq3s) {
  e1U0[b[69284]] = ![];if (junq3s[b[44526]] === b[50307] && junq3s[b[40462]]) {
    for (var rtg = 0x0; rtg < junq3s[b[40462]][b[40282]]; rtg++) {
      junq3s[b[40462]][rtg][b[40591]] = e1UG1(junq3s[b[40462]][rtg]);
    }e1U0[b[69134]][-0x1] = window[b[69285]](junq3s[b[40462]]), window[b[52672]][b[69286]](-0x1);
  } else window['e11GU0'](b[69287] + junq3s[b[44526]]);
}, window[b[69288]] = function (j$iq3) {
  sendApi(e1U0[b[69125]], b[69283], { 'partner_id': e1U0[b[63933]], 'uid': e1U0[b[65507]], 'version': e1U0[b[45115]], 'game_pkg': e1U0[b[65508]], 'device': e1U0[b[65510]] }, j$iq3, e1G0U, e101);
}, window['e1G1U'] = function (_v7m4, s0b6) {
  sendApi(e1U0[b[69125]], b[69289], { 'partner_id': e1U0[b[63933]], 'uid': e1U0[b[65507]], 'version': e1U0[b[45115]], 'game_pkg': e1U0[b[65508]], 'device': e1U0[b[65510]], 'server_group_id': s0b6 }, e1GU1, e1G0U, e101);
}, window['e1GU1'] = function (l$xgth) {
  e1U0[b[69284]] = ![];if (l$xgth[b[44526]] === b[50307] && l$xgth[b[40462]] && l$xgth[b[40462]][b[40462]]) {
    var k0d5b6 = l$xgth[b[40462]][b[69290]],
        fzvyh = [];for (var $qxji3 = 0x0; $qxji3 < l$xgth[b[40462]][b[40462]][b[40282]]; $qxji3++) {
      l$xgth[b[40462]][b[40462]][$qxji3][b[40591]] = e1UG1(l$xgth[b[40462]][b[40462]][$qxji3]), (fzvyh[b[40282]] == 0x0 || l$xgth[b[40462]][b[40462]][$qxji3][b[40591]] != 0x0) && (fzvyh[fzvyh[b[40282]]] = l$xgth[b[40462]][b[40462]][$qxji3]);
    }e1U0[b[69134]][k0d5b6] = window[b[69285]](fzvyh), window[b[52672]][b[69286]](k0d5b6);
  } else window['e11GU0'](b[69291] + l$xgth[b[44526]]);
}, window['e1IG0U'] = function (ht$xlg) {
  sendApi(e1U0[b[69125]], b[69292], { 'partner_id': e1U0[b[63933]], 'uid': e1U0[b[65507]], 'version': e1U0[b[45115]], 'game_pkg': e1U0[b[65508]], 'device': e1U0[b[65510]] }, reqServerRecommendCallBack, e1G0U, e101);
}, window[b[69293]] = function (xtj$ig) {
  e1U0[b[69284]] = ![];if (xtj$ig[b[44526]] === b[50307] && xtj$ig[b[40462]]) {
    for (var b6sku = 0x0; b6sku < xtj$ig[b[40462]][b[40282]]; b6sku++) {
      xtj$ig[b[40462]][b6sku][b[40591]] = e1UG1(xtj$ig[b[40462]][b6sku]);
    }e1U0[b[69134]][-0x2] = window[b[69285]](xtj$ig[b[40462]]), window[b[52672]][b[69286]](-0x2);
  } else alert(b[69294] + xtj$ig[b[44526]]);
}, window[b[69285]] = function (rzyhfv) {
  if (!rzyhfv && rzyhfv[b[40282]] <= 0x0) return rzyhfv;for (let m7av_4 = 0x0; m7av_4 < rzyhfv[b[40282]]; m7av_4++) {
    rzyhfv[m7av_4][b[69295]] && rzyhfv[m7av_4][b[69295]] == 0x1 && (rzyhfv[m7av_4][b[69216]] += b[69296]);
  }return rzyhfv;
}, window['e1U1G'] = function (us3qj, db0k96) {
  us3qj = us3qj || e1U0[b[65502]][b[51895]], sendApi(e1U0[b[69125]], b[69297], { 'type': '4', 'game_pkg': e1U0[b[65508]], 'server_id': us3qj }, db0k96);
}, window[b[69298]] = function (ma_47, uks9q, nuqsj3, sqn93) {
  nuqsj3 = nuqsj3 || e1U0[b[65502]][b[51895]], sendApi(e1U0[b[69125]], b[69299], { 'type': ma_47, 'game_pkg': uks9q, 'server_id': nuqsj3 }, sqn93);
}, window['e1UG1'] = function (k9suqn) {
  if (k9suqn) {
    if (k9suqn[b[40591]] == 0x1) {
      if (k9suqn[b[69300]] == 0x1) return 0x2;else return 0x1;
    } else return k9suqn[b[40591]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['e101GU'] = function (d086, rzlht) {
  e1U0[b[69301]] = { 'step': d086, 'server_id': rzlht };var lhrtxg = this;e11UG0({ 'title': b[69302] }), sendApi(e1U0[b[69125]], b[69303], { 'partner_id': e1U0[b[63933]], 'uid': e1U0[b[65507]], 'game_pkg': e1U0[b[65508]], 'server_id': rzlht, 'platform': e1U0[b[65477]], 'platform_uid': e1U0[b[65509]], 'check_login_time': e1U0[b[69209]], 'check_login_sign': e1U0[b[69208]], 'version_name': e1U0[b[69185]] }, e101UG, e1G0U, e101, function ($i3xq) {
    return $i3xq[b[44526]] == b[50307] || $i3xq[b[40569]] == b[69304] || $i3xq[b[40569]] == b[69305];
  });
}, window['e101UG'] = function (xtgrl) {
  var ghlxt = this;if (xtgrl[b[44526]] === b[50307] && xtgrl[b[40462]]) {
    var u96sb = e1U0[b[65502]];u96sb[b[69306]] = e1U0[b[69135]], u96sb[b[51878]] = String(xtgrl[b[40462]][b[69307]]), u96sb[b[65479]] = parseInt(xtgrl[b[40462]][b[41295]]);if (xtgrl[b[40462]][b[65478]]) u96sb[b[65478]] = parseInt(xtgrl[b[40462]][b[65478]]);else u96sb[b[65478]] = parseInt(xtgrl[b[40462]][b[51895]]);u96sb[b[69308]] = 0x0, u96sb[b[44928]] = e1U0[b[69228]], u96sb[b[69309]] = xtgrl[b[40462]][b[69310]], u96sb[b[69311]] = xtgrl[b[40462]][b[69311]], console[b[40417]](b[69312] + JSON[b[44914]](u96sb[b[69311]])), e1U0[b[41075]] == 0x1 && u96sb[b[69311]] && u96sb[b[69311]][b[69313]] == 0x1 && (e1U0[b[69314]] = 0x1, window[b[69031]][b[40623]]['e1I0U']()), e10G1U();
  } else e1U0[b[69301]][b[47505]] >= 0x3 ? (e101(JSON[b[44914]](xtgrl)), window['e11GU0'](b[69315] + xtgrl[b[44526]])) : sendApi(e1U0[b[69125]], b[69194], { 'platform': e1U0[b[69123]], 'partner_id': e1U0[b[63933]], 'token': e1U0[b[69192]], 'game_pkg': e1U0[b[65508]], 'deviceId': e1U0[b[65510]], 'scene': b[69195] + e1U0[b[69133]] }, function (thrgzl) {
    if (!thrgzl || thrgzl[b[44526]] != b[50307]) {
      window['e11GU0'](b[69207] + thrgzl && thrgzl[b[44526]]);return;
    }e1U0[b[69208]] = String(thrgzl[b[51878]]), e1U0[b[69209]] = String(thrgzl[b[41295]]), setTimeout(function () {
      e101GU(e1U0[b[69301]][b[47505]] + 0x1, e1U0[b[69301]][b[51895]]);
    }, 0x5dc);
  }, e1G0U, e101, function (xjtg) {
    return xjtg[b[44526]] == b[50307] || xjtg[b[44526]] == b[65829];
  });
}, window['e10G1U'] = function () {
  ServerLoading[b[40623]][b[69220]](e1U0[b[41075]]), window['e1G0'] = !![], window['e10U1G']();
}, window['e10GU1'] = function () {
  if (window['e10G'] && window['e1UG0'] && window[b[69141]] && window[b[69142]] && window['e1U0G'] && window['e1UG']) {
    if (!window[b[68707]][b[40623]]) {
      console[b[40417]](b[69316] + window[b[68707]][b[40623]]);var _y4vz = wx[b[69012]](),
          dw5182 = _y4vz[b[41221]] ? _y4vz[b[41221]] : 0x0,
          ca74m = { 'cdn': window['e1U0'][b[44928]], 'spareCdn': window['e1U0'][b[65197]], 'newRegister': window['e1U0'][b[41075]], 'wxPC': window['e1U0'][b[65199]], 'wxIOS': window['e1U0'][b[41515]], 'wxAndroid': window['e1U0'][b[51717]], 'wxParam': { 'limitLoad': window['e1U0']['e1I1G0U'], 'benchmarkLevel': window['e1U0']['e1I1UG0'], 'wxFrom': window[b[41004]][b[40296]] == b[69317] ? 0x1 : 0x0, 'wxSDKVersion': window[b[69032]] }, 'configType': window['e1U0'][b[52236]], 'exposeType': window['e1U0'][b[41159]], 'scene': dw5182 };new window[b[68707]](ca74m, window['e1U0'][b[40587]], window['e1I1GU0']);
    }
  }
}, window['e10U1G'] = function () {
  if (window['e10G'] && window['e1UG0'] && window[b[69141]] && window[b[69142]] && window['e1U0G'] && window['e1UG'] && window['e1G0'] && window['e1GU']) {
    e11U0G();if (!e10GU) {
      e10GU = !![];if (!window[b[68707]][b[40623]]) window['e10GU1']();var d90kb = 0x0,
          u9qs3n = wx[b[69318]]();u9qs3n && (window['e1U0'][b[69087]] && (d90kb = u9qs3n[b[40778]]), console[b[40569]](b[69319] + u9qs3n[b[40778]] + b[69320] + u9qs3n[b[41655]] + b[69321] + u9qs3n[b[41657]] + b[69322] + u9qs3n[b[41656]] + b[69323] + u9qs3n[b[40650]] + b[69324] + u9qs3n[b[40651]]));var i$3jxg = {};for (const un93sq in e1U0[b[65502]]) {
        i$3jxg[un93sq] = e1U0[b[65502]][un93sq];
      }var $gtlhx = { 'channel': window['e1U0'][b[65506]], 'account': window['e1U0'][b[65507]], 'userId': window['e1U0'][b[63932]], 'serverId': i$3jxg[b[51895]], 'cdn': window['e1U0'][b[44928]], 'data': window['e1U0'][b[40462]], 'package': window['e1U0'][b[40453]], 'newRegister': window['e1U0'][b[41075]], 'pkgName': window['e1U0'][b[65508]], 'partnerId': window['e1U0'][b[63933]], 'platform_uid': window['e1U0'][b[65509]], 'deviceId': window['e1U0'][b[65510]], 'selectedServer': i$3jxg, 'configType': window['e1U0'][b[52236]], 'exposeType': window['e1U0'][b[41159]], 'debugUsers': window['e1U0'][b[52626]], 'wxMenuTop': d90kb, 'wxShield': window['e1U0'][b[41183]] };if (window[b[69230]]) for (var qji3$x in window[b[69230]]) {
        $gtlhx[qji3$x] = window[b[69230]][qji3$x];
      }window[b[68707]][b[40623]]['e1GIU0']($gtlhx);
    }
  } else console[b[40569]](b[69325] + window['e10G'] + b[69326] + window['e1UG0'] + b[69327] + window[b[69141]] + b[69328] + window[b[69142]] + b[69329] + window['e1U0G'] + b[69330] + window['e1UG'] + b[69331] + window['e1G0'] + b[69332] + window['e1GU']);
};