var b = wx.$e;
console[b[40569]](b[69013]), window[b[69014]], wx[b[69015]](function (z4rfvy) {
  if (z4rfvy) {
    if (z4rfvy[b[40298]]) {
      var kns69 = window[b[41004]][b[69016]][b[40427]](new RegExp(/\./, 'g'), '_'),
          j3uq = z4rfvy[b[40298]],
          igxl$t = j3uq[b[40305]](/(eeeeeeee\/eeegame.js:)[0-9]{1,60}(:)/g);if (igxl$t) for (var $iqj3 = 0x0; $iqj3 < igxl$t[b[40282]]; $iqj3++) {
        if (igxl$t[$iqj3] && igxl$t[$iqj3][b[40282]] > 0x0) {
          var meoac = parseInt(igxl$t[$iqj3][b[40427]](b[69017], '')[b[40427]](':', ''));j3uq = j3uq[b[40427]](igxl$t[$iqj3], igxl$t[$iqj3][b[40427]](':' + meoac + ':', ':' + (meoac - 0x2) + ':'));
        }
      }j3uq = j3uq[b[40427]](new RegExp(b[69018], 'g'), b[69019] + kns69 + b[65605]), j3uq = j3uq[b[40427]](new RegExp(b[69020], 'g'), b[69019] + kns69 + b[65605]), z4rfvy[b[40298]] = j3uq;
    }var lzyr = { 'id': window['e1U0'][b[69021]], 'role': window['e1U0'][b[45045]], 'level': window['e1U0'][b[69022]], 'user': window['e1U0'][b[65507]], 'version': window['e1U0'][b[40587]], 'cdn': window['e1U0'][b[44928]], 'pkgName': window['e1U0'][b[65508]], 'gamever': window[b[41004]][b[69016]], 'serverid': window['e1U0'][b[65502]] ? window['e1U0'][b[65502]][b[51895]] : 0x0, 'systemInfo': window[b[69023]], 'error': b[69024], 'stack': z4rfvy ? z4rfvy[b[40298]] : '' },
        ks96bu = JSON[b[44914]](lzyr);console[b[40460]](b[69025] + ks96bu), (!window[b[69014]] || window[b[69014]] != lzyr[b[40460]]) && (window[b[69014]] = lzyr[b[40460]], window['e11U'](lzyr));
  }
});import 'eeemd5min.js';import 'eeezlibs.js';window[b[69026]] = require(b[69027]);import 'eeeindex.js';import 'eeelibsmin.js';import 'eeewxmini.js';import 'eeeinitmin.js';console[b[40569]](b[69028]), console[b[40569]](b[69029]), e11UG0({ 'title': b[69030] });var eemcapo = { 'e1I10UG': !![] };new window[b[69031]](eemcapo), window[b[69031]][b[40623]]['e1IGU01']();if (window['e1I1U0G']) clearInterval(window['e1I1U0G']);window['e1I1U0G'] = null, window['e1IG01U'] = function (_omca7, $ilgx) {
  if (!_omca7 || !$ilgx) return 0x0;_omca7 = _omca7[b[40404]]('.'), $ilgx = $ilgx[b[40404]]('.');const yzhrl = Math[b[40452]](_omca7[b[40282]], $ilgx[b[40282]]);while (_omca7[b[40282]] < yzhrl) {
    _omca7[b[40304]]('0');
  }while ($ilgx[b[40282]] < yzhrl) {
    $ilgx[b[40304]]('0');
  }for (var sq93un = 0x0; sq93un < yzhrl; sq93un++) {
    const k9qnsu = parseInt(_omca7[sq93un]),
          b06d9 = parseInt($ilgx[sq93un]);if (k9qnsu > b06d9) return 0x1;else {
      if (k9qnsu < b06d9) return -0x1;
    }
  }return 0x0;
}, window[b[69032]] = wx[b[69033]]()[b[69032]], console[b[40417]](b[69034] + window[b[69032]]);var ey_fzv = wx[b[69035]]();ey_fzv[b[69036]](function (qjnus) {
  console[b[40417]](b[69037] + qjnus[b[69038]]);
}), ey_fzv[b[69039]](function () {
  wx[b[69040]]({ 'title': b[69041], 'content': b[69042], 'showCancel': ![], 'success': function (xgtrhl) {
      ey_fzv[b[69043]]();
    } });
}), ey_fzv[b[69044]](function () {
  console[b[40417]](b[69045]);
}), window['e1IG0U1'] = function () {
  console[b[40417]](b[69046]);var xg3$ji = wx[b[69047]]({ 'name': b[69048], 'success': function (tj) {
      console[b[40417]](b[69049]), console[b[40417]](tj), tj && tj[b[65689]] == b[69050] ? (window['e10G'] = !![], window['e10GU1'](), window['e10U1G']()) : setTimeout(function () {
        window['e1IG0U1']();
      }, 0x1f4);
    }, 'fail': function (jqxi3$) {
      console[b[40417]](b[69051]), console[b[40417]](jqxi3$), setTimeout(function () {
        window['e1IG0U1']();
      }, 0x1f4);
    } });xg3$ji && xg3$ji[b[69052]](x$qij3 => {});
}, window['e1IU10G'] = function () {
  console[b[40417]](b[69053]);var qinu = wx[b[69047]]({ 'name': b[69054], 'success': function (dw520) {
      console[b[40417]](b[69055]), console[b[40417]](dw520), dw520 && dw520[b[65689]] == b[69050] ? (window['e1UG0'] = !![], window['e10GU1'](), window['e10U1G']()) : setTimeout(function () {
        window['e1IU10G']();
      }, 0x1f4);
    }, 'fail': function (hxt$lg) {
      console[b[40417]](b[69056]), console[b[40417]](hxt$lg), setTimeout(function () {
        window['e1IU10G']();
      }, 0x1f4);
    } });qinu && qinu[b[69052]](mco_a => {});
}, window[b[69057]] = function () {
  window['e1IG01U'](window[b[69032]], b[69058]) >= 0x0 ? (console[b[40417]](b[69059] + window[b[69032]] + b[69060]), window['e1U1'](), window['e1IG0U1'](), window['e1IU10G']()) : (window['e1U01'](b[69061], window[b[69032]]), wx[b[69040]]({ 'title': b[46749], 'content': b[69062] }));
}, window[b[69023]] = '', wx[b[69063]]({ 'success'(s9b6k0) {
    window[b[69023]] = b[69064] + s9b6k0[b[69065]] + b[69066] + s9b6k0[b[69067]] + b[69068] + s9b6k0[b[45115]] + b[69069] + s9b6k0[b[40927]] + b[69070] + s9b6k0[b[65477]] + b[69071] + s9b6k0[b[69032]] + b[69072] + s9b6k0[b[49694]], console[b[40417]](window[b[69023]]), console[b[40417]](b[69073] + s9b6k0[b[69074]] + b[69075] + s9b6k0[b[69076]] + b[69077] + s9b6k0[b[69078]] + b[69079] + s9b6k0[b[69080]] + b[69081] + s9b6k0[b[69082]] + b[69083] + s9b6k0[b[69084]] + b[69085] + (s9b6k0[b[69086]] ? s9b6k0[b[69086]][b[40778]] + ',' + s9b6k0[b[69086]][b[41655]] + ',' + s9b6k0[b[69086]][b[41657]] + ',' + s9b6k0[b[69086]][b[41656]] : ''));var vf74 = s9b6k0[b[40927]] ? s9b6k0[b[40927]][b[40331]]() : '',
        txhl = s9b6k0[b[69067]] ? s9b6k0[b[69067]][b[40331]]()[b[40427]]('\x20', '') : '';window['e1U0'][b[41515]] = vf74[b[40364]](b[68717]) != -0x1, window['e1U0'][b[51717]] = vf74[b[40364]](b[68716]) != -0x1, window['e1U0'][b[69087]] = vf74[b[40364]](b[68717]) != -0x1 || vf74[b[40364]](b[68716]) != -0x1, window['e1U0'][b[65199]] = vf74[b[40364]](b[69088]) != -0x1 || vf74[b[40364]](b[68722]) != -0x1, window['e1U0'][b[69089]] = s9b6k0[b[65477]] ? s9b6k0[b[65477]][b[40331]]() : '', window['e1U0']['e1I1G0U'] = ![], window['e1U0']['e1I1UG0'] = 0x2;if (vf74[b[40364]](b[68716]) != -0x1) {
      if (s9b6k0[b[49694]] >= 0x18) window['e1U0']['e1I1UG0'] = 0x3;else window['e1U0']['e1I1UG0'] = 0x2;
    } else {
      if (vf74[b[40364]](b[68717]) != -0x1) {
        if (s9b6k0[b[49694]] && s9b6k0[b[49694]] >= 0x14) window['e1U0']['e1I1UG0'] = 0x3;else {
          if (txhl[b[40364]](b[69090]) != -0x1 || txhl[b[40364]](b[69091]) != -0x1 || txhl[b[40364]](b[69092]) != -0x1 || txhl[b[40364]](b[69093]) != -0x1 || txhl[b[40364]](b[69094]) != -0x1) window['e1U0']['e1I1UG0'] = 0x2;else window['e1U0']['e1I1UG0'] = 0x3;
        }
      } else window['e1U0']['e1I1UG0'] = 0x2;
    }console[b[40417]](b[69095] + window['e1U0']['e1I1G0U'] + b[69096] + window['e1U0']['e1I1UG0']);
  } }), wx[b[69097]]({ 'success': function (yztr) {
    console[b[40417]](b[69098] + yztr[b[45022]] + b[69099] + yztr[b[69100]]);
  } }), wx[b[69101]]({ 'success': function (moa7c) {
    console[b[40417]](b[69102] + moa7c[b[69103]]);
  } }), wx[b[69104]]({ 'keepScreenOn': !![] }), wx[b[69105]](function (af_47v) {
  console[b[40417]](b[69102] + af_47v[b[69103]] + b[69106] + af_47v[b[69107]]);
}), wx[b[51228]](function (rvzhfy) {
  window['e1G1'] = rvzhfy, window['e101G'] && window['e1G1'] && (console[b[40569]](b[69108] + window['e1G1'][b[41221]]), window['e101G'](window['e1G1']), window['e1G1'] = null);
}), window[b[69109]] = 0x0, window['e1IUG01'] = 0x0, window[b[69110]] = null, wx[b[69111]](function () {
  window['e1IUG01']++;var b69k = Date[b[40574]]();(window[b[69109]] == 0x0 || b69k - window[b[69109]] > 0x1d4c0) && (console[b[40473]](b[69112]), wx[b[52290]]());if (window['e1IUG01'] >= 0x2) {
    window['e1IUG01'] = 0x0, console[b[40460]](b[69113]), wx[b[69114]]('0', 0x1);if (window['e1U0'] && window['e1U0'][b[41515]]) window['e1U01'](b[69115], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});