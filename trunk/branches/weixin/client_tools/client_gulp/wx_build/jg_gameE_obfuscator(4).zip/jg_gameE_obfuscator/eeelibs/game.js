var b = wx.$e;
require(b[69501]);