var _ = wx.y$;
(function (window, document, jlimhk) {
  var suvxtw = jlimhk['un'],
      jhgfie = jlimhk['uns'],
      kghifj = jlimhk['static'],
      ihgfk = jlimhk['class'],
      nikml = jlimhk['getset'],
      milkj = jlimhk['__newvec'],
      svwur = laya['utils']['Browser'],
      hefgji = laya['events']['Event'],
      jkolm = laya['events']['EventDispatcher'],
      fcbead = laya['resource']['HTMLImage'],
      z01y_ = laya['utils']['Handler'],
      kjnmol = laya['display']['Input'],
      hfjkg = laya['net']['Loader'],
      uvzyx = laya['maths']['Matrix'],
      trvuw = laya['renders']['Render'],
      edifh = laya['utils']['RunDriver'],
      febdc = laya['media']['Sound'],
      srtuv = laya['media']['SoundChannel'],
      orpsqt = laya['media']['SoundManager'],
      pnlom = laya['display']['Stage'],
      lqpmon = laya['net']['URL'],
      yvzxu = laya['utils']['Utils'],
      deacf = function () {
    function faecbd() {}return ihgfk(faecbd, 'laya.wx.mini.MiniAdpter'), faecbd['getJson'] = function (yz$x_0) {
      return JSON['parse'](yz$x_0);
    }, faecbd['init'] = function (hkjlim, cegdhf) {
      hkjlim === void 0x0 && (hkjlim = ![]), cegdhf === void 0x0 && (cegdhf = ![]);if (faecbd['_inited']) return;faecbd['window'] = window;if (faecbd['window']['navigator']['userAgent']['indexOf']('MiniGame') < 0x0) return;faecbd['_inited'] = !![], faecbd['isZiYu'] = cegdhf, faecbd['isPosMsgYu'] = hkjlim, faecbd['EnvConfig'] = {}, !faecbd['isZiYu'] && (lknmjo['setNativeFileDir']('/layaairGame'), lknmjo['existDir'](lknmjo['fileNativeDir'], z01y_['create'](faecbd, faecbd['onMkdirCallBack']))), faecbd['window']['focus'] = function () {}, jlimhk['getUrlPath'] = function () {}, faecbd['window']['logtime'] = function (urstv) {}, faecbd['window']['alertTimeLog'] = function (qolmnp) {}, faecbd['window']['resetShareInfo'] = function () {}, faecbd['window']['CanvasRenderingContext2D'] = function () {}, faecbd['window']['CanvasRenderingContext2D']['prototype'] = faecbd['window']['wx']['createCanvas']()['getContext']('2d')['__proto__'], faecbd['window']['document']['body']['appendChild'] = function () {}, faecbd['EnvConfig']['pixelRatioInt'] = 0x0, edifh['getPixelRatio'] = faecbd['pixelRatio'], faecbd['_preCreateElement'] = svwur['createElement'], svwur['createElement'] = faecbd['createElement'], edifh['createShaderCondition'] = faecbd['createShaderCondition'], yvzxu['parseXMLFromString'] = faecbd['parseXMLFromString'], kjnmol['_createInputElement'] = nlopqm['_createInputElement'], faecbd['EnvConfig']['load'] = hfjkg['prototype']['load'], hfjkg['prototype']['load'] = jmnilk['prototype']['load'], faecbd['isZiYu'] && hkjlim && wx['onMessage'](function (cghed) {
        cghed['isLoad'] && (lknmjo['ziyuFileData'][cghed['url']] = cghed['data']);
      });
    }, faecbd['onMkdirCallBack'] = function (jlkonm, y1z0$) {
      if (!jlkonm) lknmjo['filesListObj'] = JSON['parse'](y1z0$['data']);
    }, faecbd['pixelRatio'] = function () {
      if (!faecbd['EnvConfig']['pixelRatioInt']) try {
        var efbc = wx['getSystemInfoSync']();return faecbd['EnvConfig']['pixelRatioInt'] = efbc['pixelRatio'], efbc = efbc, efbc['pixelRatio'];
      } catch (dcae) {}return faecbd['EnvConfig']['pixelRatioInt'];
    }, faecbd['createElement'] = function (qo) {
      if (qo == 'canvas') {
        var sqropn;return faecbd['idx'] == 0x1 ? faecbd['isZiYu'] ? (sqropn = sharedCanvas, sqropn['style'] = {}) : sqropn = window['canvas'] : sqropn = window['wx']['createCanvas'](), faecbd['idx']++, sqropn;
      } else {
        if (qo == 'textarea' || qo == 'input') return faecbd['onCreateInput'](qo);else {
          if (qo == 'div') {
            var mljon = faecbd['_preCreateElement'](qo);return mljon['contains'] = function (jhkmil) {
              return null;
            }, mljon['removeChild'] = function (klgjhi) {}, mljon;
          } else return faecbd['_preCreateElement'](qo);
        }
      }
    }, faecbd['onCreateInput'] = function (lkmijh) {
      var rsqpt = faecbd['_preCreateElement'](lkmijh);return rsqpt['focus'] = nlopqm['wxinputFocus'], rsqpt['blur'] = nlopqm['wxinputblur'], rsqpt['style'] = {}, rsqpt['value'] = 0x0, rsqpt['parentElement'] = {}, rsqpt['placeholder'] = {}, rsqpt['type'] = {}, rsqpt['setColor'] = function (fgbdc) {}, rsqpt['setType'] = function (qsrtuv) {}, rsqpt['setFontFace'] = function (egfjhi) {}, rsqpt['addEventListener'] = function (egfhid) {}, rsqpt['contains'] = function (imkl) {
        return null;
      }, rsqpt['removeChild'] = function (feihd) {}, rsqpt;
    }, faecbd['createShaderCondition'] = function (twvsxu) {
      var lnjkom = this,
          xzuvy = function () {
        var nqspr = twvsxu;return lnjkom[twvsxu['replace']('this.', '')];
      };return xzuvy;
    }, faecbd['EnvConfig'] = null, faecbd['window'] = null, faecbd['_preCreateElement'] = null, faecbd['_inited'] = ![], faecbd['wxRequest'] = null, faecbd['systemInfo'] = null, faecbd['version'] = '0.0.1', faecbd['isZiYu'] = ![], faecbd['isPosMsgYu'] = ![], faecbd['parseXMLFromString'] = function (dchfge) {
      var hgdfi, jkonlm;dchfge = dchfge['replace'](/>\s+</g, '><');try {
        hgdfi = new window['Parser']['DOMParser']()['parseFromString'](dchfge, 'text/xml');
      } catch (imkhjl) {
        throw '需要引入xml解析库文件';
      }return hgdfi;
    }, faecbd['idx'] = 0x1, faecbd;
  }(),
      fji = function () {
    function rstvu() {}ihgfk(rstvu, 'laya.wx.mini.MiniImage');var aebfdc = rstvu['prototype'];return aebfdc['_loadImage'] = function (y$0_1) {
      var psrqo = this,
          spnqro = ![];y$0_1['indexOf']('layaNativeDir/') == -0x1 && (spnqro = !![], y$0_1 = lqpmon['formatURL'](y$0_1));if (!lknmjo['getFileInfo'](y$0_1)) {
        if (y$0_1['indexOf']('http://') != -0x1 || y$0_1['indexOf']('https://') != -0x1) lknmjo['downImg'](y$0_1, new z01y_(rstvu, rstvu['onDownImgCallBack'], [y$0_1, psrqo]), y$0_1);else rstvu['onCreateImage'](y$0_1, psrqo, !![]);
      } else rstvu['onCreateImage'](y$0_1, psrqo, !spnqro);
    }, rstvu['onDownImgCallBack'] = function (tvxuy, x_wyz, hegcdf) {
      if (!hegcdf) rstvu['onCreateImage'](tvxuy, x_wyz);else x_wyz['onError'](null);
    }, rstvu['onCreateImage'] = function (rsu, efgih, qrpsu) {
      qrpsu === void 0x0 && (qrpsu = ![]);var rqn;if (!qrpsu) {
        var rqopnm = lknmjo['getFileInfo'](rsu),
            srtup = rqopnm['md5'];rqn = lknmjo['getFileNativePath'](srtup);
      } else rqn = rsu;if (efgih['imgCache'] == null) efgih['imgCache'] = {};var ghkli;function jglihk() {
        ghkli['onload'] = null, ghkli['onerror'] = null, delete efgih['imgCache'][rsu];
      };var jkhgil = function () {
        jglihk(), efgih['onLoaded'](ghkli);
      },
          bcefd = function () {
        jglihk(), efgih['event']('error', 'Load image failed');
      };efgih['_type'] == 'nativeimage' ? (ghkli = new svwur['window']['Image'](), ghkli['crossOrigin'] = '', ghkli['onload'] = jkhgil, ghkli['onerror'] = bcefd, ghkli['src'] = rqn, efgih['imgCache'][rsu] = ghkli) : new fcbead['create'](rqn, { 'onload': jkhgil, 'onerror': bcefd, 'onCreate': function (morqpn) {
          ghkli = morqpn, efgih['imgCache'][rsu] = morqpn;
        } });
    }, rstvu;
  }(),
      nlopqm = function () {
    function nlqop() {}return ihgfk(nlqop, 'laya.wx.mini.MiniInput'), nlqop['_createInputElement'] = function () {
      kjnmol['_initInput'](kjnmol['area'] = svwur['createElement']('textarea')), kjnmol['_initInput'](kjnmol['input'] = svwur['createElement']('input')), kjnmol['inputContainer'] = svwur['createElement']('div'), kjnmol['inputContainer']['style']['position'] = 'absolute', kjnmol['inputContainer']['style']['zIndex'] = 0x186a0, svwur['container']['appendChild'](kjnmol['inputContainer']), kjnmol['inputContainer']['setPos'] = function (otrq, kljomn) {
        kjnmol['inputContainer']['style']['left'] = otrq + 'px', kjnmol['inputContainer']['style']['top'] = kljomn + 'px';
      }, jlimhk['stage']['on']('resize', null, nlqop['_onStageResize']), wx['onWindowResize'] && wx['onWindowResize'](function (kjifg) {
        window['dispatchEvent'] && window['dispatchEvent']('resize');
      }), orpsqt['_soundClass'] = okmln, orpsqt['_musicClass'] = okmln;
    }, nlqop['_onStageResize'] = function () {
      var $2z_1 = jlimhk['stage']['_canvasTransform']['identity']();$2z_1['scale'](svwur['width'] / trvuw['canvas']['width'] / edifh['getPixelRatio'](), svwur['height'] / trvuw['canvas']['height'] / edifh['getPixelRatio']());
    }, nlqop['wxinputFocus'] = function (mpklno) {
      var okmn = kjnmol['inputElement']['target'];if (okmn && !okmn['editable']) return;deacf['window']['wx']['offKeyboardConfirm'](), deacf['window']['wx']['offKeyboardInput'](), deacf['window']['wx']['showKeyboard']({ 'defaultValue': okmn['text'], 'maxLength': okmn['maxChars'], 'multiple': okmn['multiline'], 'confirmHold': !![], 'confirmType': 'done', 'success': function (bfcde) {}, 'fail': function (pstuq) {} }), deacf['window']['wx']['onKeyboardConfirm'](function (onmjk) {
        var qpnml = onmjk ? onmjk['value'] : '';okmn['text'] = qpnml, okmn['event']('input'), laya['wx']['mini']['MiniInput']['inputEnter']();
      }), deacf['window']['wx']['onKeyboardInput'](function (bfecgd) {
        var xwvut = bfecgd ? bfecgd['value'] : '';if (!okmn['multiline']) {
          if (xwvut['indexOf']('\x0a') != -0x1) {
            laya['wx']['mini']['MiniInput']['inputEnter']();return;
          }
        }okmn['text'] = xwvut, okmn['event']('input');
      });
    }, nlqop['inputEnter'] = function () {
      kjnmol['inputElement']['target']['focus'] = ![];
    }, nlqop['wxinputblur'] = function () {
      nlqop['hideKeyboard']();
    }, nlqop['hideKeyboard'] = function () {
      deacf['window']['wx']['offKeyboardConfirm'](), deacf['window']['wx']['offKeyboardInput'](), deacf['window']['wx']['hideKeyboard']({ 'success': function (ijghfe) {
          console['log']('隐藏键盘');
        }, 'fail': function (rsqop) {
          console['log']('隐藏键盘出错:' + (rsqop ? rsqop['errMsg'] : ''));
        } });
    }, nlqop;
  }(),
      jmnilk = function () {
    function xwuyzv() {}ihgfk(xwuyzv, 'laya.wx.mini.MiniLoader');var _234 = xwuyzv['prototype'];return _234['load'] = function (jlkhgi, dbfeg, twuy, vyxt, rsoqn) {
      twuy === void 0x0 && (twuy = !![]), rsoqn === void 0x0 && (rsoqn = ![]);var pnrqm = this;pnrqm['_url'] = jlkhgi;if (jlkhgi['indexOf']('data:image') === 0x0) pnrqm['_type'] = dbfeg = 'image';else pnrqm['_type'] = dbfeg || (dbfeg = pnrqm['getTypeFromUrl'](jlkhgi));pnrqm['_cache'] = twuy, pnrqm['_data'] = null;var rtwv = 'ascii';if (jlkhgi['indexOf']('.fnt') != -0x1) rtwv = 'utf8';else dbfeg == 'arraybuffer' && (rtwv = '');;var qopr = yvzxu['getFileExtension'](jlkhgi);if (xwuyzv['_fileTypeArr']['indexOf'](qopr) != -0x1) deacf['EnvConfig']['load']['call'](this, jlkhgi, dbfeg, twuy, vyxt, rsoqn);else {
        if (!lknmjo['getFileInfo'](jlkhgi)) {
          if (jlkhgi['indexOf']('layaNativeDir/') != -0x1) {
            if (deacf['isZiYu']) {
              var ghjkil = lknmjo['ziyuFileData'][jlkhgi];pnrqm['onLoaded'](ghjkil);return;
            } else {
              cosnole['log']('read read'), lknmjo['read'](jlkhgi, rtwv, new z01y_(xwuyzv, xwuyzv['onReadNativeCallBack'], [rtwv, jlkhgi, dbfeg, twuy, vyxt, rsoqn, pnrqm]));return;
            }
          }if (lqpmon['rootPath'] == '') var srvtw = jlkhgi;else srvtw = jlkhgi['split'](lqpmon['rootPath'])[0x0];jlkhgi['indexOf']('http://') != -0x1 || jlkhgi['indexOf']('https://') != -0x1 ? deacf['EnvConfig']['load']['call'](pnrqm, jlkhgi, dbfeg, twuy, vyxt, rsoqn) : lknmjo['readFile'](srvtw, rtwv, new z01y_(xwuyzv, xwuyzv['onReadNativeCallBack'], [rtwv, jlkhgi, dbfeg, twuy, vyxt, rsoqn, pnrqm]), jlkhgi);
        } else deacf['EnvConfig']['load']['call'](this, jlkhgi, dbfeg, twuy, vyxt, rsoqn);
      }
    }, _234['resMgrLoad'] = function (milkhj, mjikn, onmprq, dgcbfe, kjnl, egdfc, lnjik) {
      onmprq === void 0x0 && (onmprq = 0x0), dgcbfe === void 0x0 && (dgcbfe = ![]), kjnl === void 0x0 && (kjnl = ![]), egdfc === void 0x0 && (egdfc = 0x0), lnjik === void 0x0 && (lnjik = 0x3), milkhj['indexOf']('mpack') != -0x1 && console['log']('=============resMgrLoad url:', milkhj), deacf['EnvConfig']['resMgrLoad'](milkhj, (dfbeac, poqlmn, norspq) => {
        xwuyzv['prototype']['resMgrLoadCallBack'](dfbeac, poqlmn, norspq, mjikn);
      }, onmprq, dgcbfe, kjnl, egdfc, lnjik);
    }, _234['resMgrLoadCallBack'] = function (xvuytw, qrpsno, $vwyz, eadfcb) {
      console['log']('buff:::', xvuytw, $vwyz, lknmjo['fileNativeDir'] + '///' + lknmjo['fileListName']), eadfcb(xvuytw, qrpsno, $vwyz);
    }, _234['clearRes'] = function (ghedfi, knjmlo) {
      knjmlo === void 0x0 && (knjmlo = ![]);var jgkhf = this;jgkhf['clearRes'](ghedfi, knjmlo);var lghik = lknmjo['getFileInfo'](ghedfi);if (lghik && (ghedfi['indexOf']('http://') != -0x1 || ghedfi['indexOf']('https://') != -0x1)) {
        var _10234 = lghik['md5'],
            fkjhig = lknmjo['getFileNativePath'](_10234);lknmjo['remove'](fkjhig);
      }
    }, xwuyzv['onReadNativeCallBack'] = function (hc, edfchg, vutqr, igde, ijglhk, qrsvu, psrqno, mkonpl, jhlikg) {
      igde === void 0x0 && (igde = !![]), qrsvu === void 0x0 && (qrsvu = ![]), mkonpl === void 0x0 && (mkonpl = 0x0);if (!mkonpl) {
        var pnsoqr;if (vutqr == 'json' || vutqr == 'atlas') pnsoqr = deacf['getJson'](jhlikg['data']);else vutqr == 'xml' ? pnsoqr = yvzxu['parseXMLFromString'](jhlikg['data']) : pnsoqr = jhlikg['data'];psrqno['onLoaded'](pnsoqr), !deacf['isZiYu'] && deacf['isPosMsgYu'] && vutqr != 'arraybuffer' && wx['postMessage']({ 'url': edfchg, 'data': pnsoqr, 'isLoad': !![] });
      } else mkonpl == 0x1 && deacf['EnvConfig']['load']['call'](psrqno, edfchg, vutqr, igde, ijglhk, qrsvu);
    }, kghifj(xwuyzv, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['png', 'jpg', 'bmp', 'jpeg', 'gif'];
    }]), xwuyzv;
  }(),
      lknmjo = function (aef) {
    function qsrpo() {
      qsrpo['__super']['call'](this);;
    }return ihgfk(qsrpo, 'laya.wx.mini.MiniFileMgr', aef), qsrpo['isLoadFile'] = function (ifgdhe) {
      return qsrpo['_fileTypeArr']['indexOf'](ifgdhe) != -0x1 ? !![] : ![];
    }, qsrpo['getFileInfo'] = function (qplmo) {
      var konlpm = qplmo['split']('?')[0x0],
          ormn = qsrpo['filesListObj'][konlpm];if (ormn == null) return null;else return ormn;return null;
    }, qsrpo['onFileUpdate'] = function ($y0_z, nqorp) {
      var qvutsr = $y0_z['split']('/'),
          zw_y$x = qvutsr[qvutsr['length'] - 0x1],
          xwyz_ = qsrpo['getFileInfo'](nqorp);if (xwyz_ == null) qsrpo['onSaveFile'](nqorp, zw_y$x);else {
        if (xwyz_['readyUrl'] != nqorp) qsrpo['remove'](zw_y$x, nqorp);
      }
    }, qsrpo['exits'] = function (nosrp, qomnl) {
      var klhmi = qsrpo['getFileNativePath'](nosrp);qsrpo['fs']['getFileInfo']({ 'filePath': klhmi, 'success': function (cfdaeb) {
          qomnl != null && qomnl['runWith']([0x0, cfdaeb]);
        }, 'fail': function (orspt) {
          qomnl != null && qomnl['runWith']([0x1, orspt]);
        } });
    }, qsrpo['read'] = function (pnmoql, higjl, aed, kgjhl) {
      higjl === void 0x0 && (higjl = 'ascill'), kgjhl === void 0x0 && (kgjhl = '');var prnos;kgjhl != '' ? prnos = qsrpo['getFileNativePath'](pnmoql) : prnos = pnmoql, qsrpo['fs']['readFile']({ 'filePath': prnos, 'encoding': higjl, 'success': function (vtusw) {
          aed != null && aed['runWith']([0x0, vtusw]);
        }, 'fail': function (jlgihk) {
          if (jlgihk && kgjhl != '') qsrpo['down'](kgjhl, higjl, aed, kgjhl);else aed != null && aed['runWith']([0x1]);
        } });
    }, qsrpo['readNativeFile'] = function (hgfeij, _13420) {
      qsrpo['fs']['readFile']({ 'filePath': hgfeij, 'encoding': '', 'success': function (ighefj) {
          _13420 != null && _13420['runWith']([0x0]);
        }, 'fail': function (pnmlqo) {
          _13420 != null && _13420['runWith']([0x1]);
        } });
    }, qsrpo['down'] = function (jfihg, lgjhki, idehgf, fie) {
      lgjhki === void 0x0 && (lgjhki = 'ascill'), fie === void 0x0 && (fie = '');var vtxus = qsrpo['getFileNativePath'](fie),
          fcgdeb = qsrpo['wxdown']({ 'url': jfihg, 'filePath': vtxus, 'success': function (opnqml) {
          if (opnqml['statusCode'] === 0xc8) qsrpo['readFile'](opnqml['filePath'], lgjhki, idehgf, fie);
        }, 'fail': function (pnmrqo) {
          idehgf != null && idehgf['runWith']([0x1, pnmrqo]);
        } });fcgdeb['onProgressUpdate'](function (svutrq) {
        idehgf != null && idehgf['runWith']([0x2, svutrq['progress']]);
      });
    }, qsrpo['readFile'] = function (tvuqs, $_01zy, suqvr, ilmhjk) {
      $_01zy === void 0x0 && ($_01zy = 'ascill'), ilmhjk === void 0x0 && (ilmhjk = ''), qsrpo['fs']['readFile']({ 'filePath': tvuqs, 'encoding': $_01zy, 'success': function (nlmji) {
          if (tvuqs['indexOf']('http://') != -0x1 || tvuqs['indexOf']('https://') != -0x1) qsrpo['onFileUpdate'](tvuqs, ilmhjk);suqvr != null && suqvr['runWith']([0x0, nlmji]);
        }, 'fail': function (rwsutv) {
          if (rwsutv) suqvr != null && suqvr['runWith']([0x1, rwsutv]);
        } });
    }, qsrpo['downImg'] = function (likhmj, z2$01, vqut) {
      vqut === void 0x0 && (vqut = '');var klmjno = qsrpo['wxdown']({ 'url': likhmj, 'success': function (uvrsq) {
          uvrsq['statusCode'] === 0xc8 && qsrpo['copyFile'](uvrsq['tempFilePath'], vqut, z2$01);
        }, 'fail': function (z0_x) {
          z2$01 != null && z2$01['runWith']([0x1, z0_x]);
        } });
    }, qsrpo['copyFile'] = function (kglhi, nmljki, ebcd) {
      var $_1203 = kglhi['split']('/'),
          zvxw$y = $_1203[$_1203['length'] - 0x1],
          pqso = nmljki['split']('?')[0x0],
          z0xy$ = qsrpo['getFileInfo'](nmljki),
          bdefgc = qsrpo['getFileNativePath'](zvxw$y);qsrpo['fs']['copyFile']({ 'srcPath': kglhi, 'destPath': bdefgc, 'success': function (ijhgfk) {
          if (!z0xy$) qsrpo['onSaveFile'](nmljki, zvxw$y), ebcd != null && ebcd['runWith']([0x0]);else {
            if (z0xy$['readyUrl'] != nmljki) qsrpo['remove'](zvxw$y, nmljki, ebcd);
          }
        }, 'fail': function (wtrvsu) {
          ebcd != null && ebcd['runWith']([0x1, wtrvsu]);
        } });
    }, qsrpo['getFileNativePath'] = function ($ywzv) {
      return laya['wx']['mini']['MiniFileMgr']['fileNativeDir'] + '/' + $ywzv;
    }, qsrpo['remove'] = function (pqns, bcge, vyx$) {
      bcge === void 0x0 && (bcge = '');var nmoql = qsrpo['getFileInfo'](bcge),
          cedbf = qsrpo['getFileNativePath'](nmoql['md5']);jlimhk['loader']['clearRes'](nmoql['readyUrl']), qsrpo['fs']['unlink']({ 'filePath': cedbf, 'success': function (_y01z$) {
          if (bcge != '') qsrpo['onSaveFile'](bcge, pqns);vyx$ != null && vyx$['runWith']([0x0]);
        }, 'fail': function (vtus) {} });
    }, qsrpo['onSaveFile'] = function (noprs, rsupqt) {
      var opnrq = noprs['split']('?')[0x0];qsrpo['filesListObj'][opnrq] = { 'md5': rsupqt, 'readyUrl': noprs }, qsrpo['fs']['writeFile']({ 'filePath': qsrpo['fileNativeDir'] + '/' + qsrpo['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](qsrpo['filesListObj']), 'success': function (gcdfbe) {
          console['log']('写入测试测试成功：', gcdfbe);
        }, 'fail': function (mhjk) {
          console['log']('写入测试测试失败：', mhjk);
        } });
    }, qsrpo['existDir'] = function (egfcdb, tqrs) {
      qsrpo['fs']['mkdir']({ 'dirPath': egfcdb, 'success': function (ko) {
          tqrs != null && tqrs['runWith']([0x0, { 'data': JSON['stringify']({}) }]);
        }, 'fail': function (dcfbae) {
          if (dcfbae['errMsg']['indexOf']('file already exists') != -0x1) qsrpo['readSync'](qsrpo['fileListName'], 'utf8', tqrs);else tqrs != null && tqrs['runWith']([0x1, dcfbae]);
        } });
    }, qsrpo['readSync'] = function (onjmk, _1, oljmnk, $023_1) {
      _1 === void 0x0 && (_1 = 'ascill'), $023_1 === void 0x0 && ($023_1 = '');var _z$x = qsrpo['getFileNativePath'](onjmk),
          qopmn;try {
        qopmn = qsrpo['fs']['readFileSync'](_z$x), oljmnk != null && oljmnk['runWith']([0x0, { 'data': qopmn }]);
      } catch (tuxvyw) {
        oljmnk != null && oljmnk['runWith']([0x1]);
      }
    }, qsrpo['readCache'] = function () {}, qsrpo['writeCache'] = function (vusqt) {
      var nkpl = readyUrl['split']('?')[0x0];qsrpo['filesListObj'][nkpl] = { 'md5': md5Name, 'readyUrl': readyUrl }, qsrpo['fs']['writeFile']({ 'filePath': qsrpo['fileNativeDir'] + '/' + qsrpo['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](qsrpo['filesListObj']), 'success': function (z$0xy_) {}, 'fail': function (lm) {} });
    }, qsrpo['setNativeFileDir'] = function (z$0_1) {
      qsrpo['fileNativeDir'] = wx['env']['USER_DATA_PATH'] + z$0_1;
    }, qsrpo['filesListObj'] = {}, qsrpo['fileNativeDir'] = null, qsrpo['fileListName'] = 'layaairfiles.txt', qsrpo['ziyuFileData'] = {}, kghifj(qsrpo, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['json', 'ani', 'xml', 'sk', 'txt', 'atlas', 'swf', 'part', 'fnt', 'proto', 'lh', 'lav', 'lani', 'lmat', 'lm', 'ltc'];
    }, 'fs', function () {
      return this['fs'] = wx['getFileSystemManager']();
    }, 'wxdown', function () {
      return this['wxdown'] = wx['downloadFile'];
    }]), qsrpo;
  }(jkolm),
      okmln = function (rstu) {
    function pnroqm() {
      this['_sound'] = null, this['url'] = null, this['loaded'] = ![], pnroqm['__super']['call'](this), this['_sound'] = pnroqm['_createSound']();
    }ihgfk(pnroqm, 'laya.wx.mini.MiniSound', rstu);var nop = pnroqm['prototype'];return nop['load'] = function (konml) {
      var uxzyv = this;konml = lqpmon['formatURL'](konml), this['url'] = konml;if (pnroqm['_audioCache'][konml]) {
        this['event']('complete');return;
      }function ilkmjn() {
        if (pnroqm['_null'] != undefined) uxzyv['_sound']['onCanplay'](pnroqm['_null']), uxzyv['_sound']['onError'](pnroqm['_null']);else try {
          uxzyv['_sound']['onCanplay'](null), uxzyv['_sound']['onError'](null), pnroqm['_null'] = null;
        } catch (jfgieh) {
          console['warn']('[wxmini] _clearSound:' + jfgieh), uxzyv['_sound']['onCanplay'](nplm), uxzyv['_sound']['onError'](nplm), pnroqm['_null'] = nplm;
        }
      }function rnpsq() {
        ilkmjn(), cfba['loaded'] = !![], cfba['event']('complete'), pnroqm['_audioCache'][cfba['url']] = cfba;
      }function ljnmo(rtsq) {
        console['error']('errCode=' + rtsq['errCode'] + '  errMsg=' + rtsq['errMsg']), ilkmjn(), cfba['event']('error');
      }function nplm() {}this['_sound']['onCanplay'](rnpsq), this['_sound']['onError'](ljnmo), this['_sound']['src'] = konml;var cfba = this;
    }, nop['play'] = function (nlkjo, gihef) {
      nlkjo === void 0x0 && (nlkjo = 0x0), gihef === void 0x0 && (gihef = 0x0);var xsuwv;if (this['url'] == orpsqt['_tMusic']) {
        if (!pnroqm['_musicAudio']) pnroqm['_musicAudio'] = pnroqm['_createSound']();xsuwv = pnroqm['_musicAudio'];
      } else xsuwv = pnroqm['_createSound']();xsuwv['src'] = this['url'];var wvuxyz = new ikgj(xsuwv);return wvuxyz['url'] = this['url'], wvuxyz['loops'] = gihef, wvuxyz['startTime'] = nlkjo, wvuxyz['play'](), orpsqt['addChannel'](wvuxyz), wvuxyz;
    }, nop['dispose'] = function () {
      var wzxvy$ = pnroqm['_audioCache'][this['url']];wzxvy$ && (wzxvy$['src'] = '', delete pnroqm['_audioCache'][this['url']]);
    }, nikml(0x0, nop, 'duration', function () {
      return this['_sound']['duration'];
    }), pnroqm['_createSound'] = function () {
      return pnroqm['_id']++, deacf['window']['wx']['createInnerAudioContext']();
    }, pnroqm['_musicAudio'] = null, pnroqm['_id'] = 0x0, pnroqm['_audioCache'] = {}, pnroqm['_null'] = undefined, pnroqm;
  }(jkolm),
      ikgj = function (jhkim) {
    function z_yxw(eghdif) {
      this['_audio'] = null, this['_onEnd'] = null, z_yxw['__super']['call'](this), this['_audio'] = eghdif, this['_onEnd'] = yvzxu['bind'](this['__onEnd'], this), eghdif['onEnded'](this['_onEnd']);
    }ihgfk(z_yxw, 'laya.wx.mini.MiniSoundChannel', jhkim);var fdbeg = z_yxw['prototype'];return fdbeg['__onEnd'] = function () {
      if (this['loops'] == 0x1) {
        this['completeHandler'] && (jlimhk['timer']['once'](0xa, this, this['__runComplete'], [this['completeHandler']], ![]), this['completeHandler'] = null);this['stop'](), this['event']('complete');return;
      }this['loops'] > 0x0 && this['loops']--, this['startTime'] = 0x0, this['play']();
    }, fdbeg['__onNull'] = function () {}, fdbeg['play'] = function () {
      this['isStopped'] = ![], orpsqt['addChannel'](this);if (this['_audio']) this['_audio']['play']();
    }, fdbeg['stop'] = function () {
      this['isStopped'] = !![], orpsqt['removeChannel'](this), this['completeHandler'] = null;if (!this['_audio']) return;this['_audio']['stop']();if (z_yxw['_null'] != undefined) this['_audio']['onEnded'](z_yxw['_null']);else try {
        this['_audio']['onEnded'](null), z_yxw['_null'] = null;
      } catch (tuywvx) {
        console['warn']('[wxmini] stop:' + tuywvx), this['_audio']['onEnded'](yvzxu['bind'](this['__onNull'], this)), z_yxw['_null'] = yvzxu['bind'](this['__onNull'], this);
      }this['_audio'] = null;
    }, fdbeg['pause'] = function () {
      this['isStopped'] = !![], this['_audio']['pause']();
    }, fdbeg['resume'] = function () {
      if (!this['_audio']) return;this['isStopped'] = ![], orpsqt['addChannel'](this), this['_audio']['play']();
    }, nikml(0x0, fdbeg, 'position', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['currentTime'];
    }), nikml(0x0, fdbeg, 'duration', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['duration'];
    }), nikml(0x0, fdbeg, 'volume', function () {
      return 0x1;
    }, function (dbecaf) {}), z_yxw['_null'] = undefined, z_yxw;
  }(srtuv);
})(window, document, Laya);typeof define === 'function' && define['amd'] && define('laya.core', ['require', 'exports'], function (require, exports) {
  'use strict';

  Object['defineProperty'](exports, '__esModule', { 'value': !![] });for (var lmopkn in Laya) {
    var utrsw = Laya[lmopkn];utrsw && utrsw['__isclass'] && (exports[lmopkn] = utrsw);
  }
});