var _ = wx.y$;
var HOST = _[27403];
var that = this;
export default class Dall {
    stebutonanimation(partner_id, game_pkg, game_id) {
        let username = wx.getStorageSync(_[27404]);
        let sign = "";
        let ts = Date.now();
        console.log(_[27405] + username);
        let that = this;
        wx.request({
            url: _[27406] + HOST + _[27407] + partner_id + '/' + game_pkg,
            method: _[27408],
            dataType: _[5696],
            header: {
                'content-type': _[27409] // 默认值
            },
            data: {
                username: username,
                ts: ts
            },
            success: function (res) {
                sign = res.data.data;
                that.Getto(username, ts, sign, game_id);
            }
        });
    }
    Getto(username, ts, sign, game_id) {
        wx.navigateToMiniProgram({
            appId: _[27410],
            path: _[27411] + username + _[27412] + ts + _[27413] + sign + _[27414] + game_id,
            extraData: {
                foo: _[19648]
            },
            envVersion: _[27415],
            success(res) {
                wx.showToast({
                    title: _[27416]
                });
            }
        });
    }

}