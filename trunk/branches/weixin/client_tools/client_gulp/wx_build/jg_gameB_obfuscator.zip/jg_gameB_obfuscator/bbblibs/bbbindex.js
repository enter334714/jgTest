var _ = wx.y$;
import _dkpmlno from '../bbbk/bbbsdk.js';window[_[29253]] = { 'wxVersion': window[_[557]][_[29152]] }, window[_[29254]] = ![], window['p$ED'] = 0x1, window[_[29255]] = 0x1, window['p$CDE'] = !![], window[_[29256]] = !![], window['p$ABCDE'] = '', window['p$DE'] = { 'base_cdn': _[29257], 'cdn': _[29257] }, p$DE[_[29258]] = {}, p$DE[_[25052]] = '0', p$DE[_[4740]] = window[_[29253]][_[29259]], p$DE[_[29225]] = '', p$DE['os'] = '1', p$DE[_[29260]] = _[29261], p$DE[_[29262]] = _[29263], p$DE[_[29264]] = _[29265], p$DE[_[29266]] = _[29267], p$DE[_[29268]] = _[29269], p$DE[_[23752]] = '1', p$DE[_[25347]] = '', p$DE[_[25349]] = '', p$DE[_[29270]] = 0x0, p$DE[_[29271]] = {}, p$DE[_[29272]] = parseInt(p$DE[_[23752]]), p$DE[_[25345]] = p$DE[_[23752]], p$DE[_[25341]] = {}, p$DE['p$BD'] = _[29273], p$DE[_[29274]] = ![], p$DE[_[12296]] = _[29275], p$DE[_[25320]] = Date[_[83]](), p$DE[_[11898]] = _[29276], p$DE[_[714]] = '_a', p$DE[_[29277]] = 0x2, p$DE[_[101]] = 0x7c1, p$DE[_[29259]] = window[_[29253]][_[29259]], p$DE[_[738]] = ![], p$DE[_[1074]] = ![], p$DE[_[11374]] = ![], p$DE[_[25054]] = ![], window['p$CED'] = 0x5, window['p$CE'] = ![], window['p$EC'] = ![], window['p$DCE'] = ![], window[_[29278]] = ![], window[_[29279]] = ![], window['p$DEC'] = ![], window['p$CD'] = ![], window['p$DC'] = ![], window['p$ECD'] = ![], window[_[4208]] = function (xtvwu) {
  console[_[482]](_[4208], xtvwu), wx[_[5020]]({}), wx[_[29176]]({ 'title': _[6394], 'content': xtvwu, 'success'(jkilnm) {
      if (jkilnm[_[29280]]) console[_[482]](_[29281]);else jkilnm[_[553]] && console[_[482]](_[29282]);
    } });
}, window['p$BCDE'] = function (wytxvu) {
  console[_[482]](_[29283], wytxvu), p$BDEC(), wx[_[29176]]({ 'title': _[6394], 'content': wytxvu, 'confirmText': _[29284], 'cancelText': _[18584], 'success'(khj) {
      if (khj[_[29280]]) window['p$DB']();else khj[_[553]] && (console[_[482]](_[29285]), wx[_[25047]]({}));
    } });
}, window[_[29286]] = function (mnploq) {
  console[_[482]](_[29286], mnploq), wx[_[29176]]({ 'title': _[6394], 'content': mnploq, 'confirmText': _[25477], 'showCancel': ![], 'complete'(y$_0xz) {
      console[_[482]](_[29285]), wx[_[25047]]({});
    } });
}, window['p$BCED'] = ![], window['p$BDCE'] = function (yuvz) {
  window['p$BCED'] = !![], wx[_[5019]](yuvz);
}, window['p$BDEC'] = function () {
  window['p$BCED'] && (window['p$BCED'] = ![], wx[_[5020]]({}));
}, window['p$BECD'] = function (sonrpq) {
  window[_[29167]][_[148]]['p$BECD'](sonrpq);
}, window[_[12174]] = function (kjlnim, vyutx) {
  _dkpmlno[_[12174]](kjlnim, function ($zy_0) {
    $zy_0 && $zy_0[_[11]] ? $zy_0[_[11]][_[4141]] == 0x1 ? vyutx(!![]) : (vyutx(![]), console[_[78]](_[29287] + $zy_0[_[11]][_[29288]])) : console[_[482]](_[12174], $zy_0);
  });
}, window['p$BEDC'] = function (jlkno) {
  console[_[482]](_[29289], jlkno);
}, window['p$BDE'] = function (tsqr) {}, window['p$BED'] = function (rsonq, rqst, ilkjh) {}, window['p$BE'] = function (sqonr) {
  console[_[482]](_[29290], sqonr), window[_[29167]][_[148]][_[29291]](), window[_[29167]][_[148]][_[29292]](), window[_[29167]][_[148]][_[29293]]();
}, window['p$EB'] = function (qostpr) {
  window['p$BCDE'](_[29294]);var eacdf = { 'id': window['p$DE'][_[29157]], 'role': window['p$DE'][_[4669]], 'level': window['p$DE'][_[29158]], 'account': window['p$DE'][_[25346]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4546]], 'pkgName': window['p$DE'][_[25347]], 'gamever': window[_[557]][_[29152]], 'serverid': window['p$DE'][_[25341]] ? window['p$DE'][_[25341]][_[11552]] : 0x0, 'systemInfo': window[_[29159]], 'error': _[29295], 'stack': qostpr ? qostpr : _[29294] },
      ilkh = JSON[_[4532]](eacdf);console[_[125]](_[29296] + ilkh), window['p$BD'](ilkh);
}, window['p$DBE'] = function (gihklj) {
  var mropnq = JSON[_[527]](gihklj);mropnq[_[29297]] = window[_[557]][_[29152]], mropnq[_[29298]] = window['p$DE'][_[25341]] ? window['p$DE'][_[25341]][_[11552]] : 0x0, mropnq[_[29159]] = window[_[29159]];var ywtux = JSON[_[4532]](mropnq);console[_[125]](_[29299] + ywtux), window['p$BD'](ywtux);
}, window['p$DEB'] = function (y$_xzw, _023$1) {
  var _140 = { 'id': window['p$DE'][_[29157]], 'role': window['p$DE'][_[4669]], 'level': window['p$DE'][_[29158]], 'account': window['p$DE'][_[25346]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4546]], 'pkgName': window['p$DE'][_[25347]], 'gamever': window[_[557]][_[29152]], 'serverid': window['p$DE'][_[25341]] ? window['p$DE'][_[25341]][_[11552]] : 0x0, 'systemInfo': window[_[29159]], 'error': y$_xzw, 'stack': _023$1 },
      zwuyx = JSON[_[4532]](_140);console[_[96]](_[29300] + zwuyx), window['p$BD'](zwuyx);
}, window['p$BD'] = function (nijlkm) {
  if (window['p$DE'][_[29226]] == _[29301]) return;var hfikgj = p$DE['p$BD'] + _[29302] + p$DE[_[25346]];wx[_[477]]({ 'url': hfikgj, 'method': _[29017], 'data': nijlkm, 'header': { 'content-type': _[29303], 'cache-control': _[29304] }, 'success': function (y$w_x) {
      DEBUG && console[_[482]](_[29305], hfikgj, nijlkm, y$w_x);
    }, 'fail': function (qvusrt) {
      DEBUG && console[_[482]](_[29305], hfikgj, nijlkm, qvusrt);
    }, 'complete': function () {} });
}, window[_[29306]] = function () {
  function njilkm() {
    return ((0x1 + Math[_[119]]()) * 0x10000 | 0x0)[_[275]](0x10)[_[500]](0x1);
  }return njilkm() + njilkm() + '-' + njilkm() + '-' + njilkm() + '-' + njilkm() + '+' + njilkm() + njilkm() + njilkm();
}, window['p$DB'] = function () {
  console[_[482]](_[29307]);var sqtrup = _dkpmlno[_[29308]]();p$DE[_[25345]] = sqtrup[_[29309]], p$DE[_[29272]] = sqtrup[_[29309]], p$DE[_[23752]] = sqtrup[_[29309]], p$DE[_[25347]] = sqtrup[_[29310]];var xwzvuy = { 'game_ver': p$DE[_[4740]] };p$DE[_[25349]] = this[_[29306]](), p$BDCE({ 'title': _[29311] }), _dkpmlno[_[368]](xwzvuy, this['p$EBD'][_[74]](this));
}, window['p$EBD'] = function (jkiln) {
  var yuzvx = jkiln[_[29312]];console[_[482]](_[29313] + yuzvx + _[29314] + (yuzvx == 0x1) + _[29315] + jkiln[_[29152]] + _[29316] + window[_[29253]][_[29259]]);if (!jkiln[_[29152]] || window['p$ACEBD'](window[_[29253]][_[29259]], jkiln[_[29152]]) < 0x0) console[_[482]](_[29317]), p$DE[_[29262]] = _[29318], p$DE[_[29264]] = _[29319], p$DE[_[29266]] = _[29320], p$DE[_[4546]] = _[29321], p$DE[_[25051]] = _[29322], p$DE[_[29323]] = _[29324], p$DE[_[738]] = ![];else window['p$ACEBD'](window[_[29253]][_[29259]], jkiln[_[29152]]) == 0x0 ? (console[_[482]](_[29325]), p$DE[_[29262]] = _[29263], p$DE[_[29264]] = _[29265], p$DE[_[29266]] = _[29267], p$DE[_[4546]] = _[29257], p$DE[_[25051]] = _[29322], p$DE[_[29323]] = _[29324], p$DE[_[738]] = !![]) : (console[_[482]](_[29326]), p$DE[_[29262]] = _[29263], p$DE[_[29264]] = _[29265], p$DE[_[29266]] = _[29267], p$DE[_[4546]] = _[29257], p$DE[_[25051]] = _[29322], p$DE[_[29323]] = _[29324], p$DE[_[738]] = ![]);p$DE[_[29270]] = config[_[28632]] ? config[_[28632]] : 0x0, this['p$CDBE'](), this['p$CDEB'](), window[_[29327]] = 0x5, p$BDCE({ 'title': _[29328] }), _dkpmlno[_[29040]](this['p$EDB'][_[74]](this));
}, window[_[29327]] = 0x5, window['p$EDB'] = function (sqrtuv, dbcfae) {
  if (sqrtuv == 0x0 && dbcfae && dbcfae[_[28725]]) {
    p$DE[_[29329]] = dbcfae[_[28725]];var pnqolm = this;p$BDCE({ 'title': _[29330] }), sendApi(p$DE[_[29262]], _[29331], { 'platform': p$DE[_[29260]], 'partner_id': p$DE[_[23752]], 'token': dbcfae[_[28725]], 'game_pkg': p$DE[_[25347]], 'deviceId': p$DE[_[25349]], 'scene': _[29332] + p$DE[_[29270]] }, this['p$CBDE'][_[74]](this), p$CED, p$EB);
  } else dbcfae && dbcfae[_[25535]] && window[_[29327]] > 0x0 && (dbcfae[_[25535]][_[115]](_[29333]) != -0x1 || dbcfae[_[25535]][_[115]](_[29334]) != -0x1 || dbcfae[_[25535]][_[115]](_[29335]) != -0x1 || dbcfae[_[25535]][_[115]](_[29336]) != -0x1 || dbcfae[_[25535]][_[115]](_[29337]) != -0x1 || dbcfae[_[25535]][_[115]](_[29338]) != -0x1) ? (window[_[29327]]--, _dkpmlno[_[29040]](this['p$EDB'][_[74]](this))) : (window['p$DEB'](_[29339], JSON[_[4532]]({ 'status': sqrtuv, 'data': dbcfae })), window['p$BCDE'](_[29340] + (dbcfae && dbcfae[_[25535]] ? '，' + dbcfae[_[25535]] : '')));
}, window['p$CBDE'] = function (qurtp) {
  if (!qurtp) {
    window['p$DEB'](_[29341], _[29342]), window['p$BCDE'](_[29343]);return;
  }if (qurtp[_[4141]] != _[9962]) {
    window['p$DEB'](_[29341], JSON[_[4532]](qurtp)), window['p$BCDE'](_[29344] + qurtp[_[4141]]);return;
  }p$DE[_[23751]] = String(qurtp[_[25346]]), p$DE[_[25346]] = String(qurtp[_[25346]]), p$DE[_[25318]] = String(qurtp[_[25318]]), p$DE[_[25345]] = String(qurtp[_[25318]]), p$DE[_[25348]] = String(qurtp[_[25348]]), p$DE[_[29345]] = String(qurtp[_[11535]]), p$DE[_[29346]] = String(qurtp[_[851]]), p$DE[_[11535]] = '';var rsuvw = this;p$BDCE({ 'title': _[29347] }), sendApi(p$DE[_[29262]], _[29348], { 'partner_id': p$DE[_[23752]], 'uid': p$DE[_[25346]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25347]], 'device': p$DE[_[25349]] }, rsuvw['p$CBED'][_[74]](rsuvw), p$CED, p$EB);
}, window['p$CBED'] = function (wy$zxv) {
  if (!wy$zxv) {
    window['p$BCDE'](_[29349]);return;
  }if (wy$zxv[_[4141]] != _[9962]) {
    window['p$BCDE'](_[29350] + wy$zxv[_[4141]]);return;
  }if (!wy$zxv[_[11]] || wy$zxv[_[11]][_[13]] == 0x0) {
    window['p$BCDE'](_[29351]);return;
  }p$DE[_[630]] = wy$zxv[_[29352]], p$DE[_[25341]] = { 'server_id': String(wy$zxv[_[11]][0x0][_[11552]]), 'server_name': String(wy$zxv[_[11]][0x0][_[29353]]), 'entry_ip': wy$zxv[_[11]][0x0][_[25369]], 'entry_port': parseInt(wy$zxv[_[11]][0x0][_[25370]]), 'status': p$DCB(wy$zxv[_[11]][0x0]), 'start_time': wy$zxv[_[11]][0x0][_[29354]], 'cdn': p$DE[_[4546]] }, this['p$EDCB']();
}, window['p$EDCB'] = function () {
  if (p$DE[_[630]] == 0x1) {
    var y_$10 = p$DE[_[25341]][_[106]];if (y_$10 === -0x1 || y_$10 === 0x0) {
      window['p$BCDE'](y_$10 === -0x1 ? _[29355] : _[29356]);return;
    }p$EBCD(0x0, p$DE[_[25341]][_[11552]]), window[_[29167]][_[148]][_[29357]](p$DE[_[630]]);
  } else window[_[29167]][_[148]][_[29358]](), p$BDEC();window['p$DC'] = !![], window['p$ECDB'](), window['p$EDBC']();
}, window['p$CDBE'] = function () {
  sendApi(p$DE[_[29262]], _[29359], { 'game_pkg': p$DE[_[25347]], 'version_name': p$DE[_[29323]] }, this[_[29360]][_[74]](this), p$CED, p$EB);
}, window[_[29360]] = function (degbc) {
  if (!degbc) {
    window['p$BCDE'](_[29361]);return;
  }if (degbc[_[4141]] != _[9962]) {
    window['p$BCDE'](_[29362] + degbc[_[4141]]);return;
  }if (!degbc[_[11]] || !degbc[_[11]][_[4740]]) {
    window['p$BCDE'](_[29363] + (degbc[_[11]] && degbc[_[11]][_[4740]]));return;
  }degbc[_[11]][_[29364]] && degbc[_[11]][_[29364]][_[13]] > 0xa && (p$DE[_[29365]] = degbc[_[11]][_[29364]], p$DE[_[4546]] = degbc[_[11]][_[29364]]), degbc[_[11]][_[4740]] && (p$DE[_[101]] = degbc[_[11]][_[4740]]), console[_[78]](_[25483] + p$DE[_[101]] + _[29366] + p$DE[_[29323]]), window['p$DEC'] = !![], window['p$ECDB'](), window['p$EDBC']();
}, window[_[29367]], window['p$CDEB'] = function () {
  sendApi(p$DE[_[29262]], _[29368], { 'game_pkg': p$DE[_[25347]] }, this['p$CEBD'][_[74]](this), p$CED, p$EB);
}, window['p$CEBD'] = function (jgfihk) {
  if (jgfihk[_[4141]] === _[9962] && jgfihk[_[11]]) {
    window[_[29367]] = jgfihk[_[11]];for (var uvwrs in jgfihk[_[11]]) {
      p$DE[uvwrs] = jgfihk[_[11]][uvwrs];
    }
  } else console[_[78]](_[29369] + jgfihk[_[4141]]);window['p$CD'] = !![], window['p$EDBC']();
}, window[_[29370]] = function (xz0y$_, gkhjli, $_z01y, svtqru, gihej, pnokl, ghefij, oqplm, jnlko) {
  gihej = String(gihej);var bafedc = ghefij,
      eigj = oqplm;p$DE[_[29258]][gihej] = { 'productid': gihej, 'productname': bafedc, 'productdesc': eigj, 'roleid': xz0y$_, 'rolename': gkhjli, 'rolelevel': $_z01y, 'price': pnokl, 'callback': jnlko }, sendApi(p$DE[_[29266]], _[29371], { 'game_pkg': p$DE[_[25347]], 'server_id': p$DE[_[25341]][_[11552]], 'server_name': p$DE[_[25341]][_[29353]], 'level': $_z01y, 'uid': p$DE[_[25346]], 'role_id': xz0y$_, 'role_name': gkhjli, 'product_id': gihej, 'product_name': bafedc, 'product_desc': eigj, 'money': pnokl, 'partner_id': p$DE[_[23752]] }, toPayCallBack, p$CED, p$EB);
}, window[_[29372]] = function (hkgli) {
  if (hkgli) {
    if (hkgli[_[29373]] === 0xc8 || hkgli[_[4141]] == _[9962]) {
      var x$wy = p$DE[_[29258]][String(hkgli[_[29374]])];if (x$wy[_[335]]) x$wy[_[335]](hkgli[_[29374]], hkgli[_[29375]], -0x1);_dkpmlno[_[29098]]({ 'cpbill': hkgli[_[29375]], 'productid': hkgli[_[29374]], 'productname': x$wy[_[29376]], 'productdesc': x$wy[_[29377]], 'serverid': p$DE[_[25341]][_[11552]], 'servername': p$DE[_[25341]][_[29353]], 'roleid': x$wy[_[29378]], 'rolename': x$wy[_[29379]], 'rolelevel': x$wy[_[29380]], 'price': x$wy[_[27051]], 'extension': JSON[_[4532]]({ 'cp_order_id': hkgli[_[29375]] }) }, function (_1z0, lknjom) {
        x$wy[_[335]] && _1z0 == 0x0 && x$wy[_[335]](hkgli[_[29374]], hkgli[_[29375]], _1z0);console[_[78]](JSON[_[4532]]({ 'type': _[29381], 'status': _1z0, 'data': hkgli, 'role_name': x$wy[_[29379]] }));if (_1z0 === 0x0) {} else {
          if (_1z0 === 0x1) {} else {
            if (_1z0 === 0x2) {}
          }
        }
      });
    } else alert(hkgli[_[78]]);
  }
}, window['p$CEDB'] = function () {}, window['p$BCE'] = function (lhigkj, mqp, vsxut, cgehf, w$xz) {
  _dkpmlno[_[29144]](p$DE[_[25341]][_[11552]], p$DE[_[25341]][_[29353]] || p$DE[_[25341]][_[11552]], lhigkj, mqp, vsxut), sendApi(p$DE[_[29262]], _[29382], { 'game_pkg': p$DE[_[25347]], 'server_id': p$DE[_[25341]][_[11552]], 'role_id': lhigkj, 'uid': p$DE[_[25346]], 'role_name': mqp, 'role_type': cgehf, 'level': vsxut });
}, window['p$BEC'] = function (zxv$y, komj, rstw, stpu, zy_$01, pqsrn, rtqosp, pnq, _40213, z02$_) {
  p$DE[_[29157]] = zxv$y, p$DE[_[4669]] = komj, p$DE[_[29158]] = rstw, _dkpmlno[_[29145]](p$DE[_[25341]][_[11552]], p$DE[_[25341]][_[29353]] || p$DE[_[25341]][_[11552]], zxv$y, komj, rstw), sendApi(p$DE[_[29262]], _[29383], { 'game_pkg': p$DE[_[25347]], 'server_id': p$DE[_[25341]][_[11552]], 'role_id': zxv$y, 'uid': p$DE[_[25346]], 'role_name': komj, 'role_type': stpu, 'level': rstw, 'evolution': zy_$01 });
}, window['p$CBE'] = function (trqsop, mkhil, cbgde, urwsvt, fhegd, fhjgi, yvx$z, zx_y, $zvyw, ihdf) {
  p$DE[_[29157]] = trqsop, p$DE[_[4669]] = mkhil, p$DE[_[29158]] = cbgde, _dkpmlno[_[29146]](p$DE[_[25341]][_[11552]], p$DE[_[25341]][_[29353]] || p$DE[_[25341]][_[11552]], trqsop, mkhil, cbgde), sendApi(p$DE[_[29262]], _[29383], { 'game_pkg': p$DE[_[25347]], 'server_id': p$DE[_[25341]][_[11552]], 'role_id': trqsop, 'uid': p$DE[_[25346]], 'role_name': mkhil, 'role_type': urwsvt, 'level': cbgde, 'evolution': fhegd });
}, window['p$CEB'] = function (vtwru) {}, window['p$BC'] = function (norqmp) {
  _dkpmlno[_[29077]](_[29077], function (jnmik) {
    norqmp && norqmp(jnmik);
  });
}, window[_[25031]] = function () {
  _dkpmlno[_[25031]]();
}, window[_[29384]] = function () {
  _dkpmlno[_[23644]]();
}, window[_[29385]] = function (higd, jikfh, _12304, nporm, gidfe, ikmh, lijmh, dgch) {
  dgch = dgch || p$DE[_[25341]][_[11552]], sendApi(p$DE[_[29262]], _[29386], { 'phone': higd, 'role_id': jikfh, 'uid': p$DE[_[25346]], 'game_pkg': p$DE[_[25347]], 'partner_id': p$DE[_[23752]], 'server_id': dgch }, lijmh);
}, window[_[10884]] = function (knopm) {
  window['p$EBC'] = knopm, window['p$EBC'] && window['p$CB'] && (console[_[78]](_[29245] + window['p$CB'][_[776]]), window['p$EBC'](window['p$CB']), window['p$CB'] = null);
}, window['p$ECB'] = function (fiejgh, imhj, uvxyz, nsqrop) {
  window[_[22]](_[29387], { 'game_pkg': window['p$DE'][_[25347]], 'role_id': imhj, 'server_id': uvxyz }, nsqrop);
}, window['p$DBCE'] = function (gcdfe, rnpsoq) {
  function uptqrs(mjhi) {
    var fgeij = [],
        zwuvyx = [],
        omplkn = window[_[557]][_[29388]];for (var jlhmk in omplkn) {
      var ghjkf = Number(jlhmk);(!gcdfe || !gcdfe[_[13]] || gcdfe[_[115]](ghjkf) != -0x1) && (zwuvyx[_[29]](omplkn[jlhmk]), fgeij[_[29]]([ghjkf, 0x3]));
    }window['p$ACEBD'](window[_[29168]], _[29389]) >= 0x0 ? (console[_[482]](_[29390]), _dkpmlno[_[29141]](zwuvyx, function (ehfgcd) {
      console[_[482]](_[29391]), console[_[482]](ehfgcd);if (ehfgcd && ehfgcd[_[25535]] == _[29392]) for (var uqtr in omplkn) {
        if (ehfgcd[omplkn[uqtr]] == _[29393]) {
          var z$_y0 = Number(uqtr);for (var wvsutx = 0x0; wvsutx < fgeij[_[13]]; wvsutx++) {
            if (fgeij[wvsutx][0x0] == z$_y0) {
              fgeij[wvsutx][0x1] = 0x1;break;
            }
          }
        }
      }window['p$ACEBD'](window[_[29168]], _[29394]) >= 0x0 ? wx[_[29395]]({ 'withSubscriptions': !![], 'success': function (xyzw_) {
          var idfh = xyzw_[_[29396]][_[29397]];if (idfh) {
            console[_[482]](_[29398]), console[_[482]](idfh);for (var yx$wz_ in omplkn) {
              if (idfh[omplkn[yx$wz_]] == _[29393]) {
                var spnqor = Number(yx$wz_);for (var nmlki = 0x0; nmlki < fgeij[_[13]]; nmlki++) {
                  if (fgeij[nmlki][0x0] == spnqor) {
                    fgeij[nmlki][0x1] = 0x2;break;
                  }
                }
              }
            }console[_[482]](fgeij), rnpsoq && rnpsoq(fgeij);
          } else console[_[482]](_[29399]), console[_[482]](xyzw_), console[_[482]](fgeij), rnpsoq && rnpsoq(fgeij);
        }, 'fail': function () {
          console[_[482]](_[29400]), console[_[482]](fgeij), rnpsoq && rnpsoq(fgeij);
        } }) : (console[_[482]](_[29401] + window[_[29168]]), console[_[482]](fgeij), rnpsoq && rnpsoq(fgeij));
    })) : (console[_[482]](_[29402] + window[_[29168]]), console[_[482]](fgeij), rnpsoq && rnpsoq(fgeij)), wx[_[29403]](uptqrs);
  }wx[_[29404]](uptqrs);
}, window['p$DBEC'] = { 'isSuccess': ![], 'level': _[29405], 'isCharging': ![] }, window['p$DCBE'] = function (_3021) {
  wx[_[29234]]({ 'success': function (eabcdf) {
      var qstuvr = window['p$DBEC'];qstuvr[_[29406]] = !![], qstuvr[_[4645]] = Number(eabcdf[_[4645]])[_[4256]](0x0), qstuvr[_[29237]] = eabcdf[_[29237]], _3021 && _3021(qstuvr[_[29406]], qstuvr[_[4645]], qstuvr[_[29237]]);
    }, 'fail': function (vx$wyz) {
      console[_[482]](_[29407], vx$wyz[_[25535]]);var onkpl = window['p$DBEC'];_3021 && _3021(onkpl[_[29406]], onkpl[_[4645]], onkpl[_[29237]]);
    } });
}, window[_[22]] = function (v$yz, egid, _wy$zx, xvswut, ikhjl, gebfdc, quvts, sptqor) {
  if (xvswut == undefined) xvswut = 0x1;wx[_[477]]({ 'url': v$yz, 'method': quvts || _[25237], 'responseType': _[4453], 'data': egid, 'header': { 'content-type': sptqor || _[29303] }, 'success': function (kgjlh) {
      DEBUG && console[_[482]](_[29408], v$yz, info, kgjlh);if (kgjlh && kgjlh[_[25600]] == 0xc8) {
        var eighj = kgjlh[_[11]];!gebfdc || gebfdc(eighj) ? _wy$zx && _wy$zx(eighj) : window[_[29409]](v$yz, egid, _wy$zx, xvswut, ikhjl, gebfdc, kgjlh);
      } else window[_[29409]](v$yz, egid, _wy$zx, xvswut, ikhjl, gebfdc, kgjlh);
    }, 'fail': function (lkhijg) {
      DEBUG && console[_[482]](_[29410], v$yz, info, lkhijg), window[_[29409]](v$yz, egid, _wy$zx, xvswut, ikhjl, gebfdc, lkhijg);
    }, 'complete': function () {} });
}, window[_[29409]] = function (prusqt, gikhjl, mproq, hijklm, igjfkh, qronm, afcd) {
  hijklm - 0x1 > 0x0 ? setTimeout(function () {
    window[_[22]](prusqt, gikhjl, mproq, hijklm - 0x1, igjfkh, qronm);
  }, 0x3e8) : igjfkh && igjfkh(JSON[_[4532]]({ 'url': prusqt, 'response': afcd }));
}, window[_[29411]] = function (gedhcf, wvuxts, wy$zx, higje, mqnpol, yzxvuw, qtsurv) {
  !wy$zx && (wy$zx = {});var lnqpom = Math[_[118]](Date[_[83]]() / 0x3e8);wy$zx[_[851]] = lnqpom, wy$zx[_[29412]] = wvuxts;var gfeijh = Object[_[267]](wy$zx)[_[1078]](),
      vxyut = '',
      kpl = '';for (var ywzvux = 0x0; ywzvux < gfeijh[_[13]]; ywzvux++) {
    vxyut = vxyut + (ywzvux == 0x0 ? '' : '&') + gfeijh[ywzvux] + wy$zx[gfeijh[ywzvux]], kpl = kpl + (ywzvux == 0x0 ? '' : '&') + gfeijh[ywzvux] + '=' + encodeURIComponent(wy$zx[gfeijh[ywzvux]]);
  }vxyut = vxyut + p$DE[_[29268]];var z20$ = _[29413] + md5(vxyut);send(gedhcf + '?' + kpl + (kpl == '' ? '' : '&') + z20$, null, higje, mqnpol, yzxvuw, qtsurv || function (mokj) {
    return mokj[_[4141]] == _[9962];
  }, null, _[29018]);
}, window['p$DCEB'] = function (qrno, pnok) {
  var rqpts = 0x0;p$DE[_[25341]] && (rqpts = p$DE[_[25341]][_[11552]]), sendApi(p$DE[_[29264]], _[29414], { 'partnerId': p$DE[_[23752]], 'gamePkg': p$DE[_[25347]], 'logTime': Math[_[118]](Date[_[83]]() / 0x3e8), 'platformUid': p$DE[_[25348]], 'type': qrno, 'serverId': rqpts }, null, 0x2, null, function () {
    return !![];
  });
}, window['p$DEBC'] = function (qruspt) {
  sendApi(p$DE[_[29262]], _[29415], { 'partner_id': p$DE[_[23752]], 'uid': p$DE[_[25346]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25347]], 'device': p$DE[_[25349]] }, p$DECB, p$CED, p$EB);
}, window['p$DECB'] = function (qpnrom) {
  if (qpnrom[_[4141]] === _[9962] && qpnrom[_[11]]) {
    qpnrom[_[11]][_[5623]]({ 'id': -0x2, 'name': _[29416] }), qpnrom[_[11]][_[5623]]({ 'id': -0x1, 'name': _[29417] }), p$DE[_[29418]] = qpnrom[_[11]];if (window[_[12346]]) window[_[12346]][_[29419]]();
  } else p$DE[_[29420]] = ![], window['p$BCDE'](_[29421] + qpnrom[_[4141]]);
}, window['p$BCD'] = function (y0x$_) {
  sendApi(p$DE[_[29262]], _[29422], { 'partner_id': p$DE[_[23752]], 'uid': p$DE[_[25346]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25347]], 'device': p$DE[_[25349]] }, p$BDC, p$CED, p$EB);
}, window['p$BDC'] = function (ecfba) {
  p$DE[_[29423]] = ![];if (ecfba[_[4141]] === _[9962] && ecfba[_[11]]) {
    for (var kihjlg = 0x0; kihjlg < ecfba[_[11]][_[13]]; kihjlg++) {
      ecfba[_[11]][kihjlg][_[106]] = p$DCB(ecfba[_[11]][kihjlg]);
    }p$DE[_[29271]][-0x1] = window[_[29424]](ecfba[_[11]]), window[_[12346]][_[29425]](-0x1);
  } else window['p$BCDE'](_[29426] + ecfba[_[4141]]);
}, window[_[29427]] = function (cedfa) {
  sendApi(p$DE[_[29262]], _[29422], { 'partner_id': p$DE[_[23752]], 'uid': p$DE[_[25346]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25347]], 'device': p$DE[_[25349]] }, cedfa, p$CED, p$EB);
}, window['p$CBD'] = function (jfigh, vtrus) {
  sendApi(p$DE[_[29262]], _[29428], { 'partner_id': p$DE[_[23752]], 'uid': p$DE[_[25346]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25347]], 'device': p$DE[_[25349]], 'server_group_id': vtrus }, p$CDB, p$CED, p$EB);
}, window['p$CDB'] = function (rnpso) {
  p$DE[_[29423]] = ![];if (rnpso[_[4141]] === _[9962] && rnpso[_[11]] && rnpso[_[11]][_[11]]) {
    var usvw = rnpso[_[11]][_[29429]],
        tvqr = [];for (var rqpot = 0x0; rqpot < rnpso[_[11]][_[11]][_[13]]; rqpot++) {
      rnpso[_[11]][_[11]][rqpot][_[106]] = p$DCB(rnpso[_[11]][_[11]][rqpot]), (tvqr[_[13]] == 0x0 || rnpso[_[11]][_[11]][rqpot][_[106]] != 0x0) && (tvqr[tvqr[_[13]]] = rnpso[_[11]][_[11]][rqpot]);
    }p$DE[_[29271]][usvw] = window[_[29424]](tvqr), window[_[12346]][_[29425]](usvw);
  } else window['p$BCDE'](_[29430] + rnpso[_[4141]]);
}, window['p$ACED'] = function (jknm) {
  sendApi(p$DE[_[29262]], _[29431], { 'partner_id': p$DE[_[23752]], 'uid': p$DE[_[25346]], 'version': p$DE[_[4740]], 'game_pkg': p$DE[_[25347]], 'device': p$DE[_[25349]] }, reqServerRecommendCallBack, p$CED, p$EB);
}, window[_[29432]] = function (dhfge) {
  p$DE[_[29423]] = ![];if (dhfge[_[4141]] === _[9962] && dhfge[_[11]]) {
    for (var njmli = 0x0; njmli < dhfge[_[11]][_[13]]; njmli++) {
      dhfge[_[11]][njmli][_[106]] = p$DCB(dhfge[_[11]][njmli]);
    }p$DE[_[29271]][-0x2] = window[_[29424]](dhfge[_[11]]), window[_[12346]][_[29425]](-0x2);
  } else alert(_[29433] + dhfge[_[4141]]);
}, window[_[29424]] = function (tvsuq) {
  if (!tvsuq && tvsuq[_[13]] <= 0x0) return tvsuq;for (let jklno = 0x0; jklno < tvsuq[_[13]]; jklno++) {
    tvsuq[jklno][_[29434]] && tvsuq[jklno][_[29434]] == 0x1 && (tvsuq[jklno][_[29353]] += _[29435]);
  }return tvsuq;
}, window['p$DBC'] = function (plomkn, prsqto) {
  plomkn = plomkn || p$DE[_[25341]][_[11552]], sendApi(p$DE[_[29262]], _[29436], { 'type': '4', 'game_pkg': p$DE[_[25347]], 'server_id': plomkn }, prsqto);
}, window[_[29437]] = function (xwutvs, nkmlj, fjgieh, iejfhg) {
  fjgieh = fjgieh || p$DE[_[25341]][_[11552]], sendApi(p$DE[_[29262]], _[29438], { 'type': xwutvs, 'game_pkg': nkmlj, 'server_id': fjgieh }, iejfhg);
}, window['p$DCB'] = function (ebcfg) {
  if (ebcfg) {
    if (ebcfg[_[106]] == 0x1) {
      if (ebcfg[_[29439]] == 0x1) return 0x2;else return 0x1;
    } else return ebcfg[_[106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['p$EBCD'] = function (nrps, qnrsp) {
  p$DE[_[29440]] = { 'step': nrps, 'server_id': qnrsp };var w$zyx_ = this;p$BDCE({ 'title': _[29441] }), sendApi(p$DE[_[29262]], _[29442], { 'partner_id': p$DE[_[23752]], 'uid': p$DE[_[25346]], 'game_pkg': p$DE[_[25347]], 'server_id': qnrsp, 'platform': p$DE[_[25318]], 'platform_uid': p$DE[_[25348]], 'check_login_time': p$DE[_[29346]], 'check_login_sign': p$DE[_[29345]], 'version_name': p$DE[_[29323]] }, p$EBDC, p$CED, p$EB, function (higk) {
    return higk[_[4141]] == _[9962] || higk[_[78]] == _[29443] || higk[_[78]] == _[29444];
  });
}, window['p$EBDC'] = function (egjfhi) {
  var onpl = this;if (egjfhi[_[4141]] === _[9962] && egjfhi[_[11]]) {
    var rnpoqs = p$DE[_[25341]];rnpoqs[_[29445]] = p$DE[_[29272]], rnpoqs[_[11535]] = String(egjfhi[_[11]][_[29446]]), rnpoqs[_[25320]] = parseInt(egjfhi[_[11]][_[851]]);if (egjfhi[_[11]][_[25319]]) rnpoqs[_[25319]] = parseInt(egjfhi[_[11]][_[25319]]);else rnpoqs[_[25319]] = parseInt(egjfhi[_[11]][_[11552]]);rnpoqs[_[29447]] = 0x0, rnpoqs[_[4546]] = p$DE[_[29365]], rnpoqs[_[29448]] = egjfhi[_[11]][_[29449]], rnpoqs[_[29450]] = egjfhi[_[11]][_[29450]], console[_[482]](_[29451] + JSON[_[4532]](rnpoqs[_[29450]])), p$DE[_[630]] == 0x1 && rnpoqs[_[29450]] && rnpoqs[_[29450]][_[29452]] == 0x1 && (p$DE[_[29453]] = 0x1, window[_[29167]][_[148]]['p$AED']()), p$ECBD();
  } else p$DE[_[29440]][_[7164]] >= 0x3 ? (p$EB(JSON[_[4532]](egjfhi)), window['p$BCDE'](_[29454] + egjfhi[_[4141]])) : sendApi(p$DE[_[29262]], _[29331], { 'platform': p$DE[_[29260]], 'partner_id': p$DE[_[23752]], 'token': p$DE[_[29329]], 'game_pkg': p$DE[_[25347]], 'deviceId': p$DE[_[25349]], 'scene': _[29332] + p$DE[_[29270]] }, function (hkijlg) {
    if (!hkijlg || hkijlg[_[4141]] != _[9962]) {
      window['p$BCDE'](_[29344] + hkijlg && hkijlg[_[4141]]);return;
    }p$DE[_[29345]] = String(hkijlg[_[11535]]), p$DE[_[29346]] = String(hkijlg[_[851]]), setTimeout(function () {
      p$EBCD(p$DE[_[29440]][_[7164]] + 0x1, p$DE[_[29440]][_[11552]]);
    }, 0x5dc);
  }, p$CED, p$EB, function (suqtrv) {
    return suqtrv[_[4141]] == _[9962] || suqtrv[_[4141]] == _[25678];
  });
}, window['p$ECBD'] = function () {
  ServerLoading[_[148]][_[29357]](p$DE[_[630]]), window['p$CE'] = !![], window['p$EDBC']();
}, window['p$ECDB'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[29278]] && window[_[29279]] && window['p$DEC'] && window['p$DC']) {
    if (!window[_[28615]][_[148]]) {
      console[_[482]](_[29455] + window[_[28615]][_[148]]);var mnljk = wx[_[29456]](),
          ghjie = mnljk[_[776]] ? mnljk[_[776]] : 0x0,
          begdfc = { 'cdn': window['p$DE'][_[4546]], 'spareCdn': window['p$DE'][_[25051]], 'newRegister': window['p$DE'][_[630]], 'wxPC': window['p$DE'][_[25054]], 'wxIOS': window['p$DE'][_[1074]], 'wxAndroid': window['p$DE'][_[11374]], 'wxParam': { 'limitLoad': window['p$DE']['p$ABCED'], 'benchmarkLevel': window['p$DE']['p$ABDCE'], 'wxFrom': window[_[557]][_[28632]] == _[29457] ? 0x1 : 0x0, 'wxSDKVersion': window[_[29168]] }, 'configType': window['p$DE'][_[11898]], 'exposeType': window['p$DE'][_[714]], 'scene': ghjie };new window[_[28615]](begdfc, window['p$DE'][_[101]], window['p$ABCDE']);
    }
  }
}, window['p$EDBC'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[29278]] && window[_[29279]] && window['p$DEC'] && window['p$DC'] && window['p$CE'] && window['p$CD']) {
    p$BDEC();if (!p$ECD) {
      p$ECD = !![];if (!window[_[28615]][_[148]]) window['p$ECDB']();var mnikj = 0x0,
          utwsx = wx[_[29458]]();utwsx && (window['p$DE'][_[29224]] && (mnikj = utwsx[_[323]]), console[_[78]](_[29459] + utwsx[_[323]] + _[29460] + utwsx[_[1216]] + _[29461] + utwsx[_[1218]] + _[29462] + utwsx[_[1217]] + _[29463] + utwsx[_[176]] + _[29464] + utwsx[_[177]]));var mropq = {};for (const nojmk in p$DE[_[25341]]) {
        mropq[nojmk] = p$DE[_[25341]][nojmk];
      }var bfedac = { 'channel': window['p$DE'][_[25345]], 'account': window['p$DE'][_[25346]], 'userId': window['p$DE'][_[23751]], 'cdn': window['p$DE'][_[4546]], 'data': window['p$DE'][_[11]], 'package': window['p$DE'][_[25052]], 'newRegister': window['p$DE'][_[630]], 'pkgName': window['p$DE'][_[25347]], 'partnerId': window['p$DE'][_[23752]], 'platform_uid': window['p$DE'][_[25348]], 'deviceId': window['p$DE'][_[25349]], 'selectedServer': mropq, 'configType': window['p$DE'][_[11898]], 'exposeType': window['p$DE'][_[714]], 'debugUsers': window['p$DE'][_[12296]], 'wxMenuTop': mnikj, 'wxShield': window['p$DE'][_[738]] };if (window[_[29367]]) for (var $123 in window[_[29367]]) {
        bfedac[$123] = window[_[29367]][$123];
      }window[_[28615]][_[148]]['p$EDA'](bfedac);
    }
  } else console[_[78]](_[29465] + window['p$EC'] + _[29466] + window['p$DCE'] + _[29467] + window[_[29278]] + _[29468] + window[_[29279]] + _[29469] + window['p$DEC'] + _[29470] + window['p$DC'] + _[29471] + window['p$CE'] + _[29472] + window['p$CD']);
};