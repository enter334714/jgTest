var _ = wx.y$;
import _dxw$v from '../bbbk/bbbsdk.js';window[_[27633]] = { 'wxVersion': window[_[547]][_[27533]] }, window[_[27634]] = ![], window['p$ED'] = 0x1, window[_[27635]] = 0x1, window['p$CDE'] = !![], window[_[27636]] = !![], window['p$ABCED'] = '', window['p$DE'] = { 'base_cdn': _[27637], 'cdn': _[27637] }, p$DE[_[27638]] = {}, p$DE[_[23701]] = '0', p$DE[_[4570]] = window[_[27633]][_[27639]], p$DE[_[27606]] = '', p$DE['os'] = '1', p$DE[_[27640]] = _[27641], p$DE[_[27642]] = _[27643], p$DE[_[27644]] = _[27645], p$DE[_[27646]] = _[27647], p$DE[_[27648]] = _[27649], p$DE[_[22813]] = '1', p$DE[_[24070]] = '', p$DE[_[24072]] = '', p$DE[_[27650]] = 0x0, p$DE[_[27651]] = {}, p$DE[_[27652]] = parseInt(p$DE[_[22813]]), p$DE[_[24068]] = p$DE[_[22813]], p$DE[_[24064]] = {}, p$DE['p$BD'] = _[27653], p$DE[_[27654]] = ![], p$DE[_[11615]] = _[27655], p$DE[_[24044]] = Date[_[83]](), p$DE[_[11211]] = _[27656], p$DE[_[700]] = '_a', p$DE[_[27657]] = 0x2, p$DE[_[101]] = 0x7c1, p$DE[_[27639]] = window[_[27633]][_[27639]], p$DE[_[725]] = ![], p$DE[_[501]] = ![], p$DE[_[10880]] = ![], p$DE[_[23703]] = ![], window['p$CED'] = 0x5, window['p$CE'] = ![], window['p$EC'] = ![], window['p$DCE'] = ![], window[_[27658]] = ![], window[_[27659]] = ![], window['p$DEC'] = ![], window['p$CD'] = ![], window['p$DC'] = ![], window['p$ECD'] = ![], window[_[4048]] = function (hgiklj) {
  console[_[471]](_[4048], hgiklj), wx[_[4845]]({}), wx[_[27557]]({ 'title': _[6237], 'content': hgiklj, 'success'(vsrtu) {
      if (vsrtu[_[27660]]) console[_[471]](_[27661]);else vsrtu[_[543]] && console[_[471]](_[27662]);
    } });
}, window['p$BCDE'] = function (nrqpom) {
  console[_[471]](_[27663], nrqpom), p$BDEC(), wx[_[27557]]({ 'title': _[6237], 'content': nrqpom, 'confirmText': _[27664], 'cancelText': _[17770], 'success'(okpmln) {
      if (okpmln[_[27660]]) window['p$DB']();else okpmln[_[543]] && (console[_[471]](_[27665]), wx[_[24214]]({}));
    } });
}, window['p$EAD'] = function (tspoqr) {
  console[_[471]](_[27666], tspoqr), wx[_[27557]]({ 'title': _[6237], 'content': tspoqr, 'confirmText': _[24186], 'showCancel': ![], 'complete'(opsrqt) {
      console[_[471]](_[27665]), wx[_[24214]]({});
    } });
}, window['p$BCED'] = ![], window['p$BDCE'] = function (zyxw) {
  window['p$BCED'] = !![], wx[_[4844]](zyxw);
}, window['p$BDEC'] = function () {
  window['p$BCED'] && (window['p$BCED'] = ![], wx[_[4845]]({}));
}, window['p$BECD'] = function (gebcf) {
  window[_[27548]][_[148]]['p$BECD'](gebcf);
}, window[_[11530]] = function (imkhl, mlknij) {
  _dxw$v[_[11530]](imkhl, function (ptroqs) {
    ptroqs && ptroqs[_[11]] ? ptroqs[_[11]][_[3985]] == 0x1 ? mlknij(!![]) : (mlknij(![]), console[_[78]](_[27667] + ptroqs[_[11]][_[27668]])) : console[_[471]](_[11530], ptroqs);
  });
}, window['p$BEDC'] = function (cgfe) {
  console[_[471]](_[27669], cgfe);
}, window['p$BDE'] = function (rqnos) {}, window['p$BED'] = function (fgdcb, ojlnkm, pqru) {}, window['p$BE'] = function (ijhkgf) {
  console[_[471]](_[27670], ijhkgf), window[_[27548]][_[148]][_[27671]](), window[_[27548]][_[148]][_[27672]](), window[_[27548]][_[148]][_[27673]]();
}, window['p$EB'] = function (feh) {
  console[_[471]](_[27674]), window['p$BCDE'](_[27674]), p$BD(feh ? feh : _[27675]);
}, window['p$DBE'] = function (rutpsq) {
  var wzvy$x = JSON[_[517]](rutpsq);wzvy$x[_[27676]] = window[_[547]][_[27533]], wzvy$x[_[27677]] = window['p$DE'][_[24064]] ? window['p$DE'][_[24064]][_[11051]] : 0x0, wzvy$x[_[27540]] = window[_[27540]];var bcafde = JSON[_[4367]](wzvy$x);console[_[125]](_[27678] + bcafde), p$BD(bcafde);
}, window['p$DEB'] = function (wrsvut) {
  var rtqpo = { 'id': window['p$DE'][_[27538]], 'role': window['p$DE'][_[4499]], 'level': window['p$DE'][_[27539]], 'user': window['p$DE'][_[24069]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4379]], 'pkgName': window['p$DE'][_[24070]], 'gamever': window[_[547]][_[27533]], 'serverid': window['p$DE'][_[24064]] ? window['p$DE'][_[24064]][_[11051]] : 0x0, 'systemInfo': window[_[27540]], 'error': wrsvut },
      $vwy = JSON[_[4367]](rtqpo);console[_[96]](_[27679] + $vwy), window['p$BD']($vwy);
}, window['p$BD'] = function (jfe) {
  if (window['p$DE'][_[27607]] == _[27680]) return;var ijhfe = p$DE['p$BD'] + _[27681] + p$DE[_[24069]];wx[_[466]]({ 'url': ijhfe, 'method': _[27408], 'data': jfe, 'header': { 'content-type': _[27682], 'cache-control': _[27683] }, 'success': function (vxwz$) {
      DEBUG && console[_[471]](_[27684], ijhfe, jfe, vxwz$);
    }, 'fail': function (ebadf) {
      DEBUG && console[_[471]](_[27684], ijhfe, jfe, ebadf);
    }, 'complete': function () {} });
}, window[_[27685]] = function () {
  function hjlkg() {
    return ((0x1 + Math[_[119]]()) * 0x10000 | 0x0)[_[272]](0x10)[_[489]](0x1);
  }return hjlkg() + hjlkg() + '-' + hjlkg() + '-' + hjlkg() + '-' + hjlkg() + '+' + hjlkg() + hjlkg() + hjlkg();
}, window['p$DB'] = function () {
  console[_[471]](_[27686]);var orpqsn = _dxw$v[_[27687]]();p$DE[_[24068]] = orpqsn[_[27688]], p$DE[_[27652]] = orpqsn[_[27688]], p$DE[_[22813]] = orpqsn[_[27688]], p$DE[_[24070]] = orpqsn[_[27689]];var qpsutr = { 'game_ver': p$DE[_[4570]] };p$DE[_[24072]] = this[_[27685]](), p$BDCE({ 'title': _[27690] }), _dxw$v[_[364]](qpsutr, this['p$EBD'][_[74]](this));
}, window['p$EBD'] = function (rtuqsv) {
  var $0_yx = rtuqsv[_[27691]];console[_[471]](_[27692] + $0_yx + _[27693] + ($0_yx == 0x1) + _[27694] + rtuqsv[_[27533]] + _[27695] + window[_[27633]][_[27639]]);if (!rtuqsv[_[27533]] || window['p$ACEDB'](window[_[27633]][_[27639]], rtuqsv[_[27533]]) < 0x0) console[_[471]](_[27696]), p$DE[_[27642]] = _[27697], p$DE[_[27644]] = _[27698], p$DE[_[27646]] = _[27699], p$DE[_[4379]] = _[27700], p$DE[_[23700]] = _[27701], p$DE[_[27702]] = _[27703], p$DE[_[725]] = ![];else window['p$ACEDB'](window[_[27633]][_[27639]], rtuqsv[_[27533]]) == 0x0 ? (console[_[471]](_[27704]), p$DE[_[27642]] = _[27643], p$DE[_[27644]] = _[27645], p$DE[_[27646]] = _[27647], p$DE[_[4379]] = _[27705], p$DE[_[23700]] = _[27701], p$DE[_[27702]] = _[27703], p$DE[_[725]] = !![]) : (console[_[471]](_[27706]), p$DE[_[27642]] = _[27643], p$DE[_[27644]] = _[27645], p$DE[_[27646]] = _[27647], p$DE[_[4379]] = _[27705], p$DE[_[23700]] = _[27701], p$DE[_[27702]] = _[27703], p$DE[_[725]] = ![]);p$DE[_[27650]] = config[_[27043]] ? config[_[27043]] : 0x0, this['p$CDBE'](), this['p$CDEB'](), p$BDCE({ 'title': _[27707] }), _dxw$v[_[27431]](this['p$EDB'][_[74]](this));
}, window['p$EDB'] = function (npl, vytx) {
  p$BDCE({ 'title': _[27708] });if (npl === 0x0 && vytx && vytx[_[27134]]) {
    p$DE[_[27709]] = vytx[_[27134]];var xwyvuz = this;sendApi(p$DE[_[27642]], _[27710], { 'platform': p$DE[_[27640]], 'partner_id': p$DE[_[22813]], 'token': vytx[_[27134]], 'game_pkg': p$DE[_[24070]], 'deviceId': p$DE[_[24072]], 'scene': _[27711] + p$DE[_[27650]] }, this['p$CBDE'][_[74]](this), p$CED, p$EB);
  } else p$BD(JSON[_[4367]]({ 'account': p$DE[_[24069]], 'pkgName': p$DE[_[24070]], 'error': _[27712], 'stack': JSON[_[4367]]({ 'status': npl, 'data': vytx }) })), window['p$BCDE'](_[27713] + (vytx && vytx[_[24235]] ? '，' + vytx[_[24235]] : ''));
}, window['p$CBDE'] = function (oqpmnl) {
  if (!oqpmnl) {
    window['p$BCDE'](_[27714]);return;
  }if (oqpmnl[_[3985]] != _[9575]) {
    window['p$BCDE'](_[27715] + oqpmnl[_[3985]]);return;
  }p$DE[_[22812]] = String(oqpmnl[_[24069]]), p$DE[_[24069]] = String(oqpmnl[_[24069]]), p$DE[_[24042]] = String(oqpmnl[_[24042]]), p$DE[_[24068]] = String(oqpmnl[_[24042]]), p$DE[_[24071]] = String(oqpmnl[_[24071]]), p$DE[_[27716]] = String(oqpmnl[_[11034]]), p$DE[_[27717]] = String(oqpmnl[_[838]]), p$DE[_[11034]] = '';var x$_yz = this;p$BDCE({ 'title': _[27718] }), sendApi(p$DE[_[27642]], _[27719], { 'partner_id': p$DE[_[22813]], 'uid': p$DE[_[24069]], 'version': p$DE[_[4570]], 'game_pkg': p$DE[_[24070]], 'device': p$DE[_[24072]] }, x$_yz['p$CBED'][_[74]](x$_yz), p$CED, p$EB);
}, window['p$CBED'] = function (ywvuz) {
  if (!ywvuz) {
    window['p$BCDE'](_[27720]);return;
  }if (ywvuz[_[3985]] != _[9575]) {
    window['p$BCDE'](_[27721] + ywvuz[_[3985]]);return;
  }if (!ywvuz[_[11]] || ywvuz[_[11]][_[13]] == 0x0) {
    window['p$BCDE'](_[27722]);return;
  }p$DE[_[618]] = ywvuz[_[27723]], p$DE[_[24064]] = { 'server_id': String(ywvuz[_[11]][0x0][_[11051]]), 'server_name': String(ywvuz[_[11]][0x0][_[27724]]), 'entry_ip': ywvuz[_[11]][0x0][_[24092]], 'entry_port': parseInt(ywvuz[_[11]][0x0][_[24093]]), 'status': p$EBCD(ywvuz[_[11]][0x0]), 'start_time': ywvuz[_[11]][0x0][_[27725]], 'cdn': p$DE[_[4379]] }, this['p$ABCDE']();
}, window['p$ABCDE'] = function () {
  if (p$DE[_[618]] == 0x1) {
    var yw$_xz = p$DE[_[24064]][_[106]];if (yw$_xz === -0x1 || yw$_xz === 0x0) {
      window['p$BCDE'](yw$_xz === -0x1 ? _[27726] : _[27727]);return;
    }p$EBDC(0x0, p$DE[_[24064]][_[11051]]), window[_[27548]][_[148]][_[27728]](p$DE[_[618]]);
  } else window[_[27548]][_[148]][_[27729]](), p$BDEC();window['p$DC'] = !![], window['p$EDBC'](), window['p$EDCB']();
}, window['p$CDBE'] = function () {
  var jehfi = this;sendApi(p$DE[_[27642]], _[27730], { 'game_pkg': p$DE[_[24070]], 'version_name': p$DE[_[27702]] }, function (edgcf) {
    if (!edgcf) {
      window['p$BCDE'](_[27731]);return;
    }if (edgcf[_[3985]] != _[9575]) {
      window['p$BCDE'](_[27732] + edgcf[_[3985]]);return;
    }if (!edgcf[_[11]] || !edgcf[_[11]][_[4570]]) {
      window['p$BCDE'](_[27733] + (edgcf[_[11]] && edgcf[_[11]][_[4570]]));return;
    }p$DE[_[27734]] = edgcf[_[11]][_[27735]] && edgcf[_[11]][_[27735]][_[13]] ? edgcf[_[11]][_[27735]] : p$DE[_[27734]], p$DE[_[4379]] = edgcf[_[11]][_[27735]] && edgcf[_[11]][_[27735]][_[13]] ? edgcf[_[11]][_[27735]] : p$DE[_[4379]], p$DE[_[101]] = edgcf[_[11]][_[4570]] || p$DE[_[101]], console[_[78]](_[24192] + p$DE[_[101]] + _[27736] + p$DE[_[27702]]), window['p$DEC'] = !![], window['p$EDBC'](), window['p$EDCB']();
  });
}, window[_[27737]], window['p$CDEB'] = function () {
  sendApi(p$DE[_[27642]], _[27738], { 'game_pkg': p$DE[_[24070]] }, p$CEBD);
}, window['p$CEBD'] = function ($z1_2) {
  if ($z1_2[_[3985]] === _[9575] && $z1_2[_[11]]) {
    window[_[27737]] = $z1_2[_[11]];for (var sqprt in $z1_2[_[11]]) {
      p$DE[sqprt] = $z1_2[_[11]][sqprt];
    }
  } else console[_[78]](_[27739] + $z1_2[_[3985]]);window['p$CD'] = !![], window['p$EDCB']();
}, window[_[27740]] = function (hkijgl, _120$3, qspron, tvrqsu, ihde, hfjk, fdcebg, lhkim, rnqopm) {
  ihde = String(ihde);var jikln = fdcebg,
      opnmqr = lhkim;p$DE[_[27638]][ihde] = { 'productid': ihde, 'productname': jikln, 'productdesc': opnmqr, 'roleid': hkijgl, 'rolename': _120$3, 'rolelevel': qspron, 'price': hfjk, 'callback': rnqopm }, sendApi(p$DE[_[27646]], _[27741], { 'game_pkg': p$DE[_[24070]], 'server_id': p$DE[_[24064]][_[11051]], 'server_name': p$DE[_[24064]][_[27724]], 'level': qspron, 'uid': p$DE[_[24069]], 'role_id': hkijgl, 'role_name': _120$3, 'product_id': ihde, 'product_name': jikln, 'product_desc': opnmqr, 'money': hfjk, 'partner_id': p$DE[_[22813]] }, toPayCallBack, p$CED, p$EB);
}, window[_[27742]] = function (fcbge) {
  if (fcbge) {
    if (fcbge[_[27743]] === 0xc8 || fcbge[_[3985]] == _[9575]) {
      var yxtw = p$DE[_[27638]][String(fcbge[_[27744]])];if (yxtw[_[332]]) yxtw[_[332]](fcbge[_[27744]], fcbge[_[27745]], -0x1);_dxw$v[_[27479]]({ 'cpbill': fcbge[_[27745]], 'productid': fcbge[_[27744]], 'productname': yxtw[_[27746]], 'productdesc': yxtw[_[27747]], 'serverid': p$DE[_[24064]][_[11051]], 'servername': p$DE[_[24064]][_[27724]], 'roleid': yxtw[_[27748]], 'rolename': yxtw[_[27749]], 'rolelevel': yxtw[_[27750]], 'price': yxtw[_[25582]], 'extension': JSON[_[4367]]({ 'cp_order_id': fcbge[_[27745]] }) }, function (cfbead, wzxuyv) {
        yxtw[_[332]] && cfbead == 0x0 && yxtw[_[332]](fcbge[_[27744]], fcbge[_[27745]], cfbead);console[_[78]](JSON[_[4367]]({ 'type': _[27751], 'status': cfbead, 'data': fcbge, 'role_name': yxtw[_[27749]] }));if (cfbead === 0x0) {} else {
          if (cfbead === 0x1) {} else {
            if (cfbead === 0x2) {}
          }
        }
      });
    } else alert(fcbge[_[78]]);
  }
}, window['p$CEDB'] = function () {}, window['p$BCE'] = function (wuvxs, hgefc, qsptru, ihjlkg, mlnkoj) {
  _dxw$v[_[27525]](p$DE[_[24064]][_[11051]], p$DE[_[24064]][_[27724]] || p$DE[_[24064]][_[11051]], wuvxs, hgefc, qsptru), sendApi(p$DE[_[27642]], _[27752], { 'game_pkg': p$DE[_[24070]], 'server_id': p$DE[_[24064]][_[11051]], 'role_id': wuvxs, 'uid': p$DE[_[24069]], 'role_name': hgefc, 'role_type': ihjlkg, 'level': qsptru });
}, window['p$BEC'] = function (_2z$, qsnrop, uvtxyw, fdcegb, y0z, igehdf, sruptq, egchd, _4012, tvuw) {
  p$DE[_[27538]] = _2z$, p$DE[_[4499]] = qsnrop, p$DE[_[27539]] = uvtxyw, _dxw$v[_[27526]](p$DE[_[24064]][_[11051]], p$DE[_[24064]][_[27724]] || p$DE[_[24064]][_[11051]], _2z$, qsnrop, uvtxyw), sendApi(p$DE[_[27642]], _[27753], { 'game_pkg': p$DE[_[24070]], 'server_id': p$DE[_[24064]][_[11051]], 'role_id': _2z$, 'uid': p$DE[_[24069]], 'role_name': qsnrop, 'role_type': fdcegb, 'level': uvtxyw, 'evolution': y0z });
}, window['p$CBE'] = function (zxy0$, njolkm, xwvu, okmj, yzvw$x, z_$2, lmijh, svwt, _10, xzuwy) {
  p$DE[_[27538]] = zxy0$, p$DE[_[4499]] = njolkm, p$DE[_[27539]] = xwvu;
}, window['p$CEB'] = function (gdheif) {}, window['p$BC'] = function (xvzwy) {
  _dxw$v[_[27458]](_[27458], function (_y0$1) {
    xvzwy(_y0$1);
  });
}, window[_[23685]] = function () {
  _dxw$v[_[23685]]();
}, window[_[27754]] = function () {
  _dxw$v[_[22719]]();
}, window['p$CB'] = function (_wy) {
  window['p$ECB'] = _wy, window['p$ECB'] && window['p$EBC'] && (console[_[78]](_[27627] + window['p$EBC'][_[763]]), window['p$ECB'](window['p$EBC']), window['p$EBC'] = null);
}, window['p$DBCE'] = function (fbdcea, lomnp, fbgced, ihjlk) {
  window[_[22]](_[27755], { 'game_pkg': window['p$DE'][_[24070]], 'role_id': lomnp, 'server_id': fbgced }, ihjlk);
}, window['p$DBEC'] = function (pln, $0_21) {
  function noqlpm(efgcb) {
    var npqoml = [],
        srqpn = [],
        mklon = window[_[547]][_[27756]];for (var febc in mklon) {
      var sqvrtu = Number(febc);(!pln || !pln[_[13]] || pln[_[115]](sqvrtu) != -0x1) && (srqpn[_[29]](mklon[febc]), npqoml[_[29]]([sqvrtu, 0x3]));
    }window['p$ACEDB'](window[_[27549]], _[27757]) >= 0x0 ? (console[_[471]](_[27758]), _dxw$v[_[27522]](srqpn, function (y$zxvw) {
      console[_[471]](_[27759]), console[_[471]](y$zxvw);if (y$zxvw && y$zxvw[_[24235]] == _[27760]) for (var tyux in mklon) {
        if (y$zxvw[mklon[tyux]] == _[27761]) {
          var gefid = Number(tyux);for (var fjieg = 0x0; fjieg < npqoml[_[13]]; fjieg++) {
            if (npqoml[fjieg][0x0] == gefid) {
              npqoml[fjieg][0x1] = 0x1;break;
            }
          }
        }
      }window['p$ACEDB'](window[_[27549]], _[27762]) >= 0x0 ? wx[_[27763]]({ 'withSubscriptions': !![], 'success': function (kjnlmi) {
          var vsuqt = kjnlmi[_[27764]][_[27765]];if (vsuqt) {
            console[_[471]](_[27766]), console[_[471]](vsuqt);for (var z0$y_1 in mklon) {
              if (vsuqt[mklon[z0$y_1]] == _[27761]) {
                var $_xz = Number(z0$y_1);for (var troqps = 0x0; troqps < npqoml[_[13]]; troqps++) {
                  if (npqoml[troqps][0x0] == $_xz) {
                    npqoml[troqps][0x1] = 0x2;break;
                  }
                }
              }
            }console[_[471]](npqoml), $0_21 && $0_21(npqoml);
          } else console[_[471]](_[27767]), console[_[471]](kjnlmi), console[_[471]](npqoml), $0_21 && $0_21(npqoml);
        }, 'fail': function () {
          console[_[471]](_[27768]), console[_[471]](npqoml), $0_21 && $0_21(npqoml);
        } }) : (console[_[471]](_[27769] + window[_[27549]]), console[_[471]](npqoml), $0_21 && $0_21(npqoml));
    })) : (console[_[471]](_[27770] + window[_[27549]]), console[_[471]](npqoml), $0_21 && $0_21(npqoml)), wx[_[27771]](noqlpm);
  }wx[_[27772]](noqlpm);
}, window['p$DCBE'] = { 'isSuccess': ![], 'level': _[27773], 'isCharging': ![] }, window['p$DCEB'] = function (gchfe) {
  wx[_[27615]]({ 'success': function (pqtors) {
      var jnkmil = window['p$DCBE'];jnkmil[_[27774]] = !![], jnkmil[_[4475]] = Number(pqtors[_[4475]])[_[4096]](0x0), jnkmil[_[27618]] = pqtors[_[27618]], gchfe && gchfe(jnkmil[_[27774]], jnkmil[_[4475]], jnkmil[_[27618]]);
    }, 'fail': function (xvyuzw) {
      console[_[471]](_[27775], xvyuzw[_[24235]]);var zy_w$x = window['p$DCBE'];gchfe && gchfe(zy_w$x[_[27774]], zy_w$x[_[4475]], zy_w$x[_[27618]]);
    } });
}, window[_[22]] = function (ormnp, onpkml, stqur, $xvyz, pnmr, jfihk, wvuxy, olknp) {
  $xvyz == undefined && ($xvyz = 0x1);var qmrpno = new XMLHttpRequest();qmrpno[_[24258]] = function () {
    if (qmrpno[_[62]] == 0x4) {
      if (qmrpno[_[106]] == 0xc8 || qmrpno[_[106]] == 0x12d) {
        var iehjgf = qmrpno[_[24259]];iehjgf = JSON[_[517]](qmrpno[_[24259]]);if (!jfihk || jfihk(iehjgf, qmrpno, ormnp)) {
          stqur && stqur(iehjgf);return;
        } else console[_[78]](ormnp), console[_[125]](iehjgf);
      }$xvyz - 0x1 > 0x0 ? setTimeout(function () {
        send(ormnp, onpkml, stqur, $xvyz - 0x1, pnmr, jfihk);
      }, 0x3e8) : pnmr && pnmr(JSON[_[4367]]({ 'account': p$DE[_[24069]], 'pkgName': p$DE[_[24070]], 'error': _[27776], 'stack': JSON[_[4367]]({ 'url': ormnp, 'status': qmrpno[_[106]], 'response': qmrpno[_[24259]], 'responseType': qmrpno[_[24263]] }) }));
    }
  }, qmrpno[_[65]](wvuxy || _[23904], ormnp), qmrpno[_[24263]] = _[4294], qmrpno[_[27777]](_[27778], olknp || _[27682]), qmrpno[_[22]](onpkml);
}, window[_[27779]] = function (efjhg, oqpsrn, glkijh, feacb, ikmj, xtsu, jmkil) {
  !glkijh && (glkijh = {});var x0$y = Math[_[118]](Date[_[83]]() / 0x3e8);glkijh[_[838]] = x0$y, glkijh[_[23823]] = oqpsrn;var nmjol = Object[_[264]](glkijh)[_[1066]](),
      xywtvu = '',
      y$z_xw = '';for (var vx$yz = 0x0; vx$yz < nmjol[_[13]]; vx$yz++) {
    xywtvu = xywtvu + (vx$yz == 0x0 ? '' : '&') + nmjol[vx$yz] + glkijh[nmjol[vx$yz]], y$z_xw = y$z_xw + (vx$yz == 0x0 ? '' : '&') + nmjol[vx$yz] + '=' + encodeURIComponent(glkijh[nmjol[vx$yz]]);
  }xywtvu = xywtvu + p$DE[_[27648]];var _03421 = _[27780] + md5(xywtvu);send(efjhg + '?' + y$z_xw + (y$z_xw == '' ? '' : '&') + _03421, null, feacb, ikmj, xtsu, jmkil || function (uvwy) {
    return uvwy[_[3985]] == _[9575];
  }, null, _[27409]);
}, window['p$DEBC'] = function (_$xyzw, ghdf) {
  var $yzxvw = 0x0;p$DE[_[24064]] && ($yzxvw = p$DE[_[24064]][_[11051]]), sendApi(p$DE[_[27644]], _[27781], { 'partnerId': p$DE[_[22813]], 'gamePkg': p$DE[_[24070]], 'logTime': Math[_[118]](Date[_[83]]() / 0x3e8), 'platformUid': p$DE[_[24071]], 'type': _$xyzw, 'serverId': $yzxvw }, null, 0x2, null, function () {
    return !![];
  });
}, window['p$DECB'] = function (acfbe) {
  sendApi(p$DE[_[27642]], _[27782], { 'partner_id': p$DE[_[22813]], 'uid': p$DE[_[24069]], 'version': p$DE[_[4570]], 'game_pkg': p$DE[_[24070]], 'device': p$DE[_[24072]] }, p$BCD, p$CED, p$EB);
}, window['p$BCD'] = function (kilgjh) {
  if (kilgjh[_[3985]] === _[9575] && kilgjh[_[11]]) {
    kilgjh[_[11]][_[5445]]({ 'id': -0x2, 'name': _[27783] }), kilgjh[_[11]][_[5445]]({ 'id': -0x1, 'name': _[27784] }), p$DE[_[27785]] = kilgjh[_[11]];if (window[_[11664]]) window[_[11664]][_[27786]]();
  } else p$DE[_[27787]] = ![], window['p$BCDE'](_[27788] + kilgjh[_[3985]]);
}, window['p$BDC'] = function (psnoq) {
  sendApi(p$DE[_[27642]], _[27789], { 'partner_id': p$DE[_[22813]], 'uid': p$DE[_[24069]], 'version': p$DE[_[4570]], 'game_pkg': p$DE[_[24070]], 'device': p$DE[_[24072]] }, p$CBD, p$CED, p$EB);
}, window['p$CBD'] = function (z_y$01) {
  p$DE[_[27790]] = ![];if (z_y$01[_[3985]] === _[9575] && z_y$01[_[11]]) {
    for (var sutxv = 0x0; sutxv < z_y$01[_[11]][_[13]]; sutxv++) {
      z_y$01[_[11]][sutxv][_[106]] = p$EBCD(z_y$01[_[11]][sutxv]);
    }p$DE[_[27651]][-0x1] = window[_[27791]](z_y$01[_[11]]), window[_[11664]][_[27792]](-0x1);
  } else window['p$BCDE'](_[27793] + z_y$01[_[3985]]);
}, window['p$CDB'] = function (yvz$w, ijklgh) {
  sendApi(p$DE[_[27642]], _[27794], { 'partner_id': p$DE[_[22813]], 'uid': p$DE[_[24069]], 'version': p$DE[_[4570]], 'game_pkg': p$DE[_[24070]], 'device': p$DE[_[24072]], 'server_group_id': ijklgh }, p$DBC, p$CED, p$EB);
}, window['p$DBC'] = function (mkol) {
  p$DE[_[27790]] = ![];if (mkol[_[3985]] === _[9575] && mkol[_[11]] && mkol[_[11]][_[11]]) {
    var xuwtv = mkol[_[11]][_[27795]],
        ighedf = [];for (var oqprst = 0x0; oqprst < mkol[_[11]][_[11]][_[13]]; oqprst++) {
      mkol[_[11]][_[11]][oqprst][_[106]] = p$EBCD(mkol[_[11]][_[11]][oqprst]), (ighedf[_[13]] == 0x0 || mkol[_[11]][_[11]][oqprst][_[106]] != 0x0) && (ighedf[ighedf[_[13]]] = mkol[_[11]][_[11]][oqprst]);
    }p$DE[_[27651]][xuwtv] = window[_[27791]](ighedf), window[_[11664]][_[27792]](xuwtv);
  } else window['p$BCDE'](_[27796] + mkol[_[3985]]);
}, window['p$ADCE'] = function (nrom) {
  sendApi(p$DE[_[27642]], _[27797], { 'partner_id': p$DE[_[22813]], 'uid': p$DE[_[24069]], 'version': p$DE[_[4570]], 'game_pkg': p$DE[_[24070]], 'device': p$DE[_[24072]] }, reqServerRecommendCallBack, p$CED, p$EB);
}, window[_[27798]] = function (jhlgk) {
  p$DE[_[27790]] = ![];if (jhlgk[_[3985]] === _[9575] && jhlgk[_[11]]) {
    for (var fcgbde = 0x0; fcgbde < jhlgk[_[11]][_[13]]; fcgbde++) {
      jhlgk[_[11]][fcgbde][_[106]] = p$EBCD(jhlgk[_[11]][fcgbde]);
    }p$DE[_[27651]][-0x2] = window[_[27791]](jhlgk[_[11]]), window[_[11664]][_[27792]](-0x2);
  } else alert(_[27799] + jhlgk[_[3985]]);
}, window[_[27791]] = function (ljhimk) {
  if (!ljhimk && ljhimk[_[13]] <= 0x0) return ljhimk;for (let wutx = 0x0; wutx < ljhimk[_[13]]; wutx++) {
    ljhimk[wutx][_[27800]] && ljhimk[wutx][_[27800]] == 0x1 && (ljhimk[wutx][_[27724]] += _[27801]);
  }return ljhimk;
}, window['p$DCB'] = function (wuvtrs, ruvts) {
  wuvtrs = wuvtrs || p$DE[_[24064]][_[11051]], sendApi(p$DE[_[27642]], _[27802], { 'type': '4', 'game_pkg': p$DE[_[24070]], 'server_id': wuvtrs }, ruvts);
}, window[_[27803]] = function (ihkjgf, lnqmo, rstop, fbecda) {
  rstop = rstop || p$DE[_[24064]][_[11051]], sendApi(p$DE[_[27642]], _[27804], { 'type': ihkjgf, 'game_pkg': lnqmo, 'server_id': rstop }, fbecda);
}, window['p$EBCD'] = function (jgihfk) {
  if (jgihfk) {
    if (jgihfk[_[106]] == 0x1) {
      if (jgihfk[_[27805]] == 0x1) return 0x2;else return 0x1;
    } else return jgihfk[_[106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['p$EBDC'] = function (gbcf, hkjigf) {
  p$DE[_[27806]] = { 'step': gbcf, 'server_id': hkjigf };var afeb = this;p$BDCE({ 'title': _[27807] }), sendApi(p$DE[_[27642]], _[27808], { 'partner_id': p$DE[_[22813]], 'uid': p$DE[_[24069]], 'game_pkg': p$DE[_[24070]], 'server_id': hkjigf, 'platform': p$DE[_[24042]], 'platform_uid': p$DE[_[24071]], 'check_login_time': p$DE[_[27717]], 'check_login_sign': p$DE[_[27716]], 'version_name': p$DE[_[27702]] }, p$ECBD, p$CED, p$EB, function (y$01z) {
    return y$01z[_[3985]] == _[9575] || y$01z[_[78]] == _[27809] || y$01z[_[78]] == _[27810];
  });
}, window['p$ECBD'] = function (lmop) {
  var z0$1y = this;if (lmop[_[3985]] === _[9575] && lmop[_[11]]) {
    var nsor = p$DE[_[24064]];nsor[_[27811]] = p$DE[_[27652]], nsor[_[11034]] = String(lmop[_[11]][_[27812]]), nsor[_[24044]] = parseInt(lmop[_[11]][_[838]]);if (lmop[_[11]][_[24043]]) nsor[_[24043]] = parseInt(lmop[_[11]][_[24043]]);else nsor[_[24043]] = parseInt(lmop[_[11]][_[11051]]);nsor[_[27813]] = 0x0, nsor[_[4379]] = p$DE[_[27734]], nsor[_[27814]] = lmop[_[11]][_[27815]], nsor[_[27816]] = lmop[_[11]][_[27816]], console[_[471]](_[27817] + JSON[_[4367]](nsor[_[27816]])), p$DE[_[618]] == 0x1 && nsor[_[27816]] && nsor[_[27816]][_[27818]] == 0x1 && (p$DE[_[27819]] = 0x1, window[_[27548]][_[148]]['p$AE']()), p$ECDB();
  } else sendApi(p$DE[_[27642]], _[27710], { 'platform': p$DE[_[27640]], 'partner_id': p$DE[_[22813]], 'token': p$DE[_[27709]], 'game_pkg': p$DE[_[24070]], 'deviceId': p$DE[_[24072]], 'scene': _[27711] + p$DE[_[27650]] }, function (ojnklm) {
    if (ojnklm[_[3985]] == _[24292]) {
      window['p$BCDE'](_[27715] + ojnklm[_[3985]]);return;
    }p$DE[_[27716]] = String(ojnklm[_[11034]]), p$DE[_[27717]] = String(ojnklm[_[838]]), setTimeout(function () {
      p$EBDC(p$DE[_[27806]][_[6924]], p$DE[_[27806]][_[11051]]);
    }, 0x5dc);
  }, p$CED, p$EB, function (omjkln) {
    return omjkln[_[3985]] == _[9575] || omjkln[_[3985]] == _[24292];
  });
}, window['p$ECDB'] = function () {
  ServerLoading[_[148]][_[27728]](p$DE[_[618]]), window['p$CE'] = !![], window['p$EDCB']();
}, window['p$EDBC'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[27658]] && window[_[27659]] && window['p$DEC'] && window['p$DC']) {
    if (!window[_[27026]][_[148]]) {
      console[_[471]](_[27820] + window[_[27026]][_[148]]);var opnsq = wx[_[27821]](),
          rnosq = opnsq[_[763]] ? opnsq[_[763]] : 0x0,
          rpos = { 'cdn': window['p$DE'][_[4379]], 'spareCdn': window['p$DE'][_[23700]], 'newRegister': window['p$DE'][_[618]], 'wxPC': window['p$DE'][_[23703]], 'wxIOS': window['p$DE'][_[501]], 'wxAndroid': window['p$DE'][_[10880]], 'wxParam': { 'limitLoad': window['p$DE']['p$ABDCE'], 'benchmarkLevel': window['p$DE']['p$ABDEC'], 'wxFrom': window[_[547]][_[27043]] == _[27822] ? 0x1 : 0x0, 'wxSDKVersion': window[_[27549]] }, 'configType': window['p$DE'][_[11211]], 'exposeType': window['p$DE'][_[700]], 'scene': rnosq };new window[_[27026]](rpos, window['p$DE'][_[101]], window['p$ABCED']);
    }
  }
}, window['p$EDCB'] = function () {
  if (window['p$EC'] && window['p$DCE'] && window[_[27658]] && window[_[27659]] && window['p$DEC'] && window['p$DC'] && window['p$CE'] && window['p$CD']) {
    p$BDEC();if (!p$ECD) {
      p$ECD = !![];if (!window[_[27026]][_[148]]) window['p$EDBC']();var fbgcde = 0x0,
          hkjfi = wx[_[27823]]();hkjfi && (window['p$DE'][_[27605]] && (fbgcde = hkjfi[_[320]]), console[_[78]](_[27824] + hkjfi[_[320]] + _[27825] + hkjfi[_[1200]] + _[27826] + hkjfi[_[1202]] + _[27827] + hkjfi[_[1201]] + _[27828] + hkjfi[_[176]] + _[27829] + hkjfi[_[177]]));var mkjl = {};for (const qprtos in p$DE[_[24064]]) {
        mkjl[qprtos] = p$DE[_[24064]][qprtos];
      }var ehdigf = { 'channel': window['p$DE'][_[24068]], 'account': window['p$DE'][_[24069]], 'userId': window['p$DE'][_[22812]], 'serverId': mkjl[_[11051]], 'cdn': window['p$DE'][_[4379]], 'data': window['p$DE'][_[11]], 'package': window['p$DE'][_[23701]], 'newRegister': window['p$DE'][_[618]], 'pkgName': window['p$DE'][_[24070]], 'partnerId': window['p$DE'][_[22813]], 'platform_uid': window['p$DE'][_[24071]], 'deviceId': window['p$DE'][_[24072]], 'selectedServer': mkjl, 'configType': window['p$DE'][_[11211]], 'exposeType': window['p$DE'][_[700]], 'debugUsers': window['p$DE'][_[11615]], 'wxMenuTop': fbgcde, 'wxShield': window['p$DE'][_[725]] };if (window[_[27737]]) for (var nqpso in window[_[27737]]) {
        ehdigf[nqpso] = window[_[27737]][nqpso];
      }window[_[27026]][_[148]]['p$CAED'](ehdigf);
    }
  } else console[_[78]](_[27830] + window['p$EC'] + _[27831] + window['p$DCE'] + _[27832] + window[_[27658]] + _[27833] + window[_[27659]] + _[27834] + window['p$DEC'] + _[27835] + window['p$DC'] + _[27836] + window['p$CE'] + _[27837] + window['p$CD']);
};