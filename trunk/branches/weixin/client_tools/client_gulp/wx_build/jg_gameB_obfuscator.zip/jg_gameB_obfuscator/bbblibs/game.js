var _ = wx.y$;
require(_[31027]);