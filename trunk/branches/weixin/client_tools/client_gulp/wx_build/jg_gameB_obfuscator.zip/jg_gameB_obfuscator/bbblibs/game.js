var _ = wx.y$;
require(_[28005]);