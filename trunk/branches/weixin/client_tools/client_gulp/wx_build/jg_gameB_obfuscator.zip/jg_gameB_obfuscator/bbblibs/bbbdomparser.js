var _ = wx.y$;
function _dtuwsx(w_zyx$) {
  this['options'] = w_zyx$ || { 'locator': {} };
}function _dkmlj($vyzw, trqso, tqrpos) {
  function nopmlk(nprqm) {
    var twurs = $vyzw[nprqm];!twurs && fehgj && (twurs = 0x2 == $vyzw['length'] ? function (eghi) {
      $vyzw(nprqm, eghi);
    } : $vyzw), jhgfi[nprqm] = twurs && function (rpm) {
      twurs('[xmldom ' + nprqm + ']\t' + rpm + _ddfeb(tqrpos));
    } || function () {};
  }if (!$vyzw) {
    if (trqso instanceof _diknj) return trqso;$vyzw = trqso;
  }var jhgfi = {},
      fehgj = $vyzw instanceof Function;return tqrpos = tqrpos || {}, nopmlk('warning'), nopmlk('error'), nopmlk('fatalError'), jhgfi;
}function _diknj() {
  this['cdata'] = !0x1;
}function _dcgfeh(zxwv$, tuvwr) {
  tuvwr['lineNumber'] = zxwv$['lineNumber'], tuvwr['columnNumber'] = zxwv$['columnNumber'];
}function _ddfeb(vtusqr) {
  return vtusqr ? '\x0a@' + (vtusqr['systemId'] || '') + '#[line:' + vtusqr['lineNumber'] + ',col:' + vtusqr['columnNumber'] + ']' : void 0x0;
}function _dsnorqp(jeihg, x0_yz$, cfgbe) {
  return 'string' == typeof jeihg ? jeihg['substr'](x0_yz$, cfgbe) : jeihg['length'] >= x0_yz$ + cfgbe || x0_yz$ ? new java['lang']['String'](jeihg, x0_yz$, cfgbe) + '' : jeihg;
}function _dfhdgec($wyvz, pqronm) {
  $wyvz['currentElement'] ? $wyvz['currentElement']['appendChild'](pqronm) : $wyvz['doc']['appendChild'](pqronm);
}_dtuwsx['prototype']['parseFromString'] = function ($3_021, yxvuz) {
  var z0_1 = this['options'],
      ecfbad = new _dvzywux(),
      jihfge = z0_1['domBuilder'] || new _diknj(),
      zy1$0_ = z0_1['errorHandler'],
      efdh = z0_1['locator'],
      rqtups = z0_1['xmlns'] || {},
      molj = { 'lt': '<', 'gt': '>', 'amp': '&', 'quot': '\x22', 'apos': '\x27' };return efdh && jihfge['setDocumentLocator'](efdh), ecfbad['errorHandler'] = _dkmlj(zy1$0_, jihfge, efdh), ecfbad['domBuilder'] = z0_1['domBuilder'] || jihfge, /\/x?html?$/['test'](yxvuz) && (molj['nbsp'] = '\u00a0', molj['copy'] = '©', rqtups[''] = 'http://www.w3.org/1999/xhtml'), rqtups['xml'] = rqtups['xml'] || 'http://www.w3.org/XML/1998/namespace', $3_021 ? ecfbad['parse']($3_021, rqtups, molj) : ecfbad['errorHandler']['error']('invalid doc source'), jihfge['doc'];
}, _diknj['prototype'] = { 'startDocument': function () {
    this['doc'] = new _dcdgehf()['createDocument'](null, null, null), this['locator'] && (this['doc']['documentURI'] = this['locator']['systemId']);
  }, 'startElement': function (vuwrt, rtuqp, lgikhj, xsvuw) {
    var ijfh = this['doc'],
        mnlik = ijfh['createElementNS'](vuwrt, lgikhj || rtuqp),
        ikhjgl = xsvuw['length'];_dfhdgec(this, mnlik), this['currentElement'] = mnlik, this['locator'] && _dcgfeh(this['locator'], mnlik);for (var xy_$z0 = 0x0; ikhjgl > xy_$z0; xy_$z0++) {
      var vuwrt = xsvuw['getURI'](xy_$z0),
          fgjihe = xsvuw['getValue'](xy_$z0),
          lgikhj = xsvuw['getQName'](xy_$z0),
          _$wyx = ijfh['createAttributeNS'](vuwrt, lgikhj);this['locator'] && _dcgfeh(xsvuw['getLocator'](xy_$z0), _$wyx), _$wyx['value'] = _$wyx['nodeValue'] = fgjihe, mnlik['setAttributeNode'](_$wyx);
    }
  }, 'endElement': function () {
    {
      var y0z$_ = this['currentElement'];y0z$_['tagName'];
    }this['currentElement'] = y0z$_['parentNode'];
  }, 'startPrefixMapping': function () {}, 'endPrefixMapping': function () {}, 'processingInstruction': function (ghilkj, xywz$v) {
    var fkhgij = this['doc']['createProcessingInstruction'](ghilkj, xywz$v);this['locator'] && _dcgfeh(this['locator'], fkhgij), _dfhdgec(this, fkhgij);
  }, 'ignorableWhitespace': function () {}, 'characters': function (rtsvqu) {
    if (rtsvqu = _dsnorqp['apply'](this, arguments)) {
      if (this['cdata']) var qmlpon = this['doc']['createCDATASection'](rtsvqu);else var qmlpon = this['doc']['createTextNode'](rtsvqu);this['currentElement'] ? this['currentElement']['appendChild'](qmlpon) : /^\s*$/['test'](rtsvqu) && this['doc']['appendChild'](qmlpon), this['locator'] && _dcgfeh(this['locator'], qmlpon);
    }
  }, 'skippedEntity': function () {}, 'endDocument': function () {
    this['doc']['normalize']();
  }, 'setDocumentLocator': function (moknlp) {
    (this['locator'] = moknlp) && (moknlp['lineNumber'] = 0x0);
  }, 'comment': function (lkjonm) {
    lkjonm = _dsnorqp['apply'](this, arguments);var tqpsur = this['doc']['createComment'](lkjonm);this['locator'] && _dcgfeh(this['locator'], tqpsur), _dfhdgec(this, tqpsur);
  }, 'startCDATA': function () {
    this['cdata'] = !0x0;
  }, 'endCDATA': function () {
    this['cdata'] = !0x1;
  }, 'startDTD': function (ghcfde, rtqup, tqrp) {
    var yxwvut = this['doc']['implementation'];if (yxwvut && yxwvut['createDocumentType']) {
      var mpnroq = yxwvut['createDocumentType'](ghcfde, rtqup, tqrp);this['locator'] && _dcgfeh(this['locator'], mpnroq), _dfhdgec(this, mpnroq);
    }
  }, 'warning': function (qsn) {
    console['warn']('[xmldom warning]\t' + qsn, _ddfeb(this['locator']));
  }, 'error': function (_1zy$0) {
    console['error']('[xmldom error]\t' + _1zy$0, _ddfeb(this['locator']));
  }, 'fatalError': function (_w$yxz) {
    throw console['error']('[xmldom fatalError]\t' + _w$yxz, _ddfeb(this['locator'])), _w$yxz;
  } }, 'endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl'['replace'](/\w+/g, function (rtpsqu) {
  _diknj['prototype'][rtpsqu] = function () {
    return null;
  };
});var _dvzywux = require('./bbbsax')['XMLReader'],
    _dcdgehf = exports['DOMImplementation'] = require('./bbbdom')['DOMImplementation'];exports['XMLSerializer'] = require('./bbbdom')['XMLSerializer'], exports['DOMParser'] = _dtuwsx;