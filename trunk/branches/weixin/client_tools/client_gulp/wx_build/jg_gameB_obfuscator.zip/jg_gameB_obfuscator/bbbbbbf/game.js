var _ = wx.y$;
require('bbbbBuff.js'), window[_[28741]][_[28731]][_[28619]] = null, window['client_pb'] = require('bbbcleintpb.js'), window[_[25487]] = window[_[28741]][_[25375]][_[25376]](client_pb);