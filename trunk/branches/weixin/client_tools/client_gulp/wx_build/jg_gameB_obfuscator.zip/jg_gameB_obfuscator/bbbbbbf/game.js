var _ = wx.y$;
require('bbbbBuff.js'), window[_[27150]][_[27140]][_[27030]] = null, window['client_pb'] = require('bbbcleintpb.js'), window[_[24196]] = window[_[27150]][_[24098]][_[24099]](client_pb);