var _ = wx.y$;
require('bbbbBuff.js'), window[_[224]][_[210]][_[12]] = null, window['client_pb'] = require('bbbcleintpb.js'), window[_[532]] = window[_[224]][_[152]][_[53]](client_pb);