var _ = wx.y$;
function _dmjin() {}function _duxvws(kpnlom, nsrqp, qoprmn, plnkom, npoklm) {
  function ecdfgb(fkhig) {
    if (fkhig > 0xffff) {
      fkhig -= 0x10000;var vuwrt = 0xd800 + (fkhig >> 0xa),
          ojkml = 0xdc00 + (0x3ff & fkhig);return String['fromCharCode'](vuwrt, ojkml);
    }return String['fromCharCode'](fkhig);
  }function kjilm(oprsnq) {
    var fkjigh = oprsnq['slice'](0x1, -0x1);return fkjigh in qoprmn ? qoprmn[fkjigh] : '#' === fkjigh['charAt'](0x0) ? ecdfgb(parseInt(fkjigh['substr'](0x1)['replace']('x', '0x'))) : (npoklm['error']('entity not found:' + oprsnq), oprsnq);
  }function qlopn(hilgjk) {
    if (hilgjk > ljigk) {
      var z_0 = kpnlom['substring'](ljigk, hilgjk)['replace'](/&#?\w+;/g, kjilm);tsuwvr && knljmi(ljigk), plnkom['characters'](z_0, 0x0, hilgjk - ljigk), ljigk = hilgjk;
    }
  }function knljmi(swtuvx, eghdi) {
    for (; swtuvx >= xwsvut && (eghdi = wutsxv['exec'](kpnlom));) lnkoj = eghdi['index'], xwsvut = lnkoj + eghdi[0x0]['length'], tsuwvr['lineNumber']++;tsuwvr['columnNumber'] = swtuvx - lnkoj + 0x1;
  }for (var lnkoj = 0x0, xwsvut = 0x0, wutsxv = /.*(?:\r\n?|\n)|.*$/g, tsuwvr = plnkom['locator'], gfhid = [{ 'currentNSMap': nsrqp }], bcae = {}, ljigk = 0x0;;) {
    try {
      var opm = kpnlom['indexOf']('<', ljigk);if (0x0 > opm) {
        if (!kpnlom['substr'](ljigk)['match'](/^\s*$/)) {
          var faec = plnkom['doc'],
              gdhfie = faec['createTextNode'](kpnlom['substr'](ljigk));faec['appendChild'](gdhfie), plnkom['currentElement'] = gdhfie;
        }return;
      }switch (opm > ljigk && qlopn(opm), kpnlom['charAt'](opm + 0x1)) {case '/':
          var qputr = kpnlom['indexOf']('>', opm + 0x3),
              rsvtw = kpnlom['substring'](opm + 0x2, qputr),
              uyzxw = gfhid['pop']();0x0 > qputr ? (rsvtw = kpnlom['substring'](opm + 0x2)['replace'](/[\s<].*/, ''), npoklm['error']('end tag name: ' + rsvtw + ' is not complete:' + uyzxw['tagName']), qputr = opm + 0x1 + rsvtw['length']) : rsvtw['match'](/\s</) && (rsvtw = rsvtw['replace'](/[\s<].*/, ''), npoklm['error']('end tag name: ' + rsvtw + ' maybe not complete'), qputr = opm + 0x1 + rsvtw['length']);var bfcda = uyzxw['localNSMap'],
              gfdch = uyzxw['tagName'] == rsvtw,
              rpomq = gfdch || uyzxw['tagName'] && uyzxw['tagName']['toLowerCase']() == rsvtw['toLowerCase']();if (rpomq) {
            if (plnkom['endElement'](uyzxw['uri'], uyzxw['localName'], rsvtw), bfcda) {
              for (var opnmr in bfcda) plnkom['endPrefixMapping'](opnmr);
            }gfdch || npoklm['fatalError']('end tag name: ' + rsvtw + ' is not match the current start tagName:' + uyzxw['tagName']);
          } else gfhid['push'](uyzxw);qputr++;break;case '?':
          tsuwvr && knljmi(opm), qputr = _dorqpmn(kpnlom, opm, plnkom);break;case '!':
          tsuwvr && knljmi(opm), qputr = _dxuywt(kpnlom, opm, plnkom, npoklm);break;default:
          tsuwvr && knljmi(opm);var mkljh = new _d_y0(),
              vyxz$ = gfhid[gfhid['length'] - 0x1]['currentNSMap'],
              qputr = _dstpur(kpnlom, opm, mkljh, vyxz$, kjilm, npoklm),
              z$10_ = mkljh['length'];if (!mkljh['closed'] && _d_1z0(kpnlom, qputr, mkljh['tagName'], bcae) && (mkljh['closed'] = !0x0, qoprmn['nbsp'] || npoklm['warning']('unclosed xml attribute')), tsuwvr && z$10_) {
            for (var utxy = _dfcebg(tsuwvr, {}), fdce = 0x0; z$10_ > fdce; fdce++) {
              var faebd = mkljh[fdce];knljmi(faebd['offset']), faebd['locator'] = _dfcebg(tsuwvr, {});
            }plnkom['locator'] = utxy, _duxyvz(mkljh, plnkom, vyxz$) && gfhid['push'](mkljh), plnkom['locator'] = tsuwvr;
          } else _duxyvz(mkljh, plnkom, vyxz$) && gfhid['push'](mkljh);'http://www.w3.org/1999/xhtml' !== mkljh['uri'] || mkljh['closed'] ? qputr++ : qputr = _debacfd(kpnlom, qputr, mkljh['tagName'], kjilm, plnkom);}
    } catch (nklmij) {
      npoklm['error']('element parse error: ' + nklmij), qputr = -0x1;
    }qputr > ljigk ? ljigk = qputr : qlopn(Math['max'](opm, ljigk) + 0x1);
  }
}function _dfcebg($0zy, z1$) {
  return z1$['lineNumber'] = $0zy['lineNumber'], z1$['columnNumber'] = $0zy['columnNumber'], z1$;
}function _dstpur(inml, vwzux, pnsq, kgih, zwvx$, zy_1$) {
  for (var olnqm, vrwu, jhgkl = ++vwzux, tqsupr = _dutxyw;;) {
    var pmr = inml['charAt'](jhgkl);switch (pmr) {case '=':
        if (tqsupr === _dsoqpn) olnqm = inml['slice'](vwzux, jhgkl), tqsupr = _dvtuxws;else {
          if (tqsupr !== _dklghi) throw new Error('attribute equal must after attrName');tqsupr = _dvtuxws;
        }break;case '\x27':case '\x22':
        if (tqsupr === _dvtuxws || tqsupr === _dsoqpn) {
          if (tqsupr === _dsoqpn && (zy_1$['warning']('attribute value must after "="'), olnqm = inml['slice'](vwzux, jhgkl)), vwzux = jhgkl + 0x1, jhgkl = inml['indexOf'](pmr, vwzux), !(jhgkl > 0x0)) throw new Error('attribute value no end \'' + pmr + '\' match');vrwu = inml['slice'](vwzux, jhgkl)['replace'](/&#?\w+;/g, zwvx$), pnsq['add'](olnqm, vrwu, vwzux - 0x1), tqsupr = _dfihgd;
        } else {
          if (tqsupr != _dnplo) throw new Error('attribute value must after "="');vrwu = inml['slice'](vwzux, jhgkl)['replace'](/&#?\w+;/g, zwvx$), pnsq['add'](olnqm, vrwu, vwzux), zy_1$['warning']('attribute "' + olnqm + '" missed start quot(' + pmr + ')!!'), vwzux = jhgkl + 0x1, tqsupr = _dfihgd;
        }break;case '/':
        switch (tqsupr) {case _dutxyw:
            pnsq['setTagName'](inml['slice'](vwzux, jhgkl));case _dfihgd:case _d_zx0y:case _dcedba:
            tqsupr = _dcedba, pnsq['closed'] = !0x0;case _dnplo:case _dsoqpn:case _dklghi:
            break;default:
            throw new Error('attribute invalid close char(\'/\')');}break;case '':
        return zy_1$['error']('unexpected end of input'), tqsupr == _dutxyw && pnsq['setTagName'](inml['slice'](vwzux, jhgkl)), jhgkl;case '>':
        switch (tqsupr) {case _dutxyw:
            pnsq['setTagName'](inml['slice'](vwzux, jhgkl));case _dfihgd:case _d_zx0y:case _dcedba:
            break;case _dnplo:case _dsoqpn:
            vrwu = inml['slice'](vwzux, jhgkl), '/' === vrwu['slice'](-0x1) && (pnsq['closed'] = !0x0, vrwu = vrwu['slice'](0x0, -0x1));case _dklghi:
            tqsupr === _dklghi && (vrwu = olnqm), tqsupr == _dnplo ? (zy_1$['warning']('attribute "' + vrwu + '" missed quot(")!!'), pnsq['add'](olnqm, vrwu['replace'](/&#?\w+;/g, zwvx$), vwzux)) : ('http://www.w3.org/1999/xhtml' === kgih[''] && vrwu['match'](/^(?:disabled|checked|selected)$/i) || zy_1$['warning']('attribute "' + vrwu + '" missed value!! "' + vrwu + '" instead!!'), pnsq['add'](vrwu, vrwu, vwzux));break;case _dvtuxws:
            throw new Error('attribute value missed!!');}return jhgkl;case '\u0080':
        pmr = '\x20';default:
        if ('\x20' >= pmr) switch (tqsupr) {case _dutxyw:
            pnsq['setTagName'](inml['slice'](vwzux, jhgkl)), tqsupr = _d_zx0y;break;case _dsoqpn:
            olnqm = inml['slice'](vwzux, jhgkl), tqsupr = _dklghi;break;case _dnplo:
            var vrwu = inml['slice'](vwzux, jhgkl)['replace'](/&#?\w+;/g, zwvx$);zy_1$['warning']('attribute "' + vrwu + '" missed quot(")!!'), pnsq['add'](olnqm, vrwu, vwzux);case _dfihgd:
            tqsupr = _d_zx0y;} else switch (tqsupr) {case _dklghi:
            {
              pnsq['tagName'];
            }'http://www.w3.org/1999/xhtml' === kgih[''] && olnqm['match'](/^(?:disabled|checked|selected)$/i) || zy_1$['warning']('attribute "' + olnqm + '" missed value!! "' + olnqm + '" instead2!!'), pnsq['add'](olnqm, olnqm, vwzux), vwzux = jhgkl, tqsupr = _dsoqpn;break;case _dfihgd:
            zy_1$['warning']('attribute space is required"' + olnqm + '\x22!!');case _d_zx0y:
            tqsupr = _dsoqpn, vwzux = jhgkl;break;case _dvtuxws:
            tqsupr = _dnplo, vwzux = jhgkl;break;case _dcedba:
            throw new Error('elements closed character \'/\' and \'>\' must be connected to');}}jhgkl++;
  }
}function _duxyvz(ighjlk, kimjhl, kjolmn) {
  for (var bacd = ighjlk['tagName'], acdfe = null, iehgj = ighjlk['length']; iehgj--;) {
    var utspq = ighjlk[iehgj],
        opstqr = utspq['qName'],
        lqnm = utspq['value'],
        wuy = opstqr['indexOf'](':');if (wuy > 0x0) var mpqno = utspq['prefix'] = opstqr['slice'](0x0, wuy),
        gfecdh = opstqr['slice'](wuy + 0x1),
        vuzxyw = 'xmlns' === mpqno && gfecdh;else gfecdh = opstqr, mpqno = null, vuzxyw = 'xmlns' === opstqr && '';utspq['localName'] = gfecdh, vuzxyw !== !0x1 && (null == acdfe && (acdfe = {}, _dmjnli(kjolmn, kjolmn = {})), kjolmn[vuzxyw] = acdfe[vuzxyw] = lqnm, utspq['uri'] = 'http://www.w3.org/2000/xmlns/', kimjhl['startPrefixMapping'](vuzxyw, lqnm));
  }for (var iehgj = ighjlk['length']; iehgj--;) {
    utspq = ighjlk[iehgj];var mpqno = utspq['prefix'];mpqno && ('xml' === mpqno && (utspq['uri'] = 'http://www.w3.org/XML/1998/namespace'), 'xmlns' !== mpqno && (utspq['uri'] = kjolmn[mpqno || '']));
  }var wuy = bacd['indexOf'](':');wuy > 0x0 ? (mpqno = ighjlk['prefix'] = bacd['slice'](0x0, wuy), gfecdh = ighjlk['localName'] = bacd['slice'](wuy + 0x1)) : (mpqno = null, gfecdh = ighjlk['localName'] = bacd);var ijnl = ighjlk['uri'] = kjolmn[mpqno || ''];if (kimjhl['startElement'](ijnl, gfecdh, bacd, ighjlk), !ighjlk['closed']) return ighjlk['currentNSMap'] = kjolmn, ighjlk['localNSMap'] = acdfe, !0x0;if (kimjhl['endElement'](ijnl, gfecdh, bacd), acdfe) {
    for (mpqno in acdfe) kimjhl['endPrefixMapping'](mpqno);
  }
}function _debacfd(mji, vuxswt, kiljn, egfbc, gdcebf) {
  if (/^(?:script|textarea)$/i['test'](kiljn)) {
    var nqromp = mji['indexOf']('</' + kiljn + '>', vuxswt),
        mljnik = mji['substring'](vuxswt + 0x1, nqromp);if (/[&<]/['test'](mljnik)) return (/^script$/i['test'](kiljn) ? (gdcebf['characters'](mljnik, 0x0, mljnik['length']), nqromp) : (mljnik = mljnik['replace'](/&#?\w+;/g, egfbc), gdcebf['characters'](mljnik, 0x0, mljnik['length']), nqromp)
    );
  }return vuxswt + 0x1;
}function _d_1z0(hegfi, gjihfe, xytuv, lpnomq) {
  var rvuwst = lpnomq[xytuv];return null == rvuwst && (rvuwst = hegfi['lastIndexOf']('</' + xytuv + '>'), gjihfe > rvuwst && (rvuwst = hegfi['lastIndexOf']('</' + xytuv)), lpnomq[xytuv] = rvuwst), gjihfe > rvuwst;
}function _dmjnli(yzvwux, dfgbc) {
  for (var gjlkhi in yzvwux) dfgbc[gjlkhi] = yzvwux[gjlkhi];
}function _dxuywt(njkiml, bfdce, fac, gdefb) {
  var trosp = njkiml['charAt'](bfdce + 0x2);switch (trosp) {case '-':
      if ('-' === njkiml['charAt'](bfdce + 0x3)) {
        var cafbde = njkiml['indexOf']('-->', bfdce + 0x4);return cafbde > bfdce ? (fac['comment'](njkiml, bfdce + 0x4, cafbde - bfdce - 0x4), cafbde + 0x3) : (gdefb['error']('Unclosed comment'), -0x1);
      }return -0x1;default:
      if ('CDATA[' == njkiml['substr'](bfdce + 0x3, 0x6)) {
        var cafbde = njkiml['indexOf'](']]>', bfdce + 0x9);return fac['startCDATA'](), fac['characters'](njkiml, bfdce + 0x9, cafbde - bfdce - 0x9), fac['endCDATA'](), cafbde + 0x3;
      }var edbgc = _dopmlkn(njkiml, bfdce),
          cgdeh = edbgc['length'];if (cgdeh > 0x1 && /!doctype/i['test'](edbgc[0x0][0x0])) {
        var dabcf = edbgc[0x1][0x0],
            febcg = cgdeh > 0x3 && /^public$/i['test'](edbgc[0x2][0x0]) && edbgc[0x3][0x0],
            ghikfj = cgdeh > 0x4 && edbgc[0x4][0x0],
            vqtu = edbgc[cgdeh - 0x1];return fac['startDTD'](dabcf, febcg && febcg['replace'](/^(['"])(.*?)\1$/, '$2'), ghikfj && ghikfj['replace'](/^(['"])(.*?)\1$/, '$2')), fac['endDTD'](), vqtu['index'] + vqtu[0x0]['length'];
      }}return -0x1;
}function _dorqpmn(vwyutx, _01$z, x0y$_z) {
  var ompqrn = vwyutx['indexOf']('?>', _01$z);if (ompqrn) {
    var nil = vwyutx['substring'](_01$z, ompqrn)['match'](/^<\?(\S*)\s*([\s\S]*?)\s*$/);if (nil) {
      {
        nil[0x0]['length'];
      }return x0y$_z['processingInstruction'](nil[0x1], nil[0x2]), ompqrn + 0x2;
    }return -0x1;
  }return -0x1;
}function _d_y0() {}function _domnrqp(z_$, eihfdg) {
  return z_$['__proto__'] = eihfdg, z_$;
}function _dopmlkn(z12$0_, turps) {
  var xvt,
      srqutp = [],
      mnpql = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;for (mnpql['lastIndex'] = turps, mnpql['exec'](z12$0_); xvt = mnpql['exec'](z12$0_);) if (srqutp['push'](xvt), xvt[0x1]) return srqutp;
}var _drotspq = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    _dokpln = new RegExp('[\\-\\.0-9' + _drotspq['source']['slice'](0x1, -0x1) + '\\u00B7\\u0300-\\u036F\\u203F-\\u2040]'),
    _dzx0_$ = new RegExp('^' + _drotspq['source'] + _dokpln['source'] + '*(?::' + _drotspq['source'] + _dokpln['source'] + '*)?$'),
    _dutxyw = 0x0,
    _dsoqpn = 0x1,
    _dklghi = 0x2,
    _dvtuxws = 0x3,
    _dnplo = 0x4,
    _dfihgd = 0x5,
    _d_zx0y = 0x6,
    _dcedba = 0x7;_dmjin['prototype'] = { 'parse': function (vyuw, tqvus, tsvwux) {
    var tsrwuv = this['domBuilder'];tsrwuv['startDocument'](), _dmjnli(tqvus, tqvus = {}), _duxvws(vyuw, tqvus, tsvwux, tsrwuv, this['errorHandler']), tsrwuv['endDocument']();
  } }, _d_y0['prototype'] = { 'setTagName': function (y0$z1_) {
    if (!_dzx0_$['test'](y0$z1_)) throw new Error('invalid tagName:' + y0$z1_);this['tagName'] = y0$z1_;
  }, 'add': function (ljonk, inkmjl, xstw) {
    if (!_dzx0_$['test'](ljonk)) throw new Error('invalid attribute:' + ljonk);this[this['length']++] = { 'qName': ljonk, 'value': inkmjl, 'offset': xstw };
  }, 'length': 0x0, 'getLocalName': function (moj) {
    return this[moj]['localName'];
  }, 'getLocator': function (lqnopm) {
    return this[lqnopm]['locator'];
  }, 'getQName': function (oqnpml) {
    return this[oqnpml]['qName'];
  }, 'getURI': function (xvuzy) {
    return this[xvuzy]['uri'];
  }, 'getValue': function (trsvw) {
    return this[trsvw]['value'];
  } }, _domnrqp({}, _domnrqp['prototype']) instanceof _domnrqp || (_domnrqp = function (oklm, lmoknj) {
  function fcdab() {}fcdab['prototype'] = lmoknj, fcdab = new fcdab();for (lmoknj in oklm) fcdab[lmoknj] = oklm[lmoknj];return fcdab;
}), exports['XMLReader'] = _dmjin;