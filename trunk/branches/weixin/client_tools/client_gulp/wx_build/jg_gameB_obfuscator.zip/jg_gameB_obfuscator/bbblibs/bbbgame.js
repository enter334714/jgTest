var _ = wx.y$;
console[_[78]](_[27530]), window[_[27531]], wx[_[27532]](function (_0z2$) {
  if (_0z2$) {
    if (_0z2$[_[4381]]) {
      var nokmlp = window[_[547]][_[27533]][_[4557]](new RegExp(/\./, 'g'), '_'),
          lnmk = _0z2$[_[4381]],
          qnmpro = lnmk[_[11461]](/(bbbbbbbbb\/bbbgame.js:)[0-9]{1,60}(:)/g);if (qnmpro) for (var onmpkl = 0x0; onmpkl < qnmpro[_[13]]; onmpkl++) {
        if (qnmpro[onmpkl] && qnmpro[onmpkl][_[13]] > 0x0) {
          var vyxtuw = parseInt(qnmpro[onmpkl][_[4557]](_[27534], '')[_[4557]](':', ''));lnmk = lnmk[_[4557]](qnmpro[onmpkl], qnmpro[onmpkl][_[4557]](':' + vyxtuw + ':', ':' + (vyxtuw - 0x2) + ':'));
        }
      }lnmk = lnmk[_[4557]](new RegExp(_[27535], 'g'), _[27536] + nokmlp + _[24166]), lnmk = lnmk[_[4557]](new RegExp(_[27537], 'g'), _[27536] + nokmlp + _[24166]), _0z2$[_[4381]] = lnmk;
    }var qptsur = { 'id': window['p$DE'][_[27538]], 'role': window['p$DE'][_[4499]], 'level': window['p$DE'][_[27539]], 'user': window['p$DE'][_[24069]], 'version': window['p$DE'][_[101]], 'gamever': window[_[547]][_[27533]], 'cdn': window['p$DE'][_[4379]], 'serverid': window['p$DE'][_[24064]] ? window['p$DE'][_[24064]][_[11051]] : 0x0, 'systemInfo': window[_[27540]], 'error': _[27541], 'stack': _0z2$ ? _0z2$[_[4381]] : '' },
        jmlkno = JSON[_[4367]](qptsur);console[_[125]](_[27542] + jmlkno), (!window[_[27531]] || window[_[27531]] != qptsur[_[125]]) && (window[_[27531]] = qptsur[_[125]], window['p$BD'](qptsur));
  }
});import 'bbbmd5min.js';import 'bbbzlibs.js';window[_[27543]] = require(_[27544]);import 'bbbindex.js';import 'bbblibsmin.js';import 'bbbwxmini.js';import 'bbbinitmin.js';console[_[78]](_[27545]), console[_[78]](_[27546]), p$BDCE({ 'title': _[27547] });var _dqmopnr = { 'p$ACBDE': !![] };new window[_[27548]](_dqmopnr), window[_[27548]][_[148]]['p$ACEBD']();if (window['p$ABECD']) clearInterval(window['p$ABECD']);window['p$ABECD'] = null, window['p$ACEDB'] = function (vusxtw, gdfech) {
  if (!vusxtw || !gdfech) return 0x0;vusxtw = vusxtw[_[15]]('.'), gdfech = gdfech[_[15]]('.');const dgi = Math[_[840]](vusxtw[_[13]], gdfech[_[13]]);while (vusxtw[_[13]] < dgi) {
    vusxtw[_[29]]('0');
  }while (gdfech[_[13]] < dgi) {
    gdfech[_[29]]('0');
  }for (var vrqsut = 0x0; vrqsut < dgi; vrqsut++) {
    const ljom = parseInt(vusxtw[vrqsut]),
          yw_$xz = parseInt(gdfech[vrqsut]);if (ljom > yw_$xz) return 0x1;else {
      if (ljom < yw_$xz) return -0x1;
    }
  }return 0x0;
}, window[_[27549]] = wx[_[27550]]()[_[27549]], console[_[471]](_[27551] + window[_[27549]]);var _dvutwy = wx[_[27552]]();_dvutwy[_[27553]](function (vxyw) {
  console[_[471]](_[27554] + vxyw[_[27555]]);
}), _dvutwy[_[27556]](function () {
  wx[_[27557]]({ 'title': _[27558], 'content': _[27559], 'showCancel': ![], 'success': function (fgikhj) {
      _dvutwy[_[27560]]();
    } });
}), _dvutwy[_[27561]](function () {
  console[_[471]](_[27562]);
}), window['p$ADBCE'] = function () {
  console[_[471]](_[27563]);var glhkji = wx[_[27564]]({ 'name': _[27565], 'success': function (cbgfed) {
      console[_[471]](_[27566]), console[_[471]](cbgfed), cbgfed && cbgfed[_[24235]] == _[27567] ? (window['p$EC'] = !![], window['p$EDBC'](), window['p$EDCB']()) : setTimeout(function () {
        window['p$ADBCE']();
      }, 0x1f4);
    }, 'fail': function (vtyx) {
      console[_[471]](_[27568]), console[_[471]](vtyx), setTimeout(function () {
        window['p$ADBCE']();
      }, 0x1f4);
    } });glhkji && glhkji[_[27569]](uwrsv => {});
}, window['p$ADCBE'] = function () {
  console[_[471]](_[27570]);var eijf = wx[_[27564]]({ 'name': _[27571], 'success': function (jimkh) {
      console[_[471]](_[27572]), console[_[471]](jimkh), jimkh && jimkh[_[24235]] == _[27567] ? (window['p$DCE'] = !![], window['p$EDBC'](), window['p$EDCB']()) : setTimeout(function () {
        window['p$ADCBE']();
      }, 0x1f4);
    }, 'fail': function (ehgdf) {
      console[_[471]](_[27573]), console[_[471]](ehgdf), setTimeout(function () {
        window['p$ADCBE']();
      }, 0x1f4);
    } });eijf && eijf[_[27569]](ghed => {});
}, window[_[27574]] = function () {
  window['p$ACEDB'](window[_[27549]], _[27575]) >= 0x0 ? (console[_[471]](_[27576] + window[_[27549]] + _[27577]), window['p$DB'](), window['p$ADBCE'](), window['p$ADCBE']()) : (window['p$DEB'](_[27578] + window[_[27549]]), wx[_[27557]]({ 'title': _[6237], 'content': _[27579] }));
}, window[_[27540]] = '', wx[_[27580]]({ 'success'(gcefhd) {
    window[_[27540]] = _[27581] + gcefhd[_[27582]] + _[27583] + gcefhd[_[27584]] + _[27585] + gcefhd[_[4570]] + _[27586] + gcefhd[_[464]] + _[27587] + gcefhd[_[24042]] + _[27588] + gcefhd[_[27549]] + _[27589] + gcefhd[_[8965]], console[_[471]](window[_[27540]]), console[_[471]](_[27590] + gcefhd[_[27591]] + _[27592] + gcefhd[_[27593]] + _[27594] + gcefhd[_[27595]] + _[27596] + gcefhd[_[27597]] + _[27598] + gcefhd[_[27599]] + _[27600] + gcefhd[_[27601]] + _[27602] + (gcefhd[_[27603]] ? gcefhd[_[27603]][_[320]] + ',' + gcefhd[_[27603]][_[1200]] + ',' + gcefhd[_[27603]][_[1202]] + ',' + gcefhd[_[27603]][_[1201]] : ''));var ecfdb = gcefhd[_[464]] ? gcefhd[_[464]][_[11713]]() : '',
        nosqr = gcefhd[_[27584]] ? gcefhd[_[27584]][_[11713]]()[_[4557]]('\x20', '') : '';window['p$DE'][_[501]] = ecfdb[_[115]](_[27604]) != -0x1, window['p$DE'][_[10880]] = ecfdb[_[115]](_[27484]) != -0x1, window['p$DE'][_[27605]] = ecfdb[_[115]](_[27604]) != -0x1 || ecfdb[_[115]](_[27484]) != -0x1, window['p$DE'][_[23703]] = ecfdb[_[115]](_[27485]) != -0x1 || ecfdb[_[115]](_[27606]) != -0x1, window['p$DE'][_[27607]] = gcefhd[_[24042]] ? gcefhd[_[24042]][_[11713]]() : '', window['p$DE']['p$ABDCE'] = ![], window['p$DE']['p$ABDEC'] = 0x2;if (ecfdb[_[115]](_[27484]) != -0x1) {
      if (gcefhd[_[8965]] >= 0x18) window['p$DE']['p$ABDEC'] = 0x3;else window['p$DE']['p$ABDEC'] = 0x2;
    } else {
      if (ecfdb[_[115]](_[27604]) != -0x1) {
        if (gcefhd[_[8965]] && gcefhd[_[8965]] >= 0x14) window['p$DE']['p$ABDEC'] = 0x3;else {
          if (nosqr[_[115]](_[27608]) != -0x1 || nosqr[_[115]](_[27609]) != -0x1 || nosqr[_[115]](_[27610]) != -0x1 || nosqr[_[115]](_[27611]) != -0x1 || nosqr[_[115]](_[27612]) != -0x1) window['p$DE']['p$ABDEC'] = 0x2;else window['p$DE']['p$ABDEC'] = 0x3;
        }
      } else window['p$DE']['p$ABDEC'] = 0x2;
    }console[_[471]](_[27613] + window['p$DE']['p$ABDCE'] + _[27614] + window['p$DE']['p$ABDEC']);
  } }), wx[_[27615]]({ 'success': function (hgije) {
    console[_[471]](_[27616] + hgije[_[4475]] + _[27617] + hgije[_[27618]]);
  } }), wx[_[27619]]({ 'success': function (jmok) {
    console[_[471]](_[27620] + jmok[_[27621]]);
  } }), wx[_[27622]]({ 'keepScreenOn': !![] }), wx[_[27623]](function (dfgch) {
  console[_[471]](_[27620] + dfgch[_[27621]] + _[27624] + dfgch[_[27625]]);
}), wx[_[27626]](function (xvwu) {
  window['p$EBC'] = xvwu, window['p$ECB'] && window['p$EBC'] && (console[_[78]](_[27627] + window['p$EBC'][_[763]]), window['p$ECB'](window['p$EBC']), window['p$EBC'] = null);
}), window['p$ADEBC'] = 0x0, window[_[27628]] = null, wx[_[27629]](function () {
  window['p$ADEBC']++, wx[_[11265]]();if (window['p$ADEBC'] >= 0x2) {
    window['p$ADEBC'] = 0x0, console[_[125]](_[27630]), wx[_[27631]]('0', 0x1);if (window['p$DE'] && window['p$DE'][_[501]]) window['p$DEB'](_[27632]);if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});