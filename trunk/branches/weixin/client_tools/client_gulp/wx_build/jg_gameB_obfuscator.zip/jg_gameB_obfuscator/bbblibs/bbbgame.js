var _ = wx.y$;
console[_[78]](_[29149]), window[_[29150]], wx[_[29151]](function (qpru) {
  if (qpru) {
    if (qpru[_[4548]]) {
      var y$z_x0 = window[_[557]][_[29152]][_[4727]](new RegExp(/\./, 'g'), '_'),
          zvwy$ = qpru[_[4548]],
          rpsnqo = zvwy$[_[12098]](/(bbbbbbbbb\/bbbgame.js:)[0-9]{1,60}(:)/g);if (rpsnqo) for (var adb = 0x0; adb < rpsnqo[_[13]]; adb++) {
        if (rpsnqo[adb] && rpsnqo[adb][_[13]] > 0x0) {
          var pqomn = parseInt(rpsnqo[adb][_[4727]](_[29153], '')[_[4727]](':', ''));zvwy$ = zvwy$[_[4727]](rpsnqo[adb], rpsnqo[adb][_[4727]](':' + pqomn + ':', ':' + (pqomn - 0x2) + ':'));
        }
      }zvwy$ = zvwy$[_[4727]](new RegExp(_[29154], 'g'), _[29155] + y$z_x0 + _[25446]), zvwy$ = zvwy$[_[4727]](new RegExp(_[29156], 'g'), _[29155] + y$z_x0 + _[25446]), qpru[_[4548]] = zvwy$;
    }var rqts = { 'id': window['p$DE'][_[29157]], 'role': window['p$DE'][_[4669]], 'level': window['p$DE'][_[29158]], 'user': window['p$DE'][_[25346]], 'version': window['p$DE'][_[101]], 'cdn': window['p$DE'][_[4546]], 'pkgName': window['p$DE'][_[25347]], 'gamever': window[_[557]][_[29152]], 'serverid': window['p$DE'][_[25341]] ? window['p$DE'][_[25341]][_[11552]] : 0x0, 'systemInfo': window[_[29159]], 'error': _[29160], 'stack': qpru ? qpru[_[4548]] : '' },
        gchdfe = JSON[_[4532]](rqts);console[_[125]](_[29161] + gchdfe), (!window[_[29150]] || window[_[29150]] != rqts[_[125]]) && (window[_[29150]] = rqts[_[125]], window['p$BD'](rqts));
  }
});import 'bbbmd5min.js';import 'bbbzlibs.js';window[_[29162]] = require(_[29163]);import 'bbbindex.js';import 'bbblibsmin.js';import 'bbbwxmini.js';import 'bbbinitmin.js';console[_[78]](_[29164]), console[_[78]](_[29165]), p$BDCE({ 'title': _[29166] });var _dxwvz$ = { 'p$ABEDC': !![] };new window[_[29167]](_dxwvz$), window[_[29167]][_[148]]['p$ACDEB']();if (window['p$ABDEC']) clearInterval(window['p$ABDEC']);window['p$ABDEC'] = null, window['p$ACEBD'] = function (x$vwzy, rtvsw) {
  if (!x$vwzy || !rtvsw) return 0x0;x$vwzy = x$vwzy[_[15]]('.'), rtvsw = rtvsw[_[15]]('.');const yx_$ = Math[_[853]](x$vwzy[_[13]], rtvsw[_[13]]);while (x$vwzy[_[13]] < yx_$) {
    x$vwzy[_[29]]('0');
  }while (rtvsw[_[13]] < yx_$) {
    rtvsw[_[29]]('0');
  }for (var oprq = 0x0; oprq < yx_$; oprq++) {
    const ikhjlg = parseInt(x$vwzy[oprq]),
          wyxvz$ = parseInt(rtvsw[oprq]);if (ikhjlg > wyxvz$) return 0x1;else {
      if (ikhjlg < wyxvz$) return -0x1;
    }
  }return 0x0;
}, window[_[29168]] = wx[_[29169]]()[_[29168]], console[_[482]](_[29170] + window[_[29168]]);var _drtusp = wx[_[29171]]();_drtusp[_[29172]](function (nroqpm) {
  console[_[482]](_[29173] + nroqpm[_[29174]]);
}), _drtusp[_[29175]](function () {
  wx[_[29176]]({ 'title': _[29177], 'content': _[29178], 'showCancel': ![], 'success': function (eigfj) {
      _drtusp[_[29179]]();
    } });
}), _drtusp[_[29180]](function () {
  console[_[482]](_[29181]);
}), window['p$ACEDB'] = function () {
  console[_[482]](_[29182]);var tvsu = wx[_[29183]]({ 'name': _[29184], 'success': function (pnsoqr) {
      console[_[482]](_[29185]), console[_[482]](pnsoqr), pnsoqr && pnsoqr[_[25535]] == _[29186] ? (window['p$EC'] = !![], window['p$ECDB'](), window['p$EDBC']()) : setTimeout(function () {
        window['p$ACEDB']();
      }, 0x1f4);
    }, 'fail': function (nkpolm) {
      console[_[482]](_[29187]), console[_[482]](nkpolm), setTimeout(function () {
        window['p$ACEDB']();
      }, 0x1f4);
    } });tvsu && tvsu[_[29188]](vyxt => {});
}, window['p$ADBEC'] = function () {
  console[_[482]](_[29189]);var hdcgf = wx[_[29183]]({ 'name': _[29190], 'success': function (qotrsp) {
      console[_[482]](_[29191]), console[_[482]](qotrsp), qotrsp && qotrsp[_[25535]] == _[29186] ? (window['p$DCE'] = !![], window['p$ECDB'](), window['p$EDBC']()) : setTimeout(function () {
        window['p$ADBEC']();
      }, 0x1f4);
    }, 'fail': function (rnops) {
      console[_[482]](_[29192]), console[_[482]](rnops), setTimeout(function () {
        window['p$ADBEC']();
      }, 0x1f4);
    } });hdcgf && hdcgf[_[29188]](pnmq => {});
}, window[_[29193]] = function () {
  window['p$ACEBD'](window[_[29168]], _[29194]) >= 0x0 ? (console[_[482]](_[29195] + window[_[29168]] + _[29196]), window['p$DB'](), window['p$ACEDB'](), window['p$ADBEC']()) : (window['p$DEB'](_[29197], window[_[29168]]), wx[_[29176]]({ 'title': _[6394], 'content': _[29198] }));
}, window[_[29159]] = '', wx[_[29199]]({ 'success'(ejhfig) {
    window[_[29159]] = _[29200] + ejhfig[_[29201]] + _[29202] + ejhfig[_[29203]] + _[29204] + ejhfig[_[4740]] + _[29205] + ejhfig[_[475]] + _[29206] + ejhfig[_[25318]] + _[29207] + ejhfig[_[29168]] + _[29208] + ejhfig[_[9349]], console[_[482]](window[_[29159]]), console[_[482]](_[29209] + ejhfig[_[29210]] + _[29211] + ejhfig[_[29212]] + _[29213] + ejhfig[_[29214]] + _[29215] + ejhfig[_[29216]] + _[29217] + ejhfig[_[29218]] + _[29219] + ejhfig[_[29220]] + _[29221] + (ejhfig[_[29222]] ? ejhfig[_[29222]][_[323]] + ',' + ejhfig[_[29222]][_[1216]] + ',' + ejhfig[_[29222]][_[1218]] + ',' + ejhfig[_[29222]][_[1217]] : ''));var yvtuxw = ejhfig[_[475]] ? ejhfig[_[475]][_[12395]]() : '',
        gfhdce = ejhfig[_[29203]] ? ejhfig[_[29203]][_[12395]]()[_[4727]]('\x20', '') : '';window['p$DE'][_[1074]] = yvtuxw[_[115]](_[29223]) != -0x1, window['p$DE'][_[11374]] = yvtuxw[_[115]](_[29103]) != -0x1, window['p$DE'][_[29224]] = yvtuxw[_[115]](_[29223]) != -0x1 || yvtuxw[_[115]](_[29103]) != -0x1, window['p$DE'][_[25054]] = yvtuxw[_[115]](_[29104]) != -0x1 || yvtuxw[_[115]](_[29225]) != -0x1, window['p$DE'][_[29226]] = ejhfig[_[25318]] ? ejhfig[_[25318]][_[12395]]() : '', window['p$DE']['p$ABCED'] = ![], window['p$DE']['p$ABDCE'] = 0x2;if (yvtuxw[_[115]](_[29103]) != -0x1) {
      if (ejhfig[_[9349]] >= 0x18) window['p$DE']['p$ABDCE'] = 0x3;else window['p$DE']['p$ABDCE'] = 0x2;
    } else {
      if (yvtuxw[_[115]](_[29223]) != -0x1) {
        if (ejhfig[_[9349]] && ejhfig[_[9349]] >= 0x14) window['p$DE']['p$ABDCE'] = 0x3;else {
          if (gfhdce[_[115]](_[29227]) != -0x1 || gfhdce[_[115]](_[29228]) != -0x1 || gfhdce[_[115]](_[29229]) != -0x1 || gfhdce[_[115]](_[29230]) != -0x1 || gfhdce[_[115]](_[29231]) != -0x1) window['p$DE']['p$ABDCE'] = 0x2;else window['p$DE']['p$ABDCE'] = 0x3;
        }
      } else window['p$DE']['p$ABDCE'] = 0x2;
    }console[_[482]](_[29232] + window['p$DE']['p$ABCED'] + _[29233] + window['p$DE']['p$ABDCE']);
  } }), wx[_[29234]]({ 'success': function (svuxt) {
    console[_[482]](_[29235] + svuxt[_[4645]] + _[29236] + svuxt[_[29237]]);
  } }), wx[_[29238]]({ 'success': function (sxtvuw) {
    console[_[482]](_[29239] + sxtvuw[_[29240]]);
  } }), wx[_[29241]]({ 'keepScreenOn': !![] }), wx[_[29242]](function (hjfgie) {
  console[_[482]](_[29239] + hjfgie[_[29240]] + _[29243] + hjfgie[_[29244]]);
}), wx[_[10884]](function (eihgjf) {
  window['p$CB'] = eihgjf, window['p$EBC'] && window['p$CB'] && (console[_[78]](_[29245] + window['p$CB'][_[776]]), window['p$EBC'](window['p$CB']), window['p$CB'] = null);
}), window[_[29246]] = 0x0, window['p$ADCEB'] = 0x0, window[_[29247]] = null, wx[_[29248]](function () {
  window['p$ADCEB']++;var $z21 = Date[_[83]]();(window[_[29246]] == 0x0 || $z21 - window[_[29246]] > 0x1d4c0) && (console[_[96]](_[29249]), wx[_[11951]]());if (window['p$ADCEB'] >= 0x2) {
    window['p$ADCEB'] = 0x0, console[_[125]](_[29250]), wx[_[29251]]('0', 0x1);if (window['p$DE'] && window['p$DE'][_[1074]]) window['p$DEB'](_[29252], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});