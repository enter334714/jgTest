var _ = wx.y$;
console[_[594]](_[30453]), window[_[30454]], wx[_[30455]](function (jkilhg) {
  if (jkilhg) {
    if (jkilhg[_[35]]) {
      var bfcaed = window[_[1032]][_[30456]][_[166]](new RegExp(/\./, 'g'), '_'),
          swvxt = jkilhg[_[35]],
          zy_$0x = swvxt[_[42]](/(bbbbbbbbb\/bbbgame.js:)[0-9]{1,60}(:)/g);if (zy_$0x) for (var pmqorn = 0x0; pmqorn < zy_$0x[_[19]]; pmqorn++) {
        if (zy_$0x[pmqorn] && zy_$0x[pmqorn][_[19]] > 0x0) {
          var oqpnlm = parseInt(zy_$0x[pmqorn][_[166]](_[30457], '')[_[166]](':', ''));swvxt = swvxt[_[166]](zy_$0x[pmqorn], zy_$0x[pmqorn][_[166]](':' + oqpnlm + ':', ':' + (oqpnlm - 0x2) + ':'));
        }
      }swvxt = swvxt[_[166]](new RegExp(_[30458], 'g'), _[30459] + bfcaed + _[26570]), swvxt = swvxt[_[166]](new RegExp(_[30460], 'g'), _[30459] + bfcaed + _[26570]), jkilhg[_[35]] = swvxt;
    }var gjlihk = { 'id': window['p$DE'][_[30461]], 'role': window['p$DE'][_[5317]], 'level': window['p$DE'][_[30462]], 'user': window['p$DE'][_[26473]], 'version': window['p$DE'][_[612]], 'cdn': window['p$DE'][_[5197]], 'pkgName': window['p$DE'][_[26474]], 'gamever': window[_[1032]][_[30456]], 'serverid': window['p$DE'][_[26468]] ? window['p$DE'][_[26468]][_[12260]] : 0x0, 'systemInfo': window[_[30463]], 'error': _[30464], 'stack': jkilhg ? jkilhg[_[35]] : '' },
        suxtvw = JSON[_[5183]](gjlihk);console[_[199]](_[30465] + suxtvw), (!window[_[30454]] || window[_[30454]] != gjlihk[_[199]]) && (window[_[30454]] = gjlihk[_[199]], window['p$BD'](gjlihk));
  }
});import 'bbbmd5min.js';import 'bbbzlibs.js';window[_[30466]] = require(_[30467]);import 'bbbindex.js';import 'bbblibsmin.js';import 'bbbwxmini.js';import 'bbbinitmin.js';console[_[594]](_[30468]), console[_[594]](_[30469]), p$BDCE({ 'title': _[30470] });var _dsqrnop = { 'p$ABEDC': !![] };new window[_[30471]](_dsqrnop), window[_[30471]][_[648]]['p$ACDEB']();if (window['p$ABDEC']) clearInterval(window['p$ABDEC']);window['p$ABDEC'] = null, window['p$ACEBD'] = function (wtuyv, jfgkhi) {
  if (!wtuyv || !jfgkhi) return 0x0;wtuyv = wtuyv[_[144]]('.'), jfgkhi = jfgkhi[_[144]]('.');const lomkjn = Math[_[191]](wtuyv[_[19]], jfgkhi[_[19]]);while (wtuyv[_[19]] < lomkjn) {
    wtuyv[_[41]]('0');
  }while (jfgkhi[_[19]] < lomkjn) {
    jfgkhi[_[41]]('0');
  }for (var pomrqn = 0x0; pomrqn < lomkjn; pomrqn++) {
    const monplk = parseInt(wtuyv[pomrqn]),
          qorsp = parseInt(jfgkhi[pomrqn]);if (monplk > qorsp) return 0x1;else {
      if (monplk < qorsp) return -0x1;
    }
  }return 0x0;
}, window[_[30472]] = wx[_[30473]]()[_[30472]], console[_[156]](_[30474] + window[_[30472]]);var _dusqrtp = wx[_[30475]]();_dusqrtp[_[30476]](function (suwvtr) {
  console[_[156]](_[30477] + suwvtr[_[30478]]);
}), _dusqrtp[_[30479]](function () {
  wx[_[30480]]({ 'title': _[30481], 'content': _[30482], 'showCancel': ![], 'success': function (supt) {
      _dusqrtp[_[30483]]();
    } });
}), _dusqrtp[_[30484]](function () {
  console[_[156]](_[30485]);
}), window['p$ACEDB'] = function () {
  console[_[156]](_[30486]);var tspqo = wx[_[30487]]({ 'name': _[30488], 'success': function (fihgk) {
      console[_[156]](_[30489]), console[_[156]](fihgk), fihgk && fihgk[_[26668]] == _[30490] ? (window['p$EC'] = !![], window['p$ECDB'](), window['p$EDBC']()) : setTimeout(function () {
        window['p$ACEDB']();
      }, 0x1f4);
    }, 'fail': function (xzwvy) {
      console[_[156]](_[30491]), console[_[156]](xzwvy), setTimeout(function () {
        window['p$ACEDB']();
      }, 0x1f4);
    } });tspqo && tspqo[_[30133]](pron => {});
}, window['p$ADBEC'] = function () {
  console[_[156]](_[30492]);var xzv$wy = wx[_[30487]]({ 'name': _[30493], 'success': function (plknom) {
      console[_[156]](_[30494]), console[_[156]](plknom), plknom && plknom[_[26668]] == _[30490] ? (window['p$DCE'] = !![], window['p$ECDB'](), window['p$EDBC']()) : setTimeout(function () {
        window['p$ADBEC']();
      }, 0x1f4);
    }, 'fail': function (hgje) {
      console[_[156]](_[30495]), console[_[156]](hgje), setTimeout(function () {
        window['p$ADBEC']();
      }, 0x1f4);
    } });xzv$wy && xzv$wy[_[30133]](sonrp => {});
}, window[_[30496]] = function () {
  window['p$ACEBD'](window[_[30472]], _[30497]) >= 0x0 ? (console[_[156]](_[30498] + window[_[30472]] + _[30499]), window['p$DB'](), window['p$ACEDB'](), window['p$ADBEC']()) : (window['p$DEB'](_[30500], window[_[30472]]), wx[_[30480]]({ 'title': _[7049], 'content': _[30501] }));
}, window[_[30463]] = '', wx[_[30502]]({ 'success'(pmqnro) {
    window[_[30463]] = _[30503] + pmqnro[_[30504]] + _[30505] + pmqnro[_[30506]] + _[30507] + pmqnro[_[5388]] + _[30508] + pmqnro[_[954]] + _[30509] + pmqnro[_[26438]] + _[30510] + pmqnro[_[30472]] + _[30511] + pmqnro[_[10021]], console[_[156]](window[_[30463]]), console[_[156]](_[30512] + pmqnro[_[30513]] + _[30514] + pmqnro[_[30515]] + _[30516] + pmqnro[_[30517]] + _[30518] + pmqnro[_[30519]] + _[30520] + pmqnro[_[30521]] + _[30522] + pmqnro[_[30523]] + _[30524] + (pmqnro[_[30525]] ? pmqnro[_[30525]][_[802]] + ',' + pmqnro[_[30525]][_[1717]] + ',' + pmqnro[_[30525]][_[1719]] + ',' + pmqnro[_[30525]][_[1718]] : ''));var srpo = pmqnro[_[954]] ? pmqnro[_[954]][_[68]]() : '',
        sport = pmqnro[_[30506]] ? pmqnro[_[30506]][_[68]]()[_[166]]('\x20', '') : '';window['p$DE'][_[1564]] = srpo[_[102]](_[30526]) != -0x1, window['p$DE'][_[12082]] = srpo[_[102]](_[30405]) != -0x1, window['p$DE'][_[30527]] = srpo[_[102]](_[30526]) != -0x1 || srpo[_[102]](_[30405]) != -0x1, window['p$DE'][_[26169]] = srpo[_[102]](_[30406]) != -0x1 || srpo[_[102]](_[30528]) != -0x1, window['p$DE'][_[30529]] = pmqnro[_[26438]] ? pmqnro[_[26438]][_[68]]() : '', window['p$DE']['p$ABCED'] = ![], window['p$DE']['p$ABDCE'] = 0x2;if (srpo[_[102]](_[30405]) != -0x1) {
      if (pmqnro[_[10021]] >= 0x18) window['p$DE']['p$ABDCE'] = 0x3;else window['p$DE']['p$ABDCE'] = 0x2;
    } else {
      if (srpo[_[102]](_[30526]) != -0x1) {
        if (pmqnro[_[10021]] && pmqnro[_[10021]] >= 0x14) window['p$DE']['p$ABDCE'] = 0x3;else {
          if (sport[_[102]](_[30530]) != -0x1 || sport[_[102]](_[30531]) != -0x1 || sport[_[102]](_[30532]) != -0x1 || sport[_[102]](_[30533]) != -0x1 || sport[_[102]](_[30534]) != -0x1) window['p$DE']['p$ABDCE'] = 0x2;else window['p$DE']['p$ABDCE'] = 0x3;
        }
      } else window['p$DE']['p$ABDCE'] = 0x2;
    }console[_[156]](_[30535] + window['p$DE']['p$ABCED'] + _[30536] + window['p$DE']['p$ABDCE']);
  } }), wx[_[30537]]({ 'success': function (tsxuvw) {
    console[_[156]](_[30538] + tsxuvw[_[5294]] + _[30539] + tsxuvw[_[30540]]);
  } }), wx[_[12662]]({ 'success': function (orpq) {
    console[_[156]](_[30541] + orpq[_[13973]]);
  } }), wx[_[30542]]({ 'keepScreenOn': !![] }), wx[_[12664]](function (vwr) {
  console[_[156]](_[30541] + vwr[_[13973]] + _[30543] + vwr[_[30544]]);
}), wx[_[11588]](function (upqst) {
  window['p$CB'] = upqst, window['p$EBC'] && window['p$CB'] && (console[_[594]](_[30545] + window['p$CB'][_[1270]]), window['p$EBC'](window['p$CB']), window['p$CB'] = null);
}), window[_[30546]] = 0x0, window['p$ADCEB'] = 0x0, window[_[30547]] = null, wx[_[30548]](function () {
  window['p$ADCEB']++;var jgifeh = Date[_[599]]();(window[_[30546]] == 0x0 || jgifeh - window[_[30546]] > 0x1d4c0) && (console[_[212]](_[30549]), wx[_[12733]]());if (window['p$ADCEB'] >= 0x2) {
    window['p$ADCEB'] = 0x0, console[_[199]](_[30550]), wx[_[30551]]('0', 0x1);if (window['p$DE'] && window['p$DE'][_[1564]]) window['p$DEB'](_[30552], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});