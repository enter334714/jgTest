var B = wx.$z;
console[B[440070]](B[440335]), window[B[440336]], wx[B[440337]](function (otzdey) {
  if (otzdey) {
    if (otzdey[B[440338]]) {
      var xste = window[B[440002]][B[440003]][B[440339]](new RegExp(/\./, 'g'), '_'),
          dybo8 = otzdey[B[440338]],
          b8r2 = dybo8[B[440340]](/(zzzzz\/zzGAMEz.js:)[0-9]{1,60}(:)/g);if (b8r2) for (var ur_w5 = 0x0; ur_w5 < b8r2[B[440167]]; ur_w5++) {
        if (b8r2[ur_w5] && b8r2[ur_w5][B[440167]] > 0x0) {
          var eoasz = parseInt(b8r2[ur_w5][B[440339]](B[440341], '')[B[440339]](':', ''));dybo8 = dybo8[B[440339]](b8r2[ur_w5], b8r2[ur_w5][B[440339]](':' + eoasz + ':', ':' + (eoasz - 0x2) + ':'));
        }
      }dybo8 = dybo8[B[440339]](new RegExp(B[440342], 'g'), B[440343] + xste + B[440344]), dybo8 = dybo8[B[440339]](new RegExp(B[440345], 'g'), B[440343] + xste + B[440344]), otzdey[B[440338]] = dybo8;
    }var x9esaz = { 'id': window['z0JD'][B[440079]], 'role': window['z0JD'][B[440080]], 'level': window['z0JD'][B[440081]], 'user': window['z0JD'][B[440082]], 'version': window['z0JD'][B[440041]], 'cdn': window['z0JD'][B[440083]], 'pkgName': window['z0JD'][B[440024]], 'gamever': window[B[440002]][B[440003]], 'serverid': window['z0JD'][B[440030]] ? window['z0JD'][B[440030]][B[440084]] : 0x0, 'systemInfo': window[B[440085]], 'error': B[440346], 'stack': otzdey ? otzdey[B[440338]] : '' },
        teszx = JSON[B[440087]](x9esaz);console[B[440088]](B[440347] + teszx), (!window[B[440336]] || window[B[440336]] != x9esaz[B[440088]]) && (window[B[440336]] = x9esaz[B[440088]], window['z00J'](x9esaz));
  }
});import 'zzbfzz.js';import 'zz11zz.js';window[B[440348]] = require(B[440349]);import 'zINDzz.js';import 'zzIB1zz.js';import 'zzMtadzz.js';import 'zzINIzz.js';console[B[440070]](B[440350]), console[B[440070]](B[440351]), z00JYD({ 'title': B[440352] });var zuw2_50 = { 'z0R0DJY': !![] };new window[B[440065]](zuw2_50), window[B[440065]][B[440066]]['z0RYJD0']();if (window['z0R0JDY']) clearInterval(window['z0R0JDY']);window['z0R0JDY'] = null, window['z0RYD0J'] = function (nmi7q3, nilmv7) {
  if (!nmi7q3 || !nilmv7) return 0x0;nmi7q3 = nmi7q3[B[440353]]('.'), nilmv7 = nilmv7[B[440353]]('.');const l7nvm = Math[B[440354]](nmi7q3[B[440167]], nilmv7[B[440167]]);while (nmi7q3[B[440167]] < l7nvm) {
    nmi7q3[B[440224]]('0');
  }while (nilmv7[B[440167]] < l7nvm) {
    nilmv7[B[440224]]('0');
  }for (var etdza = 0x0; etdza < l7nvm; etdza++) {
    const odkzyt = parseInt(nmi7q3[etdza]),
          aozet = parseInt(nilmv7[etdza]);if (odkzyt > aozet) return 0x1;else {
      if (odkzyt < aozet) return -0x1;
    }
  }return 0x0;
}, window[B[440225]] = wx[B[440355]]()[B[440225]], console[B[440049]](B[440356] + window[B[440225]]);var zboydk = wx[B[440357]]();zboydk[B[440358]](function (w5ur2_) {
  console[B[440049]](B[440359] + w5ur2_[B[440360]]);
}), zboydk[B[440361]](function () {
  wx[B[440051]]({ 'title': B[440362], 'content': B[440363], 'showCancel': ![], 'success': function (sae9z) {
      zboydk[B[440364]]();
    } });
}), zboydk[B[440365]](function () {
  console[B[440049]](B[440366]);
}), window['z0RYDJ0'] = function () {
  console[B[440049]](B[440367]);var tozsea = wx[B[440368]]({ 'name': B[440369], 'success': function (ryk8d) {
      console[B[440049]](B[440370]), console[B[440049]](ryk8d), ryk8d && ryk8d[B[440141]] == B[440371] ? (window['z0DY'] = !![], window['z0DYJ0'](), window['z0DJ0Y']()) : setTimeout(function () {
        window['z0RYDJ0']();
      }, 0x1f4);
    }, 'fail': function (eazots) {
      console[B[440049]](B[440372]), console[B[440049]](eazots), setTimeout(function () {
        window['z0RYDJ0']();
      }, 0x1f4);
    } });tozsea && tozsea[B[440373]](gx19ph => {});
}, window['z0RJ0DY'] = function () {
  console[B[440049]](B[440374]);var w25ur_ = wx[B[440368]]({ 'name': B[440375], 'success': function (ru52) {
      console[B[440049]](B[440376]), console[B[440049]](ru52), ru52 && ru52[B[440141]] == B[440371] ? (window['z0JYD'] = !![], window['z0DYJ0'](), window['z0DJ0Y']()) : setTimeout(function () {
        window['z0RJ0DY']();
      }, 0x1f4);
    }, 'fail': function (p4hg6) {
      console[B[440049]](B[440377]), console[B[440049]](p4hg6), setTimeout(function () {
        window['z0RJ0DY']();
      }, 0x1f4);
    } });w25ur_ && w25ur_[B[440373]](j$i3m => {});
}, window[B[440378]] = function () {
  window['z0RYD0J'](window[B[440225]], B[440379]) >= 0x0 ? (console[B[440049]](B[440380] + window[B[440225]] + B[440381]), window['z0J0'](), window['z0RYDJ0'](), window['z0RJ0DY']()) : (window['z0JD0'](B[440382], window[B[440225]]), wx[B[440051]]({ 'title': B[440052], 'content': B[440383] }));
}, window[B[440085]] = '', wx[B[440384]]({ 'success'(_20u5w) {
    window[B[440085]] = B[440385] + _20u5w[B[440386]] + B[440387] + _20u5w[B[440388]] + B[440389] + _20u5w[B[440010]] + B[440390] + _20u5w[B[440391]] + B[440392] + _20u5w[B[440157]] + B[440393] + _20u5w[B[440225]] + B[440394] + _20u5w[B[440395]], console[B[440049]](window[B[440085]]), console[B[440049]](B[440396] + _20u5w[B[440397]] + B[440398] + _20u5w[B[440399]] + B[440400] + _20u5w[B[440401]] + B[440402] + _20u5w[B[440403]] + B[440404] + _20u5w[B[440405]] + B[440406] + _20u5w[B[440407]] + B[440408] + (_20u5w[B[440409]] ? _20u5w[B[440409]][B[440315]] + ',' + _20u5w[B[440409]][B[440318]] + ',' + _20u5w[B[440409]][B[440320]] + ',' + _20u5w[B[440409]][B[440322]] : ''));var sze9ax = _20u5w[B[440391]] ? _20u5w[B[440391]][B[440410]]() : '',
        zsoe = _20u5w[B[440388]] ? _20u5w[B[440388]][B[440410]]()[B[440339]]('\x20', '') : '';window['z0JD'][B[440043]] = sze9ax[B[440142]](B[440411]) != -0x1, window['z0JD'][B[440044]] = sze9ax[B[440142]](B[440412]) != -0x1, window['z0JD'][B[440314]] = sze9ax[B[440142]](B[440411]) != -0x1 || sze9ax[B[440142]](B[440412]) != -0x1, window['z0JD'][B[440045]] = sze9ax[B[440142]](B[440413]) != -0x1 || sze9ax[B[440142]](B[440012]) != -0x1, window['z0JD'][B[440096]] = _20u5w[B[440157]] ? _20u5w[B[440157]][B[440410]]() : '', window['z0JD']['z0R0YDJ'] = ![], window['z0JD']['z0R0JYD'] = 0x2;if (sze9ax[B[440142]](B[440412]) != -0x1) {
      if (_20u5w[B[440395]] >= 0x18) window['z0JD']['z0R0JYD'] = 0x3;else window['z0JD']['z0R0JYD'] = 0x2;
    } else {
      if (sze9ax[B[440142]](B[440411]) != -0x1) {
        if (_20u5w[B[440395]] && _20u5w[B[440395]] >= 0x14) window['z0JD']['z0R0JYD'] = 0x3;else {
          if (zsoe[B[440142]](B[440414]) != -0x1 || zsoe[B[440142]](B[440415]) != -0x1 || zsoe[B[440142]](B[440416]) != -0x1 || zsoe[B[440142]](B[440417]) != -0x1 || zsoe[B[440142]](B[440418]) != -0x1) window['z0JD']['z0R0JYD'] = 0x2;else window['z0JD']['z0R0JYD'] = 0x3;
        }
      } else window['z0JD']['z0R0JYD'] = 0x2;
    }console[B[440049]](B[440419] + window['z0JD']['z0R0YDJ'] + B[440420] + window['z0JD']['z0R0JYD']);
  } }), wx[B[440244]]({ 'success': function (eydtoz) {
    console[B[440049]](B[440421] + eydtoz[B[440246]] + B[440422] + eydtoz[B[440248]]);
  } }), wx[B[440423]]({ 'success': function (ydzto) {
    console[B[440049]](B[440424] + ydzto[B[440425]]);
  } }), wx[B[440426]]({ 'keepScreenOn': !![] }), wx[B[440427]](function (rwu_25) {
  console[B[440049]](B[440424] + rwu_25[B[440425]] + B[440428] + rwu_25[B[440429]]);
}), wx[B[440218]](function (hpsx91) {
  window['z0Y0'] = hpsx91, window['z0D0Y'] && window['z0Y0'] && (console[B[440070]](B[440219] + window['z0Y0'][B[440220]]), window['z0D0Y'](window['z0Y0']), window['z0Y0'] = null);
}), window[B[440430]] = 0x0, window['z0RJYD0'] = 0x0, window[B[440431]] = null, wx[B[440432]](function () {
  window['z0RJYD0']++;var ivn7lf = Date[B[440036]]();(window[B[440430]] == 0x0 || ivn7lf - window[B[440430]] > 0x1d4c0) && (console[B[440094]](B[440433]), wx[B[440434]]());if (window['z0RJYD0'] >= 0x2) {
    window['z0RJYD0'] = 0x0, console[B[440088]](B[440435]), wx[B[440436]]('0', 0x1);if (window['z0JD'] && window['z0JD'][B[440043]]) window['z0JD0'](B[440437], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});