var B = wx.$z;
console[B[440091]](B[440456]), window[B[440457]], wx[B[440458]](function (pf6h) {
  if (pf6h) {
    if (pf6h[B[440459]]) {
      var gxp91h = window[B[440002]][B[440003]][B[440460]](new RegExp(/\./, 'g'), '_'),
          teozas = pf6h[B[440459]],
          i3jm$q = teozas[B[440461]](/(zzzzz\/zzGAMEz.js:)[0-9]{1,60}(:)/g);if (i3jm$q) for (var krb8y_ = 0x0; krb8y_ < i3jm$q[B[440213]]; krb8y_++) {
        if (i3jm$q[krb8y_] && i3jm$q[krb8y_][B[440213]] > 0x0) {
          var _8bk5r = parseInt(i3jm$q[krb8y_][B[440460]](B[440462], '')[B[440460]](':', ''));teozas = teozas[B[440460]](i3jm$q[krb8y_], i3jm$q[krb8y_][B[440460]](':' + _8bk5r + ':', ':' + (_8bk5r - 0x2) + ':'));
        }
      }teozas = teozas[B[440460]](new RegExp(B[440463], 'g'), B[440464] + gxp91h + B[440465]), teozas = teozas[B[440460]](new RegExp(B[440466], 'g'), B[440464] + gxp91h + B[440465]), pf6h[B[440459]] = teozas;
    }var fvlni7 = { 'id': window[B[440011]][B[440107]], 'role': window[B[440011]][B[440108]], 'level': window[B[440011]][B[440109]], 'user': window[B[440011]][B[440110]], 'version': window[B[440011]][B[440047]], 'cdn': window[B[440011]][B[440111]], 'pkgName': window[B[440011]][B[440029]], 'gamever': window[B[440002]][B[440003]], 'serverid': window[B[440011]][B[440035]] ? window[B[440011]][B[440035]][B[440112]] : 0x0, 'systemInfo': window[B[440113]], 'error': B[440467], 'stack': pf6h ? pf6h[B[440459]] : '' },
        oats = JSON[B[440115]](fvlni7);console[B[440116]](B[440468] + oats), (!window[B[440457]] || window[B[440457]] != fvlni7[B[440116]]) && (window[B[440457]] = fvlni7[B[440116]], window[B[440036]](fvlni7));
  }
});import 'zzbfzz.js';import 'zz11zz.js';window[B[440469]] = require(B[440470]);import 'zINDzz.js';import 'zzIB1zz.js';import 'zzMtadzz.js';import 'zzINIzz.js';console[B[440091]](B[440471]), console[B[440091]](B[440472]), z00JYD({ 'title': B[440473] });var zkdybot = { 'z0R0DJY': !![] };new window[B[440086]](zkdybot), window[B[440086]][B[440087]][B[440474]]();if (window[B[440475]]) clearInterval(window[B[440475]]);window[B[440475]] = null, window[B[440152]] = function (saozte, zkd) {
  if (!saozte || !zkd) return 0x0;saozte = saozte[B[440476]]('.'), zkd = zkd[B[440476]]('.');const vnlfi7 = Math[B[440477]](saozte[B[440213]], zkd[B[440213]]);while (saozte[B[440213]] < vnlfi7) {
    saozte[B[440316]]('0');
  }while (zkd[B[440213]] < vnlfi7) {
    zkd[B[440316]]('0');
  }for (var dzeat = 0x0; dzeat < vnlfi7; dzeat++) {
    const v4f6l = parseInt(saozte[dzeat]),
          vimn = parseInt(zkd[dzeat]);if (v4f6l > vimn) return 0x1;else {
      if (v4f6l < vimn) return -0x1;
    }
  }return 0x0;
}, window[B[440317]] = wx[B[440478]]()[B[440317]], console[B[440064]](B[440479] + window[B[440317]]);var zvm7n = wx[B[440480]]();zvm7n[B[440481]](function (r8_52u) {
  console[B[440064]](B[440482] + r8_52u[B[440483]]);
}), zvm7n[B[440484]](function () {
  wx[B[440066]]({ 'title': B[440485], 'content': B[440486], 'showCancel': ![], 'success': function (g19phx) {
      zvm7n[B[440487]]();
    } });
}), zvm7n[B[440488]](function () {
  console[B[440064]](B[440489]);
}), window[B[440490]] = function () {
  console[B[440064]](B[440491]);var zyted = wx[B[440492]]({ 'name': B[440493], 'success': function (w2u05_) {
      console[B[440064]](B[440494]), console[B[440064]](w2u05_), w2u05_ && w2u05_[B[440178]] == B[440495] ? (window[B[440054]] = !![], window[B[440250]](), window[B[440251]]()) : setTimeout(function () {
        window[B[440490]]();
      }, 0x1f4);
    }, 'fail': function (liv7f) {
      console[B[440064]](B[440496]), console[B[440064]](liv7f), setTimeout(function () {
        window[B[440490]]();
      }, 0x1f4);
    } });zyted && zyted[B[440497]](lnim73 => {});
}, window[B[440498]] = function () {
  console[B[440064]](B[440499]);var oastze = wx[B[440492]]({ 'name': B[440500], 'success': function (dtykob) {
      console[B[440064]](B[440501]), console[B[440064]](dtykob), dtykob && dtykob[B[440178]] == B[440495] ? (window[B[440055]] = !![], window[B[440250]](), window[B[440251]]()) : setTimeout(function () {
        window[B[440498]]();
      }, 0x1f4);
    }, 'fail': function (r8ydkb) {
      console[B[440064]](B[440502]), console[B[440064]](r8ydkb), setTimeout(function () {
        window[B[440498]]();
      }, 0x1f4);
    } });oastze && oastze[B[440497]](i3$q => {});
}, window[B[440503]] = function () {
  window[B[440152]](window[B[440317]], B[440504]) >= 0x0 ? (console[B[440064]](B[440505] + window[B[440317]] + B[440506]), window[B[440076]](), window[B[440490]](), window[B[440498]]()) : (window[B[440124]](B[440507], window[B[440317]]), wx[B[440066]]({ 'title': B[440067], 'content': B[440508] }));
}, window[B[440113]] = '', wx[B[440509]]({ 'success'(hxs) {
    window[B[440113]] = B[440510] + hxs[B[440511]] + B[440512] + hxs[B[440513]] + B[440514] + hxs[B[440015]] + B[440515] + hxs[B[440516]] + B[440517] + hxs[B[440198]] + B[440518] + hxs[B[440317]] + B[440519] + hxs[B[440520]], console[B[440064]](window[B[440113]]), console[B[440064]](B[440521] + hxs[B[440522]] + B[440523] + hxs[B[440524]] + B[440525] + hxs[B[440526]] + B[440527] + hxs[B[440528]] + B[440529] + hxs[B[440530]] + B[440531] + hxs[B[440532]] + B[440533] + (hxs[B[440534]] ? hxs[B[440534]][B[440434]] + ',' + hxs[B[440534]][B[440437]] + ',' + hxs[B[440534]][B[440439]] + ',' + hxs[B[440534]][B[440441]] : ''));var axh9s = hxs[B[440516]] ? hxs[B[440516]][B[440535]]() : '',
        yeot = hxs[B[440513]] ? hxs[B[440513]][B[440535]]()[B[440460]]('\x20', '') : '';window[B[440011]][B[440049]] = axh9s[B[440179]](B[440536]) != -0x1, window[B[440011]][B[440050]] = axh9s[B[440179]](B[440537]) != -0x1, window[B[440011]][B[440433]] = axh9s[B[440179]](B[440536]) != -0x1 || axh9s[B[440179]](B[440537]) != -0x1, window[B[440011]][B[440051]] = axh9s[B[440179]](B[440538]) != -0x1 || axh9s[B[440179]](B[440017]) != -0x1, window[B[440011]][B[440127]] = hxs[B[440198]] ? hxs[B[440198]][B[440535]]() : '', window[B[440011]][B[440429]] = ![], window[B[440011]][B[440430]] = 0x2;if (axh9s[B[440179]](B[440537]) != -0x1) {
      if (hxs[B[440520]] >= 0x18) window[B[440011]][B[440430]] = 0x3;else window[B[440011]][B[440430]] = 0x2;
    } else {
      if (axh9s[B[440179]](B[440536]) != -0x1) {
        if (hxs[B[440520]] && hxs[B[440520]] >= 0x14) window[B[440011]][B[440430]] = 0x3;else {
          if (yeot[B[440179]](B[440539]) != -0x1 || yeot[B[440179]](B[440540]) != -0x1 || yeot[B[440179]](B[440541]) != -0x1 || yeot[B[440179]](B[440542]) != -0x1 || yeot[B[440179]](B[440543]) != -0x1) window[B[440011]][B[440430]] = 0x2;else window[B[440011]][B[440430]] = 0x3;
        }
      } else window[B[440011]][B[440430]] = 0x2;
    }console[B[440064]](B[440544] + window[B[440011]][B[440429]] + B[440545] + window[B[440011]][B[440430]]);
  } }), wx[B[440338]]({ 'success': function (w_u20) {
    console[B[440064]](B[440546] + w_u20[B[440340]] + B[440547] + w_u20[B[440342]]);
  } }), wx[B[440344]]({ 'success': function (hgf64) {
    console[B[440064]](B[440548] + hgf64[B[440549]]);
  } }), wx[B[440550]]({ 'keepScreenOn': !![] }), wx[B[440345]](function (u_58r) {
  console[B[440064]](B[440548] + u_58r[B[440549]] + B[440551] + u_58r[B[440552]]);
}), wx[B[440306]](function (zxase) {
  window[B[440308]] = zxase, window[B[440307]] && window[B[440308]] && (console[B[440091]](B[440309] + window[B[440308]][B[440310]]), window[B[440307]](window[B[440308]]), window[B[440308]] = null);
}), window[B[440553]] = 0x0, window[B[440554]] = 0x0, window[B[440555]] = null, wx[B[440556]](function () {
  window[B[440554]]++;var zetsxa = Date[B[440042]]();(window[B[440553]] == 0x0 || zetsxa - window[B[440553]] > 0x1d4c0) && (console[B[440125]](B[440557]), wx[B[440558]]());if (window[B[440554]] >= 0x2) {
    window[B[440554]] = 0x0, console[B[440116]](B[440559]), wx[B[440560]]('0', 0x1);if (window[B[440011]] && window[B[440011]][B[440049]]) window[B[440124]](B[440561], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});