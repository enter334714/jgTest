var B = wx.$z;
import zfn6l4v from '../zzabzzsdk/z7sdkz.js';window[B[440001]] = { 'wxVersion': window[B[440002]][B[440003]] }, window[B[440004]] = ![], window['z0DJ'] = 0x1, window[B[440005]] = 0x1, window['z0YJD'] = !![], window[B[440006]] = !![], window['z0R0YJD'] = '', window['z0JD'] = { 'base_cdn': B[440007], 'cdn': B[440007] }, z0JD[B[440008]] = {}, z0JD[B[440009]] = '0', z0JD[B[440010]] = window[B[440001]][B[440011]], z0JD[B[440012]] = '', z0JD['os'] = '1', z0JD[B[440013]] = B[440014], z0JD[B[440015]] = B[440016], z0JD[B[440017]] = B[440018], z0JD[B[440019]] = B[440020], z0JD[B[440021]] = B[440022], z0JD[B[440023]] = '1', z0JD[B[440024]] = '', z0JD[B[440025]] = '', z0JD[B[440026]] = 0x0, z0JD[B[440027]] = {}, z0JD[B[440028]] = parseInt(z0JD[B[440023]]), z0JD[B[440029]] = z0JD[B[440023]], z0JD[B[440030]] = {}, z0JD['z00J'] = B[440031], z0JD[B[440032]] = ![], z0JD[B[440033]] = B[440034], z0JD[B[440035]] = Date[B[440036]](), z0JD[B[440037]] = B[440038], z0JD[B[440039]] = '_a', z0JD[B[440040]] = 0x2, z0JD[B[440041]] = 0x7c1, z0JD[B[440011]] = window[B[440001]][B[440011]], z0JD[B[440042]] = ![], z0JD[B[440043]] = ![], z0JD[B[440044]] = ![], z0JD[B[440045]] = ![], window['z0YDJ'] = 0x5, window['z0YD'] = ![], window['z0DY'] = ![], window['z0JYD'] = ![], window[B[440046]] = ![], window[B[440047]] = ![], window['z0JDY'] = ![], window['z0YJ'] = ![], window['z0JY'] = ![], window['z0DYJ'] = ![], window[B[440048]] = function ($mq3i) {
  console[B[440049]](B[440048], $mq3i), wx[B[440050]]({}), wx[B[440051]]({ 'title': B[440052], 'content': $mq3i, 'success'(w_u2r5) {
      if (w_u2r5[B[440053]]) console[B[440049]](B[440054]);else w_u2r5[B[440055]] && console[B[440049]](B[440056]);
    } });
}, window['z00YJD'] = function (vnlmi) {
  console[B[440049]](B[440057], vnlmi), z00JDY(), wx[B[440051]]({ 'title': B[440052], 'content': vnlmi, 'confirmText': B[440058], 'cancelText': B[440059], 'success'(e9saxz) {
      if (e9saxz[B[440053]]) window['z0J0']();else e9saxz[B[440055]] && (console[B[440049]](B[440060]), wx[B[440061]]({}));
    } });
}, window[B[440062]] = function (n3mi7q) {
  console[B[440049]](B[440062], n3mi7q), wx[B[440051]]({ 'title': B[440052], 'content': n3mi7q, 'confirmText': B[440063], 'showCancel': ![], 'complete'(f7viln) {
      console[B[440049]](B[440060]), wx[B[440061]]({});
    } });
}, window['z00YDJ'] = ![], window['z00JYD'] = function (bkdy8o) {
  window['z00YDJ'] = !![], wx[B[440064]](bkdy8o);
}, window['z00JDY'] = function () {
  window['z00YDJ'] && (window['z00YDJ'] = ![], wx[B[440050]]({}));
}, window['z00DYJ'] = function (tzeyod) {
  window[B[440065]][B[440066]]['z00DYJ'](tzeyod);
}, window[B[440067]] = function (wur_2, q7$m) {
  zfn6l4v[B[440067]](wur_2, function (deozyt) {
    deozyt && deozyt[B[440068]] ? deozyt[B[440068]][B[440069]] == 0x1 ? q7$m(!![]) : (q7$m(![]), console[B[440070]](B[440071] + deozyt[B[440068]][B[440072]])) : console[B[440049]](B[440067], deozyt);
  });
}, window['z00DJY'] = function (vinlm) {
  console[B[440049]](B[440073], vinlm);
}, window['z00JD'] = function (bdykr8) {}, window['z00DJ'] = function (xaezs9, edatz, ni7fvl) {}, window['z00D'] = function (r2_85) {
  console[B[440049]](B[440074], r2_85), window[B[440065]][B[440066]][B[440075]](), window[B[440065]][B[440066]][B[440076]](), window[B[440065]][B[440066]][B[440077]]();
}, window['z0D0'] = function (todzae) {
  window['z00YJD'](B[440078]);var q7$im = { 'id': window['z0JD'][B[440079]], 'role': window['z0JD'][B[440080]], 'level': window['z0JD'][B[440081]], 'account': window['z0JD'][B[440082]], 'version': window['z0JD'][B[440041]], 'cdn': window['z0JD'][B[440083]], 'pkgName': window['z0JD'][B[440024]], 'gamever': window[B[440002]][B[440003]], 'serverid': window['z0JD'][B[440030]] ? window['z0JD'][B[440030]][B[440084]] : 0x0, 'systemInfo': window[B[440085]], 'error': B[440086], 'stack': todzae ? todzae : B[440078] },
      ykbod8 = JSON[B[440087]](q7$im);console[B[440088]](B[440089] + ykbod8), window['z00J'](ykbod8);
}, window['z0J0D'] = function (nfil) {
  var h1a9s = JSON[B[440090]](nfil);h1a9s[B[440091]] = window[B[440002]][B[440003]], h1a9s[B[440092]] = window['z0JD'][B[440030]] ? window['z0JD'][B[440030]][B[440084]] : 0x0, h1a9s[B[440085]] = window[B[440085]];var ykodbt = JSON[B[440087]](h1a9s);console[B[440088]](B[440093] + ykodbt), window['z00J'](ykodbt);
}, window['z0JD0'] = function (yetdo, ztoed) {
  var tyok = { 'id': window['z0JD'][B[440079]], 'role': window['z0JD'][B[440080]], 'level': window['z0JD'][B[440081]], 'account': window['z0JD'][B[440082]], 'version': window['z0JD'][B[440041]], 'cdn': window['z0JD'][B[440083]], 'pkgName': window['z0JD'][B[440024]], 'gamever': window[B[440002]][B[440003]], 'serverid': window['z0JD'][B[440030]] ? window['z0JD'][B[440030]][B[440084]] : 0x0, 'systemInfo': window[B[440085]], 'error': yetdo, 'stack': ztoed },
      zde = JSON[B[440087]](tyok);console[B[440094]](B[440095] + zde), window['z00J'](zde);
}, window['z00J'] = function (_5r2w) {
  if (window['z0JD'][B[440096]] == B[440097]) return;var tdzo = z0JD['z00J'] + B[440098] + z0JD[B[440082]];wx[B[440099]]({ 'url': tdzo, 'method': B[440100], 'data': _5r2w, 'header': { 'content-type': B[440101], 'cache-control': B[440102] }, 'success': function (r58_b) {
      DEBUG && console[B[440049]](B[440103], tdzo, _5r2w, r58_b);
    }, 'fail': function (ybokt) {
      DEBUG && console[B[440049]](B[440103], tdzo, _5r2w, ybokt);
    }, 'complete': function () {} });
}, window[B[440104]] = function () {
  function botd() {
    return ((0x1 + Math[B[440105]]()) * 0x10000 | 0x0)[B[440106]](0x10)[B[440107]](0x1);
  }return botd() + botd() + '-' + botd() + '-' + botd() + '-' + botd() + '+' + botd() + botd() + botd();
}, window['z0J0'] = function () {
  console[B[440049]](B[440108]);var u_8 = zfn6l4v[B[440109]]();z0JD[B[440029]] = u_8[B[440110]], z0JD[B[440028]] = u_8[B[440110]], z0JD[B[440023]] = u_8[B[440110]], z0JD[B[440024]] = u_8[B[440111]];var oyb8dk = { 'game_ver': z0JD[B[440010]] };z0JD[B[440025]] = this[B[440104]](), z00JYD({ 'title': B[440112] }), zfn6l4v[B[440113]](oyb8dk, this['z0D0J'][B[440114]](this));
}, window['z0D0J'] = function (aoszet) {
  var qim$3j = aoszet[B[440115]];console[B[440049]](B[440116] + qim$3j + B[440117] + (qim$3j == 0x1) + B[440118] + aoszet[B[440003]] + B[440119] + window[B[440001]][B[440011]]);if (!aoszet[B[440003]] || window['z0RYD0J'](window[B[440001]][B[440011]], aoszet[B[440003]]) < 0x0) console[B[440049]](B[440120]), z0JD[B[440015]] = B[440121], z0JD[B[440017]] = B[440122], z0JD[B[440019]] = B[440123], z0JD[B[440083]] = B[440124], z0JD[B[440125]] = B[440126], z0JD[B[440127]] = 'fj', z0JD[B[440042]] = ![];else window['z0RYD0J'](window[B[440001]][B[440011]], aoszet[B[440003]]) == 0x0 ? (console[B[440049]](B[440128]), z0JD[B[440015]] = B[440016], z0JD[B[440017]] = B[440018], z0JD[B[440019]] = B[440020], z0JD[B[440083]] = B[440129], z0JD[B[440125]] = B[440126], z0JD[B[440127]] = B[440130], z0JD[B[440042]] = !![]) : (console[B[440049]](B[440131]), z0JD[B[440015]] = B[440016], z0JD[B[440017]] = B[440018], z0JD[B[440019]] = B[440020], z0JD[B[440083]] = B[440129], z0JD[B[440125]] = B[440126], z0JD[B[440127]] = B[440130], z0JD[B[440042]] = ![]);z0JD[B[440026]] = config[B[440132]] ? config[B[440132]] : 0x0, this['z0YJ0D'](), this['z0YJD0'](), window[B[440133]] = 0x5, z00JYD({ 'title': B[440134] }), zfn6l4v[B[440135]](this['z0DJ0'][B[440114]](this));
}, window[B[440133]] = 0x5, window['z0DJ0'] = function (vg6f4, s1axe9) {
  if (vg6f4 == 0x0 && s1axe9 && s1axe9[B[440136]]) {
    z0JD[B[440137]] = s1axe9[B[440136]];var m$7iq = this;z00JYD({ 'title': B[440138] }), sendApi(z0JD[B[440015]], B[440139], { 'platform': z0JD[B[440013]], 'partner_id': z0JD[B[440023]], 'token': s1axe9[B[440136]], 'game_pkg': z0JD[B[440024]], 'deviceId': z0JD[B[440025]], 'scene': B[440140] + z0JD[B[440026]] }, this['z0Y0JD'][B[440114]](this), z0YDJ, z0D0);
  } else s1axe9 && s1axe9[B[440141]] && window[B[440133]] > 0x0 && (s1axe9[B[440141]][B[440142]](B[440143]) != -0x1 || s1axe9[B[440141]][B[440142]](B[440144]) != -0x1 || s1axe9[B[440141]][B[440142]](B[440145]) != -0x1 || s1axe9[B[440141]][B[440142]](B[440146]) != -0x1 || s1axe9[B[440141]][B[440142]](B[440147]) != -0x1 || s1axe9[B[440141]][B[440142]](B[440148]) != -0x1) ? (window[B[440133]]--, zfn6l4v[B[440135]](this['z0DJ0'][B[440114]](this))) : (window['z0JD0'](B[440149], JSON[B[440087]]({ 'status': vg6f4, 'data': s1axe9 })), window['z00YJD'](B[440150] + (s1axe9 && s1axe9[B[440141]] ? '，' + s1axe9[B[440141]] : '')));
}, window['z0Y0JD'] = function (fg4l) {
  if (!fg4l) {
    window['z0JD0'](B[440151], B[440152]), window['z00YJD'](B[440153]);return;
  }if (fg4l[B[440069]] != B[440154]) {
    window['z0JD0'](B[440151], JSON[B[440087]](fg4l)), window['z00YJD'](B[440155] + fg4l[B[440069]]);return;
  }z0JD[B[440156]] = String(fg4l[B[440082]]), z0JD[B[440082]] = String(fg4l[B[440082]]), z0JD[B[440157]] = String(fg4l[B[440157]]), z0JD[B[440029]] = String(fg4l[B[440157]]), z0JD[B[440158]] = String(fg4l[B[440158]]), z0JD[B[440159]] = String(fg4l[B[440160]]), z0JD[B[440161]] = String(fg4l[B[440162]]), z0JD[B[440160]] = '';var ifnvl7 = this;z00JYD({ 'title': B[440163] }), sendApi(z0JD[B[440015]], B[440164], { 'partner_id': z0JD[B[440023]], 'uid': z0JD[B[440082]], 'version': z0JD[B[440010]], 'game_pkg': z0JD[B[440024]], 'device': z0JD[B[440025]] }, ifnvl7['z0Y0DJ'][B[440114]](ifnvl7), z0YDJ, z0D0);
}, window['z0Y0DJ'] = function (gh94p1) {
  if (!gh94p1) {
    window['z00YJD'](B[440165]);return;
  }if (gh94p1[B[440069]] != B[440154]) {
    window['z00YJD'](B[440166] + gh94p1[B[440069]]);return;
  }if (!gh94p1[B[440068]] || gh94p1[B[440068]][B[440167]] == 0x0) {
    window['z00YJD'](B[440168]);return;
  }z0JD[B[440169]] = gh94p1[B[440170]], z0JD[B[440030]] = { 'server_id': String(gh94p1[B[440068]][0x0][B[440084]]), 'server_name': String(gh94p1[B[440068]][0x0][B[440171]]), 'entry_ip': gh94p1[B[440068]][0x0][B[440172]], 'entry_port': parseInt(gh94p1[B[440068]][0x0][B[440173]]), 'status': z0JY0(gh94p1[B[440068]][0x0]), 'start_time': gh94p1[B[440068]][0x0][B[440174]], 'cdn': z0JD[B[440083]] }, this['z0DJY0']();
}, window['z0DJY0'] = function () {
  if (z0JD[B[440169]] == 0x1) {
    var bkydto = z0JD[B[440030]][B[440175]];if (bkydto === -0x1 || bkydto === 0x0) {
      window['z00YJD'](bkydto === -0x1 ? B[440176] : B[440177]);return;
    }z0D0YJ(0x0, z0JD[B[440030]][B[440084]]), window[B[440065]][B[440066]][B[440178]](z0JD[B[440169]]);
  } else window[B[440065]][B[440066]][B[440179]](), z00JDY();window['z0JY'] = !![], window['z0DYJ0'](), window['z0DJ0Y']();
}, window['z0YJ0D'] = function () {
  sendApi(z0JD[B[440015]], B[440180], { 'game_pkg': z0JD[B[440024]], 'version_name': z0JD[B[440127]] }, this[B[440181]][B[440114]](this), z0YDJ, z0D0);
}, window[B[440181]] = function (g6vfp) {
  if (!g6vfp) {
    window['z00YJD'](B[440182]);return;
  }if (g6vfp[B[440069]] != B[440154]) {
    window['z00YJD'](B[440183] + g6vfp[B[440069]]);return;
  }if (!g6vfp[B[440068]] || !g6vfp[B[440068]][B[440010]]) {
    window['z00YJD'](B[440184] + (g6vfp[B[440068]] && g6vfp[B[440068]][B[440010]]));return;
  }g6vfp[B[440068]][B[440185]] && g6vfp[B[440068]][B[440185]][B[440167]] > 0xa && (z0JD[B[440186]] = g6vfp[B[440068]][B[440185]], z0JD[B[440083]] = g6vfp[B[440068]][B[440185]]), g6vfp[B[440068]][B[440010]] && (z0JD[B[440041]] = g6vfp[B[440068]][B[440010]]), console[B[440070]](B[440187] + z0JD[B[440041]] + B[440188] + z0JD[B[440127]]), window['z0JDY'] = !![], window['z0DYJ0'](), window['z0DJ0Y']();
}, window[B[440189]], window['z0YJD0'] = function () {
  sendApi(z0JD[B[440015]], B[440190], { 'game_pkg': z0JD[B[440024]] }, this['z0YD0J'][B[440114]](this), z0YDJ, z0D0);
}, window['z0YD0J'] = function (pf6g) {
  if (pf6g[B[440069]] === B[440154] && pf6g[B[440068]]) {
    window[B[440189]] = pf6g[B[440068]];for (var okyt in pf6g[B[440068]]) {
      z0JD[okyt] = pf6g[B[440068]][okyt];
    }
  } else console[B[440070]](B[440191] + pf6g[B[440069]]);window['z0YJ'] = !![], window['z0DJ0Y']();
}, window[B[440192]] = function (l3i7m, zeotyd, xs1ah, zodtky, w0_25, $iqm7, x1hps9, fv7n6l, _y8kbr) {
  w0_25 = String(w0_25);var zyodtk = x1hps9,
      y8dbk = fv7n6l;z0JD[B[440008]][w0_25] = { 'productid': w0_25, 'productname': zyodtk, 'productdesc': y8dbk, 'roleid': l3i7m, 'rolename': zeotyd, 'rolelevel': xs1ah, 'price': $iqm7, 'callback': _y8kbr }, sendApi(z0JD[B[440019]], B[440193], { 'game_pkg': z0JD[B[440024]], 'server_id': z0JD[B[440030]][B[440084]], 'server_name': z0JD[B[440030]][B[440171]], 'level': xs1ah, 'uid': z0JD[B[440082]], 'role_id': l3i7m, 'role_name': zeotyd, 'product_id': w0_25, 'product_name': zyodtk, 'product_desc': y8dbk, 'money': $iqm7, 'partner_id': z0JD[B[440023]] }, toPayCallBack, z0YDJ, z0D0);
}, window[B[440194]] = function (r8kby) {
  if (r8kby) {
    if (r8kby[B[440195]] === 0xc8 || r8kby[B[440069]] == B[440154]) {
      var ytzdeo = z0JD[B[440008]][String(r8kby[B[440196]])];if (ytzdeo[B[440197]]) ytzdeo[B[440197]](r8kby[B[440196]], r8kby[B[440198]], -0x1);zfn6l4v[B[440199]]({ 'cpbill': r8kby[B[440198]], 'productid': r8kby[B[440196]], 'productname': ytzdeo[B[440200]], 'productdesc': ytzdeo[B[440201]], 'serverid': z0JD[B[440030]][B[440084]], 'servername': z0JD[B[440030]][B[440171]], 'roleid': ytzdeo[B[440202]], 'rolename': ytzdeo[B[440203]], 'rolelevel': ytzdeo[B[440204]], 'price': ytzdeo[B[440205]], 'extension': JSON[B[440087]]({ 'cp_order_id': r8kby[B[440198]] }) }, function (dky8br, $iq37m) {
        ytzdeo[B[440197]] && dky8br == 0x0 && ytzdeo[B[440197]](r8kby[B[440196]], r8kby[B[440198]], dky8br);console[B[440070]](JSON[B[440087]]({ 'type': B[440206], 'status': dky8br, 'data': r8kby, 'role_name': ytzdeo[B[440203]] }));if (dky8br === 0x0) {} else {
          if (dky8br === 0x1) {} else {
            if (dky8br === 0x2) {}
          }
        }
      });
    } else alert(r8kby[B[440070]]);
  }
}, window['z0YDJ0'] = function () {}, window['z00YD'] = function (adozt, pfh6g4, yetzod, ur825, u52_rw) {
  zfn6l4v[B[440207]](z0JD[B[440030]][B[440084]], z0JD[B[440030]][B[440171]] || z0JD[B[440030]][B[440084]], adozt, pfh6g4, yetzod), sendApi(z0JD[B[440015]], B[440208], { 'game_pkg': z0JD[B[440024]], 'server_id': z0JD[B[440030]][B[440084]], 'role_id': adozt, 'uid': z0JD[B[440082]], 'role_name': pfh6g4, 'role_type': ur825, 'level': yetzod });
}, window['z00DY'] = function (r2w_5, nv6l7, h9gxp, eozat, tdybok, i3$mqj, h1x9as, zaotd, p1s9xh, d8kyob) {
  z0JD[B[440079]] = r2w_5, z0JD[B[440080]] = nv6l7, z0JD[B[440081]] = h9gxp, zfn6l4v[B[440209]](z0JD[B[440030]][B[440084]], z0JD[B[440030]][B[440171]] || z0JD[B[440030]][B[440084]], r2w_5, nv6l7, h9gxp), sendApi(z0JD[B[440015]], B[440210], { 'game_pkg': z0JD[B[440024]], 'server_id': z0JD[B[440030]][B[440084]], 'role_id': r2w_5, 'uid': z0JD[B[440082]], 'role_name': nv6l7, 'role_type': eozat, 'level': h9gxp, 'evolution': tdybok });
}, window['z0Y0D'] = function (b528_, dotyze, b85_, kzdo, _58rk, tdkboy, p1shx9, wu0, oybtk, vlf4n) {
  z0JD[B[440079]] = b528_, z0JD[B[440080]] = dotyze, z0JD[B[440081]] = b85_, zfn6l4v[B[440211]](z0JD[B[440030]][B[440084]], z0JD[B[440030]][B[440171]] || z0JD[B[440030]][B[440084]], b528_, dotyze, b85_), sendApi(z0JD[B[440015]], B[440210], { 'game_pkg': z0JD[B[440024]], 'server_id': z0JD[B[440030]][B[440084]], 'role_id': b528_, 'uid': z0JD[B[440082]], 'role_name': dotyze, 'role_type': kzdo, 'level': b85_, 'evolution': _58rk });
}, window['z0YD0'] = function (yzte) {}, window['z00Y'] = function (inl3) {
  zfn6l4v[B[440212]](B[440212], function ($iqm) {
    inl3 && inl3($iqm);
  });
}, window[B[440213]] = function () {
  zfn6l4v[B[440213]]();
}, window[B[440214]] = function () {
  zfn6l4v[B[440215]]();
}, window[B[440216]] = function (qm3ji$, f6hp, u2_5rw, g49p1, nf6lv, fgh, _b5r82, gfp64v) {
  gfp64v = gfp64v || z0JD[B[440030]][B[440084]], sendApi(z0JD[B[440015]], B[440217], { 'phone': qm3ji$, 'role_id': f6hp, 'uid': z0JD[B[440082]], 'game_pkg': z0JD[B[440024]], 'partner_id': z0JD[B[440023]], 'server_id': gfp64v }, _b5r82);
}, window[B[440218]] = function (aozes) {
  window['z0D0Y'] = aozes, window['z0D0Y'] && window['z0Y0'] && (console[B[440070]](B[440219] + window['z0Y0'][B[440220]]), window['z0D0Y'](window['z0Y0']), window['z0Y0'] = null);
}, window['z0DY0'] = function (n7lmv, i7flvn, kytdz, zated) {
  window[B[440221]](B[440222], { 'game_pkg': window['z0JD'][B[440024]], 'role_id': i7flvn, 'server_id': kytdz }, zated);
}, window['z0J0YD'] = function (a91s, _uwr) {
  function dyokb(inq73m) {
    var oezd = [],
        e9xsa1 = [],
        g4lf6v = window[B[440002]][B[440223]];for (var inflv7 in g4lf6v) {
      var minq3 = Number(inflv7);(!a91s || !a91s[B[440167]] || a91s[B[440142]](minq3) != -0x1) && (e9xsa1[B[440224]](g4lf6v[inflv7]), oezd[B[440224]]([minq3, 0x3]));
    }window['z0RYD0J'](window[B[440225]], B[440226]) >= 0x0 ? (console[B[440049]](B[440227]), zfn6l4v[B[440228]] && zfn6l4v[B[440228]](e9xsa1, function (rk_) {
      console[B[440049]](B[440229]), console[B[440049]](rk_);if (rk_ && rk_[B[440141]] == B[440230]) for (var lnfi7v in g4lf6v) {
        if (rk_[g4lf6v[lnfi7v]] == B[440231]) {
          var i37$qm = Number(lnfi7v);for (var adte = 0x0; adte < oezd[B[440167]]; adte++) {
            if (oezd[adte][0x0] == i37$qm) {
              oezd[adte][0x1] = 0x1;break;
            }
          }
        }
      }window['z0RYD0J'](window[B[440225]], B[440232]) >= 0x0 ? wx[B[440233]]({ 'withSubscriptions': !![], 'success': function (hgf6) {
          var sxe19a = hgf6[B[440234]][B[440235]];if (sxe19a) {
            console[B[440049]](B[440236]), console[B[440049]](sxe19a);for (var d8kbr in g4lf6v) {
              if (sxe19a[g4lf6v[d8kbr]] == B[440231]) {
                var v4g6p = Number(d8kbr);for (var ah91 = 0x0; ah91 < oezd[B[440167]]; ah91++) {
                  if (oezd[ah91][0x0] == v4g6p) {
                    oezd[ah91][0x1] = 0x2;break;
                  }
                }
              }
            }console[B[440049]](oezd), _uwr && _uwr(oezd);
          } else console[B[440049]](B[440237]), console[B[440049]](hgf6), console[B[440049]](oezd), _uwr && _uwr(oezd);
        }, 'fail': function () {
          console[B[440049]](B[440238]), console[B[440049]](oezd), _uwr && _uwr(oezd);
        } }) : (console[B[440049]](B[440239] + window[B[440225]]), console[B[440049]](oezd), _uwr && _uwr(oezd));
    })) : (console[B[440049]](B[440240] + window[B[440225]]), console[B[440049]](oezd), _uwr && _uwr(oezd)), wx[B[440241]](dyokb);
  }wx[B[440242]](dyokb);
}, window['z0J0DY'] = { 'isSuccess': ![], 'level': B[440243], 'isCharging': ![] }, window['z0JY0D'] = function (yezodt) {
  wx[B[440244]]({ 'success': function (h1x9sp) {
      var m7$qi = window['z0J0DY'];m7$qi[B[440245]] = !![], m7$qi[B[440246]] = Number(h1x9sp[B[440246]])[B[440247]](0x0), m7$qi[B[440248]] = h1x9sp[B[440248]], yezodt && yezodt(m7$qi[B[440245]], m7$qi[B[440246]], m7$qi[B[440248]]);
    }, 'fail': function (vpf6) {
      console[B[440049]](B[440249], vpf6[B[440141]]);var ifnv7l = window['z0J0DY'];yezodt && yezodt(ifnv7l[B[440245]], ifnv7l[B[440246]], ifnv7l[B[440248]]);
    } });
}, window[B[440221]] = function (bk, azeodt, b8_5r, y8dbo, hx9p1g, ydtzk, oteazs, vfp4) {
  if (y8dbo == undefined) y8dbo = 0x1;wx[B[440099]]({ 'url': bk, 'method': oteazs || B[440250], 'responseType': B[440251], 'data': azeodt, 'header': { 'content-type': vfp4 || B[440101] }, 'success': function (hs9x1p) {
      DEBUG && console[B[440049]](B[440252], bk, info, hs9x1p);if (hs9x1p && hs9x1p[B[440253]] == 0xc8) {
        var br5k_ = hs9x1p[B[440068]];!ydtzk || ydtzk(br5k_) ? b8_5r && b8_5r(br5k_) : window[B[440254]](bk, azeodt, b8_5r, y8dbo, hx9p1g, ydtzk, hs9x1p);
      } else window[B[440254]](bk, azeodt, b8_5r, y8dbo, hx9p1g, ydtzk, hs9x1p);
    }, 'fail': function (ahxs) {
      DEBUG && console[B[440049]](B[440255], bk, info, ahxs), window[B[440254]](bk, azeodt, b8_5r, y8dbo, hx9p1g, ydtzk, ahxs);
    }, 'complete': function () {} });
}, window[B[440254]] = function (i7ln3, ifnlv7, hp41g, _w5u02, ur5w2, livnf, ni3q7) {
  _w5u02 - 0x1 > 0x0 ? setTimeout(function () {
    window[B[440221]](i7ln3, ifnlv7, hp41g, _w5u02 - 0x1, ur5w2, livnf);
  }, 0x3e8) : ur5w2 && ur5w2(JSON[B[440087]]({ 'url': i7ln3, 'response': ni3q7 }));
}, window[B[440256]] = function (lni7m3, hg9x1p, xs19ah, phg1, f7nv6, dtbko, atzso) {
  !xs19ah && (xs19ah = {});var bykodt = Math[B[440257]](Date[B[440036]]() / 0x3e8);xs19ah[B[440162]] = bykodt, xs19ah[B[440258]] = hg9x1p;var estzx = Object[B[440259]](xs19ah)[B[440260]](),
      eszaxt = '',
      h4gp61 = '';for (var aotzed = 0x0; aotzed < estzx[B[440167]]; aotzed++) {
    eszaxt = eszaxt + (aotzed == 0x0 ? '' : '&') + estzx[aotzed] + xs19ah[estzx[aotzed]], h4gp61 = h4gp61 + (aotzed == 0x0 ? '' : '&') + estzx[aotzed] + '=' + encodeURIComponent(xs19ah[estzx[aotzed]]);
  }eszaxt = eszaxt + z0JD[B[440021]];var _bk = B[440261] + md5(eszaxt);send(lni7m3 + '?' + h4gp61 + (h4gp61 == '' ? '' : '&') + _bk, null, phg1, f7nv6, dtbko, atzso || function (ilm3n7) {
    return ilm3n7[B[440069]] == B[440154];
  }, null, B[440262]);
}, window['z0JYD0'] = function (k5r8b_, vflni) {
  var q7mn3 = 0x0;z0JD[B[440030]] && (q7mn3 = z0JD[B[440030]][B[440084]]), sendApi(z0JD[B[440017]], B[440263], { 'partnerId': z0JD[B[440023]], 'gamePkg': z0JD[B[440024]], 'logTime': Math[B[440257]](Date[B[440036]]() / 0x3e8), 'platformUid': z0JD[B[440158]], 'type': k5r8b_, 'serverId': q7mn3 }, null, 0x2, null, function () {
    return !![];
  });
}, window['z0JD0Y'] = function (eotza) {
  sendApi(z0JD[B[440015]], B[440264], { 'partner_id': z0JD[B[440023]], 'uid': z0JD[B[440082]], 'version': z0JD[B[440010]], 'game_pkg': z0JD[B[440024]], 'device': z0JD[B[440025]] }, z0JDY0, z0YDJ, z0D0);
}, window['z0JDY0'] = function (odtyb) {
  if (odtyb[B[440069]] === B[440154] && odtyb[B[440068]]) {
    odtyb[B[440068]][B[440265]]({ 'id': -0x2, 'name': B[440266] }), odtyb[B[440068]][B[440265]]({ 'id': -0x1, 'name': B[440267] }), z0JD[B[440268]] = odtyb[B[440068]];if (window[B[440269]]) window[B[440269]][B[440270]]();
  } else z0JD[B[440271]] = ![], window['z00YJD'](B[440272] + odtyb[B[440069]]);
}, window['z00YJ'] = function (a1hx9) {
  sendApi(z0JD[B[440015]], B[440273], { 'partner_id': z0JD[B[440023]], 'uid': z0JD[B[440082]], 'version': z0JD[B[440010]], 'game_pkg': z0JD[B[440024]], 'device': z0JD[B[440025]] }, z00JY, z0YDJ, z0D0);
}, window['z00JY'] = function (nv6fl4) {
  z0JD[B[440274]] = ![];if (nv6fl4[B[440069]] === B[440154] && nv6fl4[B[440068]]) {
    for (var zetsx = 0x0; zetsx < nv6fl4[B[440068]][B[440167]]; zetsx++) {
      nv6fl4[B[440068]][zetsx][B[440175]] = z0JY0(nv6fl4[B[440068]][zetsx]);
    }z0JD[B[440027]][-0x1] = window[B[440275]](nv6fl4[B[440068]]), window[B[440269]][B[440276]](-0x1);
  } else window['z00YJD'](B[440277] + nv6fl4[B[440069]]);
}, window[B[440278]] = function (ybk8od) {
  sendApi(z0JD[B[440015]], B[440273], { 'partner_id': z0JD[B[440023]], 'uid': z0JD[B[440082]], 'version': z0JD[B[440010]], 'game_pkg': z0JD[B[440024]], 'device': z0JD[B[440025]] }, ybk8od, z0YDJ, z0D0);
}, window['z0Y0J'] = function (qi3m$, lfi7v) {
  sendApi(z0JD[B[440015]], B[440279], { 'partner_id': z0JD[B[440023]], 'uid': z0JD[B[440082]], 'version': z0JD[B[440010]], 'game_pkg': z0JD[B[440024]], 'device': z0JD[B[440025]], 'server_group_id': lfi7v }, z0YJ0, z0YDJ, z0D0);
}, window['z0YJ0'] = function (qj3i$) {
  z0JD[B[440274]] = ![];if (qj3i$[B[440069]] === B[440154] && qj3i$[B[440068]] && qj3i$[B[440068]][B[440068]]) {
    var astoz = qj3i$[B[440068]][B[440280]],
        pxs1 = [];for (var b8y = 0x0; b8y < qj3i$[B[440068]][B[440068]][B[440167]]; b8y++) {
      qj3i$[B[440068]][B[440068]][b8y][B[440175]] = z0JY0(qj3i$[B[440068]][B[440068]][b8y]), (pxs1[B[440167]] == 0x0 || qj3i$[B[440068]][B[440068]][b8y][B[440175]] != 0x0) && (pxs1[pxs1[B[440167]]] = qj3i$[B[440068]][B[440068]][b8y]);
    }z0JD[B[440027]][astoz] = window[B[440275]](pxs1), window[B[440269]][B[440276]](astoz);
  } else window['z00YJD'](B[440281] + qj3i$[B[440069]]);
}, window['z0RYDJ'] = function (mi73) {
  sendApi(z0JD[B[440015]], B[440282], { 'partner_id': z0JD[B[440023]], 'uid': z0JD[B[440082]], 'version': z0JD[B[440010]], 'game_pkg': z0JD[B[440024]], 'device': z0JD[B[440025]] }, reqServerRecommendCallBack, z0YDJ, z0D0);
}, window[B[440283]] = function (i7vn) {
  z0JD[B[440274]] = ![];if (i7vn[B[440069]] === B[440154] && i7vn[B[440068]]) {
    for (var g4lvf = 0x0; g4lvf < i7vn[B[440068]][B[440167]]; g4lvf++) {
      i7vn[B[440068]][g4lvf][B[440175]] = z0JY0(i7vn[B[440068]][g4lvf]);
    }z0JD[B[440027]][-0x2] = window[B[440275]](i7vn[B[440068]]), window[B[440269]][B[440276]](-0x2);
  } else alert(B[440284] + i7vn[B[440069]]);
}, window[B[440275]] = function (hg6f4) {
  if (!hg6f4 && hg6f4[B[440167]] <= 0x0) return hg6f4;for (let jim3q$ = 0x0; jim3q$ < hg6f4[B[440167]]; jim3q$++) {
    hg6f4[jim3q$][B[440285]] && hg6f4[jim3q$][B[440285]] == 0x1 && (hg6f4[jim3q$][B[440171]] += B[440286]);
  }return hg6f4;
}, window['z0J0Y'] = function (gh91x, jim) {
  gh91x = gh91x || z0JD[B[440030]][B[440084]], sendApi(z0JD[B[440015]], B[440287], { 'type': '4', 'game_pkg': z0JD[B[440024]], 'server_id': gh91x }, jim);
}, window[B[440288]] = function (hgxp9, s9, xa91h, _5r8) {
  xa91h = xa91h || z0JD[B[440030]][B[440084]], sendApi(z0JD[B[440015]], B[440289], { 'type': hgxp9, 'game_pkg': s9, 'server_id': xa91h }, _5r8);
}, window['z0JY0'] = function (oetyzd) {
  if (oetyzd) {
    if (oetyzd[B[440175]] == 0x1) {
      if (oetyzd[B[440290]] == 0x1) return 0x2;else return 0x1;
    } else return oetyzd[B[440175]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['z0D0YJ'] = function (iq37nm, livmn7) {
  z0JD[B[440291]] = { 'step': iq37nm, 'server_id': livmn7 };var y_krb8 = this;z00JYD({ 'title': B[440292] }), sendApi(z0JD[B[440015]], B[440293], { 'partner_id': z0JD[B[440023]], 'uid': z0JD[B[440082]], 'game_pkg': z0JD[B[440024]], 'server_id': livmn7, 'platform': z0JD[B[440157]], 'platform_uid': z0JD[B[440158]], 'check_login_time': z0JD[B[440161]], 'check_login_sign': z0JD[B[440159]], 'version_name': z0JD[B[440127]] }, z0D0JY, z0YDJ, z0D0, function (k_8yr) {
    return k_8yr[B[440069]] == B[440154] || k_8yr[B[440070]] == B[440294] || k_8yr[B[440070]] == B[440295];
  });
}, window['z0D0JY'] = function (xgh1) {
  var inq7 = this;if (xgh1[B[440069]] === B[440154] && xgh1[B[440068]]) {
    var ilm7n = z0JD[B[440030]];ilm7n[B[440296]] = z0JD[B[440028]], ilm7n[B[440160]] = String(xgh1[B[440068]][B[440297]]), ilm7n[B[440035]] = parseInt(xgh1[B[440068]][B[440162]]);if (xgh1[B[440068]][B[440298]]) ilm7n[B[440298]] = parseInt(xgh1[B[440068]][B[440298]]);else ilm7n[B[440298]] = parseInt(xgh1[B[440068]][B[440084]]);ilm7n[B[440299]] = 0x0, ilm7n[B[440083]] = z0JD[B[440186]], ilm7n[B[440300]] = xgh1[B[440068]][B[440301]], ilm7n[B[440302]] = xgh1[B[440068]][B[440302]], console[B[440049]](B[440303] + JSON[B[440087]](ilm7n[B[440302]])), z0JD[B[440169]] == 0x1 && ilm7n[B[440302]] && ilm7n[B[440302]][B[440304]] == 0x1 && (z0JD[B[440305]] = 0x1, window[B[440065]][B[440066]]['z0RDJ']()), z0DY0J();
  } else z0JD[B[440291]][B[440306]] >= 0x3 ? (z0D0(JSON[B[440087]](xgh1)), window['z00YJD'](B[440307] + xgh1[B[440069]])) : sendApi(z0JD[B[440015]], B[440139], { 'platform': z0JD[B[440013]], 'partner_id': z0JD[B[440023]], 'token': z0JD[B[440137]], 'game_pkg': z0JD[B[440024]], 'deviceId': z0JD[B[440025]], 'scene': B[440140] + z0JD[B[440026]] }, function (lf6n4) {
    if (!lf6n4 || lf6n4[B[440069]] != B[440154]) {
      window['z00YJD'](B[440155] + lf6n4 && lf6n4[B[440069]]);return;
    }z0JD[B[440159]] = String(lf6n4[B[440160]]), z0JD[B[440161]] = String(lf6n4[B[440162]]), setTimeout(function () {
      z0D0YJ(z0JD[B[440291]][B[440306]] + 0x1, z0JD[B[440291]][B[440084]]);
    }, 0x5dc);
  }, z0YDJ, z0D0, function (pf46h) {
    return pf46h[B[440069]] == B[440154] || pf46h[B[440069]] == B[440308];
  });
}, window['z0DY0J'] = function () {
  ServerLoading[B[440066]][B[440178]](z0JD[B[440169]]), window['z0YD'] = !![], window['z0DJ0Y']();
}, window['z0DYJ0'] = function () {
  if (window['z0DY'] && window['z0JYD'] && window[B[440046]] && window[B[440047]] && window['z0JDY'] && window['z0JY']) {
    if (!window[B[440309]][B[440066]]) {
      console[B[440049]](B[440310] + window[B[440309]][B[440066]]);var dok8b = wx[B[440311]](),
          r8kdby = dok8b[B[440220]] ? dok8b[B[440220]] : 0x0,
          q3m$ij = { 'cdn': window['z0JD'][B[440083]], 'spareCdn': window['z0JD'][B[440125]], 'newRegister': window['z0JD'][B[440169]], 'wxPC': window['z0JD'][B[440045]], 'wxIOS': window['z0JD'][B[440043]], 'wxAndroid': window['z0JD'][B[440044]], 'wxParam': { 'limitLoad': window['z0JD']['z0R0YDJ'], 'benchmarkLevel': window['z0JD']['z0R0JYD'], 'wxFrom': window[B[440002]][B[440132]] == B[440312] ? 0x1 : 0x0, 'wxSDKVersion': window[B[440225]] }, 'configType': window['z0JD'][B[440037]], 'exposeType': window['z0JD'][B[440039]], 'scene': r8kdby };new window[B[440309]](q3m$ij, window['z0JD'][B[440041]], window['z0R0YJD']);
    }
  }
}, window['z0DJ0Y'] = function () {
  if (window['z0DY'] && window['z0JYD'] && window[B[440046]] && window[B[440047]] && window['z0JDY'] && window['z0JY'] && window['z0YD'] && window['z0YJ']) {
    z00JDY();if (!z0DYJ) {
      z0DYJ = !![];if (!window[B[440309]][B[440066]]) window['z0DYJ0']();var ph1s9 = 0x0,
          n3mi = wx[B[440313]]();n3mi && (window['z0JD'][B[440314]] && (ph1s9 = n3mi[B[440315]]), console[B[440070]](B[440316] + n3mi[B[440315]] + B[440317] + n3mi[B[440318]] + B[440319] + n3mi[B[440320]] + B[440321] + n3mi[B[440322]] + B[440323] + n3mi[B[440324]] + B[440325] + n3mi[B[440326]]));var $3qj = {};for (const r_58kb in z0JD[B[440030]]) {
        $3qj[r_58kb] = z0JD[B[440030]][r_58kb];
      }var r258_ = { 'channel': window['z0JD'][B[440029]], 'account': window['z0JD'][B[440082]], 'userId': window['z0JD'][B[440156]], 'serverId': $3qj[B[440084]], 'cdn': window['z0JD'][B[440083]], 'data': window['z0JD'][B[440068]], 'package': window['z0JD'][B[440009]], 'newRegister': window['z0JD'][B[440169]], 'pkgName': window['z0JD'][B[440024]], 'partnerId': window['z0JD'][B[440023]], 'platform_uid': window['z0JD'][B[440158]], 'deviceId': window['z0JD'][B[440025]], 'selectedServer': $3qj, 'configType': window['z0JD'][B[440037]], 'exposeType': window['z0JD'][B[440039]], 'debugUsers': window['z0JD'][B[440033]], 'wxMenuTop': ph1s9, 'wxShield': window['z0JD'][B[440042]] };if (window[B[440189]]) for (var yo8k in window[B[440189]]) {
        r258_[yo8k] = window[B[440189]][yo8k];
      }window[B[440309]][B[440066]]['z0DJR'](r258_);
    }
  } else console[B[440070]](B[440327] + window['z0DY'] + B[440328] + window['z0JYD'] + B[440329] + window[B[440046]] + B[440330] + window[B[440047]] + B[440331] + window['z0JDY'] + B[440332] + window['z0JY'] + B[440333] + window['z0YD'] + B[440334] + window['z0YJ']);
};