var B = wx.$z;
import ztyeozd from '../zzabzzsdk/z7sdkz.js';window[B[440001]] = { 'wxVersion': window[B[440002]][B[440003]] }, window[B[440004]] = ![], window[B[440005]] = 0x1, window[B[440006]] = 0x1, window[B[440007]] = !![], window[B[440008]] = !![], window[B[440009]] = '', window[B[440010]] = ![], window[B[440011]] = { 'base_cdn': B[440012], 'cdn': B[440012] }, z0JD[B[440013]] = {}, z0JD[B[440014]] = '0', z0JD[B[440015]] = window[B[440001]][B[440016]], z0JD[B[440017]] = '', z0JD['os'] = '1', z0JD[B[440018]] = B[440019], z0JD[B[440020]] = B[440021], z0JD[B[440022]] = B[440023], z0JD[B[440024]] = B[440025], z0JD[B[440026]] = B[440027], z0JD[B[440028]] = '1', z0JD[B[440029]] = '', z0JD[B[440030]] = '', z0JD[B[440031]] = 0x0, z0JD[B[440032]] = {}, z0JD[B[440033]] = parseInt(z0JD[B[440028]]), z0JD[B[440034]] = z0JD[B[440028]], z0JD[B[440035]] = {}, z0JD[B[440036]] = B[440037], z0JD[B[440038]] = ![], z0JD[B[440039]] = B[440040], z0JD[B[440041]] = Date[B[440042]](), z0JD[B[440043]] = B[440044], z0JD[B[440045]] = '_a', z0JD[B[440046]] = 0x2, z0JD[B[440047]] = 0x7c1, z0JD[B[440016]] = window[B[440001]][B[440016]], z0JD[B[440048]] = ![], z0JD[B[440049]] = ![], z0JD[B[440050]] = ![], z0JD[B[440051]] = ![], window[B[440052]] = 0x5, window[B[440053]] = ![], window[B[440054]] = ![], window[B[440055]] = ![], window[B[440056]] = ![], window[B[440057]] = ![], window[B[440058]] = ![], window[B[440059]] = ![], window[B[440060]] = ![], window[B[440061]] = ![], window[B[440062]] = null, window[B[440063]] = function (kr8_y) {
  console[B[440064]](B[440063], kr8_y), wx[B[440065]]({}), wx[B[440066]]({ 'title': B[440067], 'content': kr8_y, 'success'(kybo8) {
      if (kybo8[B[440068]]) console[B[440064]](B[440069]);else kybo8[B[440070]] && console[B[440064]](B[440071]);
    } });
}, window[B[440072]] = function (ykdbo) {
  console[B[440064]](B[440073], ykdbo), z00JDY(), wx[B[440066]]({ 'title': B[440067], 'content': ykdbo, 'confirmText': B[440074], 'cancelText': B[440075], 'success'(astxez) {
      if (astxez[B[440068]]) window[B[440076]]();else astxez[B[440070]] && (console[B[440064]](B[440077]), wx[B[440078]]({}));
    } });
}, window[B[440079]] = function (fl6gv4) {
  console[B[440064]](B[440079], fl6gv4), wx[B[440066]]({ 'title': B[440067], 'content': fl6gv4, 'confirmText': B[440080], 'showCancel': ![], 'complete'(kzytdo) {
      console[B[440064]](B[440077]), wx[B[440078]]({});
    } });
}, window[B[440081]] = ![], window[B[440082]] = function (_u5wr2) {
  window[B[440081]] = !![], wx[B[440083]](_u5wr2);
}, window[B[440084]] = function () {
  window[B[440081]] && (window[B[440081]] = ![], wx[B[440065]]({}));
}, window[B[440085]] = function (sxh) {
  window[B[440086]][B[440087]][B[440085]](sxh);
}, window[B[440088]] = function (iqm$j3, dbry8) {
  ztyeozd[B[440088]](iqm$j3, function (kb8r5) {
    kb8r5 && kb8r5[B[440089]] ? kb8r5[B[440089]][B[440090]] == 0x1 ? dbry8(!![]) : (dbry8(![]), console[B[440091]](B[440092] + kb8r5[B[440089]][B[440093]])) : console[B[440064]](B[440088], kb8r5);
  });
}, window[B[440094]] = function (zokytd) {
  console[B[440064]](B[440095], zokytd);
}, window[B[440096]] = function (q7m3i) {}, window[B[440097]] = function (g4hp6f, sza9xe, a1exs) {}, window[B[440098]] = function (j3qim) {
  console[B[440064]](B[440099], j3qim), window[B[440086]][B[440087]][B[440100]](), window[B[440086]][B[440087]][B[440101]](), window[B[440086]][B[440087]][B[440102]]();
}, window[B[440103]] = function (nlvm7i) {
  window[B[440104]](0xe, B[440105] + nlvm7i), window[B[440072]](B[440106]);var lin73 = { 'id': window[B[440011]][B[440107]], 'role': window[B[440011]][B[440108]], 'level': window[B[440011]][B[440109]], 'account': window[B[440011]][B[440110]], 'version': window[B[440011]][B[440047]], 'cdn': window[B[440011]][B[440111]], 'pkgName': window[B[440011]][B[440029]], 'gamever': window[B[440002]][B[440003]], 'serverid': window[B[440011]][B[440035]] ? window[B[440011]][B[440035]][B[440112]] : 0x0, 'systemInfo': window[B[440113]], 'error': B[440114], 'stack': nlvm7i ? nlvm7i : B[440106] },
      xh9sp = JSON[B[440115]](lin73);console[B[440116]](B[440117] + xh9sp), window[B[440036]](xh9sp);
}, window[B[440104]] = function (m3ln7, eaostz) {
  sendApi(z0JD[B[440022]], B[440118], { 'game_pkg': z0JD[B[440029]], 'partner_id': z0JD[B[440028]], 'server_id': z0JD[B[440035]] && z0JD[B[440035]][B[440112]] > 0x0 ? z0JD[B[440035]][B[440112]] : 0x0, 'uid': z0JD[B[440110]] > 0x0 ? z0JD[B[440110]] : 0x0, 'type': m3ln7, 'info': eaostz });
}, window[B[440119]] = function (im$q3) {
  var v7lf = JSON[B[440120]](im$q3);v7lf[B[440121]] = window[B[440002]][B[440003]], v7lf[B[440122]] = window[B[440011]][B[440035]] ? window[B[440011]][B[440035]][B[440112]] : 0x0, v7lf[B[440113]] = window[B[440113]];var xsa9h1 = JSON[B[440115]](v7lf);console[B[440116]](B[440123] + xsa9h1), window[B[440036]](xsa9h1);
}, window[B[440124]] = function (deaz, m7il3) {
  var gp94 = { 'id': window[B[440011]][B[440107]], 'role': window[B[440011]][B[440108]], 'level': window[B[440011]][B[440109]], 'account': window[B[440011]][B[440110]], 'version': window[B[440011]][B[440047]], 'cdn': window[B[440011]][B[440111]], 'pkgName': window[B[440011]][B[440029]], 'gamever': window[B[440002]][B[440003]], 'serverid': window[B[440011]][B[440035]] ? window[B[440011]][B[440035]][B[440112]] : 0x0, 'systemInfo': window[B[440113]], 'error': deaz, 'stack': m7il3 },
      ijm = JSON[B[440115]](gp94);console[B[440125]](B[440126] + ijm), window[B[440036]](ijm);
}, window[B[440036]] = function (tdeoa) {
  if (window[B[440011]][B[440127]] == B[440128]) return;var qimj3$ = z0JD[B[440036]] + B[440129] + z0JD[B[440110]];wx[B[440130]]({ 'url': qimj3$, 'method': B[440131], 'data': tdeoa, 'header': { 'content-type': B[440132], 'cache-control': B[440133] }, 'success': function (qi$3) {
      DEBUG && console[B[440064]](B[440134], qimj3$, tdeoa, qi$3);
    }, 'fail': function (pxh19) {
      DEBUG && console[B[440064]](B[440134], qimj3$, tdeoa, pxh19);
    }, 'complete': function () {} });
}, window[B[440135]] = function () {
  function iqmn37() {
    return ((0x1 + Math[B[440136]]()) * 0x10000 | 0x0)[B[440137]](0x10)[B[440138]](0x1);
  }return iqmn37() + iqmn37() + '-' + iqmn37() + '-' + iqmn37() + '-' + iqmn37() + '+' + iqmn37() + iqmn37() + iqmn37();
}, window[B[440076]] = function () {
  console[B[440064]](B[440139]);var i3jm$ = ztyeozd[B[440140]]();z0JD[B[440034]] = i3jm$[B[440141]], z0JD[B[440033]] = i3jm$[B[440141]], z0JD[B[440028]] = i3jm$[B[440141]], z0JD[B[440029]] = i3jm$[B[440142]];var lnfv67 = { 'game_ver': z0JD[B[440015]] };z0JD[B[440030]] = this[B[440135]](), z00JYD({ 'title': B[440143] }), ztyeozd[B[440144]](lnfv67, this[B[440145]][B[440146]](this));
}, window[B[440145]] = function (oetsaz) {
  var h91xa = oetsaz[B[440147]];sdkInitRes = oetsaz, console[B[440064]](B[440148] + h91xa + B[440149] + (h91xa == 0x1) + B[440150] + oetsaz[B[440003]] + B[440151] + window[B[440001]][B[440016]]);if (!oetsaz[B[440003]] || window[B[440152]](window[B[440001]][B[440016]], oetsaz[B[440003]]) < 0x0) console[B[440064]](B[440153]), z0JD[B[440020]] = B[440154], z0JD[B[440022]] = B[440155], z0JD[B[440024]] = B[440156], z0JD[B[440111]] = B[440157], z0JD[B[440158]] = B[440159], z0JD[B[440160]] = 'fj', z0JD[B[440048]] = ![];else window[B[440152]](window[B[440001]][B[440016]], oetsaz[B[440003]]) == 0x0 ? (console[B[440064]](B[440161]), z0JD[B[440020]] = B[440021], z0JD[B[440022]] = B[440023], z0JD[B[440024]] = B[440025], z0JD[B[440111]] = B[440162], z0JD[B[440158]] = B[440159], z0JD[B[440160]] = B[440163], z0JD[B[440048]] = !![]) : (console[B[440064]](B[440164]), z0JD[B[440020]] = B[440021], z0JD[B[440022]] = B[440023], z0JD[B[440024]] = B[440025], z0JD[B[440111]] = B[440162], z0JD[B[440158]] = B[440159], z0JD[B[440160]] = B[440163], z0JD[B[440048]] = ![]);z0JD[B[440031]] = config[B[440165]] ? config[B[440165]] : 0x0, this[B[440166]](), this[B[440167]](), window[B[440168]] = 0x5, z00JYD({ 'title': B[440169] }), ztyeozd[B[440170]](this[B[440171]][B[440146]](this));
}, window[B[440168]] = 0x5, window[B[440171]] = function (r_kb5, zoes) {
  if (r_kb5 == 0x0 && zoes && zoes[B[440172]]) {
    z0JD[B[440173]] = zoes[B[440172]];var p1x9g = this;z00JYD({ 'title': B[440174] }), sendApi(z0JD[B[440020]], B[440175], { 'platform': z0JD[B[440018]], 'partner_id': z0JD[B[440028]], 'token': zoes[B[440172]], 'game_pkg': z0JD[B[440029]], 'deviceId': z0JD[B[440030]], 'scene': B[440176] + z0JD[B[440031]] }, this[B[440177]][B[440146]](this), z0YDJ, z0D0);
  } else zoes && zoes[B[440178]] && window[B[440168]] > 0x0 && (zoes[B[440178]][B[440179]](B[440180]) != -0x1 || zoes[B[440178]][B[440179]](B[440181]) != -0x1 || zoes[B[440178]][B[440179]](B[440182]) != -0x1 || zoes[B[440178]][B[440179]](B[440183]) != -0x1 || zoes[B[440178]][B[440179]](B[440184]) != -0x1 || zoes[B[440178]][B[440179]](B[440185]) != -0x1) ? (window[B[440168]]--, ztyeozd[B[440170]](this[B[440171]][B[440146]](this))) : (window[B[440104]](0x1, B[440186] + r_kb5 + B[440187] + (zoes ? zoes[B[440178]] : '')), window[B[440124]](B[440188], JSON[B[440115]]({ 'status': r_kb5, 'data': zoes })), window[B[440072]](B[440189] + (zoes && zoes[B[440178]] ? '，' + zoes[B[440178]] : '')));
}, window[B[440177]] = function (o8bkdy) {
  if (!o8bkdy) {
    window[B[440104]](0x2, B[440190]), window[B[440124]](B[440191], B[440192]), window[B[440072]](B[440193]);return;
  }if (o8bkdy[B[440090]] != B[440194]) {
    window[B[440104]](0x2, B[440195] + o8bkdy[B[440090]]), window[B[440124]](B[440191], JSON[B[440115]](o8bkdy)), window[B[440072]](B[440196] + o8bkdy[B[440090]]);return;
  }z0JD[B[440197]] = String(o8bkdy[B[440110]]), z0JD[B[440110]] = String(o8bkdy[B[440110]]), z0JD[B[440198]] = String(o8bkdy[B[440198]]), z0JD[B[440034]] = String(o8bkdy[B[440198]]), z0JD[B[440199]] = String(o8bkdy[B[440199]]), z0JD[B[440200]] = String(o8bkdy[B[440201]]), z0JD[B[440202]] = String(o8bkdy[B[440203]]), z0JD[B[440201]] = '';var kdzyot = this;z00JYD({ 'title': B[440204] });var xa1sh = localStorage[B[440205]](B[440206] + z0JD[B[440029]] + z0JD[B[440110]]);if (xa1sh && xa1sh != '') {
    var eyo = Number(xa1sh);kdzyot[B[440207]](eyo);
  } else kdzyot[B[440208]]();
}, window[B[440208]] = function () {
  var k_85rb = this;sendApi(z0JD[B[440020]], B[440209], { 'partner_id': z0JD[B[440028]], 'uid': z0JD[B[440110]], 'version': z0JD[B[440015]], 'game_pkg': z0JD[B[440029]], 'device': z0JD[B[440030]] }, k_85rb[B[440210]][B[440146]](k_85rb), z0YDJ, z0D0);
}, window[B[440210]] = function (eatz) {
  if (!eatz) {
    window[B[440104]](0x3, B[440211]), window[B[440072]](B[440211]);return;
  }if (eatz[B[440090]] != B[440194]) {
    window[B[440104]](0x3, B[440212] + eatz[B[440090]]), window[B[440072]](B[440212] + eatz[B[440090]]);return;
  }if (!eatz[B[440089]] || eatz[B[440089]][B[440213]] == 0x0) {
    window[B[440104]](0x3, B[440214]), window[B[440072]](B[440215]);return;
  }this[B[440216]](eatz);
}, window[B[440207]] = function (nf6l4) {
  var br_258 = this;sendApi(z0JD[B[440020]], B[440217], { 'server_id': nf6l4, 'time': Date[B[440042]]() / 0x3e8 }, br_258[B[440218]][B[440146]](br_258), z0YDJ, z0D0);
}, window[B[440218]] = function (etdzoa) {
  if (!etdzoa) {
    window[B[440104]](0x4, B[440219]), this[B[440208]]();return;
  }if (etdzoa[B[440090]] != B[440194]) {
    window[B[440104]](0x4, B[440220] + etdzoa[B[440090]]), this[B[440208]]();return;
  }if (!etdzoa[B[440089]] || etdzoa[B[440089]][B[440213]] == 0x0) {
    window[B[440104]](0x4, B[440221]), this[B[440208]]();return;
  }this[B[440216]](etdzoa), window[B[440086]] && window[B[440086]][B[440087]][B[440222]] && window[B[440086]][B[440087]][B[440222]](sdkInitRes[B[440223]], sdkInitRes[B[440224]], sdkInitRes[B[440225]], sdkInitRes[B[440226]], sdkInitRes[B[440227]]);
}, window[B[440216]] = function ($i3j) {
  z0JD[B[440228]] = $i3j[B[440229]] != undefined ? $i3j[B[440229]] : 0x0, z0JD[B[440035]] = { 'server_id': String($i3j[B[440089]][0x0][B[440112]]), 'server_name': String($i3j[B[440089]][0x0][B[440230]]), 'entry_ip': $i3j[B[440089]][0x0][B[440231]], 'entry_port': parseInt($i3j[B[440089]][0x0][B[440232]]), 'status': z0JY0($i3j[B[440089]][0x0]), 'start_time': $i3j[B[440089]][0x0][B[440233]], 'cdn': z0JD[B[440111]] }, this[B[440234]]();
}, window[B[440235]] = null, window[B[440234]] = function () {
  var _8kbry = this;ztyeozd[B[440236]](function (zkdot) {
    console[B[440064]](B[440237] + JSON[B[440115]](zkdot)), youYiCofig = zkdot;window[B[440235]][B[440238]] == 0x1 && (z0JD[B[440228]] = 0x0);if (z0JD[B[440228]] == 0x1) {
      var mi7$3 = z0JD[B[440035]][B[440239]];if (mi7$3 === -0x1 || mi7$3 === 0x0) {
        window[B[440104]](0xf, B[440240] + z0JD[B[440035]]['id'] + B[440241] + z0JD[B[440035]][B[440239]]), window[B[440072]](mi7$3 === -0x1 ? B[440242] : B[440243]);return;
      }z0D0YJ(0x0, z0JD[B[440035]][B[440112]]), window[B[440086]][B[440087]][B[440244]](z0JD[B[440228]]);
    } else window[B[440086]][B[440087]][B[440245]](() => {
      var odteyz = window[B[440235]][B[440246]],
          pg94h = window[B[440235]][B[440238]] == 0x1;pg94h && window[B[440086]][B[440087]][B[440247]](B[440248], odteyz, B[440249]);
    }, _8kbry), z00JDY();window[B[440060]] = !![], window[B[440250]](), window[B[440251]]();
  });
}, window[B[440252]] = function () {
  ztyeozd[B[440253]](function (tdyoz) {
    console[B[440064]](B[440254] + JSON[B[440115]](tdyoz));
  });
}, window[B[440166]] = function () {
  sendApi(z0JD[B[440020]], B[440255], { 'game_pkg': z0JD[B[440029]], 'version_name': z0JD[B[440160]] }, this[B[440256]][B[440146]](this), z0YDJ, z0D0);
}, window[B[440256]] = function (bdyo8k) {
  if (!bdyo8k) {
    window[B[440104]](0x5, B[440257]), window[B[440072]](B[440257]);return;
  }if (bdyo8k[B[440090]] != B[440194]) {
    window[B[440104]](0x5, B[440258] + bdyo8k[B[440090]]), window[B[440072]](B[440258] + bdyo8k[B[440090]]);return;
  }if (!bdyo8k[B[440089]] || !bdyo8k[B[440089]][B[440015]]) {
    window[B[440104]](0x5, B[440259] + (bdyo8k[B[440089]] && bdyo8k[B[440089]][B[440015]])), window[B[440072]](B[440259] + (bdyo8k[B[440089]] && bdyo8k[B[440089]][B[440015]]));return;
  }bdyo8k[B[440089]][B[440260]] && bdyo8k[B[440089]][B[440260]][B[440213]] > 0xa && (z0JD[B[440261]] = bdyo8k[B[440089]][B[440260]], z0JD[B[440111]] = bdyo8k[B[440089]][B[440260]]), bdyo8k[B[440089]][B[440015]] && (z0JD[B[440047]] = bdyo8k[B[440089]][B[440015]]), console[B[440091]](B[440262] + z0JD[B[440047]] + B[440263] + z0JD[B[440160]]), window[B[440058]] = !![], window[B[440250]](), window[B[440251]]();
}, window[B[440264]], window[B[440167]] = function () {
  sendApi(z0JD[B[440020]], B[440265], { 'game_pkg': z0JD[B[440029]] }, this[B[440266]][B[440146]](this), z0YDJ, z0D0);
}, window[B[440266]] = function (datz) {
  if (datz && datz[B[440090]] === B[440194] && datz[B[440089]]) {
    window[B[440264]] = datz[B[440089]];for (var mi$jq in datz[B[440089]]) {
      z0JD[mi$jq] = datz[B[440089]][mi$jq];
    }
  } else window[B[440104]](0xb, B[440267]), console[B[440091]](B[440268] + datz[B[440090]]);window[B[440059]] = !![], window[B[440251]]();
}, window[B[440269]] = function (zadeot, _20, n7fil, sextaz, vml7ni, a1h9, e9x1sa, zodety, kdztoy, hpg9) {
  vml7ni = String(vml7ni);var ln7miv = e9x1sa,
      pf4gv = zodety;z0JD[B[440013]][vml7ni] = { 'productid': vml7ni, 'productname': ln7miv, 'productdesc': pf4gv, 'roleid': zadeot, 'rolename': _20, 'rolelevel': n7fil, 'price': a1h9, 'callback': kdztoy }, sendApi(z0JD[B[440024]], B[440270], { 'game_pkg': z0JD[B[440029]], 'server_id': z0JD[B[440035]][B[440112]], 'server_name': z0JD[B[440035]][B[440230]], 'level': n7fil, 'uid': z0JD[B[440110]], 'role_id': zadeot, 'role_name': _20, 'product_id': vml7ni, 'product_name': ln7miv, 'product_desc': pf4gv, 'money': a1h9, 'partner_id': z0JD[B[440028]] }, toPayCallBack, z0YDJ, z0D0);
}, window[B[440271]] = function (ezsax) {
  if (ezsax && (ezsax[B[440272]] === 0xc8 || ezsax[B[440090]] == B[440194])) {
    var b258_ = z0JD[B[440013]][String(ezsax[B[440273]])];if (b258_[B[440274]]) b258_[B[440274]](ezsax[B[440273]], ezsax[B[440275]], -0x1);ztyeozd[B[440276]]({ 'cpbill': ezsax[B[440275]], 'productid': ezsax[B[440273]], 'productname': b258_[B[440277]], 'productdesc': b258_[B[440278]], 'serverid': z0JD[B[440035]][B[440112]], 'servername': z0JD[B[440035]][B[440230]], 'roleid': b258_[B[440279]], 'rolename': b258_[B[440280]], 'rolelevel': b258_[B[440281]], 'price': b258_[B[440282]], 'extension': JSON[B[440115]]({ 'cp_order_id': ezsax[B[440275]] }) }, function (sea1, ozaed) {
      b258_[B[440274]] && sea1 == 0x0 && b258_[B[440274]](ezsax[B[440273]], ezsax[B[440275]], sea1);console[B[440091]](JSON[B[440115]]({ 'type': B[440283], 'status': sea1, 'data': ezsax, 'role_name': b258_[B[440280]] }));if (sea1 === 0x0) {} else {
        if (sea1 === 0x1) {} else {
          if (sea1 === 0x2) {}
        }
      }
    });
  } else {
    var sahx19 = ezsax ? B[440284] + ezsax[B[440272]] + B[440285] + ezsax[B[440090]] + B[440286] + ezsax[B[440091]] : B[440287];window[B[440104]](0xd, B[440288] + sahx19), alert(sahx19);
  }
}, window[B[440289]] = function () {}, window[B[440290]] = function (dyo8k, pg419h, kybo, mjqi3, im7lv) {
  ztyeozd[B[440291]](z0JD[B[440035]][B[440112]], z0JD[B[440035]][B[440230]] || z0JD[B[440035]][B[440112]], dyo8k, pg419h, kybo), sendApi(z0JD[B[440020]], B[440292], { 'game_pkg': z0JD[B[440029]], 'server_id': z0JD[B[440035]][B[440112]], 'role_id': dyo8k, 'uid': z0JD[B[440110]], 'role_name': pg419h, 'role_type': mjqi3, 'level': kybo });
}, window[B[440293]] = function (l4nf6, e19xas, ktzd, nmlvi7, s1hxp9, rk8_, hsp19x, xh1pg9, etazo, kyotbd) {
  z0JD[B[440107]] = l4nf6, z0JD[B[440108]] = e19xas, z0JD[B[440109]] = ktzd, ztyeozd[B[440294]](z0JD[B[440035]][B[440112]], z0JD[B[440035]][B[440230]] || z0JD[B[440035]][B[440112]], l4nf6, e19xas, ktzd), sendApi(z0JD[B[440020]], B[440295], { 'game_pkg': z0JD[B[440029]], 'server_id': z0JD[B[440035]][B[440112]], 'role_id': l4nf6, 'uid': z0JD[B[440110]], 'role_name': e19xas, 'role_type': nmlvi7, 'level': ktzd, 'evolution': s1hxp9 });
}, window[B[440296]] = function (_b8kry, g6pvf, tzokyd, gp64fv, nim3l7, m$iq7, mlinv7, tsex, f6gvl4, i7nm3l) {
  z0JD[B[440107]] = _b8kry, z0JD[B[440108]] = g6pvf, z0JD[B[440109]] = tzokyd, ztyeozd[B[440297]](z0JD[B[440035]][B[440112]], z0JD[B[440035]][B[440230]] || z0JD[B[440035]][B[440112]], _b8kry, g6pvf, tzokyd), sendApi(z0JD[B[440020]], B[440295], { 'game_pkg': z0JD[B[440029]], 'server_id': z0JD[B[440035]][B[440112]], 'role_id': _b8kry, 'uid': z0JD[B[440110]], 'role_name': g6pvf, 'role_type': gp64fv, 'level': tzokyd, 'evolution': nim3l7 });
}, window[B[440298]] = function (dbyrk) {}, window[B[440299]] = function (xg9p1h) {
  ztyeozd[B[440300]](B[440300], function (iqnm) {
    xg9p1h && xg9p1h(iqnm);
  });
}, window[B[440301]] = function () {
  ztyeozd[B[440301]]();
}, window[B[440302]] = function () {
  ztyeozd[B[440303]]();
}, window[B[440304]] = function (x91hs, n4vf, ex19s, u_rw5, ydr8, limv, kbyd8o, _5b8) {
  _5b8 = _5b8 || z0JD[B[440035]][B[440112]], sendApi(z0JD[B[440020]], B[440305], { 'phone': x91hs, 'role_id': n4vf, 'uid': z0JD[B[440110]], 'game_pkg': z0JD[B[440029]], 'partner_id': z0JD[B[440028]], 'server_id': _5b8 }, kbyd8o, 0x2, null, function () {
    return !![];
  });
}, window[B[440306]] = function ($m3iq7) {
  window[B[440307]] = $m3iq7, window[B[440307]] && window[B[440308]] && (console[B[440091]](B[440309] + window[B[440308]][B[440310]]), window[B[440307]](window[B[440308]]), window[B[440308]] = null);
}, window[B[440311]] = function (botdy, il37mn, _u8r5, exats) {
  window[B[440312]](B[440313], { 'game_pkg': window[B[440011]][B[440029]], 'role_id': il37mn, 'server_id': _u8r5 }, exats);
}, window[B[440314]] = function (z9ae, k8_ry, bkyr_) {
  function oaedzt(oaztes) {
    var xp1s9 = [],
        f7vin = [],
        vgf4l6 = bkyr_ || window[B[440002]][B[440315]];for (var w_2ru5 in vgf4l6) {
      var _ry8bk = Number(w_2ru5);(!z9ae || !z9ae[B[440213]] || z9ae[B[440179]](_ry8bk) != -0x1) && (f7vin[B[440316]](vgf4l6[w_2ru5]), xp1s9[B[440316]]([_ry8bk, 0x3]));
    }window[B[440152]](window[B[440317]], B[440318]) >= 0x0 ? (console[B[440064]](B[440319]), ztyeozd[B[440320]] && ztyeozd[B[440320]](f7vin, function (tydkzo) {
      console[B[440064]](B[440321]), console[B[440064]](tydkzo);if (tydkzo && tydkzo[B[440178]] == B[440322]) for (var oatde in vgf4l6) {
        if (tydkzo[vgf4l6[oatde]] == B[440323]) {
          var kdobt = Number(oatde);for (var ahs9 = 0x0; ahs9 < xp1s9[B[440213]]; ahs9++) {
            if (xp1s9[ahs9][0x0] == kdobt) {
              xp1s9[ahs9][0x1] = 0x1;break;
            }
          }
        }
      }window[B[440152]](window[B[440317]], B[440324]) >= 0x0 ? wx[B[440325]]({ 'withSubscriptions': !![], 'success': function (k8ybrd) {
          var l3ni7m = k8ybrd[B[440326]][B[440327]];if (l3ni7m) {
            console[B[440064]](B[440328]), console[B[440064]](l3ni7m);for (var _2b in vgf4l6) {
              if (l3ni7m[vgf4l6[_2b]] == B[440323]) {
                var edzot = Number(_2b);for (var yzedot = 0x0; yzedot < xp1s9[B[440213]]; yzedot++) {
                  if (xp1s9[yzedot][0x0] == edzot) {
                    xp1s9[yzedot][0x1] = 0x2;break;
                  }
                }
              }
            }console[B[440064]](xp1s9), k8_ry && k8_ry(xp1s9);
          } else console[B[440064]](B[440329]), console[B[440064]](k8ybrd), console[B[440064]](xp1s9), k8_ry && k8_ry(xp1s9);
        }, 'fail': function () {
          console[B[440064]](B[440330]), console[B[440064]](xp1s9), k8_ry && k8_ry(xp1s9);
        } }) : (console[B[440064]](B[440331] + window[B[440317]]), console[B[440064]](xp1s9), k8_ry && k8_ry(xp1s9));
    })) : (console[B[440064]](B[440332] + window[B[440317]]), console[B[440064]](xp1s9), k8_ry && k8_ry(xp1s9)), wx[B[440333]](oaedzt);
  }wx[B[440334]](oaedzt);
}, window[B[440335]] = { 'isSuccess': ![], 'level': B[440336], 'isCharging': ![] }, window[B[440337]] = function (n7q) {
  wx[B[440338]]({ 'success': function (g6fh4) {
      var _w502u = window[B[440335]];_w502u[B[440339]] = !![], _w502u[B[440340]] = Number(g6fh4[B[440340]])[B[440341]](0x0), _w502u[B[440342]] = g6fh4[B[440342]], n7q && n7q(_w502u[B[440339]], _w502u[B[440340]], _w502u[B[440342]]);
    }, 'fail': function (j3mq$i) {
      console[B[440064]](B[440343], j3mq$i[B[440178]]);var nim7q = window[B[440335]];n7q && n7q(nim7q[B[440339]], nim7q[B[440340]], nim7q[B[440342]]);
    } });
}, window[B[440344]] = function (hpxg) {
  wx[B[440344]]({ 'success': function (k_ybr8) {
      hpxg && hpxg(!![], k_ybr8);
    }, 'fail': function (i3q$mj) {
      hpxg && hpxg(![], i3q$mj);
    } });
}, window[B[440345]] = function (ivfl) {
  if (ivfl) wx[B[440345]](ivfl);
}, window[B[440346]] = function (dybkr8) {
  wx[B[440346]](dybkr8);
}, window[B[440312]] = function (x9esz, nvlf4, ezoty, sph9x, zxes9a, a1esx9, v7mil, xea19s) {
  if (sph9x == undefined) sph9x = 0x1;wx[B[440130]]({ 'url': x9esz, 'method': v7mil || B[440347], 'responseType': B[440348], 'data': nvlf4, 'header': { 'content-type': xea19s || B[440132] }, 'success': function (gxp1h) {
      DEBUG && console[B[440064]](B[440349], x9esz, info, gxp1h);if (gxp1h && gxp1h[B[440350]] == 0xc8) {
        var p1xs = gxp1h[B[440089]];!a1esx9 || a1esx9(p1xs) ? ezoty && ezoty(p1xs) : window[B[440351]](x9esz, nvlf4, ezoty, sph9x, zxes9a, a1esx9, gxp1h);
      } else window[B[440351]](x9esz, nvlf4, ezoty, sph9x, zxes9a, a1esx9, gxp1h);
    }, 'fail': function (vf6p4) {
      DEBUG && console[B[440064]](B[440352], x9esz, info, vf6p4), window[B[440351]](x9esz, nvlf4, ezoty, sph9x, zxes9a, a1esx9, vf6p4);
    }, 'complete': function () {} });
}, window[B[440351]] = function (otbdk, e9sazx, yodzt, _w02u5, rw_u5, txzsea, sh91) {
  _w02u5 - 0x1 > 0x0 ? setTimeout(function () {
    window[B[440312]](otbdk, e9sazx, yodzt, _w02u5 - 0x1, rw_u5, txzsea);
  }, 0x3e8) : rw_u5 && rw_u5(JSON[B[440115]]({ 'url': otbdk, 'response': sh91 }));
}, window[B[440353]] = function (mqi37n, ytkzod, vilmn7, atsoze, m3n7q, _52wr, v6lf7n) {
  !vilmn7 && (vilmn7 = {});var mni73q = Math[B[440354]](Date[B[440042]]() / 0x3e8);vilmn7[B[440203]] = mni73q, vilmn7[B[440355]] = ytkzod;var rk8d = Object[B[440356]](vilmn7)[B[440357]](),
      p1h4g6 = '',
      tzse = '';for (var kd8r = 0x0; kd8r < rk8d[B[440213]]; kd8r++) {
    p1h4g6 = p1h4g6 + (kd8r == 0x0 ? '' : '&') + rk8d[kd8r] + vilmn7[rk8d[kd8r]], tzse = tzse + (kd8r == 0x0 ? '' : '&') + rk8d[kd8r] + '=' + encodeURIComponent(vilmn7[rk8d[kd8r]]);
  }p1h4g6 = p1h4g6 + z0JD[B[440026]];var rbk8y_ = B[440358] + md5(p1h4g6);send(mqi37n + '?' + tzse + (tzse == '' ? '' : '&') + rbk8y_, null, atsoze, m3n7q, _52wr, v6lf7n || function (gpf64v) {
    return gpf64v[B[440090]] == B[440194];
  }, null, B[440359]);
}, window[B[440360]] = function ($ji3q, _b8ky) {
  var _k5br8 = 0x0;z0JD[B[440035]] && (_k5br8 = z0JD[B[440035]][B[440112]]), sendApi(z0JD[B[440022]], B[440361], { 'partnerId': z0JD[B[440028]], 'gamePkg': z0JD[B[440029]], 'logTime': Math[B[440354]](Date[B[440042]]() / 0x3e8), 'platformUid': z0JD[B[440199]], 'type': $ji3q, 'serverId': _k5br8 }, null, 0x2, null, function () {
    return !![];
  });
}, window[B[440362]] = function (eatzx) {
  sendApi(z0JD[B[440020]], B[440363], { 'partner_id': z0JD[B[440028]], 'uid': z0JD[B[440110]], 'version': z0JD[B[440015]], 'game_pkg': z0JD[B[440029]], 'device': z0JD[B[440030]] }, z0JDY0, z0YDJ, z0D0);
}, window[B[440364]] = function (vi7mn) {
  if (vi7mn && vi7mn[B[440090]] === B[440194] && vi7mn[B[440089]]) {
    vi7mn[B[440089]][B[440365]]({ 'id': -0x2, 'name': B[440366] }), vi7mn[B[440089]][B[440365]]({ 'id': -0x1, 'name': B[440367] }), z0JD[B[440368]] = vi7mn[B[440089]];if (window[B[440369]]) window[B[440369]][B[440370]]();
  } else {
    z0JD[B[440371]] = ![];var g6lfv4 = vi7mn ? vi7mn[B[440090]] : '';window[B[440104]](0x7, B[440372] + g6lfv4), window[B[440072]](B[440373] + g6lfv4);
  }
}, window[B[440374]] = function (eodaz) {
  sendApi(z0JD[B[440020]], B[440375], { 'partner_id': z0JD[B[440028]], 'uid': z0JD[B[440110]], 'version': z0JD[B[440015]], 'game_pkg': z0JD[B[440029]], 'device': z0JD[B[440030]] }, z00JY, z0YDJ, z0D0);
}, window[B[440376]] = function (i7vnml) {
  z0JD[B[440377]] = ![];if (i7vnml && i7vnml[B[440090]] === B[440194] && i7vnml[B[440089]]) {
    for (var iv7n = 0x0; iv7n < i7vnml[B[440089]][B[440213]]; iv7n++) {
      i7vnml[B[440089]][iv7n][B[440239]] = z0JY0(i7vnml[B[440089]][iv7n]);
    }z0JD[B[440032]][-0x1] = window[B[440378]](i7vnml[B[440089]]), window[B[440369]][B[440379]](-0x1);
  } else {
    var gpvf = i7vnml ? i7vnml[B[440090]] : '';window[B[440104]](0x8, B[440380] + gpvf), window[B[440072]](B[440381] + gpvf);
  }
}, window[B[440382]] = function (ph19) {
  sendApi(z0JD[B[440020]], B[440375], { 'partner_id': z0JD[B[440028]], 'uid': z0JD[B[440110]], 'version': z0JD[B[440015]], 'game_pkg': z0JD[B[440029]], 'device': z0JD[B[440030]] }, ph19, z0YDJ, z0D0);
}, window[B[440383]] = function (gp419h, h1p9xg) {
  sendApi(z0JD[B[440020]], B[440384], { 'partner_id': z0JD[B[440028]], 'uid': z0JD[B[440110]], 'version': z0JD[B[440015]], 'game_pkg': z0JD[B[440029]], 'device': z0JD[B[440030]], 'server_group_id': h1p9xg }, z0YJ0, z0YDJ, z0D0);
}, window[B[440385]] = function (yb8dok) {
  z0JD[B[440377]] = ![];if (yb8dok && yb8dok[B[440090]] === B[440194] && yb8dok[B[440089]] && yb8dok[B[440089]][B[440089]]) {
    var fnv64 = yb8dok[B[440089]][B[440386]],
        fpgh64 = [];for (var eztoyd = 0x0; eztoyd < yb8dok[B[440089]][B[440089]][B[440213]]; eztoyd++) {
      yb8dok[B[440089]][B[440089]][eztoyd][B[440239]] = z0JY0(yb8dok[B[440089]][B[440089]][eztoyd]), (fpgh64[B[440213]] == 0x0 || yb8dok[B[440089]][B[440089]][eztoyd][B[440239]] != 0x0) && (fpgh64[fpgh64[B[440213]]] = yb8dok[B[440089]][B[440089]][eztoyd]);
    }z0JD[B[440032]][fnv64] = window[B[440378]](fpgh64), window[B[440369]][B[440379]](fnv64);
  } else {
    var bky_r8 = yb8dok ? yb8dok[B[440090]] : '';window[B[440104]](0x9, B[440387] + bky_r8), window[B[440072]](B[440388] + bky_r8);
  }
}, window[B[440389]] = function (xsa19e) {
  sendApi(z0JD[B[440020]], B[440390], { 'partner_id': z0JD[B[440028]], 'uid': z0JD[B[440110]], 'version': z0JD[B[440015]], 'game_pkg': z0JD[B[440029]], 'device': z0JD[B[440030]] }, reqServerRecommendCallBack, z0YDJ, z0D0);
}, window[B[440391]] = function (y8kbod) {
  z0JD[B[440377]] = ![];if (y8kbod && y8kbod[B[440090]] === B[440194] && y8kbod[B[440089]]) {
    for (var y_rk8 = 0x0; y_rk8 < y8kbod[B[440089]][B[440213]]; y_rk8++) {
      y8kbod[B[440089]][y_rk8][B[440239]] = z0JY0(y8kbod[B[440089]][y_rk8]);
    }z0JD[B[440032]][-0x2] = window[B[440378]](y8kbod[B[440089]]), window[B[440369]][B[440379]](-0x2);
  } else {
    var kboyd = y8kbod ? y8kbod[B[440090]] : '';window[B[440104]](0xa, B[440392] + kboyd), alert(B[440393] + kboyd);
  }
}, window[B[440378]] = function (g6p41h) {
  return g6p41h;
}, window[B[440394]] = function (tozkdy, l7nmv) {
  tozkdy = tozkdy || z0JD[B[440035]][B[440112]], sendApi(z0JD[B[440020]], B[440395], { 'type': '4', 'game_pkg': z0JD[B[440029]], 'server_id': tozkdy }, l7nmv);
}, window[B[440396]] = function (ykb8do, vgfl64, f7vl, x9a1se) {
  f7vl = f7vl || z0JD[B[440035]][B[440112]], sendApi(z0JD[B[440020]], B[440397], { 'type': ykb8do, 'game_pkg': vgfl64, 'server_id': f7vl }, x9a1se);
}, window[B[440398]] = function (deyzto, b5k8) {
  sendApi(z0JD[B[440020]], B[440399], { 'game_pkg': deyzto }, b5k8);
}, window[B[440400]] = function (tob) {
  if (tob) {
    if (tob[B[440239]] == 0x1) {
      if (tob[B[440401]] == 0x1) return 0x2;else return 0x1;
    } else return tob[B[440239]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window[B[440402]] = function (eoyd, glv64) {
  var aztes = window[B[440235]][B[440238]] == 0x1;if (aztes) {
    var dkybr8 = window[B[440235]][B[440246]],
        aztes = window[B[440235]][B[440238]] == 0x1;window[B[440086]][B[440087]][B[440247]](B[440248], dkybr8, B[440249]);return;
  }z0JD[B[440403]] = { 'step': eoyd, 'server_id': glv64 };var kb8rdy = this;z00JYD({ 'title': B[440404] }), sendApi(z0JD[B[440020]], B[440405], { 'partner_id': z0JD[B[440028]], 'uid': z0JD[B[440110]], 'game_pkg': z0JD[B[440029]], 'server_id': glv64, 'platform': z0JD[B[440198]], 'platform_uid': z0JD[B[440199]], 'check_login_time': z0JD[B[440202]], 'check_login_sign': z0JD[B[440200]], 'version_name': z0JD[B[440160]] }, z0D0JY, z0YDJ, z0D0, function (ybo8dk) {
    return ybo8dk[B[440090]] == B[440194] || ybo8dk[B[440091]] == B[440406] || ybo8dk[B[440091]] == B[440407];
  });
}, window[B[440408]] = function (iml3n7) {
  var hxs = this;if (iml3n7 && iml3n7[B[440090]] === B[440194] && iml3n7[B[440089]]) {
    var r_kby8 = z0JD[B[440035]];r_kby8[B[440409]] = z0JD[B[440033]], r_kby8[B[440201]] = String(iml3n7[B[440089]][B[440410]]), r_kby8[B[440041]] = parseInt(iml3n7[B[440089]][B[440203]]);if (iml3n7[B[440089]][B[440411]]) r_kby8[B[440411]] = parseInt(iml3n7[B[440089]][B[440411]]);else r_kby8[B[440411]] = parseInt(iml3n7[B[440089]][B[440112]]);r_kby8[B[440412]] = 0x0, r_kby8[B[440111]] = z0JD[B[440261]], r_kby8[B[440413]] = iml3n7[B[440089]][B[440414]], r_kby8[B[440415]] = iml3n7[B[440089]][B[440415]];if (iml3n7[B[440089]][B[440416]]) r_kby8[B[440416]] = parseInt(iml3n7[B[440089]][B[440416]]);console[B[440064]](B[440417] + JSON[B[440115]](r_kby8[B[440415]])), z0JD[B[440228]] == 0x1 && r_kby8[B[440415]] && r_kby8[B[440415]][B[440418]] == 0x1 && (z0JD[B[440419]] = 0x1, window[B[440086]][B[440087]][B[440420]]()), z0DY0J();
  } else {
    if (z0JD[B[440403]][B[440421]] >= 0x3) {
      var i3jq = iml3n7 ? iml3n7[B[440090]] : '';window[B[440104]](0xc, B[440422] + i3jq), z0D0(JSON[B[440115]](iml3n7)), window[B[440072]](B[440423] + i3jq);
    } else sendApi(z0JD[B[440020]], B[440175], { 'platform': z0JD[B[440018]], 'partner_id': z0JD[B[440028]], 'token': z0JD[B[440173]], 'game_pkg': z0JD[B[440029]], 'deviceId': z0JD[B[440030]], 'scene': B[440176] + z0JD[B[440031]] }, function (qm7) {
      if (!qm7 || qm7[B[440090]] != B[440194]) {
        window[B[440072]](B[440196] + qm7 && qm7[B[440090]]);return;
      }z0JD[B[440200]] = String(qm7[B[440201]]), z0JD[B[440202]] = String(qm7[B[440203]]), setTimeout(function () {
        z0D0YJ(z0JD[B[440403]][B[440421]] + 0x1, z0JD[B[440403]][B[440112]]);
      }, 0x5dc);
    }, z0YDJ, z0D0, function (iqn7m) {
      return iqn7m[B[440090]] == B[440194] || iqn7m[B[440090]] == B[440424];
    });
  }
}, window[B[440425]] = function () {
  ServerLoading[B[440087]][B[440244]](z0JD[B[440228]]), window[B[440053]] = !![], window[B[440251]]();
}, window[B[440250]] = function () {
  if (window[B[440054]] && window[B[440055]] && window[B[440056]] && window[B[440057]] && window[B[440058]] && window[B[440060]]) {
    if (!window[B[440426]][B[440087]]) {
      console[B[440064]](B[440427] + window[B[440426]][B[440087]]);var texzsa = wx[B[440428]](),
          $mjq3i = texzsa[B[440310]] ? texzsa[B[440310]] : 0x0,
          w2ur5_ = { 'cdn': window[B[440011]][B[440111]], 'spareCdn': window[B[440011]][B[440158]], 'newRegister': window[B[440011]][B[440228]], 'wxPC': window[B[440011]][B[440051]], 'wxIOS': window[B[440011]][B[440049]], 'wxAndroid': window[B[440011]][B[440050]], 'wxParam': { 'limitLoad': window[B[440011]][B[440429]], 'benchmarkLevel': window[B[440011]][B[440430]], 'wxFrom': window[B[440002]][B[440165]] == B[440431] ? 0x1 : 0x0, 'wxSDKVersion': window[B[440317]] }, 'configType': window[B[440011]][B[440043]], 'exposeType': window[B[440011]][B[440045]], 'scene': $mjq3i };new window[B[440426]](w2ur5_, window[B[440011]][B[440047]], window[B[440009]]);
    }
  }
}, window[B[440251]] = function () {
  if (window[B[440054]] && window[B[440055]] && window[B[440056]] && window[B[440057]] && window[B[440058]] && window[B[440060]] && window[B[440053]] && window[B[440059]]) {
    z00JDY();if (!z0DYJ) {
      z0DYJ = !![];if (!window[B[440426]][B[440087]]) window[B[440250]]();var tzsxe = 0x0,
          asoz = wx[B[440432]]();asoz && (window[B[440011]][B[440433]] && (tzsxe = asoz[B[440434]]), console[B[440091]](B[440435] + asoz[B[440434]] + B[440436] + asoz[B[440437]] + B[440438] + asoz[B[440439]] + B[440440] + asoz[B[440441]] + B[440442] + asoz[B[440443]] + B[440444] + asoz[B[440445]]));var ozsae = {};for (const rw_5 in z0JD[B[440035]]) {
        ozsae[rw_5] = z0JD[B[440035]][rw_5];
      }var w2_u = { 'channel': window[B[440011]][B[440034]], 'account': window[B[440011]][B[440110]], 'userId': window[B[440011]][B[440197]], 'cdn': window[B[440011]][B[440111]], 'data': window[B[440011]][B[440089]], 'package': window[B[440011]][B[440014]], 'newRegister': window[B[440011]][B[440228]], 'pkgName': window[B[440011]][B[440029]], 'partnerId': window[B[440011]][B[440028]], 'platform_uid': window[B[440011]][B[440199]], 'deviceId': window[B[440011]][B[440030]], 'selectedServer': ozsae, 'configType': window[B[440011]][B[440043]], 'exposeType': window[B[440011]][B[440045]], 'debugUsers': window[B[440011]][B[440039]], 'wxMenuTop': tzsxe, 'wxShield': window[B[440011]][B[440048]] };if (window[B[440264]]) for (var ij$qm in window[B[440264]]) {
        w2_u[ij$qm] = window[B[440264]][ij$qm];
      }window[B[440426]][B[440087]][B[440446]](w2_u);if (z0JD[B[440035]] && z0JD[B[440035]][B[440112]]) localStorage[B[440447]](B[440206] + z0JD[B[440029]] + z0JD[B[440110]], z0JD[B[440035]][B[440112]]);
    }
  } else console[B[440091]](B[440448] + window[B[440054]] + B[440449] + window[B[440055]] + B[440450] + window[B[440056]] + B[440451] + window[B[440057]] + B[440452] + window[B[440058]] + B[440453] + window[B[440060]] + B[440454] + window[B[440053]] + B[440455] + window[B[440059]]);
};