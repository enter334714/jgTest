var B = wx.$z;
import 'zzMAIz.js';