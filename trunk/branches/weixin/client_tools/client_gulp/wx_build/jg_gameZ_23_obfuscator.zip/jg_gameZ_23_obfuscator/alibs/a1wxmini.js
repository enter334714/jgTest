var c = wx.$a;
(function (window, document, nszjv) {
  var gsx1 = nszjv['un'],
      uf1gx = nszjv['uns'],
      qr5t87 = nszjv['static'],
      njsz = nszjv['class'],
      t875r3 = nszjv['getset'],
      wu_e2 = nszjv['__newvec'],
      k8dt6q = laya['utils']['Browser'],
      w40e_o = laya['events']['Event'],
      lc0b$ = laya['events']['EventDispatcher'],
      d5t8r = laya['resource']['HTMLImage'],
      b$lyc0 = laya['utils']['Handler'],
      k6qhdz = laya['display']['Input'],
      wgf1u2 = laya['net']['Loader'],
      jznvhs = laya['maths']['Matrix'],
      hjnkv = laya['renders']['Render'],
      fwg2u1 = laya['utils']['RunDriver'],
      w2egu1 = laya['media']['Sound'],
      c0 = laya['media']['SoundChannel'],
      o04e_y = laya['media']['SoundManager'],
      c$by0l = laya['display']['Stage'],
      _oe04y = laya['net']['URL'],
      x2fg = laya['utils']['Utils'],
      y$cob = function () {
    function r7tp5() {}return njsz(r7tp5, 'laya.wx.mini.MiniAdpter'), r7tp5['getJson'] = function (cmby$) {
      return JSON['parse'](cmby$);
    }, r7tp5['init'] = function ($lmcb, qr578t) {
      $lmcb === void 0x0 && ($lmcb = ![]), qr578t === void 0x0 && (qr578t = ![]);if (r7tp5['_inited']) return;r7tp5['window'] = window;if (r7tp5['window']['navigator']['userAgent']['indexOf']('MiniGame') < 0x0) return;r7tp5['_inited'] = !![], r7tp5['isZiYu'] = qr578t, r7tp5['isPosMsgYu'] = $lmcb, r7tp5['EnvConfig'] = {}, !r7tp5['isZiYu'] && (y$bco['setNativeFileDir']('/layaairGame'), y$bco['existDir'](y$bco['fileNativeDir'], b$lyc0['create'](r7tp5, r7tp5['onMkdirCallBack']))), r7tp5['window']['focus'] = function () {}, nszjv['getUrlPath'] = function () {}, r7tp5['window']['logtime'] = function (l$cabm) {}, r7tp5['window']['alertTimeLog'] = function (xsfjvn) {}, r7tp5['window']['resetShareInfo'] = function () {}, r7tp5['window']['CanvasRenderingContext2D'] = function () {}, r7tp5['window']['CanvasRenderingContext2D']['prototype'] = r7tp5['window']['wx']['createCanvas']()['getContext']('2d')['__proto__'], r7tp5['window']['document']['body']['appendChild'] = function () {}, r7tp5['EnvConfig']['pixelRatioInt'] = 0x0, fwg2u1['getPixelRatio'] = r7tp5['pixelRatio'], r7tp5['_preCreateElement'] = k8dt6q['createElement'], k8dt6q['createElement'] = r7tp5['createElement'], fwg2u1['createShaderCondition'] = r7tp5['createShaderCondition'], x2fg['parseXMLFromString'] = r7tp5['parseXMLFromString'], k6qhdz['_createInputElement'] = fjsn1['_createInputElement'], r7tp5['EnvConfig']['load'] = wgf1u2['prototype']['load'], wgf1u2['prototype']['load'] = d6v['prototype']['load'], r7tp5['isZiYu'] && $lmcb && wx['onMessage'](function (hnjzv) {
        hnjzv['isLoad'] && (y$bco['ziyuFileData'][hnjzv['url']] = hnjzv['data']);
      });
    }, r7tp5['onMkdirCallBack'] = function (nzvjhk, qkz6d8) {
      if (!nzvjhk) y$bco['filesListObj'] = JSON['parse'](qkz6d8['data']);
    }, r7tp5['pixelRatio'] = function () {
      if (!r7tp5['EnvConfig']['pixelRatioInt']) try {
        var svzhjn = wx['getSystemInfoSync']();return r7tp5['EnvConfig']['pixelRatioInt'] = svzhjn['pixelRatio'], svzhjn = svzhjn, svzhjn['pixelRatio'];
      } catch (ybl) {}return r7tp5['EnvConfig']['pixelRatioInt'];
    }, r7tp5['createElement'] = function (g2fxs) {
      if (g2fxs == 'canvas') {
        var khzn6;return r7tp5['idx'] == 0x1 ? r7tp5['isZiYu'] ? (khzn6 = sharedCanvas, khzn6['style'] = {}) : khzn6 = window['canvas'] : khzn6 = window['wx']['createCanvas'](), r7tp5['idx']++, khzn6;
      } else {
        if (g2fxs == 'textarea' || g2fxs == 'input') return r7tp5['onCreateInput'](g2fxs);else {
          if (g2fxs == 'div') {
            var nf1js = r7tp5['_preCreateElement'](g2fxs);return nf1js['contains'] = function (sf1jnx) {
              return null;
            }, nf1js['removeChild'] = function (jsvhn) {}, nf1js;
          } else return r7tp5['_preCreateElement'](g2fxs);
        }
      }
    }, r7tp5['onCreateInput'] = function (sf1xg2) {
      var c$bmal = r7tp5['_preCreateElement'](sf1xg2);return c$bmal['focus'] = fjsn1['wxinputFocus'], c$bmal['blur'] = fjsn1['wxinputblur'], c$bmal['style'] = {}, c$bmal['value'] = 0x0, c$bmal['parentElement'] = {}, c$bmal['placeholder'] = {}, c$bmal['type'] = {}, c$bmal['setColor'] = function (oc$) {}, c$bmal['setType'] = function (cyl$0b) {}, c$bmal['setFontFace'] = function (sxfg2) {}, c$bmal['addEventListener'] = function (nxhsjv) {}, c$bmal['contains'] = function (jsvnfx) {
        return null;
      }, c$bmal['removeChild'] = function (vsnfj) {}, c$bmal;
    }, r7tp5['createShaderCondition'] = function (bmlca) {
      var k6tdq8 = this,
          bco40y = function () {
        var gs2 = bmlca;return k6tdq8[bmlca['replace']('this.', '')];
      };return bco40y;
    }, r7tp5['EnvConfig'] = null, r7tp5['window'] = null, r7tp5['_preCreateElement'] = null, r7tp5['_inited'] = ![], r7tp5['wxRequest'] = null, r7tp5['systemInfo'] = null, r7tp5['version'] = '0.0.1', r7tp5['isZiYu'] = ![], r7tp5['isPosMsgYu'] = ![], r7tp5['parseXMLFromString'] = function (hnvsjz) {
      var zhkd6, fxg12s;hnvsjz = hnvsjz['replace'](/>\s+</g, '><');try {
        zhkd6 = new window['Parser']['DOMParser']()['parseFromString'](hnvsjz, 'text/xml');
      } catch (bcl0$) {
        throw '需要引入xml解析库文件';
      }return zhkd6;
    }, r7tp5['idx'] = 0x1, r7tp5;
  }(),
      snjxh = function () {
    function oybc() {}njsz(oybc, 'laya.wx.mini.MiniImage');var sjhv = oybc['prototype'];return sjhv['_loadImage'] = function (gf1x) {
      var sj21fx = this,
          cyl0b = ![];gf1x['indexOf']('layaNativeDir/') == -0x1 && (cyl0b = !![], gf1x = _oe04y['formatURL'](gf1x));if (!y$bco['getFileInfo'](gf1x)) {
        if (gf1x['indexOf']('http://') != -0x1 || gf1x['indexOf']('https://') != -0x1) y$bco['downImg'](gf1x, new b$lyc0(oybc, oybc['onDownImgCallBack'], [gf1x, sj21fx]), gf1x);else oybc['onCreateImage'](gf1x, sj21fx, !![]);
      } else oybc['onCreateImage'](gf1x, sj21fx, !cyl0b);
    }, oybc['onDownImgCallBack'] = function (nhzkvj, khnzvj, u12ewg) {
      if (!u12ewg) oybc['onCreateImage'](nhzkvj, khnzvj);else khnzvj['onError'](null);
    }, oybc['onCreateImage'] = function (q7tr, b$m9al, ye4o_) {
      ye4o_ === void 0x0 && (ye4o_ = ![]);var yb4co0;if (!ye4o_) {
        var o40bc = y$bco['getFileInfo'](q7tr),
            zvnkjh = o40bc['md5'];yb4co0 = y$bco['getFileNativePath'](zvnkjh);
      } else yb4co0 = q7tr;if (b$m9al['imgCache'] == null) b$m9al['imgCache'] = {};var vnjz;function hzkqd() {
        vnjz['onload'] = null, vnjz['onerror'] = null, delete b$m9al['imgCache'][q7tr];
      };var t8r6qd = function () {
        hzkqd(), b$m9al['onLoaded'](vnjz);
      },
          yo4_e0 = function () {
        hzkqd(), b$m9al['event']('error', 'Load image failed');
      };b$m9al['_type'] == 'nativeimage' ? (vnjz = new k8dt6q['window']['Image'](), vnjz['crossOrigin'] = '', vnjz['onload'] = t8r6qd, vnjz['onerror'] = yo4_e0, vnjz['src'] = yb4co0, b$m9al['imgCache'][q7tr] = vnjz) : new d5t8r['create'](yb4co0, { 'onload': t8r6qd, 'onerror': yo4_e0, 'onCreate': function (tqdr5) {
          vnjz = tqdr5, b$m9al['imgCache'][q7tr] = tqdr5;
        } });
    }, oybc;
  }(),
      fjsn1 = function () {
    function vkhzd() {}return njsz(vkhzd, 'laya.wx.mini.MiniInput'), vkhzd['_createInputElement'] = function () {
      k6qhdz['_initInput'](k6qhdz['area'] = k8dt6q['createElement']('textarea')), k6qhdz['_initInput'](k6qhdz['input'] = k8dt6q['createElement']('input')), k6qhdz['inputContainer'] = k8dt6q['createElement']('div'), k6qhdz['inputContainer']['style']['position'] = 'absolute', k6qhdz['inputContainer']['style']['zIndex'] = 0x186a0, k8dt6q['container']['appendChild'](k6qhdz['inputContainer']), k6qhdz['inputContainer']['setPos'] = function (xs1j2, y$bcml) {
        k6qhdz['inputContainer']['style']['left'] = xs1j2 + 'px', k6qhdz['inputContainer']['style']['top'] = y$bcml + 'px';
      }, nszjv['stage']['on']('resize', null, vkhzd['_onStageResize']), wx['onWindowResize'] && wx['onWindowResize'](function (ns1x) {
        window['dispatchEvent'] && window['dispatchEvent']('resize');
      }), o04e_y['_soundClass'] = t538r7, o04e_y['_musicClass'] = t538r7, window['_videoClass'] = nsvfj;
    }, vkhzd['_onStageResize'] = function () {
      var nvszjh = nszjv['stage']['_canvasTransform']['identity']();nvszjh['scale'](k8dt6q['width'] / hjnkv['canvas']['width'] / fwg2u1['getPixelRatio'](), k8dt6q['height'] / hjnkv['canvas']['height'] / fwg2u1['getPixelRatio']());
    }, vkhzd['wxinputFocus'] = function (blym$) {
      var o_e0w4 = k6qhdz['inputElement']['target'];if (o_e0w4 && !o_e0w4['editable']) return;y$cob['window']['wx']['offKeyboardConfirm'](), y$cob['window']['wx']['offKeyboardInput'](), y$cob['window']['wx']['showKeyboard']({ 'defaultValue': o_e0w4['text'], 'maxLength': o_e0w4['maxChars'], 'multiple': o_e0w4['multiline'], 'confirmHold': !![], 'confirmType': 'done', 'success': function (trqd86) {}, 'fail': function (hsnv) {} }), y$cob['window']['wx']['onKeyboardConfirm'](function (hvjxsn) {
        var mab$9l = hvjxsn ? hvjxsn['value'] : '';o_e0w4['text'] = mab$9l, o_e0w4['event']('input'), laya['wx']['mini']['MiniInput']['inputEnter']();
      }), y$cob['window']['wx']['onKeyboardInput'](function (d68rt) {
        var jfnsxv = d68rt ? d68rt['value'] : '';if (!o_e0w4['multiline']) {
          if (jfnsxv['indexOf']('\x0a') != -0x1) {
            laya['wx']['mini']['MiniInput']['inputEnter']();return;
          }
        }o_e0w4['text'] = jfnsxv, o_e0w4['event']('input');
      });
    }, vkhzd['inputEnter'] = function () {
      k6qhdz['inputElement']['target']['focus'] = ![];
    }, vkhzd['wxinputblur'] = function () {
      vkhzd['hideKeyboard']();
    }, vkhzd['hideKeyboard'] = function () {
      y$cob['window']['wx']['offKeyboardConfirm'](), y$cob['window']['wx']['offKeyboardInput'](), y$cob['window']['wx']['hideKeyboard']({ 'success': function (i3rp5) {
          console['log']('隐藏键盘');
        }, 'fail': function (n1sfjx) {
          console['log']('隐藏键盘出错:' + (n1sfjx ? n1sfjx['errMsg'] : ''));
        } });
    }, vkhzd;
  }(),
      d6v = function () {
    function t8r7q() {}njsz(t8r7q, 'laya.wx.mini.MiniLoader');var szjnh = t8r7q['prototype'];return szjnh['load'] = function (m$cbyl, eo0_y, c4bo, knhjv, vjzh) {
      c4bo === void 0x0 && (c4bo = !![]), vjzh === void 0x0 && (vjzh = ![]);var e_wgu2 = this;e_wgu2['_url'] = m$cbyl;if (m$cbyl['indexOf']('data:image') === 0x0) e_wgu2['_type'] = eo0_y = 'image';else e_wgu2['_type'] = eo0_y || (eo0_y = e_wgu2['getTypeFromUrl'](m$cbyl));e_wgu2['_cache'] = c4bo, e_wgu2['_data'] = null;var o_4c = 'ascii';if (m$cbyl['indexOf']('.fnt') != -0x1) o_4c = 'utf8';else eo0_y == 'arraybuffer' && (o_4c = '');;var q68dt = x2fg['getFileExtension'](m$cbyl);if (t8r7q['_fileTypeArr']['indexOf'](q68dt) != -0x1) y$cob['EnvConfig']['load']['call'](this, m$cbyl, eo0_y, c4bo, knhjv, vjzh);else {
        if (!y$bco['getFileInfo'](m$cbyl)) {
          if (m$cbyl['indexOf']('layaNativeDir/') != -0x1) {
            if (y$cob['isZiYu']) {
              var sf1jx = y$bco['ziyuFileData'][m$cbyl];e_wgu2['onLoaded'](sf1jx);return;
            } else {
              cosnole['log']('read read'), y$bco['read'](m$cbyl, o_4c, new b$lyc0(t8r7q, t8r7q['onReadNativeCallBack'], [o_4c, m$cbyl, eo0_y, c4bo, knhjv, vjzh, e_wgu2]));return;
            }
          }if (_oe04y['rootPath'] == '') var r7q85t = m$cbyl;else r7q85t = m$cbyl['split'](_oe04y['rootPath'])[0x0];m$cbyl['indexOf']('http://') != -0x1 || m$cbyl['indexOf']('https://') != -0x1 ? y$cob['EnvConfig']['load']['call'](e_wgu2, m$cbyl, eo0_y, c4bo, knhjv, vjzh) : y$bco['readFile'](r7q85t, o_4c, new b$lyc0(t8r7q, t8r7q['onReadNativeCallBack'], [o_4c, m$cbyl, eo0_y, c4bo, knhjv, vjzh, e_wgu2]), m$cbyl);
        } else y$cob['EnvConfig']['load']['call'](this, m$cbyl, eo0_y, c4bo, knhjv, vjzh);
      }
    }, szjnh['resMgrLoad'] = function (w2eg_u, h6dkvz, nszhv, xvjnhs, cy0lb, cbma, e0_4yo) {
      nszhv === void 0x0 && (nszhv = 0x0), xvjnhs === void 0x0 && (xvjnhs = ![]), cy0lb === void 0x0 && (cy0lb = ![]), cbma === void 0x0 && (cbma = 0x0), e0_4yo === void 0x0 && (e0_4yo = 0x3), w2eg_u['indexOf']('mpack') != -0x1 && console['log']('=============resMgrLoad url:', w2eg_u), y$cob['EnvConfig']['resMgrLoad'](w2eg_u, (fxnvsj, $lyc, qdk6t8) => {
        t8r7q['prototype']['resMgrLoadCallBack'](fxnvsj, $lyc, qdk6t8, h6dkvz);
      }, nszhv, xvjnhs, cy0lb, cbma, e0_4yo);
    }, szjnh['resMgrLoadCallBack'] = function (kjnzhv, zdh6v, sf2, w2ug_e) {
      console['log']('buff:::', kjnzhv, sf2, y$bco['fileNativeDir'] + '///' + y$bco['fileListName']), w2ug_e(kjnzhv, zdh6v, sf2);
    }, szjnh['clearRes'] = function (t8dq5r, ybo04c) {
      ybo04c === void 0x0 && (ybo04c = ![]);var $cmlyb = this;$cmlyb['clearRes'](t8dq5r, ybo04c);var t6dr8 = y$bco['getFileInfo'](t8dq5r);if (t6dr8 && (t8dq5r['indexOf']('http://') != -0x1 || t8dq5r['indexOf']('https://') != -0x1)) {
        var jxn1s = t6dr8['md5'],
            rtqd58 = y$bco['getFileNativePath'](jxn1s);y$bco['remove'](rtqd58);
      }
    }, t8r7q['onReadNativeCallBack'] = function (gw1fu2, vnsh, h6kn, vjkn, khdzv, fsvjnx, o_4ey0, _u4w, vjszh) {
      vjkn === void 0x0 && (vjkn = !![]), fsvjnx === void 0x0 && (fsvjnx = ![]), _u4w === void 0x0 && (_u4w = 0x0);if (!_u4w) {
        var ow_0e4;if (h6kn == 'json' || h6kn == 'atlas') ow_0e4 = y$cob['getJson'](vjszh['data']);else h6kn == 'xml' ? ow_0e4 = x2fg['parseXMLFromString'](vjszh['data']) : ow_0e4 = vjszh['data'];o_4ey0['onLoaded'](ow_0e4), !y$cob['isZiYu'] && y$cob['isPosMsgYu'] && h6kn != 'arraybuffer' && wx['postMessage']({ 'url': vnsh, 'data': ow_0e4, 'isLoad': !![] });
      } else _u4w == 0x1 && y$cob['EnvConfig']['load']['call'](o_4ey0, vnsh, h6kn, vjkn, khdzv, fsvjnx);
    }, qr5t87(t8r7q, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['png', 'jpg', 'bmp', 'jpeg', 'gif'];
    }]), t8r7q;
  }(),
      y$bco = function (e4w_o) {
    function gw2_eu() {
      gw2_eu['__super']['call'](this);;
    }return njsz(gw2_eu, 'laya.wx.mini.MiniFileMgr', e4w_o), gw2_eu['isLoadFile'] = function (am$lb9) {
      return gw2_eu['_fileTypeArr']['indexOf'](am$lb9) != -0x1 ? !![] : ![];
    }, gw2_eu['getFileInfo'] = function (oycb40) {
      var c_o40y = oycb40['split']('?')[0x0],
          zhjnk = gw2_eu['filesListObj'][c_o40y];if (zhjnk == null) return null;else return zhjnk;return null;
    }, gw2_eu['onFileUpdate'] = function (nzvhj, qd68t) {
      var z6hqkd = nzvhj['split']('/'),
          lyb$mc = z6hqkd[z6hqkd['length'] - 0x1],
          d6kqt = gw2_eu['getFileInfo'](qd68t);if (d6kqt == null) gw2_eu['onSaveFile'](qd68t, lyb$mc);else {
        if (d6kqt['readyUrl'] != qd68t) gw2_eu['remove'](lyb$mc, qd68t);
      }
    }, gw2_eu['exits'] = function (_geu4w, qdr8t) {
      var gf2w1u = gw2_eu['getFileNativePath'](_geu4w);gw2_eu['fs']['getFileInfo']({ 'filePath': gf2w1u, 'success': function (rt57q) {
          qdr8t != null && qdr8t['runWith']([0x0, rt57q]);
        }, 'fail': function (vhs) {
          qdr8t != null && qdr8t['runWith']([0x1, vhs]);
        } });
    }, gw2_eu['read'] = function (q58rdt, lbmc$a, y_e0o4, u2gwf) {
      lbmc$a === void 0x0 && (lbmc$a = 'ascill'), u2gwf === void 0x0 && (u2gwf = '');var yeo40_;u2gwf != '' ? yeo40_ = gw2_eu['getFileNativePath'](q58rdt) : yeo40_ = q58rdt, gw2_eu['fs']['readFile']({ 'filePath': yeo40_, 'encoding': lbmc$a, 'success': function (hxjns) {
          y_e0o4 != null && y_e0o4['runWith']([0x0, hxjns]);
        }, 'fail': function (r5t7p) {
          if (r5t7p && u2gwf != '') gw2_eu['down'](u2gwf, lbmc$a, y_e0o4, u2gwf);else y_e0o4 != null && y_e0o4['runWith']([0x1]);
        } });
    }, gw2_eu['readNativeFile'] = function (byc$lm, zh6kn) {
      gw2_eu['fs']['readFile']({ 'filePath': byc$lm, 'encoding': '', 'success': function (yo0bc$) {
          zh6kn != null && zh6kn['runWith']([0x0]);
        }, 'fail': function (oy_40e) {
          zh6kn != null && zh6kn['runWith']([0x1]);
        } });
    }, gw2_eu['down'] = function (we2_gu, zkvhd, u2_egw, r58tq) {
      zkvhd === void 0x0 && (zkvhd = 'ascill'), r58tq === void 0x0 && (r58tq = '');var gwf1u = gw2_eu['getFileNativePath'](r58tq),
          ybl$c0 = gw2_eu['wxdown']({ 'url': we2_gu, 'filePath': gwf1u, 'success': function (hzdk6v) {
          if (hzdk6v['statusCode'] === 0xc8) gw2_eu['readFile'](hzdk6v['filePath'], zkvhd, u2_egw, r58tq);
        }, 'fail': function (w2eg1) {
          u2_egw != null && u2_egw['runWith']([0x1, w2eg1]);
        } });ybl$c0['onProgressUpdate'](function (lm$b) {
        u2_egw != null && u2_egw['runWith']([0x2, lm$b['progress']]);
      });
    }, gw2_eu['readFile'] = function (dqk6t, vjnhz, rqt785, fgu12w) {
      vjnhz === void 0x0 && (vjnhz = 'ascill'), fgu12w === void 0x0 && (fgu12w = ''), gw2_eu['fs']['readFile']({ 'filePath': dqk6t, 'encoding': vjnhz, 'success': function (nshjx) {
          if (dqk6t['indexOf']('http://') != -0x1 || dqk6t['indexOf']('https://') != -0x1) gw2_eu['onFileUpdate'](dqk6t, fgu12w);rqt785 != null && rqt785['runWith']([0x0, nshjx]);
        }, 'fail': function (u2w_e) {
          if (u2w_e) rqt785 != null && rqt785['runWith']([0x1, u2w_e]);
        } });
    }, gw2_eu['downImg'] = function (q85trd, we12gu, e2wug_) {
      e2wug_ === void 0x0 && (e2wug_ = '');var nkjzh = gw2_eu['wxdown']({ 'url': q85trd, 'success': function (xfsnj) {
          xfsnj['statusCode'] === 0xc8 && gw2_eu['copyFile'](xfsnj['tempFilePath'], e2wug_, we12gu);
        }, 'fail': function (cb0o4y) {
          we12gu != null && we12gu['runWith']([0x1, cb0o4y]);
        } });
    }, gw2_eu['copyFile'] = function (qrt6, t8357r, dr8) {
      var ux1g = qrt6['split']('/'),
          $blyc = ux1g[ux1g['length'] - 0x1],
          h6kqdz = t8357r['split']('?')[0x0],
          xfvjns = gw2_eu['getFileInfo'](t8357r),
          l$mbyc = gw2_eu['getFileNativePath']($blyc);gw2_eu['fs']['copyFile']({ 'srcPath': qrt6, 'destPath': l$mbyc, 'success': function (eu1wg2) {
          if (!xfvjns) gw2_eu['onSaveFile'](t8357r, $blyc), dr8 != null && dr8['runWith']([0x0]);else {
            if (xfvjns['readyUrl'] != t8357r) gw2_eu['remove']($blyc, t8357r, dr8);
          }
        }, 'fail': function (w1u2eg) {
          dr8 != null && dr8['runWith']([0x1, w1u2eg]);
        } });
    }, gw2_eu['getFileNativePath'] = function (hk6dv) {
      return laya['wx']['mini']['MiniFileMgr']['fileNativeDir'] + '/' + hk6dv;
    }, gw2_eu['remove'] = function (a$bmc, b$yc0l, y$bm) {
      b$yc0l === void 0x0 && (b$yc0l = '');var nshzv = gw2_eu['getFileInfo'](b$yc0l),
          l9b = gw2_eu['getFileNativePath'](nshzv['md5']);nszjv['loader']['clearRes'](nshzv['readyUrl']), gw2_eu['fs']['unlink']({ 'filePath': l9b, 'success': function (nvkh6) {
          if (b$yc0l != '') gw2_eu['onSaveFile'](b$yc0l, a$bmc);y$bm != null && y$bm['runWith']([0x0]);
        }, 'fail': function (jxsnvh) {} });
    }, gw2_eu['onSaveFile'] = function (c_04o, qdhzk6) {
      var rt35p = c_04o['split']('?')[0x0];gw2_eu['filesListObj'][rt35p] = { 'md5': qdhzk6, 'readyUrl': c_04o }, gw2_eu['fs']['writeFile']({ 'filePath': gw2_eu['fileNativeDir'] + '/' + gw2_eu['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](gw2_eu['filesListObj']), 'success': function (ug2w1) {
          console['log']('写入测试测试成功：', ug2w1);
        }, 'fail': function (o4y_c) {
          console['log']('写入测试测试失败：', o4y_c);
        } });
    }, gw2_eu['existDir'] = function (yo0e, c$0yob) {
      gw2_eu['fs']['mkdir']({ 'dirPath': yo0e, 'success': function (d8q5) {
          c$0yob != null && c$0yob['runWith']([0x0, { 'data': JSON['stringify']({}) }]);
        }, 'fail': function (rtq57) {
          if (rtq57['errMsg']['indexOf']('file already exists') != -0x1) gw2_eu['readSync'](gw2_eu['fileListName'], 'utf8', c$0yob);else c$0yob != null && c$0yob['runWith']([0x1, rtq57]);
        } });
    }, gw2_eu['readSync'] = function (ca$lbm, uo_we, jvfn, g21sxf) {
      uo_we === void 0x0 && (uo_we = 'ascill'), g21sxf === void 0x0 && (g21sxf = '');var trq = gw2_eu['getFileNativePath'](ca$lbm),
          _o4uew;try {
        _o4uew = gw2_eu['fs']['readFileSync'](trq), jvfn != null && jvfn['runWith']([0x0, { 'data': _o4uew }]);
      } catch (gw_ue) {
        jvfn != null && jvfn['runWith']([0x1]);
      }
    }, gw2_eu['readCache'] = function () {}, gw2_eu['writeCache'] = function (vfsj) {
      var z8qd6k = readyUrl['split']('?')[0x0];gw2_eu['filesListObj'][z8qd6k] = { 'md5': md5Name, 'readyUrl': readyUrl }, gw2_eu['fs']['writeFile']({ 'filePath': gw2_eu['fileNativeDir'] + '/' + gw2_eu['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](gw2_eu['filesListObj']), 'success': function (c0y4) {}, 'fail': function (e2wug1) {} });
    }, gw2_eu['setNativeFileDir'] = function ($mcylb) {
      gw2_eu['fileNativeDir'] = wx['env']['USER_DATA_PATH'] + $mcylb;
    }, gw2_eu['filesListObj'] = {}, gw2_eu['fileNativeDir'] = null, gw2_eu['fileListName'] = 'layaairfiles.txt', gw2_eu['ziyuFileData'] = {}, qr5t87(gw2_eu, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['json', 'ani', 'xml', 'sk', 'txt', 'atlas', 'swf', 'part', 'fnt', 'proto', 'lh', 'lav', 'lani', 'lmat', 'lm', 'ltc'];
    }, 'fs', function () {
      return this['fs'] = wx['getFileSystemManager']();
    }, 'wxdown', function () {
      return this['wxdown'] = wx['downloadFile'];
    }]), gw2_eu;
  }(lc0b$),
      t538r7 = function (g_ewu) {
    function al9mb$() {
      this['_sound'] = null, this['_chanell'] = null, this['url'] = null, this['loaded'] = ![], al9mb$['__super']['call'](this), this['_sound'] = al9mb$['_createSound'](), this['_chanell'] = new fs21gx(this['_sound']);
    }njsz(al9mb$, 'laya.wx.mini.MiniSound', g_ewu);var d58qr = al9mb$['prototype'];return d58qr['load'] = function (khzjv) {
      var calbm = this;khzjv = _oe04y['formatURL'](khzjv), this['url'] = khzjv;if (al9mb$['_audioCache'][khzjv]) {
        this['event']('complete');return;
      }function rq785() {
        if (al9mb$['_null'] != undefined) calbm['_sound']['onCanplay'](al9mb$['_null']), calbm['_sound']['onError'](al9mb$['_null']);else try {
          calbm['_sound']['onCanplay'](null), calbm['_sound']['onError'](null), al9mb$['_null'] = null;
        } catch (byo4) {
          console['warn']('[wxmini] _clearSound:' + byo4), calbm['_sound']['onCanplay'](ue_g), calbm['_sound']['onError'](ue_g), al9mb$['_null'] = ue_g;
        }
      }function qdt6r() {
        cblmy$['loaded'] = !![], cblmy$['event']('complete'), al9mb$['_audioCache'][cblmy$['url']] = cblmy$;
      }function o$yb0(_weg2u) {
        console['error']('errCode=' + _weg2u['errCode'] + '  errMsg=' + _weg2u['errMsg']), cblmy$['event']('error');
      }function ue_g() {}this['_sound']['onCanplay'](qdt6r), this['_sound']['onError'](o$yb0), this['_sound']['src'] = khzjv;var cblmy$ = this;
    }, d58qr['play'] = function (hz6knv, w4_o0) {
      hz6knv === void 0x0 && (hz6knv = 0x0), w4_o0 === void 0x0 && (w4_o0 = 0x0);var cmlab$, p537ri;if (this['url'] == o04e_y['_tMusic']) {
        if (!al9mb$['_musicAudio']) al9mb$['_musicAudio'] = this['_sound'];cmlab$ = al9mb$['_musicAudio'], p537ri = this['_chanell'];
      } else cmlab$ = this['_sound'], p537ri = this['_chanell'];return cmlab$['src'] = this['url'], cmlab$['startTime'] = 0x0, p537ri['isStopped'] && (p537ri['url'] = this['url'], p537ri['loops'] = w4_o0, p537ri['startTime'] = hz6knv, p537ri['play'](), o04e_y['addChannel'](p537ri)), p537ri;
    }, d58qr['dispose'] = function () {
      var hzv = al9mb$['_audioCache'][this['url']];hzv && (hzv['src'] = '', delete al9mb$['_audioCache'][this['url']]);
    }, t875r3(0x0, d58qr, 'duration', function () {
      return this['_sound']['duration'];
    }), al9mb$['_createSound'] = function () {
      al9mb$['_id']++;var i37pr5 = y$cob['window']['wx']['createInnerAudioContext']({ 'useWebAudioImplement': ![] });return i37pr5;
    }, al9mb$['_musicAudio'] = null, al9mb$['_id'] = 0x0, al9mb$['_audioCache'] = {}, al9mb$['_null'] = undefined, al9mb$;
  }(lc0b$),
      fs21gx = function (b$0cly) {
    function w04o(hsvxj) {
      this['_audio'] = null, this['_onEnd'] = null, w04o['__super']['call'](this), this['isStopped'] = !![], this['_audio'] = hsvxj, this['_onEnd'] = x2fg['bind'](this['__onEnd'], this), hsvxj['onEnded'](this['_onEnd']);
    }njsz(w04o, 'laya.wx.mini.MiniSoundChannel', b$0cly);var kqd6h = w04o['prototype'];return kqd6h['__onEnd'] = function () {
      if (this['loops'] == 0x1) {
        this['completeHandler'] && (nszjv['timer']['once'](0xa, this, this['__runComplete'], [this['completeHandler']], ![]), this['completeHandler'] = null);this['stop'](), this['event']('complete');return;
      }this['loops'] > 0x0 && this['loops']--, this['startTime'] = 0x0, this['play']();
    }, kqd6h['__onNull'] = function () {}, kqd6h['play'] = function () {
      this['isStopped'] = ![], o04e_y['addChannel'](this);if (this['_audio']) this['_audio']['play']();
    }, kqd6h['stop'] = function () {
      this['isStopped'] = !![], o04e_y['removeChannel'](this), this['completeHandler'] = null;if (!this['_audio']) return;this['_audio']['stop']();
    }, kqd6h['pause'] = function () {
      this['isStopped'] = !![], this['_audio']['pause']();
    }, kqd6h['resume'] = function () {
      if (!this['_audio']) return;this['isStopped'] = ![], o04e_y['addChannel'](this), this['_audio']['play']();
    }, t875r3(0x0, kqd6h, 'position', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['currentTime'];
    }), t875r3(0x0, kqd6h, 'duration', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['duration'];
    }), t875r3(0x0, kqd6h, 'volume', function () {
      return 0x1;
    }, function (bc$0ly) {}), w04o['_null'] = undefined, w04o;
  }(c0),
      nsvfj = function () {
    function shvxjn() {
      this['videoend'] = ![], this['videourl'] = '', this['videoElement'] = y$cob['window']['wx']['createVideo']({ 'showCenterPlayBtn': ![], 'showProgressInControlMode': ![], 'objectFit': 'fill' });
    }njsz(shvxjn, 'laya.wx.mini.MiniVideo');var g1f2 = shvxjn['prototype'];return g1f2['on'] = function (yb0o$c, u2x1gf, f1ugw2) {
      if (yb0o$c == 'loadedmetadata') this['onPlayFunc'] = f1ugw2['bind'](u2x1gf), this['videoElement']['onPlay'] = this['onPlayFunction']['bind'](this);else yb0o$c == 'ended' && (this['onEndedFunC'] = f1ugw2['bind'](u2x1gf), this['videoElement']['onEnded'] = this['onEndedFunction']['bind'](this));this['videoElement']['onTimeUpdate'] = this['onTimeUpdateFunc']['bind'](this);
    }, g1f2['onTimeUpdateFunc'] = function (y0c$) {
      this['position'] = y0c$['position'], this['_duration'] = y0c$['duration'];
    }, g1f2['onPlayFunction'] = function () {
      if (this['videoElement']) this['videoElement']['readyState'] = 0xc8;console['log']('=====视频加载完成========'), this['onPlayFunc'] != null && this['onPlayFunc']();
    }, g1f2['onended'] = function (q6dr8, t5r78) {
      this['onEndedFunC'] = t5r78['bind'](q6dr8), this['videoElement']['onended'] = this['onEndedFunction']['bind'](this);
    }, g1f2['onEndedFunction'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], console['log']('=====视频播放完毕========'), this['onEndedFunC'] != null && this['onEndedFunC']();
    }, g1f2['off'] = function ($mbac, d58r, oc4_) {
      if ($mbac == 'loadedmetadata') this['onPlayFunc'] = oc4_['bind'](d58r), this['videoElement']['offPlay'] = this['onPlayFunction']['bind'](this);else $mbac == 'ended' && (this['onEndedFunC'] = oc4_['bind'](d58r), this['videoElement']['offEnded'] = this['onEndedFunction']['bind'](this));
    }, g1f2['load'] = function (e2u1w) {
      if (!this['videoElement']) return;this['videoElement']['src'] = e2u1w;
    }, g1f2['play'] = function () {
      if (!this['videoElement']) return;this['videoend'] = ![], this['videoElement']['play']();
    }, g1f2['pause'] = function () {
      if (!this['videoElement']) return;this['videoend'] = !![], this['videoElement']['pause']();
    }, g1f2['size'] = function (jzhnsv, r35tp) {
      if (!this['videoElement']) return;this['videoElement']['width'] = jzhnsv, this['videoElement']['height'] = r35tp;
    }, g1f2['destroy'] = function () {
      if (this['videoElement']) this['videoElement']['destroy']();this['videoElement'] = null, this['onEndedFunC'] = null, this['onPlayFunc'] = null, this['videoend'] = ![], this['videourl'] = null;
    }, g1f2['reload'] = function () {
      if (!this['videoElement']) return;this['videoElement']['src'] = this['videourl'];
    }, t875r3(0x0, g1f2, 'duration', function () {
      return this['_duration'];
    }), t875r3(0x0, g1f2, 'currentTime', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['initialTime'];
    }, function (qtdr5) {
      if (!this['videoElement']) return;this['videoElement']['initialTime'] = qtdr5;
    }), t875r3(0x0, g1f2, 'videoWidth', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['width'];
    }), t875r3(0x0, g1f2, 'videoHeight', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['height'];
    }), t875r3(0x0, g1f2, 'ended', function () {
      return this['videoend'];
    }), t875r3(0x0, g1f2, 'loop', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['loop'];
    }, function (d6qz8) {
      if (!this['videoElement']) return;this['videoElement']['loop'] = d6qz8;
    }), t875r3(0x0, g1f2, 'playbackRate', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['playbackRate'];
    }, function (shzjvn) {
      if (!this['videoElement']) return;this['videoElement']['playbackRate'] = shzjvn;
    }), t875r3(0x0, g1f2, 'muted', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['muted'];
    }, function (uw1ge) {
      if (!this['videoElement']) return;this['videoElement']['muted'] = uw1ge;
    }), t875r3(0x0, g1f2, 'paused', function () {
      if (!this['videoElement']) return ![];return this['videoElement']['paused'];
    }), t875r3(0x0, g1f2, 'x', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['x'];
    }, function ($cbylm) {
      if (!this['videoElement']) return;this['videoElement']['x'] = $cbylm;
    }), t875r3(0x0, g1f2, 'y', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['y'];
    }, function (zdk6vh) {
      if (!this['videoElement']) return;this['videoElement']['y'] = zdk6vh;
    }), t875r3(0x0, g1f2, 'currentSrc', function () {
      return this['videoElement']['src'];
    }), t875r3(0x0, g1f2, 'src', function () {
      if (!this['videoElement']) return 0x0;return this['videoElement']['src'];
    }, function (vdzk) {
      if (!this['videoElement']) return;this['videoElement']['src'] = vdzk;
    }), t875r3(0x0, g1f2, 'controls', function () {
      if (!this['videoElement']) return;return this['videoElement']['controls'];
    }, function (g1xfu2) {
      if (!this['videoElement']) return;this['videoElement']['controls'] = g1xfu2;
    }), t875r3(0x0, g1f2, 'autoplay', function () {
      if (!this['videoElement']) return;return this['videoElement']['autoplay'];
    }, function (co$y0) {
      if (!this['videoElement']) return;this['videoElement']['autoplay'] = co$y0;
    }), shvxjn;
  }();
})(window, document, Laya);typeof define === 'function' && define['amd'] && define('laya.core', ['require', 'exports'], function (require, exports) {
  'use strict';
  Object['defineProperty'](exports, '__esModule', { 'value': !![] });for (var t7853 in Laya) {
    var hvnsx = Laya[t7853];hvnsx && hvnsx['__isclass'] && (exports[t7853] = hvnsx);
  }
});