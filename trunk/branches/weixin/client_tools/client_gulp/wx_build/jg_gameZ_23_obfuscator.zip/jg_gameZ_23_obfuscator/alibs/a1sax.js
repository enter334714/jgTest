var c = wx.$a;
function gq8k6d() {}function gboc0(o40_ey, dhzvk6, cmybl$, rt75q, weu2_g) {
  function o_4e(hkzvn) {
    if (hkzvn > 0xffff) {
      hkzvn -= 0x10000;var w04o_e = 0xd800 + (hkzvn >> 0xa),
          hd6vkz = 0xdc00 + (0x3ff & hkzvn);return String['fromCharCode'](w04o_e, hd6vkz);
    }return String['fromCharCode'](hkzvn);
  }function lb$my(_4yeo0) {
    var qr85td = _4yeo0['slice'](0x1, -0x1);return qr85td in cmybl$ ? cmybl$[qr85td] : '#' === qr85td['charAt'](0x0) ? o_4e(parseInt(qr85td['substr'](0x1)['replace']('x', '0x'))) : (weu2_g['error']('entity not found:' + _4yeo0), _4yeo0);
  }function jnhxsv(fvsxnj) {
    if (fvsxnj > euo4_) {
      var vkhjzn = o40_ey['substring'](euo4_, fvsxnj)['replace'](/&#?\w+;/g, lb$my);q6dhz && o$ybc(euo4_), rt75q['characters'](vkhjzn, 0x0, fvsxnj - euo4_), euo4_ = fvsxnj;
    }
  }function o$ybc(vh6zn, fx12j) {
    for (; vh6zn >= g21wuf && (fx12j = k6hdvz['exec'](o40_ey));) e0ow_4 = fx12j['index'], g21wuf = e0ow_4 + fx12j[0x0]['length'], q6dhz['lineNumber']++;q6dhz['columnNumber'] = vh6zn - e0ow_4 + 0x1;
  }for (var e0ow_4 = 0x0, g21wuf = 0x0, k6hdvz = /.*(?:\r\n?|\n)|.*$/g, q6dhz = rt75q['locator'], c$y0b = [{ 'currentNSMap': dhzvk6 }], _ewg2 = {}, euo4_ = 0x0;;) {
    try {
      var r5i3p7 = o40_ey['indexOf']('<', euo4_);if (0x0 > r5i3p7) {
        if (!o40_ey['substr'](euo4_)['match'](/^\s*$/)) {
          var q7rt85 = rt75q['doc'],
              yco_0 = q7rt85['createTextNode'](o40_ey['substr'](euo4_));q7rt85['appendChild'](yco_0), rt75q['currentElement'] = yco_0;
        }return;
      }switch (r5i3p7 > euo4_ && jnhxsv(r5i3p7), o40_ey['charAt'](r5i3p7 + 0x1)) {case '/':
          var u2wg_e = o40_ey['indexOf']('>', r5i3p7 + 0x3),
              p53rt = o40_ey['substring'](r5i3p7 + 0x2, u2wg_e),
              ycm$b = c$y0b['pop']();0x0 > u2wg_e ? (p53rt = o40_ey['substring'](r5i3p7 + 0x2)['replace'](/[\s<].*/, ''), weu2_g['error']('end tag name: ' + p53rt + ' is not complete:' + ycm$b['tagName']), u2wg_e = r5i3p7 + 0x1 + p53rt['length']) : p53rt['match'](/\s</) && (p53rt = p53rt['replace'](/[\s<].*/, ''), weu2_g['error']('end tag name: ' + p53rt + ' maybe not complete'), u2wg_e = r5i3p7 + 0x1 + p53rt['length']);var ylb0c = ycm$b['localNSMap'],
              oew0_4 = ycm$b['tagName'] == p53rt,
              gu2_ew = oew0_4 || ycm$b['tagName'] && ycm$b['tagName']['toLowerCase']() == p53rt['toLowerCase']();if (gu2_ew) {
            if (rt75q['endElement'](ycm$b['uri'], ycm$b['localName'], p53rt), ylb0c) {
              for (var jfxsv in ylb0c) rt75q['endPrefixMapping'](jfxsv);
            }oew0_4 || weu2_g['fatalError']('end tag name: ' + p53rt + ' is not match the current start tagName:' + ycm$b['tagName']);
          } else c$y0b['push'](ycm$b);u2wg_e++;break;case '?':
          q6dhz && o$ybc(r5i3p7), u2wg_e = gzkvjnh(o40_ey, r5i3p7, rt75q);break;case '!':
          q6dhz && o$ybc(r5i3p7), u2wg_e = gjsxv(o40_ey, r5i3p7, rt75q, weu2_g);break;default:
          q6dhz && o$ybc(r5i3p7);var $bcly0 = new gvkhd6z(),
              xug21f = c$y0b[c$y0b['length'] - 0x1]['currentNSMap'],
              u2wg_e = g_coy0(o40_ey, r5i3p7, $bcly0, xug21f, lb$my, weu2_g),
              xug2 = $bcly0['length'];if (!$bcly0['closed'] && gueow4_(o40_ey, u2wg_e, $bcly0['tagName'], _ewg2) && ($bcly0['closed'] = !0x0, cmybl$['nbsp'] || weu2_g['warning']('unclosed xml attribute')), q6dhz && xug2) {
            for (var snhjx = gjfsvnx(q6dhz, {}), fx1nsj = 0x0; xug2 > fx1nsj; fx1nsj++) {
              var f12gs = $bcly0[fx1nsj];o$ybc(f12gs['offset']), f12gs['locator'] = gjfsvnx(q6dhz, {});
            }rt75q['locator'] = snhjx, gwe1g($bcly0, rt75q, xug21f) && c$y0b['push']($bcly0), rt75q['locator'] = q6dhz;
          } else gwe1g($bcly0, rt75q, xug21f) && c$y0b['push']($bcly0);'http://www.w3.org/1999/xhtml' !== $bcly0['uri'] || $bcly0['closed'] ? u2wg_e++ : u2wg_e = go4uw_e(o40_ey, u2wg_e, $bcly0['tagName'], lb$my, rt75q);}
    } catch (i5r3) {
      weu2_g['error']('element parse error: ' + i5r3), u2wg_e = -0x1;
    }u2wg_e > euo4_ ? euo4_ = u2wg_e : jnhxsv(Math['max'](r5i3p7, euo4_) + 0x1);
  }
}function gjfsvnx(ly0$cb, yoe) {
  return yoe['lineNumber'] = ly0$cb['lineNumber'], yoe['columnNumber'] = ly0$cb['columnNumber'], yoe;
}function g_coy0(jnszv, hvkjz, b$l0, l$b0, k6vnhz, y4oe0) {
  for (var u1gxf2, fg1u2w, dqr68 = ++hvkjz, l0$byc = gx1gf2;;) {
    var i5rp3 = jnszv['charAt'](dqr68);switch (i5rp3) {case '=':
        if (l0$byc === gx1ugf2) u1gxf2 = jnszv['slice'](hvkjz, dqr68), l0$byc = gmby$l;else {
          if (l0$byc !== gdv6kh) throw new Error('attribute equal must after attrName');l0$byc = gmby$l;
        }break;case '\x27':case '\x22':
        if (l0$byc === gmby$l || l0$byc === gx1ugf2) {
          if (l0$byc === gx1ugf2 && (y4oe0['warning']('attribute value must after "="'), u1gxf2 = jnszv['slice'](hvkjz, dqr68)), hvkjz = dqr68 + 0x1, dqr68 = jnszv['indexOf'](i5rp3, hvkjz), !(dqr68 > 0x0)) throw new Error('attribute value no end \'' + i5rp3 + '\' match');fg1u2w = jnszv['slice'](hvkjz, dqr68)['replace'](/&#?\w+;/g, k6vnhz), b$l0['add'](u1gxf2, fg1u2w, hvkjz - 0x1), l0$byc = gguw21;
        } else {
          if (l0$byc != gmcy$lb) throw new Error('attribute value must after "="');fg1u2w = jnszv['slice'](hvkjz, dqr68)['replace'](/&#?\w+;/g, k6vnhz), b$l0['add'](u1gxf2, fg1u2w, hvkjz), y4oe0['warning']('attribute "' + u1gxf2 + '" missed start quot(' + i5rp3 + ')!!'), hvkjz = dqr68 + 0x1, l0$byc = gguw21;
        }break;case '/':
        switch (l0$byc) {case gx1gf2:
            b$l0['setTagName'](jnszv['slice'](hvkjz, dqr68));case gguw21:case gueg_w:case g_eo04w:
            l0$byc = g_eo04w, b$l0['closed'] = !0x0;case gmcy$lb:case gx1ugf2:case gdv6kh:
            break;default:
            throw new Error('attribute invalid close char(\'/\')');}break;case '':
        return y4oe0['error']('unexpected end of input'), l0$byc == gx1gf2 && b$l0['setTagName'](jnszv['slice'](hvkjz, dqr68)), dqr68;case '>':
        switch (l0$byc) {case gx1gf2:
            b$l0['setTagName'](jnszv['slice'](hvkjz, dqr68));case gguw21:case gueg_w:case g_eo04w:
            break;case gmcy$lb:case gx1ugf2:
            fg1u2w = jnszv['slice'](hvkjz, dqr68), '/' === fg1u2w['slice'](-0x1) && (b$l0['closed'] = !0x0, fg1u2w = fg1u2w['slice'](0x0, -0x1));case gdv6kh:
            l0$byc === gdv6kh && (fg1u2w = u1gxf2), l0$byc == gmcy$lb ? (y4oe0['warning']('attribute "' + fg1u2w + '" missed quot(")!!'), b$l0['add'](u1gxf2, fg1u2w['replace'](/&#?\w+;/g, k6vnhz), hvkjz)) : ('http://www.w3.org/1999/xhtml' === l$b0[''] && fg1u2w['match'](/^(?:disabled|checked|selected)$/i) || y4oe0['warning']('attribute "' + fg1u2w + '" missed value!! "' + fg1u2w + '" instead!!'), b$l0['add'](fg1u2w, fg1u2w, hvkjz));break;case gmby$l:
            throw new Error('attribute value missed!!');}return dqr68;case '\u0080':
        i5rp3 = '\x20';default:
        if ('\x20' >= i5rp3) switch (l0$byc) {case gx1gf2:
            b$l0['setTagName'](jnszv['slice'](hvkjz, dqr68)), l0$byc = gueg_w;break;case gx1ugf2:
            u1gxf2 = jnszv['slice'](hvkjz, dqr68), l0$byc = gdv6kh;break;case gmcy$lb:
            var fg1u2w = jnszv['slice'](hvkjz, dqr68)['replace'](/&#?\w+;/g, k6vnhz);y4oe0['warning']('attribute "' + fg1u2w + '" missed quot(")!!'), b$l0['add'](u1gxf2, fg1u2w, hvkjz);case gguw21:
            l0$byc = gueg_w;} else switch (l0$byc) {case gdv6kh:
            {
              b$l0['tagName'];
            }'http://www.w3.org/1999/xhtml' === l$b0[''] && u1gxf2['match'](/^(?:disabled|checked|selected)$/i) || y4oe0['warning']('attribute "' + u1gxf2 + '" missed value!! "' + u1gxf2 + '" instead2!!'), b$l0['add'](u1gxf2, u1gxf2, hvkjz), hvkjz = dqr68, l0$byc = gx1ugf2;break;case gguw21:
            y4oe0['warning']('attribute space is required"' + u1gxf2 + '\x22!!');case gueg_w:
            l0$byc = gx1ugf2, hvkjz = dqr68;break;case gmby$l:
            l0$byc = gmcy$lb, hvkjz = dqr68;break;case g_eo04w:
            throw new Error('elements closed character \'/\' and \'>\' must be connected to');}}dqr68++;
  }
}function gwe1g(vjnxsh, d85qtr, pr7i53) {
  for (var uxg21 = vjnxsh['tagName'], zjnsh = null, sfjxv = vjnxsh['length']; sfjxv--;) {
    var e4_uow = vjnxsh[sfjxv],
        gxs1 = e4_uow['qName'],
        $cylb = e4_uow['value'],
        nhkzv6 = gxs1['indexOf'](':');if (nhkzv6 > 0x0) var cb$o = e4_uow['prefix'] = gxs1['slice'](0x0, nhkzv6),
        vd6khz = gxs1['slice'](nhkzv6 + 0x1),
        x2f1g = 'xmlns' === cb$o && vd6khz;else vd6khz = gxs1, cb$o = null, x2f1g = 'xmlns' === gxs1 && '';e4_uow['localName'] = vd6khz, x2f1g !== !0x1 && (null == zjnsh && (zjnsh = {}, gfsj1nx(pr7i53, pr7i53 = {})), pr7i53[x2f1g] = zjnsh[x2f1g] = $cylb, e4_uow['uri'] = 'http://www.w3.org/2000/xmlns/', d85qtr['startPrefixMapping'](x2f1g, $cylb));
  }for (var sfjxv = vjnxsh['length']; sfjxv--;) {
    e4_uow = vjnxsh[sfjxv];var cb$o = e4_uow['prefix'];cb$o && ('xml' === cb$o && (e4_uow['uri'] = 'http://www.w3.org/XML/1998/namespace'), 'xmlns' !== cb$o && (e4_uow['uri'] = pr7i53[cb$o || '']));
  }var nhkzv6 = uxg21['indexOf'](':');nhkzv6 > 0x0 ? (cb$o = vjnxsh['prefix'] = uxg21['slice'](0x0, nhkzv6), vd6khz = vjnxsh['localName'] = uxg21['slice'](nhkzv6 + 0x1)) : (cb$o = null, vd6khz = vjnxsh['localName'] = uxg21);var c0ylb$ = vjnxsh['uri'] = pr7i53[cb$o || ''];if (d85qtr['startElement'](c0ylb$, vd6khz, uxg21, vjnxsh), !vjnxsh['closed']) return vjnxsh['currentNSMap'] = pr7i53, vjnxsh['localNSMap'] = zjnsh, !0x0;if (d85qtr['endElement'](c0ylb$, vd6khz, uxg21), zjnsh) {
    for (cb$o in zjnsh) d85qtr['endPrefixMapping'](cb$o);
  }
}function go4uw_e(szhjn, sg2x, dzqk86, zkdqh, w1eu2g) {
  if (/^(?:script|textarea)$/i['test'](dzqk86)) {
    var pr7 = szhjn['indexOf']('</' + dzqk86 + '>', sg2x),
        bycm = szhjn['substring'](sg2x + 0x1, pr7);if (/[&<]/['test'](bycm)) return (/^script$/i['test'](dzqk86) ? (w1eu2g['characters'](bycm, 0x0, bycm['length']), pr7) : (bycm = bycm['replace'](/&#?\w+;/g, zkdqh), w1eu2g['characters'](bycm, 0x0, bycm['length']), pr7)
    );
  }return sg2x + 0x1;
}function gueow4_(cbm$a, q6hzd, cmbl$y, ri5p37) {
  var y4bo0c = ri5p37[cmbl$y];return null == y4bo0c && (y4bo0c = cbm$a['lastIndexOf']('</' + cmbl$y + '>'), q6hzd > y4bo0c && (y4bo0c = cbm$a['lastIndexOf']('</' + cmbl$y)), ri5p37[cmbl$y] = y4bo0c), q6hzd > y4bo0c;
}function gfsj1nx(fg2uw1, jszhv) {
  for (var gu2 in fg2uw1) jszhv[gu2] = fg2uw1[gu2];
}function gjsxv($clymb, _we0o4, ewo_0, c_0o4y) {
  var am$9b = $clymb['charAt'](_we0o4 + 0x2);switch (am$9b) {case '-':
      if ('-' === $clymb['charAt'](_we0o4 + 0x3)) {
        var o_e = $clymb['indexOf']('-->', _we0o4 + 0x4);return o_e > _we0o4 ? (ewo_0['comment']($clymb, _we0o4 + 0x4, o_e - _we0o4 - 0x4), o_e + 0x3) : (c_0o4y['error']('Unclosed comment'), -0x1);
      }return -0x1;default:
      if ('CDATA[' == $clymb['substr'](_we0o4 + 0x3, 0x6)) {
        var o_e = $clymb['indexOf'](']]>', _we0o4 + 0x9);return ewo_0['startCDATA'](), ewo_0['characters']($clymb, _we0o4 + 0x9, o_e - _we0o4 - 0x9), ewo_0['endCDATA'](), o_e + 0x3;
      }var yc0$l = g$boc0y($clymb, _we0o4),
          xj1f2s = yc0$l['length'];if (xj1f2s > 0x1 && /!doctype/i['test'](yc0$l[0x0][0x0])) {
        var t58qd = yc0$l[0x1][0x0],
            kq6hd = xj1f2s > 0x3 && /^public$/i['test'](yc0$l[0x2][0x0]) && yc0$l[0x3][0x0],
            $lm = xj1f2s > 0x4 && yc0$l[0x4][0x0],
            t6kqd8 = yc0$l[xj1f2s - 0x1];return ewo_0['startDTD'](t58qd, kq6hd && kq6hd['replace'](/^(['"])(.*?)\1$/, '$2'), $lm && $lm['replace'](/^(['"])(.*?)\1$/, '$2')), ewo_0['endDTD'](), t6kqd8['index'] + t6kqd8[0x0]['length'];
      }}return -0x1;
}function gzkvjnh(gue1w, yob0, we4u_o) {
  var l9a = gue1w['indexOf']('?>', yob0);if (l9a) {
    var tp537r = gue1w['substring'](yob0, l9a)['match'](/^<\?(\S*)\s*([\s\S]*?)\s*$/);if (tp537r) {
      {
        tp537r[0x0]['length'];
      }return we4u_o['processingInstruction'](tp537r[0x1], tp537r[0x2]), l9a + 0x2;
    }return -0x1;
  }return -0x1;
}function gvkhd6z() {}function gxjnfv(vzhn6k, c$boy0) {
  return vzhn6k['__proto__'] = c$boy0, vzhn6k;
}function g$boc0y(znhvkj, fx1nj) {
  var t785r,
      f1nsx = [],
      q6z8d = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;for (q6z8d['lastIndex'] = fx1nj, q6z8d['exec'](znhvkj); t785r = q6z8d['exec'](znhvkj);) if (f1nsx['push'](t785r), t785r[0x1]) return f1nsx;
}var gf12jxs = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    ge_wu4o = new RegExp('[\\-\\.0-9' + gf12jxs['source']['slice'](0x1, -0x1) + '\\u00B7\\u0300-\\u036F\\u203F-\\u2040]'),
    gfnjv = new RegExp('^' + gf12jxs['source'] + ge_wu4o['source'] + '*(?::' + gf12jxs['source'] + ge_wu4o['source'] + '*)?$'),
    gx1gf2 = 0x0,
    gx1ugf2 = 0x1,
    gdv6kh = 0x2,
    gmby$l = 0x3,
    gmcy$lb = 0x4,
    gguw21 = 0x5,
    gueg_w = 0x6,
    g_eo04w = 0x7;gq8k6d['prototype'] = { 'parse': function (hvzjsn, jfxvns, vhnjk) {
    var y$cmb = this['domBuilder'];y$cmb['startDocument'](), gfsj1nx(jfxvns, jfxvns = {}), gboc0(hvzjsn, jfxvns, vhnjk, y$cmb, this['errorHandler']), y$cmb['endDocument']();
  } }, gvkhd6z['prototype'] = { 'setTagName': function (vhsznj) {
    if (!gfnjv['test'](vhsznj)) throw new Error('invalid tagName:' + vhsznj);this['tagName'] = vhsznj;
  }, 'add': function (rd6q8, _y40oe, _euw2g) {
    if (!gfnjv['test'](rd6q8)) throw new Error('invalid attribute:' + rd6q8);this[this['length']++] = { 'qName': rd6q8, 'value': _y40oe, 'offset': _euw2g };
  }, 'length': 0x0, 'getLocalName': function (fs21jx) {
    return this[fs21jx]['localName'];
  }, 'getLocator': function (ugwf) {
    return this[ugwf]['locator'];
  }, 'getQName': function (s1jnxf) {
    return this[s1jnxf]['qName'];
  }, 'getURI': function (qk6d) {
    return this[qk6d]['uri'];
  }, 'getValue': function (f12xjs) {
    return this[f12xjs]['value'];
  } }, gxjnfv({}, gxjnfv['prototype']) instanceof gxjnfv || (gxjnfv = function (c0lyb, sf1x2g) {
  function w2gu_e() {}w2gu_e['prototype'] = sf1x2g, w2gu_e = new w2gu_e();for (sf1x2g in c0lyb) w2gu_e[sf1x2g] = c0lyb[sf1x2g];return w2gu_e;
}), exports['XMLReader'] = gq8k6d;