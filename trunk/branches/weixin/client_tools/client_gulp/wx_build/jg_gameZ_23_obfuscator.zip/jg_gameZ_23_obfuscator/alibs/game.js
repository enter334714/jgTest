var c = wx.$a;
require(c[31172]);