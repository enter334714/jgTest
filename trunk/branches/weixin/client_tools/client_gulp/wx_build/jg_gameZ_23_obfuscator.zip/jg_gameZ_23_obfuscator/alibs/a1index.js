var c = wx.$a;
import ga$l9b from '../a3a4/eeesdk.js';window[c[30643]] = { 'wxVersion': window[c[1153]][c[30527]] }, window[c[30644]] = ![], window[c[30645]] = 0x1, window[c[30646]] = 0x1, window[c[30647]] = !![], window[c[30648]] = !![], window[c[30649]] = '', window[c[30650]] = ![], window[c[30532]] = { 'base_cdn': c[30651], 'cdn': c[30651] }, j1E[c[30652]] = {}, j1E[c[478]] = '0', j1E[c[5606]] = window[c[30643]][c[30653]], j1E[c[30613]] = '', j1E['os'] = '1', j1E[c[30654]] = c[30655], j1E[c[30656]] = c[30657], j1E[c[30658]] = c[30659], j1E[c[30660]] = c[30661], j1E[c[30662]] = c[30663], j1E[c[24994]] = '1', j1E[c[26692]] = '', j1E[c[26694]] = '', j1E[c[30664]] = 0x0, j1E[c[30665]] = {}, j1E[c[30666]] = parseInt(j1E[c[24994]]), j1E[c[26690]] = j1E[c[24994]], j1E[c[26686]] = {}, j1E[c[30538]] = c[30667], j1E[c[30668]] = ![], j1E[c[13306]] = c[30669], j1E[c[26658]] = Date[c[696]](), j1E[c[12906]] = c[30670], j1E[c[1329]] = '_a', j1E[c[30671]] = 0x2, j1E[c[713]] = 0x7c1, j1E[c[30653]] = window[c[30643]][c[30653]], j1E[c[1353]] = ![], j1E[c[1688]] = ![], j1E[c[12298]] = ![], j1E[c[26387]] = ![], window[c[30672]] = 0x5, window[c[30673]] = ![], window[c[30568]] = ![], window[c[30576]] = ![], window[c[30674]] = ![], window[c[30675]] = ![], window[c[30676]] = ![], window[c[30677]] = ![], window[c[30678]] = ![], window[c[30679]] = ![], window[c[30680]] = null, window[c[1232]] = function (d8q6z) {
  console[c[442]](c[1232], d8q6z), wx[c[5886]]({}), wx[c[30556]]({ 'title': c[7266], 'content': d8q6z, 'success'(fg1sx2) {
      if (fg1sx2[c[30681]]) console[c[442]](c[30682]);else fg1sx2[c[1149]] && console[c[442]](c[30683]);
    } });
}, window[c[30684]] = function (sx2f1) {
  console[c[442]](c[30685], sx2f1), jM1EB(), wx[c[30556]]({ 'title': c[7266], 'content': sx2f1, 'confirmText': c[30686], 'cancelText': c[19778], 'success'(s2jf1x) {
      if (s2jf1x[c[30681]]) window[c[30582]]();else s2jf1x[c[1149]] && (console[c[442]](c[30687]), wx[c[26384]]({}));
    } });
}, window[c[30688]] = function (hkvzn) {
  console[c[442]](c[30688], hkvzn), wx[c[30556]]({ 'title': c[7266], 'content': hkvzn, 'confirmText': c[26821], 'showCancel': ![], 'complete'(sfg21) {
      console[c[442]](c[30687]), wx[c[26384]]({});
    } });
}, window[c[30689]] = ![], window[c[30690]] = function (kdq68) {
  window[c[30689]] = !![], wx[c[5885]](kdq68);
}, window[c[30691]] = function () {
  window[c[30689]] && (window[c[30689]] = ![], wx[c[5886]]({}));
}, window[c[30692]] = function (_o4e0) {
  window[c[30544]][c[759]][c[30692]](_o4e0);
}, window[c[617]] = function (d86qkz, ug2e1w) {
  ga$l9b[c[617]](d86qkz, function (pt35r7) {
    pt35r7 && pt35r7[c[487]] ? pt35r7[c[487]][c[1873]] == 0x1 ? ug2e1w(!![]) : (ug2e1w(![]), console[c[691]](c[30693] + pt35r7[c[487]][c[30694]])) : console[c[442]](c[617], pt35r7);
  });
}, window[c[30695]] = function (gf1x2s) {
  console[c[442]](c[30696], gf1x2s);
}, window[c[30697]] = function (dhkzq) {}, window[c[30698]] = function (dh6vkz, jfs1x2, d8k) {}, window[c[30699]] = function (p57ri3) {
  console[c[442]](c[30700], p57ri3), window[c[30544]][c[759]][c[30701]](), window[c[30544]][c[759]][c[30702]](), window[c[30544]][c[759]][c[30703]]();
}, window[c[30704]] = function (r5q7t8) {
  window[c[30705]](0xe, c[30706] + r5q7t8), window[c[30684]](c[30707]);var u4eow_ = { 'id': window[c[30532]][c[30533]], 'role': window[c[30532]][c[5535]], 'level': window[c[30532]][c[30534]], 'account': window[c[30532]][c[26691]], 'version': window[c[30532]][c[713]], 'cdn': window[c[30532]][c[5415]], 'pkgName': window[c[30532]][c[26692]], 'gamever': window[c[1153]][c[30527]], 'serverid': window[c[30532]][c[26686]] ? window[c[30532]][c[26686]][c[596]] : 0x0, 'systemInfo': window[c[30535]], 'error': c[30708], 'stack': r5q7t8 ? r5q7t8 : c[30707] },
      q5td8 = JSON[c[5401]](u4eow_);console[c[485]](c[30709] + q5td8), window[c[30538]](q5td8);
}, window[c[30705]] = function (hvnsjx, vk) {
  sendApi(j1E[c[30658]], c[30710], { 'game_pkg': j1E[c[26692]], 'partner_id': j1E[c[24994]], 'server_id': j1E[c[26686]] && j1E[c[26686]][c[596]] > 0x0 ? j1E[c[26686]][c[596]] : 0x0, 'uid': j1E[c[26691]] > 0x0 ? j1E[c[26691]] : 0x0, 'type': hvnsjx, 'info': vk });
}, window[c[30711]] = function (e04o_y) {
  var yo4cb0 = JSON[c[441]](e04o_y);yo4cb0[c[30712]] = window[c[1153]][c[30527]], yo4cb0[c[30713]] = window[c[30532]][c[26686]] ? window[c[30532]][c[26686]][c[596]] : 0x0, yo4cb0[c[30535]] = window[c[30535]];var xsjvhn = JSON[c[5401]](yo4cb0);console[c[485]](c[30714] + xsjvhn), window[c[30538]](xsjvhn);
}, window[c[30583]] = function (zk6dq8, e0w_4o) {
  var irp735 = { 'id': window[c[30532]][c[30533]], 'role': window[c[30532]][c[5535]], 'level': window[c[30532]][c[30534]], 'account': window[c[30532]][c[26691]], 'version': window[c[30532]][c[713]], 'cdn': window[c[30532]][c[5415]], 'pkgName': window[c[30532]][c[26692]], 'gamever': window[c[1153]][c[30527]], 'serverid': window[c[30532]][c[26686]] ? window[c[30532]][c[26686]][c[596]] : 0x0, 'systemInfo': window[c[30535]], 'error': zk6dq8, 'stack': e0w_4o },
      dz8k6q = JSON[c[5401]](irp735);console[c[498]](c[30715] + dz8k6q), window[c[30538]](dz8k6q);
}, window[c[30538]] = function (ugxf2) {
  if (window[c[30532]][c[30614]] == c[30716]) return;var eg4u = j1E[c[30538]] + c[30717] + j1E[c[26691]];wx[c[1076]]({ 'url': eg4u, 'method': c[552], 'data': ugxf2, 'header': { 'content-type': c[30718], 'cache-control': c[30719] }, 'success': function (vnxshj) {
      DEBUG && console[c[442]](c[30720], eg4u, ugxf2, vnxshj);
    }, 'fail': function (dv6zk) {
      DEBUG && console[c[442]](c[30720], eg4u, ugxf2, dv6zk);
    }, 'complete': function () {} });
}, window[c[30721]] = function () {
  function bmacl() {
    return ((0x1 + Math[c[728]]()) * 0x10000 | 0x0)[c[327]](0x10)[c[448]](0x1);
  }return bmacl() + bmacl() + '-' + bmacl() + '-' + bmacl() + '-' + bmacl() + '+' + bmacl() + bmacl() + bmacl();
}, window[c[30582]] = function () {
  console[c[442]](c[30722]);var sx1njf = ga$l9b[c[30723]]();j1E[c[26690]] = sx1njf[c[30724]], j1E[c[30666]] = sx1njf[c[30724]], j1E[c[24994]] = sx1njf[c[30724]], j1E[c[26692]] = sx1njf[c[30725]];var zkvhd = { 'game_ver': j1E[c[5606]] };j1E[c[26694]] = this[c[30721]](), jM1BE({ 'title': c[30726] }), ga$l9b[c[612]](zkvhd, this[c[30727]][c[297]](this));
}, window[c[30727]] = function (gue4w_) {
  var o4c0b = gue4w_[c[30728]];sdkInitRes = gue4w_, console[c[442]](c[30729] + o4c0b + c[30730] + (o4c0b == 0x1) + c[30731] + gue4w_[c[30527]] + c[30732] + window[c[30643]][c[30653]]);if (!gue4w_[c[30527]] || window[c[30547]](window[c[30643]][c[30653]], gue4w_[c[30527]]) < 0x0) console[c[442]](c[30733]), j1E[c[30656]] = c[30734], j1E[c[30658]] = c[30735], j1E[c[30660]] = c[30736], j1E[c[5415]] = c[30737], j1E[c[26385]] = c[30738], j1E[c[30739]] = c[30740], j1E[c[1353]] = ![];else window[c[30547]](window[c[30643]][c[30653]], gue4w_[c[30527]]) == 0x0 ? (console[c[442]](c[30741]), j1E[c[30656]] = c[30657], j1E[c[30658]] = c[30659], j1E[c[30660]] = c[30661], j1E[c[5415]] = c[30742], j1E[c[26385]] = c[30738], j1E[c[30739]] = c[30743], j1E[c[1353]] = !![]) : (console[c[442]](c[30744]), j1E[c[30656]] = c[30657], j1E[c[30658]] = c[30659], j1E[c[30660]] = c[30661], j1E[c[5415]] = c[30742], j1E[c[26385]] = c[30738], j1E[c[30739]] = c[30743], j1E[c[1353]] = ![]);j1E[c[30664]] = config[c[322]] ? config[c[322]] : 0x0, this[c[30745]](), this[c[30746]](), window[c[30747]] = 0x5, jM1BE({ 'title': c[30748] }), ga$l9b[c[546]](this[c[30749]][c[297]](this));
}, window[c[30747]] = 0x5, window[c[30749]] = function (t7r83, ew1ug2) {
  if (t7r83 == 0x0 && ew1ug2 && ew1ug2[c[473]]) {
    j1E[c[30750]] = ew1ug2[c[473]];var hkvd6 = this;jM1BE({ 'title': c[30751] }), sendApi(j1E[c[30656]], c[30752], { 'platform': j1E[c[30654]], 'partner_id': j1E[c[24994]], 'token': ew1ug2[c[473]], 'game_pkg': j1E[c[26692]], 'deviceId': j1E[c[26694]], 'scene': c[30753] + j1E[c[30664]] }, this[c[30754]][c[297]](this), jBE1, jEM);
  } else ew1ug2 && ew1ug2[c[26885]] && window[c[30747]] > 0x0 && (ew1ug2[c[26885]][c[390]](c[30755]) != -0x1 || ew1ug2[c[26885]][c[390]](c[30756]) != -0x1 || ew1ug2[c[26885]][c[390]](c[30757]) != -0x1 || ew1ug2[c[26885]][c[390]](c[30758]) != -0x1 || ew1ug2[c[26885]][c[390]](c[30759]) != -0x1 || ew1ug2[c[26885]][c[390]](c[30760]) != -0x1) ? (window[c[30747]]--, ga$l9b[c[546]](this[c[30749]][c[297]](this))) : (window[c[30705]](0x1, c[30761] + t7r83 + c[30762] + (ew1ug2 ? ew1ug2[c[26885]] : '')), window[c[30583]](c[30763], JSON[c[5401]]({ 'status': t7r83, 'data': ew1ug2 })), window[c[30684]](c[30764] + (ew1ug2 && ew1ug2[c[26885]] ? '，' + ew1ug2[c[26885]] : '')));
}, window[c[30754]] = function (ambcl$) {
  if (!ambcl$) {
    window[c[30705]](0x2, c[30765]), window[c[30583]](c[30766], c[30767]), window[c[30684]](c[30768]);return;
  }if (ambcl$[c[1873]] != c[10850]) {
    window[c[30705]](0x2, c[30769] + ambcl$[c[1873]]), window[c[30583]](c[30766], JSON[c[5401]](ambcl$)), window[c[30684]](c[30770] + ambcl$[c[1873]]);return;
  }j1E[c[20157]] = String(ambcl$[c[26691]]), j1E[c[26691]] = String(ambcl$[c[26691]]), j1E[c[26656]] = String(ambcl$[c[26656]]), j1E[c[26690]] = String(ambcl$[c[26656]]), j1E[c[26693]] = String(ambcl$[c[26693]]), j1E[c[30771]] = String(ambcl$[c[12459]]), j1E[c[30772]] = String(ambcl$[c[1465]]), j1E[c[12459]] = '';var ptr753 = this;jM1BE({ 'title': c[30773] });var mabcl$ = localStorage[c[1079]](c[30774] + j1E[c[26692]] + j1E[c[26691]]);if (mabcl$ && mabcl$ != '') {
    var dqz86k = Number(mabcl$);ptr753[c[30775]](dqz86k);
  } else ptr753[c[30776]]();
}, window[c[30776]] = function () {
  var mal$9 = this;sendApi(j1E[c[30656]], c[30777], { 'partner_id': j1E[c[24994]], 'uid': j1E[c[26691]], 'version': j1E[c[5606]], 'game_pkg': j1E[c[26692]], 'device': j1E[c[26694]] }, mal$9[c[30778]][c[297]](mal$9), jBE1, jEM);
}, window[c[30778]] = function (bmc$la) {
  if (!bmc$la) {
    window[c[30705]](0x3, c[30779]), window[c[30684]](c[30779]);return;
  }if (bmc$la[c[1873]] != c[10850]) {
    window[c[30705]](0x3, c[30780] + bmc$la[c[1873]]), window[c[30684]](c[30780] + bmc$la[c[1873]]);return;
  }if (!bmc$la[c[487]] || bmc$la[c[487]][c[308]] == 0x0) {
    window[c[30705]](0x3, c[30781]), window[c[30684]](c[30782]);return;
  }this[c[30783]](bmc$la);
}, window[c[30775]] = function (we4u_o) {
  var r5tq78 = this;sendApi(j1E[c[30656]], c[30784], { 'server_id': we4u_o, 'time': Date[c[696]]() / 0x3e8 }, r5tq78[c[30785]][c[297]](r5tq78), jBE1, jEM);
}, window[c[30785]] = function (fxjsvn) {
  if (!fxjsvn) {
    window[c[30705]](0x4, c[30786]), this[c[30776]]();return;
  }if (fxjsvn[c[1873]] != c[10850]) {
    window[c[30705]](0x4, c[30787] + fxjsvn[c[1873]]), this[c[30776]]();return;
  }if (!fxjsvn[c[487]] || fxjsvn[c[487]][c[308]] == 0x0) {
    window[c[30705]](0x4, c[30788]), this[c[30776]]();return;
  }this[c[30783]](fxjsvn), window[c[30544]] && window[c[30544]][c[759]][c[30789]] && window[c[30544]][c[759]][c[30789]](sdkInitRes[c[30790]], sdkInitRes[c[30791]], sdkInitRes[c[30792]], sdkInitRes[c[30793]], sdkInitRes[c[30794]]);
}, window[c[30783]] = function (sxh) {
  j1E[c[1242]] = sxh[c[30795]] != undefined ? sxh[c[30795]] : 0x0, j1E[c[26686]] = { 'server_id': String(sxh[c[487]][0x0][c[596]]), 'server_name': String(sxh[c[487]][0x0][c[30796]]), 'entry_ip': sxh[c[487]][0x0][c[26716]], 'entry_port': parseInt(sxh[c[487]][0x0][c[26717]]), 'status': j1BM(sxh[c[487]][0x0]), 'start_time': sxh[c[487]][0x0][c[30797]], 'cdn': j1E[c[5415]] }, this[c[30798]]();
}, window[c[30798]] = function () {
  var pt5r7 = this;if (j1E[c[1242]] == 0x1) {
    var ocb40 = j1E[c[26686]][c[718]];if (ocb40 === -0x1 || ocb40 === 0x0) {
      window[c[30705]](0xf, c[30799] + j1E[c[26686]]['id'] + c[30800] + j1E[c[26686]][c[718]]), window[c[30684]](ocb40 === -0x1 ? c[30801] : c[30802]);return;
    }jEMB1(0x0, j1E[c[26686]][c[596]]), window[c[30544]][c[759]][c[30803]](j1E[c[1242]]);
  } else window[c[30544]][c[759]][c[30804]](), jM1EB();window[c[30678]] = !![], window[c[30569]](), window[c[30570]]();
}, window[c[30745]] = function () {
  sendApi(j1E[c[30656]], c[30805], { 'game_pkg': j1E[c[26692]], 'version_name': j1E[c[30739]] }, this[c[30806]][c[297]](this), jBE1, jEM);
}, window[c[30806]] = function (kdz6q) {
  if (!kdz6q) {
    window[c[30705]](0x5, c[30807]), window[c[30684]](c[30807]);return;
  }if (kdz6q[c[1873]] != c[10850]) {
    window[c[30705]](0x5, c[30808] + kdz6q[c[1873]]), window[c[30684]](c[30808] + kdz6q[c[1873]]);return;
  }if (!kdz6q[c[487]] || !kdz6q[c[487]][c[5606]]) {
    window[c[30705]](0x5, c[30809] + (kdz6q[c[487]] && kdz6q[c[487]][c[5606]])), window[c[30684]](c[30809] + (kdz6q[c[487]] && kdz6q[c[487]][c[5606]]));return;
  }kdz6q[c[487]][c[30810]] && kdz6q[c[487]][c[30810]][c[308]] > 0xa && (j1E[c[30811]] = kdz6q[c[487]][c[30810]], j1E[c[5415]] = kdz6q[c[487]][c[30810]]), kdz6q[c[487]][c[5606]] && (j1E[c[713]] = kdz6q[c[487]][c[5606]]), console[c[691]](c[26828] + j1E[c[713]] + c[30812] + j1E[c[30739]]), window[c[30676]] = !![], window[c[30569]](), window[c[30570]]();
}, window[c[30813]], window[c[30746]] = function () {
  sendApi(j1E[c[30656]], c[30814], { 'game_pkg': j1E[c[26692]] }, this[c[30815]][c[297]](this), jBE1, jEM);
}, window[c[30815]] = function (dtr6) {
  if (dtr6 && dtr6[c[1873]] === c[10850] && dtr6[c[487]]) {
    window[c[30813]] = dtr6[c[487]];for (var cb$myl in dtr6[c[487]]) {
      j1E[cb$myl] = dtr6[c[487]][cb$myl];
    }
  } else window[c[30705]](0xb, c[30816]), console[c[691]](c[30817] + dtr6[c[1873]]);window[c[30677]] = !![], window[c[30570]]();
}, window[c[30818]] = function (_e2wu, u12ew, p35r7, $ab9l, y40o_, k6td8q, dzvk6, snfxvj, gxu1, ux2g1f) {
  y40o_ = String(y40o_);var rq6t8d = dzvk6,
      hnjkvz = snfxvj;j1E[c[30652]][y40o_] = { 'productid': y40o_, 'productname': rq6t8d, 'productdesc': hnjkvz, 'roleid': _e2wu, 'rolename': u12ew, 'rolelevel': p35r7, 'price': k6td8q, 'callback': gxu1 }, sendApi(j1E[c[30660]], c[30819], { 'game_pkg': j1E[c[26692]], 'server_id': j1E[c[26686]][c[596]], 'server_name': j1E[c[26686]][c[30796]], 'level': p35r7, 'uid': j1E[c[26691]], 'role_id': _e2wu, 'role_name': u12ew, 'product_id': y40o_, 'product_name': rq6t8d, 'product_desc': hnjkvz, 'money': k6td8q, 'partner_id': j1E[c[24994]] }, toPayCallBack, jBE1, jEM);
}, window[c[30820]] = function (d8q6rt) {
  if (d8q6rt && (d8q6rt[c[30821]] === 0xc8 || d8q6rt[c[1873]] == c[10850])) {
    var dq8kz = j1E[c[30652]][String(d8q6rt[c[30822]])];if (dq8kz[c[933]]) dq8kz[c[933]](d8q6rt[c[30822]], d8q6rt[c[30823]], -0x1);ga$l9b[c[583]]({ 'cpbill': d8q6rt[c[30823]], 'productid': d8q6rt[c[30822]], 'productname': dq8kz[c[30824]], 'productdesc': dq8kz[c[30825]], 'serverid': j1E[c[26686]][c[596]], 'servername': j1E[c[26686]][c[30796]], 'roleid': dq8kz[c[30826]], 'rolename': dq8kz[c[30827]], 'rolelevel': dq8kz[c[30828]], 'price': dq8kz[c[28470]], 'extension': JSON[c[5401]]({ 'cp_order_id': d8q6rt[c[30823]] }) }, function (kzhv6, j21s) {
      dq8kz[c[933]] && kzhv6 == 0x0 && dq8kz[c[933]](d8q6rt[c[30822]], d8q6rt[c[30823]], kzhv6);console[c[691]](JSON[c[5401]]({ 'type': c[30829], 'status': kzhv6, 'data': d8q6rt, 'role_name': dq8kz[c[30827]] }));if (kzhv6 === 0x0) {} else {
        if (kzhv6 === 0x1) {} else {
          if (kzhv6 === 0x2) {}
        }
      }
    });
  } else {
    var eo_0w4 = d8q6rt ? c[30830] + d8q6rt[c[30821]] + c[30831] + d8q6rt[c[1873]] + c[30832] + d8q6rt[c[691]] : c[30833];window[c[30705]](0xd, c[30834] + eo_0w4), alert(eo_0w4);
  }
}, window[c[30835]] = function () {}, window[c[30836]] = function (zqhdk, u21fw, ktq6d8, vkznh6, y0cl$b) {
  ga$l9b[c[614]](j1E[c[26686]][c[596]], j1E[c[26686]][c[30796]] || j1E[c[26686]][c[596]], zqhdk, u21fw, ktq6d8), sendApi(j1E[c[30656]], c[30837], { 'game_pkg': j1E[c[26692]], 'server_id': j1E[c[26686]][c[596]], 'role_id': zqhdk, 'uid': j1E[c[26691]], 'role_name': u21fw, 'role_type': vkznh6, 'level': ktq6d8 });
}, window[c[30838]] = function (nj1sf, amlb$9, ycob0$, h6v, hjx, xuf2g, szhnv, uf1gw, r5t387, qrt85) {
  j1E[c[30533]] = nj1sf, j1E[c[5535]] = amlb$9, j1E[c[30534]] = ycob0$, ga$l9b[c[615]](j1E[c[26686]][c[596]], j1E[c[26686]][c[30796]] || j1E[c[26686]][c[596]], nj1sf, amlb$9, ycob0$), sendApi(j1E[c[30656]], c[30839], { 'game_pkg': j1E[c[26692]], 'server_id': j1E[c[26686]][c[596]], 'role_id': nj1sf, 'uid': j1E[c[26691]], 'role_name': amlb$9, 'role_type': h6v, 'level': ycob0$, 'evolution': hjx });
}, window[c[30840]] = function (oc_0y, pt735r, j1nfx, cbo40y, w1g2uf, mla9$, b$lc0, g4w, b4yo0, c0b4y) {
  j1E[c[30533]] = oc_0y, j1E[c[5535]] = pt735r, j1E[c[30534]] = j1nfx, ga$l9b[c[616]](j1E[c[26686]][c[596]], j1E[c[26686]][c[30796]] || j1E[c[26686]][c[596]], oc_0y, pt735r, j1nfx), sendApi(j1E[c[30656]], c[30839], { 'game_pkg': j1E[c[26692]], 'server_id': j1E[c[26686]][c[596]], 'role_id': oc_0y, 'uid': j1E[c[26691]], 'role_name': pt735r, 'role_type': cbo40y, 'level': j1nfx, 'evolution': w1g2uf });
}, window[c[30841]] = function (ye4o) {}, window[c[30842]] = function (e4g_uw) {
  ga$l9b[c[567]](c[567], function (uwoe) {
    e4g_uw && e4g_uw(uwoe);
  });
}, window[c[613]] = function () {
  ga$l9b[c[613]]();
}, window[c[30843]] = function () {
  ga$l9b[c[620]]();
}, window[c[30844]] = function (sn1fj, kjhvz, kvhznj, mla, ylc$, gw, sx1gf2, xhjsv) {
  xhjsv = xhjsv || j1E[c[26686]][c[596]], sendApi(j1E[c[30656]], c[30845], { 'phone': sn1fj, 'role_id': kjhvz, 'uid': j1E[c[26691]], 'game_pkg': j1E[c[26692]], 'partner_id': j1E[c[24994]], 'server_id': xhjsv }, sx1gf2, 0x2, null, function () {
    return !![];
  });
}, window[c[11804]] = function (ge_u) {
  window[c[30633]] = ge_u, window[c[30633]] && window[c[30632]] && (console[c[691]](c[30634] + window[c[30632]][c[1391]]), window[c[30633]](window[c[30632]]), window[c[30632]] = null);
}, window[c[30846]] = function (cb$0yl, y$mblc, qzd, yb$o) {
  window[c[641]](c[30847], { 'game_pkg': window[c[30532]][c[26692]], 'role_id': y$mblc, 'server_id': qzd }, yb$o);
}, window[c[30848]] = function (b$alm, kq6, y$mbcl) {
  function co40y_(dzh6v) {
    var y$bcm = [],
        g_ew4 = [],
        xfu2g1 = y$mbcl || window[c[1153]][c[30849]];for (var fjx1s in xfu2g1) {
      var wug_2e = Number(fjx1s);(!b$alm || !b$alm[c[308]] || b$alm[c[390]](wug_2e) != -0x1) && (g_ew4[c[330]](xfu2g1[fjx1s]), y$bcm[c[330]]([wug_2e, 0x3]));
    }window[c[30547]](window[c[30548]], c[30850]) >= 0x0 ? (console[c[442]](c[30851]), ga$l9b[c[609]] && ga$l9b[c[609]](g_ew4, function (njvhsz) {
      console[c[442]](c[30852]), console[c[442]](njvhsz);if (njvhsz && njvhsz[c[26885]] == c[30853]) for (var b9mal$ in xfu2g1) {
        if (njvhsz[xfu2g1[b9mal$]] == c[30854]) {
          var vsjxnh = Number(b9mal$);for (var cm$bla = 0x0; cm$bla < y$bcm[c[308]]; cm$bla++) {
            if (y$bcm[cm$bla][0x0] == vsjxnh) {
              y$bcm[cm$bla][0x1] = 0x1;break;
            }
          }
        }
      }window[c[30547]](window[c[30548]], c[30855]) >= 0x0 ? wx[c[30856]]({ 'withSubscriptions': !![], 'success': function (fnvx) {
          var wu4oe = fnvx[c[30857]][c[30858]];if (wu4oe) {
            console[c[442]](c[30859]), console[c[442]](wu4oe);for (var bma9$l in xfu2g1) {
              if (wu4oe[xfu2g1[bma9$l]] == c[30854]) {
                var wuo_4e = Number(bma9$l);for (var ip57r = 0x0; ip57r < y$bcm[c[308]]; ip57r++) {
                  if (y$bcm[ip57r][0x0] == wuo_4e) {
                    y$bcm[ip57r][0x1] = 0x2;break;
                  }
                }
              }
            }console[c[442]](y$bcm), kq6 && kq6(y$bcm);
          } else console[c[442]](c[30860]), console[c[442]](fnvx), console[c[442]](y$bcm), kq6 && kq6(y$bcm);
        }, 'fail': function () {
          console[c[442]](c[30861]), console[c[442]](y$bcm), kq6 && kq6(y$bcm);
        } }) : (console[c[442]](c[30862] + window[c[30548]]), console[c[442]](y$bcm), kq6 && kq6(y$bcm));
    })) : (console[c[442]](c[30863] + window[c[30548]]), console[c[442]](y$bcm), kq6 && kq6(y$bcm)), wx[c[30864]](co40y_);
  }wx[c[30865]](co40y_);
}, window[c[30866]] = { 'isSuccess': ![], 'level': c[30867], 'isCharging': ![] }, window[c[14197]] = function (qd86k) {
  wx[c[30624]]({ 'success': function (ugwe21) {
      var r3tp5 = window[c[30866]];r3tp5[c[30868]] = !![], r3tp5[c[5512]] = Number(ugwe21[c[5512]])[c[5135]](0x0), r3tp5[c[30627]] = ugwe21[c[30627]], qd86k && qd86k(r3tp5[c[30868]], r3tp5[c[5512]], r3tp5[c[30627]]);
    }, 'fail': function (sxf2g1) {
      console[c[442]](c[30869], sxf2g1[c[26885]]);var p5tr = window[c[30866]];qd86k && qd86k(p5tr[c[30868]], p5tr[c[5512]], p5tr[c[30627]]);
    } });
}, window[c[12876]] = function ($al9mb) {
  wx[c[12876]]({ 'success': function (fg2x1s) {
      $al9mb && $al9mb(!![], fg2x1s);
    }, 'fail': function (ey0o_4) {
      $al9mb && $al9mb(![], ey0o_4);
    } });
}, window[c[12878]] = function (jhn) {
  if (jhn) wx[c[12878]](jhn);
}, window[c[26380]] = function (_0w4e) {
  wx[c[26380]](_0w4e);
}, window[c[641]] = function (fux1, y_o, q86kd, kqhz, d6qr8t, oc0b, uxgf12, y$mclb) {
  if (kqhz == undefined) kqhz = 0x1;wx[c[1076]]({ 'url': fux1, 'method': uxgf12 || c[26575], 'responseType': c[5319], 'data': y_o, 'header': { 'content-type': y$mclb || c[30718] }, 'success': function (zq6k) {
      DEBUG && console[c[442]](c[30870], fux1, info, zq6k);if (zq6k && zq6k[c[26953]] == 0xc8) {
        var lbymc = zq6k[c[487]];!oc0b || oc0b(lbymc) ? q86kd && q86kd(lbymc) : window[c[30871]](fux1, y_o, q86kd, kqhz, d6qr8t, oc0b, zq6k);
      } else window[c[30871]](fux1, y_o, q86kd, kqhz, d6qr8t, oc0b, zq6k);
    }, 'fail': function (knh6vz) {
      DEBUG && console[c[442]](c[30872], fux1, info, knh6vz), window[c[30871]](fux1, y_o, q86kd, kqhz, d6qr8t, oc0b, knh6vz);
    }, 'complete': function () {} });
}, window[c[30871]] = function (nsvzh, zhvdk6, vnjxfs, eu1wg, ey0o, $cylm, d6z8k) {
  eu1wg - 0x1 > 0x0 ? setTimeout(function () {
    window[c[641]](nsvzh, zhvdk6, vnjxfs, eu1wg - 0x1, ey0o, $cylm);
  }, 0x3e8) : ey0o && ey0o(JSON[c[5401]]({ 'url': nsvzh, 'response': d6z8k }));
}, window[c[30873]] = function (by$c0, jxfvn, pr753, rt57, y4o0_, l$mbyc, wu_4eo) {
  !pr753 && (pr753 = {});var rq8td6 = Math[c[335]](Date[c[696]]() / 0x3e8);pr753[c[1465]] = rq8td6, pr753[c[30874]] = jxfvn;var sfv = Object[c[307]](pr753)[c[497]](),
      jzvnsh = '',
      fu1w2g = '';for (var vx = 0x0; vx < sfv[c[308]]; vx++) {
    jzvnsh = jzvnsh + (vx == 0x0 ? '' : '&') + sfv[vx] + pr753[sfv[vx]], fu1w2g = fu1w2g + (vx == 0x0 ? '' : '&') + sfv[vx] + '=' + encodeURIComponent(pr753[sfv[vx]]);
  }jzvnsh = jzvnsh + j1E[c[30662]];var c_ = c[30875] + md5(jzvnsh);send(by$c0 + '?' + fu1w2g + (fu1w2g == '' ? '' : '&') + c_, null, rt57, y4o0_, l$mbyc, wu_4eo || function (lcy0) {
    return lcy0[c[1873]] == c[10850];
  }, null, c[553]);
}, window[c[30876]] = function (dq6kt8, qdh6k) {
  var fx1jns = 0x0;j1E[c[26686]] && (fx1jns = j1E[c[26686]][c[596]]), sendApi(j1E[c[30658]], c[30877], { 'partnerId': j1E[c[24994]], 'gamePkg': j1E[c[26692]], 'logTime': Math[c[335]](Date[c[696]]() / 0x3e8), 'platformUid': j1E[c[26693]], 'type': dq6kt8, 'serverId': fx1jns }, null, 0x2, null, function () {
    return !![];
  });
}, window[c[30878]] = function (r75p3i) {
  sendApi(j1E[c[30656]], c[30879], { 'partner_id': j1E[c[24994]], 'uid': j1E[c[26691]], 'version': j1E[c[5606]], 'game_pkg': j1E[c[26692]], 'device': j1E[c[26694]] }, j1EBM, jBE1, jEM);
}, window[c[30880]] = function (hk) {
  if (hk && hk[c[1873]] === c[10850] && hk[c[487]]) {
    hk[c[487]][c[413]]({ 'id': -0x2, 'name': c[30881] }), hk[c[487]][c[413]]({ 'id': -0x1, 'name': c[30882] }), j1E[c[30883]] = hk[c[487]];if (window[c[13357]]) window[c[13357]][c[30884]]();
  } else {
    j1E[c[30885]] = ![];var xsvnjh = hk ? hk[c[1873]] : '';window[c[30705]](0x7, c[30886] + xsvnjh), window[c[30684]](c[30887] + xsvnjh);
  }
}, window[c[30888]] = function (_w) {
  sendApi(j1E[c[30656]], c[30889], { 'partner_id': j1E[c[24994]], 'uid': j1E[c[26691]], 'version': j1E[c[5606]], 'game_pkg': j1E[c[26692]], 'device': j1E[c[26694]] }, jM1B, jBE1, jEM);
}, window[c[30890]] = function (h6kvzd) {
  j1E[c[30891]] = ![];if (h6kvzd && h6kvzd[c[1873]] === c[10850] && h6kvzd[c[487]]) {
    for (var tdk8 = 0x0; tdk8 < h6kvzd[c[487]][c[308]]; tdk8++) {
      h6kvzd[c[487]][tdk8][c[718]] = j1BM(h6kvzd[c[487]][tdk8]);
    }j1E[c[30665]][-0x1] = window[c[30892]](h6kvzd[c[487]]), window[c[13357]][c[30893]](-0x1);
  } else {
    var mbycl$ = h6kvzd ? h6kvzd[c[1873]] : '';window[c[30705]](0x8, c[30894] + mbycl$), window[c[30684]](c[30895] + mbycl$);
  }
}, window[c[30896]] = function (e4_0ow) {
  sendApi(j1E[c[30656]], c[30889], { 'partner_id': j1E[c[24994]], 'uid': j1E[c[26691]], 'version': j1E[c[5606]], 'game_pkg': j1E[c[26692]], 'device': j1E[c[26694]] }, e4_0ow, jBE1, jEM);
}, window[c[30897]] = function (weug4, uxg1f2) {
  sendApi(j1E[c[30656]], c[30898], { 'partner_id': j1E[c[24994]], 'uid': j1E[c[26691]], 'version': j1E[c[5606]], 'game_pkg': j1E[c[26692]], 'device': j1E[c[26694]], 'server_group_id': uxg1f2 }, jB1M, jBE1, jEM);
}, window[c[30899]] = function (gu21xf) {
  j1E[c[30891]] = ![];if (gu21xf && gu21xf[c[1873]] === c[10850] && gu21xf[c[487]] && gu21xf[c[487]][c[487]]) {
    var r37p5i = gu21xf[c[487]][c[30900]],
        boyc = [];for (var w4ug = 0x0; w4ug < gu21xf[c[487]][c[487]][c[308]]; w4ug++) {
      gu21xf[c[487]][c[487]][w4ug][c[718]] = j1BM(gu21xf[c[487]][c[487]][w4ug]), (boyc[c[308]] == 0x0 || gu21xf[c[487]][c[487]][w4ug][c[718]] != 0x0) && (boyc[boyc[c[308]]] = gu21xf[c[487]][c[487]][w4ug]);
    }j1E[c[30665]][r37p5i] = window[c[30892]](boyc), window[c[13357]][c[30893]](r37p5i);
  } else {
    var gx2 = gu21xf ? gu21xf[c[1873]] : '';window[c[30705]](0x9, c[30901] + gx2), window[c[30684]](c[30902] + gx2);
  }
}, window[c[30903]] = function (qh6zkd) {
  sendApi(j1E[c[30656]], c[30904], { 'partner_id': j1E[c[24994]], 'uid': j1E[c[26691]], 'version': j1E[c[5606]], 'game_pkg': j1E[c[26692]], 'device': j1E[c[26694]] }, reqServerRecommendCallBack, jBE1, jEM);
}, window[c[30905]] = function (eu21w) {
  j1E[c[30891]] = ![];if (eu21w && eu21w[c[1873]] === c[10850] && eu21w[c[487]]) {
    for (var o_u4ew = 0x0; o_u4ew < eu21w[c[487]][c[308]]; o_u4ew++) {
      eu21w[c[487]][o_u4ew][c[718]] = j1BM(eu21w[c[487]][o_u4ew]);
    }j1E[c[30665]][-0x2] = window[c[30892]](eu21w[c[487]]), window[c[13357]][c[30893]](-0x2);
  } else {
    var oy4b = eu21w ? eu21w[c[1873]] : '';window[c[30705]](0xa, c[30906] + oy4b), alert(c[30907] + oy4b);
  }
}, window[c[30892]] = function (q8z6d) {
  return q8z6d;
}, window[c[30908]] = function (ugwe12, a9lm$b) {
  ugwe12 = ugwe12 || j1E[c[26686]][c[596]], sendApi(j1E[c[30656]], c[30909], { 'type': '4', 'game_pkg': j1E[c[26692]], 'server_id': ugwe12 }, a9lm$b);
}, window[c[30910]] = function (r73t5, rt8753, cm$yb, fuwg21) {
  cm$yb = cm$yb || j1E[c[26686]][c[596]], sendApi(j1E[c[30656]], c[30911], { 'type': r73t5, 'game_pkg': rt8753, 'server_id': cm$yb }, fuwg21);
}, window[c[30912]] = function (w2ug_e, f12sxg) {
  sendApi(j1E[c[30656]], c[30913], { 'game_pkg': w2ug_e }, f12sxg);
}, window[c[30914]] = function (c$0ylb) {
  if (c$0ylb) {
    if (c$0ylb[c[718]] == 0x1) {
      if (c$0ylb[c[30915]] == 0x1) return 0x2;else return 0x1;
    } else return c$0ylb[c[718]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window[c[30916]] = function (jnxsvh, lmcb) {
  j1E[c[30917]] = { 'step': jnxsvh, 'server_id': lmcb };var wuoe = this;jM1BE({ 'title': c[30918] }), sendApi(j1E[c[30656]], c[30919], { 'partner_id': j1E[c[24994]], 'uid': j1E[c[26691]], 'game_pkg': j1E[c[26692]], 'server_id': lmcb, 'platform': j1E[c[26656]], 'platform_uid': j1E[c[26693]], 'check_login_time': j1E[c[30772]], 'check_login_sign': j1E[c[30771]], 'version_name': j1E[c[30739]] }, jEM1B, jBE1, jEM, function (al9mb) {
    return al9mb[c[1873]] == c[10850] || al9mb[c[691]] == c[30920] || al9mb[c[691]] == c[30921];
  });
}, window[c[30922]] = function (jvszh) {
  var qdt68 = this;if (jvszh && jvszh[c[1873]] === c[10850] && jvszh[c[487]]) {
    var dr5t8q = j1E[c[26686]];dr5t8q[c[30923]] = j1E[c[30666]], dr5t8q[c[12459]] = String(jvszh[c[487]][c[30924]]), dr5t8q[c[26658]] = parseInt(jvszh[c[487]][c[1465]]);if (jvszh[c[487]][c[26657]]) dr5t8q[c[26657]] = parseInt(jvszh[c[487]][c[26657]]);else dr5t8q[c[26657]] = parseInt(jvszh[c[487]][c[596]]);dr5t8q[c[30925]] = 0x0, dr5t8q[c[5415]] = j1E[c[30811]], dr5t8q[c[30926]] = jvszh[c[487]][c[30927]], dr5t8q[c[30928]] = jvszh[c[487]][c[30928]];if (jvszh[c[487]][c[26661]]) dr5t8q[c[26661]] = parseInt(jvszh[c[487]][c[26661]]);console[c[442]](c[30929] + JSON[c[5401]](dr5t8q[c[30928]])), j1E[c[1242]] == 0x1 && dr5t8q[c[30928]] && dr5t8q[c[30928]][c[30930]] == 0x1 && (j1E[c[30931]] = 0x1, window[c[30544]][c[759]][c[30932]]()), jEBM1();
  } else {
    if (j1E[c[30917]][c[8050]] >= 0x3) {
      var wgf2u1 = jvszh ? jvszh[c[1873]] : '';window[c[30705]](0xc, c[30933] + wgf2u1), jEM(JSON[c[5401]](jvszh)), window[c[30684]](c[30934] + wgf2u1);
    } else sendApi(j1E[c[30656]], c[30752], { 'platform': j1E[c[30654]], 'partner_id': j1E[c[24994]], 'token': j1E[c[30750]], 'game_pkg': j1E[c[26692]], 'deviceId': j1E[c[26694]], 'scene': c[30753] + j1E[c[30664]] }, function (o4w_e0) {
      if (!o4w_e0 || o4w_e0[c[1873]] != c[10850]) {
        window[c[30684]](c[30770] + o4w_e0 && o4w_e0[c[1873]]);return;
      }j1E[c[30771]] = String(o4w_e0[c[12459]]), j1E[c[30772]] = String(o4w_e0[c[1465]]), setTimeout(function () {
        jEMB1(j1E[c[30917]][c[8050]] + 0x1, j1E[c[30917]][c[596]]);
      }, 0x5dc);
    }, jBE1, jEM, function (xvnsf) {
      return xvnsf[c[1873]] == c[10850] || xvnsf[c[1873]] == c[27030];
    });
  }
}, window[c[30935]] = function () {
  ServerLoading[c[759]][c[30803]](j1E[c[1242]]), window[c[30673]] = !![], window[c[30570]]();
}, window[c[30569]] = function () {
  if (window[c[30568]] && window[c[30576]] && window[c[30674]] && window[c[30675]] && window[c[30676]] && window[c[30678]]) {
    if (!window[c[30523]][c[759]]) {
      console[c[442]](c[30936] + window[c[30523]][c[759]]);var gewu4 = wx[c[30937]](),
          sjznhv = gewu4[c[1391]] ? gewu4[c[1391]] : 0x0,
          t85 = { 'cdn': window[c[30532]][c[5415]], 'spareCdn': window[c[30532]][c[26385]], 'newRegister': window[c[30532]][c[1242]], 'wxPC': window[c[30532]][c[26387]], 'wxIOS': window[c[30532]][c[1688]], 'wxAndroid': window[c[30532]][c[12298]], 'wxParam': { 'limitLoad': window[c[30532]][c[30615]], 'benchmarkLevel': window[c[30532]][c[30616]], 'wxFrom': window[c[1153]][c[322]] == c[30938] ? 0x1 : 0x0, 'wxSDKVersion': window[c[30548]] }, 'configType': window[c[30532]][c[12906]], 'exposeType': window[c[30532]][c[1329]], 'scene': sjznhv };new window[c[30523]](t85, window[c[30532]][c[713]], window[c[30649]]);
    }
  }
}, window[c[30570]] = function () {
  if (window[c[30568]] && window[c[30576]] && window[c[30674]] && window[c[30675]] && window[c[30676]] && window[c[30678]] && window[c[30673]] && window[c[30677]]) {
    jM1EB();if (!jEB1) {
      jEB1 = !![];if (!window[c[30523]][c[759]]) window[c[30569]]();var vsjfn = 0x0,
          dqz68k = wx[c[30939]]();dqz68k && (window[c[30532]][c[30611]] && (vsjfn = dqz68k[c[918]]), console[c[691]](c[30940] + dqz68k[c[918]] + c[30941] + dqz68k[c[1900]] + c[30942] + dqz68k[c[1902]] + c[30943] + dqz68k[c[1901]] + c[30944] + dqz68k[c[788]] + c[30945] + dqz68k[c[789]]));var $mbylc = {};for (const d68qkt in j1E[c[26686]]) {
        $mbylc[d68qkt] = j1E[c[26686]][d68qkt];
      }var p3r57 = { 'channel': window[c[30532]][c[26690]], 'account': window[c[30532]][c[26691]], 'userId': window[c[30532]][c[20157]], 'cdn': window[c[30532]][c[5415]], 'data': window[c[30532]][c[487]], 'package': window[c[30532]][c[478]], 'newRegister': window[c[30532]][c[1242]], 'pkgName': window[c[30532]][c[26692]], 'partnerId': window[c[30532]][c[24994]], 'platform_uid': window[c[30532]][c[26693]], 'deviceId': window[c[30532]][c[26694]], 'selectedServer': $mbylc, 'configType': window[c[30532]][c[12906]], 'exposeType': window[c[30532]][c[1329]], 'debugUsers': window[c[30532]][c[13306]], 'wxMenuTop': vsjfn, 'wxShield': window[c[30532]][c[1353]] };if (window[c[30813]]) for (var ye4o0 in window[c[30813]]) {
        p3r57[ye4o0] = window[c[30813]][ye4o0];
      }window[c[30523]][c[759]][c[26708]](p3r57);if (j1E[c[26686]] && j1E[c[26686]][c[596]]) localStorage[c[1083]](c[30774] + j1E[c[26692]] + j1E[c[26691]], j1E[c[26686]][c[596]]);
    }
  } else console[c[691]](c[30946] + window[c[30568]] + c[30947] + window[c[30576]] + c[30948] + window[c[30674]] + c[30949] + window[c[30675]] + c[30950] + window[c[30676]] + c[30951] + window[c[30678]] + c[30952] + window[c[30673]] + c[30953] + window[c[30677]]);
};