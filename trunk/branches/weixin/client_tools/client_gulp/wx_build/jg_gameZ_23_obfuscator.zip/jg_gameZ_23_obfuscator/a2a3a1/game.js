var c = wx.$a;
import 'amain.js';