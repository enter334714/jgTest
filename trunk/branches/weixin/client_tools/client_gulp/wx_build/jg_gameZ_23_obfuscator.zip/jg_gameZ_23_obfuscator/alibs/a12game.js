var c = wx.$a;
console[c[691]](c[30524]), window[c[30525]], wx[c[30526]](function (tq86dk) {
  if (tq86dk) {
    if (tq86dk[c[324]]) {
      var r573p = window[c[1153]][c[30527]][c[452]](new RegExp(/\./, 'g'), '_'),
          eo_4u = tq86dk[c[324]],
          o0b$y = eo_4u[c[331]](/(a2a3a1\/a12game.js:)[0-9]{1,60}(:)/g);if (o0b$y) for (var jhzkv = 0x0; jhzkv < o0b$y[c[308]]; jhzkv++) {
        if (o0b$y[jhzkv] && o0b$y[jhzkv][c[308]] > 0x0) {
          var mcl$ba = parseInt(o0b$y[jhzkv][c[452]](c[30528], '')[c[452]](':', ''));eo_4u = eo_4u[c[452]](o0b$y[jhzkv], o0b$y[jhzkv][c[452]](':' + mcl$ba + ':', ':' + (mcl$ba - 0x2) + ':'));
        }
      }eo_4u = eo_4u[c[452]](new RegExp(c[30529], 'g'), c[30530] + r573p + c[26790]), eo_4u = eo_4u[c[452]](new RegExp(c[30531], 'g'), c[30530] + r573p + c[26790]), tq86dk[c[324]] = eo_4u;
    }var d6kvzh = { 'id': window[c[30532]][c[30533]], 'role': window[c[30532]][c[5535]], 'level': window[c[30532]][c[30534]], 'user': window[c[30532]][c[26691]], 'version': window[c[30532]][c[713]], 'cdn': window[c[30532]][c[5415]], 'pkgName': window[c[30532]][c[26692]], 'gamever': window[c[1153]][c[30527]], 'serverid': window[c[30532]][c[26686]] ? window[c[30532]][c[26686]][c[596]] : 0x0, 'systemInfo': window[c[30535]], 'error': c[30536], 'stack': tq86dk ? tq86dk[c[324]] : '' },
        tdqk8 = JSON[c[5401]](d6kvzh);console[c[485]](c[30537] + tdqk8), (!window[c[30525]] || window[c[30525]] != d6kvzh[c[485]]) && (window[c[30525]] = d6kvzh[c[485]], window[c[30538]](d6kvzh));
  }
});import 'a1md5min.js';import 'ea1zlibs.js';window[c[30539]] = require(c[30540]);import 'a1index.js';import 'a1ibsmin.js';import 'a1wxmini.js';import 'a1initmin.js';console[c[691]](c[30541]), console[c[691]](c[30542]), jM1BE({ 'title': c[30543] });var glmc$ba = { 'j6ME1B': !![] };new window[c[30544]](glmc$ba), window[c[30544]][c[759]][c[30545]]();if (window[c[30546]]) clearInterval(window[c[30546]]);window[c[30546]] = null, window[c[30547]] = function (svhnz, vzsj) {
  if (!svhnz || !vzsj) return 0x0;svhnz = svhnz[c[430]]('.'), vzsj = vzsj[c[430]]('.');const fx2sj = Math[c[477]](svhnz[c[308]], vzsj[c[308]]);while (svhnz[c[308]] < fx2sj) {
    svhnz[c[330]]('0');
  }while (vzsj[c[308]] < fx2sj) {
    vzsj[c[330]]('0');
  }for (var fw2u1 = 0x0; fw2u1 < fx2sj; fw2u1++) {
    const _4uo = parseInt(svhnz[fw2u1]),
          _u2egw = parseInt(vzsj[fw2u1]);if (_4uo > _u2egw) return 0x1;else {
      if (_4uo < _u2egw) return -0x1;
    }
  }return 0x0;
}, window[c[30548]] = wx[c[30549]]()[c[30548]], console[c[442]](c[30550] + window[c[30548]]);var gabml$ = wx[c[30551]]();gabml$[c[30552]](function (hzvns) {
  console[c[442]](c[30553] + hzvns[c[30554]]);
}), gabml$[c[30555]](function () {
  wx[c[30556]]({ 'title': c[30557], 'content': c[30558], 'showCancel': ![], 'success': function (fgxs2) {
      gabml$[c[30559]]();
    } });
}), gabml$[c[30560]](function () {
  console[c[442]](c[30561]);
}), window[c[30562]] = function () {
  console[c[442]](c[30563]);var ob40c = wx[c[30564]]({ 'name': c[30565], 'success': function (hkdv6) {
      console[c[442]](c[30566]), console[c[442]](hkdv6), hkdv6 && hkdv6[c[26885]] == c[30567] ? (window[c[30568]] = !![], window[c[30569]](), window[c[30570]]()) : setTimeout(function () {
        window[c[30562]]();
      }, 0x1f4);
    }, 'fail': function (_4y0oe) {
      console[c[442]](c[30571]), console[c[442]](_4y0oe), setTimeout(function () {
        window[c[30562]]();
      }, 0x1f4);
    } });ob40c && ob40c[c[30351]](j1s2xf => {});
}, window[c[30572]] = function () {
  console[c[442]](c[30573]);var vnhzsj = wx[c[30564]]({ 'name': c[30574], 'success': function (sjhvz) {
      console[c[442]](c[30575]), console[c[442]](sjhvz), sjhvz && sjhvz[c[26885]] == c[30567] ? (window[c[30576]] = !![], window[c[30569]](), window[c[30570]]()) : setTimeout(function () {
        window[c[30572]]();
      }, 0x1f4);
    }, 'fail': function (w_ug4e) {
      console[c[442]](c[30577]), console[c[442]](w_ug4e), setTimeout(function () {
        window[c[30572]]();
      }, 0x1f4);
    } });vnhzsj && vnhzsj[c[30351]](i5p7r => {});
}, window[c[30578]] = function () {
  window[c[30547]](window[c[30548]], c[30579]) >= 0x0 ? (console[c[442]](c[30580] + window[c[30548]] + c[30581]), window[c[30582]](), window[c[30562]](), window[c[30572]]()) : (window[c[30583]](c[30584], window[c[30548]]), wx[c[30556]]({ 'title': c[7266], 'content': c[30585] }));
}, window[c[30535]] = '', wx[c[30586]]({ 'success'(sjxnhv) {
    window[c[30535]] = c[30587] + sjxnhv[c[30588]] + c[30589] + sjxnhv[c[30590]] + c[30591] + sjxnhv[c[5606]] + c[30592] + sjxnhv[c[1074]] + c[30593] + sjxnhv[c[26656]] + c[30594] + sjxnhv[c[30548]] + c[30595] + sjxnhv[c[10238]], console[c[442]](window[c[30535]]), console[c[442]](c[30596] + sjxnhv[c[30597]] + c[30598] + sjxnhv[c[30599]] + c[30600] + sjxnhv[c[30601]] + c[30602] + sjxnhv[c[30603]] + c[30604] + sjxnhv[c[30605]] + c[30606] + sjxnhv[c[30607]] + c[30608] + (sjxnhv[c[30609]] ? sjxnhv[c[30609]][c[918]] + ',' + sjxnhv[c[30609]][c[1900]] + ',' + sjxnhv[c[30609]][c[1902]] + ',' + sjxnhv[c[30609]][c[1901]] : ''));var nfvxsj = sjxnhv[c[1074]] ? sjxnhv[c[1074]][c[357]]() : '',
        eguw1 = sjxnhv[c[30590]] ? sjxnhv[c[30590]][c[357]]()[c[452]]('\x20', '') : '';window[c[30532]][c[1688]] = nfvxsj[c[390]](c[30610]) != -0x1, window[c[30532]][c[12298]] = nfvxsj[c[390]](c[602]) != -0x1, window[c[30532]][c[30611]] = nfvxsj[c[390]](c[30610]) != -0x1 || nfvxsj[c[390]](c[602]) != -0x1, window[c[30532]][c[26387]] = nfvxsj[c[390]](c[30612]) != -0x1 || nfvxsj[c[390]](c[30613]) != -0x1, window[c[30532]][c[30614]] = sjxnhv[c[26656]] ? sjxnhv[c[26656]][c[357]]() : '', window[c[30532]][c[30615]] = ![], window[c[30532]][c[30616]] = 0x2;if (nfvxsj[c[390]](c[602]) != -0x1) {
      if (sjxnhv[c[10238]] >= 0x18) window[c[30532]][c[30616]] = 0x3;else window[c[30532]][c[30616]] = 0x2;
    } else {
      if (nfvxsj[c[390]](c[30610]) != -0x1) {
        if (sjxnhv[c[10238]] && sjxnhv[c[10238]] >= 0x14) window[c[30532]][c[30616]] = 0x3;else {
          if (eguw1[c[390]](c[30617]) != -0x1 || eguw1[c[390]](c[30618]) != -0x1 || eguw1[c[390]](c[30619]) != -0x1 || eguw1[c[390]](c[30620]) != -0x1 || eguw1[c[390]](c[30621]) != -0x1) window[c[30532]][c[30616]] = 0x2;else window[c[30532]][c[30616]] = 0x3;
        }
      } else window[c[30532]][c[30616]] = 0x2;
    }console[c[442]](c[30622] + window[c[30532]][c[30615]] + c[30623] + window[c[30532]][c[30616]]);
  } }), wx[c[30624]]({ 'success': function (i3p5r) {
    console[c[442]](c[30625] + i3p5r[c[5512]] + c[30626] + i3p5r[c[30627]]);
  } }), wx[c[12876]]({ 'success': function (cl$mby) {
    console[c[442]](c[30628] + cl$mby[c[14187]]);
  } }), wx[c[30629]]({ 'keepScreenOn': !![] }), wx[c[12878]](function (nvzj) {
  console[c[442]](c[30628] + nvzj[c[14187]] + c[30630] + nvzj[c[30631]]);
}), wx[c[11804]](function (zhvns) {
  window[c[30632]] = zhvns, window[c[30633]] && window[c[30632]] && (console[c[691]](c[30634] + window[c[30632]][c[1391]]), window[c[30633]](window[c[30632]]), window[c[30632]] = null);
}), window[c[30635]] = 0x0, window[c[30636]] = 0x0, window[c[30637]] = null, wx[c[30638]](function () {
  window[c[30636]]++;var bo0cy = Date[c[696]]();(window[c[30635]] == 0x0 || bo0cy - window[c[30635]] > 0x1d4c0) && (console[c[498]](c[30639]), wx[c[12948]]());if (window[c[30636]] >= 0x2) {
    window[c[30636]] = 0x0, console[c[485]](c[30640]), wx[c[30641]]('0', 0x1);if (window[c[30532]] && window[c[30532]][c[1688]]) window[c[30583]](c[30642], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});