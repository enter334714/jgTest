var c = wx.$a;
function gr5(f21js) {
  this['options'] = f21js || { 'locator': {} };
}function gnhvjsz(zdhv, uw21fg, szvjn) {
  function xsgf1(k86dqz) {
    var l9am$b = zdhv[k86dqz];!l9am$b && r5pt3 && (l9am$b = 0x2 == zdhv['length'] ? function (we1) {
      zdhv(k86dqz, we1);
    } : zdhv), gfux1[k86dqz] = l9am$b && function (z6dqh) {
      l9am$b('[xmldom ' + k86dqz + ']\t' + z6dqh + gktdq6(szvjn));
    } || function () {};
  }if (!zdhv) {
    if (uw21fg instanceof gd6qk8) return uw21fg;zdhv = uw21fg;
  }var gfux1 = {},
      r5pt3 = zdhv instanceof Function;return szvjn = szvjn || {}, xsgf1('warning'), xsgf1('error'), xsgf1('fatalError'), gfux1;
}function gd6qk8() {
  this['cdata'] = !0x1;
}function g_gweu2(sxvfn, ybc0o) {
  ybc0o['lineNumber'] = sxvfn['lineNumber'], ybc0o['columnNumber'] = sxvfn['columnNumber'];
}function gktdq6(q5t78r) {
  return q5t78r ? '\x0a@' + (q5t78r['systemId'] || '') + '#[line:' + q5t78r['lineNumber'] + ',col:' + q5t78r['columnNumber'] + ']' : void 0x0;
}function gxj2fs(qdtk86, p5i7r3, _4uweg) {
  return 'string' == typeof qdtk86 ? qdtk86['substr'](p5i7r3, _4uweg) : qdtk86['length'] >= p5i7r3 + _4uweg || p5i7r3 ? new java['lang']['String'](qdtk86, p5i7r3, _4uweg) + '' : qdtk86;
}function gnhkzjv(we2_gu, b$mca) {
  we2_gu['currentElement'] ? we2_gu['currentElement']['appendChild'](b$mca) : we2_gu['doc']['appendChild'](b$mca);
}gr5['prototype']['parseFromString'] = function (jzvnhk, ufx12) {
  var _egwu = this['options'],
      vhzd = new geo04(),
      $o0cb = _egwu['domBuilder'] || new gd6qk8(),
      cy$ob0 = _egwu['errorHandler'],
      b4y0oc = _egwu['locator'],
      oew4u = _egwu['xmlns'] || {},
      zjnvkh = { 'lt': '<', 'gt': '>', 'amp': '&', 'quot': '\x22', 'apos': '\x27' };return b4y0oc && $o0cb['setDocumentLocator'](b4y0oc), vhzd['errorHandler'] = gnhvjsz(cy$ob0, $o0cb, b4y0oc), vhzd['domBuilder'] = _egwu['domBuilder'] || $o0cb, /\/x?html?$/['test'](ufx12) && (zjnvkh['nbsp'] = '\u00a0', zjnvkh['copy'] = '©', oew4u[''] = 'http://www.w3.org/1999/xhtml'), oew4u['xml'] = oew4u['xml'] || 'http://www.w3.org/XML/1998/namespace', jzvnhk ? vhzd['parse'](jzvnhk, oew4u, zjnvkh) : vhzd['errorHandler']['error']('invalid doc source'), $o0cb['doc'];
}, gd6qk8['prototype'] = { 'startDocument': function () {
    this['doc'] = new ge4uw_()['createDocument'](null, null, null), this['locator'] && (this['doc']['documentURI'] = this['locator']['systemId']);
  }, 'startElement': function (c40boy, z6vn, jzvnk, jhnzv) {
    var snzjvh = this['doc'],
        _w4eou = snzjvh['createElementNS'](c40boy, jzvnk || z6vn),
        w2gf = jhnzv['length'];gnhkzjv(this, _w4eou), this['currentElement'] = _w4eou, this['locator'] && g_gweu2(this['locator'], _w4eou);for (var lby$c = 0x0; w2gf > lby$c; lby$c++) {
      var c40boy = jhnzv['getURI'](lby$c),
          e4ow0_ = jhnzv['getValue'](lby$c),
          jzvnk = jhnzv['getQName'](lby$c),
          fg2uw1 = snzjvh['createAttributeNS'](c40boy, jzvnk);this['locator'] && g_gweu2(jhnzv['getLocator'](lby$c), fg2uw1), fg2uw1['value'] = fg2uw1['nodeValue'] = e4ow0_, _w4eou['setAttributeNode'](fg2uw1);
    }
  }, 'endElement': function () {
    {
      var k6dt8q = this['currentElement'];k6dt8q['tagName'];
    }this['currentElement'] = k6dt8q['parentNode'];
  }, 'startPrefixMapping': function () {}, 'endPrefixMapping': function () {}, 'processingInstruction': function (jznhk, lcamb$) {
    var r6q8dt = this['doc']['createProcessingInstruction'](jznhk, lcamb$);this['locator'] && g_gweu2(this['locator'], r6q8dt), gnhkzjv(this, r6q8dt);
  }, 'ignorableWhitespace': function () {}, 'characters': function (dqkhz) {
    if (dqkhz = gxj2fs['apply'](this, arguments)) {
      if (this['cdata']) var c0_4yo = this['doc']['createCDATASection'](dqkhz);else var c0_4yo = this['doc']['createTextNode'](dqkhz);this['currentElement'] ? this['currentElement']['appendChild'](c0_4yo) : /^\s*$/['test'](dqkhz) && this['doc']['appendChild'](c0_4yo), this['locator'] && g_gweu2(this['locator'], c0_4yo);
    }
  }, 'skippedEntity': function () {}, 'endDocument': function () {
    this['doc']['normalize']();
  }, 'setDocumentLocator': function (pi357r) {
    (this['locator'] = pi357r) && (pi357r['lineNumber'] = 0x0);
  }, 'comment': function (yc04_) {
    yc04_ = gxj2fs['apply'](this, arguments);var kdvhz = this['doc']['createComment'](yc04_);this['locator'] && g_gweu2(this['locator'], kdvhz), gnhkzjv(this, kdvhz);
  }, 'startCDATA': function () {
    this['cdata'] = !0x0;
  }, 'endCDATA': function () {
    this['cdata'] = !0x1;
  }, 'startDTD': function (m$yb, sj1xnf, eyo04_) {
    var hnjsx = this['doc']['implementation'];if (hnjsx && hnjsx['createDocumentType']) {
      var jnxvfs = hnjsx['createDocumentType'](m$yb, sj1xnf, eyo04_);this['locator'] && g_gweu2(this['locator'], jnxvfs), gnhkzjv(this, jnxvfs);
    }
  }, 'warning': function (lycb) {
    console['warn']('[xmldom warning]\t' + lycb, gktdq6(this['locator']));
  }, 'error': function (rq86td) {
    console['error']('[xmldom error]\t' + rq86td, gktdq6(this['locator']));
  }, 'fatalError': function (lm9b$) {
    throw console['error']('[xmldom fatalError]\t' + lm9b$, gktdq6(this['locator'])), lm9b$;
  } }, 'endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl'['replace'](/\w+/g, function (acl$bm) {
  gd6qk8['prototype'][acl$bm] = function () {
    return null;
  };
});var geo04 = require('./a1sax')['XMLReader'],
    ge4uw_ = exports['DOMImplementation'] = require('./a1dom')['DOMImplementation'];exports['XMLSerializer'] = require('./a1dom')['XMLSerializer'], exports['DOMParser'] = gr5;