﻿var sdk_conf = {
  game_id: '256', //苍月之戒小程序-HC--官方-天枢服
  game_pkg: 'tjqy_cyzjxcx_HC',
  partner_id: '19',
  game_ver: '19.0.125',  //T包为19.x.x，每次上传版本修改，先设置，上传审核版本的时候保持一致
  is_auth: false,  //授权登录
  from: null, //来源
  tmpId: {1:'VnJ98WKBz-AOAoOJve7O7cVmpkfROB1E2ixAksfALx4', 2:'xruYuyn5zSQrFjDWMxCFuVvpqnCY5_qhsqMg8LfXH_4', 3:'kMHSQtyk1vR9zmyzNPwlA1pXk86dhq59wCIeAdNlM-A'},  // 订阅的类型 和 模板id
  min_app_id: '',
};

module.exports = sdk_conf;