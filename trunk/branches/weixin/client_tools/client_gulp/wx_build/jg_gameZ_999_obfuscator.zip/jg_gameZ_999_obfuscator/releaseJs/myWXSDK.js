var H = wx.$F;
var fe3lnxw = wx['$F'];import f_iak from '../libs/7cwan_sdk';var fkav5_ = fn3we(),
    f$v = { 'game_ver': H[3906] };function fn3we() {
  return { 'login': function (z18o9r, lx0w) {
      f_iak[H[117]](f$v, function (j5av_k) {
        f_iak[H[3737]](function (k3_bi, $v5jsd) {
          0x0 == k3_bi ? (k3_bi = window[H[3744]]) && k3_bi[H[3720]]({ 'openId': $v5jsd[H[3907]] }) : console[H[351]](H[3908] + $v5jsd[H[3909]]);
        });
      });
    }, 'pay': function (t4lpu0, sm5$j) {
      var aibvk = {};aibvk[H[3910]] = t4lpu0[H[3911]], aibvk[H[3912]] = t4lpu0[H[3913]], aibvk[H[3914]] = t4lpu0[H[3709]], aibvk[H[3915]] = t4lpu0[H[3711]], aibvk[H[3916]] = t4lpu0[H[3916]], aibvk[H[3917]] = t4lpu0[H[3917]], aibvk[H[3918]] = t4lpu0[H[3919]], aibvk[H[3920]] = t4lpu0[H[3921]], aibvk[H[3922]] = t4lpu0[H[1190]], aibvk[H[3923]] = t4lpu0[H[3913]], aibvk[H[3924]] = 'wx', f_iak[H[3714]](aibvk, sm5$j);
    }, 'logRoleInfo'(ix3ewn, r9p86t) {
      var bva5k = ix3ewn[H[3748]],
          u6rt = ix3ewn[H[3916]],
          mgy$d = ix3ewn[H[3917]],
          r9tp = ix3ewn[H[3919]],
          j_5ks = ix3ewn[H[3921]];ix3ewn = ix3ewn[H[1190]], 0x0 == bva5k ? (ix3ewn = 0x0, f_iak[H[3925]](u6rt, mgy$d, r9tp, j_5ks, ix3ewn)) : 0x1 == bva5k ? f_iak[H[3926]](u6rt, mgy$d, r9tp, j_5ks, ix3ewn) : 0x2 == bva5k && f_iak[H[3927]](u6rt, mgy$d, r9tp, j_5ks, ix3ewn);
    }, 'checkMsg'(lx0wu4, sd$vj5) {
      f_iak[H[3928]](lx0wu4, sd$vj5);
    } };
}function ft8r9p6(z961r8, ka5b, vds_5) {
  z961r8 in fkav5_ && fkav5_[z961r8](ka5b, vds_5);
}exports[H[3737]] = function (abik3n, p69r8) {
  ft8r9p6(H[3737], abik3n, p69r8);
}, exports[H[3749]] = function (lxn0w, i3a_kb) {
  ft8r9p6(H[3749], lxn0w, i3a_kb);
}, exports[H[3716]] = function (p0l4t, qds$j) {
  ft8r9p6(H[3716], p0l4t, qds$j);
}, exports[H[3714]] = function (xwl04u, dmq$sj) {
  ft8r9p6(H[3714], xwl04u, dmq$sj);
};