var H = wx.$F;
var fvkaj5_ = wx['$F'];require('./default.thm.min.js');