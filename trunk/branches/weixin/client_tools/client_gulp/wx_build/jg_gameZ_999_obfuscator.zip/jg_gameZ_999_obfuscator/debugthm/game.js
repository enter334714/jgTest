var H = wx.$F;
var H = wx.$F;require("./default.thm.js");