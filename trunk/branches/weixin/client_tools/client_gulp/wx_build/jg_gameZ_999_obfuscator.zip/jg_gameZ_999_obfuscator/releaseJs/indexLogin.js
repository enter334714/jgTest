var H = wx.$F;
var fwl0enx = wx['$F'];window['pf'] = parent['pf'], window['pt'] = parent['pt'], window[H[3690]] = parent[H[3690]], window[H[3692]] = parent[H[3692]], window[H[3778]] = parent[H[3778]], window[H[3679]] = parent[H[3679]], window[H[3680]] = parent[H[3680]], window[H[3684]] = parent[H[3684]], window[H[3686]] = parent[H[3686]], window[H[3693]] = parent[H[3693]];var fmd5j$ = window[H[1934]][H[3703]];if (fmd5j$ && -0x1 != fmd5j$[H[4]]('?')) {
  var fczo89 = (fmd5j$ = fmd5j$[H[138]](0x1))[H[22]]('&'),
      fyg$mdq = {};for (var fvk_5s = 0x0; fvk_5s < fczo89[H[50]]; fvk_5s++) fyg$mdq[fczo89[fvk_5s][H[22]]('=')[0x0]] = unescape(fczo89[fvk_5s][H[22]]('=')[0x1]);window[H[3704]] = fyg$mdq;
} else window[H[3704]] = null;function fdm$s5j(iew3b) {
  parent[H[1130]](iew3b);
}function fp4ut(z619r) {
  parent[H[3779]](z619r);
}function fprt64(qsjm) {
  parent[H[3757]](qsjm);
}function fp8r9(r9oz81) {
  parent[H[3780]](r9oz81);
}function fjd_5v(vbka_) {
  Main[H[117]][H[3720]](vbka_);
}function finb3a() {
  Main[H[117]][H[3738]]();
}function f_jd5v(dsj$v5, mqjsd) {
  Main[H[3743]](dsj$v5, mqjsd);
}function fnabi(vikb, m5jsd$) {
  Main[H[117]][H[3781]](vikb, m5jsd$);
}window[H[3782]] = require(H[3783]);