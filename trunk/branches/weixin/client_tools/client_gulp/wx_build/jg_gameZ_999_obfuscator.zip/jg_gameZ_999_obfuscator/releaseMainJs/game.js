var H = wx.$F;
var fpr6tu4 = wx['$F'];