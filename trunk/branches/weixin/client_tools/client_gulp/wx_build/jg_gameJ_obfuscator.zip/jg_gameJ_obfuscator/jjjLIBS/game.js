var S = wx.$J;
require(S[569088]);