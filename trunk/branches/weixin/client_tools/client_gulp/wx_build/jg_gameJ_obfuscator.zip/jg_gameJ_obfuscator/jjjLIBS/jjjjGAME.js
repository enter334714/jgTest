var S = wx.$J;
console[S[540078]](S[569512]), window[S[569513]], wx[S[569514]](function (jep53) {
  return;if (jep53) {
    if (jep53[S[544549]]) {
      var ykosg6 = window[S[540557]][S[569090]][S[544728]](new RegExp(/\./, 'g'), '_'),
          vnw35j = jep53[S[544549]],
          lbu0 = vnw35j[S[552099]](/(jjjjjjjjjj\/jjjjGAME.js:)[0-9]{1,60}(:)/g);if (lbu0) for (var x892di = 0x0; x892di < lbu0[S[540013]]; x892di++) {
        if (lbu0[x892di] && lbu0[x892di][S[540013]] > 0x0) {
          var oyclg = parseInt(lbu0[x892di][S[544728]](S[569515], '')[S[544728]](':', ''));vnw35j = vnw35j[S[544728]](lbu0[x892di], lbu0[x892di][S[544728]](':' + oyclg + ':', ':' + (oyclg - 0x2) + ':'));
        }
      }vnw35j = vnw35j[S[544728]](new RegExp(S[569516], 'g'), S[569517] + ykosg6 + S[565447]), vnw35j = vnw35j[S[544728]](new RegExp(S[569518], 'g'), S[569517] + ykosg6 + S[565447]), jep53[S[544549]] = vnw35j;
    }var ucbl4e = { 'id': window['$j9A'][S[569135]], 'role': window['$j9A'][S[544670]], 'level': window['$j9A'][S[569136]], 'user': window['$j9A'][S[565347]], 'version': window['$j9A'][S[540101]], 'cdn': window['$j9A'][S[544547]], 'pkgName': window['$j9A'][S[565348]], 'gamever': window[S[540557]][S[569090]], 'serverid': window['$j9A'][S[565342]] ? window['$j9A'][S[565342]][S[551553]] : 0x0, 'systemInfo': window[S[569137]], 'error': S[569519], 'stack': jep53 ? jep53[S[544549]] : '' },
        cs = JSON[S[544533]](ucbl4e);console[S[540125]](S[569520] + cs), (!window[S[569513]] || window[S[569513]] != ucbl4e[S[540125]]) && (window[S[569513]] = ucbl4e[S[540125]], window['$j39'](ucbl4e));
  }
});import 'jjjMDFIVEMIN.js';import 'jjjZLIBS.js';window[S[569521]] = require(S[569522]);import 'jjjLIBSMIN.js';import 'jjjWXMINI.js';import 'jjjINITMIN.js';import 'jjjINDEX.js';console[S[540078]](S[569523]), console[S[540078]](S[569524]), $j39SA({ 'title': S[569525] });var j1_d2m81 = { '$jI3A9S': !![] };new window[S[569126]](j1_d2m81), window[S[569126]][S[540148]]['$jIS9A3']();if (window['$jI39AS']) clearInterval(window['$jI39AS']);window['$jI39AS'] = null, window['$jISA39'] = function (zxh9a$, gyl0oc) {
  if (!zxh9a$ || !gyl0oc) return 0x0;zxh9a$ = zxh9a$[S[540015]]('.'), gyl0oc = gyl0oc[S[540015]]('.');const pb5nj = Math[S[540853]](zxh9a$[S[540013]], gyl0oc[S[540013]]);while (zxh9a$[S[540013]] < pb5nj) {
    zxh9a$[S[540029]]('0');
  }while (gyl0oc[S[540013]] < pb5nj) {
    gyl0oc[S[540029]]('0');
  }for (var mqfr71 = 0x0; mqfr71 < pb5nj; mqfr71++) {
    const sogy0k = parseInt(zxh9a$[mqfr71]),
          ejnbp5 = parseInt(gyl0oc[mqfr71]);if (sogy0k > ejnbp5) return 0x1;else {
      if (sogy0k < ejnbp5) return -0x1;
    }
  }return 0x0;
}, window[S[569235]] = wx[S[569526]]()[S[569235]], console[S[540482]](S[569527] + window[S[569235]]);var j1_kyog6 = wx[S[569528]]();j1_kyog6[S[569529]](function (sk6gyo) {
  console[S[540482]](S[569530] + sk6gyo[S[569531]]);
}), j1_kyog6[S[569532]](function () {
  wx[S[569118]]({ 'title': S[569533], 'content': S[569534], 'showCancel': ![], 'success': function (s7fk6r) {
      j1_kyog6[S[569535]]();
    } });
}), j1_kyog6[S[569536]](function () {
  console[S[540482]](S[569537]);
}), window['$jISA93'] = function () {
  console[S[540482]](S[569538]);var f1dq2m = wx[S[569539]]({ 'name': S[569540], 'success': function (z9x28) {
      console[S[540482]](S[569541]), console[S[540482]](z9x28), z9x28 && z9x28[S[565531]] == S[569542] ? (window['$jAS'] = !![], window['$jAS93'](), window['$jA93S']()) : setTimeout(function () {
        window['$jISA93']();
      }, 0x1f4);
    }, 'fail': function (i92x8d) {
      console[S[540482]](S[569543]), console[S[540482]](i92x8d), setTimeout(function () {
        window['$jISA93']();
      }, 0x1f4);
    } });f1dq2m && f1dq2m[S[569544]](xazh9i => {});
}, window['$jI93AS'] = function () {
  console[S[540482]](S[569545]);var ul4bec = wx[S[569539]]({ 'name': S[569546], 'success': function (xai98z) {
      console[S[540482]](S[569547]), console[S[540482]](xai98z), xai98z && xai98z[S[565531]] == S[569542] ? (window['$j9SA'] = !![], window['$jAS93'](), window['$jA93S']()) : setTimeout(function () {
        window['$jI93AS']();
      }, 0x1f4);
    }, 'fail': function (cgo0ly) {
      console[S[540482]](S[569548]), console[S[540482]](cgo0ly), setTimeout(function () {
        window['$jI93AS']();
      }, 0x1f4);
    } });ul4bec && ul4bec[S[569544]](jpn53w => {});
}, window[S[569549]] = function () {
  window['$jISA39'](window[S[569235]], S[569550]) >= 0x0 ? (console[S[540482]](S[569551] + window[S[569235]] + S[569552]), window['$j93'](), window['$jISA93'](), window['$jI93AS']()) : (window['$j9A3'](S[569553], window[S[569235]]), wx[S[569118]]({ 'title': S[546395], 'content': S[569554] }));
}, window[S[569137]] = '', wx[S[569555]]({ 'success'(yo0gs) {
    window[S[569137]] = S[569556] + yo0gs[S[569557]] + S[569558] + yo0gs[S[569559]] + S[569560] + yo0gs[S[544741]] + S[569561] + yo0gs[S[540475]] + S[569562] + yo0gs[S[565319]] + S[569563] + yo0gs[S[569235]] + S[569564] + yo0gs[S[549350]], console[S[540482]](window[S[569137]]), console[S[540482]](S[569565] + yo0gs[S[569566]] + S[569567] + yo0gs[S[569568]] + S[569569] + yo0gs[S[569570]] + S[569571] + yo0gs[S[569572]] + S[569573] + yo0gs[S[569574]] + S[569575] + yo0gs[S[569576]] + S[569577] + (yo0gs[S[569578]] ? yo0gs[S[569578]][S[540323]] + ',' + yo0gs[S[569578]][S[541216]] + ',' + yo0gs[S[569578]][S[541218]] + ',' + yo0gs[S[569578]][S[541217]] : ''));var ks0yg = yo0gs[S[540475]] ? yo0gs[S[540475]][S[552396]]() : '',
        ebupn4 = yo0gs[S[569559]] ? yo0gs[S[569559]][S[552396]]()[S[544728]]('\x20', '') : '';window['$j9A'][S[541074]] = ks0yg[S[540115]](S[569579]) != -0x1, window['$j9A'][S[551375]] = ks0yg[S[540115]](S[569067]) != -0x1, window['$j9A'][S[569307]] = ks0yg[S[540115]](S[569579]) != -0x1 || ks0yg[S[540115]](S[569067]) != -0x1, window['$j9A'][S[565055]] = ks0yg[S[540115]](S[569580]) != -0x1 || ks0yg[S[540115]](S[569097]) != -0x1, window['$j9A'][S[569144]] = yo0gs[S[565319]] ? yo0gs[S[565319]][S[552396]]() : '', window['$j9A']['$jI3SA9'] = ![], window['$j9A']['$jI39SA'] = 0x2;if (ks0yg[S[540115]](S[569067]) != -0x1) {
      if (yo0gs[S[549350]] >= 0x18) window['$j9A']['$jI39SA'] = 0x3;else window['$j9A']['$jI39SA'] = 0x2;
    } else {
      if (ks0yg[S[540115]](S[569579]) != -0x1) {
        if (yo0gs[S[549350]] && yo0gs[S[549350]] >= 0x14) window['$j9A']['$jI39SA'] = 0x3;else {
          if (ebupn4[S[540115]](S[569581]) != -0x1 || ebupn4[S[540115]](S[569582]) != -0x1 || ebupn4[S[540115]](S[569583]) != -0x1 || ebupn4[S[540115]](S[569584]) != -0x1 || ebupn4[S[540115]](S[569585]) != -0x1) window['$j9A']['$jI39SA'] = 0x2;else window['$j9A']['$jI39SA'] = 0x3;
        }
      } else window['$j9A']['$jI39SA'] = 0x2;
    }console[S[540482]](S[569586] + window['$j9A']['$jI3SA9'] + S[569587] + window['$j9A']['$jI39SA']);
  } }), wx[S[569253]]({ 'success': function (lg0u4) {
    console[S[540482]](S[569588] + lg0u4[S[544646]] + S[569589] + lg0u4[S[569255]]);
  } }), wx[S[569590]]({ 'success': function (bl4ep) {
    console[S[540482]](S[569591] + bl4ep[S[569592]]);
  } }), wx[S[569593]]({ 'keepScreenOn': !![] }), wx[S[569594]](function (e4ulcb) {
  console[S[540482]](S[569591] + e4ulcb[S[569592]] + S[569595] + e4ulcb[S[569596]]);
}), wx[S[550885]](function (w5jpn) {
  window['$jS3'] = w5jpn, window['$jA3S'] && window['$jS3'] && (console[S[540078]](S[569232] + window['$jS3'][S[540776]]), window['$jA3S'](window['$jS3']), window['$jS3'] = null);
}), window[S[569597]] = 0x0, window['$jI9SA3'] = 0x0, window[S[569598]] = null, wx[S[569599]](function () {
  window['$jI9SA3']++;var olgy0c = Date[S[540083]]();(window[S[569597]] == 0x0 || olgy0c - window[S[569597]] > 0x1d4c0) && (console[S[540096]](S[569600]), wx[S[551952]]());if (window['$jI9SA3'] >= 0x2) {
    window['$jI9SA3'] = 0x0, console[S[540125]](S[569601]), wx[S[569602]]('0', 0x1);if (window['$j9A'] && window['$j9A'][S[541074]]) window['$j9A3'](S[569603], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});