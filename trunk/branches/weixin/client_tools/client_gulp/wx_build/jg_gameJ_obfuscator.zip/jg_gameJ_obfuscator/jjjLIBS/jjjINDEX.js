var S = wx.$J;
import j1_pbe5n from '../jjjjSDK/jjjSDDK.js';window[S[569089]] = { 'wxVersion': window[S[540557]][S[569090]] }, window[S[569091]] = ![], window['$jA9'] = 0x1, window[S[569092]] = 0x1, window['$jS9A'] = !![], window[S[569093]] = !![], window['$jI3S9A'] = '', window['$j9A'] = { 'base_cdn': S[569094], 'cdn': S[569094] }, $j9A[S[569095]] = {}, $j9A[S[565053]] = '0', $j9A[S[544741]] = window[S[569089]][S[569096]], $j9A[S[569097]] = '', $j9A['os'] = '1', $j9A[S[569098]] = S[569099], $j9A[S[569100]] = S[569101], $j9A[S[569102]] = S[569103], $j9A[S[569104]] = S[569105], $j9A[S[569106]] = S[569107], $j9A[S[563753]] = '1', $j9A[S[565348]] = '', $j9A[S[565350]] = '', $j9A[S[569108]] = 0x0, $j9A[S[569109]] = {}, $j9A[S[569110]] = parseInt($j9A[S[563753]]), $j9A[S[565346]] = $j9A[S[563753]], $j9A[S[565342]] = {}, $j9A['$j39'] = S[569111], $j9A[S[569112]] = ![], $j9A[S[552297]] = S[569113], $j9A[S[565321]] = Date[S[540083]](), $j9A[S[551899]] = S[569114], $j9A[S[540714]] = '_a', $j9A[S[569115]] = 0x2, $j9A[S[540101]] = 0x7c1, $j9A[S[569096]] = window[S[569089]][S[569096]], $j9A[S[540738]] = ![], $j9A[S[541074]] = ![], $j9A[S[551375]] = ![], $j9A[S[565055]] = ![], window['$jSA9'] = 0x5, window['$jSA'] = ![], window['$jAS'] = ![], window['$j9SA'] = ![], window[S[569116]] = ![], window[S[569117]] = ![], window['$j9AS'] = ![], window['$jS9'] = ![], window['$j9S'] = ![], window['$jAS9'] = ![], window[S[544209]] = function (ysok76) {
  console[S[540482]](S[544209], ysok76), wx[S[545021]]({}), wx[S[569118]]({ 'title': S[546395], 'content': ysok76, 'success'(rmqfd1) {
      if (rmqfd1[S[569119]]) console[S[540482]](S[569120]);else rmqfd1[S[540553]] && console[S[540482]](S[569121]);
    } });
}, window['$j3S9A'] = function (m1r) {
  console[S[540482]](S[569122], m1r), $j39AS(), wx[S[569118]]({ 'title': S[546395], 'content': m1r, 'confirmText': S[569123], 'cancelText': S[558585], 'success'(e4lucb) {
      if (e4lucb[S[569119]]) window['$j93']();else e4lucb[S[540553]] && (console[S[540482]](S[569124]), wx[S[565048]]({}));
    } });
}, window[S[569125]] = function (bue4) {
  console[S[540482]](S[569125], bue4), wx[S[569118]]({ 'title': S[546395], 'content': bue4, 'confirmText': S[565478], 'showCancel': ![], 'complete'(i8x29) {
      console[S[540482]](S[569124]), wx[S[565048]]({});
    } });
}, window['$j3SA9'] = ![], window['$j39SA'] = function (blpeu) {
  window['$j3SA9'] = !![], wx[S[545020]](blpeu);
}, window['$j39AS'] = function () {
  window['$j3SA9'] && (window['$j3SA9'] = ![], wx[S[545021]]({}));
}, window['$j3AS9'] = function (fd2qm) {
  window[S[569126]][S[540148]]['$j3AS9'](fd2qm);
}, window[S[552175]] = function (e3jn, fkrm76) {
  j1_pbe5n[S[552175]](e3jn, function (l4u0) {
    l4u0 && l4u0[S[540011]] ? l4u0[S[540011]][S[544142]] == 0x1 ? fkrm76(!![]) : (fkrm76(![]), console[S[540078]](S[569127] + l4u0[S[540011]][S[569128]])) : console[S[540482]](S[552175], l4u0);
  });
}, window['$j3A9S'] = function (w3n5jp) {
  console[S[540482]](S[569129], w3n5jp);
}, window['$j39A'] = function (iq12d) {}, window['$j3A9'] = function (n5be4, cl4eb, wnv5) {}, window['$j3A'] = function (bclue) {
  console[S[540482]](S[569130], bclue), window[S[569126]][S[540148]][S[569131]](), window[S[569126]][S[540148]][S[569132]](), window[S[569126]][S[540148]][S[569133]]();
}, window['$jA3'] = function (dfmr1) {
  window['$j3S9A'](S[569134]);var go0cl = { 'id': window['$j9A'][S[569135]], 'role': window['$j9A'][S[544670]], 'level': window['$j9A'][S[569136]], 'account': window['$j9A'][S[565347]], 'version': window['$j9A'][S[540101]], 'cdn': window['$j9A'][S[544547]], 'pkgName': window['$j9A'][S[565348]], 'gamever': window[S[540557]][S[569090]], 'serverid': window['$j9A'][S[565342]] ? window['$j9A'][S[565342]][S[551553]] : 0x0, 'systemInfo': window[S[569137]], 'error': S[569138], 'stack': dfmr1 ? dfmr1 : S[569134] },
      r1qfd = JSON[S[544533]](go0cl);console[S[540125]](S[569139] + r1qfd), window['$j39'](r1qfd);
}, window['$j93A'] = function (i8a9z) {
  var bje5 = JSON[S[540527]](i8a9z);bje5[S[569140]] = window[S[540557]][S[569090]], bje5[S[569141]] = window['$j9A'][S[565342]] ? window['$j9A'][S[565342]][S[551553]] : 0x0, bje5[S[569137]] = window[S[569137]];var s0oyc = JSON[S[544533]](bje5);console[S[540125]](S[569142] + s0oyc), window['$j39'](s0oyc);
}, window['$j9A3'] = function (vjn, ha9z$) {
  var i8z2 = { 'id': window['$j9A'][S[569135]], 'role': window['$j9A'][S[544670]], 'level': window['$j9A'][S[569136]], 'account': window['$j9A'][S[565347]], 'version': window['$j9A'][S[540101]], 'cdn': window['$j9A'][S[544547]], 'pkgName': window['$j9A'][S[565348]], 'gamever': window[S[540557]][S[569090]], 'serverid': window['$j9A'][S[565342]] ? window['$j9A'][S[565342]][S[551553]] : 0x0, 'systemInfo': window[S[569137]], 'error': vjn, 'stack': ha9z$ },
      xz9i82 = JSON[S[544533]](i8z2);console[S[540096]](S[569143] + xz9i82), window['$j39'](xz9i82);
}, window['$j39'] = function (m2f1qd) {
  if (window['$j9A'][S[569144]] == S[569145]) return;var e5bnpj = $j9A['$j39'] + S[569146] + $j9A[S[565347]];wx[S[540477]]({ 'url': e5bnpj, 'method': S[569028], 'data': m2f1qd, 'header': { 'content-type': S[569147], 'cache-control': S[569148] }, 'success': function (m2f1) {
      DEBUG && console[S[540482]](S[569149], e5bnpj, m2f1qd, m2f1);
    }, 'fail': function (ax$z9h) {
      DEBUG && console[S[540482]](S[569149], e5bnpj, m2f1qd, ax$z9h);
    }, 'complete': function () {} });
}, window[S[569150]] = function () {
  function ubp4() {
    return ((0x1 + Math[S[540119]]()) * 0x10000 | 0x0)[S[540275]](0x10)[S[540500]](0x1);
  }return ubp4() + ubp4() + '-' + ubp4() + '-' + ubp4() + '-' + ubp4() + '+' + ubp4() + ubp4() + ubp4();
}, window['$j93'] = function () {
  console[S[540482]](S[569151]);var z2x98i = j1_pbe5n[S[569152]]();$j9A[S[565346]] = z2x98i[S[569153]], $j9A[S[569110]] = z2x98i[S[569153]], $j9A[S[563753]] = z2x98i[S[569153]], $j9A[S[565348]] = z2x98i[S[569154]];var b4elcu = { 'game_ver': $j9A[S[544741]] };$j9A[S[565350]] = this[S[569150]](), $j39SA({ 'title': S[569155] }), j1_pbe5n[S[540368]](b4elcu, this['$jA39'][S[540074]](this));
};var wx_develop = ![];window['$jA39'] = function (eb5jpn) {
  var mrq71 = eb5jpn[S[569156]];wx_develop = mrq71 == 0x1, console[S[540482]](S[569157] + mrq71 + S[569158] + (mrq71 == 0x1) + S[569159] + eb5jpn[S[569090]] + S[569160] + window[S[569089]][S[569096]]);if (!eb5jpn[S[569090]] || window['$jISA39'](window[S[569089]][S[569096]], eb5jpn[S[569090]]) < 0x0) console[S[540482]](S[569161]), $j9A[S[569100]] = S[569162], $j9A[S[569102]] = S[569163], $j9A[S[569104]] = S[569164], $j9A[S[544547]] = S[569165], $j9A[S[565052]] = S[569166], $j9A[S[569167]] = 'ly', $j9A[S[540738]] = ![];else window['$jISA39'](window[S[569089]][S[569096]], eb5jpn[S[569090]]) == 0x0 ? (console[S[540482]](S[569168]), $j9A[S[569100]] = S[569101], $j9A[S[569102]] = S[569103], $j9A[S[569104]] = S[569105], $j9A[S[544547]] = S[569169], $j9A[S[565052]] = S[569166], $j9A[S[569167]] = S[569170], $j9A[S[540738]] = !![]) : (console[S[540482]](S[569171]), $j9A[S[569100]] = S[569101], $j9A[S[569102]] = S[569103], $j9A[S[569104]] = S[569105], $j9A[S[544547]] = S[569169], $j9A[S[565052]] = S[569166], $j9A[S[569167]] = S[569170], $j9A[S[540738]] = ![]);$j9A[S[569108]] = config[S[568631]] ? config[S[568631]] : 0x0, this['$jS93A'](), this['$jS9A3'](), window[S[569172]] = 0x5, $j39SA({ 'title': S[569173] }), j1_pbe5n[S[569023]](this['$jA93'][S[540074]](this));
}, window[S[569172]] = 0x5, window['$jA93'] = function (v3n5jw, eplbu4) {
  if (v3n5jw == 0x0 && eplbu4 && eplbu4[S[568724]]) {
    $j9A[S[569174]] = eplbu4[S[568724]];var cgulo = this;$j39SA({ 'title': S[569175] }), sendApi($j9A[S[569100]], S[569176], { 'platform': $j9A[S[569098]], 'partner_id': $j9A[S[563753]], 'token': eplbu4[S[568724]], 'game_pkg': $j9A[S[565348]], 'deviceId': $j9A[S[565350]], 'scene': S[569177] + $j9A[S[569108]] }, this['$jS39A'][S[540074]](this), $jSA9, $jA3);
  } else eplbu4 && eplbu4[S[565531]] && window[S[569172]] > 0x0 && (eplbu4[S[565531]][S[540115]](S[569178]) != -0x1 || eplbu4[S[565531]][S[540115]](S[569179]) != -0x1 || eplbu4[S[565531]][S[540115]](S[569180]) != -0x1 || eplbu4[S[565531]][S[540115]](S[569181]) != -0x1 || eplbu4[S[565531]][S[540115]](S[569182]) != -0x1 || eplbu4[S[565531]][S[540115]](S[569183]) != -0x1) ? (window[S[569172]]--, j1_pbe5n[S[569023]](this['$jA93'][S[540074]](this))) : (window['$j9A3'](S[569184], JSON[S[544533]]({ 'status': v3n5jw, 'data': eplbu4 })), window['$j3S9A'](S[569185] + (eplbu4 && eplbu4[S[565531]] ? '，' + eplbu4[S[565531]] : '')));
}, window['$jS39A'] = function (jne5) {
  if (!jne5) {
    window['$j9A3'](S[569186], S[569187]), window['$j3S9A'](S[569188]);return;
  }if (jne5[S[544142]] != S[549963]) {
    window['$j9A3'](S[569186], JSON[S[544533]](jne5)), window['$j3S9A'](S[569189] + jne5[S[544142]]);return;
  }$j9A[S[563752]] = String(jne5[S[565347]]), $j9A[S[565347]] = String(jne5[S[565347]]), $j9A[S[565319]] = String(jne5[S[565319]]), $j9A[S[565346]] = String(jne5[S[565319]]), $j9A[S[565349]] = String(jne5[S[565349]]), $j9A[S[569190]] = String(jne5[S[551536]]), $j9A[S[569191]] = String(jne5[S[540851]]), $j9A[S[551536]] = '';var ygosk = this;$j39SA({ 'title': S[569192] }), sendApi($j9A[S[569100]], S[569193], { 'partner_id': $j9A[S[563753]], 'uid': $j9A[S[565347]], 'version': $j9A[S[544741]], 'game_pkg': $j9A[S[565348]], 'device': $j9A[S[565350]] }, ygosk['$jS3A9'][S[540074]](ygosk), $jSA9, $jA3);
}, window['$jS3A9'] = function (qfdmr) {
  if (!qfdmr) {
    window['$j3S9A'](S[569194]);return;
  }if (qfdmr[S[544142]] != S[549963]) {
    window['$j3S9A'](S[569195] + qfdmr[S[544142]]);return;
  }if (!qfdmr[S[540011]] || qfdmr[S[540011]][S[540013]] == 0x0) {
    window['$j3S9A'](S[569196]);return;
  }$j9A[S[540630]] = qfdmr[S[569197]], $j9A[S[565342]] = { 'server_id': String(qfdmr[S[540011]][0x0][S[551553]]), 'server_name': String(qfdmr[S[540011]][0x0][S[569198]]), 'entry_ip': qfdmr[S[540011]][0x0][S[565370]], 'entry_port': parseInt(qfdmr[S[540011]][0x0][S[565371]]), 'status': $j9S3(qfdmr[S[540011]][0x0]), 'start_time': qfdmr[S[540011]][0x0][S[569199]], 'cdn': $j9A[S[544547]] }, this['$jA9S3']();
}, window['$jA9S3'] = function () {
  if ($j9A[S[540630]] == 0x1) {
    var qm71r = $j9A[S[565342]][S[540106]];if (qm71r === -0x1 || qm71r === 0x0) {
      window['$j3S9A'](qm71r === -0x1 ? S[569200] : S[569201]);return;
    }$jA3S9(0x0, $j9A[S[565342]][S[551553]]), window[S[569126]][S[540148]][S[569202]]($j9A[S[540630]]);
  } else window[S[569126]][S[540148]][S[569203]](), $j39AS();window['$j9S'] = !![], window['$jAS93'](), window['$jA93S']();
}, window['$jS93A'] = function () {
  sendApi($j9A[S[569100]], S[569204], { 'game_pkg': $j9A[S[565348]], 'version_name': $j9A[S[569167]] }, this[S[569205]][S[540074]](this), $jSA9, $jA3);
}, window[S[569205]] = function (ucog0l) {
  if (!ucog0l) {
    window['$j3S9A'](S[569206]);return;
  }if (ucog0l[S[544142]] != S[549963]) {
    window['$j3S9A'](S[569207] + ucog0l[S[544142]]);return;
  }if (!ucog0l[S[540011]] || !ucog0l[S[540011]][S[544741]]) {
    window['$j3S9A'](S[569208] + (ucog0l[S[540011]] && ucog0l[S[540011]][S[544741]]));return;
  }ucog0l[S[540011]][S[569209]] && ucog0l[S[540011]][S[569209]][S[540013]] > 0xa && ($j9A[S[569210]] = ucog0l[S[540011]][S[569209]], $j9A[S[544547]] = ucog0l[S[540011]][S[569209]]), ucog0l[S[540011]][S[544741]] && ($j9A[S[540101]] = ucog0l[S[540011]][S[544741]]), console[S[540078]](S[565484] + $j9A[S[540101]] + S[569211] + $j9A[S[569167]]), window['$j9AS'] = !![], window['$jAS93'](), window['$jA93S']();
}, window[S[569212]], window['$jS9A3'] = function () {
  sendApi($j9A[S[569100]], S[569213], { 'game_pkg': $j9A[S[565348]] }, this['$jSA39'][S[540074]](this), $jSA9, $jA3);
}, window['$jSA39'] = function (ub4lce) {
  if (ub4lce[S[544142]] === S[549963] && ub4lce[S[540011]]) {
    window[S[569212]] = ub4lce[S[540011]];for (var mfrk76 in ub4lce[S[540011]]) {
      $j9A[mfrk76] = ub4lce[S[540011]][mfrk76];
    }
  } else console[S[540078]](S[569214] + ub4lce[S[544142]]);window['$jS9'] = !![], window['$jA93S']();
}, window[S[569215]] = function (k6o7s, xid, qd21m8, bnpej, df2q, olcy0, u4lpe, gco0ys, ycogs0) {
  df2q = String(df2q);var u4cg0l = u4lpe,
      bp4uel = gco0ys;$j9A[S[569095]][df2q] = { 'productid': df2q, 'productname': u4cg0l, 'productdesc': bp4uel, 'roleid': k6o7s, 'rolename': xid, 'rolelevel': qd21m8, 'price': olcy0, 'callback': ycogs0 }, sendApi($j9A[S[569104]], S[569216], { 'game_pkg': $j9A[S[565348]], 'server_id': $j9A[S[565342]][S[551553]], 'server_name': $j9A[S[565342]][S[569198]], 'level': qd21m8, 'uid': $j9A[S[565347]], 'role_id': k6o7s, 'role_name': xid, 'product_id': df2q, 'product_name': u4cg0l, 'product_desc': bp4uel, 'money': olcy0, 'partner_id': $j9A[S[563753]] }, toPayCallBack, $jSA9, $jA3);
}, window[S[569217]] = function (sk0go) {
  if (sk0go) {
    if (sk0go[S[569218]] === 0xc8 || sk0go[S[544142]] == S[549963]) {
      var qidx82 = $j9A[S[569095]][String(sk0go[S[569219]])];if (qidx82[S[540335]]) qidx82[S[540335]](sk0go[S[569219]], sk0go[S[569220]], -0x1);j1_pbe5n[S[569057]]({ 'cpbill': sk0go[S[569220]], 'productid': sk0go[S[569219]], 'productname': qidx82[S[569221]], 'productdesc': qidx82[S[569222]], 'serverid': $j9A[S[565342]][S[551553]], 'servername': $j9A[S[565342]][S[569198]], 'roleid': qidx82[S[569223]], 'rolename': qidx82[S[569224]], 'rolelevel': qidx82[S[569225]], 'price': qidx82[S[567048]], 'extension': JSON[S[544533]]({ 'cp_order_id': sk0go[S[569220]] }) }, function (ygco0l, q21mfd) {
        qidx82[S[540335]] && ygco0l == 0x0 && qidx82[S[540335]](sk0go[S[569219]], sk0go[S[569220]], ygco0l);console[S[540078]](JSON[S[544533]]({ 'type': S[569226], 'status': ygco0l, 'data': sk0go, 'role_name': qidx82[S[569224]] }));if (ygco0l === 0x0) {} else {
          if (ygco0l === 0x1) {} else {
            if (ygco0l === 0x2) {}
          }
        }
      });
    } else alert(sk0go[S[540078]]);
  }
}, window['$jSA93'] = function () {}, window['$j3SA'] = function (yc0sog, bjnp5e, mdrqf1, uel4c, okgys6) {
  j1_pbe5n[S[569082]]($j9A[S[565342]][S[551553]], $j9A[S[565342]][S[569198]] || $j9A[S[565342]][S[551553]], yc0sog, bjnp5e, mdrqf1), sendApi($j9A[S[569100]], S[569227], { 'game_pkg': $j9A[S[565348]], 'server_id': $j9A[S[565342]][S[551553]], 'role_id': yc0sog, 'uid': $j9A[S[565347]], 'role_name': bjnp5e, 'role_type': uel4c, 'level': mdrqf1 });
}, window['$j3AS'] = function (bc4, kg6yos, h9za$, rk6fs, s6yk, fm7kr, b0luc, fk7m6r, m7k, gluc4) {
  $j9A[S[569135]] = bc4, $j9A[S[544670]] = kg6yos, $j9A[S[569136]] = h9za$, j1_pbe5n[S[569083]]($j9A[S[565342]][S[551553]], $j9A[S[565342]][S[569198]] || $j9A[S[565342]][S[551553]], bc4, kg6yos, h9za$), sendApi($j9A[S[569100]], S[569228], { 'game_pkg': $j9A[S[565348]], 'server_id': $j9A[S[565342]][S[551553]], 'role_id': bc4, 'uid': $j9A[S[565347]], 'role_name': kg6yos, 'role_type': rk6fs, 'level': h9za$, 'evolution': s6yk });
}, window['$jS3A'] = function (lgcou, nw5vj3, uepl4b, o6yskg, b5e4, sy0ok, o6yksg, ulbpe, izx8a9, r76f1) {
  $j9A[S[569135]] = lgcou, $j9A[S[544670]] = nw5vj3, $j9A[S[569136]] = uepl4b, j1_pbe5n[S[569084]]($j9A[S[565342]][S[551553]], $j9A[S[565342]][S[569198]] || $j9A[S[565342]][S[551553]], lgcou, nw5vj3, uepl4b), sendApi($j9A[S[569100]], S[569228], { 'game_pkg': $j9A[S[565348]], 'server_id': $j9A[S[565342]][S[551553]], 'role_id': lgcou, 'uid': $j9A[S[565347]], 'role_name': nw5vj3, 'role_type': o6yskg, 'level': uepl4b, 'evolution': b5e4 });
}, window['$jSA3'] = function (q82ixd) {}, window['$j3S'] = function (f71mrq) {
  j1_pbe5n[S[569039]](S[569039], function (di8q1) {
    f71mrq && f71mrq(di8q1);
  });
}, window[S[565032]] = function () {
  j1_pbe5n[S[565032]]();
}, window[S[569229]] = function () {
  j1_pbe5n[S[563645]]();
}, window[S[569230]] = function (vw3nj, qmf1dr, jb5e, wjv5n, d2x9i8, ocgul0, b4une, q82di) {
  q82di = q82di || $j9A[S[565342]][S[551553]], sendApi($j9A[S[569100]], S[569231], { 'phone': vw3nj, 'role_id': qmf1dr, 'uid': $j9A[S[565347]], 'game_pkg': $j9A[S[565348]], 'partner_id': $j9A[S[563753]], 'server_id': q82di }, b4une);
}, window[S[550885]] = function (mdq281) {
  window['$jA3S'] = mdq281, window['$jA3S'] && window['$jS3'] && (console[S[540078]](S[569232] + window['$jS3'][S[540776]]), window['$jA3S'](window['$jS3']), window['$jS3'] = null);
}, window['$jAS3'] = function (gos0c, zx29i8, blue, ysk0o) {
  window[S[540022]](S[569233], { 'game_pkg': window['$j9A'][S[565348]], 'role_id': zx29i8, 'server_id': blue }, ysk0o);
}, window['$j93SA'] = function (vn5jw3, c4ue) {
  function hiza9(x82qi) {
    var q1di28 = [],
        mrq1f7 = [],
        m1dq8 = window[S[540557]][S[569234]];for (var ule4 in m1dq8) {
      var rk6mf = Number(ule4);(!vn5jw3 || !vn5jw3[S[540013]] || vn5jw3[S[540115]](rk6mf) != -0x1) && (mrq1f7[S[540029]](m1dq8[ule4]), q1di28[S[540029]]([rk6mf, 0x3]));
    }window['$jISA39'](window[S[569235]], S[569236]) >= 0x0 ? (console[S[540482]](S[569237]), j1_pbe5n[S[569079]] && j1_pbe5n[S[569079]](mrq1f7, function (lyocg) {
      console[S[540482]](S[569238]), console[S[540482]](lyocg);if (lyocg && lyocg[S[565531]] == S[569239]) for (var f67kr in m1dq8) {
        if (lyocg[m1dq8[f67kr]] == S[569240]) {
          var e4buc = Number(f67kr);for (var i2zx98 = 0x0; i2zx98 < q1di28[S[540013]]; i2zx98++) {
            if (q1di28[i2zx98][0x0] == e4buc) {
              q1di28[i2zx98][0x1] = 0x1;break;
            }
          }
        }
      }window['$jISA39'](window[S[569235]], S[569241]) >= 0x0 ? wx[S[569242]]({ 'withSubscriptions': !![], 'success': function (syocg) {
          var bpn4e = syocg[S[569243]][S[569244]];if (bpn4e) {
            console[S[540482]](S[569245]), console[S[540482]](bpn4e);for (var upeb4l in m1dq8) {
              if (bpn4e[m1dq8[upeb4l]] == S[569240]) {
                var srk67f = Number(upeb4l);for (var axz89 = 0x0; axz89 < q1di28[S[540013]]; axz89++) {
                  if (q1di28[axz89][0x0] == srk67f) {
                    q1di28[axz89][0x1] = 0x2;break;
                  }
                }
              }
            }console[S[540482]](q1di28), c4ue && c4ue(q1di28);
          } else console[S[540482]](S[569246]), console[S[540482]](syocg), console[S[540482]](q1di28), c4ue && c4ue(q1di28);
        }, 'fail': function () {
          console[S[540482]](S[569247]), console[S[540482]](q1di28), c4ue && c4ue(q1di28);
        } }) : (console[S[540482]](S[569248] + window[S[569235]]), console[S[540482]](q1di28), c4ue && c4ue(q1di28));
    })) : (console[S[540482]](S[569249] + window[S[569235]]), console[S[540482]](q1di28), c4ue && c4ue(q1di28)), wx[S[569250]](hiza9);
  }wx[S[569251]](hiza9);
}, window['$j93AS'] = { 'isSuccess': ![], 'level': S[569252], 'isCharging': ![] }, window['$j9S3A'] = function (bu04lc) {
  wx[S[569253]]({ 'success': function (fqdm12) {
      var uglc = window['$j93AS'];uglc[S[569254]] = !![], uglc[S[544646]] = Number(fqdm12[S[544646]])[S[544257]](0x0), uglc[S[569255]] = fqdm12[S[569255]], bu04lc && bu04lc(uglc[S[569254]], uglc[S[544646]], uglc[S[569255]]);
    }, 'fail': function (n5vw) {
      console[S[540482]](S[569256], n5vw[S[565531]]);var x8di2q = window['$j93AS'];bu04lc && bu04lc(x8di2q[S[569254]], x8di2q[S[544646]], x8di2q[S[569255]]);
    } });
}, window[S[540022]] = function (w35pn, kygso, k7fr6m, m7rf, ucl0g4, q2mdf1, ep5j3n, axzi9h) {
  if (m7rf == undefined) m7rf = 0x1;wx[S[540477]]({ 'url': w35pn, 'method': ep5j3n || S[565238], 'responseType': S[544454], 'data': kygso, 'header': { 'content-type': axzi9h || S[569147] }, 'success': function (cbleu) {
      DEBUG && console[S[540482]](S[569257], w35pn, info, cbleu);if (cbleu && cbleu[S[565602]] == 0xc8) {
        var ebcu4 = cbleu[S[540011]];!q2mdf1 || q2mdf1(ebcu4) ? k7fr6m && k7fr6m(ebcu4) : window[S[569258]](w35pn, kygso, k7fr6m, m7rf, ucl0g4, q2mdf1, cbleu);
      } else window[S[569258]](w35pn, kygso, k7fr6m, m7rf, ucl0g4, q2mdf1, cbleu);
    }, 'fail': function (qdx2i8) {
      DEBUG && console[S[540482]](S[569259], w35pn, info, qdx2i8), window[S[569258]](w35pn, kygso, k7fr6m, m7rf, ucl0g4, q2mdf1, qdx2i8);
    }, 'complete': function () {} });
}, window[S[569258]] = function (ixzah9, u0gol, dqr1fm, b4nep, m2q8d, krf6s7, zahx$) {
  b4nep - 0x1 > 0x0 ? setTimeout(function () {
    window[S[540022]](ixzah9, u0gol, dqr1fm, b4nep - 0x1, m2q8d, krf6s7);
  }, 0x3e8) : m2q8d && m2q8d(JSON[S[544533]]({ 'url': ixzah9, 'response': zahx$ }));
}, window[S[569260]] = function (n45ebp, le4ubp, z9h$ax, q812d, fq1md, o76sy, z8ix9) {
  !z9h$ax && (z9h$ax = {});var g4ul0 = Math[S[540118]](Date[S[540083]]() / 0x3e8);z9h$ax[S[540851]] = g4ul0, z9h$ax[S[569261]] = le4ubp;var $za9hx = Object[S[540267]](z9h$ax)[S[541078]](),
      epnub = '',
      m7rfk = '';for (var pn4b5 = 0x0; pn4b5 < $za9hx[S[540013]]; pn4b5++) {
    epnub = epnub + (pn4b5 == 0x0 ? '' : '&') + $za9hx[pn4b5] + z9h$ax[$za9hx[pn4b5]], m7rfk = m7rfk + (pn4b5 == 0x0 ? '' : '&') + $za9hx[pn4b5] + '=' + encodeURIComponent(z9h$ax[$za9hx[pn4b5]]);
  }epnub = epnub + $j9A[S[569106]];var rmfq71 = S[569262] + md5(epnub);send(n45ebp + '?' + m7rfk + (m7rfk == '' ? '' : '&') + rmfq71, null, q812d, fq1md, o76sy, z8ix9 || function (md821) {
    return md821[S[544142]] == S[549963];
  }, null, S[569029]);
}, window['$j9SA3'] = function (enp45b, fq7mr1) {
  var oyks6 = 0x0;$j9A[S[565342]] && (oyks6 = $j9A[S[565342]][S[551553]]), sendApi($j9A[S[569102]], S[569263], { 'partnerId': $j9A[S[563753]], 'gamePkg': $j9A[S[565348]], 'logTime': Math[S[540118]](Date[S[540083]]() / 0x3e8), 'platformUid': $j9A[S[565349]], 'type': enp45b, 'serverId': oyks6 }, null, 0x2, null, function () {
    return !![];
  });
}, window['$j9A3S'] = function (syo6g) {
  sendApi($j9A[S[569100]], S[569264], { 'partner_id': $j9A[S[563753]], 'uid': $j9A[S[565347]], 'version': $j9A[S[544741]], 'game_pkg': $j9A[S[565348]], 'device': $j9A[S[565350]] }, $j9AS3, $jSA9, $jA3);
}, window['$j9AS3'] = function (c0syog) {
  if (c0syog[S[544142]] === S[549963] && c0syog[S[540011]]) {
    c0syog[S[540011]][S[545624]]({ 'id': -0x2, 'name': S[569265] }), c0syog[S[540011]][S[545624]]({ 'id': -0x1, 'name': S[569266] }), $j9A[S[569267]] = c0syog[S[540011]];if (window[S[552347]]) window[S[552347]][S[569268]]();
  } else $j9A[S[569269]] = ![], window['$j3S9A'](S[569270] + c0syog[S[544142]]);
}, window['$j3S9'] = function (q21md8) {
  sendApi($j9A[S[569100]], S[569271], { 'partner_id': $j9A[S[563753]], 'uid': $j9A[S[565347]], 'version': $j9A[S[544741]], 'game_pkg': $j9A[S[565348]], 'device': $j9A[S[565350]] }, $j39S, $jSA9, $jA3);
}, window['$j39S'] = function (koy0) {
  $j9A[S[569272]] = ![];if (koy0[S[544142]] === S[549963] && koy0[S[540011]]) {
    for (var puenb4 = 0x0; puenb4 < koy0[S[540011]][S[540013]]; puenb4++) {
      koy0[S[540011]][puenb4][S[540106]] = $j9S3(koy0[S[540011]][puenb4]);
    }$j9A[S[569109]][-0x1] = window[S[569273]](koy0[S[540011]]), window[S[552347]][S[569274]](-0x1);
  } else window['$j3S9A'](S[569275] + koy0[S[544142]]);
}, window[S[569276]] = function (sf67k) {
  sendApi($j9A[S[569100]], S[569271], { 'partner_id': $j9A[S[563753]], 'uid': $j9A[S[565347]], 'version': $j9A[S[544741]], 'game_pkg': $j9A[S[565348]], 'device': $j9A[S[565350]] }, sf67k, $jSA9, $jA3);
}, window['$jS39'] = function (b4u, a9x8z) {
  sendApi($j9A[S[569100]], S[569277], { 'partner_id': $j9A[S[563753]], 'uid': $j9A[S[565347]], 'version': $j9A[S[544741]], 'game_pkg': $j9A[S[565348]], 'device': $j9A[S[565350]], 'server_group_id': a9x8z }, $jS93, $jSA9, $jA3);
}, window['$jS93'] = function (kf76sr) {
  $j9A[S[569272]] = ![];if (kf76sr[S[544142]] === S[549963] && kf76sr[S[540011]] && kf76sr[S[540011]][S[540011]]) {
    var ky0 = kf76sr[S[540011]][S[569278]],
        gcyl = [];for (var ahz$x = 0x0; ahz$x < kf76sr[S[540011]][S[540011]][S[540013]]; ahz$x++) {
      kf76sr[S[540011]][S[540011]][ahz$x][S[540106]] = $j9S3(kf76sr[S[540011]][S[540011]][ahz$x]), (gcyl[S[540013]] == 0x0 || kf76sr[S[540011]][S[540011]][ahz$x][S[540106]] != 0x0) && (gcyl[gcyl[S[540013]]] = kf76sr[S[540011]][S[540011]][ahz$x]);
    }$j9A[S[569109]][ky0] = window[S[569273]](gcyl), window[S[552347]][S[569274]](ky0);
  } else window['$j3S9A'](S[569279] + kf76sr[S[544142]]);
}, window['$jISA9'] = function (soc0gy) {
  sendApi($j9A[S[569100]], S[569280], { 'partner_id': $j9A[S[563753]], 'uid': $j9A[S[565347]], 'version': $j9A[S[544741]], 'game_pkg': $j9A[S[565348]], 'device': $j9A[S[565350]] }, reqServerRecommendCallBack, $jSA9, $jA3);
}, window[S[569281]] = function (pben45) {
  $j9A[S[569272]] = ![];if (pben45[S[544142]] === S[549963] && pben45[S[540011]]) {
    for (var m1frqd = 0x0; m1frqd < pben45[S[540011]][S[540013]]; m1frqd++) {
      pben45[S[540011]][m1frqd][S[540106]] = $j9S3(pben45[S[540011]][m1frqd]);
    }$j9A[S[569109]][-0x2] = window[S[569273]](pben45[S[540011]]), window[S[552347]][S[569274]](-0x2);
  } else alert(S[569282] + pben45[S[544142]]);
}, window[S[569273]] = function (u4blep) {
  if (!u4blep && u4blep[S[540013]] <= 0x0) return u4blep;for (let cluo0g = 0x0; cluo0g < u4blep[S[540013]]; cluo0g++) {
    u4blep[cluo0g][S[569283]] && u4blep[cluo0g][S[569283]] == 0x1 && (u4blep[cluo0g][S[569198]] += S[569284]);
  }return u4blep;
}, window['$j93S'] = function (d2mf1q, d812m) {
  d2mf1q = d2mf1q || $j9A[S[565342]][S[551553]], sendApi($j9A[S[569100]], S[569285], { 'type': '4', 'game_pkg': $j9A[S[565348]], 'server_id': d2mf1q }, d812m);
}, window[S[569286]] = function (c4ube, lceu, enub4p, b0u4l) {
  enub4p = enub4p || $j9A[S[565342]][S[551553]], sendApi($j9A[S[569100]], S[569287], { 'type': c4ube, 'game_pkg': lceu, 'server_id': enub4p }, b0u4l);
}, window['$j9S3'] = function (r7mqf) {
  if (r7mqf) {
    if (r7mqf[S[540106]] == 0x1) {
      if (r7mqf[S[569288]] == 0x1) return 0x2;else return 0x1;
    } else return r7mqf[S[540106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$jA3S9'] = function (lp4eub, rkys7) {
  $j9A[S[569289]] = { 'step': lp4eub, 'server_id': rkys7 };var wnj5 = this;$j39SA({ 'title': S[569290] }), sendApi($j9A[S[569100]], S[569291], { 'partner_id': $j9A[S[563753]], 'uid': $j9A[S[565347]], 'game_pkg': $j9A[S[565348]], 'server_id': rkys7, 'platform': $j9A[S[565319]], 'platform_uid': $j9A[S[565349]], 'check_login_time': $j9A[S[569191]], 'check_login_sign': $j9A[S[569190]], 'version_name': $j9A[S[569167]] }, $jA39S, $jSA9, $jA3, function (fmkr76) {
    return fmkr76[S[544142]] == S[549963] || fmkr76[S[540078]] == S[569292] || fmkr76[S[540078]] == S[569293];
  });
}, window['$jA39S'] = function (lc4bue) {
  var guc = this;if (lc4bue[S[544142]] === S[549963] && lc4bue[S[540011]]) {
    var n4upe = $j9A[S[565342]];n4upe[S[569294]] = $j9A[S[569110]], n4upe[S[551536]] = String(lc4bue[S[540011]][S[569295]]), n4upe[S[565321]] = parseInt(lc4bue[S[540011]][S[540851]]);if (lc4bue[S[540011]][S[565320]]) n4upe[S[565320]] = parseInt(lc4bue[S[540011]][S[565320]]);else n4upe[S[565320]] = parseInt(lc4bue[S[540011]][S[551553]]);n4upe[S[569296]] = 0x0, n4upe[S[544547]] = $j9A[S[569210]], n4upe[S[569297]] = lc4bue[S[540011]][S[569298]], n4upe[S[569299]] = lc4bue[S[540011]][S[569299]], console[S[540482]](S[569300] + JSON[S[544533]](n4upe[S[569299]])), $j9A[S[540630]] == 0x1 && n4upe[S[569299]] && n4upe[S[569299]][S[569301]] == 0x1 && ($j9A[S[569302]] = 0x1, window[S[569126]][S[540148]]['$jIA9']()), $jAS39();
  } else sendApi($j9A[S[569100]], S[569176], { 'platform': $j9A[S[569098]], 'partner_id': $j9A[S[563753]], 'token': $j9A[S[569174]], 'game_pkg': $j9A[S[565348]], 'deviceId': $j9A[S[565350]], 'scene': S[569177] + $j9A[S[569108]] }, function (cl4) {
    if (cl4[S[544142]] == S[565681]) {
      window['$j3S9A'](S[569189] + cl4[S[544142]]);return;
    }$j9A[S[569190]] = String(cl4[S[551536]]), $j9A[S[569191]] = String(cl4[S[540851]]), setTimeout(function () {
      $jA3S9($j9A[S[569289]][S[547165]], $j9A[S[569289]][S[551553]]);
    }, 0x5dc);
  }, $jSA9, $jA3, function (dqm18) {
    return dqm18[S[544142]] == S[549963] || dqm18[S[544142]] == S[565681];
  });
}, window['$jAS39'] = function () {
  ServerLoading[S[540148]][S[569202]]($j9A[S[540630]]), window['$jSA'] = !![], window['$jA93S']();
}, window['$jAS93'] = function () {
  if (window['$jAS'] && window['$j9SA'] && window[S[569116]] && window[S[569117]] && window['$j9AS'] && window['$j9S']) {
    if (!window[S[568612]][S[540148]]) {
      console[S[540482]](S[569303] + window[S[568612]][S[540148]]);var s0ogky = wx[S[569304]](),
          x89iz = s0ogky[S[540776]] ? s0ogky[S[540776]] : 0x0,
          w53jn = { 'cdn': window['$j9A'][S[544547]], 'spareCdn': window['$j9A'][S[565052]], 'newRegister': window['$j9A'][S[540630]], 'wxPC': window['$j9A'][S[565055]], 'wxIOS': window['$j9A'][S[541074]], 'wxAndroid': window['$j9A'][S[551375]], 'wxParam': { 'limitLoad': window['$j9A']['$jI3SA9'], 'benchmarkLevel': window['$j9A']['$jI39SA'], 'wxFrom': window[S[540557]][S[568631]] == S[569305] ? 0x1 : 0x0, 'wxSDKVersion': window[S[569235]] }, 'configType': window['$j9A'][S[551899]], 'exposeType': window['$j9A'][S[540714]], 'scene': x89iz };new window[S[568612]](w53jn, window['$j9A'][S[540101]], window['$jI3S9A']);
    }
  }
}, window['$jA93S'] = function () {
  if (window['$jAS'] && window['$j9SA'] && window[S[569116]] && window[S[569117]] && window['$j9AS'] && window['$j9S'] && window['$jSA'] && window['$jS9']) {
    $j39AS();if (!$jAS9) {
      $jAS9 = !![];if (!window[S[568612]][S[540148]]) window['$jAS93']();var skyr = 0x0,
          ug4c = wx[S[569306]]();ug4c && (window['$j9A'][S[569307]] && (skyr = ug4c[S[540323]]), console[S[540078]](S[569308] + ug4c[S[540323]] + S[569309] + ug4c[S[541216]] + S[569310] + ug4c[S[541218]] + S[569311] + ug4c[S[541217]] + S[569312] + ug4c[S[540176]] + S[569313] + ug4c[S[540177]]));var lcug04 = {};for (const enp5bj in $j9A[S[565342]]) {
        lcug04[enp5bj] = $j9A[S[565342]][enp5bj];
      }var pjw5 = { 'channel': window['$j9A'][S[565346]], 'account': window['$j9A'][S[565347]], 'userId': window['$j9A'][S[563752]], 'cdn': window['$j9A'][S[544547]], 'data': window['$j9A'][S[540011]], 'package': window['$j9A'][S[565053]], 'newRegister': window['$j9A'][S[540630]], 'pkgName': window['$j9A'][S[565348]], 'partnerId': window['$j9A'][S[563753]], 'platform_uid': window['$j9A'][S[565349]], 'deviceId': window['$j9A'][S[565350]], 'selectedServer': lcug04, 'configType': window['$j9A'][S[551899]], 'exposeType': window['$j9A'][S[540714]], 'debugUsers': window['$j9A'][S[552297]], 'wxMenuTop': skyr, 'wxShield': window['$j9A'][S[540738]] };if (window[S[569212]]) for (var go0syc in window[S[569212]]) {
        pjw5[go0syc] = window[S[569212]][go0syc];
      }window[S[568612]][S[540148]]['$jA9I'](pjw5);
    }
  } else console[S[540078]](S[569314] + window['$jAS'] + S[569315] + window['$j9SA'] + S[569316] + window[S[569116]] + S[569317] + window[S[569117]] + S[569318] + window['$j9AS'] + S[569319] + window['$j9S'] + S[569320] + window['$jSA'] + S[569321] + window['$jS9']);
};