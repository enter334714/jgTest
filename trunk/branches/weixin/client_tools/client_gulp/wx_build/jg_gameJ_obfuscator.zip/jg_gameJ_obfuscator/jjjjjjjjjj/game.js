var S = wx.$J;
import 'jjjMAIN.js';