//游戏标识(appid)
window.DDSDK_APPKEY = "wx2c0da88537dd7191";
//游戏名(gname)
window.DDSDK_GNAME = "tjqy";
//md5key由零境对接人员提供。
window.DDSDK_MD5KEY = "10a7cdd970fe135cf4f7bb55c0e3b59f";