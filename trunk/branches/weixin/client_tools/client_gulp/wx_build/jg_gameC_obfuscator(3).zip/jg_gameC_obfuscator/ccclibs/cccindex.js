var p = wx.$h;
import a_ie8$k from '../cccck/cccsdk.js';window[p[49093]] = { 'wxVersion': window[p[20555]][p[48992]] }, window[p[49094]] = ![], window['$aVQ'] = 0x1, window[p[49095]] = 0x1, window['$a3QV'] = !![], window[p[49096]] = !![], window['$aH53QV'] = '', window['$aQV'] = { 'base_cdn': p[49097], 'cdn': p[49097] }, $aQV[p[49098]] = {}, $aQV[p[44906]] = '0', $aQV[p[24716]] = window[p[49093]][p[49099]], $aQV[p[49065]] = '', $aQV['os'] = '1', $aQV[p[49100]] = p[49101], $aQV[p[49102]] = p[49103], $aQV[p[49104]] = p[49105], $aQV[p[49106]] = p[49107], $aQV[p[49108]] = p[49109], $aQV[p[43641]] = '1', $aQV[p[45220]] = '', $aQV[p[45222]] = '', $aQV[p[49110]] = 0x0, $aQV[p[49111]] = {}, $aQV[p[49112]] = parseInt($aQV[p[43641]]), $aQV[p[45218]] = $aQV[p[43641]], $aQV[p[45214]] = {}, $aQV['$a5Q'] = p[49113], $aQV[p[49114]] = ![], $aQV[p[32244]] = p[49115], $aQV[p[45191]] = Date[p[20083]](), $aQV[p[31851]] = p[49116], $aQV[p[20712]] = '_a', $aQV[p[49117]] = 0x2, $aQV[p[20101]] = 0x7c1, $aQV[p[49099]] = window[p[49093]][p[49099]], $aQV[p[20736]] = ![], $aQV[p[21072]] = ![], $aQV[p[31332]] = ![], $aQV[p[44908]] = ![], window['$a3VQ'] = 0x5, window['$a3V'] = ![], window['$aV3'] = ![], window['$aQ3V'] = ![], window[p[49118]] = ![], window[p[49119]] = ![], window['$aQV3'] = ![], window['$a3Q'] = ![], window['$aQ3'] = ![], window['$aV3Q'] = ![], window[p[24185]] = function (mcsdl) {
  console[p[20480]](p[24185], mcsdl), wx[p[24995]]({}), wx[p[49016]]({ 'title': p[26361], 'content': mcsdl, 'success'(bo9iz) {
      if (bo9iz[p[49120]]) console[p[20480]](p[49121]);else bo9iz[p[20551]] && console[p[20480]](p[49122]);
    } });
}, window['$a53QV'] = function (csf1tj) {
  console[p[20480]](p[49123], csf1tj), $a5QV3(), wx[p[49016]]({ 'title': p[26361], 'content': csf1tj, 'confirmText': p[49124], 'cancelText': p[38499], 'success'(nwa2p) {
      if (nwa2p[p[49120]]) window['$aQ5']();else nwa2p[p[20551]] && (console[p[20480]](p[49125]), wx[p[45378]]({}));
    } });
}, window['$aQH'] = function (t4j37f) {
  console[p[20480]](p[49126], t4j37f), wx[p[49016]]({ 'title': p[26361], 'content': t4j37f, 'confirmText': p[45350], 'showCancel': ![], 'complete'(eib6y$) {
      console[p[20480]](p[49125]), wx[p[45378]]({});
    } });
}, window['$a53VQ'] = ![], window['$a5Q3V'] = function (a7p34w) {
  window['$a53VQ'] = !![], wx[p[24994]](a7p34w);
}, window['$a5QV3'] = function () {
  window['$a53VQ'] && (window['$a53VQ'] = ![], wx[p[24995]]({}));
}, window['$a5V3Q'] = function (ykei6$) {
  window[p[49007]][p[20148]]['$a5V3Q'](ykei6$);
}, window[p[32125]] = function (c5lds, x0g_2) {
  a_ie8$k[p[32125]](c5lds, function (ib$eoy) {
    ib$eoy && ib$eoy[p[20011]] ? ib$eoy[p[20011]][p[24118]] == 0x1 ? x0g_2(!![]) : (x0g_2(![]), console[p[20078]](p[49127] + ib$eoy[p[20011]][p[49128]])) : console[p[20480]](p[32125], ib$eoy);
  });
}, window['$a5VQ3'] = function (nrpa4) {
  console[p[20480]](p[49129], nrpa4);
}, window['$a5QV'] = function (j3ts1f) {}, window['$a5VQ'] = function (j1tscf, kg_h8, ds1c5m) {}, window['$a5V'] = function (vnr2) {
  console[p[20480]](p[49130], vnr2), window[p[49007]][p[20148]][p[49131]](), window[p[49007]][p[20148]][p[49132]](), window[p[49007]][p[20148]][p[49133]]();
}, window['$aV5'] = function (i9ybz) {
  window['$a53QV'](p[49134]);var p47a3w = { 'id': window['$aQV'][p[48997]], 'role': window['$aQV'][p[24645]], 'level': window['$aQV'][p[48998]], 'account': window['$aQV'][p[45219]], 'version': window['$aQV'][p[20101]], 'cdn': window['$aQV'][p[24524]], 'pkgName': window['$aQV'][p[45220]], 'gamever': window[p[20555]][p[48992]], 'serverid': window['$aQV'][p[45214]] ? window['$aQV'][p[45214]][p[31510]] : 0x0, 'systemInfo': window[p[48999]], 'error': p[49135], 'stack': i9ybz ? i9ybz : p[49134] },
      izy = JSON[p[24510]](p47a3w);console[p[20125]](p[49136] + izy), window['$a5Q'](izy);
}, window['$aQ5V'] = function (byoe$) {
  var sd1m5 = JSON[p[20525]](byoe$);sd1m5[p[49137]] = window[p[20555]][p[48992]], sd1m5[p[49138]] = window['$aQV'][p[45214]] ? window['$aQV'][p[45214]][p[31510]] : 0x0, sd1m5[p[48999]] = window[p[48999]];var vwnxr = JSON[p[24510]](sd1m5);console[p[20125]](p[49139] + vwnxr), window['$a5Q'](vwnxr);
}, window['$aQV5'] = function (jf34, rxnwv2) {
  var x_2gv0 = { 'id': window['$aQV'][p[48997]], 'role': window['$aQV'][p[24645]], 'level': window['$aQV'][p[48998]], 'account': window['$aQV'][p[45219]], 'version': window['$aQV'][p[20101]], 'cdn': window['$aQV'][p[24524]], 'pkgName': window['$aQV'][p[45220]], 'gamever': window[p[20555]][p[48992]], 'serverid': window['$aQV'][p[45214]] ? window['$aQV'][p[45214]][p[31510]] : 0x0, 'systemInfo': window[p[48999]], 'error': jf34, 'stack': rxnwv2 },
      v2xn = JSON[p[24510]](x_2gv0);console[p[20096]](p[49140] + v2xn), window['$a5Q'](v2xn);
}, window['$a5Q'] = function (qybzo) {
  if (window['$aQV'][p[49066]] == p[48498]) return;var pf7a43 = $aQV['$a5Q'] + p[49141] + $aQV[p[45219]];wx[p[20475]]({ 'url': pf7a43, 'method': p[48472], 'data': qybzo, 'header': { 'content-type': p[49142], 'cache-control': p[49143] }, 'success': function (n_g2) {
      DEBUG && console[p[20480]](p[49144], pf7a43, qybzo, n_g2);
    }, 'fail': function ($h08) {
      DEBUG && console[p[20480]](p[49144], pf7a43, qybzo, $h08);
    }, 'complete': function () {} });
}, window[p[49145]] = function () {
  function lsd5mc() {
    return ((0x1 + Math[p[20119]]()) * 0x10000 | 0x0)[p[20272]](0x10)[p[20498]](0x1);
  }return lsd5mc() + lsd5mc() + '-' + lsd5mc() + '-' + lsd5mc() + '-' + lsd5mc() + '+' + lsd5mc() + lsd5mc() + lsd5mc();
}, window['$aQ5'] = function () {
  console[p[20480]](p[49146]);var fjs31t = a_ie8$k[p[49147]]();$aQV[p[45218]] = fjs31t[p[49148]], $aQV[p[49112]] = fjs31t[p[49148]], $aQV[p[43641]] = fjs31t[p[49148]], $aQV[p[45220]] = fjs31t[p[49149]];var iye6k = { 'game_ver': $aQV[p[24716]] };$aQV[p[45222]] = this[p[49145]](), $a5Q3V({ 'title': p[49150] }), a_ie8$k[p[20366]](iye6k, this['$aV5Q'][p[20074]](this));
}, window['$aV5Q'] = function (s15m) {
  var wr47pa = s15m[p[49151]];console[p[20480]](p[49152] + wr47pa + p[49153] + (wr47pa == 0x1) + p[49154] + s15m[p[48992]] + p[49155] + window[p[49093]][p[49099]]);if (!s15m[p[48992]] || window['$aH3V5Q'](window[p[49093]][p[49099]], s15m[p[48992]]) < 0x0) console[p[20480]](p[49156]), $aQV[p[49102]] = p[49157], $aQV[p[49104]] = p[49158], $aQV[p[49106]] = p[49159], $aQV[p[24524]] = p[49160], $aQV[p[44905]] = p[49161], $aQV[p[49162]] = 'ts', $aQV[p[20736]] = ![];else window['$aH3V5Q'](window[p[49093]][p[49099]], s15m[p[48992]]) == 0x0 ? (console[p[20480]](p[49163]), $aQV[p[49102]] = p[49103], $aQV[p[49104]] = p[49105], $aQV[p[49106]] = p[49107], $aQV[p[24524]] = p[49164], $aQV[p[44905]] = p[49161], $aQV[p[49162]] = p[49165], $aQV[p[20736]] = !![]) : (console[p[20480]](p[49166]), $aQV[p[49102]] = p[49103], $aQV[p[49104]] = p[49105], $aQV[p[49106]] = p[49107], $aQV[p[24524]] = p[49164], $aQV[p[44905]] = p[49161], $aQV[p[49162]] = p[49165], $aQV[p[20736]] = ![]);$aQV[p[49110]] = config[p[48612]] ? config[p[48612]] : 0x0, this['$a3Q5V'](), this['$a3QV5'](), window[p[49167]] = 0x5, $a5Q3V({ 'title': p[49168] }), a_ie8$k[p[48455]](this['$aVQ5'][p[20074]](this));
}, window[p[49167]] = 0x5, window['$aVQ5'] = function (gh_v08, kg80) {
  if (gh_v08 == 0x0 && kg80 && kg80[p[48702]]) {
    $aQV[p[49169]] = kg80[p[48702]];var k6yie$ = this;$a5Q3V({ 'title': p[49170] }), sendApi($aQV[p[49102]], p[49171], { 'platform': $aQV[p[49100]], 'partner_id': $aQV[p[43641]], 'token': kg80[p[48702]], 'game_pkg': $aQV[p[45220]], 'deviceId': $aQV[p[45222]], 'scene': p[49172] + $aQV[p[49110]] }, this['$a35QV'][p[20074]](this), $a3VQ, $aV5);
  } else kg80 && kg80[p[45405]] && window[p[49167]] > 0x0 && (kg80[p[45405]][p[20115]](p[49173]) != -0x1 || kg80[p[45405]][p[20115]](p[49174]) != -0x1 || kg80[p[45405]][p[20115]](p[49175]) != -0x1 || kg80[p[45405]][p[20115]](p[49176]) != -0x1 || kg80[p[45405]][p[20115]](p[49177]) != -0x1 || kg80[p[45405]][p[20115]](p[49178]) != -0x1) ? (window[p[49167]]--, a_ie8$k[p[48455]](this['$aVQ5'][p[20074]](this))) : (window['$aQV5'](p[49179], JSON[p[24510]]({ 'status': gh_v08, 'data': kg80 })), window['$a53QV'](p[49180] + (kg80 && kg80[p[45405]] ? '，' + kg80[p[45405]] : '')));
}, window['$a35QV'] = function (bo9yqz) {
  if (!bo9yqz) {
    window['$aQV5'](p[49181], p[49182]), window['$a53QV'](p[49183]);return;
  }if (bo9yqz[p[24118]] != p[29922]) {
    window['$aQV5'](p[49181], JSON[p[24510]](bo9yqz)), window['$a53QV'](p[49184] + bo9yqz[p[24118]]);return;
  }$aQV[p[43640]] = String(bo9yqz[p[45219]]), $aQV[p[45219]] = String(bo9yqz[p[45219]]), $aQV[p[45189]] = String(bo9yqz[p[45189]]), $aQV[p[45218]] = String(bo9yqz[p[45189]]), $aQV[p[45221]] = String(bo9yqz[p[45221]]), $aQV[p[49185]] = String(bo9yqz[p[31493]]), $aQV[p[49186]] = String(bo9yqz[p[20849]]), $aQV[p[31493]] = '';var h08kg6 = this;$a5Q3V({ 'title': p[49187] }), sendApi($aQV[p[49102]], p[49188], { 'partner_id': $aQV[p[43641]], 'uid': $aQV[p[45219]], 'version': $aQV[p[24716]], 'game_pkg': $aQV[p[45220]], 'device': $aQV[p[45222]] }, h08kg6['$a35VQ'][p[20074]](h08kg6), $a3VQ, $aV5);
}, window['$a35VQ'] = function (yek6$) {
  if (!yek6$) {
    window['$a53QV'](p[49189]);return;
  }if (yek6$[p[24118]] != p[29922]) {
    window['$a53QV'](p[49190] + yek6$[p[24118]]);return;
  }if (!yek6$[p[20011]] || yek6$[p[20011]][p[20013]] == 0x0) {
    window['$a53QV'](p[49191]);return;
  }$aQV[p[20628]] = yek6$[p[49192]], $aQV[p[45214]] = { 'server_id': String(yek6$[p[20011]][0x0][p[31510]]), 'server_name': String(yek6$[p[20011]][0x0][p[49193]]), 'entry_ip': yek6$[p[20011]][0x0][p[45242]], 'entry_port': parseInt(yek6$[p[20011]][0x0][p[45243]]), 'status': $aQ35(yek6$[p[20011]][0x0]), 'start_time': yek6$[p[20011]][0x0][p[49194]], 'cdn': $aQV[p[24524]] }, this['$aVQ35']();
}, window['$aVQ35'] = function () {
  if ($aQV[p[20628]] == 0x1) {
    var _vnxr = $aQV[p[45214]][p[20106]];if (_vnxr === -0x1 || _vnxr === 0x0) {
      window['$a53QV'](_vnxr === -0x1 ? p[49195] : p[49196]);return;
    }$aV53Q(0x0, $aQV[p[45214]][p[31510]]), window[p[49007]][p[20148]][p[49197]]($aQV[p[20628]]);
  } else window[p[49007]][p[20148]][p[49198]](), $a5QV3();window['$aQ3'] = !![], window['$aV3Q5'](), window['$aVQ53']();
}, window['$a3Q5V'] = function () {
  sendApi($aQV[p[49102]], p[49199], { 'game_pkg': $aQV[p[45220]], 'version_name': $aQV[p[49162]] }, this[p[49200]][p[20074]](this), $a3VQ, $aV5);
}, window[p[49200]] = function (e6yik) {
  if (!e6yik) {
    window['$a53QV'](p[49201]);return;
  }if (e6yik[p[24118]] != p[29922]) {
    window['$a53QV'](p[49202] + e6yik[p[24118]]);return;
  }if (!e6yik[p[20011]] || !e6yik[p[20011]][p[24716]]) {
    window['$a53QV'](p[49203] + (e6yik[p[20011]] && e6yik[p[20011]][p[24716]]));return;
  }e6yik[p[20011]][p[49204]] && e6yik[p[20011]][p[49204]][p[20013]] > 0xa && ($aQV[p[49205]] = e6yik[p[20011]][p[49204]], $aQV[p[24524]] = e6yik[p[20011]][p[49204]]), e6yik[p[20011]][p[24716]] && ($aQV[p[20101]] = e6yik[p[20011]][p[24716]]), console[p[20078]](p[45356] + $aQV[p[20101]] + p[49206] + $aQV[p[49162]]), window['$aQV3'] = !![], window['$aV3Q5'](), window['$aVQ53']();
}, window[p[49207]], window['$a3QV5'] = function () {
  sendApi($aQV[p[49102]], p[49208], { 'game_pkg': $aQV[p[45220]] }, this['$a3V5Q'][p[20074]](this), $a3VQ, $aV5);
}, window['$a3V5Q'] = function (sctf1) {
  if (sctf1[p[24118]] === p[29922] && sctf1[p[20011]]) {
    window[p[49207]] = sctf1[p[20011]];for (var $yeoib in sctf1[p[20011]]) {
      $aQV[$yeoib] = sctf1[p[20011]][$yeoib];
    }
  } else console[p[20078]](p[49209] + sctf1[p[24118]]);window['$a3Q'] = !![], window['$aVQ53']();
}, window[p[49210]] = function (f73j1, pr47aw, k6ey, _2gxvn, e$yi6k, j3ft, x2gv_, g_08v, dc5sl) {
  e$yi6k = String(e$yi6k);var h6$0 = x2gv_,
      oyi$b = g_08v;$aQV[p[49098]][e$yi6k] = { 'productid': e$yi6k, 'productname': h6$0, 'productdesc': oyi$b, 'roleid': f73j1, 'rolename': pr47aw, 'rolelevel': k6ey, 'price': j3ft, 'callback': dc5sl }, sendApi($aQV[p[49106]], p[49211], { 'game_pkg': $aQV[p[45220]], 'server_id': $aQV[p[45214]][p[31510]], 'server_name': $aQV[p[45214]][p[49193]], 'level': k6ey, 'uid': $aQV[p[45219]], 'role_id': f73j1, 'role_name': pr47aw, 'product_id': e$yi6k, 'product_name': h6$0, 'product_desc': oyi$b, 'money': j3ft, 'partner_id': $aQV[p[43641]] }, toPayCallBack, $a3VQ, $aV5);
}, window[p[49212]] = function (kyi6$) {
  if (kyi6$) {
    if (kyi6$[p[49213]] === 0xc8 || kyi6$[p[24118]] == p[29922]) {
      var zoqyb9 = $aQV[p[49098]][String(kyi6$[p[49214]])];if (zoqyb9[p[20332]]) zoqyb9[p[20332]](kyi6$[p[49214]], kyi6$[p[49215]], -0x1);a_ie8$k[p[48490]]({ 'cpbill': kyi6$[p[49215]], 'productid': kyi6$[p[49214]], 'productname': zoqyb9[p[49216]], 'productdesc': zoqyb9[p[49217]], 'serverid': $aQV[p[45214]][p[31510]], 'servername': $aQV[p[45214]][p[49193]], 'roleid': zoqyb9[p[49218]], 'rolename': zoqyb9[p[49219]], 'rolelevel': zoqyb9[p[49220]], 'price': zoqyb9[p[46913]], 'extension': JSON[p[24510]]({ 'cp_order_id': kyi6$[p[49215]] }) }, function (i$ey6, bzoq) {
        zoqyb9[p[20332]] && i$ey6 == 0x0 && zoqyb9[p[20332]](kyi6$[p[49214]], kyi6$[p[49215]], i$ey6);console[p[20078]](JSON[p[24510]]({ 'type': p[49221], 'status': i$ey6, 'data': kyi6$, 'role_name': zoqyb9[p[49219]] }));if (i$ey6 === 0x0) {} else {
          if (i$ey6 === 0x1) {} else {
            if (i$ey6 === 0x2) {}
          }
        }
      });
    } else alert(kyi6$[p[20078]]);
  }
}, window['$a3VQ5'] = function () {}, window['$a53V'] = function (np4wr, pa4f37, js3ft1, a4f7, rwa2) {
  a_ie8$k[p[48542]]($aQV[p[45214]][p[31510]], $aQV[p[45214]][p[49193]] || $aQV[p[45214]][p[31510]], np4wr, pa4f37, js3ft1), sendApi($aQV[p[49102]], p[49222], { 'game_pkg': $aQV[p[45220]], 'server_id': $aQV[p[45214]][p[31510]], 'role_id': np4wr, 'uid': $aQV[p[45219]], 'role_name': pa4f37, 'role_type': a4f7, 'level': js3ft1 });
}, window['$a5V3'] = function (ieby$6, rwv2xn, eoyi9b, sc5lmd, rnw4pa, eio9, p7awr, n2xrpw, a74pw3, g_0k) {
  $aQV[p[48997]] = ieby$6, $aQV[p[24645]] = rwv2xn, $aQV[p[48998]] = eoyi9b, a_ie8$k[p[48543]]($aQV[p[45214]][p[31510]], $aQV[p[45214]][p[49193]] || $aQV[p[45214]][p[31510]], ieby$6, rwv2xn, eoyi9b), sendApi($aQV[p[49102]], p[49223], { 'game_pkg': $aQV[p[45220]], 'server_id': $aQV[p[45214]][p[31510]], 'role_id': ieby$6, 'uid': $aQV[p[45219]], 'role_name': rwv2xn, 'role_type': sc5lmd, 'level': eoyi9b, 'evolution': rnw4pa });
}, window['$a35V'] = function (k8e6$i, s1jf3, csd5m, _0ghk8, nraw4p, gxh0v, p74wa, arw4n, obye, e9yiob) {
  $aQV[p[48997]] = k8e6$i, $aQV[p[24645]] = s1jf3, $aQV[p[48998]] = csd5m, a_ie8$k[p[48544]]($aQV[p[45214]][p[31510]], $aQV[p[45214]][p[49193]] || $aQV[p[45214]][p[31510]], k8e6$i, s1jf3, csd5m), sendApi($aQV[p[49102]], p[49223], { 'game_pkg': $aQV[p[45220]], 'server_id': $aQV[p[45214]][p[31510]], 'role_id': k8e6$i, 'uid': $aQV[p[45219]], 'role_name': s1jf3, 'role_type': _0ghk8, 'level': csd5m, 'evolution': nraw4p });
}, window['$a3V5'] = function (_g02) {}, window['$a53'] = function (i68ek) {
  a_ie8$k[p[48576]](p[48576], function (x20v_) {
    i68ek && i68ek(x20v_);
  });
}, window[p[44889]] = function () {
  a_ie8$k[p[44889]]();
}, window[p[49224]] = function () {
  a_ie8$k[p[43534]]();
}, window[p[30843]] = function (qbzy9o) {
  window['$aV53'] = qbzy9o, window['$aV53'] && window['$a35'] && (console[p[20078]](p[49085] + window['$a35'][p[20774]]), window['$aV53'](window['$a35']), window['$a35'] = null);
}, window['$aV35'] = function (arpwn4, ts, s3j1, ja) {
  window[p[20022]](p[49225], { 'game_pkg': window['$aQV'][p[45220]], 'role_id': ts, 'server_id': s3j1 }, ja);
}, window['$aQ53V'] = function (rnw4a, $yeik) {
  function d5mc1s(xwrnv) {
    var pxr2n = [],
        hk86g = [],
        jc51t = window[p[20555]][p[49226]];for (var ieoyb9 in jc51t) {
      var prna2 = Number(ieoyb9);(!rnw4a || !rnw4a[p[20013]] || rnw4a[p[20115]](prna2) != -0x1) && (hk86g[p[20029]](jc51t[ieoyb9]), pxr2n[p[20029]]([prna2, 0x3]));
    }window['$aH3V5Q'](window[p[49008]], p[49227]) >= 0x0 ? (console[p[20480]](p[49228]), a_ie8$k[p[48594]] && a_ie8$k[p[48594]](hk86g, function (vwn2rx) {
      console[p[20480]](p[49229]), console[p[20480]](vwn2rx);if (vwn2rx && vwn2rx[p[45405]] == p[49230]) for (var oi9zy in jc51t) {
        if (vwn2rx[jc51t[oi9zy]] == p[49231]) {
          var f4ap37 = Number(oi9zy);for (var cm5d = 0x0; cm5d < pxr2n[p[20013]]; cm5d++) {
            if (pxr2n[cm5d][0x0] == f4ap37) {
              pxr2n[cm5d][0x1] = 0x1;break;
            }
          }
        }
      }window['$aH3V5Q'](window[p[49008]], p[49232]) >= 0x0 ? wx[p[49233]]({ 'withSubscriptions': !![], 'success': function (jf1cs) {
          var f3jt47 = jf1cs[p[49234]][p[49235]];if (f3jt47) {
            console[p[20480]](p[49236]), console[p[20480]](f3jt47);for (var rn4wpa in jc51t) {
              if (f3jt47[jc51t[rn4wpa]] == p[49231]) {
                var h0xgv = Number(rn4wpa);for (var $8e6h = 0x0; $8e6h < pxr2n[p[20013]]; $8e6h++) {
                  if (pxr2n[$8e6h][0x0] == h0xgv) {
                    pxr2n[$8e6h][0x1] = 0x2;break;
                  }
                }
              }
            }console[p[20480]](pxr2n), $yeik && $yeik(pxr2n);
          } else console[p[20480]](p[49237]), console[p[20480]](jf1cs), console[p[20480]](pxr2n), $yeik && $yeik(pxr2n);
        }, 'fail': function () {
          console[p[20480]](p[49238]), console[p[20480]](pxr2n), $yeik && $yeik(pxr2n);
        } }) : (console[p[20480]](p[49239] + window[p[49008]]), console[p[20480]](pxr2n), $yeik && $yeik(pxr2n));
    })) : (console[p[20480]](p[49240] + window[p[49008]]), console[p[20480]](pxr2n), $yeik && $yeik(pxr2n)), wx[p[49241]](d5mc1s);
  }wx[p[49242]](d5mc1s);
}, window['$aQ5V3'] = { 'isSuccess': ![], 'level': p[49243], 'isCharging': ![] }, window['$aQ35V'] = function ($6ybie) {
  wx[p[49074]]({ 'success': function (n4r) {
      var tfcs = window['$aQ5V3'];tfcs[p[49244]] = !![], tfcs[p[24621]] = Number(n4r[p[24621]])[p[24233]](0x0), tfcs[p[49077]] = n4r[p[49077]], $6ybie && $6ybie(tfcs[p[49244]], tfcs[p[24621]], tfcs[p[49077]]);
    }, 'fail': function (p7w4) {
      console[p[20480]](p[49245], p7w4[p[45405]]);var ibe$6 = window['$aQ5V3'];$6ybie && $6ybie(ibe$6[p[49244]], ibe$6[p[24621]], ibe$6[p[49077]]);
    } });
}, window[p[20022]] = function (xwnv, h0xvg_, v_g2x, s1tdc5, af47, x2_g0, xnr2p, rnwap) {
  if (s1tdc5 == undefined) s1tdc5 = 0x1;wx[p[20475]]({ 'url': xwnv, 'method': xnr2p || p[45108], 'responseType': p[24430], 'data': h0xvg_, 'header': { 'content-type': rnwap || p[49142] }, 'success': function (ajf473) {
      DEBUG && console[p[20480]](p[49246], xwnv, info, ajf473);if (ajf473 && ajf473[p[45471]] == 0xc8) {
        var _2xvgn = ajf473[p[20011]];!x2_g0 || x2_g0(_2xvgn) ? v_g2x && v_g2x(_2xvgn) : window[p[49247]](xwnv, h0xvg_, v_g2x, s1tdc5, af47, x2_g0, ajf473);
      } else window[p[49247]](xwnv, h0xvg_, v_g2x, s1tdc5, af47, x2_g0, ajf473);
    }, 'fail': function (b$e6iy) {
      DEBUG && console[p[20480]](p[49248], xwnv, info, b$e6iy), window[p[49247]](xwnv, h0xvg_, v_g2x, s1tdc5, af47, x2_g0, b$e6iy);
    }, 'complete': function () {} });
}, window[p[49247]] = function (paw74r, kg_0h8, a2nr, v0g_xh, npw4r, s5dl, w37ap4) {
  v0g_xh - 0x1 > 0x0 ? setTimeout(function () {
    window[p[20022]](paw74r, kg_0h8, a2nr, v0g_xh - 0x1, npw4r, s5dl);
  }, 0x3e8) : npw4r && npw4r(JSON[p[24510]]({ 'url': paw74r, 'response': w37ap4 }));
}, window[p[49249]] = function (beoy, i$e68, ct1fsj, $ey6ki, f1s3jt, zy9bio, c15tds) {
  !ct1fsj && (ct1fsj = {});var n2xg = Math[p[20118]](Date[p[20083]]() / 0x3e8);ct1fsj[p[20849]] = n2xg, ct1fsj[p[45029]] = i$e68;var yeo$ = Object[p[20264]](ct1fsj)[p[21076]](),
      i6k8$e = '',
      w347a = '';for (var yboi9z = 0x0; yboi9z < yeo$[p[20013]]; yboi9z++) {
    i6k8$e = i6k8$e + (yboi9z == 0x0 ? '' : '&') + yeo$[yboi9z] + ct1fsj[yeo$[yboi9z]], w347a = w347a + (yboi9z == 0x0 ? '' : '&') + yeo$[yboi9z] + '=' + encodeURIComponent(ct1fsj[yeo$[yboi9z]]);
  }i6k8$e = i6k8$e + $aQV[p[49108]];var j7ft = p[49250] + md5(i6k8$e);send(beoy + '?' + w347a + (w347a == '' ? '' : '&') + j7ft, null, $ey6ki, f1s3jt, zy9bio, c15tds || function (t5dcs1) {
    return t5dcs1[p[24118]] == p[29922];
  }, null, p[48473]);
}, window['$aQ3V5'] = function (rp74aw, e6k8i) {
  var tj5c1 = 0x0;$aQV[p[45214]] && (tj5c1 = $aQV[p[45214]][p[31510]]), sendApi($aQV[p[49104]], p[49251], { 'partnerId': $aQV[p[43641]], 'gamePkg': $aQV[p[45220]], 'logTime': Math[p[20118]](Date[p[20083]]() / 0x3e8), 'platformUid': $aQV[p[45221]], 'type': rp74aw, 'serverId': tj5c1 }, null, 0x2, null, function () {
    return !![];
  });
}, window['$aQV53'] = function (a73pf) {
  sendApi($aQV[p[49102]], p[49252], { 'partner_id': $aQV[p[43641]], 'uid': $aQV[p[45219]], 'version': $aQV[p[24716]], 'game_pkg': $aQV[p[45220]], 'device': $aQV[p[45222]] }, $aQV35, $a3VQ, $aV5);
}, window['$aQV35'] = function (kh_8g0) {
  if (kh_8g0[p[24118]] === p[29922] && kh_8g0[p[20011]]) {
    kh_8g0[p[20011]][p[25598]]({ 'id': -0x2, 'name': p[49253] }), kh_8g0[p[20011]][p[25598]]({ 'id': -0x1, 'name': p[49254] }), $aQV[p[49255]] = kh_8g0[p[20011]];if (window[p[32290]]) window[p[32290]][p[49256]]();
  } else $aQV[p[49257]] = ![], window['$a53QV'](p[49258] + kh_8g0[p[24118]]);
}, window['$a53Q'] = function (hkg6) {
  sendApi($aQV[p[49102]], p[49259], { 'partner_id': $aQV[p[43641]], 'uid': $aQV[p[45219]], 'version': $aQV[p[24716]], 'game_pkg': $aQV[p[45220]], 'device': $aQV[p[45222]] }, $a5Q3, $a3VQ, $aV5);
}, window['$a5Q3'] = function (sjcft1) {
  $aQV[p[49260]] = ![];if (sjcft1[p[24118]] === p[29922] && sjcft1[p[20011]]) {
    for (var z9bqyo = 0x0; z9bqyo < sjcft1[p[20011]][p[20013]]; z9bqyo++) {
      sjcft1[p[20011]][z9bqyo][p[20106]] = $aQ35(sjcft1[p[20011]][z9bqyo]);
    }$aQV[p[49111]][-0x1] = window[p[49261]](sjcft1[p[20011]]), window[p[32290]][p[49262]](-0x1);
  } else window['$a53QV'](p[49263] + sjcft1[p[24118]]);
}, window[p[49264]] = function (hvg_0) {
  sendApi($aQV[p[49102]], p[49259], { 'partner_id': $aQV[p[43641]], 'uid': $aQV[p[45219]], 'version': $aQV[p[24716]], 'game_pkg': $aQV[p[45220]], 'device': $aQV[p[45222]] }, hvg_0, $a3VQ, $aV5);
}, window['$a35Q'] = function (v_2gx, yz9oi) {
  sendApi($aQV[p[49102]], p[49265], { 'partner_id': $aQV[p[43641]], 'uid': $aQV[p[45219]], 'version': $aQV[p[24716]], 'game_pkg': $aQV[p[45220]], 'device': $aQV[p[45222]], 'server_group_id': yz9oi }, $a3Q5, $a3VQ, $aV5);
}, window['$a3Q5'] = function (_xv20) {
  $aQV[p[49260]] = ![];if (_xv20[p[24118]] === p[29922] && _xv20[p[20011]] && _xv20[p[20011]][p[20011]]) {
    var gxn_2 = _xv20[p[20011]][p[49266]],
        csj1tf = [];for (var _xg20v = 0x0; _xg20v < _xv20[p[20011]][p[20011]][p[20013]]; _xg20v++) {
      _xv20[p[20011]][p[20011]][_xg20v][p[20106]] = $aQ35(_xv20[p[20011]][p[20011]][_xg20v]), (csj1tf[p[20013]] == 0x0 || _xv20[p[20011]][p[20011]][_xg20v][p[20106]] != 0x0) && (csj1tf[csj1tf[p[20013]]] = _xv20[p[20011]][p[20011]][_xg20v]);
    }$aQV[p[49111]][gxn_2] = window[p[49261]](csj1tf), window[p[32290]][p[49262]](gxn_2);
  } else window['$a53QV'](p[49267] + _xv20[p[24118]]);
}, window['$aH3VQ'] = function (wrnap4) {
  sendApi($aQV[p[49102]], p[49268], { 'partner_id': $aQV[p[43641]], 'uid': $aQV[p[45219]], 'version': $aQV[p[24716]], 'game_pkg': $aQV[p[45220]], 'device': $aQV[p[45222]] }, reqServerRecommendCallBack, $a3VQ, $aV5);
}, window[p[49269]] = function (cj5s) {
  $aQV[p[49260]] = ![];if (cj5s[p[24118]] === p[29922] && cj5s[p[20011]]) {
    for (var xr2wnp = 0x0; xr2wnp < cj5s[p[20011]][p[20013]]; xr2wnp++) {
      cj5s[p[20011]][xr2wnp][p[20106]] = $aQ35(cj5s[p[20011]][xr2wnp]);
    }$aQV[p[49111]][-0x2] = window[p[49261]](cj5s[p[20011]]), window[p[32290]][p[49262]](-0x2);
  } else alert(p[49270] + cj5s[p[24118]]);
}, window[p[49261]] = function (gn2x) {
  if (!gn2x && gn2x[p[20013]] <= 0x0) return gn2x;for (let x_gvh0 = 0x0; x_gvh0 < gn2x[p[20013]]; x_gvh0++) {
    gn2x[x_gvh0][p[49271]] && gn2x[x_gvh0][p[49271]] == 0x1 && (gn2x[x_gvh0][p[49193]] += p[49272]);
  }return gn2x;
}, window['$aQ53'] = function (h6$ke8, o9iybe) {
  h6$ke8 = h6$ke8 || $aQV[p[45214]][p[31510]], sendApi($aQV[p[49102]], p[49273], { 'type': '4', 'game_pkg': $aQV[p[45220]], 'server_id': h6$ke8 }, o9iybe);
}, window[p[49274]] = function (hk6$, beoy9i, ap3f4, lc5mds) {
  ap3f4 = ap3f4 || $aQV[p[45214]][p[31510]], sendApi($aQV[p[49102]], p[49275], { 'type': hk6$, 'game_pkg': beoy9i, 'server_id': ap3f4 }, lc5mds);
}, window['$aQ35'] = function (yioe9) {
  if (yioe9) {
    if (yioe9[p[20106]] == 0x1) {
      if (yioe9[p[49276]] == 0x1) return 0x2;else return 0x1;
    } else return yioe9[p[20106]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$aV53Q'] = function (jt734, fjt1c) {
  $aQV[p[49277]] = { 'step': jt734, 'server_id': fjt1c };var sd5cl = this;$a5Q3V({ 'title': p[49278] }), sendApi($aQV[p[49102]], p[49279], { 'partner_id': $aQV[p[43641]], 'uid': $aQV[p[45219]], 'game_pkg': $aQV[p[45220]], 'server_id': fjt1c, 'platform': $aQV[p[45189]], 'platform_uid': $aQV[p[45221]], 'check_login_time': $aQV[p[49186]], 'check_login_sign': $aQV[p[49185]], 'version_name': $aQV[p[49162]] }, $aV5Q3, $a3VQ, $aV5, function (i$e8k6) {
    return i$e8k6[p[24118]] == p[29922] || i$e8k6[p[20078]] == p[49280] || i$e8k6[p[20078]] == p[49281];
  });
}, window['$aV5Q3'] = function (rn4a) {
  var n4a = this;if (rn4a[p[24118]] === p[29922] && rn4a[p[20011]]) {
    var s3t = $aQV[p[45214]];s3t[p[49282]] = $aQV[p[49112]], s3t[p[31493]] = String(rn4a[p[20011]][p[49283]]), s3t[p[45191]] = parseInt(rn4a[p[20011]][p[20849]]);if (rn4a[p[20011]][p[45190]]) s3t[p[45190]] = parseInt(rn4a[p[20011]][p[45190]]);else s3t[p[45190]] = parseInt(rn4a[p[20011]][p[31510]]);s3t[p[49284]] = 0x0, s3t[p[24524]] = $aQV[p[49205]], s3t[p[49285]] = rn4a[p[20011]][p[49286]], s3t[p[49287]] = rn4a[p[20011]][p[49287]], console[p[20480]](p[49288] + JSON[p[24510]](s3t[p[49287]])), $aQV[p[20628]] == 0x1 && s3t[p[49287]] && s3t[p[49287]][p[49289]] == 0x1 && ($aQV[p[49290]] = 0x1, window[p[49007]][p[20148]]['$aHVQ']()), $aV35Q();
  } else $aQV[p[49277]][p[27118]] >= 0x3 ? ($aV5(JSON[p[24510]](rn4a)), window['$a53QV'](p[49291] + rn4a[p[24118]])) : sendApi($aQV[p[49102]], p[49171], { 'platform': $aQV[p[49100]], 'partner_id': $aQV[p[43641]], 'token': $aQV[p[49169]], 'game_pkg': $aQV[p[45220]], 'deviceId': $aQV[p[45222]], 'scene': p[49172] + $aQV[p[49110]] }, function (ybeo9i) {
    if (!ybeo9i || ybeo9i[p[24118]] != p[29922]) {
      window['$a53QV'](p[49184] + ybeo9i && ybeo9i[p[24118]]);return;
    }$aQV[p[49185]] = String(ybeo9i[p[31493]]), $aQV[p[49186]] = String(ybeo9i[p[20849]]), setTimeout(function () {
      $aV53Q($aQV[p[49277]][p[27118]] + 0x1, $aQV[p[49277]][p[31510]]);
    }, 0x5dc);
  }, $a3VQ, $aV5, function (g20x_v) {
    return g20x_v[p[24118]] == p[29922] || g20x_v[p[24118]] == p[45549];
  });
}, window['$aV35Q'] = function () {
  ServerLoading[p[20148]][p[49197]]($aQV[p[20628]]), window['$a3V'] = !![], window['$aVQ53']();
}, window['$aV3Q5'] = function () {
  if (window['$aV3'] && window['$aQ3V'] && window[p[49118]] && window[p[49119]] && window['$aQV3'] && window['$aQ3']) {
    if (!window[p[48445]][p[20148]]) {
      console[p[20480]](p[49292] + window[p[48445]][p[20148]]);var i6bye = wx[p[49293]](),
          ap4nr = i6bye[p[20774]] ? i6bye[p[20774]] : 0x0,
          nar2w = { 'cdn': window['$aQV'][p[24524]], 'spareCdn': window['$aQV'][p[44905]], 'newRegister': window['$aQV'][p[20628]], 'wxPC': window['$aQV'][p[44908]], 'wxIOS': window['$aQV'][p[21072]], 'wxAndroid': window['$aQV'][p[31332]], 'wxParam': { 'limitLoad': window['$aQV']['$aH53VQ'], 'benchmarkLevel': window['$aQV']['$aH5Q3V'], 'wxFrom': window[p[20555]][p[48612]] == p[49294] ? 0x1 : 0x0, 'wxSDKVersion': window[p[49008]] }, 'configType': window['$aQV'][p[31851]], 'exposeType': window['$aQV'][p[20712]], 'scene': ap4nr };new window[p[48445]](nar2w, window['$aQV'][p[20101]], window['$aH53QV']);
    }
  }
}, window['$aVQ53'] = function () {
  if (window['$aV3'] && window['$aQ3V'] && window[p[49118]] && window[p[49119]] && window['$aQV3'] && window['$aQ3'] && window['$a3V'] && window['$a3Q']) {
    $a5QV3();if (!$aV3Q) {
      $aV3Q = !![];if (!window[p[48445]][p[20148]]) window['$aV3Q5']();var f73p = 0x0,
          wrp2a = wx[p[49295]]();wrp2a && (window['$aQV'][p[49064]] && (f73p = wrp2a[p[20320]]), console[p[20078]](p[49296] + wrp2a[p[20320]] + p[49297] + wrp2a[p[21213]] + p[49298] + wrp2a[p[21215]] + p[49299] + wrp2a[p[21214]] + p[49300] + wrp2a[p[20176]] + p[49301] + wrp2a[p[20177]]));var w4a7p3 = {};for (const ap74rw in $aQV[p[45214]]) {
        w4a7p3[ap74rw] = $aQV[p[45214]][ap74rw];
      }var kh$860 = { 'channel': window['$aQV'][p[45218]], 'account': window['$aQV'][p[45219]], 'userId': window['$aQV'][p[43640]], 'cdn': window['$aQV'][p[24524]], 'data': window['$aQV'][p[20011]], 'package': window['$aQV'][p[44906]], 'newRegister': window['$aQV'][p[20628]], 'pkgName': window['$aQV'][p[45220]], 'partnerId': window['$aQV'][p[43641]], 'platform_uid': window['$aQV'][p[45221]], 'deviceId': window['$aQV'][p[45222]], 'selectedServer': w4a7p3, 'configType': window['$aQV'][p[31851]], 'exposeType': window['$aQV'][p[20712]], 'debugUsers': window['$aQV'][p[32244]], 'wxMenuTop': f73p, 'wxShield': window['$aQV'][p[20736]] };if (window[p[49207]]) for (var w7pr4a in window[p[49207]]) {
        kh$860[w7pr4a] = window[p[49207]][w7pr4a];
      }window[p[48445]][p[20148]]['$a3HQV'](kh$860);
    }
  } else console[p[20078]](p[49302] + window['$aV3'] + p[49303] + window['$aQ3V'] + p[49304] + window[p[49118]] + p[49305] + window[p[49119]] + p[49306] + window['$aQV3'] + p[49307] + window['$aQ3'] + p[49308] + window['$a3V'] + p[49309] + window['$a3Q']);
};