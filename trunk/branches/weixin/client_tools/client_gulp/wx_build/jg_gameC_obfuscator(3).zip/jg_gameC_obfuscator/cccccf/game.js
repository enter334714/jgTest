var p = wx.$h;
require('ccccBuff.js'), window[p[48718]][p[48708]][p[48599]] = null, window['client_pb'] = require('ccccleintpb.js'), window[p[45360]] = window[p[48718]][p[45248]][p[45249]](client_pb);