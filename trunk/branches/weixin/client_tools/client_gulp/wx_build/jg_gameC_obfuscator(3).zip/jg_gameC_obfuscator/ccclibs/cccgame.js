var p = wx.$h;
console[p[20078]](p[48989]), window[p[48990]], wx[p[48991]](function (w2nvx) {
  if (w2nvx) {
    if (w2nvx[p[24525]]) {
      var pnx2wr = window[p[20555]][p[48992]][p[24703]](new RegExp(/\./, 'g'), '_'),
          yoe$bi = w2nvx[p[24525]],
          ybizo = yoe$bi[p[32052]](/(cccccccc\/cccgame.js:)[0-9]{1,60}(:)/g);if (ybizo) for (var wa4 = 0x0; wa4 < ybizo[p[20013]]; wa4++) {
        if (ybizo[wa4] && ybizo[wa4][p[20013]] > 0x0) {
          var x_gh = parseInt(ybizo[wa4][p[24703]](p[48993], '')[p[24703]](':', ''));yoe$bi = yoe$bi[p[24703]](ybizo[wa4], ybizo[wa4][p[24703]](':' + x_gh + ':', ':' + (x_gh - 0x2) + ':'));
        }
      }yoe$bi = yoe$bi[p[24703]](new RegExp(p[48994], 'g'), p[48995] + pnx2wr + p[45319]), yoe$bi = yoe$bi[p[24703]](new RegExp(p[48996], 'g'), p[48995] + pnx2wr + p[45319]), w2nvx[p[24525]] = yoe$bi;
    }var ozyi9b = { 'id': window['$aQV'][p[48997]], 'role': window['$aQV'][p[24645]], 'level': window['$aQV'][p[48998]], 'user': window['$aQV'][p[45219]], 'version': window['$aQV'][p[20101]], 'cdn': window['$aQV'][p[24524]], 'pkgName': window['$aQV'][p[45220]], 'gamever': window[p[20555]][p[48992]], 'serverid': window['$aQV'][p[45214]] ? window['$aQV'][p[45214]][p[31510]] : 0x0, 'systemInfo': window[p[48999]], 'error': p[49000], 'stack': w2nvx ? w2nvx[p[24525]] : '' },
        kh80g_ = JSON[p[24510]](ozyi9b);console[p[20125]](p[49001] + kh80g_), (!window[p[48990]] || window[p[48990]] != ozyi9b[p[20125]]) && (window[p[48990]] = ozyi9b[p[20125]], window['$a5Q'](ozyi9b));
  }
});import 'cccmd5min.js';import 'ccczlibs.js';window[p[49002]] = require(p[49003]);import 'cccindex.js';import 'ccclibsmin.js';import 'cccwxmini.js';import 'cccinitmin.js';console[p[20078]](p[49004]), console[p[20078]](p[49005]), $a5Q3V({ 'title': p[49006] });var a_k608h = { '$aH5VQ3': !![] };new window[p[49007]](a_k608h), window[p[49007]][p[20148]]['$aH3QV5']();if (window['$aH5QV3']) clearInterval(window['$aH5QV3']);window['$aH5QV3'] = null, window['$aH3V5Q'] = function (nr2a, c51dts) {
  if (!nr2a || !c51dts) return 0x0;nr2a = nr2a[p[20015]]('.'), c51dts = c51dts[p[20015]]('.');const ld5c = Math[p[20851]](nr2a[p[20013]], c51dts[p[20013]]);while (nr2a[p[20013]] < ld5c) {
    nr2a[p[20029]]('0');
  }while (c51dts[p[20013]] < ld5c) {
    c51dts[p[20029]]('0');
  }for (var csm5l = 0x0; csm5l < ld5c; csm5l++) {
    const v_80h = parseInt(nr2a[csm5l]),
          gn_ = parseInt(c51dts[csm5l]);if (v_80h > gn_) return 0x1;else {
      if (v_80h < gn_) return -0x1;
    }
  }return 0x0;
}, window[p[49008]] = wx[p[49009]]()[p[49008]], console[p[20480]](p[49010] + window[p[49008]]);var a_jf473a = wx[p[49011]]();a_jf473a[p[49012]](function (sd15tc) {
  console[p[20480]](p[49013] + sd15tc[p[49014]]);
}), a_jf473a[p[49015]](function () {
  wx[p[49016]]({ 'title': p[49017], 'content': p[49018], 'showCancel': ![], 'success': function (iek$6) {
      a_jf473a[p[49019]]();
    } });
}), a_jf473a[p[49020]](function () {
  console[p[20480]](p[49021]);
}), window['$aH3VQ5'] = function () {
  console[p[20480]](p[49022]);var vngx2_ = wx[p[49023]]({ 'name': p[49024], 'success': function (x0vgh) {
      console[p[20480]](p[49025]), console[p[20480]](x0vgh), x0vgh && x0vgh[p[45405]] == p[49026] ? (window['$aV3'] = !![], window['$aV3Q5'](), window['$aVQ53']()) : setTimeout(function () {
        window['$aH3VQ5']();
      }, 0x1f4);
    }, 'fail': function (a374j) {
      console[p[20480]](p[49027]), console[p[20480]](a374j), setTimeout(function () {
        window['$aH3VQ5']();
      }, 0x1f4);
    } });vngx2_ && vngx2_[p[49028]](nwrvx => {});
}, window['$aHQ5V3'] = function () {
  console[p[20480]](p[49029]);var wrx2v = wx[p[49023]]({ 'name': p[49030], 'success': function (obzqy) {
      console[p[20480]](p[49031]), console[p[20480]](obzqy), obzqy && obzqy[p[45405]] == p[49026] ? (window['$aQ3V'] = !![], window['$aV3Q5'](), window['$aVQ53']()) : setTimeout(function () {
        window['$aHQ5V3']();
      }, 0x1f4);
    }, 'fail': function (k$e6i8) {
      console[p[20480]](p[49032]), console[p[20480]](k$e6i8), setTimeout(function () {
        window['$aHQ5V3']();
      }, 0x1f4);
    } });wrx2v && wrx2v[p[49028]](ek8$h => {});
}, window[p[49033]] = function () {
  window['$aH3V5Q'](window[p[49008]], p[49034]) >= 0x0 ? (console[p[20480]](p[49035] + window[p[49008]] + p[49036]), window['$aQ5'](), window['$aH3VQ5'](), window['$aHQ5V3']()) : (window['$aQV5'](p[49037], window[p[49008]]), wx[p[49016]]({ 'title': p[26361], 'content': p[49038] }));
}, window[p[48999]] = '', wx[p[49039]]({ 'success'(smd) {
    window[p[48999]] = p[49040] + smd[p[49041]] + p[49042] + smd[p[49043]] + p[49044] + smd[p[24716]] + p[49045] + smd[p[20473]] + p[49046] + smd[p[45189]] + p[49047] + smd[p[49008]] + p[49048] + smd[p[29309]], console[p[20480]](window[p[48999]]), console[p[20480]](p[49049] + smd[p[49050]] + p[49051] + smd[p[49052]] + p[49053] + smd[p[49054]] + p[49055] + smd[p[49056]] + p[49057] + smd[p[49058]] + p[49059] + smd[p[49060]] + p[49061] + (smd[p[49062]] ? smd[p[49062]][p[20320]] + ',' + smd[p[49062]][p[21213]] + ',' + smd[p[49062]][p[21215]] + ',' + smd[p[49062]][p[21214]] : ''));var n_vx2r = smd[p[20473]] ? smd[p[20473]][p[32339]]() : '',
        g8k_h0 = smd[p[49043]] ? smd[p[49043]][p[32339]]()[p[24703]]('\x20', '') : '';window['$aQV'][p[21072]] = n_vx2r[p[20115]](p[49063]) != -0x1, window['$aQV'][p[31332]] = n_vx2r[p[20115]](p[48496]) != -0x1, window['$aQV'][p[49064]] = n_vx2r[p[20115]](p[49063]) != -0x1 || n_vx2r[p[20115]](p[48496]) != -0x1, window['$aQV'][p[44908]] = n_vx2r[p[20115]](p[48497]) != -0x1 || n_vx2r[p[20115]](p[49065]) != -0x1, window['$aQV'][p[49066]] = smd[p[45189]] ? smd[p[45189]][p[32339]]() : '', window['$aQV']['$aH53VQ'] = ![], window['$aQV']['$aH5Q3V'] = 0x2;if (n_vx2r[p[20115]](p[48496]) != -0x1) {
      if (smd[p[29309]] >= 0x18) window['$aQV']['$aH5Q3V'] = 0x3;else window['$aQV']['$aH5Q3V'] = 0x2;
    } else {
      if (n_vx2r[p[20115]](p[49063]) != -0x1) {
        if (smd[p[29309]] && smd[p[29309]] >= 0x14) window['$aQV']['$aH5Q3V'] = 0x3;else {
          if (g8k_h0[p[20115]](p[49067]) != -0x1 || g8k_h0[p[20115]](p[49068]) != -0x1 || g8k_h0[p[20115]](p[49069]) != -0x1 || g8k_h0[p[20115]](p[49070]) != -0x1 || g8k_h0[p[20115]](p[49071]) != -0x1) window['$aQV']['$aH5Q3V'] = 0x2;else window['$aQV']['$aH5Q3V'] = 0x3;
        }
      } else window['$aQV']['$aH5Q3V'] = 0x2;
    }console[p[20480]](p[49072] + window['$aQV']['$aH53VQ'] + p[49073] + window['$aQV']['$aH5Q3V']);
  } }), wx[p[49074]]({ 'success': function (rxwnp2) {
    console[p[20480]](p[49075] + rxwnp2[p[24621]] + p[49076] + rxwnp2[p[49077]]);
  } }), wx[p[49078]]({ 'success': function (s1cf) {
    console[p[20480]](p[49079] + s1cf[p[49080]]);
  } }), wx[p[49081]]({ 'keepScreenOn': !![] }), wx[p[49082]](function (iyob9) {
  console[p[20480]](p[49079] + iyob9[p[49080]] + p[49083] + iyob9[p[49084]]);
}), wx[p[30843]](function (wrv2xn) {
  window['$a35'] = wrv2xn, window['$aV53'] && window['$a35'] && (console[p[20078]](p[49085] + window['$a35'][p[20774]]), window['$aV53'](window['$a35']), window['$a35'] = null);
}), window[p[49086]] = 0x0, window['$aHQ3V5'] = 0x0, window[p[49087]] = null, wx[p[49088]](function () {
  window['$aHQ3V5']++;var gk08_h = Date[p[20083]]();(window[p[49086]] == 0x0 || gk08_h - window[p[49086]] > 0x1d4c0) && (console[p[20096]](p[49089]), wx[p[31905]]());if (window['$aHQ3V5'] >= 0x2) {
    window['$aHQ3V5'] = 0x0, console[p[20125]](p[49090]), wx[p[49091]]('0', 0x1);if (window['$aQV'] && window['$aQV'][p[21072]]) window['$aQV5'](p[49092], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});