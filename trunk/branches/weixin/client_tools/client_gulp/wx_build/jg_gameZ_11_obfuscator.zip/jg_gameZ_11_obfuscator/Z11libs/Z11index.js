var B = wx.$z;
import z_he from '../Z11k/Z11sdk.js';window[B[0xa7]] = { 'wxVersion': window[B[0x6]][B[0x7]] }, window[B[0xa8]] = ![], window[B[0xa9]] = 0x1, window[B[0xaa]] = 0x1, window[B[0xab]] = !![], window[B[0xac]] = !![], window[B[0xad]] = '', window[B[0xae]] = ![], window[B[0x10]] = { 'base_cdn': B[0xaf], 'cdn': B[0xaf] }, z07L[B[0xb0]] = {}, z07L[B[0xb1]] = '0', z07L[B[0x5d]] = window[B[0xa7]][B[0xb2]], z07L[B[0x80]] = '', z07L['os'] = '1', z07L[B[0xb3]] = B[0xb4], z07L[B[0xb5]] = B[0xb6], z07L[B[0xb7]] = B[0xb8], z07L[B[0xb9]] = B[0xba], z07L[B[0xbb]] = B[0xbc], z07L[B[0xbd]] = '1', z07L[B[0x17]] = '', z07L[B[0xbe]] = '', z07L[B[0xbf]] = 0x0, z07L[B[0xc0]] = {}, z07L[B[0xc1]] = parseInt(z07L[B[0xbd]]), z07L[B[0xc2]] = z07L[B[0xbd]], z07L[B[0x18]] = {}, z07L[B[0x1f]] = B[0xc3], z07L[B[0xc4]] = ![], z07L[B[0xc5]] = B[0xc6], z07L[B[0xc7]] = Date[B[0xa0]](), z07L[B[0xc8]] = B[0xc9], z07L[B[0xca]] = '_a', z07L[B[0xcb]] = 0x2, z07L[B[0x15]] = 0x7c1, z07L[B[0xb2]] = window[B[0xa7]][B[0xb2]], z07L[B[0xcc]] = ![], z07L[B[0x78]] = ![], z07L[B[0x7b]] = ![], z07L[B[0x7e]] = ![], window[B[0xcd]] = 0x5, window[B[0xce]] = ![], window[B[0x43]] = ![], window[B[0x4c]] = ![], window[B[0xcf]] = ![], window[B[0xd0]] = ![], window[B[0xd1]] = ![], window[B[0xd2]] = ![], window[B[0xd3]] = ![], window[B[0xd4]] = ![], window[B[0xd5]] = null, window[B[0xd6]] = function (hmf0wz) {
  console[B[0x2f]](B[0xd6], hmf0wz), wx[B[0xd7]]({}), wx[B[0x36]]({ 'title': B[0x55], 'content': hmf0wz, 'success'(fzmw09) {
      if (fzmw09[B[0xd8]]) console[B[0x2f]](B[0xd9]);else fzmw09[B[0xda]] && console[B[0x2f]](B[0xdb]);
    } });
}, window[B[0xdc]] = function (xp1368) {
  console[B[0x2f]](B[0xdd], xp1368), z0Y7LG(), wx[B[0x36]]({ 'title': B[0x55], 'content': xp1368, 'confirmText': B[0xde], 'cancelText': B[0xdf], 'success'(wz39df) {
      if (wz39df[B[0xd8]]) window[B[0x52]]();else wz39df[B[0xda]] && (console[B[0x2f]](B[0xe0]), wx[B[0xe1]]({}));
    } });
}, window[B[0xe2]] = function (bis7u5) {
  console[B[0x2f]](B[0xe2], bis7u5), wx[B[0x36]]({ 'title': B[0x55], 'content': bis7u5, 'confirmText': B[0xe3], 'showCancel': ![], 'complete'(x8p41) {
      console[B[0x2f]](B[0xe0]), wx[B[0xe1]]({});
    } });
}, window[B[0xe4]] = ![], window[B[0xe5]] = function (_agjr) {
  window[B[0xe4]] = !![], wx[B[0xe6]](_agjr);
}, window[B[0xe7]] = function () {
  window[B[0xe4]] && (window[B[0xe4]] = ![], wx[B[0xd7]]({}));
}, window[B[0xe8]] = function (q_an0h) {
  window[B[0x25]][B[0x26]][B[0xe8]](q_an0h);
}, window[B[0xe9]] = function (ujogrs, y5l2$t) {
  z_he[B[0xe9]](ujogrs, function (q0hnma) {
    q0hnma && q0hnma[B[0xea]] ? q0hnma[B[0xea]][B[0xeb]] == 0x1 ? y5l2$t(!![]) : (y5l2$t(![]), console[B[0x1]](B[0xec] + q0hnma[B[0xea]][B[0xed]])) : console[B[0x2f]](B[0xe9], q0hnma);
  });
}, window[B[0xee]] = function (qnham) {
  console[B[0x2f]](B[0xef], qnham);
}, window[B[0xf0]] = function (wnqhm0) {}, window[B[0xf1]] = function (ios, grsuj, rsou7) {}, window[B[0xf2]] = function (iyb75) {
  console[B[0x2f]](B[0xf3], iyb75), window[B[0x25]][B[0x26]][B[0xf4]](), window[B[0x25]][B[0x26]][B[0xf5]](), window[B[0x25]][B[0x26]][B[0xf6]]();
}, window[B[0xf7]] = function (h0wmf) {
  window[B[0xf8]](0xe, B[0xf9] + h0wmf), window[B[0xdc]](B[0xfa]);var bs7u5 = { 'id': window[B[0x10]][B[0x11]], 'role': window[B[0x10]][B[0x12]], 'level': window[B[0x10]][B[0x13]], 'account': window[B[0x10]][B[0x14]], 'version': window[B[0x10]][B[0x15]], 'cdn': window[B[0x10]][B[0x16]], 'pkgName': window[B[0x10]][B[0x17]], 'gamever': window[B[0x6]][B[0x7]], 'serverid': window[B[0x10]][B[0x18]] ? window[B[0x10]][B[0x18]][B[0x19]] : 0x0, 'systemInfo': window[B[0x1a]], 'error': B[0xfb], 'stack': h0wmf ? h0wmf : B[0xfa] },
      mzw09f = JSON[B[0x1c]](bs7u5);console[B[0x1d]](B[0xfc] + mzw09f), window[B[0x1f]](mzw09f);
}, window[B[0xf8]] = function (rgoe_, boisu7) {
  sendApi(z07L[B[0xb7]], B[0xfd], { 'game_pkg': z07L[B[0x17]], 'partner_id': z07L[B[0xbd]], 'server_id': z07L[B[0x18]] && z07L[B[0x18]][B[0x19]] > 0x0 ? z07L[B[0x18]][B[0x19]] : 0x0, 'uid': z07L[B[0x14]] > 0x0 ? z07L[B[0x14]] : 0x0, 'type': rgoe_, 'info': boisu7 });
}, window[B[0xfe]] = function (s7uiob) {
  var t7yb25 = JSON[B[0xff]](s7uiob);t7yb25[B[0x100]] = window[B[0x6]][B[0x7]], t7yb25[B[0x101]] = window[B[0x10]][B[0x18]] ? window[B[0x10]][B[0x18]][B[0x19]] : 0x0, t7yb25[B[0x1a]] = window[B[0x1a]];var x4kp8 = JSON[B[0x1c]](t7yb25);console[B[0x1d]](B[0x102] + x4kp8), window[B[0x1f]](x4kp8);
}, window[B[0x53]] = function (d9f631, wm09) {
  var ly5t$ = { 'id': window[B[0x10]][B[0x11]], 'role': window[B[0x10]][B[0x12]], 'level': window[B[0x10]][B[0x13]], 'account': window[B[0x10]][B[0x14]], 'version': window[B[0x10]][B[0x15]], 'cdn': window[B[0x10]][B[0x16]], 'pkgName': window[B[0x10]][B[0x17]], 'gamever': window[B[0x6]][B[0x7]], 'serverid': window[B[0x10]][B[0x18]] ? window[B[0x10]][B[0x18]][B[0x19]] : 0x0, 'systemInfo': window[B[0x1a]], 'error': d9f631, 'stack': wm09 },
      srou7i = JSON[B[0x1c]](ly5t$);console[B[0xa1]](B[0x103] + srou7i), window[B[0x1f]](srou7i);
}, window[B[0x1f]] = function ($by2t) {
  if (window[B[0x10]][B[0x81]] == B[0x104]) return;var juso = z07L[B[0x1f]] + B[0x105] + z07L[B[0x14]];wx[B[0x106]]({ 'url': juso, 'method': B[0x107], 'data': $by2t, 'header': { 'content-type': B[0x108], 'cache-control': B[0x109] }, 'success': function (oerjg_) {
      DEBUG && console[B[0x2f]](B[0x10a], juso, $by2t, oerjg_);
    }, 'fail': function (qhmna) {
      DEBUG && console[B[0x2f]](B[0x10a], juso, $by2t, qhmna);
    }, 'complete': function () {} });
}, window[B[0x10b]] = function () {
  function is57() {
    return ((0x1 + Math[B[0x10c]]()) * 0x10000 | 0x0)[B[0x10d]](0x10)[B[0x10e]](0x1);
  }return is57() + is57() + '-' + is57() + '-' + is57() + '-' + is57() + '+' + is57() + is57() + is57();
}, window[B[0x52]] = function () {
  console[B[0x2f]](B[0x10f]);var s7iuro = z_he[B[0x110]]();z07L[B[0xc2]] = s7iuro[B[0x111]], z07L[B[0xc1]] = s7iuro[B[0x111]], z07L[B[0xbd]] = s7iuro[B[0x111]], z07L[B[0x17]] = s7iuro[B[0x112]];var hqmnw0 = { 'game_ver': z07L[B[0x5d]] };z07L[B[0xbe]] = this[B[0x10b]](), z0Y7GL({ 'title': B[0x113] }), z_he[B[0x114]](hqmnw0, this[B[0x115]][B[0x116]](this));
}, window[B[0x115]] = function (u5is7) {
  var _nhqa = u5is7[B[0x117]];sdkInitRes = u5is7, console[B[0x2f]](B[0x118] + _nhqa + B[0x119] + (_nhqa == 0x1) + B[0x11a] + u5is7[B[0x7]] + B[0x11b] + window[B[0xa7]][B[0xb2]]);if (!u5is7[B[0x7]] || window[B[0x29]](window[B[0xa7]][B[0xb2]], u5is7[B[0x7]]) < 0x0) console[B[0x2f]](B[0x11c]), z07L[B[0xb5]] = B[0x11d], z07L[B[0xb7]] = B[0x11e], z07L[B[0xb9]] = B[0x11f], z07L[B[0x16]] = B[0x120], z07L[B[0x121]] = B[0x122], z07L[B[0x123]] = 'fj', z07L[B[0xcc]] = ![];else window[B[0x29]](window[B[0xa7]][B[0xb2]], u5is7[B[0x7]]) == 0x0 ? (console[B[0x2f]](B[0x124]), z07L[B[0xb5]] = B[0xb6], z07L[B[0xb7]] = B[0xb8], z07L[B[0xb9]] = B[0xba], z07L[B[0x16]] = B[0x125], z07L[B[0x121]] = B[0x122], z07L[B[0x123]] = B[0x126], z07L[B[0xcc]] = !![]) : (console[B[0x2f]](B[0x127]), z07L[B[0xb5]] = B[0xb6], z07L[B[0xb7]] = B[0xb8], z07L[B[0xb9]] = B[0xba], z07L[B[0x16]] = B[0x125], z07L[B[0x121]] = B[0x122], z07L[B[0x123]] = B[0x126], z07L[B[0xcc]] = ![]);z07L[B[0xbf]] = config[B[0x128]] ? config[B[0x128]] : 0x0, this[B[0x129]](), this[B[0x12a]](), window[B[0x12b]] = 0x5, z0Y7GL({ 'title': B[0x12c] }), z_he[B[0x12d]](this[B[0x12e]][B[0x116]](this));
}, window[B[0x12b]] = 0x5, window[B[0x12e]] = function (_qjae, w0mhqn) {
  if (_qjae == 0x0 && w0mhqn && w0mhqn[B[0x12f]]) {
    z07L[B[0x130]] = w0mhqn[B[0x12f]];var iu7ob = this;z0Y7GL({ 'title': B[0x131] }), sendApi(z07L[B[0xb5]], B[0x132], { 'platform': z07L[B[0xb3]], 'partner_id': z07L[B[0xbd]], 'token': w0mhqn[B[0x12f]], 'game_pkg': z07L[B[0x17]], 'deviceId': z07L[B[0xbe]], 'scene': B[0x133] + z07L[B[0xbf]] }, this[B[0x134]][B[0x116]](this), z0GL7, z0LY);
  } else w0mhqn && w0mhqn[B[0x41]] && window[B[0x12b]] > 0x0 && (w0mhqn[B[0x41]][B[0x79]](B[0x135]) != -0x1 || w0mhqn[B[0x41]][B[0x79]](B[0x136]) != -0x1 || w0mhqn[B[0x41]][B[0x79]](B[0x137]) != -0x1 || w0mhqn[B[0x41]][B[0x79]](B[0x138]) != -0x1 || w0mhqn[B[0x41]][B[0x79]](B[0x139]) != -0x1 || w0mhqn[B[0x41]][B[0x79]](B[0x13a]) != -0x1) ? (window[B[0x12b]]--, z_he[B[0x12d]](this[B[0x12e]][B[0x116]](this))) : (window[B[0xf8]](0x1, B[0x13b] + _qjae + B[0x13c] + (w0mhqn ? w0mhqn[B[0x41]] : '')), window[B[0x53]](B[0x13d], JSON[B[0x1c]]({ 'status': _qjae, 'data': w0mhqn })), window[B[0xdc]](B[0x13e] + (w0mhqn && w0mhqn[B[0x41]] ? '，' + w0mhqn[B[0x41]] : '')));
}, window[B[0x134]] = function (jogusr) {
  if (!jogusr) {
    window[B[0xf8]](0x2, B[0x13f]), window[B[0x53]](B[0x140], B[0x141]), window[B[0xdc]](B[0x142]);return;
  }if (jogusr[B[0xeb]] != B[0x143]) {
    window[B[0xf8]](0x2, B[0x144] + jogusr[B[0xeb]]), window[B[0x53]](B[0x140], JSON[B[0x1c]](jogusr)), window[B[0xdc]](B[0x145] + jogusr[B[0xeb]]);return;
  }z07L[B[0x146]] = String(jogusr[B[0x14]]), z07L[B[0x14]] = String(jogusr[B[0x14]]), z07L[B[0x61]] = String(jogusr[B[0x61]]), z07L[B[0xc2]] = String(jogusr[B[0x61]]), z07L[B[0x147]] = String(jogusr[B[0x147]]), z07L[B[0x148]] = String(jogusr[B[0x149]]), z07L[B[0x14a]] = String(jogusr[B[0x14b]]), z07L[B[0x149]] = '';var ra_ejg = this;z0Y7GL({ 'title': B[0x14c] });var uy57 = localStorage[B[0x14d]](B[0x14e] + z07L[B[0x17]] + z07L[B[0x14]]);if (uy57 && uy57 != '') {
    var tly$ = Number(uy57);ra_ejg[B[0x14f]](tly$);
  } else ra_ejg[B[0x150]]();
}, window[B[0x150]] = function () {
  var us7ir = this;sendApi(z07L[B[0xb5]], B[0x151], { 'partner_id': z07L[B[0xbd]], 'uid': z07L[B[0x14]], 'version': z07L[B[0x5d]], 'game_pkg': z07L[B[0x17]], 'device': z07L[B[0xbe]] }, us7ir[B[0x152]][B[0x116]](us7ir), z0GL7, z0LY);
}, window[B[0x152]] = function (f9d31) {
  if (!f9d31) {
    window[B[0xf8]](0x3, B[0x153]), window[B[0xdc]](B[0x153]);return;
  }if (f9d31[B[0xeb]] != B[0x143]) {
    window[B[0xf8]](0x3, B[0x154] + f9d31[B[0xeb]]), window[B[0xdc]](B[0x154] + f9d31[B[0xeb]]);return;
  }if (!f9d31[B[0xea]] || f9d31[B[0xea]][B[0xa]] == 0x0) {
    window[B[0xf8]](0x3, B[0x155]), window[B[0xdc]](B[0x156]);return;
  }this[B[0x157]](f9d31);
}, window[B[0x14f]] = function (jqea_g) {
  var iby2 = this;sendApi(z07L[B[0xb5]], B[0x158], { 'server_id': jqea_g, 'time': Date[B[0xa0]]() / 0x3e8 }, iby2[B[0x159]][B[0x116]](iby2), z0GL7, z0LY);
}, window[B[0x159]] = function (hzfwm) {
  if (!hzfwm) {
    window[B[0xf8]](0x4, B[0x15a]), this[B[0x150]]();return;
  }if (hzfwm[B[0xeb]] != B[0x143]) {
    window[B[0xf8]](0x4, B[0x15b] + hzfwm[B[0xeb]]), this[B[0x150]]();return;
  }if (!hzfwm[B[0xea]] || hzfwm[B[0xea]][B[0xa]] == 0x0) {
    window[B[0xf8]](0x4, B[0x15c]), this[B[0x150]]();return;
  }this[B[0x157]](hzfwm), window[B[0x25]] && window[B[0x25]][B[0x26]][B[0x15d]] && window[B[0x25]][B[0x26]][B[0x15d]](sdkInitRes[B[0x15e]], sdkInitRes[B[0x15f]], sdkInitRes[B[0x160]], sdkInitRes[B[0x161]], sdkInitRes[B[0x162]]);
}, window[B[0x157]] = function (ub7ois) {
  z07L[B[0x163]] = ub7ois[B[0x164]] != undefined ? ub7ois[B[0x164]] : 0x0, z07L[B[0x18]] = { 'server_id': String(ub7ois[B[0xea]][0x0][B[0x19]]), 'server_name': String(ub7ois[B[0xea]][0x0][B[0x165]]), 'entry_ip': ub7ois[B[0xea]][0x0][B[0x166]], 'entry_port': parseInt(ub7ois[B[0xea]][0x0][B[0x167]]), 'status': z07GY(ub7ois[B[0xea]][0x0]), 'start_time': ub7ois[B[0xea]][0x0][B[0x168]], 'cdn': z07L[B[0x16]] }, this[B[0x169]]();
}, window[B[0x16a]] = null, window[B[0x169]] = function () {
  var t$5b2y = this;z_he[B[0x16b]](function (geo) {
    console[B[0x2f]](B[0x16c] + JSON[B[0x1c]](geo)), youYiCofig = geo;window[B[0x16a]][B[0x16d]] == 0x1 && (z07L[B[0x163]] = 0x0);if (z07L[B[0x163]] == 0x1) {
      var mfdw9 = z07L[B[0x18]][B[0x16e]];if (mfdw9 === -0x1 || mfdw9 === 0x0) {
        window[B[0xf8]](0xf, B[0x16f] + z07L[B[0x18]]['id'] + B[0x170] + z07L[B[0x18]][B[0x16e]]), window[B[0xdc]](mfdw9 === -0x1 ? B[0x171] : B[0x172]);return;
      }z0LYG7(0x0, z07L[B[0x18]][B[0x19]]), window[B[0x25]][B[0x26]][B[0x173]](z07L[B[0x163]]);
    } else window[B[0x25]][B[0x26]][B[0x174]](() => {
      var rjisuo = window[B[0x16a]][B[0x175]],
          s5b7ui = window[B[0x16a]][B[0x16d]] == 0x1;s5b7ui && window[B[0x25]][B[0x26]][B[0x176]](B[0x177], rjisuo, B[0x178]);
    }, t$5b2y), z0Y7LG();window[B[0xd3]] = !![], window[B[0x44]](), window[B[0x45]]();
  });
}, window[B[0x179]] = function () {
  z_he[B[0x17a]](function (n_aeq) {
    console[B[0x2f]](B[0x17b] + JSON[B[0x1c]](n_aeq));
  });
}, window[B[0x129]] = function () {
  sendApi(z07L[B[0xb5]], B[0x17c], { 'game_pkg': z07L[B[0x17]], 'version_name': z07L[B[0x123]] }, this[B[0x17d]][B[0x116]](this), z0GL7, z0LY);
}, window[B[0x17d]] = function (l$y5t) {
  if (!l$y5t) {
    window[B[0xf8]](0x5, B[0x17e]), window[B[0xdc]](B[0x17e]);return;
  }if (l$y5t[B[0xeb]] != B[0x143]) {
    window[B[0xf8]](0x5, B[0x17f] + l$y5t[B[0xeb]]), window[B[0xdc]](B[0x17f] + l$y5t[B[0xeb]]);return;
  }if (!l$y5t[B[0xea]] || !l$y5t[B[0xea]][B[0x5d]]) {
    window[B[0xf8]](0x5, B[0x180] + (l$y5t[B[0xea]] && l$y5t[B[0xea]][B[0x5d]])), window[B[0xdc]](B[0x180] + (l$y5t[B[0xea]] && l$y5t[B[0xea]][B[0x5d]]));return;
  }l$y5t[B[0xea]][B[0x181]] && l$y5t[B[0xea]][B[0x181]][B[0xa]] > 0xa && (z07L[B[0x182]] = l$y5t[B[0xea]][B[0x181]], z07L[B[0x16]] = l$y5t[B[0xea]][B[0x181]]), l$y5t[B[0xea]][B[0x5d]] && (z07L[B[0x15]] = l$y5t[B[0xea]][B[0x5d]]), console[B[0x1]](B[0x183] + z07L[B[0x15]] + B[0x184] + z07L[B[0x123]]), window[B[0xd1]] = !![], window[B[0x44]](), window[B[0x45]]();
}, window[B[0x185]], window[B[0x12a]] = function () {
  sendApi(z07L[B[0xb5]], B[0x186], { 'game_pkg': z07L[B[0x17]] }, this[B[0x187]][B[0x116]](this), z0GL7, z0LY);
}, window[B[0x187]] = function (nwqh0) {
  if (nwqh0 && nwqh0[B[0xeb]] === B[0x143] && nwqh0[B[0xea]]) {
    window[B[0x185]] = nwqh0[B[0xea]];for (var ijrus in nwqh0[B[0xea]]) {
      z07L[ijrus] = nwqh0[B[0xea]][ijrus];
    }
  } else window[B[0xf8]](0xb, B[0x188]), console[B[0x1]](B[0x189] + nwqh0[B[0xeb]]);window[B[0xd2]] = !![], window[B[0x45]]();
}, window[B[0x18a]] = function (i5u7sb, iub75, fzm90w, ejq_g, _jero, _e, b5i7y2, aq0_nh, uojg, mfd9wz) {
  _jero = String(_jero);var jusrg = b5i7y2,
      sejgor = aq0_nh;z07L[B[0xb0]][_jero] = { 'productid': _jero, 'productname': jusrg, 'productdesc': sejgor, 'roleid': i5u7sb, 'rolename': iub75, 'rolelevel': fzm90w, 'price': _e, 'callback': uojg }, sendApi(z07L[B[0xb9]], B[0x18b], { 'game_pkg': z07L[B[0x17]], 'server_id': z07L[B[0x18]][B[0x19]], 'server_name': z07L[B[0x18]][B[0x165]], 'level': fzm90w, 'uid': z07L[B[0x14]], 'role_id': i5u7sb, 'role_name': iub75, 'product_id': _jero, 'product_name': jusrg, 'product_desc': sejgor, 'money': _e, 'partner_id': z07L[B[0xbd]] }, toPayCallBack, z0GL7, z0LY);
}, window[B[0x18c]] = function (qwhmn0) {
  if (qwhmn0 && (qwhmn0[B[0x18d]] === 0xc8 || qwhmn0[B[0xeb]] == B[0x143])) {
    var s7ubo = z07L[B[0xb0]][String(qwhmn0[B[0x18e]])];if (s7ubo[B[0x18f]]) s7ubo[B[0x18f]](qwhmn0[B[0x18e]], qwhmn0[B[0x190]], -0x1);z_he[B[0x191]]({ 'cpbill': qwhmn0[B[0x190]], 'productid': qwhmn0[B[0x18e]], 'productname': s7ubo[B[0x192]], 'productdesc': s7ubo[B[0x193]], 'serverid': z07L[B[0x18]][B[0x19]], 'servername': z07L[B[0x18]][B[0x165]], 'roleid': s7ubo[B[0x194]], 'rolename': s7ubo[B[0x195]], 'rolelevel': s7ubo[B[0x196]], 'price': s7ubo[B[0x197]], 'extension': JSON[B[0x1c]]({ 'cp_order_id': qwhmn0[B[0x190]] }) }, function (egj_, zwfdm) {
      s7ubo[B[0x18f]] && egj_ == 0x0 && s7ubo[B[0x18f]](qwhmn0[B[0x18e]], qwhmn0[B[0x190]], egj_);console[B[0x1]](JSON[B[0x1c]]({ 'type': B[0x198], 'status': egj_, 'data': qwhmn0, 'role_name': s7ubo[B[0x195]] }));if (egj_ === 0x0) {} else {
        if (egj_ === 0x1) {} else {
          if (egj_ === 0x2) {}
        }
      }
    });
  } else {
    var t57yb = qwhmn0 ? B[0x199] + qwhmn0[B[0x18d]] + B[0x19a] + qwhmn0[B[0xeb]] + B[0x19b] + qwhmn0[B[0x1]] : B[0x19c];window[B[0xf8]](0xd, B[0x19d] + t57yb), alert(t57yb);
  }
}, window[B[0x19e]] = function () {}, window[B[0x19f]] = function (fmh0w, nwmz, wm9f, qna_h, iub7s5) {
  z_he[B[0x1a0]](z07L[B[0x18]][B[0x19]], z07L[B[0x18]][B[0x165]] || z07L[B[0x18]][B[0x19]], fmh0w, nwmz, wm9f), sendApi(z07L[B[0xb5]], B[0x1a1], { 'game_pkg': z07L[B[0x17]], 'server_id': z07L[B[0x18]][B[0x19]], 'role_id': fmh0w, 'uid': z07L[B[0x14]], 'role_name': nwmz, 'role_type': qna_h, 'level': wm9f });
}, window[B[0x1a2]] = function (_0qhan, _qg, osujgr, zdmw, a0nhm, _eor, f0wzhm, urojis, v2ty$, neg_qa) {
  z07L[B[0x11]] = _0qhan, z07L[B[0x12]] = _qg, z07L[B[0x13]] = osujgr, z_he[B[0x1a3]](z07L[B[0x18]][B[0x19]], z07L[B[0x18]][B[0x165]] || z07L[B[0x18]][B[0x19]], _0qhan, _qg, osujgr), sendApi(z07L[B[0xb5]], B[0x1a4], { 'game_pkg': z07L[B[0x17]], 'server_id': z07L[B[0x18]][B[0x19]], 'role_id': _0qhan, 'uid': z07L[B[0x14]], 'role_name': _qg, 'role_type': zdmw, 'level': osujgr, 'evolution': a0nhm });
}, window[B[0x1a5]] = function (qnam0, aq_0n, z0wf9, jeaq_g, y5i7, ib27y, gojru, jag_qe, z9fdw, riu7) {
  z07L[B[0x11]] = qnam0, z07L[B[0x12]] = aq_0n, z07L[B[0x13]] = z0wf9, z_he[B[0x1a6]](z07L[B[0x18]][B[0x19]], z07L[B[0x18]][B[0x165]] || z07L[B[0x18]][B[0x19]], qnam0, aq_0n, z0wf9), sendApi(z07L[B[0xb5]], B[0x1a4], { 'game_pkg': z07L[B[0x17]], 'server_id': z07L[B[0x18]][B[0x19]], 'role_id': qnam0, 'uid': z07L[B[0x14]], 'role_name': aq_0n, 'role_type': jeaq_g, 'level': z0wf9, 'evolution': y5i7 });
}, window[B[0x1a7]] = function (fd3z) {}, window[B[0x1a8]] = function (s5iu7b) {
  z_he[B[0x1a9]](B[0x1a9], function (zh0fwm) {
    s5iu7b && s5iu7b(zh0fwm);
  });
}, window[B[0x1aa]] = function () {
  z_he[B[0x1aa]]();
}, window[B[0x1ab]] = function () {
  z_he[B[0x1ac]]();
}, window[B[0x1ad]] = function (_gjea, fmdz9, f0wzmh, ahn0qm, eqh_an, irso, ouib, f0mz) {
  f0mz = f0mz || z07L[B[0x18]][B[0x19]], sendApi(z07L[B[0xb5]], B[0x1ae], { 'phone': _gjea, 'role_id': fmdz9, 'uid': z07L[B[0x14]], 'game_pkg': z07L[B[0x17]], 'partner_id': z07L[B[0xbd]], 'server_id': f0mz }, ouib, 0x2, null, function () {
    return !![];
  });
}, window[B[0x97]] = function (roejsg) {
  window[B[0x99]] = roejsg, window[B[0x99]] && window[B[0x98]] && (console[B[0x1]](B[0x9a] + window[B[0x98]][B[0x9b]]), window[B[0x99]](window[B[0x98]]), window[B[0x98]] = null);
}, window[B[0x1af]] = function (aq_hn0, e_jqg, m0wfz, h0qmw) {
  window[B[0x1b0]](B[0x1b1], { 'game_pkg': window[B[0x10]][B[0x17]], 'role_id': e_jqg, 'server_id': m0wfz }, h0qmw);
}, window[B[0x1b2]] = function (x18k4p, $vyl2t, wz9m0f) {
  function zhwn(y5i2) {
    var zd9wm = [],
        _oegr = [],
        _aj = wz9m0f || window[B[0x6]][B[0x1b3]];for (var jq_a in _aj) {
      var jugosr = Number(jq_a);(!x18k4p || !x18k4p[B[0xa]] || x18k4p[B[0x79]](jugosr) != -0x1) && (_oegr[B[0x2c]](_aj[jq_a]), zd9wm[B[0x2c]]([jugosr, 0x3]));
    }window[B[0x29]](window[B[0x2d]], B[0x1b4]) >= 0x0 ? (console[B[0x2f]](B[0x1b5]), z_he[B[0x1b6]] && z_he[B[0x1b6]](_oegr, function (zwdf9m) {
      console[B[0x2f]](B[0x1b7]), console[B[0x2f]](zwdf9m);if (zwdf9m && zwdf9m[B[0x41]] == B[0x1b8]) for (var hean_ in _aj) {
        if (zwdf9m[_aj[hean_]] == B[0x1b9]) {
          var roje_ = Number(hean_);for (var _geojr = 0x0; _geojr < zd9wm[B[0xa]]; _geojr++) {
            if (zd9wm[_geojr][0x0] == roje_) {
              zd9wm[_geojr][0x1] = 0x1;break;
            }
          }
        }
      }window[B[0x29]](window[B[0x2d]], B[0x1ba]) >= 0x0 ? wx[B[0x1bb]]({ 'withSubscriptions': !![], 'success': function (uojs) {
          var mzf90 = uojs[B[0x1bc]][B[0x1bd]];if (mzf90) {
            console[B[0x2f]](B[0x1be]), console[B[0x2f]](mzf90);for (var x36p in _aj) {
              if (mzf90[_aj[x36p]] == B[0x1b9]) {
                var y5l2 = Number(x36p);for (var rsujgo = 0x0; rsujgo < zd9wm[B[0xa]]; rsujgo++) {
                  if (zd9wm[rsujgo][0x0] == y5l2) {
                    zd9wm[rsujgo][0x1] = 0x2;break;
                  }
                }
              }
            }console[B[0x2f]](zd9wm), $vyl2t && $vyl2t(zd9wm);
          } else console[B[0x2f]](B[0x1bf]), console[B[0x2f]](uojs), console[B[0x2f]](zd9wm), $vyl2t && $vyl2t(zd9wm);
        }, 'fail': function () {
          console[B[0x2f]](B[0x1c0]), console[B[0x2f]](zd9wm), $vyl2t && $vyl2t(zd9wm);
        } }) : (console[B[0x2f]](B[0x1c1] + window[B[0x2d]]), console[B[0x2f]](zd9wm), $vyl2t && $vyl2t(zd9wm));
    })) : (console[B[0x2f]](B[0x1c2] + window[B[0x2d]]), console[B[0x2f]](zd9wm), $vyl2t && $vyl2t(zd9wm)), wx[B[0x1c3]](zhwn);
  }wx[B[0x1c4]](zhwn);
}, window[B[0x1c5]] = { 'isSuccess': ![], 'level': B[0x1c6], 'isCharging': ![] }, window[B[0x1c7]] = function (sroje) {
  wx[B[0x8b]]({ 'success': function (aehq_n) {
      var qmah0 = window[B[0x1c5]];qmah0[B[0x1c8]] = !![], qmah0[B[0x8d]] = Number(aehq_n[B[0x8d]])[B[0x1c9]](0x0), qmah0[B[0x8f]] = aehq_n[B[0x8f]], sroje && sroje(qmah0[B[0x1c8]], qmah0[B[0x8d]], qmah0[B[0x8f]]);
    }, 'fail': function (w9dfmz) {
      console[B[0x2f]](B[0x1ca], w9dfmz[B[0x41]]);var t75by2 = window[B[0x1c5]];sroje && sroje(t75by2[B[0x1c8]], t75by2[B[0x8d]], t75by2[B[0x8f]]);
    } });
}, window[B[0x90]] = function (ehqna) {
  wx[B[0x90]]({ 'success': function (ous7b) {
      ehqna && ehqna(!![], ous7b);
    }, 'fail': function (bus7oi) {
      ehqna && ehqna(![], bus7oi);
    } });
}, window[B[0x94]] = function (wzfmh0) {
  if (wzfmh0) wx[B[0x94]](wzfmh0);
}, window[B[0x1cb]] = function (by5u7i) {
  wx[B[0x1cb]](by5u7i);
}, window[B[0x1b0]] = function (erajg, _eqg, $lt25, uy7i, v2lyt, qne_g, _h0anq, urs7o) {
  if (uy7i == undefined) uy7i = 0x1;wx[B[0x106]]({ 'url': erajg, 'method': _h0anq || B[0x1cc], 'responseType': B[0x1cd], 'data': _eqg, 'header': { 'content-type': urs7o || B[0x108] }, 'success': function (d96zf3) {
      DEBUG && console[B[0x2f]](B[0x1ce], erajg, info, d96zf3);if (d96zf3 && d96zf3[B[0x1cf]] == 0xc8) {
        var g_neq = d96zf3[B[0xea]];!qne_g || qne_g(g_neq) ? $lt25 && $lt25(g_neq) : window[B[0x1d0]](erajg, _eqg, $lt25, uy7i, v2lyt, qne_g, d96zf3);
      } else window[B[0x1d0]](erajg, _eqg, $lt25, uy7i, v2lyt, qne_g, d96zf3);
    }, 'fail': function (osgjer) {
      DEBUG && console[B[0x2f]](B[0x1d1], erajg, info, osgjer), window[B[0x1d0]](erajg, _eqg, $lt25, uy7i, v2lyt, qne_g, osgjer);
    }, 'complete': function () {} });
}, window[B[0x1d0]] = function (is7obu, x1p648, nh0wqm, q0hn_, e_ngaq, p183x, ujisr) {
  q0hn_ - 0x1 > 0x0 ? setTimeout(function () {
    window[B[0x1b0]](is7obu, x1p648, nh0wqm, q0hn_ - 0x1, e_ngaq, p183x);
  }, 0x3e8) : e_ngaq && e_ngaq(JSON[B[0x1c]]({ 'url': is7obu, 'response': ujisr }));
}, window[B[0x1d2]] = function (zfw9d3, rosgju, w9mfz, eo_rgj, ham, iu5y7, hnq0ma) {
  !w9mfz && (w9mfz = {});var $5l2y = Math[B[0x1d3]](Date[B[0xa0]]() / 0x3e8);w9mfz[B[0x14b]] = $5l2y, w9mfz[B[0x1d4]] = rosgju;var oejgr_ = Object[B[0x1d5]](w9mfz)[B[0x1d6]](),
      q_jge = '',
      nqae_h = '';for (var egjro = 0x0; egjro < oejgr_[B[0xa]]; egjro++) {
    q_jge = q_jge + (egjro == 0x0 ? '' : '&') + oejgr_[egjro] + w9mfz[oejgr_[egjro]], nqae_h = nqae_h + (egjro == 0x0 ? '' : '&') + oejgr_[egjro] + '=' + encodeURIComponent(w9mfz[oejgr_[egjro]]);
  }q_jge = q_jge + z07L[B[0xbb]];var ojsir = B[0x1d7] + md5(q_jge);send(zfw9d3 + '?' + nqae_h + (nqae_h == '' ? '' : '&') + ojsir, null, eo_rgj, ham, iu5y7, hnq0ma || function (rjego_) {
    return rjego_[B[0xeb]] == B[0x143];
  }, null, B[0x1d8]);
}, window[B[0x1d9]] = function (aqnm0, kx8p41) {
  var qh_ea = 0x0;z07L[B[0x18]] && (qh_ea = z07L[B[0x18]][B[0x19]]), sendApi(z07L[B[0xb7]], B[0x1da], { 'partnerId': z07L[B[0xbd]], 'gamePkg': z07L[B[0x17]], 'logTime': Math[B[0x1d3]](Date[B[0xa0]]() / 0x3e8), 'platformUid': z07L[B[0x147]], 'type': aqnm0, 'serverId': qh_ea }, null, 0x2, null, function () {
    return !![];
  });
}, window[B[0x1db]] = function (qahn_e) {
  sendApi(z07L[B[0xb5]], B[0x1dc], { 'partner_id': z07L[B[0xbd]], 'uid': z07L[B[0x14]], 'version': z07L[B[0x5d]], 'game_pkg': z07L[B[0x17]], 'device': z07L[B[0xbe]] }, z07LGY, z0GL7, z0LY);
}, window[B[0x1dd]] = function (iyu7b) {
  if (iyu7b && iyu7b[B[0xeb]] === B[0x143] && iyu7b[B[0xea]]) {
    iyu7b[B[0xea]][B[0x1de]]({ 'id': -0x2, 'name': B[0x1df] }), iyu7b[B[0xea]][B[0x1de]]({ 'id': -0x1, 'name': B[0x1e0] }), z07L[B[0x1e1]] = iyu7b[B[0xea]];if (window[B[0x1e2]]) window[B[0x1e2]][B[0x1e3]]();
  } else {
    z07L[B[0x1e4]] = ![];var v2$tl = iyu7b ? iyu7b[B[0xeb]] : '';window[B[0xf8]](0x7, B[0x1e5] + v2$tl), window[B[0xdc]](B[0x1e6] + v2$tl);
  }
}, window[B[0x1e7]] = function (e_rgaj) {
  sendApi(z07L[B[0xb5]], B[0x1e8], { 'partner_id': z07L[B[0xbd]], 'uid': z07L[B[0x14]], 'version': z07L[B[0x5d]], 'game_pkg': z07L[B[0x17]], 'device': z07L[B[0xbe]] }, z0Y7G, z0GL7, z0LY);
}, window[B[0x1e9]] = function (h_nqa) {
  z07L[B[0x1ea]] = ![];if (h_nqa && h_nqa[B[0xeb]] === B[0x143] && h_nqa[B[0xea]]) {
    for (var _q0anh = 0x0; _q0anh < h_nqa[B[0xea]][B[0xa]]; _q0anh++) {
      h_nqa[B[0xea]][_q0anh][B[0x16e]] = z07GY(h_nqa[B[0xea]][_q0anh]);
    }z07L[B[0xc0]][-0x1] = window[B[0x1eb]](h_nqa[B[0xea]]), window[B[0x1e2]][B[0x1ec]](-0x1);
  } else {
    var rogujs = h_nqa ? h_nqa[B[0xeb]] : '';window[B[0xf8]](0x8, B[0x1ed] + rogujs), window[B[0xdc]](B[0x1ee] + rogujs);
  }
}, window[B[0x1ef]] = function (by25$) {
  sendApi(z07L[B[0xb5]], B[0x1e8], { 'partner_id': z07L[B[0xbd]], 'uid': z07L[B[0x14]], 'version': z07L[B[0x5d]], 'game_pkg': z07L[B[0x17]], 'device': z07L[B[0xbe]] }, by25$, z0GL7, z0LY);
}, window[B[0x1f0]] = function (fmwh0, bui5s) {
  sendApi(z07L[B[0xb5]], B[0x1f1], { 'partner_id': z07L[B[0xbd]], 'uid': z07L[B[0x14]], 'version': z07L[B[0x5d]], 'game_pkg': z07L[B[0x17]], 'device': z07L[B[0xbe]], 'server_group_id': bui5s }, z0G7Y, z0GL7, z0LY);
}, window[B[0x1f2]] = function (r7isu) {
  z07L[B[0x1ea]] = ![];if (r7isu && r7isu[B[0xeb]] === B[0x143] && r7isu[B[0xea]] && r7isu[B[0xea]][B[0xea]]) {
    var hz0fmw = r7isu[B[0xea]][B[0x1f3]],
        iby572 = [];for (var f90w = 0x0; f90w < r7isu[B[0xea]][B[0xea]][B[0xa]]; f90w++) {
      r7isu[B[0xea]][B[0xea]][f90w][B[0x16e]] = z07GY(r7isu[B[0xea]][B[0xea]][f90w]), (iby572[B[0xa]] == 0x0 || r7isu[B[0xea]][B[0xea]][f90w][B[0x16e]] != 0x0) && (iby572[iby572[B[0xa]]] = r7isu[B[0xea]][B[0xea]][f90w]);
    }z07L[B[0xc0]][hz0fmw] = window[B[0x1eb]](iby572), window[B[0x1e2]][B[0x1ec]](hz0fmw);
  } else {
    var qhm0w = r7isu ? r7isu[B[0xeb]] : '';window[B[0xf8]](0x9, B[0x1f4] + qhm0w), window[B[0xdc]](B[0x1f5] + qhm0w);
  }
}, window[B[0x1f6]] = function (gjq_e) {
  sendApi(z07L[B[0xb5]], B[0x1f7], { 'partner_id': z07L[B[0xbd]], 'uid': z07L[B[0x14]], 'version': z07L[B[0x5d]], 'game_pkg': z07L[B[0x17]], 'device': z07L[B[0xbe]] }, reqServerRecommendCallBack, z0GL7, z0LY);
}, window[B[0x1f8]] = function (arej) {
  z07L[B[0x1ea]] = ![];if (arej && arej[B[0xeb]] === B[0x143] && arej[B[0xea]]) {
    for (var s75ub = 0x0; s75ub < arej[B[0xea]][B[0xa]]; s75ub++) {
      arej[B[0xea]][s75ub][B[0x16e]] = z07GY(arej[B[0xea]][s75ub]);
    }z07L[B[0xc0]][-0x2] = window[B[0x1eb]](arej[B[0xea]]), window[B[0x1e2]][B[0x1ec]](-0x2);
  } else {
    var b2t7 = arej ? arej[B[0xeb]] : '';window[B[0xf8]](0xa, B[0x1f9] + b2t7), alert(B[0x1fa] + b2t7);
  }
}, window[B[0x1eb]] = function (riojsu) {
  return riojsu;
}, window[B[0x1fb]] = function (obsi7u, i5b7yu) {
  obsi7u = obsi7u || z07L[B[0x18]][B[0x19]], sendApi(z07L[B[0xb5]], B[0x1fc], { 'type': '4', 'game_pkg': z07L[B[0x17]], 'server_id': obsi7u }, i5b7yu);
}, window[B[0x1fd]] = function (h0wnqm, ha_0qn, aq_ne, uy57ib) {
  aq_ne = aq_ne || z07L[B[0x18]][B[0x19]], sendApi(z07L[B[0xb5]], B[0x1fe], { 'type': h0wnqm, 'game_pkg': ha_0qn, 'server_id': aq_ne }, uy57ib);
}, window[B[0x1ff]] = function (_goerj, wd3z) {
  sendApi(z07L[B[0xb5]], B[0x200], { 'game_pkg': _goerj }, wd3z);
}, window[B[0x201]] = function (ly5$2t) {
  if (ly5$2t) {
    if (ly5$2t[B[0x16e]] == 0x1) {
      if (ly5$2t[B[0x202]] == 0x1) return 0x2;else return 0x1;
    } else return ly5$2t[B[0x16e]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window[B[0x203]] = function (_ageqn, t52ly$) {
  var t5yl2$ = window[B[0x16a]][B[0x16d]] == 0x1;if (t5yl2$) {
    var qange = window[B[0x16a]][B[0x175]],
        t5yl2$ = window[B[0x16a]][B[0x16d]] == 0x1;window[B[0x25]][B[0x26]][B[0x176]](B[0x177], qange, B[0x178]);return;
  }z07L[B[0x204]] = { 'step': _ageqn, 'server_id': t52ly$ };var ly$v = this;z0Y7GL({ 'title': B[0x205] }), sendApi(z07L[B[0xb5]], B[0x206], { 'partner_id': z07L[B[0xbd]], 'uid': z07L[B[0x14]], 'game_pkg': z07L[B[0x17]], 'server_id': t52ly$, 'platform': z07L[B[0x61]], 'platform_uid': z07L[B[0x147]], 'check_login_time': z07L[B[0x14a]], 'check_login_sign': z07L[B[0x148]], 'version_name': z07L[B[0x123]] }, z0LY7G, z0GL7, z0LY, function (df3169) {
    return df3169[B[0xeb]] == B[0x143] || df3169[B[0x1]] == B[0x207] || df3169[B[0x1]] == B[0x208];
  });
}, window[B[0x209]] = function (boui7) {
  var eojrg = this;if (boui7 && boui7[B[0xeb]] === B[0x143] && boui7[B[0xea]]) {
    var m0qwhn = z07L[B[0x18]];m0qwhn[B[0x20a]] = z07L[B[0xc1]], m0qwhn[B[0x149]] = String(boui7[B[0xea]][B[0x20b]]), m0qwhn[B[0xc7]] = parseInt(boui7[B[0xea]][B[0x14b]]);if (boui7[B[0xea]][B[0x20c]]) m0qwhn[B[0x20c]] = parseInt(boui7[B[0xea]][B[0x20c]]);else m0qwhn[B[0x20c]] = parseInt(boui7[B[0xea]][B[0x19]]);m0qwhn[B[0x20d]] = 0x0, m0qwhn[B[0x16]] = z07L[B[0x182]], m0qwhn[B[0x20e]] = boui7[B[0xea]][B[0x20f]], m0qwhn[B[0x210]] = boui7[B[0xea]][B[0x210]];if (boui7[B[0xea]][B[0x211]]) m0qwhn[B[0x211]] = parseInt(boui7[B[0xea]][B[0x211]]);console[B[0x2f]](B[0x212] + JSON[B[0x1c]](m0qwhn[B[0x210]])), z07L[B[0x163]] == 0x1 && m0qwhn[B[0x210]] && m0qwhn[B[0x210]][B[0x213]] == 0x1 && (z07L[B[0x214]] = 0x1, window[B[0x25]][B[0x26]][B[0x215]]()), z0LGY7();
  } else {
    if (z07L[B[0x204]][B[0x216]] >= 0x3) {
      var mha = boui7 ? boui7[B[0xeb]] : '';window[B[0xf8]](0xc, B[0x217] + mha), z0LY(JSON[B[0x1c]](boui7)), window[B[0xdc]](B[0x218] + mha);
    } else sendApi(z07L[B[0xb5]], B[0x132], { 'platform': z07L[B[0xb3]], 'partner_id': z07L[B[0xbd]], 'token': z07L[B[0x130]], 'game_pkg': z07L[B[0x17]], 'deviceId': z07L[B[0xbe]], 'scene': B[0x133] + z07L[B[0xbf]] }, function (iuo7sr) {
      if (!iuo7sr || iuo7sr[B[0xeb]] != B[0x143]) {
        window[B[0xdc]](B[0x145] + iuo7sr && iuo7sr[B[0xeb]]);return;
      }z07L[B[0x148]] = String(iuo7sr[B[0x149]]), z07L[B[0x14a]] = String(iuo7sr[B[0x14b]]), setTimeout(function () {
        z0LYG7(z07L[B[0x204]][B[0x216]] + 0x1, z07L[B[0x204]][B[0x19]]);
      }, 0x5dc);
    }, z0GL7, z0LY, function (nq0wmh) {
      return nq0wmh[B[0xeb]] == B[0x143] || nq0wmh[B[0xeb]] == B[0x219];
    });
  }
}, window[B[0x21a]] = function () {
  ServerLoading[B[0x26]][B[0x173]](z07L[B[0x163]]), window[B[0xce]] = !![], window[B[0x45]]();
}, window[B[0x44]] = function () {
  if (window[B[0x43]] && window[B[0x4c]] && window[B[0xcf]] && window[B[0xd0]] && window[B[0xd1]] && window[B[0xd3]]) {
    if (!window[B[0x21b]][B[0x26]]) {
      console[B[0x2f]](B[0x21c] + window[B[0x21b]][B[0x26]]);var m9z0wf = wx[B[0x21d]](),
          b2t$5 = m9z0wf[B[0x9b]] ? m9z0wf[B[0x9b]] : 0x0,
          $yl2t5 = { 'cdn': window[B[0x10]][B[0x16]], 'spareCdn': window[B[0x10]][B[0x121]], 'newRegister': window[B[0x10]][B[0x163]], 'wxPC': window[B[0x10]][B[0x7e]], 'wxIOS': window[B[0x10]][B[0x78]], 'wxAndroid': window[B[0x10]][B[0x7b]], 'wxParam': { 'limitLoad': window[B[0x10]][B[0x82]], 'benchmarkLevel': window[B[0x10]][B[0x83]], 'wxFrom': window[B[0x6]][B[0x128]] == B[0x21e] ? 0x1 : 0x0, 'wxSDKVersion': window[B[0x2d]] }, 'configType': window[B[0x10]][B[0xc8]], 'exposeType': window[B[0x10]][B[0xca]], 'scene': b2t$5 };new window[B[0x21b]]($yl2t5, window[B[0x10]][B[0x15]], window[B[0xad]]);
    }
  }
}, window[B[0x45]] = function () {
  if (window[B[0x43]] && window[B[0x4c]] && window[B[0xcf]] && window[B[0xd0]] && window[B[0xd1]] && window[B[0xd3]] && window[B[0xce]] && window[B[0xd2]]) {
    z0Y7LG();if (!z0LG7) {
      z0LG7 = !![];if (!window[B[0x21b]][B[0x26]]) window[B[0x44]]();var x6183d = 0x0,
          jsruio = wx[B[0x21f]]();jsruio && (window[B[0x10]][B[0x7d]] && (x6183d = jsruio[B[0x73]]), console[B[0x1]](B[0x220] + jsruio[B[0x73]] + B[0x221] + jsruio[B[0x74]] + B[0x222] + jsruio[B[0x75]] + B[0x223] + jsruio[B[0x76]] + B[0x224] + jsruio[B[0x225]] + B[0x226] + jsruio[B[0x227]]));var f9dzm = {};for (const dzwmf9 in z07L[B[0x18]]) {
        f9dzm[dzwmf9] = z07L[B[0x18]][dzwmf9];
      }var jeqga_ = { 'channel': window[B[0x10]][B[0xc2]], 'account': window[B[0x10]][B[0x14]], 'userId': window[B[0x10]][B[0x146]], 'cdn': window[B[0x10]][B[0x16]], 'data': window[B[0x10]][B[0xea]], 'package': window[B[0x10]][B[0xb1]], 'newRegister': window[B[0x10]][B[0x163]], 'pkgName': window[B[0x10]][B[0x17]], 'partnerId': window[B[0x10]][B[0xbd]], 'platform_uid': window[B[0x10]][B[0x147]], 'deviceId': window[B[0x10]][B[0xbe]], 'selectedServer': f9dzm, 'configType': window[B[0x10]][B[0xc8]], 'exposeType': window[B[0x10]][B[0xca]], 'debugUsers': window[B[0x10]][B[0xc5]], 'wxMenuTop': x6183d, 'wxShield': window[B[0x10]][B[0xcc]] };if (window[B[0x185]]) for (var tvl2$y in window[B[0x185]]) {
        jeqga_[tvl2$y] = window[B[0x185]][tvl2$y];
      }window[B[0x21b]][B[0x26]][B[0x228]](jeqga_);if (z07L[B[0x18]] && z07L[B[0x18]][B[0x19]]) localStorage[B[0x229]](B[0x14e] + z07L[B[0x17]] + z07L[B[0x14]], z07L[B[0x18]][B[0x19]]);
    }
  } else console[B[0x1]](B[0x22a] + window[B[0x43]] + B[0x22b] + window[B[0x4c]] + B[0x22c] + window[B[0xcf]] + B[0x22d] + window[B[0xd0]] + B[0x22e] + window[B[0xd1]] + B[0x22f] + window[B[0xd3]] + B[0x230] + window[B[0xce]] + B[0x231] + window[B[0xd2]]);
};