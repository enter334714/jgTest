var B = wx.$z;
import 'Z11main.js';