var B = wx.$z;
require(B[0x0]);