var u = wx.$x;
import 'xxMAIx.js';