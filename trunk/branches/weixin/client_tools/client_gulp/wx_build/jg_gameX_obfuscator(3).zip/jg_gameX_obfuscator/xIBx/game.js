var u = wx.$x;
require(u[400000]);