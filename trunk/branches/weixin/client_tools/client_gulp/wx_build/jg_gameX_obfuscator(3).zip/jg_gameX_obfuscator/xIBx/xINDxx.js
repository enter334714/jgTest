var u = wx.$x;
import xjvcudn from '../xxaxxx/x7xx.js';window[u[400001]] = { 'wxVersion': window[u[400002]][u[400003]] }, window[u[400004]] = ![], window['x196'] = 0x1, window[u[400005]] = 0x1, window['x1J69'] = !![], window[u[400006]] = !![], window['x1T$J69'] = '', window['x169'] = { 'base_cdn': u[400007], 'cdn': u[400007] }, x169[u[400008]] = {}, x169[u[400009]] = '0', x169[u[400010]] = window[u[400001]][u[400011]], x169[u[400012]] = '', x169['os'] = '1', x169[u[400013]] = u[400014], x169[u[400015]] = u[400016], x169[u[400017]] = u[400018], x169[u[400019]] = u[400020], x169[u[400021]] = u[400022], x169[u[400023]] = '1', x169[u[400024]] = '', x169[u[400025]] = '', x169[u[400026]] = 0x0, x169[u[400027]] = {}, x169[u[400028]] = parseInt(x169[u[400023]]), x169[u[400029]] = x169[u[400023]], x169[u[400030]] = {}, x169['x1$6'] = u[400031], x169[u[400032]] = ![], x169[u[400033]] = u[400034], x169[u[400035]] = Date[u[400036]](), x169[u[400037]] = u[400038], x169[u[400039]] = '_a', x169[u[400040]] = 0x2, x169[u[400041]] = 0x7c1, x169[u[400011]] = window[u[400001]][u[400011]], x169[u[400042]] = ![], x169[u[400043]] = ![], x169[u[400044]] = ![], x169[u[400045]] = ![], window['x1J96'] = 0x5, window['x1J9'] = ![], window['x19J'] = ![], window['x16J9'] = ![], window[u[400046]] = ![], window[u[400047]] = ![], window['x169J'] = ![], window['x1J6'] = ![], window['x16J'] = ![], window['x19J6'] = ![], window[u[400048]] = function (k1bw0) {
  console[u[400049]](u[400048], k1bw0), wx[u[400050]]({}), wx[u[400051]]({ 'title': u[400052], 'content': k1bw0, 'success'(ae_qhp) {
      if (ae_qhp[u[400053]]) console[u[400049]](u[400054]);else ae_qhp[u[400055]] && console[u[400049]](u[400056]);
    } });
}, window['x1$J69'] = function (w0ek1) {
  console[u[400049]](u[400057], w0ek1), x1$69J(), wx[u[400051]]({ 'title': u[400052], 'content': w0ek1, 'confirmText': u[400058], 'cancelText': u[400059], 'success'(njugd) {
      if (njugd[u[400053]]) window['x16$']();else njugd[u[400055]] && (console[u[400049]](u[400060]), wx[u[400061]]({}));
    } });
}, window['x16T'] = function (vgdi4u) {
  console[u[400049]](u[400062], vgdi4u), wx[u[400051]]({ 'title': u[400052], 'content': vgdi4u, 'confirmText': u[400063], 'showCancel': ![], 'complete'(f9nu) {
      console[u[400049]](u[400060]), wx[u[400061]]({});
    } });
}, window['x1$J96'] = ![], window['x1$6J9'] = function (uvdncj) {
  window['x1$J96'] = !![], wx[u[400064]](uvdncj);
}, window['x1$69J'] = function () {
  window['x1$J96'] && (window['x1$J96'] = ![], wx[u[400050]]({}));
}, window['x1$9J6'] = function (mg4xs) {
  window[u[400065]][u[400066]]['x1$9J6'](mg4xs);
}, window[u[400067]] = function (cnfju9, f7cl9j) {
  xjvcudn[u[400067]](cnfju9, function (he0qpa) {
    he0qpa && he0qpa[u[400068]] ? he0qpa[u[400068]][u[400069]] == 0x1 ? f7cl9j(!![]) : (f7cl9j(![]), console[u[400070]](u[400071] + he0qpa[u[400068]][u[400072]])) : console[u[400049]](u[400067], he0qpa);
  });
}, window['x1$96J'] = function (njf9u) {
  console[u[400049]](u[400073], njf9u);
}, window['x1$69'] = function (aebhp) {}, window['x1$96'] = function (w3t6k1, mso4xi, x5soz) {}, window['x1$9'] = function (zxosi) {
  console[u[400049]](u[400074], zxosi), window[u[400065]][u[400066]][u[400075]](), window[u[400065]][u[400066]][u[400076]](), window[u[400065]][u[400066]][u[400077]]();
}, window['x19$'] = function (p0qeha) {
  window['x1$J69'](u[400078]);var moxsi4 = { 'id': window['x169'][u[400079]], 'role': window['x169'][u[400080]], 'level': window['x169'][u[400081]], 'account': window['x169'][u[400082]], 'version': window['x169'][u[400041]], 'cdn': window['x169'][u[400083]], 'pkgName': window['x169'][u[400024]], 'gamever': window[u[400002]][u[400003]], 'serverid': window['x169'][u[400030]] ? window['x169'][u[400030]][u[400084]] : 0x0, 'systemInfo': window[u[400085]], 'error': u[400086], 'stack': p0qeha ? p0qeha : u[400078] },
      szomix = JSON[u[400087]](moxsi4);console[u[400088]](u[400089] + szomix), window['x1$6'](szomix);
}, window['x16$9'] = function (d4ug) {
  var oms4x = JSON[u[400090]](d4ug);oms4x[u[400091]] = window[u[400002]][u[400003]], oms4x[u[400092]] = window['x169'][u[400030]] ? window['x169'][u[400030]][u[400084]] : 0x0, oms4x[u[400085]] = window[u[400085]];var bhep0a = JSON[u[400087]](oms4x);console[u[400088]](u[400093] + bhep0a), window['x1$6'](bhep0a);
}, window['x169$'] = function (kh0epb, w03bk) {
  var b1ew0 = { 'id': window['x169'][u[400079]], 'role': window['x169'][u[400080]], 'level': window['x169'][u[400081]], 'account': window['x169'][u[400082]], 'version': window['x169'][u[400041]], 'cdn': window['x169'][u[400083]], 'pkgName': window['x169'][u[400024]], 'gamever': window[u[400002]][u[400003]], 'serverid': window['x169'][u[400030]] ? window['x169'][u[400030]][u[400084]] : 0x0, 'systemInfo': window[u[400085]], 'error': kh0epb, 'stack': w03bk },
      b13 = JSON[u[400087]](b1ew0);console[u[400094]](u[400095] + b13), window['x1$6'](b13);
}, window['x1$6'] = function (j9nclf) {
  if (window['x169'][u[400096]] == u[400097]) return;var ng4vd = x169['x1$6'] + u[400098] + x169[u[400082]];wx[u[400099]]({ 'url': ng4vd, 'method': u[400100], 'data': j9nclf, 'header': { 'content-type': u[400101], 'cache-control': u[400102] }, 'success': function (s25m) {
      DEBUG && console[u[400049]](u[400103], ng4vd, j9nclf, s25m);
    }, 'fail': function (isdg4x) {
      DEBUG && console[u[400049]](u[400103], ng4vd, j9nclf, isdg4x);
    }, 'complete': function () {} });
}, window[u[400104]] = function () {
  function giudv() {
    return ((0x1 + Math[u[400105]]()) * 0x10000 | 0x0)[u[400106]](0x10)[u[400107]](0x1);
  }return giudv() + giudv() + '-' + giudv() + '-' + giudv() + '-' + giudv() + '+' + giudv() + giudv() + giudv();
}, window['x16$'] = function () {
  console[u[400049]](u[400108]);var he0pba = xjvcudn[u[400109]]();x169[u[400029]] = he0pba[u[400110]], x169[u[400028]] = he0pba[u[400110]], x169[u[400023]] = he0pba[u[400110]], x169[u[400024]] = he0pba[u[400111]];var p0hbek = { 'game_ver': x169[u[400010]] };x169[u[400025]] = this[u[400104]](), x1$6J9({ 'title': u[400112] }), xjvcudn[u[400113]](p0hbek, this['x19$6'][u[400114]](this));
}, window['x19$6'] = function (aqrh) {
  var pra_ = aqrh[u[400115]];console[u[400049]](u[400116] + pra_ + u[400117] + (pra_ == 0x1) + u[400118] + aqrh[u[400003]] + u[400119] + window[u[400001]][u[400011]]);if (!aqrh[u[400003]] || window['x1TJ9$6'](window[u[400001]][u[400011]], aqrh[u[400003]]) < 0x0) console[u[400049]](u[400120]), x169[u[400015]] = u[400121], x169[u[400017]] = u[400122], x169[u[400019]] = u[400123], x169[u[400083]] = u[400124], x169[u[400125]] = u[400126], x169[u[400127]] = 'xc', x169[u[400042]] = ![];else window['x1TJ9$6'](window[u[400001]][u[400011]], aqrh[u[400003]]) == 0x0 ? (console[u[400049]](u[400128]), x169[u[400015]] = u[400016], x169[u[400017]] = u[400018], x169[u[400019]] = u[400020], x169[u[400083]] = u[400129], x169[u[400125]] = u[400126], x169[u[400127]] = u[400130], x169[u[400042]] = !![]) : (console[u[400049]](u[400131]), x169[u[400015]] = u[400016], x169[u[400017]] = u[400018], x169[u[400019]] = u[400020], x169[u[400083]] = u[400129], x169[u[400125]] = u[400126], x169[u[400127]] = u[400130], x169[u[400042]] = ![]);x169[u[400026]] = config[u[400132]] ? config[u[400132]] : 0x0, this['x1J6$9'](), this['x1J69$'](), window[u[400133]] = 0x5, x1$6J9({ 'title': u[400134] }), xjvcudn[u[400135]](this['x196$'][u[400114]](this));
}, window[u[400133]] = 0x5, window['x196$'] = function (m25oz, gdu4vn) {
  if (m25oz == 0x0 && gdu4vn && gdu4vn[u[400136]]) {
    x169[u[400137]] = gdu4vn[u[400136]];var lnf9c = this;x1$6J9({ 'title': u[400138] }), sendApi(x169[u[400015]], u[400139], { 'platform': x169[u[400013]], 'partner_id': x169[u[400023]], 'token': gdu4vn[u[400136]], 'game_pkg': x169[u[400024]], 'deviceId': x169[u[400025]], 'scene': u[400140] + x169[u[400026]] }, this['x1J$69'][u[400114]](this), x1J96, x19$);
  } else gdu4vn && gdu4vn[u[400141]] && window[u[400133]] > 0x0 && (gdu4vn[u[400141]][u[400142]](u[400143]) != -0x1 || gdu4vn[u[400141]][u[400142]](u[400144]) != -0x1 || gdu4vn[u[400141]][u[400142]](u[400145]) != -0x1 || gdu4vn[u[400141]][u[400142]](u[400146]) != -0x1 || gdu4vn[u[400141]][u[400142]](u[400147]) != -0x1 || gdu4vn[u[400141]][u[400142]](u[400148]) != -0x1) ? (window[u[400133]]--, xjvcudn[u[400135]](this['x196$'][u[400114]](this))) : (window['x169$'](u[400149], JSON[u[400087]]({ 'status': m25oz, 'data': gdu4vn })), window['x1$J69'](u[400150] + (gdu4vn && gdu4vn[u[400141]] ? '，' + gdu4vn[u[400141]] : '')));
}, window['x1J$69'] = function (nl9fj) {
  if (!nl9fj) {
    window['x169$'](u[400151], u[400152]), window['x1$J69'](u[400153]);return;
  }if (nl9fj[u[400069]] != u[400154]) {
    window['x169$'](u[400151], JSON[u[400087]](nl9fj)), window['x1$J69'](u[400155] + nl9fj[u[400069]]);return;
  }x169[u[400156]] = String(nl9fj[u[400082]]), x169[u[400082]] = String(nl9fj[u[400082]]), x169[u[400157]] = String(nl9fj[u[400157]]), x169[u[400029]] = String(nl9fj[u[400157]]), x169[u[400158]] = String(nl9fj[u[400158]]), x169[u[400159]] = String(nl9fj[u[400160]]), x169[u[400161]] = String(nl9fj[u[400162]]), x169[u[400160]] = '';var l8y$ = this;x1$6J9({ 'title': u[400163] }), sendApi(x169[u[400015]], u[400164], { 'partner_id': x169[u[400023]], 'uid': x169[u[400082]], 'version': x169[u[400010]], 'game_pkg': x169[u[400024]], 'device': x169[u[400025]] }, l8y$['x1J$96'][u[400114]](l8y$), x1J96, x19$);
}, window['x1J$96'] = function (_rqpha) {
  if (!_rqpha) {
    window['x1$J69'](u[400165]);return;
  }if (_rqpha[u[400069]] != u[400154]) {
    window['x1$J69'](u[400166] + _rqpha[u[400069]]);return;
  }if (!_rqpha[u[400068]] || _rqpha[u[400068]][u[400167]] == 0x0) {
    window['x1$J69'](u[400168]);return;
  }x169[u[400169]] = _rqpha[u[400170]], x169[u[400030]] = { 'server_id': String(_rqpha[u[400068]][0x0][u[400084]]), 'server_name': String(_rqpha[u[400068]][0x0][u[400171]]), 'entry_ip': _rqpha[u[400068]][0x0][u[400172]], 'entry_port': parseInt(_rqpha[u[400068]][0x0][u[400173]]), 'status': x16J$(_rqpha[u[400068]][0x0]), 'start_time': _rqpha[u[400068]][0x0][u[400174]], 'cdn': x169[u[400083]] }, this['x196J$']();
}, window['x196J$'] = function () {
  if (x169[u[400169]] == 0x1) {
    var xsz = x169[u[400030]][u[400175]];if (xsz === -0x1 || xsz === 0x0) {
      window['x1$J69'](xsz === -0x1 ? u[400176] : u[400177]);return;
    }x19$J6(0x0, x169[u[400030]][u[400084]]), window[u[400065]][u[400066]][u[400178]](x169[u[400169]]);
  } else window[u[400065]][u[400066]][u[400179]](), x1$69J();window['x16J'] = !![], window['x19J6$'](), window['x196$J']();
}, window['x1J6$9'] = function () {
  sendApi(x169[u[400015]], u[400180], { 'game_pkg': x169[u[400024]], 'version_name': x169[u[400127]] }, this[u[400181]][u[400114]](this), x1J96, x19$);
}, window[u[400181]] = function (lcjnf9) {
  if (!lcjnf9) {
    window['x1$J69'](u[400182]);return;
  }if (lcjnf9[u[400069]] != u[400154]) {
    window['x1$J69'](u[400183] + lcjnf9[u[400069]]);return;
  }if (!lcjnf9[u[400068]] || !lcjnf9[u[400068]][u[400010]]) {
    window['x1$J69'](u[400184] + (lcjnf9[u[400068]] && lcjnf9[u[400068]][u[400010]]));return;
  }lcjnf9[u[400068]][u[400185]] && lcjnf9[u[400068]][u[400185]][u[400167]] > 0xa && (x169[u[400186]] = lcjnf9[u[400068]][u[400185]], x169[u[400083]] = lcjnf9[u[400068]][u[400185]]), lcjnf9[u[400068]][u[400010]] && (x169[u[400041]] = lcjnf9[u[400068]][u[400010]]), console[u[400070]](u[400187] + x169[u[400041]] + u[400188] + x169[u[400127]]), window['x169J'] = !![], window['x19J6$'](), window['x196$J']();
}, window[u[400189]], window['x1J69$'] = function () {
  sendApi(x169[u[400015]], u[400190], { 'game_pkg': x169[u[400024]] }, this['x1J9$6'][u[400114]](this), x1J96, x19$);
}, window['x1J9$6'] = function (vgi4xd) {
  if (vgi4xd[u[400069]] === u[400154] && vgi4xd[u[400068]]) {
    window[u[400189]] = vgi4xd[u[400068]];for (var fjucnv in vgi4xd[u[400068]]) {
      x169[fjucnv] = vgi4xd[u[400068]][fjucnv];
    }
  } else console[u[400070]](u[400191] + vgi4xd[u[400069]]);window['x1J6'] = !![], window['x196$J']();
}, window[u[400192]] = function (l7f89c, wtk1b3, t615, njudc, i4guvd, zmxso, zxiom, pabe0h, o625m) {
  i4guvd = String(i4guvd);var bw31k0 = zxiom,
      o4imxs = pabe0h;x169[u[400008]][i4guvd] = { 'productid': i4guvd, 'productname': bw31k0, 'productdesc': o4imxs, 'roleid': l7f89c, 'rolename': wtk1b3, 'rolelevel': t615, 'price': zmxso, 'callback': o625m }, sendApi(x169[u[400019]], u[400193], { 'game_pkg': x169[u[400024]], 'server_id': x169[u[400030]][u[400084]], 'server_name': x169[u[400030]][u[400171]], 'level': t615, 'uid': x169[u[400082]], 'role_id': l7f89c, 'role_name': wtk1b3, 'product_id': i4guvd, 'product_name': bw31k0, 'product_desc': o4imxs, 'money': zmxso, 'partner_id': x169[u[400023]] }, toPayCallBack, x1J96, x19$);
}, window[u[400194]] = function (lfc897) {
  if (lfc897) {
    if (lfc897[u[400195]] === 0xc8 || lfc897[u[400069]] == u[400154]) {
      var m25o6z = x169[u[400008]][String(lfc897[u[400196]])];if (m25o6z[u[400197]]) m25o6z[u[400197]](lfc897[u[400196]], lfc897[u[400198]], -0x1);xjvcudn[u[400199]]({ 'cpbill': lfc897[u[400198]], 'productid': lfc897[u[400196]], 'productname': m25o6z[u[400200]], 'productdesc': m25o6z[u[400201]], 'serverid': x169[u[400030]][u[400084]], 'servername': x169[u[400030]][u[400171]], 'roleid': m25o6z[u[400202]], 'rolename': m25o6z[u[400203]], 'rolelevel': m25o6z[u[400204]], 'price': m25o6z[u[400205]], 'extension': JSON[u[400087]]({ 'cp_order_id': lfc897[u[400198]] }) }, function (s2z5, l8fc9) {
        m25o6z[u[400197]] && s2z5 == 0x0 && m25o6z[u[400197]](lfc897[u[400196]], lfc897[u[400198]], s2z5);console[u[400070]](JSON[u[400087]]({ 'type': u[400206], 'status': s2z5, 'data': lfc897, 'role_name': m25o6z[u[400203]] }));if (s2z5 === 0x0) {} else {
          if (s2z5 === 0x1) {} else {
            if (s2z5 === 0x2) {}
          }
        }
      });
    } else alert(lfc897[u[400070]]);
  }
}, window['x1J96$'] = function () {}, window['x1$J9'] = function (be0w1k, b01ekw, c9nfju, xio4ms, is4dg) {
  xjvcudn[u[400207]](x169[u[400030]][u[400084]], x169[u[400030]][u[400171]] || x169[u[400030]][u[400084]], be0w1k, b01ekw, c9nfju), sendApi(x169[u[400015]], u[400208], { 'game_pkg': x169[u[400024]], 'server_id': x169[u[400030]][u[400084]], 'role_id': be0w1k, 'uid': x169[u[400082]], 'role_name': b01ekw, 'role_type': xio4ms, 'level': c9nfju });
}, window['x1$9J'] = function (f7l89, jnug, uvndg4, smoxi, xsig4m, c98lf7, $8ly7, s4idxg, os4mix, prhqa) {
  x169[u[400079]] = f7l89, x169[u[400080]] = jnug, x169[u[400081]] = uvndg4, xjvcudn[u[400209]](x169[u[400030]][u[400084]], x169[u[400030]][u[400171]] || x169[u[400030]][u[400084]], f7l89, jnug, uvndg4), sendApi(x169[u[400015]], u[400210], { 'game_pkg': x169[u[400024]], 'server_id': x169[u[400030]][u[400084]], 'role_id': f7l89, 'uid': x169[u[400082]], 'role_name': jnug, 'role_type': smoxi, 'level': uvndg4, 'evolution': xsig4m });
}, window['x1J$9'] = function (l7jc, y8l$79, uvgdn4, m5zsx, ehpbk, t16, d4sigx, _phqra, oxsm5z, l$98y7) {
  x169[u[400079]] = l7jc, x169[u[400080]] = y8l$79, x169[u[400081]] = uvgdn4, xjvcudn[u[400211]](x169[u[400030]][u[400084]], x169[u[400030]][u[400171]] || x169[u[400030]][u[400084]], l7jc, y8l$79, uvgdn4), sendApi(x169[u[400015]], u[400210], { 'game_pkg': x169[u[400024]], 'server_id': x169[u[400030]][u[400084]], 'role_id': l7jc, 'uid': x169[u[400082]], 'role_name': y8l$79, 'role_type': m5zsx, 'level': uvgdn4, 'evolution': ehpbk });
}, window['x1J9$'] = function ($l98y7) {}, window['x1$J'] = function (viudg4) {
  xjvcudn[u[400212]](u[400212], function (njgv) {
    viudg4 && viudg4(njgv);
  });
}, window[u[400213]] = function () {
  xjvcudn[u[400213]]();
}, window[u[400214]] = function () {
  xjvcudn[u[400215]]();
}, window[u[400216]] = function (k16w3t) {
  window['x19$J'] = k16w3t, window['x19$J'] && window['x1J$'] && (console[u[400070]](u[400217] + window['x1J$'][u[400218]]), window['x19$J'](window['x1J$']), window['x1J$'] = null);
}, window['x19J$'] = function (msoz5x, xz5os, a_hqr, kbw103) {
  window[u[400219]](u[400220], { 'game_pkg': window['x169'][u[400024]], 'role_id': xz5os, 'server_id': a_hqr }, kbw103);
}, window['x16$J9'] = function (vjnd, jnuvdg) {
  function s2m5zo(o2sz5m) {
    var qap_r = [],
        m5xzso = [],
        cf9l8 = window[u[400002]][u[400221]];for (var zmso25 in cf9l8) {
      var njcf9u = Number(zmso25);(!vjnd || !vjnd[u[400167]] || vjnd[u[400142]](njcf9u) != -0x1) && (m5xzso[u[400222]](cf9l8[zmso25]), qap_r[u[400222]]([njcf9u, 0x3]));
    }window['x1TJ9$6'](window[u[400223]], u[400224]) >= 0x0 ? (console[u[400049]](u[400225]), xjvcudn[u[400226]] && xjvcudn[u[400226]](m5xzso, function (o5m62) {
      console[u[400049]](u[400227]), console[u[400049]](o5m62);if (o5m62 && o5m62[u[400141]] == u[400228]) for (var w1ebk0 in cf9l8) {
        if (o5m62[cf9l8[w1ebk0]] == u[400229]) {
          var mx4igs = Number(w1ebk0);for (var vjcfn = 0x0; vjcfn < qap_r[u[400167]]; vjcfn++) {
            if (qap_r[vjcfn][0x0] == mx4igs) {
              qap_r[vjcfn][0x1] = 0x1;break;
            }
          }
        }
      }window['x1TJ9$6'](window[u[400223]], u[400230]) >= 0x0 ? wx[u[400231]]({ 'withSubscriptions': !![], 'success': function (jnuvcf) {
          var fucjv = jnuvcf[u[400232]][u[400233]];if (fucjv) {
            console[u[400049]](u[400234]), console[u[400049]](fucjv);for (var wkt1b3 in cf9l8) {
              if (fucjv[cf9l8[wkt1b3]] == u[400229]) {
                var t16w3k = Number(wkt1b3);for (var uvjf = 0x0; uvjf < qap_r[u[400167]]; uvjf++) {
                  if (qap_r[uvjf][0x0] == t16w3k) {
                    qap_r[uvjf][0x1] = 0x2;break;
                  }
                }
              }
            }console[u[400049]](qap_r), jnuvdg && jnuvdg(qap_r);
          } else console[u[400049]](u[400235]), console[u[400049]](jnuvcf), console[u[400049]](qap_r), jnuvdg && jnuvdg(qap_r);
        }, 'fail': function () {
          console[u[400049]](u[400236]), console[u[400049]](qap_r), jnuvdg && jnuvdg(qap_r);
        } }) : (console[u[400049]](u[400237] + window[u[400223]]), console[u[400049]](qap_r), jnuvdg && jnuvdg(qap_r));
    })) : (console[u[400049]](u[400238] + window[u[400223]]), console[u[400049]](qap_r), jnuvdg && jnuvdg(qap_r)), wx[u[400239]](s2m5zo);
  }wx[u[400240]](s2m5zo);
}, window['x16$9J'] = { 'isSuccess': ![], 'level': u[400241], 'isCharging': ![] }, window['x16J$9'] = function (mxs5zo) {
  wx[u[400242]]({ 'success': function (pbaeh) {
      var j9cfun = window['x16$9J'];j9cfun[u[400243]] = !![], j9cfun[u[400244]] = Number(pbaeh[u[400244]])[u[400245]](0x0), j9cfun[u[400246]] = pbaeh[u[400246]], mxs5zo && mxs5zo(j9cfun[u[400243]], j9cfun[u[400244]], j9cfun[u[400246]]);
    }, 'fail': function (mz56o) {
      console[u[400049]](u[400247], mz56o[u[400141]]);var f978cl = window['x16$9J'];mxs5zo && mxs5zo(f978cl[u[400243]], f978cl[u[400244]], f978cl[u[400246]]);
    } });
}, window[u[400219]] = function (pb0ha, gu, bpahe0, peha0q, qe_ha, pqahe, z6mo5, omzs5) {
  if (peha0q == undefined) peha0q = 0x1;wx[u[400099]]({ 'url': pb0ha, 'method': z6mo5 || u[400248], 'responseType': u[400249], 'data': gu, 'header': { 'content-type': omzs5 || u[400101] }, 'success': function (hepb0a) {
      DEBUG && console[u[400049]](u[400250], pb0ha, info, hepb0a);if (hepb0a && hepb0a[u[400251]] == 0xc8) {
        var jclnf = hepb0a[u[400068]];!pqahe || pqahe(jclnf) ? bpahe0 && bpahe0(jclnf) : window[u[400252]](pb0ha, gu, bpahe0, peha0q, qe_ha, pqahe, hepb0a);
      } else window[u[400252]](pb0ha, gu, bpahe0, peha0q, qe_ha, pqahe, hepb0a);
    }, 'fail': function (_pqaeh) {
      DEBUG && console[u[400049]](u[400253], pb0ha, info, _pqaeh), window[u[400252]](pb0ha, gu, bpahe0, peha0q, qe_ha, pqahe, _pqaeh);
    }, 'complete': function () {} });
}, window[u[400252]] = function (f9unjc, ju9ncf, uncvjf, bk0peh, gunjv, oxiszm, aqe0h) {
  bk0peh - 0x1 > 0x0 ? setTimeout(function () {
    window[u[400219]](f9unjc, ju9ncf, uncvjf, bk0peh - 0x1, gunjv, oxiszm);
  }, 0x3e8) : gunjv && gunjv(JSON[u[400087]]({ 'url': f9unjc, 'response': aqe0h }));
}, window[u[400254]] = function (t5231, we10bk, $l, ds4xig, t12w, arqp_, l98y) {
  !$l && ($l = {});var jugndv = Math[u[400255]](Date[u[400036]]() / 0x3e8);$l[u[400162]] = jugndv, $l[u[400256]] = we10bk;var ndvug4 = Object[u[400257]]($l)[u[400258]](),
      t5zo6 = '',
      hwbe0 = '';for (var qae_ph = 0x0; qae_ph < ndvug4[u[400167]]; qae_ph++) {
    t5zo6 = t5zo6 + (qae_ph == 0x0 ? '' : '&') + ndvug4[qae_ph] + $l[ndvug4[qae_ph]], hwbe0 = hwbe0 + (qae_ph == 0x0 ? '' : '&') + ndvug4[qae_ph] + '=' + encodeURIComponent($l[ndvug4[qae_ph]]);
  }t5zo6 = t5zo6 + x169[u[400021]];var xmszi = u[400259] + md5(t5zo6);send(t5231 + '?' + hwbe0 + (hwbe0 == '' ? '' : '&') + xmszi, null, ds4xig, t12w, arqp_, l98y || function (ktb3) {
    return ktb3[u[400069]] == u[400154];
  }, null, u[400260]);
}, window['x16J9$'] = function (cnlj9f, smgix) {
  var s5ozmx = 0x0;x169[u[400030]] && (s5ozmx = x169[u[400030]][u[400084]]), sendApi(x169[u[400017]], u[400261], { 'partnerId': x169[u[400023]], 'gamePkg': x169[u[400024]], 'logTime': Math[u[400255]](Date[u[400036]]() / 0x3e8), 'platformUid': x169[u[400158]], 'type': cnlj9f, 'serverId': s5ozmx }, null, 0x2, null, function () {
    return !![];
  });
}, window['x169$J'] = function (szx5mo) {
  sendApi(x169[u[400015]], u[400262], { 'partner_id': x169[u[400023]], 'uid': x169[u[400082]], 'version': x169[u[400010]], 'game_pkg': x169[u[400024]], 'device': x169[u[400025]] }, x169J$, x1J96, x19$);
}, window['x169J$'] = function (ucfnvj) {
  if (ucfnvj[u[400069]] === u[400154] && ucfnvj[u[400068]]) {
    ucfnvj[u[400068]][u[400263]]({ 'id': -0x2, 'name': u[400264] }), ucfnvj[u[400068]][u[400263]]({ 'id': -0x1, 'name': u[400265] }), x169[u[400266]] = ucfnvj[u[400068]];if (window[u[400267]]) window[u[400267]][u[400268]]();
  } else x169[u[400269]] = ![], window['x1$J69'](u[400270] + ucfnvj[u[400069]]);
}, window['x1$J6'] = function (ah0epb) {
  sendApi(x169[u[400015]], u[400271], { 'partner_id': x169[u[400023]], 'uid': x169[u[400082]], 'version': x169[u[400010]], 'game_pkg': x169[u[400024]], 'device': x169[u[400025]] }, x1$6J, x1J96, x19$);
}, window['x1$6J'] = function (cufn) {
  x169[u[400272]] = ![];if (cufn[u[400069]] === u[400154] && cufn[u[400068]]) {
    for (var n9fuj = 0x0; n9fuj < cufn[u[400068]][u[400167]]; n9fuj++) {
      cufn[u[400068]][n9fuj][u[400175]] = x16J$(cufn[u[400068]][n9fuj]);
    }x169[u[400027]][-0x1] = window[u[400273]](cufn[u[400068]]), window[u[400267]][u[400274]](-0x1);
  } else window['x1$J69'](u[400275] + cufn[u[400069]]);
}, window[u[400276]] = function (bkhe0p) {
  sendApi(x169[u[400015]], u[400271], { 'partner_id': x169[u[400023]], 'uid': x169[u[400082]], 'version': x169[u[400010]], 'game_pkg': x169[u[400024]], 'device': x169[u[400025]] }, bkhe0p, x1J96, x19$);
}, window['x1J$6'] = function (_qha, fnj9cl) {
  sendApi(x169[u[400015]], u[400277], { 'partner_id': x169[u[400023]], 'uid': x169[u[400082]], 'version': x169[u[400010]], 'game_pkg': x169[u[400024]], 'device': x169[u[400025]], 'server_group_id': fnj9cl }, x1J6$, x1J96, x19$);
}, window['x1J6$'] = function (juvdn) {
  x169[u[400272]] = ![];if (juvdn[u[400069]] === u[400154] && juvdn[u[400068]] && juvdn[u[400068]][u[400068]]) {
    var k61t = juvdn[u[400068]][u[400278]],
        he0bpa = [];for (var gdn4u = 0x0; gdn4u < juvdn[u[400068]][u[400068]][u[400167]]; gdn4u++) {
      juvdn[u[400068]][u[400068]][gdn4u][u[400175]] = x16J$(juvdn[u[400068]][u[400068]][gdn4u]), (he0bpa[u[400167]] == 0x0 || juvdn[u[400068]][u[400068]][gdn4u][u[400175]] != 0x0) && (he0bpa[he0bpa[u[400167]]] = juvdn[u[400068]][u[400068]][gdn4u]);
    }x169[u[400027]][k61t] = window[u[400273]](he0bpa), window[u[400267]][u[400274]](k61t);
  } else window['x1$J69'](u[400279] + juvdn[u[400069]]);
}, window['x1TJ96'] = function (dujgvn) {
  sendApi(x169[u[400015]], u[400280], { 'partner_id': x169[u[400023]], 'uid': x169[u[400082]], 'version': x169[u[400010]], 'game_pkg': x169[u[400024]], 'device': x169[u[400025]] }, reqServerRecommendCallBack, x1J96, x19$);
}, window[u[400281]] = function (udngj) {
  x169[u[400272]] = ![];if (udngj[u[400069]] === u[400154] && udngj[u[400068]]) {
    for (var y$97l8 = 0x0; y$97l8 < udngj[u[400068]][u[400167]]; y$97l8++) {
      udngj[u[400068]][y$97l8][u[400175]] = x16J$(udngj[u[400068]][y$97l8]);
    }x169[u[400027]][-0x2] = window[u[400273]](udngj[u[400068]]), window[u[400267]][u[400274]](-0x2);
  } else alert(u[400282] + udngj[u[400069]]);
}, window[u[400273]] = function (s4gmx) {
  if (!s4gmx && s4gmx[u[400167]] <= 0x0) return s4gmx;for (let izsxom = 0x0; izsxom < s4gmx[u[400167]]; izsxom++) {
    s4gmx[izsxom][u[400283]] && s4gmx[izsxom][u[400283]] == 0x1 && (s4gmx[izsxom][u[400171]] += u[400284]);
  }return s4gmx;
}, window['x16$J'] = function (ndgvju, vg4idu) {
  ndgvju = ndgvju || x169[u[400030]][u[400084]], sendApi(x169[u[400015]], u[400285], { 'type': '4', 'game_pkg': x169[u[400024]], 'server_id': ndgvju }, vg4idu);
}, window[u[400286]] = function (k0bhew, he0bkw, eq_p, gv4ndu) {
  eq_p = eq_p || x169[u[400030]][u[400084]], sendApi(x169[u[400015]], u[400287], { 'type': k0bhew, 'game_pkg': he0bkw, 'server_id': eq_p }, gv4ndu);
}, window['x16J$'] = function (u4nv) {
  if (u4nv) {
    if (u4nv[u[400175]] == 0x1) {
      if (u4nv[u[400288]] == 0x1) return 0x2;else return 0x1;
    } else return u4nv[u[400175]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['x19$J6'] = function (vg4dxi, kt613w) {
  x169[u[400289]] = { 'step': vg4dxi, 'server_id': kt613w };var qh_ar = this;x1$6J9({ 'title': u[400290] }), sendApi(x169[u[400015]], u[400291], { 'partner_id': x169[u[400023]], 'uid': x169[u[400082]], 'game_pkg': x169[u[400024]], 'server_id': kt613w, 'platform': x169[u[400157]], 'platform_uid': x169[u[400158]], 'check_login_time': x169[u[400161]], 'check_login_sign': x169[u[400159]], 'version_name': x169[u[400127]] }, x19$6J, x1J96, x19$, function (isxmg) {
    return isxmg[u[400069]] == u[400154] || isxmg[u[400070]] == u[400292] || isxmg[u[400070]] == u[400293];
  });
}, window['x19$6J'] = function (szix) {
  var ox = this;if (szix[u[400069]] === u[400154] && szix[u[400068]]) {
    var idv = x169[u[400030]];idv[u[400294]] = x169[u[400028]], idv[u[400160]] = String(szix[u[400068]][u[400295]]), idv[u[400035]] = parseInt(szix[u[400068]][u[400162]]);if (szix[u[400068]][u[400296]]) idv[u[400296]] = parseInt(szix[u[400068]][u[400296]]);else idv[u[400296]] = parseInt(szix[u[400068]][u[400084]]);idv[u[400297]] = 0x0, idv[u[400083]] = x169[u[400186]], idv[u[400298]] = szix[u[400068]][u[400299]], idv[u[400300]] = szix[u[400068]][u[400300]], console[u[400049]](u[400301] + JSON[u[400087]](idv[u[400300]])), x169[u[400169]] == 0x1 && idv[u[400300]] && idv[u[400300]][u[400302]] == 0x1 && (x169[u[400303]] = 0x1, window[u[400065]][u[400066]]['x1T96']()), x19J$6();
  } else x169[u[400289]][u[400304]] >= 0x3 ? (x19$(JSON[u[400087]](szix)), window['x1$J69'](u[400305] + szix[u[400069]])) : sendApi(x169[u[400015]], u[400139], { 'platform': x169[u[400013]], 'partner_id': x169[u[400023]], 'token': x169[u[400137]], 'game_pkg': x169[u[400024]], 'deviceId': x169[u[400025]], 'scene': u[400140] + x169[u[400026]] }, function (bt13k) {
    if (!bt13k || bt13k[u[400069]] != u[400154]) {
      window['x1$J69'](u[400155] + bt13k && bt13k[u[400069]]);return;
    }x169[u[400159]] = String(bt13k[u[400160]]), x169[u[400161]] = String(bt13k[u[400162]]), setTimeout(function () {
      x19$J6(x169[u[400289]][u[400304]] + 0x1, x169[u[400289]][u[400084]]);
    }, 0x5dc);
  }, x1J96, x19$, function (z253t6) {
    return z253t6[u[400069]] == u[400154] || z253t6[u[400069]] == u[400306];
  });
}, window['x19J$6'] = function () {
  ServerLoading[u[400066]][u[400178]](x169[u[400169]]), window['x1J9'] = !![], window['x196$J']();
}, window['x19J6$'] = function () {
  if (window['x19J'] && window['x16J9'] && window[u[400046]] && window[u[400047]] && window['x169J'] && window['x16J']) {
    if (!window[u[400307]][u[400066]]) {
      console[u[400049]](u[400308] + window[u[400307]][u[400066]]);var arhpq = wx[u[400309]](),
          gdu4 = arhpq[u[400218]] ? arhpq[u[400218]] : 0x0,
          hkb0e = { 'cdn': window['x169'][u[400083]], 'spareCdn': window['x169'][u[400125]], 'newRegister': window['x169'][u[400169]], 'wxPC': window['x169'][u[400045]], 'wxIOS': window['x169'][u[400043]], 'wxAndroid': window['x169'][u[400044]], 'wxParam': { 'limitLoad': window['x169']['x1T$J96'], 'benchmarkLevel': window['x169']['x1T$6J9'], 'wxFrom': window[u[400002]][u[400132]] == u[400310] ? 0x1 : 0x0, 'wxSDKVersion': window[u[400223]] }, 'configType': window['x169'][u[400037]], 'exposeType': window['x169'][u[400039]], 'scene': gdu4 };new window[u[400307]](hkb0e, window['x169'][u[400041]], window['x1T$J69']);
    }
  }
}, window['x196$J'] = function () {
  if (window['x19J'] && window['x16J9'] && window[u[400046]] && window[u[400047]] && window['x169J'] && window['x16J'] && window['x1J9'] && window['x1J6']) {
    x1$69J();if (!x19J6) {
      x19J6 = !![];if (!window[u[400307]][u[400066]]) window['x19J6$']();var u9jcf = 0x0,
          si4xmo = wx[u[400311]]();si4xmo && (window['x169'][u[400312]] && (u9jcf = si4xmo[u[400313]]), console[u[400070]](u[400314] + si4xmo[u[400313]] + u[400315] + si4xmo[u[400316]] + u[400317] + si4xmo[u[400318]] + u[400319] + si4xmo[u[400320]] + u[400321] + si4xmo[u[400322]] + u[400323] + si4xmo[u[400324]]));var ekw0b1 = {};for (const i4om in x169[u[400030]]) {
        ekw0b1[i4om] = x169[u[400030]][i4om];
      }var cnjd = { 'channel': window['x169'][u[400029]], 'account': window['x169'][u[400082]], 'userId': window['x169'][u[400156]], 'cdn': window['x169'][u[400083]], 'data': window['x169'][u[400068]], 'package': window['x169'][u[400009]], 'newRegister': window['x169'][u[400169]], 'pkgName': window['x169'][u[400024]], 'partnerId': window['x169'][u[400023]], 'platform_uid': window['x169'][u[400158]], 'deviceId': window['x169'][u[400025]], 'selectedServer': ekw0b1, 'configType': window['x169'][u[400037]], 'exposeType': window['x169'][u[400039]], 'debugUsers': window['x169'][u[400033]], 'wxMenuTop': u9jcf, 'wxShield': window['x169'][u[400042]] };if (window[u[400189]]) for (var f9l7y8 in window[u[400189]]) {
        cnjd[f9l7y8] = window[u[400189]][f9l7y8];
      }window[u[400307]][u[400066]]['x1JT69'](cnjd);
    }
  } else console[u[400070]](u[400325] + window['x19J'] + u[400326] + window['x16J9'] + u[400327] + window[u[400046]] + u[400328] + window[u[400047]] + u[400329] + window['x169J'] + u[400330] + window['x16J'] + u[400331] + window['x1J9'] + u[400332] + window['x1J6']);
};