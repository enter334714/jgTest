var u = wx.$x;
console[u[400070]](u[400333]), window[u[400334]], wx[u[400335]](function (hq0pa) {
  if (hq0pa) {
    if (hq0pa[u[400336]]) {
      var kw6 = window[u[400002]][u[400003]][u[400337]](new RegExp(/\./, 'g'), '_'),
          k16wt = hq0pa[u[400336]],
          qpha = k16wt[u[400338]](/(xxxxxxxxx\/xxGAMEx.js:)[0-9]{1,60}(:)/g);if (qpha) for (var dvnjc = 0x0; dvnjc < qpha[u[400167]]; dvnjc++) {
        if (qpha[dvnjc] && qpha[dvnjc][u[400167]] > 0x0) {
          var whb0ke = parseInt(qpha[dvnjc][u[400337]](u[400339], '')[u[400337]](':', ''));k16wt = k16wt[u[400337]](qpha[dvnjc], qpha[dvnjc][u[400337]](':' + whb0ke + ':', ':' + (whb0ke - 0x2) + ':'));
        }
      }k16wt = k16wt[u[400337]](new RegExp(u[400340], 'g'), u[400341] + kw6 + u[400342]), k16wt = k16wt[u[400337]](new RegExp(u[400343], 'g'), u[400341] + kw6 + u[400342]), hq0pa[u[400336]] = k16wt;
    }var mgs = { 'id': window['x169'][u[400079]], 'role': window['x169'][u[400080]], 'level': window['x169'][u[400081]], 'user': window['x169'][u[400082]], 'version': window['x169'][u[400041]], 'cdn': window['x169'][u[400083]], 'pkgName': window['x169'][u[400024]], 'gamever': window[u[400002]][u[400003]], 'serverid': window['x169'][u[400030]] ? window['x169'][u[400030]][u[400084]] : 0x0, 'systemInfo': window[u[400085]], 'error': u[400344], 'stack': hq0pa ? hq0pa[u[400336]] : '' },
        ugdnjv = JSON[u[400087]](mgs);console[u[400088]](u[400345] + ugdnjv), (!window[u[400334]] || window[u[400334]] != mgs[u[400088]]) && (window[u[400334]] = mgs[u[400088]], window['x1$6'](mgs));
  }
});import 'xxfxx.js';import 'xx11xx.js';window[u[400346]] = require(u[400347]);import 'xINDxx.js';import 'xxIB1xx.js';import 'xxMtadxx.js';import 'xxINIxxx.js';console[u[400070]](u[400348]), console[u[400070]](u[400349]), x1$6J9({ 'title': u[400350] });var xjncvuf = { 'x1T$96J': !![] };new window[u[400065]](xjncvuf), window[u[400065]][u[400066]]['x1TJ69$']();if (window['x1T$69J']) clearInterval(window['x1T$69J']);window['x1T$69J'] = null, window['x1TJ9$6'] = function (z325t, gxdi) {
  if (!z325t || !gxdi) return 0x0;z325t = z325t[u[400351]]('.'), gxdi = gxdi[u[400351]]('.');const vcnf = Math[u[400352]](z325t[u[400167]], gxdi[u[400167]]);while (z325t[u[400167]] < vcnf) {
    z325t[u[400222]]('0');
  }while (gxdi[u[400167]] < vcnf) {
    gxdi[u[400222]]('0');
  }for (var dngjv = 0x0; dngjv < vcnf; dngjv++) {
    const uv4g = parseInt(z325t[dngjv]),
          jfl9cn = parseInt(gxdi[dngjv]);if (uv4g > jfl9cn) return 0x1;else {
      if (uv4g < jfl9cn) return -0x1;
    }
  }return 0x0;
}, window[u[400223]] = wx[u[400353]]()[u[400223]], console[u[400049]](u[400354] + window[u[400223]]);var xo5xszm = wx[u[400355]]();xo5xszm[u[400356]](function (e0khw) {
  console[u[400049]](u[400357] + e0khw[u[400358]]);
}), xo5xszm[u[400359]](function () {
  wx[u[400051]]({ 'title': u[400360], 'content': u[400361], 'showCancel': ![], 'success': function (zm) {
      xo5xszm[u[400362]]();
    } });
}), xo5xszm[u[400363]](function () {
  console[u[400049]](u[400364]);
}), window['x1TJ96$'] = function () {
  console[u[400049]](u[400365]);var smzixo = wx[u[400366]]({ 'name': u[400367], 'success': function (ah_rp) {
      console[u[400049]](u[400368]), console[u[400049]](ah_rp), ah_rp && ah_rp[u[400141]] == u[400369] ? (window['x19J'] = !![], window['x19J6$'](), window['x196$J']()) : setTimeout(function () {
        window['x1TJ96$']();
      }, 0x1f4);
    }, 'fail': function (gd4uiv) {
      console[u[400049]](u[400370]), console[u[400049]](gd4uiv), setTimeout(function () {
        window['x1TJ96$']();
      }, 0x1f4);
    } });smzixo && smzixo[u[400371]](vdnjcu => {});
}, window['x1T6$9J'] = function () {
  console[u[400049]](u[400372]);var udn4v = wx[u[400366]]({ 'name': u[400373], 'success': function (bhekp0) {
      console[u[400049]](u[400374]), console[u[400049]](bhekp0), bhekp0 && bhekp0[u[400141]] == u[400369] ? (window['x16J9'] = !![], window['x19J6$'](), window['x196$J']()) : setTimeout(function () {
        window['x1T6$9J']();
      }, 0x1f4);
    }, 'fail': function (vixd4) {
      console[u[400049]](u[400375]), console[u[400049]](vixd4), setTimeout(function () {
        window['x1T6$9J']();
      }, 0x1f4);
    } });udn4v && udn4v[u[400371]](fjcu9 => {});
}, window[u[400376]] = function () {
  window['x1TJ9$6'](window[u[400223]], u[400377]) >= 0x0 ? (console[u[400049]](u[400378] + window[u[400223]] + u[400379]), window['x16$'](), window['x1TJ96$'](), window['x1T6$9J']()) : (window['x169$'](u[400380], window[u[400223]]), wx[u[400051]]({ 'title': u[400052], 'content': u[400381] }));
}, window[u[400085]] = '', wx[u[400382]]({ 'success'(lfy897) {
    window[u[400085]] = u[400383] + lfy897[u[400384]] + u[400385] + lfy897[u[400386]] + u[400387] + lfy897[u[400010]] + u[400388] + lfy897[u[400389]] + u[400390] + lfy897[u[400157]] + u[400391] + lfy897[u[400223]] + u[400392] + lfy897[u[400393]], console[u[400049]](window[u[400085]]), console[u[400049]](u[400394] + lfy897[u[400395]] + u[400396] + lfy897[u[400397]] + u[400398] + lfy897[u[400399]] + u[400400] + lfy897[u[400401]] + u[400402] + lfy897[u[400403]] + u[400404] + lfy897[u[400405]] + u[400406] + (lfy897[u[400407]] ? lfy897[u[400407]][u[400313]] + ',' + lfy897[u[400407]][u[400316]] + ',' + lfy897[u[400407]][u[400318]] + ',' + lfy897[u[400407]][u[400320]] : ''));var k13w0b = lfy897[u[400389]] ? lfy897[u[400389]][u[400408]]() : '',
        p0hb = lfy897[u[400386]] ? lfy897[u[400386]][u[400408]]()[u[400337]]('\x20', '') : '';window['x169'][u[400043]] = k13w0b[u[400142]](u[400409]) != -0x1, window['x169'][u[400044]] = k13w0b[u[400142]](u[400410]) != -0x1, window['x169'][u[400312]] = k13w0b[u[400142]](u[400409]) != -0x1 || k13w0b[u[400142]](u[400410]) != -0x1, window['x169'][u[400045]] = k13w0b[u[400142]](u[400411]) != -0x1 || k13w0b[u[400142]](u[400012]) != -0x1, window['x169'][u[400096]] = lfy897[u[400157]] ? lfy897[u[400157]][u[400408]]() : '', window['x169']['x1T$J96'] = ![], window['x169']['x1T$6J9'] = 0x2;if (k13w0b[u[400142]](u[400410]) != -0x1) {
      if (lfy897[u[400393]] >= 0x18) window['x169']['x1T$6J9'] = 0x3;else window['x169']['x1T$6J9'] = 0x2;
    } else {
      if (k13w0b[u[400142]](u[400409]) != -0x1) {
        if (lfy897[u[400393]] && lfy897[u[400393]] >= 0x14) window['x169']['x1T$6J9'] = 0x3;else {
          if (p0hb[u[400142]](u[400412]) != -0x1 || p0hb[u[400142]](u[400413]) != -0x1 || p0hb[u[400142]](u[400414]) != -0x1 || p0hb[u[400142]](u[400415]) != -0x1 || p0hb[u[400142]](u[400416]) != -0x1) window['x169']['x1T$6J9'] = 0x2;else window['x169']['x1T$6J9'] = 0x3;
        }
      } else window['x169']['x1T$6J9'] = 0x2;
    }console[u[400049]](u[400417] + window['x169']['x1T$J96'] + u[400418] + window['x169']['x1T$6J9']);
  } }), wx[u[400242]]({ 'success': function (cuvfn) {
    console[u[400049]](u[400419] + cuvfn[u[400244]] + u[400420] + cuvfn[u[400246]]);
  } }), wx[u[400421]]({ 'success': function (cvjfun) {
    console[u[400049]](u[400422] + cvjfun[u[400423]]);
  } }), wx[u[400424]]({ 'keepScreenOn': !![] }), wx[u[400425]](function (jlc7f) {
  console[u[400049]](u[400422] + jlc7f[u[400423]] + u[400426] + jlc7f[u[400427]]);
}), wx[u[400216]](function (z2o65) {
  window['x1J$'] = z2o65, window['x19$J'] && window['x1J$'] && (console[u[400070]](u[400217] + window['x1J$'][u[400218]]), window['x19$J'](window['x1J$']), window['x1J$'] = null);
}), window[u[400428]] = 0x0, window['x1T6J9$'] = 0x0, window[u[400429]] = null, wx[u[400430]](function () {
  window['x1T6J9$']++;var c8f9 = Date[u[400036]]();(window[u[400428]] == 0x0 || c8f9 - window[u[400428]] > 0x1d4c0) && (console[u[400094]](u[400431]), wx[u[400432]]());if (window['x1T6J9$'] >= 0x2) {
    window['x1T6J9$'] = 0x0, console[u[400088]](u[400433]), wx[u[400434]]('0', 0x1);if (window['x169'] && window['x169'][u[400043]]) window['x169$'](u[400435], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});