var F = wx.$D;
import Dxqv6wk from '../d22d22basdd22/d225sdkd22.js';window[F[560562]] = { 'wxVersion': window[F[560005]][F[560006]] }, window[F[560563]] = ![], window['D142'] = 0x1, window[F[560564]] = 0x1, window['D1X24'] = !![], window[F[560565]] = !![], window['D1WIX24'] = '', window['D124'] = { 'base_cdn': F[560566], 'cdn': F[560566] }, D124[F[560567]] = {}, D124[F[560568]] = '0', D124[F[560078]] = window[F[560562]][F[560343]], D124[F[560113]] = '', D124['os'] = '1', D124[F[560569]] = F[560570], D124[F[560571]] = F[560572], D124[F[560573]] = F[560574], D124[F[560575]] = F[560576], D124[F[560577]] = F[560578], D124[F[560579]] = '1', D124[F[560396]] = '', D124[F[560580]] = '', D124[F[560581]] = 0x0, D124[F[560435]] = {}, D124[F[560582]] = parseInt(D124[F[560579]]), D124[F[560583]] = D124[F[560579]], D124[F[560021]] = {}, D124['D1I2'] = F[560584], D124[F[560585]] = ![], D124[F[560586]] = F[560587], D124[F[560588]] = Date[F[560284]](), D124[F[560589]] = F[560590], D124[F[560591]] = '_a', D124[F[560329]] = 0x2, D124[F[560019]] = 0x7c1, D124[F[560343]] = window[F[560562]][F[560343]], D124[F[560592]] = ![], D124[F[560105]] = ![], D124[F[560108]] = ![], D124[F[560111]] = ![], window['D1X42'] = 0x5, window['D1X4'] = ![], window['D14X'] = ![], window['D12X4'] = ![], window[F[560512]] = ![], window[F[560515]] = ![], window['D124X'] = ![], window['D1X2'] = ![], window['D12X'] = ![], window['D14X2'] = ![], window[F[560593]] = function (ces3u) {
  console[F[560040]](F[560593], ces3u), wx[F[560594]]({}), wx[F[560047]]({ 'title': F[560070], 'content': ces3u, 'success'(m5glo) {
      if (m5glo[F[560595]]) console[F[560040]](F[560596]);else m5glo[F[560597]] && console[F[560040]](F[560598]);
    } });
}, window['D1IX24'] = function (u3p9b) {
  console[F[560040]](F[560599], u3p9b), D1I24X(), wx[F[560047]]({ 'title': F[560070], 'content': u3p9b, 'confirmText': F[560600], 'cancelText': F[560601], 'success'(z_li) {
      if (z_li[F[560595]]) window['D12I']();else z_li[F[560597]] && (console[F[560040]](F[560602]), wx[F[560603]]({}));
    } });
}, window[F[560604]] = function (wqx6j) {
  console[F[560040]](F[560604], wqx6j), wx[F[560047]]({ 'title': F[560070], 'content': wqx6j, 'confirmText': F[560605], 'showCancel': ![], 'complete'(axg5mj) {
      console[F[560040]](F[560602]), wx[F[560603]]({});
    } });
}, window['D1IX42'] = ![], window['D1I2X4'] = function (h2z1ir) {
  window['D1IX42'] = !![], wx[F[560606]](h2z1ir);
}, window['D1I24X'] = function () {
  window['D1IX42'] && (window['D1IX42'] = ![], wx[F[560594]]({}));
}, window['D1I4X2'] = function (cet) {
  window[F[560033]][F[560034]]['D1I4X2'](cet);
}, window[F[560607]] = function (e0vst, gl_m5o) {
  Dxqv6wk[F[560607]](e0vst, function (lmog5) {
    lmog5 && lmog5[F[560445]] ? lmog5[F[560445]][F[560444]] == 0x1 ? gl_m5o(!![]) : (gl_m5o(![]), console[F[560000]](F[560608] + lmog5[F[560445]][F[560609]])) : console[F[560040]](F[560607], lmog5);
  });
}, window['D1I42X'] = function (y8n1h$) {
  console[F[560040]](F[560610], y8n1h$);
}, window['D1I24'] = function (xkag6) {}, window['D1I42'] = function (mg5loa, c03ub, hiz_r2) {}, window['D1I4'] = function (upbc9) {
  console[F[560040]](F[560611], upbc9), window[F[560033]][F[560034]][F[560333]](), window[F[560033]][F[560034]][F[560334]](), window[F[560033]][F[560034]][F[560347]]();
}, window['D14I'] = function (tqs0) {
  window['D1IX24'](F[560612]);var xqjwk6 = { 'id': window['D124'][F[560015]], 'role': window['D124'][F[560016]], 'level': window['D124'][F[560017]], 'account': window['D124'][F[560018]], 'version': window['D124'][F[560019]], 'cdn': window['D124'][F[560020]], 'pkgName': window['D124'][F[560396]], 'gamever': window[F[560005]][F[560006]], 'serverid': window['D124'][F[560021]] ? window['D124'][F[560021]][F[560022]] : 0x0, 'systemInfo': window[F[560023]], 'error': F[560613], 'stack': tqs0 ? tqs0 : F[560612] },
      xajw6 = JSON[F[560025]](xqjwk6);console[F[560026]](F[560614] + xajw6), window['D1I2'](xajw6);
}, window['D12I4'] = function (orz_li) {
  var oz_mi = JSON[F[560615]](orz_li);oz_mi[F[560616]] = window[F[560005]][F[560006]], oz_mi[F[560617]] = window['D124'][F[560021]] ? window['D124'][F[560021]][F[560022]] : 0x0, oz_mi[F[560023]] = window[F[560023]];var esv0t = JSON[F[560025]](oz_mi);console[F[560026]](F[560618] + esv0t), window['D1I2'](esv0t);
}, window['D124I'] = function (c30st, wvqxk6) {
  var j6kaxg = { 'id': window['D124'][F[560015]], 'role': window['D124'][F[560016]], 'level': window['D124'][F[560017]], 'account': window['D124'][F[560018]], 'version': window['D124'][F[560019]], 'cdn': window['D124'][F[560020]], 'pkgName': window['D124'][F[560396]], 'gamever': window[F[560005]][F[560006]], 'serverid': window['D124'][F[560021]] ? window['D124'][F[560021]][F[560022]] : 0x0, 'systemInfo': window[F[560023]], 'error': c30st, 'stack': wvqxk6 },
      ues0 = JSON[F[560025]](j6kaxg);console[F[560549]](F[560619] + ues0), window['D1I2'](ues0);
}, window['D1I2'] = function (l5om_) {
  if (window['D124'][F[560114]] == F[560620]) return;var iz_o = D124['D1I2'] + F[560621] + D124[F[560018]];wx[F[560622]]({ 'url': iz_o, 'method': F[560623], 'data': l5om_, 'header': { 'content-type': F[560624], 'cache-control': F[560625] }, 'success': function (ogajm5) {
      DEBUG && console[F[560040]](F[560626], iz_o, l5om_, ogajm5);
    }, 'fail': function (svtweq) {
      DEBUG && console[F[560040]](F[560626], iz_o, l5om_, svtweq);
    }, 'complete': function () {} });
}, window[F[560627]] = function () {
  function mjaog5() {
    return ((0x1 + Math[F[560336]]()) * 0x10000 | 0x0)[F[560628]](0x10)[F[560629]](0x1);
  }return mjaog5() + mjaog5() + '-' + mjaog5() + '-' + mjaog5() + '-' + mjaog5() + '+' + mjaog5() + mjaog5() + mjaog5();
}, window['D12I'] = function () {
  console[F[560040]](F[560630]);var vste0c = Dxqv6wk[F[560631]]();D124[F[560583]] = vste0c[F[560632]], D124[F[560582]] = vste0c[F[560632]], D124[F[560579]] = vste0c[F[560632]], D124[F[560396]] = vste0c[F[560633]];var wjxa = { 'game_ver': D124[F[560078]] };D124[F[560580]] = this[F[560627]](), D1I2X4({ 'title': F[560634] }), Dxqv6wk[F[560477]](wjxa, this['D14I2'][F[560340]](this));
}, window['D14I2'] = function (swtev) {
  var t3s0e = swtev[F[560635]];console[F[560040]](F[560636] + t3s0e + F[560637] + (t3s0e == 0x1) + F[560638] + swtev[F[560006]] + F[560639] + window[F[560562]][F[560343]]);if (!swtev[F[560006]] || window['D1WX4I2'](window[F[560562]][F[560343]], swtev[F[560006]]) < 0x0) console[F[560040]](F[560640]), D124[F[560571]] = F[560641], D124[F[560573]] = F[560642], D124[F[560575]] = F[560643], D124[F[560020]] = F[560644], D124[F[560645]] = F[560646], D124[F[560647]] = 'jh', D124[F[560592]] = ![];else window['D1WX4I2'](window[F[560562]][F[560343]], swtev[F[560006]]) == 0x0 ? (console[F[560040]](F[560648]), D124[F[560571]] = F[560572], D124[F[560573]] = F[560574], D124[F[560575]] = F[560576], D124[F[560020]] = F[560649], D124[F[560645]] = F[560646], D124[F[560647]] = F[560650], D124[F[560592]] = !![]) : (console[F[560040]](F[560651]), D124[F[560571]] = F[560572], D124[F[560573]] = F[560574], D124[F[560575]] = F[560576], D124[F[560020]] = F[560649], D124[F[560645]] = F[560646], D124[F[560647]] = F[560650], D124[F[560592]] = ![]);D124[F[560581]] = config[F[560652]] ? config[F[560652]] : 0x0, this['D1X2I4'](), this['D1X24I'](), window[F[560653]] = 0x5, D1I2X4({ 'title': F[560654] }), Dxqv6wk[F[560655]](this['D142I'][F[560340]](this));
}, window[F[560653]] = 0x5, window['D142I'] = function (tv6kw, cs3et0) {
  if (tv6kw == 0x0 && cs3et0 && cs3et0[F[560656]]) {
    D124[F[560657]] = cs3et0[F[560656]];var xamj5g = this;D1I2X4({ 'title': F[560658] }), sendApi(D124[F[560571]], F[560659], { 'platform': D124[F[560569]], 'partner_id': D124[F[560579]], 'token': cs3et0[F[560656]], 'game_pkg': D124[F[560396]], 'deviceId': D124[F[560580]], 'scene': F[560660] + D124[F[560581]] }, this['D1XI24'][F[560340]](this), D1X42, D14I);
  } else cs3et0 && cs3et0[F[560057]] && window[F[560653]] > 0x0 && (cs3et0[F[560057]][F[560106]](F[560661]) != -0x1 || cs3et0[F[560057]][F[560106]](F[560662]) != -0x1 || cs3et0[F[560057]][F[560106]](F[560663]) != -0x1 || cs3et0[F[560057]][F[560106]](F[560664]) != -0x1 || cs3et0[F[560057]][F[560106]](F[560665]) != -0x1 || cs3et0[F[560057]][F[560106]](F[560666]) != -0x1) ? (window[F[560653]]--, Dxqv6wk[F[560655]](this['D142I'][F[560340]](this))) : (window['D124I'](F[560667], JSON[F[560025]]({ 'status': tv6kw, 'data': cs3et0 })), window['D1IX24'](F[560668] + (cs3et0 && cs3et0[F[560057]] ? '，' + cs3et0[F[560057]] : '')));
}, window['D1XI24'] = function (weqs) {
  if (!weqs) {
    window['D124I'](F[560669], F[560670]), window['D1IX24'](F[560671]);return;
  }if (weqs[F[560444]] != F[560443]) {
    window['D124I'](F[560669], JSON[F[560025]](weqs)), window['D1IX24'](F[560672] + weqs[F[560444]]);return;
  }D124[F[560673]] = String(weqs[F[560018]]), D124[F[560018]] = String(weqs[F[560018]]), D124[F[560082]] = String(weqs[F[560082]]), D124[F[560583]] = String(weqs[F[560082]]), D124[F[560674]] = String(weqs[F[560674]]), D124[F[560675]] = String(weqs[F[560676]]), D124[F[560677]] = String(weqs[F[560678]]), D124[F[560676]] = '';var tcv0se = this;D1I2X4({ 'title': F[560679] }), sendApi(D124[F[560571]], F[560680], { 'partner_id': D124[F[560579]], 'uid': D124[F[560018]], 'version': D124[F[560078]], 'game_pkg': D124[F[560396]], 'device': D124[F[560580]] }, tcv0se['D1XI42'][F[560340]](tcv0se), D1X42, D14I);
}, window['D1XI42'] = function (gm_o5l) {
  if (!gm_o5l) {
    window['D1IX24'](F[560681]);return;
  }if (gm_o5l[F[560444]] != F[560443]) {
    window['D1IX24'](F[560682] + gm_o5l[F[560444]]);return;
  }if (!gm_o5l[F[560445]] || gm_o5l[F[560445]][F[560009]] == 0x0) {
    window['D1IX24'](F[560683]);return;
  }D124[F[560521]] = gm_o5l[F[560684]], D124[F[560021]] = { 'server_id': String(gm_o5l[F[560445]][0x0][F[560022]]), 'server_name': String(gm_o5l[F[560445]][0x0][F[560423]]), 'entry_ip': gm_o5l[F[560445]][0x0][F[560685]], 'entry_port': parseInt(gm_o5l[F[560445]][0x0][F[560686]]), 'status': D12XI(gm_o5l[F[560445]][0x0]), 'start_time': gm_o5l[F[560445]][0x0][F[560687]], 'cdn': D124[F[560020]] }, this['D142XI']();
}, window['D142XI'] = function () {
  if (D124[F[560521]] == 0x1) {
    var xajm5g = D124[F[560021]][F[560422]];if (xajm5g === -0x1 || xajm5g === 0x0) {
      window['D1IX24'](xajm5g === -0x1 ? F[560688] : F[560689]);return;
    }D14IX2(0x0, D124[F[560021]][F[560022]]), window[F[560033]][F[560034]][F[560516]](D124[F[560521]]);
  } else window[F[560033]][F[560034]][F[560513]](), D1I24X();window['D12X'] = !![], window['D14X2I'](), window['D142IX']();
}, window['D1X2I4'] = function () {
  sendApi(D124[F[560571]], F[560690], { 'game_pkg': D124[F[560396]], 'version_name': D124[F[560647]] }, this[F[560691]][F[560340]](this), D1X42, D14I);
}, window[F[560691]] = function (fp9bu7) {
  if (!fp9bu7) {
    window['D1IX24'](F[560692]);return;
  }if (fp9bu7[F[560444]] != F[560443]) {
    window['D1IX24'](F[560693] + fp9bu7[F[560444]]);return;
  }if (!fp9bu7[F[560445]] || !fp9bu7[F[560445]][F[560078]]) {
    window['D1IX24'](F[560694] + (fp9bu7[F[560445]] && fp9bu7[F[560445]][F[560078]]));return;
  }fp9bu7[F[560445]][F[560695]] && fp9bu7[F[560445]][F[560695]][F[560009]] > 0xa && (D124[F[560696]] = fp9bu7[F[560445]][F[560695]], D124[F[560020]] = fp9bu7[F[560445]][F[560695]]), fp9bu7[F[560445]][F[560078]] && (D124[F[560019]] = fp9bu7[F[560445]][F[560078]]), console[F[560000]](F[560697] + D124[F[560019]] + F[560698] + D124[F[560647]]), window['D124X'] = !![], window['D14X2I'](), window['D142IX']();
}, window[F[560699]], window['D1X24I'] = function () {
  sendApi(D124[F[560571]], F[560700], { 'game_pkg': D124[F[560396]] }, this['D1X4I2'][F[560340]](this), D1X42, D14I);
}, window['D1X4I2'] = function (nrzh12) {
  if (nrzh12[F[560444]] === F[560443] && nrzh12[F[560445]]) {
    window[F[560699]] = nrzh12[F[560445]];for (var oa5jmg in nrzh12[F[560445]]) {
      D124[oa5jmg] = nrzh12[F[560445]][oa5jmg];
    }
  } else console[F[560000]](F[560701] + nrzh12[F[560444]]);window['D1X2'] = !![], window['D142IX']();
}, window[F[560702]] = function (xaj6, tvwk, tc3se0, c30ep, wetsq, e3ucp, x6jwa, w6kja, o5lma) {
  wetsq = String(wetsq);var _zr2ih = x6jwa,
      rzi21h = w6kja;D124[F[560567]][wetsq] = { 'productid': wetsq, 'productname': _zr2ih, 'productdesc': rzi21h, 'roleid': xaj6, 'rolename': tvwk, 'rolelevel': tc3se0, 'price': e3ucp, 'callback': o5lma }, sendApi(D124[F[560575]], F[560703], { 'game_pkg': D124[F[560396]], 'server_id': D124[F[560021]][F[560022]], 'server_name': D124[F[560021]][F[560423]], 'level': tc3se0, 'uid': D124[F[560018]], 'role_id': xaj6, 'role_name': tvwk, 'product_id': wetsq, 'product_name': _zr2ih, 'product_desc': rzi21h, 'money': e3ucp, 'partner_id': D124[F[560579]] }, toPayCallBack, D1X42, D14I);
}, window[F[560704]] = function (mlg_5o) {
  if (mlg_5o) {
    if (mlg_5o[F[560705]] === 0xc8 || mlg_5o[F[560444]] == F[560443]) {
      var wv6x = D124[F[560567]][String(mlg_5o[F[560706]])];if (wv6x[F[560707]]) wv6x[F[560707]](mlg_5o[F[560706]], mlg_5o[F[560708]], -0x1);Dxqv6wk[F[560709]]({ 'cpbill': mlg_5o[F[560708]], 'productid': mlg_5o[F[560706]], 'productname': wv6x[F[560710]], 'productdesc': wv6x[F[560711]], 'serverid': D124[F[560021]][F[560022]], 'servername': D124[F[560021]][F[560423]], 'roleid': wv6x[F[560712]], 'rolename': wv6x[F[560713]], 'rolelevel': wv6x[F[560714]], 'price': wv6x[F[560715]], 'extension': JSON[F[560025]]({ 'cp_order_id': mlg_5o[F[560708]] }) }, function (cs3e0t, j6kwax) {
        wv6x[F[560707]] && cs3e0t == 0x0 && wv6x[F[560707]](mlg_5o[F[560706]], mlg_5o[F[560708]], cs3e0t);console[F[560000]](JSON[F[560025]]({ 'type': F[560716], 'status': cs3e0t, 'data': mlg_5o, 'role_name': wv6x[F[560713]] }));if (cs3e0t === 0x0) {} else {
          if (cs3e0t === 0x1) {} else {
            if (cs3e0t === 0x2) {}
          }
        }
      });
    } else alert(mlg_5o[F[560000]]);
  }
}, window['D1X42I'] = function () {}, window['D1IX4'] = function (i_lzm, vtqwsk, z_rih, n2$h18, vqste0) {
  Dxqv6wk[F[560717]](D124[F[560021]][F[560022]], D124[F[560021]][F[560423]] || D124[F[560021]][F[560022]], i_lzm, vtqwsk, z_rih), sendApi(D124[F[560571]], F[560718], { 'game_pkg': D124[F[560396]], 'server_id': D124[F[560021]][F[560022]], 'role_id': i_lzm, 'uid': D124[F[560018]], 'role_name': vtqwsk, 'role_type': n2$h18, 'level': z_rih });
}, window['D1I4X'] = function (t6vq, izoml, jmgao5, gajxm, vq6k, $yn1, o_lizm, sce, qvkw6t, lozm_) {
  D124[F[560015]] = t6vq, D124[F[560016]] = izoml, D124[F[560017]] = jmgao5, Dxqv6wk[F[560719]](D124[F[560021]][F[560022]], D124[F[560021]][F[560423]] || D124[F[560021]][F[560022]], t6vq, izoml, jmgao5), sendApi(D124[F[560571]], F[560720], { 'game_pkg': D124[F[560396]], 'server_id': D124[F[560021]][F[560022]], 'role_id': t6vq, 'uid': D124[F[560018]], 'role_name': izoml, 'role_type': gajxm, 'level': jmgao5, 'evolution': vq6k });
}, window['D1XI4'] = function (loi_, zr2n, a5mojg, kqw6tv, rh18n, wetvs, _omli5, pcub03, wkajx, up03) {
  D124[F[560015]] = loi_, D124[F[560016]] = zr2n, D124[F[560017]] = a5mojg, Dxqv6wk[F[560721]](D124[F[560021]][F[560022]], D124[F[560021]][F[560423]] || D124[F[560021]][F[560022]], loi_, zr2n, a5mojg), sendApi(D124[F[560571]], F[560720], { 'game_pkg': D124[F[560396]], 'server_id': D124[F[560021]][F[560022]], 'role_id': loi_, 'uid': D124[F[560018]], 'role_name': zr2n, 'role_type': kqw6tv, 'level': a5mojg, 'evolution': rh18n });
}, window['D1X4I'] = function (p3e0u) {}, window['D1IX'] = function (ce) {
  Dxqv6wk[F[560722]](F[560722], function (_olz) {
    ce && ce(_olz);
  });
}, window[F[560723]] = function () {
  Dxqv6wk[F[560723]]();
}, window[F[560724]] = function () {
  Dxqv6wk[F[560725]]();
}, window[F[560726]] = function (x5gj, x6kjq, p3c0u, mx5gja, st0e3c, agmx5, ktwvs, tqvwsk) {
  tqvwsk = tqvwsk || D124[F[560021]][F[560022]], sendApi(D124[F[560571]], F[560727], { 'phone': x5gj, 'role_id': x6kjq, 'uid': D124[F[560018]], 'game_pkg': D124[F[560396]], 'partner_id': D124[F[560579]], 'server_id': tqvwsk }, ktwvs);
}, window[F[560134]] = function (g6jxka) {
  window['D14IX'] = g6jxka, window['D14IX'] && window['D1XI'] && (console[F[560000]](F[560135] + window['D1XI'][F[560136]]), window['D14IX'](window['D1XI']), window['D1XI'] = null);
}, window['D14XI'] = function (evwt, ih1rz, r2i, jgma) {
  window[F[560728]](F[560729], { 'game_pkg': window['D124'][F[560396]], 'role_id': ih1rz, 'server_id': r2i }, jgma);
}, window['D12IX4'] = function (y8$1h, ol5m_) {
  function wak6x(etwsv) {
    var tc3se = [],
        bpu3f9 = [],
        x6kwjq = window[F[560005]][F[560730]];for (var _ziro in x6kwjq) {
      var u0pbc3 = Number(_ziro);(!y8$1h || !y8$1h[F[560009]] || y8$1h[F[560106]](u0pbc3) != -0x1) && (bpu3f9[F[560037]](x6kwjq[_ziro]), tc3se[F[560037]]([u0pbc3, 0x3]));
    }window['D1WX4I2'](window[F[560038]], F[560731]) >= 0x0 ? (console[F[560040]](F[560732]), Dxqv6wk[F[560733]] && Dxqv6wk[F[560733]](bpu3f9, function (pb49) {
      console[F[560040]](F[560734]), console[F[560040]](pb49);if (pb49 && pb49[F[560057]] == F[560735]) for (var g6xkja in x6kwjq) {
        if (pb49[x6kwjq[g6xkja]] == F[560736]) {
          var e03ts = Number(g6xkja);for (var cp0e = 0x0; cp0e < tc3se[F[560009]]; cp0e++) {
            if (tc3se[cp0e][0x0] == e03ts) {
              tc3se[cp0e][0x1] = 0x1;break;
            }
          }
        }
      }window['D1WX4I2'](window[F[560038]], F[560737]) >= 0x0 ? wx[F[560738]]({ 'withSubscriptions': !![], 'success': function (wtseq) {
          var tvew = wtseq[F[560739]][F[560740]];if (tvew) {
            console[F[560040]](F[560741]), console[F[560040]](tvew);for (var m5l_g in x6kwjq) {
              if (tvew[x6kwjq[m5l_g]] == F[560736]) {
                var e03pcu = Number(m5l_g);for (var gl_5o = 0x0; gl_5o < tc3se[F[560009]]; gl_5o++) {
                  if (tc3se[gl_5o][0x0] == e03pcu) {
                    tc3se[gl_5o][0x1] = 0x2;break;
                  }
                }
              }
            }console[F[560040]](tc3se), ol5m_ && ol5m_(tc3se);
          } else console[F[560040]](F[560742]), console[F[560040]](wtseq), console[F[560040]](tc3se), ol5m_ && ol5m_(tc3se);
        }, 'fail': function () {
          console[F[560040]](F[560743]), console[F[560040]](tc3se), ol5m_ && ol5m_(tc3se);
        } }) : (console[F[560040]](F[560744] + window[F[560038]]), console[F[560040]](tc3se), ol5m_ && ol5m_(tc3se));
    })) : (console[F[560040]](F[560745] + window[F[560038]]), console[F[560040]](tc3se), ol5m_ && ol5m_(tc3se)), wx[F[560746]](wak6x);
  }wx[F[560747]](wak6x);
}, window['D12I4X'] = { 'isSuccess': ![], 'level': F[560748], 'isCharging': ![] }, window['D12XI4'] = function (n2zr1h) {
  wx[F[560122]]({ 'success': function (nhr281) {
      var x5mga = window['D12I4X'];x5mga[F[560749]] = !![], x5mga[F[560124]] = Number(nhr281[F[560124]])[F[560750]](0x0), x5mga[F[560126]] = nhr281[F[560126]], n2zr1h && n2zr1h(x5mga[F[560749]], x5mga[F[560124]], x5mga[F[560126]]);
    }, 'fail': function (lro_i) {
      console[F[560040]](F[560751], lro_i[F[560057]]);var zmoli_ = window['D12I4X'];n2zr1h && n2zr1h(zmoli_[F[560749]], zmoli_[F[560124]], zmoli_[F[560126]]);
    } });
}, window[F[560728]] = function (h1z2i, gx65j, qtvk, e0cstv, e3us0, zrn1, moil, ga6j5) {
  if (e0cstv == undefined) e0cstv = 0x1;wx[F[560622]]({ 'url': h1z2i, 'method': moil || F[560752], 'responseType': F[560338], 'data': gx65j, 'header': { 'content-type': ga6j5 || F[560624] }, 'success': function (ec3st0) {
      DEBUG && console[F[560040]](F[560753], h1z2i, info, ec3st0);if (ec3st0 && ec3st0[F[560754]] == 0xc8) {
        var zir2l = ec3st0[F[560445]];!zrn1 || zrn1(zir2l) ? qtvk && qtvk(zir2l) : window[F[560755]](h1z2i, gx65j, qtvk, e0cstv, e3us0, zrn1, ec3st0);
      } else window[F[560755]](h1z2i, gx65j, qtvk, e0cstv, e3us0, zrn1, ec3st0);
    }, 'fail': function (rh_iz) {
      DEBUG && console[F[560040]](F[560756], h1z2i, info, rh_iz), window[F[560755]](h1z2i, gx65j, qtvk, e0cstv, e3us0, zrn1, rh_iz);
    }, 'complete': function () {} });
}, window[F[560755]] = function (bu, kjg, olzri_, wves, rz1ih2, sc3e0, sve0) {
  wves - 0x1 > 0x0 ? setTimeout(function () {
    window[F[560728]](bu, kjg, olzri_, wves - 0x1, rz1ih2, sc3e0);
  }, 0x3e8) : rz1ih2 && rz1ih2(JSON[F[560025]]({ 'url': bu, 'response': sve0 }));
}, window[F[560757]] = function (rzi2h_, kxqw6v, zhrn, qt6kv, xgma, qk6j, twsqkv) {
  !zhrn && (zhrn = {});var nr18 = Math[F[560533]](Date[F[560284]]() / 0x3e8);zhrn[F[560678]] = nr18, zhrn[F[560758]] = kxqw6v;var i_z2r = Object[F[560759]](zhrn)[F[560449]](),
      jxm5g = '',
      w6qkjx = '';for (var rn12z = 0x0; rn12z < i_z2r[F[560009]]; rn12z++) {
    jxm5g = jxm5g + (rn12z == 0x0 ? '' : '&') + i_z2r[rn12z] + zhrn[i_z2r[rn12z]], w6qkjx = w6qkjx + (rn12z == 0x0 ? '' : '&') + i_z2r[rn12z] + '=' + encodeURIComponent(zhrn[i_z2r[rn12z]]);
  }jxm5g = jxm5g + D124[F[560577]];var y$1hn8 = F[560760] + md5(jxm5g);send(rzi2h_ + '?' + w6qkjx + (w6qkjx == '' ? '' : '&') + y$1hn8, null, qt6kv, xgma, qk6j, twsqkv || function (jog5m) {
    return jog5m[F[560444]] == F[560443];
  }, null, F[560761]);
}, window['D12X4I'] = function (y8$1hn, vkwq6t) {
  var sv0eq = 0x0;D124[F[560021]] && (sv0eq = D124[F[560021]][F[560022]]), sendApi(D124[F[560573]], F[560762], { 'partnerId': D124[F[560579]], 'gamePkg': D124[F[560396]], 'logTime': Math[F[560533]](Date[F[560284]]() / 0x3e8), 'platformUid': D124[F[560674]], 'type': y8$1hn, 'serverId': sv0eq }, null, 0x2, null, function () {
    return !![];
  });
}, window['D124IX'] = function (i_lzmo) {
  sendApi(D124[F[560571]], F[560763], { 'partner_id': D124[F[560579]], 'uid': D124[F[560018]], 'version': D124[F[560078]], 'game_pkg': D124[F[560396]], 'device': D124[F[560580]] }, D124XI, D1X42, D14I);
}, window['D124XI'] = function (kaj6w) {
  if (kaj6w[F[560444]] === F[560443] && kaj6w[F[560445]]) {
    kaj6w[F[560445]][F[560764]]({ 'id': -0x2, 'name': F[560765] }), kaj6w[F[560445]][F[560764]]({ 'id': -0x1, 'name': F[560766] }), D124[F[560395]] = kaj6w[F[560445]];if (window[F[560387]]) window[F[560387]][F[560429]]();
  } else D124[F[560406]] = ![], window['D1IX24'](F[560767] + kaj6w[F[560444]]);
}, window['D1IX2'] = function ($h2n8) {
  sendApi(D124[F[560571]], F[560768], { 'partner_id': D124[F[560579]], 'uid': D124[F[560018]], 'version': D124[F[560078]], 'game_pkg': D124[F[560396]], 'device': D124[F[560580]] }, D1I2X, D1X42, D14I);
}, window['D1I2X'] = function (gmja5) {
  D124[F[560437]] = ![];if (gmja5[F[560444]] === F[560443] && gmja5[F[560445]]) {
    for (var nrh182 = 0x0; nrh182 < gmja5[F[560445]][F[560009]]; nrh182++) {
      gmja5[F[560445]][nrh182][F[560422]] = D12XI(gmja5[F[560445]][nrh182]);
    }D124[F[560435]][-0x1] = window[F[560769]](gmja5[F[560445]]), window[F[560387]][F[560436]](-0x1);
  } else window['D1IX24'](F[560770] + gmja5[F[560444]]);
}, window[F[560771]] = function (hr81n2) {
  sendApi(D124[F[560571]], F[560768], { 'partner_id': D124[F[560579]], 'uid': D124[F[560018]], 'version': D124[F[560078]], 'game_pkg': D124[F[560396]], 'device': D124[F[560580]] }, hr81n2, D1X42, D14I);
}, window['D1XI2'] = function (i_2zh, jmoga) {
  sendApi(D124[F[560571]], F[560772], { 'partner_id': D124[F[560579]], 'uid': D124[F[560018]], 'version': D124[F[560078]], 'game_pkg': D124[F[560396]], 'device': D124[F[560580]], 'server_group_id': jmoga }, D1X2I, D1X42, D14I);
}, window['D1X2I'] = function (fu93bp) {
  D124[F[560437]] = ![];if (fu93bp[F[560444]] === F[560443] && fu93bp[F[560445]] && fu93bp[F[560445]][F[560445]]) {
    var rn1hz2 = fu93bp[F[560445]][F[560773]],
        $8yhn1 = [];for (var est0v = 0x0; est0v < fu93bp[F[560445]][F[560445]][F[560009]]; est0v++) {
      fu93bp[F[560445]][F[560445]][est0v][F[560422]] = D12XI(fu93bp[F[560445]][F[560445]][est0v]), ($8yhn1[F[560009]] == 0x0 || fu93bp[F[560445]][F[560445]][est0v][F[560422]] != 0x0) && ($8yhn1[$8yhn1[F[560009]]] = fu93bp[F[560445]][F[560445]][est0v]);
    }D124[F[560435]][rn1hz2] = window[F[560769]]($8yhn1), window[F[560387]][F[560436]](rn1hz2);
  } else window['D1IX24'](F[560774] + fu93bp[F[560444]]);
}, window['D1WX42'] = function (cus3e) {
  sendApi(D124[F[560571]], F[560775], { 'partner_id': D124[F[560579]], 'uid': D124[F[560018]], 'version': D124[F[560078]], 'game_pkg': D124[F[560396]], 'device': D124[F[560580]] }, reqServerRecommendCallBack, D1X42, D14I);
}, window[F[560776]] = function (h1rn82) {
  D124[F[560437]] = ![];if (h1rn82[F[560444]] === F[560443] && h1rn82[F[560445]]) {
    for (var cep03u = 0x0; cep03u < h1rn82[F[560445]][F[560009]]; cep03u++) {
      h1rn82[F[560445]][cep03u][F[560422]] = D12XI(h1rn82[F[560445]][cep03u]);
    }D124[F[560435]][-0x2] = window[F[560769]](h1rn82[F[560445]]), window[F[560387]][F[560436]](-0x2);
  } else alert(F[560777] + h1rn82[F[560444]]);
}, window[F[560769]] = function (jgo5am) {
  if (!jgo5am && jgo5am[F[560009]] <= 0x0) return jgo5am;for (let i_or = 0x0; i_or < jgo5am[F[560009]]; i_or++) {
    jgo5am[i_or][F[560778]] && jgo5am[i_or][F[560778]] == 0x1 && (jgo5am[i_or][F[560423]] += F[560779]);
  }return jgo5am;
}, window['D12IX'] = function (_zmloi, t6qv) {
  _zmloi = _zmloi || D124[F[560021]][F[560022]], sendApi(D124[F[560571]], F[560780], { 'type': '4', 'game_pkg': D124[F[560396]], 'server_id': _zmloi }, t6qv);
}, window[F[560781]] = function (f9pb47, _zr2h, zh12r, h1n28r) {
  zh12r = zh12r || D124[F[560021]][F[560022]], sendApi(D124[F[560571]], F[560782], { 'type': f9pb47, 'game_pkg': _zr2h, 'server_id': zh12r }, h1n28r);
}, window['D12XI'] = function (m5ilo) {
  if (m5ilo) {
    if (m5ilo[F[560422]] == 0x1) {
      if (m5ilo[F[560783]] == 0x1) return 0x2;else return 0x1;
    } else return m5ilo[F[560422]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['D14IX2'] = function (ub9, gao5m) {
  D124[F[560784]] = { 'step': ub9, 'server_id': gao5m };var vk6w = this;D1I2X4({ 'title': F[560785] }), sendApi(D124[F[560571]], F[560786], { 'partner_id': D124[F[560579]], 'uid': D124[F[560018]], 'game_pkg': D124[F[560396]], 'server_id': gao5m, 'platform': D124[F[560082]], 'platform_uid': D124[F[560674]], 'check_login_time': D124[F[560677]], 'check_login_sign': D124[F[560675]], 'version_name': D124[F[560647]] }, D14I2X, D1X42, D14I, function (s0ec3) {
    return s0ec3[F[560444]] == F[560443] || s0ec3[F[560000]] == F[560787] || s0ec3[F[560000]] == F[560788];
  });
}, window['D14I2X'] = function (u3b9pf) {
  var ir2lz_ = this;if (u3b9pf[F[560444]] === F[560443] && u3b9pf[F[560445]]) {
    var _lmzi = D124[F[560021]];_lmzi[F[560789]] = D124[F[560582]], _lmzi[F[560676]] = String(u3b9pf[F[560445]][F[560790]]), _lmzi[F[560588]] = parseInt(u3b9pf[F[560445]][F[560678]]);if (u3b9pf[F[560445]][F[560791]]) _lmzi[F[560791]] = parseInt(u3b9pf[F[560445]][F[560791]]);else _lmzi[F[560791]] = parseInt(u3b9pf[F[560445]][F[560022]]);_lmzi[F[560792]] = 0x0, _lmzi[F[560020]] = D124[F[560696]], _lmzi[F[560793]] = u3b9pf[F[560445]][F[560794]], _lmzi[F[560795]] = u3b9pf[F[560445]][F[560795]], console[F[560040]](F[560796] + JSON[F[560025]](_lmzi[F[560795]])), D124[F[560521]] == 0x1 && _lmzi[F[560795]] && _lmzi[F[560795]][F[560797]] == 0x1 && (D124[F[560344]] = 0x1, window[F[560033]][F[560034]]['D1W42']()), D14XI2();
  } else D124[F[560784]][F[560798]] >= 0x3 ? (D14I(JSON[F[560025]](u3b9pf)), window['D1IX24'](F[560799] + u3b9pf[F[560444]])) : sendApi(D124[F[560571]], F[560659], { 'platform': D124[F[560569]], 'partner_id': D124[F[560579]], 'token': D124[F[560657]], 'game_pkg': D124[F[560396]], 'deviceId': D124[F[560580]], 'scene': F[560660] + D124[F[560581]] }, function (ol_5mg) {
    if (!ol_5mg || ol_5mg[F[560444]] != F[560443]) {
      window['D1IX24'](F[560672] + ol_5mg && ol_5mg[F[560444]]);return;
    }D124[F[560675]] = String(ol_5mg[F[560676]]), D124[F[560677]] = String(ol_5mg[F[560678]]), setTimeout(function () {
      D14IX2(D124[F[560784]][F[560798]] + 0x1, D124[F[560784]][F[560022]]);
    }, 0x5dc);
  }, D1X42, D14I, function (agxk6) {
    return agxk6[F[560444]] == F[560443] || agxk6[F[560444]] == F[560800];
  });
}, window['D14XI2'] = function () {
  ServerLoading[F[560034]][F[560516]](D124[F[560521]]), window['D1X4'] = !![], window['D142IX']();
}, window['D14X2I'] = function () {
  if (window['D14X'] && window['D12X4'] && window[F[560512]] && window[F[560515]] && window['D124X'] && window['D12X']) {
    if (!window[F[560801]][F[560034]]) {
      console[F[560040]](F[560802] + window[F[560801]][F[560034]]);var oli_m = wx[F[560803]](),
          miol_z = oli_m[F[560136]] ? oli_m[F[560136]] : 0x0,
          s3ceu = { 'cdn': window['D124'][F[560020]], 'spareCdn': window['D124'][F[560645]], 'newRegister': window['D124'][F[560521]], 'wxPC': window['D124'][F[560111]], 'wxIOS': window['D124'][F[560105]], 'wxAndroid': window['D124'][F[560108]], 'wxParam': { 'limitLoad': window['D124']['D1WIX42'], 'benchmarkLevel': window['D124']['D1WI2X4'], 'wxFrom': window[F[560005]][F[560652]] == F[560804] ? 0x1 : 0x0, 'wxSDKVersion': window[F[560038]] }, 'configType': window['D124'][F[560589]], 'exposeType': window['D124'][F[560591]], 'scene': miol_z };new window[F[560801]](s3ceu, window['D124'][F[560019]], window['D1WIX24']);
    }
  }
}, window['D142IX'] = function () {
  if (window['D14X'] && window['D12X4'] && window[F[560512]] && window[F[560515]] && window['D124X'] && window['D12X'] && window['D1X4'] && window['D1X2']) {
    D1I24X();if (!D14X2) {
      D14X2 = !![];if (!window[F[560801]][F[560034]]) window['D14X2I']();var t0ev = 0x0,
          u3p0 = wx[F[560805]]();u3p0 && (window['D124'][F[560110]] && (t0ev = u3p0[F[560100]]), console[F[560000]](F[560806] + u3p0[F[560100]] + F[560807] + u3p0[F[560101]] + F[560808] + u3p0[F[560102]] + F[560809] + u3p0[F[560103]] + F[560810] + u3p0[F[560307]] + F[560811] + u3p0[F[560309]]));var r2_zhi = {};for (const eqstv in D124[F[560021]]) {
        r2_zhi[eqstv] = D124[F[560021]][eqstv];
      }var vqskw = { 'channel': window['D124'][F[560583]], 'account': window['D124'][F[560018]], 'userId': window['D124'][F[560673]], 'serverId': r2_zhi[F[560022]], 'cdn': window['D124'][F[560020]], 'data': window['D124'][F[560445]], 'package': window['D124'][F[560568]], 'newRegister': window['D124'][F[560521]], 'pkgName': window['D124'][F[560396]], 'partnerId': window['D124'][F[560579]], 'platform_uid': window['D124'][F[560674]], 'deviceId': window['D124'][F[560580]], 'selectedServer': r2_zhi, 'configType': window['D124'][F[560589]], 'exposeType': window['D124'][F[560591]], 'debugUsers': window['D124'][F[560586]], 'wxMenuTop': t0ev, 'wxShield': window['D124'][F[560592]] };if (window[F[560699]]) for (var u3ec0p in window[F[560699]]) {
        vqskw[u3ec0p] = window[F[560699]][u3ec0p];
      }window[F[560801]][F[560034]]['D142W'](vqskw);
    }
  } else console[F[560000]](F[560812] + window['D14X'] + F[560813] + window['D12X4'] + F[560814] + window[F[560512]] + F[560815] + window[F[560515]] + F[560816] + window['D124X'] + F[560817] + window['D12X'] + F[560818] + window['D1X4'] + F[560819] + window['D1X2']);
};