var F = wx.$D;
import 'd222Md22Id222.js';