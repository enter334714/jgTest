var F = wx.$D;
console[F[560000]](F[560001]), window[F[560002]], wx[F[560003]](function (n18hy$) {
  if (n18hy$) {
    if (n18hy$[F[560004]]) {
      var xjmg = window[F[560005]][F[560006]][F[560007]](new RegExp(/\./, 'g'), '_'),
          l_zimo = n18hy$[F[560004]],
          zri_l2 = l_zimo[F[560008]](/(d22d22d22d22d22\/d222Gd22MEd222.js:)[0-9]{1,60}(:)/g);if (zri_l2) for (var moj5 = 0x0; moj5 < zri_l2[F[560009]]; moj5++) {
        if (zri_l2[moj5] && zri_l2[moj5][F[560009]] > 0x0) {
          var a6kwj = parseInt(zri_l2[moj5][F[560007]](F[560010], '')[F[560007]](':', ''));l_zimo = l_zimo[F[560007]](zri_l2[moj5], zri_l2[moj5][F[560007]](':' + a6kwj + ':', ':' + (a6kwj - 0x2) + ':'));
        }
      }l_zimo = l_zimo[F[560007]](new RegExp(F[560011], 'g'), F[560012] + xjmg + F[560013]), l_zimo = l_zimo[F[560007]](new RegExp(F[560014], 'g'), F[560012] + xjmg + F[560013]), n18hy$[F[560004]] = l_zimo;
    }var nr1h28 = { 'id': window['D124'][F[560015]], 'role': window['D124'][F[560016]], 'level': window['D124'][F[560017]], 'user': window['D124'][F[560018]], 'version': window['D124'][F[560019]], 'gamever': window[F[560005]][F[560006]], 'cdn': window['D124'][F[560020]], 'serverid': window['D124'][F[560021]] ? window['D124'][F[560021]][F[560022]] : 0x0, 'systemInfo': window[F[560023]], 'error': F[560024], 'stack': n18hy$ ? n18hy$[F[560004]] : '' },
        n21h$8 = JSON[F[560025]](nr1h28);console[F[560026]](F[560027] + n21h$8), (!window[F[560002]] || window[F[560002]] != nr1h28[F[560026]]) && (window[F[560002]] = nr1h28[F[560026]], window['D1I2'](nr1h28));
  }
});import 'd22d22bfd22d22.js';import 'd22d2211d22d22.js';window[F[560028]] = require(F[560029]);import 'd22INDd22d22.js';import 'd22d22Id221d22d22.js';import 'd22d22Mtadd22d22.js';import 'd22d22INId22ad22.js';console[F[560000]](F[560030]), console[F[560000]](F[560031]), D1I2X4({ 'title': F[560032] });var D_lzm = { 'D1WI42X': !![] };new window[F[560033]](D_lzm), window[F[560033]][F[560034]]['D1WX24I']();if (window['D1WI24X']) clearInterval(window['D1WI24X']);window['D1WI24X'] = null, window['D1WX4I2'] = function (jgkx, $8nhy) {
  if (!jgkx || !$8nhy) return 0x0;jgkx = jgkx[F[560035]]('.'), $8nhy = $8nhy[F[560035]]('.');const u9bpc3 = Math[F[560036]](jgkx[F[560009]], $8nhy[F[560009]]);while (jgkx[F[560009]] < u9bpc3) {
    jgkx[F[560037]]('0');
  }while ($8nhy[F[560009]] < u9bpc3) {
    $8nhy[F[560037]]('0');
  }for (var u7f = 0x0; u7f < u9bpc3; u7f++) {
    const $y = parseInt(jgkx[u7f]),
          m_5oi = parseInt($8nhy[u7f]);if ($y > m_5oi) return 0x1;else {
      if ($y < m_5oi) return -0x1;
    }
  }return 0x0;
}, window[F[560038]] = wx[F[560039]]()[F[560038]], console[F[560040]](F[560041] + window[F[560038]]);var Dzrhn21 = wx[F[560042]]();Dzrhn21[F[560043]](function (u30ep) {
  console[F[560040]](F[560044] + u30ep[F[560045]]);
}), Dzrhn21[F[560046]](function () {
  wx[F[560047]]({ 'title': F[560048], 'content': F[560049], 'showCancel': ![], 'success': function (cvs0e) {
      Dzrhn21[F[560050]]();
    } });
}), Dzrhn21[F[560051]](function () {
  console[F[560040]](F[560052]);
}), window['D1WX42I'] = function () {
  console[F[560040]](F[560053]);var _rlz2i = wx[F[560054]]({ 'name': F[560055], 'success': function (ctsv) {
      console[F[560040]](F[560056]), console[F[560040]](ctsv), ctsv && ctsv[F[560057]] == F[560058] ? (window['D14X'] = !![], window['D14X2I'](), window['D142IX']()) : setTimeout(function () {
        window['D1WX42I']();
      }, 0x1f4);
    }, 'fail': function (jx6wa) {
      console[F[560040]](F[560059]), console[F[560040]](jx6wa), setTimeout(function () {
        window['D1WX42I']();
      }, 0x1f4);
    } });_rlz2i && _rlz2i[F[560060]](cse => {});
}, window['D1W2I4X'] = function () {
  console[F[560040]](F[560061]);var kqjx6 = wx[F[560054]]({ 'name': F[560062], 'success': function (akjgx6) {
      console[F[560040]](F[560063]), console[F[560040]](akjgx6), akjgx6 && akjgx6[F[560057]] == F[560058] ? (window['D12X4'] = !![], window['D14X2I'](), window['D142IX']()) : setTimeout(function () {
        window['D1W2I4X']();
      }, 0x1f4);
    }, 'fail': function (fbp3u) {
      console[F[560040]](F[560064]), console[F[560040]](fbp3u), setTimeout(function () {
        window['D1W2I4X']();
      }, 0x1f4);
    } });kqjx6 && kqjx6[F[560060]](i2rz1h => {});
}, window[F[560065]] = function () {
  window['D1WX4I2'](window[F[560038]], F[560066]) >= 0x0 ? (console[F[560040]](F[560067] + window[F[560038]] + F[560068]), window['D12I'](), window['D1WX42I'](), window['D1W2I4X']()) : (window['D124I'](F[560069], window[F[560038]]), wx[F[560047]]({ 'title': F[560070], 'content': F[560071] }));
}, window[F[560023]] = '', wx[F[560072]]({ 'success'(zl2ir) {
    window[F[560023]] = F[560073] + zl2ir[F[560074]] + F[560075] + zl2ir[F[560076]] + F[560077] + zl2ir[F[560078]] + F[560079] + zl2ir[F[560080]] + F[560081] + zl2ir[F[560082]] + F[560083] + zl2ir[F[560038]] + F[560084] + zl2ir[F[560085]], console[F[560040]](window[F[560023]]), console[F[560040]](F[560086] + zl2ir[F[560087]] + F[560088] + zl2ir[F[560089]] + F[560090] + zl2ir[F[560091]] + F[560092] + zl2ir[F[560093]] + F[560094] + zl2ir[F[560095]] + F[560096] + zl2ir[F[560097]] + F[560098] + (zl2ir[F[560099]] ? zl2ir[F[560099]][F[560100]] + ',' + zl2ir[F[560099]][F[560101]] + ',' + zl2ir[F[560099]][F[560102]] + ',' + zl2ir[F[560099]][F[560103]] : ''));var b3upc9 = zl2ir[F[560080]] ? zl2ir[F[560080]][F[560104]]() : '',
        pu3c = zl2ir[F[560076]] ? zl2ir[F[560076]][F[560104]]()[F[560007]]('\x20', '') : '';window['D124'][F[560105]] = b3upc9[F[560106]](F[560107]) != -0x1, window['D124'][F[560108]] = b3upc9[F[560106]](F[560109]) != -0x1, window['D124'][F[560110]] = b3upc9[F[560106]](F[560107]) != -0x1 || b3upc9[F[560106]](F[560109]) != -0x1, window['D124'][F[560111]] = b3upc9[F[560106]](F[560112]) != -0x1 || b3upc9[F[560106]](F[560113]) != -0x1, window['D124'][F[560114]] = zl2ir[F[560082]] ? zl2ir[F[560082]][F[560104]]() : '', window['D124']['D1WIX42'] = ![], window['D124']['D1WI2X4'] = 0x2;if (b3upc9[F[560106]](F[560109]) != -0x1) {
      if (zl2ir[F[560085]] >= 0x18) window['D124']['D1WI2X4'] = 0x3;else window['D124']['D1WI2X4'] = 0x2;
    } else {
      if (b3upc9[F[560106]](F[560107]) != -0x1) {
        if (zl2ir[F[560085]] && zl2ir[F[560085]] >= 0x14) window['D124']['D1WI2X4'] = 0x3;else {
          if (pu3c[F[560106]](F[560115]) != -0x1 || pu3c[F[560106]](F[560116]) != -0x1 || pu3c[F[560106]](F[560117]) != -0x1 || pu3c[F[560106]](F[560118]) != -0x1 || pu3c[F[560106]](F[560119]) != -0x1) window['D124']['D1WI2X4'] = 0x2;else window['D124']['D1WI2X4'] = 0x3;
        }
      } else window['D124']['D1WI2X4'] = 0x2;
    }console[F[560040]](F[560120] + window['D124']['D1WIX42'] + F[560121] + window['D124']['D1WI2X4']);
  } }), wx[F[560122]]({ 'success': function (kqv6tw) {
    console[F[560040]](F[560123] + kqv6tw[F[560124]] + F[560125] + kqv6tw[F[560126]]);
  } }), wx[F[560127]]({ 'success': function (h$y8n) {
    console[F[560040]](F[560128] + h$y8n[F[560129]]);
  } }), wx[F[560130]]({ 'keepScreenOn': !![] }), wx[F[560131]](function (l5oi) {
  console[F[560040]](F[560128] + l5oi[F[560129]] + F[560132] + l5oi[F[560133]]);
}), wx[F[560134]](function (o_lm5g) {
  window['D1XI'] = o_lm5g, window['D14IX'] && window['D1XI'] && (console[F[560000]](F[560135] + window['D1XI'][F[560136]]), window['D14IX'](window['D1XI']), window['D1XI'] = null);
}), window['D1W2X4I'] = 0x0, window[F[560137]] = null, wx[F[560138]](function () {
  window['D1W2X4I']++, wx[F[560139]]();if (window['D1W2X4I'] >= 0x2) {
    window['D1W2X4I'] = 0x0, console[F[560026]](F[560140]), wx[F[560141]]('0', 0x1);if (window['D124'] && window['D124'][F[560105]]) window['D124I'](F[560142], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});