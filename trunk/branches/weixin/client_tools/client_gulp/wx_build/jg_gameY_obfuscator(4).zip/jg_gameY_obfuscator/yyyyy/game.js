var a = wx.$y;
import 'yyMAIy.js';