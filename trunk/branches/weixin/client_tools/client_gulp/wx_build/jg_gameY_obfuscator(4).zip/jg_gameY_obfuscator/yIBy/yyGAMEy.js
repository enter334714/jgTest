var a = wx.$y;
console[a[420070]](a[420333]), window[a[420334]], wx[a[420335]](function (_lf) {
  if (_lf) {
    if (_lf[a[420336]]) {
      var jofh_ = window[a[420002]][a[420003]][a[420337]](new RegExp(/\./, 'g'), '_'),
          zye = _lf[a[420336]],
          exzr0 = zye[a[420338]](/(yyyyy\/yyGAMEy.js:)[0-9]{1,60}(:)/g);if (exzr0) for (var _8c = 0x0; _8c < exzr0[a[420167]]; _8c++) {
        if (exzr0[_8c] && exzr0[_8c][a[420167]] > 0x0) {
          var um6a3 = parseInt(exzr0[_8c][a[420337]](a[420339], '')[a[420337]](':', ''));zye = zye[a[420337]](exzr0[_8c], exzr0[_8c][a[420337]](':' + um6a3 + ':', ':' + (um6a3 - 0x2) + ':'));
        }
      }zye = zye[a[420337]](new RegExp(a[420340], 'g'), a[420341] + jofh_ + a[420342]), zye = zye[a[420337]](new RegExp(a[420343], 'g'), a[420341] + jofh_ + a[420342]), _lf[a[420336]] = zye;
    }var da1mu = { 'id': window['y2S0'][a[420079]], 'role': window['y2S0'][a[420080]], 'level': window['y2S0'][a[420081]], 'user': window['y2S0'][a[420082]], 'version': window['y2S0'][a[420041]], 'cdn': window['y2S0'][a[420083]], 'pkgName': window['y2S0'][a[420024]], 'gamever': window[a[420002]][a[420003]], 'serverid': window['y2S0'][a[420030]] ? window['y2S0'][a[420030]][a[420084]] : 0x0, 'systemInfo': window[a[420085]], 'error': a[420344], 'stack': _lf ? _lf[a[420336]] : '' },
        v635 = JSON[a[420087]](da1mu);console[a[420088]](a[420345] + v635), (!window[a[420334]] || window[a[420334]] != da1mu[a[420088]]) && (window[a[420334]] = da1mu[a[420088]], window['y2$S'](da1mu));
  }
});import 'yybfyy.js';import 'yy11yy.js';window[a[420346]] = require(a[420347]);import 'yINDyy.js';import 'yyIB1yy.js';import 'yyMtadyy.js';import 'yyINIyy.js';console[a[420070]](a[420348]), console[a[420070]](a[420349]), y2$S50({ 'title': a[420350] });var y_lc87s = { 'y29$0S5': !![] };new window[a[420065]](y_lc87s), window[a[420065]][a[420066]]['y295S0$']();if (window['y29$S05']) clearInterval(window['y29$S05']);window['y29$S05'] = null, window['y2950$S'] = function (wdumt1, inqp$g) {
  if (!wdumt1 || !inqp$g) return 0x0;wdumt1 = wdumt1[a[420351]]('.'), inqp$g = inqp$g[a[420351]]('.');const l_o7f = Math[a[420352]](wdumt1[a[420167]], inqp$g[a[420167]]);while (wdumt1[a[420167]] < l_o7f) {
    wdumt1[a[420222]]('0');
  }while (inqp$g[a[420167]] < l_o7f) {
    inqp$g[a[420222]]('0');
  }for (var k9c2l = 0x0; k9c2l < l_o7f; k9c2l++) {
    const ohwfj = parseInt(wdumt1[k9c2l]),
          twohj = parseInt(inqp$g[k9c2l]);if (ohwfj > twohj) return 0x1;else {
      if (ohwfj < twohj) return -0x1;
    }
  }return 0x0;
}, window[a[420223]] = wx[a[420353]]()[a[420223]], console[a[420049]](a[420354] + window[a[420223]]);var ym165 = wx[a[420355]]();ym165[a[420356]](function (m56v3) {
  console[a[420049]](a[420357] + m56v3[a[420358]]);
}), ym165[a[420359]](function () {
  wx[a[420051]]({ 'title': a[420360], 'content': a[420361], 'showCancel': ![], 'success': function (i$k2gn) {
      ym165[a[420362]]();
    } });
}), ym165[a[420363]](function () {
  console[a[420049]](a[420364]);
}), window['y2950S$'] = function () {
  console[a[420049]](a[420365]);var adu1m5 = wx[a[420366]]({ 'name': a[420367], 'success': function (u1t5d) {
      console[a[420049]](a[420368]), console[a[420049]](u1t5d), u1t5d && u1t5d[a[420141]] == a[420369] ? (window['y205'] = !![], window['y205S$'](), window['y20S$5']()) : setTimeout(function () {
        window['y2950S$']();
      }, 0x1f4);
    }, 'fail': function (yexrz) {
      console[a[420049]](a[420370]), console[a[420049]](yexrz), setTimeout(function () {
        window['y2950S$']();
      }, 0x1f4);
    } });adu1m5 && adu1m5[a[420371]](twd41 => {});
}, window['y29S$05'] = function () {
  console[a[420049]](a[420372]);var vrz0x = wx[a[420366]]({ 'name': a[420373], 'success': function (mtd5u) {
      console[a[420049]](a[420374]), console[a[420049]](mtd5u), mtd5u && mtd5u[a[420141]] == a[420369] ? (window['y2S50'] = !![], window['y205S$'](), window['y20S$5']()) : setTimeout(function () {
        window['y29S$05']();
      }, 0x1f4);
    }, 'fail': function (xz) {
      console[a[420049]](a[420375]), console[a[420049]](xz), setTimeout(function () {
        window['y29S$05']();
      }, 0x1f4);
    } });vrz0x && vrz0x[a[420371]](q$g2 => {});
}, window[a[420376]] = function () {
  window['y2950$S'](window[a[420223]], a[420377]) >= 0x0 ? (console[a[420049]](a[420378] + window[a[420223]] + a[420379]), window['y2S$'](), window['y2950S$'](), window['y29S$05']()) : (window['y2S0$'](a[420380], window[a[420223]]), wx[a[420051]]({ 'title': a[420052], 'content': a[420381] }));
}, window[a[420085]] = '', wx[a[420382]]({ 'success'(oj4hwf) {
    window[a[420085]] = a[420383] + oj4hwf[a[420384]] + a[420385] + oj4hwf[a[420386]] + a[420387] + oj4hwf[a[420010]] + a[420388] + oj4hwf[a[420389]] + a[420390] + oj4hwf[a[420157]] + a[420391] + oj4hwf[a[420223]] + a[420392] + oj4hwf[a[420393]], console[a[420049]](window[a[420085]]), console[a[420049]](a[420394] + oj4hwf[a[420395]] + a[420396] + oj4hwf[a[420397]] + a[420398] + oj4hwf[a[420399]] + a[420400] + oj4hwf[a[420401]] + a[420402] + oj4hwf[a[420403]] + a[420404] + oj4hwf[a[420405]] + a[420406] + (oj4hwf[a[420407]] ? oj4hwf[a[420407]][a[420313]] + ',' + oj4hwf[a[420407]][a[420316]] + ',' + oj4hwf[a[420407]][a[420318]] + ',' + oj4hwf[a[420407]][a[420320]] : ''));var mv53a = oj4hwf[a[420389]] ? oj4hwf[a[420389]][a[420408]]() : '',
        thwd4j = oj4hwf[a[420386]] ? oj4hwf[a[420386]][a[420408]]()[a[420337]]('\x20', '') : '';window['y2S0'][a[420043]] = mv53a[a[420142]](a[420409]) != -0x1, window['y2S0'][a[420044]] = mv53a[a[420142]](a[420410]) != -0x1, window['y2S0'][a[420312]] = mv53a[a[420142]](a[420409]) != -0x1 || mv53a[a[420142]](a[420410]) != -0x1, window['y2S0'][a[420045]] = mv53a[a[420142]](a[420411]) != -0x1 || mv53a[a[420142]](a[420012]) != -0x1, window['y2S0'][a[420096]] = oj4hwf[a[420157]] ? oj4hwf[a[420157]][a[420408]]() : '', window['y2S0']['y29$50S'] = ![], window['y2S0']['y29$S50'] = 0x2;if (mv53a[a[420142]](a[420410]) != -0x1) {
      if (oj4hwf[a[420393]] >= 0x18) window['y2S0']['y29$S50'] = 0x3;else window['y2S0']['y29$S50'] = 0x2;
    } else {
      if (mv53a[a[420142]](a[420409]) != -0x1) {
        if (oj4hwf[a[420393]] && oj4hwf[a[420393]] >= 0x14) window['y2S0']['y29$S50'] = 0x3;else {
          if (thwd4j[a[420142]](a[420412]) != -0x1 || thwd4j[a[420142]](a[420413]) != -0x1 || thwd4j[a[420142]](a[420414]) != -0x1 || thwd4j[a[420142]](a[420415]) != -0x1 || thwd4j[a[420142]](a[420416]) != -0x1) window['y2S0']['y29$S50'] = 0x2;else window['y2S0']['y29$S50'] = 0x3;
        }
      } else window['y2S0']['y29$S50'] = 0x2;
    }console[a[420049]](a[420417] + window['y2S0']['y29$50S'] + a[420418] + window['y2S0']['y29$S50']);
  } }), wx[a[420242]]({ 'success': function (lsc92k) {
    console[a[420049]](a[420419] + lsc92k[a[420244]] + a[420420] + lsc92k[a[420246]]);
  } }), wx[a[420421]]({ 'success': function (o7_) {
    console[a[420049]](a[420422] + o7_[a[420423]]);
  } }), wx[a[420424]]({ 'keepScreenOn': !![] }), wx[a[420425]](function (_7lc8) {
  console[a[420049]](a[420422] + _7lc8[a[420423]] + a[420426] + _7lc8[a[420427]]);
}), wx[a[420216]](function (o4hjwf) {
  window['y25$'] = o4hjwf, window['y20$5'] && window['y25$'] && (console[a[420070]](a[420217] + window['y25$'][a[420218]]), window['y20$5'](window['y25$']), window['y25$'] = null);
}), window[a[420428]] = 0x0, window['y29S50$'] = 0x0, window[a[420429]] = null, wx[a[420430]](function () {
  window['y29S50$']++;var mua35 = Date[a[420036]]();(window[a[420428]] == 0x0 || mua35 - window[a[420428]] > 0x1d4c0) && (console[a[420094]](a[420431]), wx[a[420432]]());if (window['y29S50$'] >= 0x2) {
    window['y29S50$'] = 0x0, console[a[420088]](a[420433]), wx[a[420434]]('0', 0x1);if (window['y2S0'] && window['y2S0'][a[420043]]) window['y2S0$'](a[420435], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});