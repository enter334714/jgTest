var a = wx.$y;
import ysc879l from '../yyabyysdk/y7sdky.js';window[a[420001]] = { 'wxVersion': window[a[420002]][a[420003]] }, window[a[420004]] = ![], window['y20S'] = 0x1, window[a[420005]] = 0x1, window['y25S0'] = !![], window[a[420006]] = !![], window['y29$5S0'] = '', window['y2S0'] = { 'base_cdn': a[420007], 'cdn': a[420007] }, y2S0[a[420008]] = {}, y2S0[a[420009]] = '0', y2S0[a[420010]] = window[a[420001]][a[420011]], y2S0[a[420012]] = '', y2S0['os'] = '1', y2S0[a[420013]] = a[420014], y2S0[a[420015]] = a[420016], y2S0[a[420017]] = a[420018], y2S0[a[420019]] = a[420020], y2S0[a[420021]] = a[420022], y2S0[a[420023]] = '1', y2S0[a[420024]] = '', y2S0[a[420025]] = '', y2S0[a[420026]] = 0x0, y2S0[a[420027]] = {}, y2S0[a[420028]] = parseInt(y2S0[a[420023]]), y2S0[a[420029]] = y2S0[a[420023]], y2S0[a[420030]] = {}, y2S0['y2$S'] = a[420031], y2S0[a[420032]] = ![], y2S0[a[420033]] = a[420034], y2S0[a[420035]] = Date[a[420036]](), y2S0[a[420037]] = a[420038], y2S0[a[420039]] = '_a', y2S0[a[420040]] = 0x2, y2S0[a[420041]] = 0x7c1, y2S0[a[420011]] = window[a[420001]][a[420011]], y2S0[a[420042]] = ![], y2S0[a[420043]] = ![], y2S0[a[420044]] = ![], y2S0[a[420045]] = ![], window['y250S'] = 0x5, window['y250'] = ![], window['y205'] = ![], window['y2S50'] = ![], window[a[420046]] = ![], window[a[420047]] = ![], window['y2S05'] = ![], window['y25S'] = ![], window['y2S5'] = ![], window['y205S'] = ![], window[a[420048]] = function (_fo8j7) {
  console[a[420049]](a[420048], _fo8j7), wx[a[420050]]({}), wx[a[420051]]({ 'title': a[420052], 'content': _fo8j7, 'success'(rvzy0) {
      if (rvzy0[a[420053]]) console[a[420049]](a[420054]);else rvzy0[a[420055]] && console[a[420049]](a[420056]);
    } });
}, window['y2$5S0'] = function (o7fj_8) {
  console[a[420049]](a[420057], o7fj_8), y2$S05(), wx[a[420051]]({ 'title': a[420052], 'content': o7fj_8, 'confirmText': a[420058], 'cancelText': a[420059], 'success'(vrz03) {
      if (vrz03[a[420053]]) window['y2S$']();else vrz03[a[420055]] && (console[a[420049]](a[420060]), wx[a[420061]]({}));
    } });
}, window[a[420062]] = function (qn2g$i) {
  console[a[420049]](a[420062], qn2g$i), wx[a[420051]]({ 'title': a[420052], 'content': qn2g$i, 'confirmText': a[420063], 'showCancel': ![], 'complete'(nkg9$2) {
      console[a[420049]](a[420060]), wx[a[420061]]({});
    } });
}, window['y2$50S'] = ![], window['y2$S50'] = function (zy0xr) {
  window['y2$50S'] = !![], wx[a[420064]](zy0xr);
}, window['y2$S05'] = function () {
  window['y2$50S'] && (window['y2$50S'] = ![], wx[a[420050]]({}));
}, window['y2$05S'] = function (_o87fl) {
  window[a[420065]][a[420066]]['y2$05S'](_o87fl);
}, window[a[420067]] = function (jw4hof, $qip) {
  ysc879l[a[420067]](jw4hof, function (n92$kg) {
    n92$kg && n92$kg[a[420068]] ? n92$kg[a[420068]][a[420069]] == 0x1 ? $qip(!![]) : ($qip(![]), console[a[420070]](a[420071] + n92$kg[a[420068]][a[420072]])) : console[a[420049]](a[420067], n92$kg);
  });
}, window['y2$0S5'] = function (jf_h) {
  console[a[420049]](a[420073], jf_h);
}, window['y2$S0'] = function (c9n$k) {}, window['y2$0S'] = function (hfj_o4, l2sc9k, dhj4t) {}, window['y2$0'] = function (rz0yxv) {
  console[a[420049]](a[420074], rz0yxv), window[a[420065]][a[420066]][a[420075]](), window[a[420065]][a[420066]][a[420076]](), window[a[420065]][a[420066]][a[420077]]();
}, window['y20$'] = function (qnpgi$) {
  window['y2$5S0'](a[420078]);var u1w4dt = { 'id': window['y2S0'][a[420079]], 'role': window['y2S0'][a[420080]], 'level': window['y2S0'][a[420081]], 'account': window['y2S0'][a[420082]], 'version': window['y2S0'][a[420041]], 'cdn': window['y2S0'][a[420083]], 'pkgName': window['y2S0'][a[420024]], 'gamever': window[a[420002]][a[420003]], 'serverid': window['y2S0'][a[420030]] ? window['y2S0'][a[420030]][a[420084]] : 0x0, 'systemInfo': window[a[420085]], 'error': a[420086], 'stack': qnpgi$ ? qnpgi$ : a[420078] },
      sc9nk = JSON[a[420087]](u1w4dt);console[a[420088]](a[420089] + sc9nk), window['y2$S'](sc9nk);
}, window['y2S$0'] = function (v3r60y) {
  var i$pqng = JSON[a[420090]](v3r60y);i$pqng[a[420091]] = window[a[420002]][a[420003]], i$pqng[a[420092]] = window['y2S0'][a[420030]] ? window['y2S0'][a[420030]][a[420084]] : 0x0, i$pqng[a[420085]] = window[a[420085]];var ht4jdw = JSON[a[420087]](i$pqng);console[a[420088]](a[420093] + ht4jdw), window['y2$S'](ht4jdw);
}, window['y2S0$'] = function (lks2, u4tw) {
  var _87fls = { 'id': window['y2S0'][a[420079]], 'role': window['y2S0'][a[420080]], 'level': window['y2S0'][a[420081]], 'account': window['y2S0'][a[420082]], 'version': window['y2S0'][a[420041]], 'cdn': window['y2S0'][a[420083]], 'pkgName': window['y2S0'][a[420024]], 'gamever': window[a[420002]][a[420003]], 'serverid': window['y2S0'][a[420030]] ? window['y2S0'][a[420030]][a[420084]] : 0x0, 'systemInfo': window[a[420085]], 'error': lks2, 'stack': u4tw },
      mu65a = JSON[a[420087]](_87fls);console[a[420094]](a[420095] + mu65a), window['y2$S'](mu65a);
}, window['y2$S'] = function (oh_jf4) {
  if (window['y2S0'][a[420096]] == a[420097]) return;var t4hjdw = y2S0['y2$S'] + a[420098] + y2S0[a[420082]];wx[a[420099]]({ 'url': t4hjdw, 'method': a[420100], 'data': oh_jf4, 'header': { 'content-type': a[420101], 'cache-control': a[420102] }, 'success': function (yva356) {
      DEBUG && console[a[420049]](a[420103], t4hjdw, oh_jf4, yva356);
    }, 'fail': function (_jh4of) {
      DEBUG && console[a[420049]](a[420103], t4hjdw, oh_jf4, _jh4of);
    }, 'complete': function () {} });
}, window[a[420104]] = function () {
  function mua356() {
    return ((0x1 + Math[a[420105]]()) * 0x10000 | 0x0)[a[420106]](0x10)[a[420107]](0x1);
  }return mua356() + mua356() + '-' + mua356() + '-' + mua356() + '-' + mua356() + '+' + mua356() + mua356() + mua356();
}, window['y2S$'] = function () {
  console[a[420049]](a[420108]);var mv563a = ysc879l[a[420109]]();y2S0[a[420029]] = mv563a[a[420110]], y2S0[a[420028]] = mv563a[a[420110]], y2S0[a[420023]] = mv563a[a[420110]], y2S0[a[420024]] = mv563a[a[420111]];var l9csk = { 'game_ver': y2S0[a[420010]] };y2S0[a[420025]] = this[a[420104]](), y2$S50({ 'title': a[420112] }), ysc879l[a[420113]](l9csk, this['y20$S'][a[420114]](this));
}, window['y20$S'] = function (yrz3) {
  var ngik$2 = yrz3[a[420115]];console[a[420049]](a[420116] + ngik$2 + a[420117] + (ngik$2 == 0x1) + a[420118] + yrz3[a[420003]] + a[420119] + window[a[420001]][a[420011]]);if (!yrz3[a[420003]] || window['y2950$S'](window[a[420001]][a[420011]], yrz3[a[420003]]) < 0x0) console[a[420049]](a[420120]), y2S0[a[420015]] = a[420121], y2S0[a[420017]] = a[420122], y2S0[a[420019]] = a[420123], y2S0[a[420083]] = a[420124], y2S0[a[420125]] = a[420126], y2S0[a[420127]] = 'yy', y2S0[a[420042]] = ![];else window['y2950$S'](window[a[420001]][a[420011]], yrz3[a[420003]]) == 0x0 ? (console[a[420049]](a[420128]), y2S0[a[420015]] = a[420016], y2S0[a[420017]] = a[420018], y2S0[a[420019]] = a[420020], y2S0[a[420083]] = a[420129], y2S0[a[420125]] = a[420126], y2S0[a[420127]] = a[420130], y2S0[a[420042]] = !![]) : (console[a[420049]](a[420131]), y2S0[a[420015]] = a[420016], y2S0[a[420017]] = a[420018], y2S0[a[420019]] = a[420020], y2S0[a[420083]] = a[420129], y2S0[a[420125]] = a[420126], y2S0[a[420127]] = a[420130], y2S0[a[420042]] = ![]);y2S0[a[420026]] = config[a[420132]] ? config[a[420132]] : 0x0, this['y25S$0'](), this['y25S0$'](), window[a[420133]] = 0x5, y2$S50({ 'title': a[420134] }), ysc879l[a[420135]](this['y20S$'][a[420114]](this));
}, window[a[420133]] = 0x5, window['y20S$'] = function (nk29$g, lsc98) {
  if (nk29$g == 0x0 && lsc98 && lsc98[a[420136]]) {
    y2S0[a[420137]] = lsc98[a[420136]];var s2ckn = this;y2$S50({ 'title': a[420138] }), sendApi(y2S0[a[420015]], a[420139], { 'platform': y2S0[a[420013]], 'partner_id': y2S0[a[420023]], 'token': lsc98[a[420136]], 'game_pkg': y2S0[a[420024]], 'deviceId': y2S0[a[420025]], 'scene': a[420140] + y2S0[a[420026]] }, this['y25$S0'][a[420114]](this), y250S, y20$);
  } else lsc98 && lsc98[a[420141]] && window[a[420133]] > 0x0 && (lsc98[a[420141]][a[420142]](a[420143]) != -0x1 || lsc98[a[420141]][a[420142]](a[420144]) != -0x1 || lsc98[a[420141]][a[420142]](a[420145]) != -0x1 || lsc98[a[420141]][a[420142]](a[420146]) != -0x1 || lsc98[a[420141]][a[420142]](a[420147]) != -0x1 || lsc98[a[420141]][a[420142]](a[420148]) != -0x1) ? (window[a[420133]]--, ysc879l[a[420135]](this['y20S$'][a[420114]](this))) : (window['y2S0$'](a[420149], JSON[a[420087]]({ 'status': nk29$g, 'data': lsc98 })), window['y2$5S0'](a[420150] + (lsc98 && lsc98[a[420141]] ? '，' + lsc98[a[420141]] : '')));
}, window['y25$S0'] = function (j7_ofh) {
  if (!j7_ofh) {
    window['y2S0$'](a[420151], a[420152]), window['y2$5S0'](a[420153]);return;
  }if (j7_ofh[a[420069]] != a[420154]) {
    window['y2S0$'](a[420151], JSON[a[420087]](j7_ofh)), window['y2$5S0'](a[420155] + j7_ofh[a[420069]]);return;
  }y2S0[a[420156]] = String(j7_ofh[a[420082]]), y2S0[a[420082]] = String(j7_ofh[a[420082]]), y2S0[a[420157]] = String(j7_ofh[a[420157]]), y2S0[a[420029]] = String(j7_ofh[a[420157]]), y2S0[a[420158]] = String(j7_ofh[a[420158]]), y2S0[a[420159]] = String(j7_ofh[a[420160]]), y2S0[a[420161]] = String(j7_ofh[a[420162]]), y2S0[a[420160]] = '';var l2k9s = this;y2$S50({ 'title': a[420163] }), sendApi(y2S0[a[420015]], a[420164], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, l2k9s['y25$0S'][a[420114]](l2k9s), y250S, y20$);
}, window['y25$0S'] = function (v0ryxz) {
  if (!v0ryxz) {
    window['y2$5S0'](a[420165]);return;
  }if (v0ryxz[a[420069]] != a[420154]) {
    window['y2$5S0'](a[420166] + v0ryxz[a[420069]]);return;
  }if (!v0ryxz[a[420068]] || v0ryxz[a[420068]][a[420167]] == 0x0) {
    window['y2$5S0'](a[420168]);return;
  }y2S0[a[420169]] = v0ryxz[a[420170]], y2S0[a[420030]] = { 'server_id': String(v0ryxz[a[420068]][0x0][a[420084]]), 'server_name': String(v0ryxz[a[420068]][0x0][a[420171]]), 'entry_ip': v0ryxz[a[420068]][0x0][a[420172]], 'entry_port': parseInt(v0ryxz[a[420068]][0x0][a[420173]]), 'status': y2S5$(v0ryxz[a[420068]][0x0]), 'start_time': v0ryxz[a[420068]][0x0][a[420174]], 'cdn': y2S0[a[420083]] }, this['y20S5$']();
}, window['y20S5$'] = function () {
  if (y2S0[a[420169]] == 0x1) {
    var r6vy = y2S0[a[420030]][a[420175]];if (r6vy === -0x1 || r6vy === 0x0) {
      window['y2$5S0'](r6vy === -0x1 ? a[420176] : a[420177]);return;
    }y20$5S(0x0, y2S0[a[420030]][a[420084]]), window[a[420065]][a[420066]][a[420178]](y2S0[a[420169]]);
  } else window[a[420065]][a[420066]][a[420179]](), y2$S05();window['y2S5'] = !![], window['y205S$'](), window['y20S$5']();
}, window['y25S$0'] = function () {
  sendApi(y2S0[a[420015]], a[420180], { 'game_pkg': y2S0[a[420024]], 'version_name': y2S0[a[420127]] }, this[a[420181]][a[420114]](this), y250S, y20$);
}, window[a[420181]] = function (ohw4t) {
  if (!ohw4t) {
    window['y2$5S0'](a[420182]);return;
  }if (ohw4t[a[420069]] != a[420154]) {
    window['y2$5S0'](a[420183] + ohw4t[a[420069]]);return;
  }if (!ohw4t[a[420068]] || !ohw4t[a[420068]][a[420010]]) {
    window['y2$5S0'](a[420184] + (ohw4t[a[420068]] && ohw4t[a[420068]][a[420010]]));return;
  }ohw4t[a[420068]][a[420185]] && ohw4t[a[420068]][a[420185]][a[420167]] > 0xa && (y2S0[a[420186]] = ohw4t[a[420068]][a[420185]], y2S0[a[420083]] = ohw4t[a[420068]][a[420185]]), ohw4t[a[420068]][a[420010]] && (y2S0[a[420041]] = ohw4t[a[420068]][a[420010]]), console[a[420070]](a[420187] + y2S0[a[420041]] + a[420188] + y2S0[a[420127]]), window['y2S05'] = !![], window['y205S$'](), window['y20S$5']();
}, window[a[420189]], window['y25S0$'] = function () {
  sendApi(y2S0[a[420015]], a[420190], { 'game_pkg': y2S0[a[420024]] }, this['y250$S'][a[420114]](this), y250S, y20$);
}, window['y250$S'] = function (k2$ni) {
  if (k2$ni[a[420069]] === a[420154] && k2$ni[a[420068]]) {
    window[a[420189]] = k2$ni[a[420068]];for (var $ckn29 in k2$ni[a[420068]]) {
      y2S0[$ckn29] = k2$ni[a[420068]][$ckn29];
    }
  } else console[a[420070]](a[420191] + k2$ni[a[420069]]);window['y25S'] = !![], window['y20S$5']();
}, window[a[420192]] = function ($2cnk, whj4to, k2s, kcl92s, o87_fj, rvx0, ohwjt, m1au, th4jo) {
  o87_fj = String(o87_fj);var wohf4 = ohwjt,
      _4hfjo = m1au;y2S0[a[420008]][o87_fj] = { 'productid': o87_fj, 'productname': wohf4, 'productdesc': _4hfjo, 'roleid': $2cnk, 'rolename': whj4to, 'rolelevel': k2s, 'price': rvx0, 'callback': th4jo }, sendApi(y2S0[a[420019]], a[420193], { 'game_pkg': y2S0[a[420024]], 'server_id': y2S0[a[420030]][a[420084]], 'server_name': y2S0[a[420030]][a[420171]], 'level': k2s, 'uid': y2S0[a[420082]], 'role_id': $2cnk, 'role_name': whj4to, 'product_id': o87_fj, 'product_name': wohf4, 'product_desc': _4hfjo, 'money': rvx0, 'partner_id': y2S0[a[420023]] }, toPayCallBack, y250S, y20$);
}, window[a[420194]] = function (dhwt4j) {
  if (dhwt4j) {
    if (dhwt4j[a[420195]] === 0xc8 || dhwt4j[a[420069]] == a[420154]) {
      var j4hfw = y2S0[a[420008]][String(dhwt4j[a[420196]])];if (j4hfw[a[420197]]) j4hfw[a[420197]](dhwt4j[a[420196]], dhwt4j[a[420198]], -0x1);ysc879l[a[420199]]({ 'cpbill': dhwt4j[a[420198]], 'productid': dhwt4j[a[420196]], 'productname': j4hfw[a[420200]], 'productdesc': j4hfw[a[420201]], 'serverid': y2S0[a[420030]][a[420084]], 'servername': y2S0[a[420030]][a[420171]], 'roleid': j4hfw[a[420202]], 'rolename': j4hfw[a[420203]], 'rolelevel': j4hfw[a[420204]], 'price': j4hfw[a[420205]], 'extension': JSON[a[420087]]({ 'cp_order_id': dhwt4j[a[420198]] }) }, function (c29kl, a6yv03) {
        j4hfw[a[420197]] && c29kl == 0x0 && j4hfw[a[420197]](dhwt4j[a[420196]], dhwt4j[a[420198]], c29kl);console[a[420070]](JSON[a[420087]]({ 'type': a[420206], 'status': c29kl, 'data': dhwt4j, 'role_name': j4hfw[a[420203]] }));if (c29kl === 0x0) {} else {
          if (c29kl === 0x1) {} else {
            if (c29kl === 0x2) {}
          }
        }
      });
    } else alert(dhwt4j[a[420070]]);
  }
}, window['y250S$'] = function () {}, window['y2$50'] = function (oj4_h, sn92c, flo, ya6v03, $c2kn9) {
  ysc879l[a[420207]](y2S0[a[420030]][a[420084]], y2S0[a[420030]][a[420171]] || y2S0[a[420030]][a[420084]], oj4_h, sn92c, flo), sendApi(y2S0[a[420015]], a[420208], { 'game_pkg': y2S0[a[420024]], 'server_id': y2S0[a[420030]][a[420084]], 'role_id': oj4_h, 'uid': y2S0[a[420082]], 'role_name': sn92c, 'role_type': ya6v03, 'level': flo });
}, window['y2$05'] = function (pgnqi$, c9ls2k, qign, jo7_8f, fs8l_, l29sc, _8oj, ik2$g, xzvyr, mtwdu) {
  y2S0[a[420079]] = pgnqi$, y2S0[a[420080]] = c9ls2k, y2S0[a[420081]] = qign, ysc879l[a[420209]](y2S0[a[420030]][a[420084]], y2S0[a[420030]][a[420171]] || y2S0[a[420030]][a[420084]], pgnqi$, c9ls2k, qign), sendApi(y2S0[a[420015]], a[420210], { 'game_pkg': y2S0[a[420024]], 'server_id': y2S0[a[420030]][a[420084]], 'role_id': pgnqi$, 'uid': y2S0[a[420082]], 'role_name': c9ls2k, 'role_type': jo7_8f, 'level': qign, 'evolution': fs8l_ });
}, window['y25$0'] = function (t41hdw, kc8l9, amdu, k$g9, rxzyv, m36av5, twdum, m5t1d, re0zx, f78_) {
  y2S0[a[420079]] = t41hdw, y2S0[a[420080]] = kc8l9, y2S0[a[420081]] = amdu, ysc879l[a[420211]](y2S0[a[420030]][a[420084]], y2S0[a[420030]][a[420171]] || y2S0[a[420030]][a[420084]], t41hdw, kc8l9, amdu), sendApi(y2S0[a[420015]], a[420210], { 'game_pkg': y2S0[a[420024]], 'server_id': y2S0[a[420030]][a[420084]], 'role_id': t41hdw, 'uid': y2S0[a[420082]], 'role_name': kc8l9, 'role_type': k$g9, 'level': amdu, 'evolution': rxzyv });
}, window['y250$'] = function (dm51au) {}, window['y2$5'] = function (f_ohj7) {
  ysc879l[a[420212]](a[420212], function (i$qng) {
    f_ohj7 && f_ohj7(i$qng);
  });
}, window[a[420213]] = function () {
  ysc879l[a[420213]]();
}, window[a[420214]] = function () {
  ysc879l[a[420215]]();
}, window[a[420216]] = function (_fohj7) {
  window['y20$5'] = _fohj7, window['y20$5'] && window['y25$'] && (console[a[420070]](a[420217] + window['y25$'][a[420218]]), window['y20$5'](window['y25$']), window['y25$'] = null);
}, window['y205$'] = function (s987c, _7hofj, $nqig2, a5v6m3) {
  window[a[420219]](a[420220], { 'game_pkg': window['y2S0'][a[420024]], 'role_id': _7hofj, 'server_id': $nqig2 }, a5v6m3);
}, window['y2S$50'] = function (ks9l2, td4jhw) {
  function lk8c9(sc9kl2) {
    var h4wtd = [],
        h4wd1 = [],
        jho4wf = window[a[420002]][a[420221]];for (var k$ing2 in jho4wf) {
      var $kgi2 = Number(k$ing2);(!ks9l2 || !ks9l2[a[420167]] || ks9l2[a[420142]]($kgi2) != -0x1) && (h4wd1[a[420222]](jho4wf[k$ing2]), h4wtd[a[420222]]([$kgi2, 0x3]));
    }window['y2950$S'](window[a[420223]], a[420224]) >= 0x0 ? (console[a[420049]](a[420225]), ysc879l[a[420226]] && ysc879l[a[420226]](h4wd1, function (s89lc7) {
      console[a[420049]](a[420227]), console[a[420049]](s89lc7);if (s89lc7 && s89lc7[a[420141]] == a[420228]) for (var _h4of in jho4wf) {
        if (s89lc7[jho4wf[_h4of]] == a[420229]) {
          var _cls7 = Number(_h4of);for (var csk9n = 0x0; csk9n < h4wtd[a[420167]]; csk9n++) {
            if (h4wtd[csk9n][0x0] == _cls7) {
              h4wtd[csk9n][0x1] = 0x1;break;
            }
          }
        }
      }window['y2950$S'](window[a[420223]], a[420230]) >= 0x0 ? wx[a[420231]]({ 'withSubscriptions': !![], 'success': function (ipg$n) {
          var wht14d = ipg$n[a[420232]][a[420233]];if (wht14d) {
            console[a[420049]](a[420234]), console[a[420049]](wht14d);for (var hjdw4 in jho4wf) {
              if (wht14d[jho4wf[hjdw4]] == a[420229]) {
                var mva563 = Number(hjdw4);for (var y635 = 0x0; y635 < h4wtd[a[420167]]; y635++) {
                  if (h4wtd[y635][0x0] == mva563) {
                    h4wtd[y635][0x1] = 0x2;break;
                  }
                }
              }
            }console[a[420049]](h4wtd), td4jhw && td4jhw(h4wtd);
          } else console[a[420049]](a[420235]), console[a[420049]](ipg$n), console[a[420049]](h4wtd), td4jhw && td4jhw(h4wtd);
        }, 'fail': function () {
          console[a[420049]](a[420236]), console[a[420049]](h4wtd), td4jhw && td4jhw(h4wtd);
        } }) : (console[a[420049]](a[420237] + window[a[420223]]), console[a[420049]](h4wtd), td4jhw && td4jhw(h4wtd));
    })) : (console[a[420049]](a[420238] + window[a[420223]]), console[a[420049]](h4wtd), td4jhw && td4jhw(h4wtd)), wx[a[420239]](lk8c9);
  }wx[a[420240]](lk8c9);
}, window['y2S$05'] = { 'isSuccess': ![], 'level': a[420241], 'isCharging': ![] }, window['y2S5$0'] = function (owj4t) {
  wx[a[420242]]({ 'success': function (v3am) {
      var eyrxz0 = window['y2S$05'];eyrxz0[a[420243]] = !![], eyrxz0[a[420244]] = Number(v3am[a[420244]])[a[420245]](0x0), eyrxz0[a[420246]] = v3am[a[420246]], owj4t && owj4t(eyrxz0[a[420243]], eyrxz0[a[420244]], eyrxz0[a[420246]]);
    }, 'fail': function (o7f_8) {
      console[a[420049]](a[420247], o7f_8[a[420141]]);var n$2c9 = window['y2S$05'];owj4t && owj4t(n$2c9[a[420243]], n$2c9[a[420244]], n$2c9[a[420246]]);
    } });
}, window[a[420219]] = function (oj4whf, hoj4t, u35ma6, f4jh_, th41dw, sckl29, z30rvy, r0xezy) {
  if (f4jh_ == undefined) f4jh_ = 0x1;wx[a[420099]]({ 'url': oj4whf, 'method': z30rvy || a[420248], 'responseType': a[420249], 'data': hoj4t, 'header': { 'content-type': r0xezy || a[420101] }, 'success': function (h4wjdt) {
      DEBUG && console[a[420049]](a[420250], oj4whf, info, h4wjdt);if (h4wjdt && h4wjdt[a[420251]] == 0xc8) {
        var umwt1 = h4wjdt[a[420068]];!sckl29 || sckl29(umwt1) ? u35ma6 && u35ma6(umwt1) : window[a[420252]](oj4whf, hoj4t, u35ma6, f4jh_, th41dw, sckl29, h4wjdt);
      } else window[a[420252]](oj4whf, hoj4t, u35ma6, f4jh_, th41dw, sckl29, h4wjdt);
    }, 'fail': function (xvz0r) {
      DEBUG && console[a[420049]](a[420253], oj4whf, info, xvz0r), window[a[420252]](oj4whf, hoj4t, u35ma6, f4jh_, th41dw, sckl29, xvz0r);
    }, 'complete': function () {} });
}, window[a[420252]] = function (w4jt, um51a6, z0v3y, k8s9cl, $92kg, n$c, av306y) {
  k8s9cl - 0x1 > 0x0 ? setTimeout(function () {
    window[a[420219]](w4jt, um51a6, z0v3y, k8s9cl - 0x1, $92kg, n$c);
  }, 0x3e8) : $92kg && $92kg(JSON[a[420087]]({ 'url': w4jt, 'response': av306y }));
}, window[a[420254]] = function (vzry0x, o87l, um36, l9s2kc, hoj_f, l9s78, ow4t) {
  !um36 && (um36 = {});var ng$ = Math[a[420255]](Date[a[420036]]() / 0x3e8);um36[a[420162]] = ng$, um36[a[420256]] = o87l;var whjo4t = Object[a[420257]](um36)[a[420258]](),
      of_jh7 = '',
      nk9$2g = '';for (var ipqng$ = 0x0; ipqng$ < whjo4t[a[420167]]; ipqng$++) {
    of_jh7 = of_jh7 + (ipqng$ == 0x0 ? '' : '&') + whjo4t[ipqng$] + um36[whjo4t[ipqng$]], nk9$2g = nk9$2g + (ipqng$ == 0x0 ? '' : '&') + whjo4t[ipqng$] + '=' + encodeURIComponent(um36[whjo4t[ipqng$]]);
  }of_jh7 = of_jh7 + y2S0[a[420021]];var yv63a = a[420259] + md5(of_jh7);send(vzry0x + '?' + nk9$2g + (nk9$2g == '' ? '' : '&') + yv63a, null, l9s2kc, hoj_f, l9s78, ow4t || function (i2kg) {
    return i2kg[a[420069]] == a[420154];
  }, null, a[420260]);
}, window['y2S50$'] = function (_8slf7, _ofhj) {
  var mtdwu = 0x0;y2S0[a[420030]] && (mtdwu = y2S0[a[420030]][a[420084]]), sendApi(y2S0[a[420017]], a[420261], { 'partnerId': y2S0[a[420023]], 'gamePkg': y2S0[a[420024]], 'logTime': Math[a[420255]](Date[a[420036]]() / 0x3e8), 'platformUid': y2S0[a[420158]], 'type': _8slf7, 'serverId': mtdwu }, null, 0x2, null, function () {
    return !![];
  });
}, window['y2S0$5'] = function (dt15mu) {
  sendApi(y2S0[a[420015]], a[420262], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, y2S05$, y250S, y20$);
}, window['y2S05$'] = function (gni) {
  if (gni[a[420069]] === a[420154] && gni[a[420068]]) {
    gni[a[420068]][a[420263]]({ 'id': -0x2, 'name': a[420264] }), gni[a[420068]][a[420263]]({ 'id': -0x1, 'name': a[420265] }), y2S0[a[420266]] = gni[a[420068]];if (window[a[420267]]) window[a[420267]][a[420268]]();
  } else y2S0[a[420269]] = ![], window['y2$5S0'](a[420270] + gni[a[420069]]);
}, window['y2$5S'] = function (j4hf) {
  sendApi(y2S0[a[420015]], a[420271], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, y2$S5, y250S, y20$);
}, window['y2$S5'] = function (j7o_8f) {
  y2S0[a[420272]] = ![];if (j7o_8f[a[420069]] === a[420154] && j7o_8f[a[420068]]) {
    for (var pqign = 0x0; pqign < j7o_8f[a[420068]][a[420167]]; pqign++) {
      j7o_8f[a[420068]][pqign][a[420175]] = y2S5$(j7o_8f[a[420068]][pqign]);
    }y2S0[a[420027]][-0x1] = window[a[420273]](j7o_8f[a[420068]]), window[a[420267]][a[420274]](-0x1);
  } else window['y2$5S0'](a[420275] + j7o_8f[a[420069]]);
}, window[a[420276]] = function (s_7fl8) {
  sendApi(y2S0[a[420015]], a[420271], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, s_7fl8, y250S, y20$);
}, window['y25$S'] = function (vr3yz, dw4thj) {
  sendApi(y2S0[a[420015]], a[420277], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]], 'server_group_id': dw4thj }, y25S$, y250S, y20$);
}, window['y25S$'] = function (w1m) {
  y2S0[a[420272]] = ![];if (w1m[a[420069]] === a[420154] && w1m[a[420068]] && w1m[a[420068]][a[420068]]) {
    var dumt = w1m[a[420068]][a[420278]],
        k$c9n = [];for (var yrv30 = 0x0; yrv30 < w1m[a[420068]][a[420068]][a[420167]]; yrv30++) {
      w1m[a[420068]][a[420068]][yrv30][a[420175]] = y2S5$(w1m[a[420068]][a[420068]][yrv30]), (k$c9n[a[420167]] == 0x0 || w1m[a[420068]][a[420068]][yrv30][a[420175]] != 0x0) && (k$c9n[k$c9n[a[420167]]] = w1m[a[420068]][a[420068]][yrv30]);
    }y2S0[a[420027]][dumt] = window[a[420273]](k$c9n), window[a[420267]][a[420274]](dumt);
  } else window['y2$5S0'](a[420279] + w1m[a[420069]]);
}, window['y2950S'] = function ($pqgi) {
  sendApi(y2S0[a[420015]], a[420280], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'version': y2S0[a[420010]], 'game_pkg': y2S0[a[420024]], 'device': y2S0[a[420025]] }, reqServerRecommendCallBack, y250S, y20$);
}, window[a[420281]] = function (cl2) {
  y2S0[a[420272]] = ![];if (cl2[a[420069]] === a[420154] && cl2[a[420068]]) {
    for (var _lfs78 = 0x0; _lfs78 < cl2[a[420068]][a[420167]]; _lfs78++) {
      cl2[a[420068]][_lfs78][a[420175]] = y2S5$(cl2[a[420068]][_lfs78]);
    }y2S0[a[420027]][-0x2] = window[a[420273]](cl2[a[420068]]), window[a[420267]][a[420274]](-0x2);
  } else alert(a[420282] + cl2[a[420069]]);
}, window[a[420273]] = function (hw4dj) {
  if (!hw4dj && hw4dj[a[420167]] <= 0x0) return hw4dj;for (let kc9s8 = 0x0; kc9s8 < hw4dj[a[420167]]; kc9s8++) {
    hw4dj[kc9s8][a[420283]] && hw4dj[kc9s8][a[420283]] == 0x1 && (hw4dj[kc9s8][a[420171]] += a[420284]);
  }return hw4dj;
}, window['y2S$5'] = function (g$92, $n9c2k) {
  g$92 = g$92 || y2S0[a[420030]][a[420084]], sendApi(y2S0[a[420015]], a[420285], { 'type': '4', 'game_pkg': y2S0[a[420024]], 'server_id': g$92 }, $n9c2k);
}, window[a[420286]] = function (knsc92, sc78_l, kn9$g2, oh4j_f) {
  kn9$g2 = kn9$g2 || y2S0[a[420030]][a[420084]], sendApi(y2S0[a[420015]], a[420287], { 'type': knsc92, 'game_pkg': sc78_l, 'server_id': kn9$g2 }, oh4j_f);
}, window['y2S5$'] = function (wtjd) {
  if (wtjd) {
    if (wtjd[a[420175]] == 0x1) {
      if (wtjd[a[420288]] == 0x1) return 0x2;else return 0x1;
    } else return wtjd[a[420175]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['y20$5S'] = function (s9lck2, z0xey) {
  y2S0[a[420289]] = { 'step': s9lck2, 'server_id': z0xey };var umt1 = this;y2$S50({ 'title': a[420290] }), sendApi(y2S0[a[420015]], a[420291], { 'partner_id': y2S0[a[420023]], 'uid': y2S0[a[420082]], 'game_pkg': y2S0[a[420024]], 'server_id': z0xey, 'platform': y2S0[a[420157]], 'platform_uid': y2S0[a[420158]], 'check_login_time': y2S0[a[420161]], 'check_login_sign': y2S0[a[420159]], 'version_name': y2S0[a[420127]] }, y20$S5, y250S, y20$, function (ofh4w) {
    return ofh4w[a[420069]] == a[420154] || ofh4w[a[420070]] == a[420292] || ofh4w[a[420070]] == a[420293];
  });
}, window['y20$S5'] = function (ign$q) {
  var yv3z0r = this;if (ign$q[a[420069]] === a[420154] && ign$q[a[420068]]) {
    var r6yv = y2S0[a[420030]];r6yv[a[420294]] = y2S0[a[420028]], r6yv[a[420160]] = String(ign$q[a[420068]][a[420295]]), r6yv[a[420035]] = parseInt(ign$q[a[420068]][a[420162]]);if (ign$q[a[420068]][a[420296]]) r6yv[a[420296]] = parseInt(ign$q[a[420068]][a[420296]]);else r6yv[a[420296]] = parseInt(ign$q[a[420068]][a[420084]]);r6yv[a[420297]] = 0x0, r6yv[a[420083]] = y2S0[a[420186]], r6yv[a[420298]] = ign$q[a[420068]][a[420299]], r6yv[a[420300]] = ign$q[a[420068]][a[420300]], console[a[420049]](a[420301] + JSON[a[420087]](r6yv[a[420300]])), y2S0[a[420169]] == 0x1 && r6yv[a[420300]] && r6yv[a[420300]][a[420302]] == 0x1 && (y2S0[a[420303]] = 0x1, window[a[420065]][a[420066]]['y290S']()), y205$S();
  } else y2S0[a[420289]][a[420304]] >= 0x3 ? (y20$(JSON[a[420087]](ign$q)), window['y2$5S0'](a[420305] + ign$q[a[420069]])) : sendApi(y2S0[a[420015]], a[420139], { 'platform': y2S0[a[420013]], 'partner_id': y2S0[a[420023]], 'token': y2S0[a[420137]], 'game_pkg': y2S0[a[420024]], 'deviceId': y2S0[a[420025]], 'scene': a[420140] + y2S0[a[420026]] }, function (hfj_4o) {
    if (!hfj_4o || hfj_4o[a[420069]] != a[420154]) {
      window['y2$5S0'](a[420155] + hfj_4o && hfj_4o[a[420069]]);return;
    }y2S0[a[420159]] = String(hfj_4o[a[420160]]), y2S0[a[420161]] = String(hfj_4o[a[420162]]), setTimeout(function () {
      y20$5S(y2S0[a[420289]][a[420304]] + 0x1, y2S0[a[420289]][a[420084]]);
    }, 0x5dc);
  }, y250S, y20$, function (ckn$2) {
    return ckn$2[a[420069]] == a[420154] || ckn$2[a[420069]] == a[420306];
  });
}, window['y205$S'] = function () {
  ServerLoading[a[420066]][a[420178]](y2S0[a[420169]]), window['y250'] = !![], window['y20S$5']();
}, window['y205S$'] = function () {
  if (window['y205'] && window['y2S50'] && window[a[420046]] && window[a[420047]] && window['y2S05'] && window['y2S5']) {
    if (!window[a[420307]][a[420066]]) {
      console[a[420049]](a[420308] + window[a[420307]][a[420066]]);var twhoj = wx[a[420309]](),
          t51um = twhoj[a[420218]] ? twhoj[a[420218]] : 0x0,
          nig$k = { 'cdn': window['y2S0'][a[420083]], 'spareCdn': window['y2S0'][a[420125]], 'newRegister': window['y2S0'][a[420169]], 'wxPC': window['y2S0'][a[420045]], 'wxIOS': window['y2S0'][a[420043]], 'wxAndroid': window['y2S0'][a[420044]], 'wxParam': { 'limitLoad': window['y2S0']['y29$50S'], 'benchmarkLevel': window['y2S0']['y29$S50'], 'wxFrom': window[a[420002]][a[420132]] == a[420310] ? 0x1 : 0x0, 'wxSDKVersion': window[a[420223]] }, 'configType': window['y2S0'][a[420037]], 'exposeType': window['y2S0'][a[420039]], 'scene': t51um };new window[a[420307]](nig$k, window['y2S0'][a[420041]], window['y29$5S0']);
    }
  }
}, window['y20S$5'] = function () {
  if (window['y205'] && window['y2S50'] && window[a[420046]] && window[a[420047]] && window['y2S05'] && window['y2S5'] && window['y250'] && window['y25S']) {
    y2$S05();if (!y205S) {
      y205S = !![];if (!window[a[420307]][a[420066]]) window['y205S$']();var da5um1 = 0x0,
          v6ay03 = wx[a[420311]]();v6ay03 && (window['y2S0'][a[420312]] && (da5um1 = v6ay03[a[420313]]), console[a[420070]](a[420314] + v6ay03[a[420313]] + a[420315] + v6ay03[a[420316]] + a[420317] + v6ay03[a[420318]] + a[420319] + v6ay03[a[420320]] + a[420321] + v6ay03[a[420322]] + a[420323] + v6ay03[a[420324]]));var vxzy0r = {};for (const j_h in y2S0[a[420030]]) {
        vxzy0r[j_h] = y2S0[a[420030]][j_h];
      }var in$2gq = { 'channel': window['y2S0'][a[420029]], 'account': window['y2S0'][a[420082]], 'userId': window['y2S0'][a[420156]], 'cdn': window['y2S0'][a[420083]], 'data': window['y2S0'][a[420068]], 'package': window['y2S0'][a[420009]], 'newRegister': window['y2S0'][a[420169]], 'pkgName': window['y2S0'][a[420024]], 'partnerId': window['y2S0'][a[420023]], 'platform_uid': window['y2S0'][a[420158]], 'deviceId': window['y2S0'][a[420025]], 'selectedServer': vxzy0r, 'configType': window['y2S0'][a[420037]], 'exposeType': window['y2S0'][a[420039]], 'debugUsers': window['y2S0'][a[420033]], 'wxMenuTop': da5um1, 'wxShield': window['y2S0'][a[420042]] };if (window[a[420189]]) for (var m5dua in window[a[420189]]) {
        in$2gq[m5dua] = window[a[420189]][m5dua];
      }window[a[420307]][a[420066]]['y20S9'](in$2gq);
    }
  } else console[a[420070]](a[420325] + window['y205'] + a[420326] + window['y2S50'] + a[420327] + window[a[420046]] + a[420328] + window[a[420047]] + a[420329] + window['y2S05'] + a[420330] + window['y2S5'] + a[420331] + window['y250'] + a[420332] + window['y25S']);
};