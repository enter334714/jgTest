var a = wx.$y;
require(a[420915]);