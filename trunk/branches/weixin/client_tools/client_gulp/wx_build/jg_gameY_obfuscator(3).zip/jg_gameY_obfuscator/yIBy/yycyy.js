var a = wx.$y;
function y_f7oj() {}function y_78lsf(h4dtw1, n$g29, y306vr, ojt, wfhjo) {
  function mtu1d(uam615) {
    if (uam615 > 0xffff) {
      uam615 -= 0x10000;var $niqgp = 0xd800 + (uam615 >> 0xa),
          dj4t = 0xdc00 + (0x3ff & uam615);return String['fromCharCode']($niqgp, dj4t);
    }return String['fromCharCode'](uam615);
  }function ojh4wf(qpgi$n) {
    var xz0yer = qpgi$n['slice'](0x1, -0x1);return xz0yer in y306vr ? y306vr[xz0yer] : '#' === xz0yer['charAt'](0x0) ? mtu1d(parseInt(xz0yer['substr'](0x1)['replace']('x', '0x'))) : (wfhjo['error']('entity not found:' + qpgi$n), qpgi$n);
  }function m5a61(j78_o) {
    if (j78_o > vzr3) {
      var m3u = h4dtw1['substring'](vzr3, j78_o)['replace'](/&#?\w+;/g, ojh4wf);zyr0e && ow4tjh(vzr3), ojt['characters'](m3u, 0x0, j78_o - vzr3), vzr3 = j78_o;
    }
  }function ow4tjh(m6a5v, dtmu51) {
    for (; m6a5v >= wtmud && (dtmu51 = _jh4['exec'](h4dtw1));) pgqi = dtmu51['index'], wtmud = pgqi + dtmu51[0x0]['length'], zyr0e['lineNumber']++;zyr0e['columnNumber'] = m6a5v - pgqi + 0x1;
  }for (var pgqi = 0x0, wtmud = 0x0, _jh4 = /.*(?:\r\n?|\n)|.*$/g, zyr0e = ojt['locator'], p$in = [{ 'currentNSMap': n$g29 }], yv3 = {}, vzr3 = 0x0;;) {
    try {
      var kc9s2 = h4dtw1['indexOf']('<', vzr3);if (0x0 > kc9s2) {
        if (!h4dtw1['substr'](vzr3)['match'](/^\s*$/)) {
          var wojt4 = ojt['doc'],
              mut15 = wojt4['createTextNode'](h4dtw1['substr'](vzr3));wojt4['appendChild'](mut15), ojt['currentElement'] = mut15;
        }return;
      }switch (kc9s2 > vzr3 && m5a61(kc9s2), h4dtw1['charAt'](kc9s2 + 0x1)) {case '/':
          var i$kgn = h4dtw1['indexOf']('>', kc9s2 + 0x3),
              n2$qg = h4dtw1['substring'](kc9s2 + 0x2, i$kgn),
              ipqgn = p$in['pop']();0x0 > i$kgn ? (n2$qg = h4dtw1['substring'](kc9s2 + 0x2)['replace'](/[\s<].*/, ''), wfhjo['error']('end tag name: ' + n2$qg + ' is not complete:' + ipqgn['tagName']), i$kgn = kc9s2 + 0x1 + n2$qg['length']) : n2$qg['match'](/\s</) && (n2$qg = n2$qg['replace'](/[\s<].*/, ''), wfhjo['error']('end tag name: ' + n2$qg + ' maybe not complete'), i$kgn = kc9s2 + 0x1 + n2$qg['length']);var y630v = ipqgn['localNSMap'],
              jo87_ = ipqgn['tagName'] == n2$qg,
              h41d = jo87_ || ipqgn['tagName'] && ipqgn['tagName']['toLowerCase']() == n2$qg['toLowerCase']();if (h41d) {
            if (ojt['endElement'](ipqgn['uri'], ipqgn['localName'], n2$qg), y630v) {
              for (var admu5 in y630v) ojt['endPrefixMapping'](admu5);
            }jo87_ || wfhjo['fatalError']('end tag name: ' + n2$qg + ' is not match the current start tagName:' + ipqgn['tagName']);
          } else p$in['push'](ipqgn);i$kgn++;break;case '?':
          zyr0e && ow4tjh(kc9s2), i$kgn = ynck$(h4dtw1, kc9s2, ojt);break;case '!':
          zyr0e && ow4tjh(kc9s2), i$kgn = ydhj4wt(h4dtw1, kc9s2, ojt, wfhjo);break;default:
          zyr0e && ow4tjh(kc9s2);var l7_c8 = new ycksl(),
              dm1a5u = p$in[p$in['length'] - 0x1]['currentNSMap'],
              i$kgn = ygq$pi(h4dtw1, kc9s2, l7_c8, dm1a5u, ojh4wf, wfhjo),
              ls9c2k = l7_c8['length'];if (!l7_c8['closed'] && ywof4(h4dtw1, i$kgn, l7_c8['tagName'], yv3) && (l7_c8['closed'] = !0x0, y306vr['nbsp'] || wfhjo['warning']('unclosed xml attribute')), zyr0e && ls9c2k) {
            for (var ot4jwh = yzv0y(zyr0e, {}), l9sc8 = 0x0; ls9c2k > l9sc8; l9sc8++) {
              var fl = l7_c8[l9sc8];ow4tjh(fl['offset']), fl['locator'] = yzv0y(zyr0e, {});
            }ojt['locator'] = ot4jwh, ya56mv(l7_c8, ojt, dm1a5u) && p$in['push'](l7_c8), ojt['locator'] = zyr0e;
          } else ya56mv(l7_c8, ojt, dm1a5u) && p$in['push'](l7_c8);'http://www.w3.org/1999/xhtml' !== l7_c8['uri'] || l7_c8['closed'] ? i$kgn++ : i$kgn = yv5ma3(h4dtw1, i$kgn, l7_c8['tagName'], ojh4wf, ojt);}
    } catch (zxyer0) {
      wfhjo['error']('element parse error: ' + zxyer0), i$kgn = -0x1;
    }i$kgn > vzr3 ? vzr3 = i$kgn : m5a61(Math['max'](kc9s2, vzr3) + 0x1);
  }
}function yzv0y(twjoh4, c9ksl2) {
  return c9ksl2['lineNumber'] = twjoh4['lineNumber'], c9ksl2['columnNumber'] = twjoh4['columnNumber'], c9ksl2;
}function ygq$pi(jwh4fo, hw4tjd, zy03r, du1tm5, j_hf4o, um1w) {
  for (var $gpnqi, amv, k8s9lc = ++hw4tjd, reyx0z = yyvrz3;;) {
    var td4wj = jwh4fo['charAt'](k8s9lc);switch (td4wj) {case '=':
        if (reyx0z === yd4wtu1) $gpnqi = jwh4fo['slice'](hw4tjd, k8s9lc), reyx0z = yhtjwo4;else {
          if (reyx0z !== yvz03r) throw new Error('attribute equal must after attrName');reyx0z = yhtjwo4;
        }break;case '\x27':case '\x22':
        if (reyx0z === yhtjwo4 || reyx0z === yd4wtu1) {
          if (reyx0z === yd4wtu1 && (um1w['warning']('attribute value must after "="'), $gpnqi = jwh4fo['slice'](hw4tjd, k8s9lc)), hw4tjd = k8s9lc + 0x1, k8s9lc = jwh4fo['indexOf'](td4wj, hw4tjd), !(k8s9lc > 0x0)) throw new Error('attribute value no end \'' + td4wj + '\' match');amv = jwh4fo['slice'](hw4tjd, k8s9lc)['replace'](/&#?\w+;/g, j_hf4o), zy03r['add']($gpnqi, amv, hw4tjd - 0x1), reyx0z = ysl_7;
        } else {
          if (reyx0z != yjhdt4) throw new Error('attribute value must after "="');amv = jwh4fo['slice'](hw4tjd, k8s9lc)['replace'](/&#?\w+;/g, j_hf4o), zy03r['add']($gpnqi, amv, hw4tjd), um1w['warning']('attribute "' + $gpnqi + '" missed start quot(' + td4wj + ')!!'), hw4tjd = k8s9lc + 0x1, reyx0z = ysl_7;
        }break;case '/':
        switch (reyx0z) {case yyvrz3:
            zy03r['setTagName'](jwh4fo['slice'](hw4tjd, k8s9lc));case ysl_7:case ykc8s9:case yutm1d5:
            reyx0z = yutm1d5, zy03r['closed'] = !0x0;case yjhdt4:case yd4wtu1:case yvz03r:
            break;default:
            throw new Error('attribute invalid close char(\'/\')');}break;case '':
        return um1w['error']('unexpected end of input'), reyx0z == yyvrz3 && zy03r['setTagName'](jwh4fo['slice'](hw4tjd, k8s9lc)), k8s9lc;case '>':
        switch (reyx0z) {case yyvrz3:
            zy03r['setTagName'](jwh4fo['slice'](hw4tjd, k8s9lc));case ysl_7:case ykc8s9:case yutm1d5:
            break;case yjhdt4:case yd4wtu1:
            amv = jwh4fo['slice'](hw4tjd, k8s9lc), '/' === amv['slice'](-0x1) && (zy03r['closed'] = !0x0, amv = amv['slice'](0x0, -0x1));case yvz03r:
            reyx0z === yvz03r && (amv = $gpnqi), reyx0z == yjhdt4 ? (um1w['warning']('attribute "' + amv + '" missed quot(")!!'), zy03r['add']($gpnqi, amv['replace'](/&#?\w+;/g, j_hf4o), hw4tjd)) : ('http://www.w3.org/1999/xhtml' === du1tm5[''] && amv['match'](/^(?:disabled|checked|selected)$/i) || um1w['warning']('attribute "' + amv + '" missed value!! "' + amv + '" instead!!'), zy03r['add'](amv, amv, hw4tjd));break;case yhtjwo4:
            throw new Error('attribute value missed!!');}return k8s9lc;case '\u0080':
        td4wj = '\x20';default:
        if ('\x20' >= td4wj) switch (reyx0z) {case yyvrz3:
            zy03r['setTagName'](jwh4fo['slice'](hw4tjd, k8s9lc)), reyx0z = ykc8s9;break;case yd4wtu1:
            $gpnqi = jwh4fo['slice'](hw4tjd, k8s9lc), reyx0z = yvz03r;break;case yjhdt4:
            var amv = jwh4fo['slice'](hw4tjd, k8s9lc)['replace'](/&#?\w+;/g, j_hf4o);um1w['warning']('attribute "' + amv + '" missed quot(")!!'), zy03r['add']($gpnqi, amv, hw4tjd);case ysl_7:
            reyx0z = ykc8s9;} else switch (reyx0z) {case yvz03r:
            {
              zy03r['tagName'];
            }'http://www.w3.org/1999/xhtml' === du1tm5[''] && $gpnqi['match'](/^(?:disabled|checked|selected)$/i) || um1w['warning']('attribute "' + $gpnqi + '" missed value!! "' + $gpnqi + '" instead2!!'), zy03r['add']($gpnqi, $gpnqi, hw4tjd), hw4tjd = k8s9lc, reyx0z = yd4wtu1;break;case ysl_7:
            um1w['warning']('attribute space is required"' + $gpnqi + '\x22!!');case ykc8s9:
            reyx0z = yd4wtu1, hw4tjd = k8s9lc;break;case yhtjwo4:
            reyx0z = yjhdt4, hw4tjd = k8s9lc;break;case yutm1d5:
            throw new Error('elements closed character \'/\' and \'>\' must be connected to');}}k8s9lc++;
  }
}function ya56mv(k2lsc, h7jof_, twjh4) {
  for (var vyrz = k2lsc['tagName'], r6v0y = null, v653ya = k2lsc['length']; v653ya--;) {
    var c8k9 = k2lsc[v653ya],
        h4djtw = c8k9['qName'],
        adm1u5 = c8k9['value'],
        f87l_s = h4djtw['indexOf'](':');if (f87l_s > 0x0) var y0erxz = c8k9['prefix'] = h4djtw['slice'](0x0, f87l_s),
        s87l_c = h4djtw['slice'](f87l_s + 0x1),
        y03vz = 'xmlns' === y0erxz && s87l_c;else s87l_c = h4djtw, y0erxz = null, y03vz = 'xmlns' === h4djtw && '';c8k9['localName'] = s87l_c, y03vz !== !0x1 && (null == r6v0y && (r6v0y = {}, yw4ht(twjh4, twjh4 = {})), twjh4[y03vz] = r6v0y[y03vz] = adm1u5, c8k9['uri'] = 'http://www.w3.org/2000/xmlns/', h7jof_['startPrefixMapping'](y03vz, adm1u5));
  }for (var v653ya = k2lsc['length']; v653ya--;) {
    c8k9 = k2lsc[v653ya];var y0erxz = c8k9['prefix'];y0erxz && ('xml' === y0erxz && (c8k9['uri'] = 'http://www.w3.org/XML/1998/namespace'), 'xmlns' !== y0erxz && (c8k9['uri'] = twjh4[y0erxz || '']));
  }var f87l_s = vyrz['indexOf'](':');f87l_s > 0x0 ? (y0erxz = k2lsc['prefix'] = vyrz['slice'](0x0, f87l_s), s87l_c = k2lsc['localName'] = vyrz['slice'](f87l_s + 0x1)) : (y0erxz = null, s87l_c = k2lsc['localName'] = vyrz);var sk2lc = k2lsc['uri'] = twjh4[y0erxz || ''];if (h7jof_['startElement'](sk2lc, s87l_c, vyrz, k2lsc), !k2lsc['closed']) return k2lsc['currentNSMap'] = twjh4, k2lsc['localNSMap'] = r6v0y, !0x0;if (h7jof_['endElement'](sk2lc, s87l_c, vyrz), r6v0y) {
    for (y0erxz in r6v0y) h7jof_['endPrefixMapping'](y0erxz);
  }
}function yv5ma3(gki$n2, _j7hf, kn9$, f_87, xryez) {
  if (/^(?:script|textarea)$/i['test'](kn9$)) {
    var n2ck9$ = gki$n2['indexOf']('</' + kn9$ + '>', _j7hf),
        o_j = gki$n2['substring'](_j7hf + 0x1, n2ck9$);if (/[&<]/['test'](o_j)) return (/^script$/i['test'](kn9$) ? (xryez['characters'](o_j, 0x0, o_j['length']), n2ck9$) : (o_j = o_j['replace'](/&#?\w+;/g, f_87), xryez['characters'](o_j, 0x0, o_j['length']), n2ck9$)
    );
  }return _j7hf + 0x1;
}function ywof4(xre, q2gi$, k2s, k92$nc) {
  var nk$9g2 = k92$nc[k2s];return null == nk$9g2 && (nk$9g2 = xre['lastIndexOf']('</' + k2s + '>'), q2gi$ > nk$9g2 && (nk$9g2 = xre['lastIndexOf']('</' + k2s)), k92$nc[k2s] = nk$9g2), q2gi$ > nk$9g2;
}function yw4ht(ng2$ik, um6a15) {
  for (var _hfo7j in ng2$ik) um6a15[_hfo7j] = ng2$ik[_hfo7j];
}function ydhj4wt(sckn29, sf8_l, k92n$, g2$nq) {
  var qin2g$ = sckn29['charAt'](sf8_l + 0x2);switch (qin2g$) {case '-':
      if ('-' === sckn29['charAt'](sf8_l + 0x3)) {
        var othj4w = sckn29['indexOf']('-->', sf8_l + 0x4);return othj4w > sf8_l ? (k92n$['comment'](sckn29, sf8_l + 0x4, othj4w - sf8_l - 0x4), othj4w + 0x3) : (g2$nq['error']('Unclosed comment'), -0x1);
      }return -0x1;default:
      if ('CDATA[' == sckn29['substr'](sf8_l + 0x3, 0x6)) {
        var othj4w = sckn29['indexOf'](']]>', sf8_l + 0x9);return k92n$['startCDATA'](), k92n$['characters'](sckn29, sf8_l + 0x9, othj4w - sf8_l - 0x9), k92n$['endCDATA'](), othj4w + 0x3;
      }var a5v6m = ywudt41(sckn29, sf8_l),
          o8fl7_ = a5v6m['length'];if (o8fl7_ > 0x1 && /!doctype/i['test'](a5v6m[0x0][0x0])) {
        var jf4h_ = a5v6m[0x1][0x0],
            kgi$2 = o8fl7_ > 0x3 && /^public$/i['test'](a5v6m[0x2][0x0]) && a5v6m[0x3][0x0],
            ry036 = o8fl7_ > 0x4 && a5v6m[0x4][0x0],
            in$qp = a5v6m[o8fl7_ - 0x1];return k92n$['startDTD'](jf4h_, kgi$2 && kgi$2['replace'](/^(['"])(.*?)\1$/, '$2'), ry036 && ry036['replace'](/^(['"])(.*?)\1$/, '$2')), k92n$['endDTD'](), in$qp['index'] + in$qp[0x0]['length'];
      }}return -0x1;
}function ynck$(f4o, _lf8, cs7l_) {
  var _f78 = f4o['indexOf']('?>', _lf8);if (_f78) {
    var dh14 = f4o['substring'](_lf8, _f78)['match'](/^<\?(\S*)\s*([\s\S]*?)\s*$/);if (dh14) {
      {
        dh14[0x0]['length'];
      }return cs7l_['processingInstruction'](dh14[0x1], dh14[0x2]), _f78 + 0x2;
    }return -0x1;
  }return -0x1;
}function ycksl() {}function ysl29k(ni2kg, c_sl8) {
  return ni2kg['__proto__'] = c_sl8, ni2kg;
}function ywudt41(rz0xvy, r60y3v) {
  var uw1t4,
      fhj4w = [],
      u1ma56 = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;for (u1ma56['lastIndex'] = r60y3v, u1ma56['exec'](rz0xvy); uw1t4 = u1ma56['exec'](rz0xvy);) if (fhj4w['push'](uw1t4), uw1t4[0x1]) return fhj4w;
}var yvy5 = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    ys_f7l = new RegExp('[\\-\\.0-9' + yvy5['source']['slice'](0x1, -0x1) + '\\u00B7\\u0300-\\u036F\\u203F-\\u2040]'),
    yum1da = new RegExp('^' + yvy5['source'] + ys_f7l['source'] + '*(?::' + yvy5['source'] + ys_f7l['source'] + '*)?$'),
    yyvrz3 = 0x0,
    yd4wtu1 = 0x1,
    yvz03r = 0x2,
    yhtjwo4 = 0x3,
    yjhdt4 = 0x4,
    ysl_7 = 0x5,
    ykc8s9 = 0x6,
    yutm1d5 = 0x7;y_f7oj['prototype'] = { 'parse': function (gqn2, y6vr, $9nkg) {
    var _78csl = this['domBuilder'];_78csl['startDocument'](), yw4ht(y6vr, y6vr = {}), y_78lsf(gqn2, y6vr, $9nkg, _78csl, this['errorHandler']), _78csl['endDocument']();
  } }, ycksl['prototype'] = { 'setTagName': function (skc89) {
    if (!yum1da['test'](skc89)) throw new Error('invalid tagName:' + skc89);this['tagName'] = skc89;
  }, 'add': function (qng$i2, jtw4ho, zvy0r) {
    if (!yum1da['test'](qng$i2)) throw new Error('invalid attribute:' + qng$i2);this[this['length']++] = { 'qName': qng$i2, 'value': jtw4ho, 'offset': zvy0r };
  }, 'length': 0x0, 'getLocalName': function (g2n$9k) {
    return this[g2n$9k]['localName'];
  }, 'getLocator': function (_ol87f) {
    return this[_ol87f]['locator'];
  }, 'getQName': function (fojh) {
    return this[fojh]['qName'];
  }, 'getURI': function (zryv03) {
    return this[zryv03]['uri'];
  }, 'getValue': function (nkc$92) {
    return this[nkc$92]['value'];
  } }, ysl29k({}, ysl29k['prototype']) instanceof ysl29k || (ysl29k = function (u1tw, otj) {
  function l8sc97() {}l8sc97['prototype'] = otj, l8sc97 = new l8sc97();for (otj in u1tw) l8sc97[otj] = u1tw[otj];return l8sc97;
}), exports['XMLReader'] = y_f7oj;