var a = wx.$y;
import ym5a6v3 from '../yyabyysdk/y7sdky.js';window[a[420916]] = { 'wxVersion': window[a[420917]][a[420918]] }, window[a[420919]] = ![], window['y20S'] = 0x1, window[a[420920]] = 0x1, window['y25S0'] = !![], window[a[420921]] = !![], window['y29$5S0'] = '', window['y2S0'] = { 'base_cdn': a[420922], 'cdn': a[420922] }, y2S0[a[420923]] = {}, y2S0[a[420304]] = '0', y2S0[a[420924]] = window[a[420916]][a[420925]], y2S0[a[420926]] = '', y2S0['os'] = '1', y2S0[a[420927]] = a[420928], y2S0[a[420929]] = a[420930], y2S0[a[420931]] = a[420932], y2S0[a[420933]] = a[420934], y2S0[a[420935]] = a[420936], y2S0[a[420937]] = '1', y2S0[a[420938]] = '', y2S0[a[420939]] = '', y2S0[a[420940]] = 0x0, y2S0[a[420941]] = {}, y2S0[a[420942]] = parseInt(y2S0[a[420937]]), y2S0[a[420943]] = y2S0[a[420937]], y2S0[a[420944]] = {}, y2S0['y2$S'] = a[420945], y2S0[a[420946]] = ![], y2S0[a[420947]] = a[420948], y2S0[a[420949]] = Date[a[420950]](), y2S0[a[420951]] = a[420952], y2S0[a[420953]] = '_a', y2S0[a[420954]] = 0x2, y2S0[a[420955]] = 0x7c1, y2S0[a[420925]] = window[a[420916]][a[420925]], y2S0[a[420956]] = ![], y2S0[a[420957]] = ![], y2S0[a[420958]] = ![], y2S0[a[420959]] = ![], window['y250S'] = 0x5, window['y250'] = ![], window['y205'] = ![], window['y2S50'] = ![], window[a[420960]] = ![], window[a[420961]] = ![], window['y2S05'] = ![], window['y25S'] = ![], window['y2S5'] = ![], window['y205S'] = ![], window[a[420962]] = function (w1t4dh) {
  console[a[420225]](a[420962], w1t4dh), wx[a[420963]]({}), wx[a[420964]]({ 'title': a[420965], 'content': w1t4dh, 'success'(ckl8s9) {
      if (ckl8s9[a[420966]]) console[a[420225]](a[420967]);else ckl8s9[a[420968]] && console[a[420225]](a[420969]);
    } });
}, window['y2$5S0'] = function (sck8l) {
  console[a[420225]](a[420970], sck8l), y2$S05(), wx[a[420964]]({ 'title': a[420965], 'content': sck8l, 'confirmText': a[420971], 'cancelText': a[420972], 'success'(dtwjh4) {
      if (dtwjh4[a[420966]]) window['y2S$']();else dtwjh4[a[420968]] && (console[a[420225]](a[420973]), wx[a[420974]]({}));
    } });
}, window[a[420975]] = function (v3m65a) {
  console[a[420225]](a[420975], v3m65a), wx[a[420964]]({ 'title': a[420965], 'content': v3m65a, 'confirmText': a[420976], 'showCancel': ![], 'complete'(g2) {
      console[a[420225]](a[420973]), wx[a[420974]]({});
    } });
}, window['y2$50S'] = ![], window['y2$S50'] = function ($c92kn) {
  window['y2$50S'] = !![], wx[a[420977]]($c92kn);
}, window['y2$S05'] = function () {
  window['y2$50S'] && (window['y2$50S'] = ![], wx[a[420963]]({}));
}, window['y2$05S'] = function (_l7) {
  window[a[420978]][a[420979]]['y2$05S'](_l7);
}, window[a[420980]] = function (qgi2n, nc9sk2) {
  ym5a6v3[a[420980]](qgi2n, function (sk2c9n) {
    sk2c9n && sk2c9n[a[420335]] ? sk2c9n[a[420335]][a[420981]] == 0x1 ? nc9sk2(!![]) : (nc9sk2(![]), console[a[420982]](a[420983] + sk2c9n[a[420335]][a[420984]])) : console[a[420225]](a[420980], sk2c9n);
  });
}, window['y2$0S5'] = function ($igqn) {
  console[a[420225]](a[420985], $igqn);
}, window['y2$S0'] = function (nkg$i) {}, window['y2$0S'] = function (o7jf_, am1du5, d14hwt) {}, window['y2$0'] = function (gi2$nq) {
  console[a[420225]](a[420986], gi2$nq), window[a[420978]][a[420979]][a[420987]](), window[a[420978]][a[420979]][a[420988]](), window[a[420978]][a[420979]][a[420989]]();
}, window['y20$'] = function ($2nki) {
  window['y2$5S0'](a[420990]);var slk98 = { 'id': window['y2S0'][a[420991]], 'role': window['y2S0'][a[420992]], 'level': window['y2S0'][a[420993]], 'account': window['y2S0'][a[420994]], 'version': window['y2S0'][a[420955]], 'cdn': window['y2S0'][a[420995]], 'pkgName': window['y2S0'][a[420938]], 'gamever': window[a[420917]][a[420918]], 'serverid': window['y2S0'][a[420944]] ? window['y2S0'][a[420944]][a[420996]] : 0x0, 'systemInfo': window[a[420997]], 'error': a[420998], 'stack': $2nki ? $2nki : a[420990] },
      v0r3z = JSON[a[420999]](slk98);console[a[420333]](a[421000] + v0r3z), window['y2$S'](v0r3z);
}, window['y2S$0'] = function (a63yv5) {
  var wd14th = JSON[a[420223]](a63yv5);wd14th[a[421001]] = window[a[420917]][a[420918]], wd14th[a[421002]] = window['y2S0'][a[420944]] ? window['y2S0'][a[420944]][a[420996]] : 0x0, wd14th[a[420997]] = window[a[420997]];var kig$n = JSON[a[420999]](wd14th);console[a[420333]](a[421003] + kig$n), window['y2$S'](kig$n);
}, window['y2S0$'] = function (v3ry0z, r0zyvx) {
  var w1t4hd = { 'id': window['y2S0'][a[420991]], 'role': window['y2S0'][a[420992]], 'level': window['y2S0'][a[420993]], 'account': window['y2S0'][a[420994]], 'version': window['y2S0'][a[420955]], 'cdn': window['y2S0'][a[420995]], 'pkgName': window['y2S0'][a[420938]], 'gamever': window[a[420917]][a[420918]], 'serverid': window['y2S0'][a[420944]] ? window['y2S0'][a[420944]][a[420996]] : 0x0, 'systemInfo': window[a[420997]], 'error': v3ry0z, 'stack': r0zyvx },
      wu1dm = JSON[a[420999]](w1t4hd);console[a[420383]](a[421004] + wu1dm), window['y2$S'](wu1dm);
}, window['y2$S'] = function (t14wdh) {
  if (window['y2S0'][a[421005]] == a[421006]) return;var l78s = y2S0['y2$S'] + a[421007] + y2S0[a[420994]];wx[a[421008]]({ 'url': l78s, 'method': a[421009], 'data': t14wdh, 'header': { 'content-type': a[421010], 'cache-control': a[421011] }, 'success': function (hwjot4) {
      DEBUG && console[a[420225]](a[421012], l78s, t14wdh, hwjot4);
    }, 'fail': function (wudmt1) {
      DEBUG && console[a[420225]](a[421012], l78s, t14wdh, wudmt1);
    }, 'complete': function () {} });
}, window[a[421013]] = function () {
  function wf4() {
    return ((0x1 + Math[a[421014]]()) * 0x10000 | 0x0)[a[420060]](0x10)[a[420234]](0x1);
  }return wf4() + wf4() + '-' + wf4() + '-' + wf4() + '-' + wf4() + '+' + wf4() + wf4() + wf4();
}, window['y2S$'] = function () {
  console[a[420225]](a[421015]);var _8o7fl = ym5a6v3[a[421016]]();y2S0[a[420943]] = _8o7fl[a[421017]], y2S0[a[420942]] = _8o7fl[a[421017]], y2S0[a[420937]] = _8o7fl[a[421017]], y2S0[a[420938]] = _8o7fl[a[421018]];var m3v56a = { 'game_ver': y2S0[a[420924]] };y2S0[a[420939]] = this[a[421013]](), y2$S50({ 'title': a[421019] }), ym5a6v3[a[421020]](m3v56a, this['y20$S'][a[420017]](this));
}, window['y20$S'] = function (vr63y0) {
  var n2k$c = vr63y0[a[421021]];console[a[420225]](a[421022] + n2k$c + a[421023] + (n2k$c == 0x1) + a[421024] + vr63y0[a[420918]] + a[421025] + window[a[420916]][a[420925]]);if (!vr63y0[a[420918]] || window['y2950$S'](window[a[420916]][a[420925]], vr63y0[a[420918]]) < 0x0) console[a[420225]](a[421026]), y2S0[a[420929]] = a[421027], y2S0[a[420931]] = a[421028], y2S0[a[420933]] = a[421029], y2S0[a[420995]] = a[421030], y2S0[a[421031]] = a[421032], y2S0[a[421033]] = 'yy', y2S0[a[420956]] = ![];else window['y2950$S'](window[a[420916]][a[420925]], vr63y0[a[420918]]) == 0x0 ? (console[a[420225]](a[421034]), y2S0[a[420929]] = a[420930], y2S0[a[420931]] = a[420932], y2S0[a[420933]] = a[420934], y2S0[a[420995]] = a[421035], y2S0[a[421031]] = a[421032], y2S0[a[421033]] = a[421036], y2S0[a[420956]] = !![]) : (console[a[420225]](a[421037]), y2S0[a[420929]] = a[420930], y2S0[a[420931]] = a[420932], y2S0[a[420933]] = a[420934], y2S0[a[420995]] = a[421035], y2S0[a[421031]] = a[421032], y2S0[a[421033]] = a[421036], y2S0[a[420956]] = ![]);y2S0[a[420940]] = config[a[420051]] ? config[a[420051]] : 0x0, this['y25S$0'](), this['y25S0$'](), window[a[421038]] = 0x5, y2$S50({ 'title': a[421039] }), ym5a6v3[a[421040]](this['y20S$'][a[420017]](this));
}, window[a[421038]] = 0x5, window['y20S$'] = function (k29csl, _4ofjh) {
  if (k29csl == 0x0 && _4ofjh && _4ofjh[a[420285]]) {
    y2S0[a[421041]] = _4ofjh[a[420285]];var a1ud5m = this;y2$S50({ 'title': a[421042] }), sendApi(y2S0[a[420929]], a[421043], { 'platform': y2S0[a[420927]], 'partner_id': y2S0[a[420937]], 'token': _4ofjh[a[420285]], 'game_pkg': y2S0[a[420938]], 'deviceId': y2S0[a[420939]], 'scene': a[421044] + y2S0[a[420940]] }, this['y25$S0'][a[420017]](this), y250S, y20$);
  } else _4ofjh && _4ofjh[a[421045]] && window[a[421038]] > 0x0 && (_4ofjh[a[421045]][a[420146]](a[421046]) != -0x1 || _4ofjh[a[421045]][a[420146]](a[421047]) != -0x1 || _4ofjh[a[421045]][a[420146]](a[421048]) != -0x1 || _4ofjh[a[421045]][a[420146]](a[421049]) != -0x1 || _4ofjh[a[421045]][a[420146]](a[421050]) != -0x1 || _4ofjh[a[421045]][a[420146]](a[421051]) != -0x1) ? (window[a[421038]]--, ym5a6v3[a[421040]](this['y20S$'][a[420017]](this))) : (window['y2S0$'](a[421052], JSON[a[420999]]({ 'status': k29csl, 'data': _4ofjh })), window['y2$5S0'](a[421053] + (_4ofjh && _4ofjh[a[421045]] ? '，' + _4ofjh[a[421045]] : '')));
}, window['y25$S0'] = function ($2ig) {
  if (!$2ig) {
    window['y2S0$'](a[421054], a[421055]), window['y2$5S0'](a[421056]);return;
  }if ($2ig[a[420981]] != a[421057]) {
    window['y2S0$'](a[421054], JSON[a[420999]]($2ig)), window['y2$5S0'](a[421058] + $2ig[a[420981]]);return;
  }y2S0[a[421059]] = String($2ig[a[420994]]), y2S0[a[420994]] = String($2ig[a[420994]]), y2S0[a[421060]] = String($2ig[a[421060]]), y2S0[a[420943]] = String($2ig[a[421060]]), y2S0[a[421061]] = String($2ig[a[421061]]), y2S0[a[421062]] = String($2ig[a[421063]]), y2S0[a[421064]] = String($2ig[a[421065]]), y2S0[a[421063]] = '';var m61u5 = this;y2$S50({ 'title': a[421066] }), sendApi(y2S0[a[420929]], a[421067], { 'partner_id': y2S0[a[420937]], 'uid': y2S0[a[420994]], 'version': y2S0[a[420924]], 'game_pkg': y2S0[a[420938]], 'device': y2S0[a[420939]] }, m61u5['y25$0S'][a[420017]](m61u5), y250S, y20$);
}, window['y25$0S'] = function (dm51ua) {
  if (!dm51ua) {
    window['y2$5S0'](a[421068]);return;
  }if (dm51ua[a[420981]] != a[421057]) {
    window['y2$5S0'](a[421069] + dm51ua[a[420981]]);return;
  }if (!dm51ua[a[420335]] || dm51ua[a[420335]][a[420031]] == 0x0) {
    window['y2$5S0'](a[421070]);return;
  }y2S0[a[421071]] = dm51ua[a[421072]], y2S0[a[420944]] = { 'server_id': String(dm51ua[a[420335]][0x0][a[420996]]), 'server_name': String(dm51ua[a[420335]][0x0][a[421073]]), 'entry_ip': dm51ua[a[420335]][0x0][a[421074]], 'entry_port': parseInt(dm51ua[a[420335]][0x0][a[421075]]), 'status': y2S5$(dm51ua[a[420335]][0x0]), 'start_time': dm51ua[a[420335]][0x0][a[421076]], 'cdn': y2S0[a[420995]] }, this['y20S5$']();
}, window['y20S5$'] = function () {
  if (y2S0[a[421071]] == 0x1) {
    var ignk$2 = y2S0[a[420944]][a[421077]];if (ignk$2 === -0x1 || ignk$2 === 0x0) {
      window['y2$5S0'](ignk$2 === -0x1 ? a[421078] : a[421079]);return;
    }y20$5S(0x0, y2S0[a[420944]][a[420996]]), window[a[420978]][a[420979]][a[421080]](y2S0[a[421071]]);
  } else window[a[420978]][a[420979]][a[421081]](), y2$S05();window['y2S5'] = !![], window['y205S$'](), window['y20S$5']();
}, window['y25S$0'] = function () {
  sendApi(y2S0[a[420929]], a[421082], { 'game_pkg': y2S0[a[420938]], 'version_name': y2S0[a[421033]] }, this[a[421083]][a[420017]](this), y250S, y20$);
}, window[a[421083]] = function (yvr3z) {
  if (!yvr3z) {
    window['y2$5S0'](a[421084]);return;
  }if (yvr3z[a[420981]] != a[421057]) {
    window['y2$5S0'](a[421085] + yvr3z[a[420981]]);return;
  }if (!yvr3z[a[420335]] || !yvr3z[a[420335]][a[420924]]) {
    window['y2$5S0'](a[421086] + (yvr3z[a[420335]] && yvr3z[a[420335]][a[420924]]));return;
  }yvr3z[a[420335]][a[421087]] && yvr3z[a[420335]][a[421087]][a[420031]] > 0xa && (y2S0[a[421088]] = yvr3z[a[420335]][a[421087]], y2S0[a[420995]] = yvr3z[a[420335]][a[421087]]), yvr3z[a[420335]][a[420924]] && (y2S0[a[420955]] = yvr3z[a[420335]][a[420924]]), console[a[420982]](a[421089] + y2S0[a[420955]] + a[421090] + y2S0[a[421033]]), window['y2S05'] = !![], window['y205S$'](), window['y20S$5']();
}, window[a[421091]], window['y25S0$'] = function () {
  sendApi(y2S0[a[420929]], a[421092], { 'game_pkg': y2S0[a[420938]] }, this['y250$S'][a[420017]](this), y250S, y20$);
}, window['y250$S'] = function (r0z) {
  if (r0z[a[420981]] === a[421057] && r0z[a[420335]]) {
    window[a[421091]] = r0z[a[420335]];for (var dtmwu1 in r0z[a[420335]]) {
      y2S0[dtmwu1] = r0z[a[420335]][dtmwu1];
    }
  } else console[a[420982]](a[421093] + r0z[a[420981]]);window['y25S'] = !![], window['y20S$5']();
}, window[a[421094]] = function (a360y, d4jw, wd14ut, n2$igk, h7_oj, gq$i2, ezr0xy, au365m, y36rv0) {
  h7_oj = String(h7_oj);var tuwm1 = ezr0xy,
      ht1w = au365m;y2S0[a[420923]][h7_oj] = { 'productid': h7_oj, 'productname': tuwm1, 'productdesc': ht1w, 'roleid': a360y, 'rolename': d4jw, 'rolelevel': wd14ut, 'price': gq$i2, 'callback': y36rv0 }, sendApi(y2S0[a[420933]], a[421095], { 'game_pkg': y2S0[a[420938]], 'server_id': y2S0[a[420944]][a[420996]], 'server_name': y2S0[a[420944]][a[421073]], 'level': wd14ut, 'uid': y2S0[a[420994]], 'role_id': a360y, 'role_name': d4jw, 'product_id': h7_oj, 'product_name': tuwm1, 'product_desc': ht1w, 'money': gq$i2, 'partner_id': y2S0[a[420937]] }, toPayCallBack, y250S, y20$);
}, window[a[421096]] = function (qgi$p) {
  if (qgi$p) {
    if (qgi$p[a[421097]] === 0xc8 || qgi$p[a[420981]] == a[421057]) {
      var gnp$iq = y2S0[a[420923]][String(qgi$p[a[421098]])];if (gnp$iq[a[421099]]) gnp$iq[a[421099]](qgi$p[a[421098]], qgi$p[a[421100]], -0x1);ym5a6v3[a[421101]]({ 'cpbill': qgi$p[a[421100]], 'productid': qgi$p[a[421098]], 'productname': gnp$iq[a[421102]], 'productdesc': gnp$iq[a[421103]], 'serverid': y2S0[a[420944]][a[420996]], 'servername': y2S0[a[420944]][a[421073]], 'roleid': gnp$iq[a[421104]], 'rolename': gnp$iq[a[421105]], 'rolelevel': gnp$iq[a[421106]], 'price': gnp$iq[a[421107]], 'extension': JSON[a[420999]]({ 'cp_order_id': qgi$p[a[421100]] }) }, function (dw1tmu, gn$pq) {
        gnp$iq[a[421099]] && dw1tmu == 0x0 && gnp$iq[a[421099]](qgi$p[a[421098]], qgi$p[a[421100]], dw1tmu);console[a[420982]](JSON[a[420999]]({ 'type': a[421108], 'status': dw1tmu, 'data': qgi$p, 'role_name': gnp$iq[a[421105]] }));if (dw1tmu === 0x0) {} else {
          if (dw1tmu === 0x1) {} else {
            if (dw1tmu === 0x2) {}
          }
        }
      });
    } else alert(qgi$p[a[420982]]);
  }
}, window['y250S$'] = function () {}, window['y2$50'] = function (ofwj4, g$qipn, k2cns9, z3v, _fo7j) {
  ym5a6v3[a[421109]](y2S0[a[420944]][a[420996]], y2S0[a[420944]][a[421073]] || y2S0[a[420944]][a[420996]], ofwj4, g$qipn, k2cns9), sendApi(y2S0[a[420929]], a[421110], { 'game_pkg': y2S0[a[420938]], 'server_id': y2S0[a[420944]][a[420996]], 'role_id': ofwj4, 'uid': y2S0[a[420994]], 'role_name': g$qipn, 'role_type': z3v, 'level': k2cns9 });
}, window['y2$05'] = function (a635u, rzey, ayv53, dwj, sf7_l, s7c8l9, f4h, m56a3v, xz0re, yr063v) {
  y2S0[a[420991]] = a635u, y2S0[a[420992]] = rzey, y2S0[a[420993]] = ayv53, ym5a6v3[a[421111]](y2S0[a[420944]][a[420996]], y2S0[a[420944]][a[421073]] || y2S0[a[420944]][a[420996]], a635u, rzey, ayv53), sendApi(y2S0[a[420929]], a[421112], { 'game_pkg': y2S0[a[420938]], 'server_id': y2S0[a[420944]][a[420996]], 'role_id': a635u, 'uid': y2S0[a[420994]], 'role_name': rzey, 'role_type': dwj, 'level': ayv53, 'evolution': sf7_l });
}, window['y25$0'] = function (fwj, ig$nk2, dua5, $ginq2, l2csk, ck29l, j_h7, avm36, rzxey0, v3ya65) {
  y2S0[a[420991]] = fwj, y2S0[a[420992]] = ig$nk2, y2S0[a[420993]] = dua5, ym5a6v3[a[421113]](y2S0[a[420944]][a[420996]], y2S0[a[420944]][a[421073]] || y2S0[a[420944]][a[420996]], fwj, ig$nk2, dua5), sendApi(y2S0[a[420929]], a[421112], { 'game_pkg': y2S0[a[420938]], 'server_id': y2S0[a[420944]][a[420996]], 'role_id': fwj, 'uid': y2S0[a[420994]], 'role_name': ig$nk2, 'role_type': $ginq2, 'level': dua5, 'evolution': l2csk });
}, window['y250$'] = function (q$i2gn) {}, window['y2$5'] = function (lcks98) {
  ym5a6v3[a[421114]](a[421114], function (o7_fl) {
    lcks98 && lcks98(o7_fl);
  });
}, window[a[421115]] = function () {
  ym5a6v3[a[421115]]();
}, window[a[421116]] = function () {
  ym5a6v3[a[421117]]();
}, window[a[421118]] = function (tu1m5) {
  window['y20$5'] = tu1m5, window['y20$5'] && window['y25$'] && (console[a[420982]](a[421119] + window['y25$'][a[421120]]), window['y20$5'](window['y25$']), window['y25$'] = null);
}, window['y205$'] = function (f7_ho, w4jtd, knig2, ryez0x) {
  window[a[421121]](a[421122], { 'game_pkg': window['y2S0'][a[420938]], 'role_id': w4jtd, 'server_id': knig2 }, ryez0x);
}, window['y2S$50'] = function (s9lck8, kn2i$) {
  function v6m5a(mau3) {
    var um1tw = [],
        y03va = [],
        h1d4tw = window[a[420917]][a[421123]];for (var mutwd1 in h1d4tw) {
      var $pnqi = Number(mutwd1);(!s9lck8 || !s9lck8[a[420031]] || s9lck8[a[420146]]($pnqi) != -0x1) && (y03va[a[420066]](h1d4tw[mutwd1]), um1tw[a[420066]]([$pnqi, 0x3]));
    }window['y2950$S'](window[a[421124]], a[421125]) >= 0x0 ? (console[a[420225]](a[421126]), ym5a6v3[a[421127]] && ym5a6v3[a[421127]](y03va, function (i$k2gn) {
      console[a[420225]](a[421128]), console[a[420225]](i$k2gn);if (i$k2gn && i$k2gn[a[421045]] == a[421129]) for (var o_8fl7 in h1d4tw) {
        if (i$k2gn[h1d4tw[o_8fl7]] == a[421130]) {
          var adm15u = Number(o_8fl7);for (var n$qigp = 0x0; n$qigp < um1tw[a[420031]]; n$qigp++) {
            if (um1tw[n$qigp][0x0] == adm15u) {
              um1tw[n$qigp][0x1] = 0x1;break;
            }
          }
        }
      }window['y2950$S'](window[a[421124]], a[421131]) >= 0x0 ? wx[a[421132]]({ 'withSubscriptions': !![], 'success': function (yex) {
          var c8slk9 = yex[a[421133]][a[421134]];if (c8slk9) {
            console[a[420225]](a[421135]), console[a[420225]](c8slk9);for (var ry063v in h1d4tw) {
              if (c8slk9[h1d4tw[ry063v]] == a[421130]) {
                var c8s_l = Number(ry063v);for (var dwh = 0x0; dwh < um1tw[a[420031]]; dwh++) {
                  if (um1tw[dwh][0x0] == c8s_l) {
                    um1tw[dwh][0x1] = 0x2;break;
                  }
                }
              }
            }console[a[420225]](um1tw), kn2i$ && kn2i$(um1tw);
          } else console[a[420225]](a[421136]), console[a[420225]](yex), console[a[420225]](um1tw), kn2i$ && kn2i$(um1tw);
        }, 'fail': function () {
          console[a[420225]](a[421137]), console[a[420225]](um1tw), kn2i$ && kn2i$(um1tw);
        } }) : (console[a[420225]](a[421138] + window[a[421124]]), console[a[420225]](um1tw), kn2i$ && kn2i$(um1tw));
    })) : (console[a[420225]](a[421139] + window[a[421124]]), console[a[420225]](um1tw), kn2i$ && kn2i$(um1tw)), wx[a[421140]](v6m5a);
  }wx[a[421141]](v6m5a);
}, window['y2S$05'] = { 'isSuccess': ![], 'level': a[421142], 'isCharging': ![] }, window['y2S5$0'] = function ($2) {
  wx[a[421143]]({ 'success': function (u6m51) {
      var v5m6a = window['y2S$05'];v5m6a[a[421144]] = !![], v5m6a[a[421145]] = Number(u6m51[a[421145]])[a[421146]](0x0), v5m6a[a[421147]] = u6m51[a[421147]], $2 && $2(v5m6a[a[421144]], v5m6a[a[421145]], v5m6a[a[421147]]);
    }, 'fail': function (adu15) {
      console[a[420225]](a[421148], adu15[a[421045]]);var gkn29$ = window['y2S$05'];$2 && $2(gkn29$[a[421144]], gkn29$[a[421145]], gkn29$[a[421147]]);
    } });
}, window[a[421121]] = function (wut4, nks92c, gkn29, u1wd4, _78fo, c789, scl8_, i$qn2g) {
  if (u1wd4 == undefined) u1wd4 = 0x1;wx[a[421008]]({ 'url': wut4, 'method': scl8_ || a[421149], 'responseType': a[421150], 'data': nks92c, 'header': { 'content-type': i$qn2g || a[421010] }, 'success': function (f_s7) {
      DEBUG && console[a[420225]](a[421151], wut4, info, f_s7);if (f_s7 && f_s7[a[421152]] == 0xc8) {
        var r0yvz3 = f_s7[a[420335]];!c789 || c789(r0yvz3) ? gkn29 && gkn29(r0yvz3) : window[a[421153]](wut4, nks92c, gkn29, u1wd4, _78fo, c789, f_s7);
      } else window[a[421153]](wut4, nks92c, gkn29, u1wd4, _78fo, c789, f_s7);
    }, 'fail': function (j87_fo) {
      DEBUG && console[a[420225]](a[421154], wut4, info, j87_fo), window[a[421153]](wut4, nks92c, gkn29, u1wd4, _78fo, c789, j87_fo);
    }, 'complete': function () {} });
}, window[a[421153]] = function (m1utd, eyx, udwt14, kn9g$2, jf87o_, c8_s, gk2$) {
  kn9g$2 - 0x1 > 0x0 ? setTimeout(function () {
    window[a[421121]](m1utd, eyx, udwt14, kn9g$2 - 0x1, jf87o_, c8_s);
  }, 0x3e8) : jf87o_ && jf87o_(JSON[a[420999]]({ 'url': m1utd, 'response': gk2$ }));
}, window[a[421155]] = function (ry3v0z, m3va5, _8l7s, _8f7, v0r6y, _jof4h, yzr03) {
  !_8l7s && (_8l7s = {});var sc89kl = Math[a[420071]](Date[a[420950]]() / 0x3e8);_8l7s[a[421065]] = sc89kl, _8l7s[a[421156]] = m3va5;var vxy0rz = Object[a[420030]](_8l7s)[a[420382]](),
      foh7j_ = '',
      jtwoh4 = '';for (var l97cs = 0x0; l97cs < vxy0rz[a[420031]]; l97cs++) {
    foh7j_ = foh7j_ + (l97cs == 0x0 ? '' : '&') + vxy0rz[l97cs] + _8l7s[vxy0rz[l97cs]], jtwoh4 = jtwoh4 + (l97cs == 0x0 ? '' : '&') + vxy0rz[l97cs] + '=' + encodeURIComponent(_8l7s[vxy0rz[l97cs]]);
  }foh7j_ = foh7j_ + y2S0[a[420935]];var u63ma = a[421157] + md5(foh7j_);send(ry3v0z + '?' + jtwoh4 + (jtwoh4 == '' ? '' : '&') + u63ma, null, _8f7, v0r6y, _jof4h, yzr03 || function (t41uwd) {
    return t41uwd[a[420981]] == a[421057];
  }, null, a[421158]);
}, window['y2S50$'] = function (a5m3, yxezr0) {
  var c98sl = 0x0;y2S0[a[420944]] && (c98sl = y2S0[a[420944]][a[420996]]), sendApi(y2S0[a[420931]], a[421159], { 'partnerId': y2S0[a[420937]], 'gamePkg': y2S0[a[420938]], 'logTime': Math[a[420071]](Date[a[420950]]() / 0x3e8), 'platformUid': y2S0[a[421061]], 'type': a5m3, 'serverId': c98sl }, null, 0x2, null, function () {
    return !![];
  });
}, window['y2S0$5'] = function (h_ofj4) {
  sendApi(y2S0[a[420929]], a[421160], { 'partner_id': y2S0[a[420937]], 'uid': y2S0[a[420994]], 'version': y2S0[a[420924]], 'game_pkg': y2S0[a[420938]], 'device': y2S0[a[420939]] }, y2S05$, y250S, y20$);
}, window['y2S05$'] = function (ma6v53) {
  if (ma6v53[a[420981]] === a[421057] && ma6v53[a[420335]]) {
    ma6v53[a[420335]][a[420174]]({ 'id': -0x2, 'name': a[421161] }), ma6v53[a[420335]][a[420174]]({ 'id': -0x1, 'name': a[421162] }), y2S0[a[421163]] = ma6v53[a[420335]];if (window[a[421164]]) window[a[421164]][a[421165]]();
  } else y2S0[a[421166]] = ![], window['y2$5S0'](a[421167] + ma6v53[a[420981]]);
}, window['y2$5S'] = function (yrv0z) {
  sendApi(y2S0[a[420929]], a[421168], { 'partner_id': y2S0[a[420937]], 'uid': y2S0[a[420994]], 'version': y2S0[a[420924]], 'game_pkg': y2S0[a[420938]], 'device': y2S0[a[420939]] }, y2$S5, y250S, y20$);
}, window['y2$S5'] = function (fh_4o) {
  y2S0[a[421169]] = ![];if (fh_4o[a[420981]] === a[421057] && fh_4o[a[420335]]) {
    for (var s_78lf = 0x0; s_78lf < fh_4o[a[420335]][a[420031]]; s_78lf++) {
      fh_4o[a[420335]][s_78lf][a[421077]] = y2S5$(fh_4o[a[420335]][s_78lf]);
    }y2S0[a[420941]][-0x1] = window[a[421170]](fh_4o[a[420335]]), window[a[421164]][a[421171]](-0x1);
  } else window['y2$5S0'](a[421172] + fh_4o[a[420981]]);
}, window[a[421173]] = function (yezx0) {
  sendApi(y2S0[a[420929]], a[421168], { 'partner_id': y2S0[a[420937]], 'uid': y2S0[a[420994]], 'version': y2S0[a[420924]], 'game_pkg': y2S0[a[420938]], 'device': y2S0[a[420939]] }, yezx0, y250S, y20$);
}, window['y25$S'] = function (f_78jo, d4wtjh) {
  sendApi(y2S0[a[420929]], a[421174], { 'partner_id': y2S0[a[420937]], 'uid': y2S0[a[420994]], 'version': y2S0[a[420924]], 'game_pkg': y2S0[a[420938]], 'device': y2S0[a[420939]], 'server_group_id': d4wtjh }, y25S$, y250S, y20$);
}, window['y25S$'] = function (va6m) {
  y2S0[a[421169]] = ![];if (va6m[a[420981]] === a[421057] && va6m[a[420335]] && va6m[a[420335]][a[420335]]) {
    var _7jo = va6m[a[420335]][a[421175]],
        yxre = [];for (var c_sl87 = 0x0; c_sl87 < va6m[a[420335]][a[420335]][a[420031]]; c_sl87++) {
      va6m[a[420335]][a[420335]][c_sl87][a[421077]] = y2S5$(va6m[a[420335]][a[420335]][c_sl87]), (yxre[a[420031]] == 0x0 || va6m[a[420335]][a[420335]][c_sl87][a[421077]] != 0x0) && (yxre[yxre[a[420031]]] = va6m[a[420335]][a[420335]][c_sl87]);
    }y2S0[a[420941]][_7jo] = window[a[421170]](yxre), window[a[421164]][a[421171]](_7jo);
  } else window['y2$5S0'](a[421176] + va6m[a[420981]]);
}, window['y2950S'] = function (k2ns9c) {
  sendApi(y2S0[a[420929]], a[421177], { 'partner_id': y2S0[a[420937]], 'uid': y2S0[a[420994]], 'version': y2S0[a[420924]], 'game_pkg': y2S0[a[420938]], 'device': y2S0[a[420939]] }, reqServerRecommendCallBack, y250S, y20$);
}, window[a[421178]] = function (k8c9sl) {
  y2S0[a[421169]] = ![];if (k8c9sl[a[420981]] === a[421057] && k8c9sl[a[420335]]) {
    for (var av6y03 = 0x0; av6y03 < k8c9sl[a[420335]][a[420031]]; av6y03++) {
      k8c9sl[a[420335]][av6y03][a[421077]] = y2S5$(k8c9sl[a[420335]][av6y03]);
    }y2S0[a[420941]][-0x2] = window[a[421170]](k8c9sl[a[420335]]), window[a[421164]][a[421171]](-0x2);
  } else alert(a[421179] + k8c9sl[a[420981]]);
}, window[a[421170]] = function (kg2$) {
  if (!kg2$ && kg2$[a[420031]] <= 0x0) return kg2$;for (let u61a5 = 0x0; u61a5 < kg2$[a[420031]]; u61a5++) {
    kg2$[u61a5][a[421180]] && kg2$[u61a5][a[421180]] == 0x1 && (kg2$[u61a5][a[421073]] += a[421181]);
  }return kg2$;
}, window['y2S$5'] = function (sklc8, hwdt4) {
  sklc8 = sklc8 || y2S0[a[420944]][a[420996]], sendApi(y2S0[a[420929]], a[421182], { 'type': '4', 'game_pkg': y2S0[a[420938]], 'server_id': sklc8 }, hwdt4);
}, window[a[421183]] = function (c8skl, cksl29, fo8_7j, oth4j) {
  fo8_7j = fo8_7j || y2S0[a[420944]][a[420996]], sendApi(y2S0[a[420929]], a[421184], { 'type': c8skl, 'game_pkg': cksl29, 'server_id': fo8_7j }, oth4j);
}, window['y2S5$'] = function (ofh) {
  if (ofh) {
    if (ofh[a[421077]] == 0x1) {
      if (ofh[a[421185]] == 0x1) return 0x2;else return 0x1;
    } else return ofh[a[421077]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['y20$5S'] = function (_87ofl, u51) {
  y2S0[a[421186]] = { 'step': _87ofl, 'server_id': u51 };var tuw14d = this;y2$S50({ 'title': a[421187] }), sendApi(y2S0[a[420929]], a[421188], { 'partner_id': y2S0[a[420937]], 'uid': y2S0[a[420994]], 'game_pkg': y2S0[a[420938]], 'server_id': u51, 'platform': y2S0[a[421060]], 'platform_uid': y2S0[a[421061]], 'check_login_time': y2S0[a[421064]], 'check_login_sign': y2S0[a[421062]], 'version_name': y2S0[a[421033]] }, y20$S5, y250S, y20$, function (_4ho) {
    return _4ho[a[420981]] == a[421057] || _4ho[a[420982]] == a[421189] || _4ho[a[420982]] == a[421190];
  });
}, window['y20$S5'] = function (vxzr) {
  var mu1d5t = this;if (vxzr[a[420981]] === a[421057] && vxzr[a[420335]]) {
    var n92cs = y2S0[a[420944]];n92cs[a[421191]] = y2S0[a[420942]], n92cs[a[421063]] = String(vxzr[a[420335]][a[421192]]), n92cs[a[420949]] = parseInt(vxzr[a[420335]][a[421065]]);if (vxzr[a[420335]][a[421193]]) n92cs[a[421193]] = parseInt(vxzr[a[420335]][a[421193]]);else n92cs[a[421193]] = parseInt(vxzr[a[420335]][a[420996]]);n92cs[a[421194]] = 0x0, n92cs[a[420995]] = y2S0[a[421088]], n92cs[a[421195]] = vxzr[a[420335]][a[421196]], n92cs[a[421197]] = vxzr[a[420335]][a[421197]], console[a[420225]](a[421198] + JSON[a[420999]](n92cs[a[421197]])), y2S0[a[421071]] == 0x1 && n92cs[a[421197]] && n92cs[a[421197]][a[421199]] == 0x1 && (y2S0[a[421200]] = 0x1, window[a[420978]][a[420979]]['y290S']()), y205$S();
  } else y2S0[a[421186]][a[421201]] >= 0x3 ? (y20$(JSON[a[420999]](vxzr)), window['y2$5S0'](a[421202] + vxzr[a[420981]])) : sendApi(y2S0[a[420929]], a[421043], { 'platform': y2S0[a[420927]], 'partner_id': y2S0[a[420937]], 'token': y2S0[a[421041]], 'game_pkg': y2S0[a[420938]], 'deviceId': y2S0[a[420939]], 'scene': a[421044] + y2S0[a[420940]] }, function (mdt51) {
    if (!mdt51 || mdt51[a[420981]] != a[421057]) {
      window['y2$5S0'](a[421058] + mdt51 && mdt51[a[420981]]);return;
    }y2S0[a[421062]] = String(mdt51[a[421063]]), y2S0[a[421064]] = String(mdt51[a[421065]]), setTimeout(function () {
      y20$5S(y2S0[a[421186]][a[421201]] + 0x1, y2S0[a[421186]][a[420996]]);
    }, 0x5dc);
  }, y250S, y20$, function (uwt14) {
    return uwt14[a[420981]] == a[421057] || uwt14[a[420981]] == a[421203];
  });
}, window['y205$S'] = function () {
  ServerLoading[a[420979]][a[421080]](y2S0[a[421071]]), window['y250'] = !![], window['y20S$5']();
}, window['y205S$'] = function () {
  if (window['y205'] && window['y2S50'] && window[a[420960]] && window[a[420961]] && window['y2S05'] && window['y2S5']) {
    if (!window[a[421204]][a[420979]]) {
      console[a[420225]](a[421205] + window[a[421204]][a[420979]]);var a16u5m = wx[a[421206]](),
          oj_hf7 = a16u5m[a[421120]] ? a16u5m[a[421120]] : 0x0,
          udma15 = { 'cdn': window['y2S0'][a[420995]], 'spareCdn': window['y2S0'][a[421031]], 'newRegister': window['y2S0'][a[421071]], 'wxPC': window['y2S0'][a[420959]], 'wxIOS': window['y2S0'][a[420957]], 'wxAndroid': window['y2S0'][a[420958]], 'wxParam': { 'limitLoad': window['y2S0']['y29$50S'], 'benchmarkLevel': window['y2S0']['y29$S50'], 'wxFrom': window[a[420917]][a[420051]] == a[421207] ? 0x1 : 0x0, 'wxSDKVersion': window[a[421124]] }, 'configType': window['y2S0'][a[420951]], 'exposeType': window['y2S0'][a[420953]], 'scene': oj_hf7 };new window[a[421204]](udma15, window['y2S0'][a[420955]], window['y29$5S0']);
    }
  }
}, window['y20S$5'] = function () {
  if (window['y205'] && window['y2S50'] && window[a[420960]] && window[a[420961]] && window['y2S05'] && window['y2S5'] && window['y250'] && window['y25S']) {
    y2$S05();if (!y205S) {
      y205S = !![];if (!window[a[421204]][a[420979]]) window['y205S$']();var inpqg$ = 0x0,
          cnsk29 = wx[a[421208]]();cnsk29 && (window['y2S0'][a[421209]] && (inpqg$ = cnsk29[a[421210]]), console[a[420982]](a[421211] + cnsk29[a[421210]] + a[421212] + cnsk29[a[421213]] + a[421214] + cnsk29[a[421215]] + a[421216] + cnsk29[a[421217]] + a[421218] + cnsk29[a[421219]] + a[421220] + cnsk29[a[421221]]));var jof_78 = {};for (const zr03 in y2S0[a[420944]]) {
        jof_78[zr03] = y2S0[a[420944]][zr03];
      }var zvrx = { 'channel': window['y2S0'][a[420943]], 'account': window['y2S0'][a[420994]], 'userId': window['y2S0'][a[421059]], 'cdn': window['y2S0'][a[420995]], 'data': window['y2S0'][a[420335]], 'package': window['y2S0'][a[420304]], 'newRegister': window['y2S0'][a[421071]], 'pkgName': window['y2S0'][a[420938]], 'partnerId': window['y2S0'][a[420937]], 'platform_uid': window['y2S0'][a[421061]], 'deviceId': window['y2S0'][a[420939]], 'selectedServer': jof_78, 'configType': window['y2S0'][a[420951]], 'exposeType': window['y2S0'][a[420953]], 'debugUsers': window['y2S0'][a[420947]], 'wxMenuTop': inpqg$, 'wxShield': window['y2S0'][a[420956]] };if (window[a[421091]]) for (var ngpi$ in window[a[421091]]) {
        zvrx[ngpi$] = window[a[421091]][ngpi$];
      }window[a[421204]][a[420979]]['y20S9'](zvrx);
    }
  } else console[a[420982]](a[421222] + window['y205'] + a[421223] + window['y2S50'] + a[421224] + window[a[420960]] + a[421225] + window[a[420961]] + a[421226] + window['y2S05'] + a[421227] + window['y2S5'] + a[421228] + window['y250'] + a[421229] + window['y25S']);
};