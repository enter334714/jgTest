var a = wx.$y;
(function (window, document, kg29n) {
  var mdu15a = kg29n['un'],
      u5tm1d = kg29n['uns'],
      ign2k = kg29n['static'],
      hwdjt4 = kg29n['class'],
      l8s_ = kg29n['getset'],
      nig = kg29n['__newvec'],
      _7cs = laya['utils']['Browser'],
      lc8sk = laya['events']['Event'],
      s9c8kl = laya['events']['EventDispatcher'],
      vzrxy0 = laya['resource']['HTMLImage'],
      c7s_8l = laya['utils']['Handler'],
      wtj4hd = laya['display']['Input'],
      cnk9$ = laya['net']['Loader'],
      j4wht = laya['maths']['Matrix'],
      kg$n2i = laya['renders']['Render'],
      f_7ol = laya['utils']['RunDriver'],
      y53va6 = laya['media']['Sound'],
      cls8 = laya['media']['SoundChannel'],
      l8s_7 = laya['media']['SoundManager'],
      _ofhj4 = laya['display']['Stage'],
      jfh7o_ = laya['net']['URL'],
      xrye0z = laya['utils']['Utils'],
      ht14dw = function () {
    function fo4wh() {}return hwdjt4(fo4wh, 'laya.wx.mini.MiniAdpter'), fo4wh['getJson'] = function (m51aud) {
      return JSON['parse'](m51aud);
    }, fo4wh['init'] = function (fl8_7o, kg2in$) {
      fl8_7o === void 0x0 && (fl8_7o = ![]), kg2in$ === void 0x0 && (kg2in$ = ![]);if (fo4wh['_inited']) return;fo4wh['window'] = window;if (fo4wh['window']['navigator']['userAgent']['indexOf']('MiniGame') < 0x0) return;fo4wh['_inited'] = !![], fo4wh['isZiYu'] = kg2in$, fo4wh['isPosMsgYu'] = fl8_7o, fo4wh['EnvConfig'] = {}, !fo4wh['isZiYu'] && (f_8jo['setNativeFileDir']('/layaairGame'), f_8jo['existDir'](f_8jo['fileNativeDir'], c7s_8l['create'](fo4wh, fo4wh['onMkdirCallBack']))), fo4wh['window']['focus'] = function () {}, kg29n['getUrlPath'] = function () {}, fo4wh['window']['logtime'] = function (t1wmud) {}, fo4wh['window']['alertTimeLog'] = function (a65m1u) {}, fo4wh['window']['resetShareInfo'] = function () {}, fo4wh['window']['CanvasRenderingContext2D'] = function () {}, fo4wh['window']['CanvasRenderingContext2D']['prototype'] = fo4wh['window']['wx']['createCanvas']()['getContext']('2d')['__proto__'], fo4wh['window']['document']['body']['appendChild'] = function () {}, fo4wh['EnvConfig']['pixelRatioInt'] = 0x0, f_7ol['getPixelRatio'] = fo4wh['pixelRatio'], fo4wh['_preCreateElement'] = _7cs['createElement'], _7cs['createElement'] = fo4wh['createElement'], f_7ol['createShaderCondition'] = fo4wh['createShaderCondition'], xrye0z['parseXMLFromString'] = fo4wh['parseXMLFromString'], wtj4hd['_createInputElement'] = k$ni2g['_createInputElement'], fo4wh['EnvConfig']['load'] = cnk9$['prototype']['load'], cnk9$['prototype']['load'] = oj8f7['prototype']['load'], fo4wh['isZiYu'] && fl8_7o && wx['onMessage'](function (rvy0x) {
        rvy0x['isLoad'] && (f_8jo['ziyuFileData'][rvy0x['url']] = rvy0x['data']);
      });
    }, fo4wh['onMkdirCallBack'] = function (o4twh, ry36v) {
      if (!o4twh) f_8jo['filesListObj'] = JSON['parse'](ry36v['data']);
    }, fo4wh['pixelRatio'] = function () {
      if (!fo4wh['EnvConfig']['pixelRatioInt']) try {
        var d5ua1 = wx['getSystemInfoSync']();return fo4wh['EnvConfig']['pixelRatioInt'] = d5ua1['pixelRatio'], d5ua1 = d5ua1, d5ua1['pixelRatio'];
      } catch (fjhwo) {}return fo4wh['EnvConfig']['pixelRatioInt'];
    }, fo4wh['createElement'] = function (aud5m1) {
      if (aud5m1 == 'canvas') {
        var td4wj;return fo4wh['idx'] == 0x1 ? fo4wh['isZiYu'] ? (td4wj = sharedCanvas, td4wj['style'] = {}) : td4wj = window['canvas'] : td4wj = window['wx']['createCanvas'](), fo4wh['idx']++, td4wj;
      } else {
        if (aud5m1 == 'textarea' || aud5m1 == 'input') return fo4wh['onCreateInput'](aud5m1);else {
          if (aud5m1 == 'div') {
            var yrexz0 = fo4wh['_preCreateElement'](aud5m1);return yrexz0['contains'] = function (d51ua) {
              return null;
            }, yrexz0['removeChild'] = function (f_l7o8) {}, yrexz0;
          } else return fo4wh['_preCreateElement'](aud5m1);
        }
      }
    }, fo4wh['onCreateInput'] = function (wht4jd) {
      var n2sck9 = fo4wh['_preCreateElement'](wht4jd);return n2sck9['focus'] = k$ni2g['wxinputFocus'], n2sck9['blur'] = k$ni2g['wxinputblur'], n2sck9['style'] = {}, n2sck9['value'] = 0x0, n2sck9['parentElement'] = {}, n2sck9['placeholder'] = {}, n2sck9['type'] = {}, n2sck9['setColor'] = function (nipq$g) {}, n2sck9['setType'] = function (yvrzx0) {}, n2sck9['setFontFace'] = function (c92ksl) {}, n2sck9['addEventListener'] = function (umtd1) {}, n2sck9['contains'] = function (va6y03) {
        return null;
      }, n2sck9['removeChild'] = function (_cl78) {}, n2sck9;
    }, fo4wh['createShaderCondition'] = function (kni2$) {
      var ht4dj = this,
          u16m5a = function () {
        var yv6r3 = kni2$;return ht4dj[kni2$['replace']('this.', '')];
      };return u16m5a;
    }, fo4wh['EnvConfig'] = null, fo4wh['window'] = null, fo4wh['_preCreateElement'] = null, fo4wh['_inited'] = ![], fo4wh['wxRequest'] = null, fo4wh['systemInfo'] = null, fo4wh['version'] = '0.0.1', fo4wh['isZiYu'] = ![], fo4wh['isPosMsgYu'] = ![], fo4wh['parseXMLFromString'] = function (n92kc) {
      var _of7j8, _ojhf7;n92kc = n92kc['replace'](/>\s+</g, '><');try {
        _of7j8 = new window['Parser']['DOMParser']()['parseFromString'](n92kc, 'text/xml');
      } catch (avm365) {
        throw '需要引入xml解析库文件';
      }return _of7j8;
    }, fo4wh['idx'] = 0x1, fo4wh;
  }(),
      gk2in = function () {
    function xr0eyz() {}hwdjt4(xr0eyz, 'laya.wx.mini.MiniImage');var n2c9$k = xr0eyz['prototype'];return n2c9$k['_loadImage'] = function (y3rv0) {
      var fj7o8_ = this,
          o4_fj = ![];y3rv0['indexOf']('layaNativeDir/') == -0x1 && (o4_fj = !![], y3rv0 = jfh7o_['formatURL'](y3rv0));if (!f_8jo['getFileInfo'](y3rv0)) {
        if (y3rv0['indexOf']('http://') != -0x1 || y3rv0['indexOf']('https://') != -0x1) f_8jo['downImg'](y3rv0, new c7s_8l(xr0eyz, xr0eyz['onDownImgCallBack'], [y3rv0, fj7o8_]), y3rv0);else xr0eyz['onCreateImage'](y3rv0, fj7o8_, !![]);
      } else xr0eyz['onCreateImage'](y3rv0, fj7o8_, !o4_fj);
    }, xr0eyz['onDownImgCallBack'] = function (qi2$n, g$i, c2s9l) {
      if (!c2s9l) xr0eyz['onCreateImage'](qi2$n, g$i);else g$i['onError'](null);
    }, xr0eyz['onCreateImage'] = function (f78ls_, othjw, zeyx0r) {
      zeyx0r === void 0x0 && (zeyx0r = ![]);var m63v;if (!zeyx0r) {
        var ut1dmw = f_8jo['getFileInfo'](f78ls_),
            y30rz = ut1dmw['md5'];m63v = f_8jo['getFileNativePath'](y30rz);
      } else m63v = f78ls_;if (othjw['imgCache'] == null) othjw['imgCache'] = {};var yzv03;function u15m6a() {
        yzv03['onload'] = null, yzv03['onerror'] = null, delete othjw['imgCache'][f78ls_];
      };var wf4hj = function () {
        u15m6a(), othjw['onLoaded'](yzv03);
      },
          ohfj_ = function () {
        u15m6a(), othjw['event']('error', 'Load image failed');
      };othjw['_type'] == 'nativeimage' ? (yzv03 = new _7cs['window']['Image'](), yzv03['crossOrigin'] = '', yzv03['onload'] = wf4hj, yzv03['onerror'] = ohfj_, yzv03['src'] = m63v, othjw['imgCache'][f78ls_] = yzv03) : new vzrxy0['create'](m63v, { 'onload': wf4hj, 'onerror': ohfj_, 'onCreate': function (exryz0) {
          yzv03 = exryz0, othjw['imgCache'][f78ls_] = exryz0;
        } });
    }, xr0eyz;
  }(),
      k$ni2g = function () {
    function j87_fo() {}return hwdjt4(j87_fo, 'laya.wx.mini.MiniInput'), j87_fo['_createInputElement'] = function () {
      wtj4hd['_initInput'](wtj4hd['area'] = _7cs['createElement']('textarea')), wtj4hd['_initInput'](wtj4hd['input'] = _7cs['createElement']('input')), wtj4hd['inputContainer'] = _7cs['createElement']('div'), wtj4hd['inputContainer']['style']['position'] = 'absolute', wtj4hd['inputContainer']['style']['zIndex'] = 0x186a0, _7cs['container']['appendChild'](wtj4hd['inputContainer']), wtj4hd['inputContainer']['setPos'] = function (jo7, ig2qn$) {
        wtj4hd['inputContainer']['style']['left'] = jo7 + 'px', wtj4hd['inputContainer']['style']['top'] = ig2qn$ + 'px';
      }, kg29n['stage']['on']('resize', null, j87_fo['_onStageResize']), wx['onWindowResize'] && wx['onWindowResize'](function (mwudt) {
        window['dispatchEvent'] && window['dispatchEvent']('resize');
      }), l8s_7['_soundClass'] = ry306, l8s_7['_musicClass'] = ry306;
    }, j87_fo['_onStageResize'] = function () {
      var kcsl92 = kg29n['stage']['_canvasTransform']['identity']();kcsl92['scale'](_7cs['width'] / kg$n2i['canvas']['width'] / f_7ol['getPixelRatio'](), _7cs['height'] / kg$n2i['canvas']['height'] / f_7ol['getPixelRatio']());
    }, j87_fo['wxinputFocus'] = function (s78_fl) {
      var ni$pqg = wtj4hd['inputElement']['target'];if (ni$pqg && !ni$pqg['editable']) return;ht14dw['window']['wx']['offKeyboardConfirm'](), ht14dw['window']['wx']['offKeyboardInput'](), ht14dw['window']['wx']['showKeyboard']({ 'defaultValue': ni$pqg['text'], 'maxLength': ni$pqg['maxChars'], 'multiple': ni$pqg['multiline'], 'confirmHold': !![], 'confirmType': 'done', 'success': function (ut51) {}, 'fail': function (whot4) {} }), ht14dw['window']['wx']['onKeyboardConfirm'](function (l7_o) {
        var q$ign2 = l7_o ? l7_o['value'] : '';ni$pqg['text'] = q$ign2, ni$pqg['event']('input'), laya['wx']['mini']['MiniInput']['inputEnter']();
      }), ht14dw['window']['wx']['onKeyboardInput'](function (c87l) {
        var foh_j7 = c87l ? c87l['value'] : '';if (!ni$pqg['multiline']) {
          if (foh_j7['indexOf']('\x0a') != -0x1) {
            laya['wx']['mini']['MiniInput']['inputEnter']();return;
          }
        }ni$pqg['text'] = foh_j7, ni$pqg['event']('input');
      });
    }, j87_fo['inputEnter'] = function () {
      wtj4hd['inputElement']['target']['focus'] = ![];
    }, j87_fo['wxinputblur'] = function () {
      j87_fo['hideKeyboard']();
    }, j87_fo['hideKeyboard'] = function () {
      ht14dw['window']['wx']['offKeyboardConfirm'](), ht14dw['window']['wx']['offKeyboardInput'](), ht14dw['window']['wx']['hideKeyboard']({ 'success': function (ikn2g) {
          console['log']('隐藏键盘');
        }, 'fail': function (nc$k92) {
          console['log']('隐藏键盘出错:' + (nc$k92 ? nc$k92['errMsg'] : ''));
        } });
    }, j87_fo;
  }(),
      oj8f7 = function () {
    function fol78() {}hwdjt4(fol78, 'laya.wx.mini.MiniLoader');var hf7jo_ = fol78['prototype'];return hf7jo_['load'] = function (_f7j8, _s87fl, e0yrxz, l98sk, w4hdt1) {
      e0yrxz === void 0x0 && (e0yrxz = !![]), w4hdt1 === void 0x0 && (w4hdt1 = ![]);var nc29s = this;nc29s['_url'] = _f7j8;if (_f7j8['indexOf']('data:image') === 0x0) nc29s['_type'] = _s87fl = 'image';else nc29s['_type'] = _s87fl || (_s87fl = nc29s['getTypeFromUrl'](_f7j8));nc29s['_cache'] = e0yrxz, nc29s['_data'] = null;var s_7l = 'ascii';if (_f7j8['indexOf']('.fnt') != -0x1) s_7l = 'utf8';else _s87fl == 'arraybuffer' && (s_7l = '');;var $9cn2k = xrye0z['getFileExtension'](_f7j8);if (fol78['_fileTypeArr']['indexOf']($9cn2k) != -0x1) ht14dw['EnvConfig']['load']['call'](this, _f7j8, _s87fl, e0yrxz, l98sk, w4hdt1);else {
        if (!f_8jo['getFileInfo'](_f7j8)) {
          if (_f7j8['indexOf']('layaNativeDir/') != -0x1) {
            if (ht14dw['isZiYu']) {
              var c29$ = f_8jo['ziyuFileData'][_f7j8];nc29s['onLoaded'](c29$);return;
            } else {
              cosnole['log']('read read'), f_8jo['read'](_f7j8, s_7l, new c7s_8l(fol78, fol78['onReadNativeCallBack'], [s_7l, _f7j8, _s87fl, e0yrxz, l98sk, w4hdt1, nc29s]));return;
            }
          }if (jfh7o_['rootPath'] == '') var f_78s = _f7j8;else f_78s = _f7j8['split'](jfh7o_['rootPath'])[0x0];_f7j8['indexOf']('http://') != -0x1 || _f7j8['indexOf']('https://') != -0x1 ? ht14dw['EnvConfig']['load']['call'](nc29s, _f7j8, _s87fl, e0yrxz, l98sk, w4hdt1) : f_8jo['readFile'](f_78s, s_7l, new c7s_8l(fol78, fol78['onReadNativeCallBack'], [s_7l, _f7j8, _s87fl, e0yrxz, l98sk, w4hdt1, nc29s]), _f7j8);
        } else ht14dw['EnvConfig']['load']['call'](this, _f7j8, _s87fl, e0yrxz, l98sk, w4hdt1);
      }
    }, hf7jo_['resMgrLoad'] = function (kn29cs, $c9n, m356a, a5um6, thj4, yer0x, d41uwt) {
      m356a === void 0x0 && (m356a = 0x0), a5um6 === void 0x0 && (a5um6 = ![]), thj4 === void 0x0 && (thj4 = ![]), yer0x === void 0x0 && (yer0x = 0x0), d41uwt === void 0x0 && (d41uwt = 0x3), kn29cs['indexOf']('mpack') != -0x1 && console['log']('=============resMgrLoad url:', kn29cs), ht14dw['EnvConfig']['resMgrLoad'](kn29cs, (fhj_7, skcn9, _s) => {
        fol78['prototype']['resMgrLoadCallBack'](fhj_7, skcn9, _s, $c9n);
      }, m356a, a5um6, thj4, yer0x, d41uwt);
    }, hf7jo_['resMgrLoadCallBack'] = function (d4h1tw, l8_of, a3mu, vr0y3) {
      console['log']('buff:::', d4h1tw, a3mu, f_8jo['fileNativeDir'] + '///' + f_8jo['fileListName']), vr0y3(d4h1tw, l8_of, a3mu);
    }, hf7jo_['clearRes'] = function (l78f_, h_4fj) {
      h_4fj === void 0x0 && (h_4fj = ![]);var rzyex = this;rzyex['clearRes'](l78f_, h_4fj);var d5mt = f_8jo['getFileInfo'](l78f_);if (d5mt && (l78f_['indexOf']('http://') != -0x1 || l78f_['indexOf']('https://') != -0x1)) {
        var dw1ut = d5mt['md5'],
            jof4w = f_8jo['getFileNativePath'](dw1ut);f_8jo['remove'](jof4w);
      }
    }, fol78['onReadNativeCallBack'] = function (yvr03z, w4fjh, k9$2, k9slc8, g$2kn, fhw, n29c$, a6, um56a) {
      k9slc8 === void 0x0 && (k9slc8 = !![]), fhw === void 0x0 && (fhw = ![]), a6 === void 0x0 && (a6 = 0x0);if (!a6) {
        var ipqg$n;if (k9$2 == 'json' || k9$2 == 'atlas') ipqg$n = ht14dw['getJson'](um56a['data']);else k9$2 == 'xml' ? ipqg$n = xrye0z['parseXMLFromString'](um56a['data']) : ipqg$n = um56a['data'];n29c$['onLoaded'](ipqg$n), !ht14dw['isZiYu'] && ht14dw['isPosMsgYu'] && k9$2 != 'arraybuffer' && wx['postMessage']({ 'url': w4fjh, 'data': ipqg$n, 'isLoad': !![] });
      } else a6 == 0x1 && ht14dw['EnvConfig']['load']['call'](n29c$, w4fjh, k9$2, k9slc8, g$2kn, fhw);
    }, ign2k(fol78, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['png', 'jpg', 'bmp', 'jpeg', 'gif'];
    }]), fol78;
  }(),
      f_8jo = function (i$pgnq) {
    function mu6a53() {
      mu6a53['__super']['call'](this);;
    }return hwdjt4(mu6a53, 'laya.wx.mini.MiniFileMgr', i$pgnq), mu6a53['isLoadFile'] = function (u1md) {
      return mu6a53['_fileTypeArr']['indexOf'](u1md) != -0x1 ? !![] : ![];
    }, mu6a53['getFileInfo'] = function (wjo4f) {
      var rxyzv0 = wjo4f['split']('?')[0x0],
          yzr3 = mu6a53['filesListObj'][rxyzv0];if (yzr3 == null) return null;else return yzr3;return null;
    }, mu6a53['onFileUpdate'] = function (s8fl, v35a) {
      var o7fhj = s8fl['split']('/'),
          olf7_8 = o7fhj[o7fhj['length'] - 0x1],
          v0zryx = mu6a53['getFileInfo'](v35a);if (v0zryx == null) mu6a53['onSaveFile'](v35a, olf7_8);else {
        if (v0zryx['readyUrl'] != v35a) mu6a53['remove'](olf7_8, v35a);
      }
    }, mu6a53['exits'] = function (dtum1, kl92cs) {
      var hdtw41 = mu6a53['getFileNativePath'](dtum1);mu6a53['fs']['getFileInfo']({ 'filePath': hdtw41, 'success': function (m6a35) {
          kl92cs != null && kl92cs['runWith']([0x0, m6a35]);
        }, 'fail': function (vxrz0) {
          kl92cs != null && kl92cs['runWith']([0x1, vxrz0]);
        } });
    }, mu6a53['read'] = function (k92$n, v6r0y, cn9k$2, v56am) {
      v6r0y === void 0x0 && (v6r0y = 'ascill'), v56am === void 0x0 && (v56am = '');var sl98c;v56am != '' ? sl98c = mu6a53['getFileNativePath'](k92$n) : sl98c = k92$n, mu6a53['fs']['readFile']({ 'filePath': sl98c, 'encoding': v6r0y, 'success': function (jtd4) {
          cn9k$2 != null && cn9k$2['runWith']([0x0, jtd4]);
        }, 'fail': function (n2cs9) {
          if (n2cs9 && v56am != '') mu6a53['down'](v56am, v6r0y, cn9k$2, v56am);else cn9k$2 != null && cn9k$2['runWith']([0x1]);
        } });
    }, mu6a53['readNativeFile'] = function (oj_f, m56a3u) {
      mu6a53['fs']['readFile']({ 'filePath': oj_f, 'encoding': '', 'success': function (u6ma3) {
          m56a3u != null && m56a3u['runWith']([0x0]);
        }, 'fail': function (dtw1u) {
          m56a3u != null && m56a3u['runWith']([0x1]);
        } });
    }, mu6a53['down'] = function (fs7_l, yv3zr0, s8c9, d14wth) {
      yv3zr0 === void 0x0 && (yv3zr0 = 'ascill'), d14wth === void 0x0 && (d14wth = '');var yx0z = mu6a53['getFileNativePath'](d14wth),
          tmud1w = mu6a53['wxdown']({ 'url': fs7_l, 'filePath': yx0z, 'success': function (thjd4) {
          if (thjd4['statusCode'] === 0xc8) mu6a53['readFile'](thjd4['filePath'], yv3zr0, s8c9, d14wth);
        }, 'fail': function (j_7ofh) {
          s8c9 != null && s8c9['runWith']([0x1, j_7ofh]);
        } });tmud1w['onProgressUpdate'](function (o7j) {
        s8c9 != null && s8c9['runWith']([0x2, o7j['progress']]);
      });
    }, mu6a53['readFile'] = function (g$n92k, u5dt, am16u, $9cn2) {
      u5dt === void 0x0 && (u5dt = 'ascill'), $9cn2 === void 0x0 && ($9cn2 = ''), mu6a53['fs']['readFile']({ 'filePath': g$n92k, 'encoding': u5dt, 'success': function (xyz0re) {
          if (g$n92k['indexOf']('http://') != -0x1 || g$n92k['indexOf']('https://') != -0x1) mu6a53['onFileUpdate'](g$n92k, $9cn2);am16u != null && am16u['runWith']([0x0, xyz0re]);
        }, 'fail': function (k2n) {
          if (k2n) am16u != null && am16u['runWith']([0x1, k2n]);
        } });
    }, mu6a53['downImg'] = function (z3r0v, jo4, ksc8l9) {
      ksc8l9 === void 0x0 && (ksc8l9 = '');var k2c9ns = mu6a53['wxdown']({ 'url': z3r0v, 'success': function (joh_7f) {
          joh_7f['statusCode'] === 0xc8 && mu6a53['copyFile'](joh_7f['tempFilePath'], ksc8l9, jo4);
        }, 'fail': function (a36mu) {
          jo4 != null && jo4['runWith']([0x1, a36mu]);
        } });
    }, mu6a53['copyFile'] = function (r6, r0y63v, f8s7_) {
      var f_j87o = r6['split']('/'),
          a5ud1m = f_j87o[f_j87o['length'] - 0x1],
          l_8sf7 = r0y63v['split']('?')[0x0],
          dtw4h1 = mu6a53['getFileInfo'](r0y63v),
          j_h4f = mu6a53['getFileNativePath'](a5ud1m);mu6a53['fs']['copyFile']({ 'srcPath': r6, 'destPath': j_h4f, 'success': function ($pgiqn) {
          if (!dtw4h1) mu6a53['onSaveFile'](r0y63v, a5ud1m), f8s7_ != null && f8s7_['runWith']([0x0]);else {
            if (dtw4h1['readyUrl'] != r0y63v) mu6a53['remove'](a5ud1m, r0y63v, f8s7_);
          }
        }, 'fail': function (x0rzyv) {
          f8s7_ != null && f8s7_['runWith']([0x1, x0rzyv]);
        } });
    }, mu6a53['getFileNativePath'] = function (_78fj) {
      return laya['wx']['mini']['MiniFileMgr']['fileNativeDir'] + '/' + _78fj;
    }, mu6a53['remove'] = function (w4hjo, $nk2gi, n2k9) {
      $nk2gi === void 0x0 && ($nk2gi = '');var h4t1dw = mu6a53['getFileInfo']($nk2gi),
          nkg2i = mu6a53['getFileNativePath'](h4t1dw['md5']);kg29n['loader']['clearRes'](h4t1dw['readyUrl']), mu6a53['fs']['unlink']({ 'filePath': nkg2i, 'success': function (k92ls) {
          if ($nk2gi != '') mu6a53['onSaveFile']($nk2gi, w4hjo);n2k9 != null && n2k9['runWith']([0x0]);
        }, 'fail': function (g9k2) {} });
    }, mu6a53['onSaveFile'] = function (rxy0, i2$kn) {
      var ua5m16 = rxy0['split']('?')[0x0];mu6a53['filesListObj'][ua5m16] = { 'md5': i2$kn, 'readyUrl': rxy0 }, mu6a53['fs']['writeFile']({ 'filePath': mu6a53['fileNativeDir'] + '/' + mu6a53['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](mu6a53['filesListObj']), 'success': function (n9sck) {
          console['log']('写入测试测试成功：', n9sck);
        }, 'fail': function (h_foj7) {
          console['log']('写入测试测试失败：', h_foj7);
        } });
    }, mu6a53['existDir'] = function (zr0v3, y60a3v) {
      mu6a53['fs']['mkdir']({ 'dirPath': zr0v3, 'success': function (vr6y30) {
          y60a3v != null && y60a3v['runWith']([0x0, { 'data': JSON['stringify']({}) }]);
        }, 'fail': function (udt14) {
          if (udt14['errMsg']['indexOf']('file already exists') != -0x1) mu6a53['readSync'](mu6a53['fileListName'], 'utf8', y60a3v);else y60a3v != null && y60a3v['runWith']([0x1, udt14]);
        } });
    }, mu6a53['readSync'] = function (foj_, h7jf_o, whd, j7f_8) {
      h7jf_o === void 0x0 && (h7jf_o = 'ascill'), j7f_8 === void 0x0 && (j7f_8 = '');var hdt41w = mu6a53['getFileNativePath'](foj_),
          ip$gqn;try {
        ip$gqn = mu6a53['fs']['readFileSync'](hdt41w), whd != null && whd['runWith']([0x0, { 'data': ip$gqn }]);
      } catch (csn29) {
        whd != null && whd['runWith']([0x1]);
      }
    }, mu6a53['readCache'] = function () {}, mu6a53['writeCache'] = function (fow4j) {
      var v5a6m3 = readyUrl['split']('?')[0x0];mu6a53['filesListObj'][v5a6m3] = { 'md5': md5Name, 'readyUrl': readyUrl }, mu6a53['fs']['writeFile']({ 'filePath': mu6a53['fileNativeDir'] + '/' + mu6a53['fileListName'], 'encoding': 'utf8', 'data': JSON['stringify'](mu6a53['filesListObj']), 'success': function (a5udm1) {}, 'fail': function (thwj4) {} });
    }, mu6a53['setNativeFileDir'] = function (du5am1) {
      mu6a53['fileNativeDir'] = wx['env']['USER_DATA_PATH'] + du5am1;
    }, mu6a53['filesListObj'] = {}, mu6a53['fileNativeDir'] = null, mu6a53['fileListName'] = 'layaairfiles.txt', mu6a53['ziyuFileData'] = {}, ign2k(mu6a53, ['_fileTypeArr', function () {
      return this['_fileTypeArr'] = ['json', 'ani', 'xml', 'sk', 'txt', 'atlas', 'swf', 'part', 'fnt', 'proto', 'lh', 'lav', 'lani', 'lmat', 'lm', 'ltc'];
    }, 'fs', function () {
      return this['fs'] = wx['getFileSystemManager']();
    }, 'wxdown', function () {
      return this['wxdown'] = wx['downloadFile'];
    }]), mu6a53;
  }(s9c8kl),
      ry306 = function (ck92s) {
    function jt4hdw() {
      this['_sound'] = null, this['url'] = null, this['loaded'] = ![], jt4hdw['__super']['call'](this), this['_sound'] = jt4hdw['_createSound']();
    }hwdjt4(jt4hdw, 'laya.wx.mini.MiniSound', ck92s);var rzyex0 = jt4hdw['prototype'];return rzyex0['load'] = function (_j4fh) {
      var lsc8k9 = this;_j4fh = jfh7o_['formatURL'](_j4fh), this['url'] = _j4fh;if (jt4hdw['_audioCache'][_j4fh]) {
        this['event']('complete');return;
      }function whfj() {
        if (jt4hdw['_null'] != undefined) lsc8k9['_sound']['onCanplay'](jt4hdw['_null']), lsc8k9['_sound']['onError'](jt4hdw['_null']);else try {
          lsc8k9['_sound']['onCanplay'](null), lsc8k9['_sound']['onError'](null), jt4hdw['_null'] = null;
        } catch (k92c) {
          console['warn']('[wxmini] _clearSound:' + k92c), lsc8k9['_sound']['onCanplay'](j4f_h), lsc8k9['_sound']['onError'](j4f_h), jt4hdw['_null'] = j4f_h;
        }
      }function w1th() {
        whfj(), u356a['loaded'] = !![], u356a['event']('complete'), jt4hdw['_audioCache'][u356a['url']] = u356a;
      }function g$2qin(r3vz0) {
        console['error']('errCode=' + r3vz0['errCode'] + '  errMsg=' + r3vz0['errMsg']), whfj(), u356a['event']('error');
      }function j4f_h() {}this['_sound']['onCanplay'](w1th), this['_sound']['onError'](g$2qin), this['_sound']['src'] = _j4fh;var u356a = this;
    }, rzyex0['play'] = function (wmtdu, _78o) {
      wmtdu === void 0x0 && (wmtdu = 0x0), _78o === void 0x0 && (_78o = 0x0);var _78lsf;if (this['url'] == l8s_7['_tMusic']) {
        if (!jt4hdw['_musicAudio']) jt4hdw['_musicAudio'] = jt4hdw['_createSound']();_78lsf = jt4hdw['_musicAudio'];
      } else _78lsf = jt4hdw['_createSound']();_78lsf['src'] = this['url'];var jhf4 = new twd4j(_78lsf);return jhf4['url'] = this['url'], jhf4['loops'] = _78o, jhf4['startTime'] = wmtdu, jhf4['play'](), l8s_7['addChannel'](jhf4), jhf4;
    }, rzyex0['dispose'] = function () {
      var v5a63 = jt4hdw['_audioCache'][this['url']];v5a63 && (v5a63['src'] = '', delete jt4hdw['_audioCache'][this['url']]);
    }, l8s_(0x0, rzyex0, 'duration', function () {
      return this['_sound']['duration'];
    }), jt4hdw['_createSound'] = function () {
      return jt4hdw['_id']++, ht14dw['window']['wx']['createInnerAudioContext']();
    }, jt4hdw['_musicAudio'] = null, jt4hdw['_id'] = 0x0, jt4hdw['_audioCache'] = {}, jt4hdw['_null'] = undefined, jt4hdw;
  }(s9c8kl),
      twd4j = function (v0y3r6) {
    function whtjd($cn2k9) {
      this['_audio'] = null, this['_onEnd'] = null, whtjd['__super']['call'](this), this['_audio'] = $cn2k9, this['_onEnd'] = xrye0z['bind'](this['__onEnd'], this), $cn2k9['onEnded'](this['_onEnd']);
    }hwdjt4(whtjd, 'laya.wx.mini.MiniSoundChannel', v0y3r6);var thjo4w = whtjd['prototype'];return thjo4w['__onEnd'] = function () {
      if (this['loops'] == 0x1) {
        this['completeHandler'] && (kg29n['timer']['once'](0xa, this, this['__runComplete'], [this['completeHandler']], ![]), this['completeHandler'] = null);this['stop'](), this['event']('complete');return;
      }this['loops'] > 0x0 && this['loops']--, this['startTime'] = 0x0, this['play']();
    }, thjo4w['__onNull'] = function () {}, thjo4w['play'] = function () {
      this['isStopped'] = ![], l8s_7['addChannel'](this);if (this['_audio']) this['_audio']['play']();
    }, thjo4w['stop'] = function () {
      this['isStopped'] = !![], l8s_7['removeChannel'](this), this['completeHandler'] = null;if (!this['_audio']) return;this['_audio']['stop']();if (whtjd['_null'] != undefined) this['_audio']['onEnded'](whtjd['_null']);else try {
        this['_audio']['onEnded'](null), whtjd['_null'] = null;
      } catch (ex0yz) {
        console['warn']('[wxmini] stop:' + ex0yz), this['_audio']['onEnded'](xrye0z['bind'](this['__onNull'], this)), whtjd['_null'] = xrye0z['bind'](this['__onNull'], this);
      }this['_audio'] = null;
    }, thjo4w['pause'] = function () {
      this['isStopped'] = !![], this['_audio']['pause']();
    }, thjo4w['resume'] = function () {
      if (!this['_audio']) return;this['isStopped'] = ![], l8s_7['addChannel'](this), this['_audio']['play']();
    }, l8s_(0x0, thjo4w, 'position', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['currentTime'];
    }), l8s_(0x0, thjo4w, 'duration', function () {
      if (!this['_audio']) return 0x0;return this['_audio']['duration'];
    }), l8s_(0x0, thjo4w, 'volume', function () {
      return 0x1;
    }, function (h4twd1) {}), whtjd['_null'] = undefined, whtjd;
  }(cls8);
})(window, document, Laya);typeof define === 'function' && define['amd'] && define('laya.core', ['require', 'exports'], function (require, exports) {
  'use strict';

  Object['defineProperty'](exports, '__esModule', { 'value': !![] });for (var pgn$q in Laya) {
    var $kgi = Laya[pgn$q];$kgi && $kgi['__isclass'] && (exports[pgn$q] = $kgi);
  }
});