var a = wx.$y;
function yf_s8(fj8_7) {
  this['options'] = fj8_7 || { 'locator': {} };
}function ym1wudt(y60v3r, ck9sl, nkc9s) {
  function qn$2i(_8l7cs) {
    var of4hwj = y60v3r[_8l7cs];!of4hwj && dh14w && (of4hwj = 0x2 == y60v3r['length'] ? function (ls_8c) {
      y60v3r(_8l7cs, ls_8c);
    } : y60v3r), _8fo7[_8l7cs] = of4hwj && function (ng$piq) {
      of4hwj('[xmldom ' + _8l7cs + ']\t' + ng$piq + yzxr0e(nkc9s));
    } || function () {};
  }if (!y60v3r) {
    if (ck9sl instanceof yxryze) return ck9sl;y60v3r = ck9sl;
  }var _8fo7 = {},
      dh14w = y60v3r instanceof Function;return nkc9s = nkc9s || {}, qn$2i('warning'), qn$2i('error'), qn$2i('fatalError'), _8fo7;
}function yxryze() {
  this['cdata'] = !0x1;
}function yy0r(tdu5m, k9$2gn) {
  k9$2gn['lineNumber'] = tdu5m['lineNumber'], k9$2gn['columnNumber'] = tdu5m['columnNumber'];
}function yzxr0e(owjht) {
  return owjht ? '\x0a@' + (owjht['systemId'] || '') + '#[line:' + owjht['lineNumber'] + ',col:' + owjht['columnNumber'] + ']' : void 0x0;
}function yckn9(lk8s9c, _j4ho, gp$nq) {
  return 'string' == typeof lk8s9c ? lk8s9c['substr'](_j4ho, gp$nq) : lk8s9c['length'] >= _j4ho + gp$nq || _j4ho ? new java['lang']['String'](lk8s9c, _j4ho, gp$nq) + '' : lk8s9c;
}function yq2i$ng(f8_7s, re0yxz) {
  f8_7s['currentElement'] ? f8_7s['currentElement']['appendChild'](re0yxz) : f8_7s['doc']['appendChild'](re0yxz);
}yf_s8['prototype']['parseFromString'] = function (t4woh, j_f4o) {
  var $pigqn = this['options'],
      dwhtj = new yxzrv0y(),
      s7_f = $pigqn['domBuilder'] || new yxryze(),
      ya0v36 = $pigqn['errorHandler'],
      xyze0 = $pigqn['locator'],
      exz0 = $pigqn['xmlns'] || {},
      mt51 = { 'lt': '<', 'gt': '>', 'amp': '&', 'quot': '\x22', 'apos': '\x27' };return xyze0 && s7_f['setDocumentLocator'](xyze0), dwhtj['errorHandler'] = ym1wudt(ya0v36, s7_f, xyze0), dwhtj['domBuilder'] = $pigqn['domBuilder'] || s7_f, /\/x?html?$/['test'](j_f4o) && (mt51['nbsp'] = '\u00a0', mt51['copy'] = '©', exz0[''] = 'http://www.w3.org/1999/xhtml'), exz0['xml'] = exz0['xml'] || 'http://www.w3.org/XML/1998/namespace', t4woh ? dwhtj['parse'](t4woh, exz0, mt51) : dwhtj['errorHandler']['error']('invalid doc source'), s7_f['doc'];
}, yxryze['prototype'] = { 'startDocument': function () {
    this['doc'] = new y_8f7o()['createDocument'](null, null, null), this['locator'] && (this['doc']['documentURI'] = this['locator']['systemId']);
  }, 'startElement': function (nkg$2, cnk9, $9gnk, jhwo4f) {
    var fjw = this['doc'],
        qgn2$ = fjw['createElementNS'](nkg$2, $9gnk || cnk9),
        h_jof = jhwo4f['length'];yq2i$ng(this, qgn2$), this['currentElement'] = qgn2$, this['locator'] && yy0r(this['locator'], qgn2$);for (var wm1ut = 0x0; h_jof > wm1ut; wm1ut++) {
      var nkg$2 = jhwo4f['getURI'](wm1ut),
          rvzx0y = jhwo4f['getValue'](wm1ut),
          $9gnk = jhwo4f['getQName'](wm1ut),
          vxyz = fjw['createAttributeNS'](nkg$2, $9gnk);this['locator'] && yy0r(jhwo4f['getLocator'](wm1ut), vxyz), vxyz['value'] = vxyz['nodeValue'] = rvzx0y, qgn2$['setAttributeNode'](vxyz);
    }
  }, 'endElement': function () {
    {
      var f8s_7 = this['currentElement'];f8s_7['tagName'];
    }this['currentElement'] = f8s_7['parentNode'];
  }, 'startPrefixMapping': function () {}, 'endPrefixMapping': function () {}, 'processingInstruction': function (hj4wfo, a6vm5) {
    var $pqngi = this['doc']['createProcessingInstruction'](hj4wfo, a6vm5);this['locator'] && yy0r(this['locator'], $pqngi), yq2i$ng(this, $pqngi);
  }, 'ignorableWhitespace': function () {}, 'characters': function (s7cl89) {
    if (s7cl89 = yckn9['apply'](this, arguments)) {
      if (this['cdata']) var tud1m = this['doc']['createCDATASection'](s7cl89);else var tud1m = this['doc']['createTextNode'](s7cl89);this['currentElement'] ? this['currentElement']['appendChild'](tud1m) : /^\s*$/['test'](s7cl89) && this['doc']['appendChild'](tud1m), this['locator'] && yy0r(this['locator'], tud1m);
    }
  }, 'skippedEntity': function () {}, 'endDocument': function () {
    this['doc']['normalize']();
  }, 'setDocumentLocator': function (m61ua) {
    (this['locator'] = m61ua) && (m61ua['lineNumber'] = 0x0);
  }, 'comment': function (hotj) {
    hotj = yckn9['apply'](this, arguments);var fl7_s = this['doc']['createComment'](hotj);this['locator'] && yy0r(this['locator'], fl7_s), yq2i$ng(this, fl7_s);
  }, 'startCDATA': function () {
    this['cdata'] = !0x0;
  }, 'endCDATA': function () {
    this['cdata'] = !0x1;
  }, 'startDTD': function (g$n2qi, f_7ojh, mt1udw) {
    var s2kc = this['doc']['implementation'];if (s2kc && s2kc['createDocumentType']) {
      var vxz0yr = s2kc['createDocumentType'](g$n2qi, f_7ojh, mt1udw);this['locator'] && yy0r(this['locator'], vxz0yr), yq2i$ng(this, vxz0yr);
    }
  }, 'warning': function (wjd4h) {
    console['warn']('[xmldom warning]\t' + wjd4h, yzxr0e(this['locator']));
  }, 'error': function (l8fo_) {
    console['error']('[xmldom error]\t' + l8fo_, yzxr0e(this['locator']));
  }, 'fatalError': function (i2$gq) {
    throw console['error']('[xmldom fatalError]\t' + i2$gq, yzxr0e(this['locator'])), i2$gq;
  } }, 'endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl'['replace'](/\w+/g, function (ls_8) {
  yxryze['prototype'][ls_8] = function () {
    return null;
  };
});var yxzrv0y = require('./yycyy')['XMLReader'],
    y_8f7o = exports['DOMImplementation'] = require('./yyDOyy')['DOMImplementation'];exports['XMLSerializer'] = require('./yyDOyy')['XMLSerializer'], exports['DOMParser'] = yf_s8;