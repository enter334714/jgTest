var a = wx.$y;
console[a[420982]](a[421230]), window[a[421231]], wx[a[421232]](function (qni2g$) {
  if (qni2g$) {
    if (qni2g$[a[420056]]) {
      var a65vm3 = window[a[420917]][a[420918]][a[420243]](new RegExp(/\./, 'g'), '_'),
          ofl_ = qni2g$[a[420056]],
          g$nqip = ofl_[a[420067]](/(yyyyy\/yyGAMEy.js:)[0-9]{1,60}(:)/g);if (g$nqip) for (var $nk9 = 0x0; $nk9 < g$nqip[a[420031]]; $nk9++) {
        if (g$nqip[$nk9] && g$nqip[$nk9][a[420031]] > 0x0) {
          var hj4two = parseInt(g$nqip[$nk9][a[420243]](a[421233], '')[a[420243]](':', ''));ofl_ = ofl_[a[420243]](g$nqip[$nk9], g$nqip[$nk9][a[420243]](':' + hj4two + ':', ':' + (hj4two - 0x2) + ':'));
        }
      }ofl_ = ofl_[a[420243]](new RegExp(a[421234], 'g'), a[421235] + a65vm3 + a[421236]), ofl_ = ofl_[a[420243]](new RegExp(a[421237], 'g'), a[421235] + a65vm3 + a[421236]), qni2g$[a[420056]] = ofl_;
    }var ncks29 = { 'id': window['y2S0'][a[420991]], 'role': window['y2S0'][a[420992]], 'level': window['y2S0'][a[420993]], 'user': window['y2S0'][a[420994]], 'version': window['y2S0'][a[420955]], 'cdn': window['y2S0'][a[420995]], 'pkgName': window['y2S0'][a[420938]], 'gamever': window[a[420917]][a[420918]], 'serverid': window['y2S0'][a[420944]] ? window['y2S0'][a[420944]][a[420996]] : 0x0, 'systemInfo': window[a[420997]], 'error': a[421238], 'stack': qni2g$ ? qni2g$[a[420056]] : '' },
        d1wmu = JSON[a[420999]](ncks29);console[a[420333]](a[421239] + d1wmu), (!window[a[421231]] || window[a[421231]] != ncks29[a[420333]]) && (window[a[421231]] = ncks29[a[420333]], window['y2$S'](ncks29));
  }
});import 'yybfyy.js';import 'yy11yy.js';window[a[421240]] = require(a[421241]);import 'yINDyy.js';import 'yyIB1yy.js';import 'yyMtadyy.js';import 'yyINIyy.js';console[a[420982]](a[421242]), console[a[420982]](a[421243]), y2$S50({ 'title': a[421244] });var yk2$gn = { 'y29$0S5': !![] };new window[a[420978]](yk2$gn), window[a[420978]][a[420979]]['y295S0$']();if (window['y29$S05']) clearInterval(window['y29$S05']);window['y29$S05'] = null, window['y2950$S'] = function (a5u1m6, v6a3y0) {
  if (!a5u1m6 || !v6a3y0) return 0x0;a5u1m6 = a5u1m6[a[420201]]('.'), v6a3y0 = v6a3y0[a[420201]]('.');const y0vrz3 = Math[a[420301]](a5u1m6[a[420031]], v6a3y0[a[420031]]);while (a5u1m6[a[420031]] < y0vrz3) {
    a5u1m6[a[420066]]('0');
  }while (v6a3y0[a[420031]] < y0vrz3) {
    v6a3y0[a[420066]]('0');
  }for (var m6au5 = 0x0; m6au5 < y0vrz3; m6au5++) {
    const wojt4 = parseInt(a5u1m6[m6au5]),
          vy3a = parseInt(v6a3y0[m6au5]);if (wojt4 > vy3a) return 0x1;else {
      if (wojt4 < vy3a) return -0x1;
    }
  }return 0x0;
}, window[a[421124]] = wx[a[421245]]()[a[421124]], console[a[420225]](a[421246] + window[a[421124]]);var yl9ks = wx[a[421247]]();yl9ks[a[421248]](function (y06rv) {
  console[a[420225]](a[421249] + y06rv[a[421250]]);
}), yl9ks[a[421251]](function () {
  wx[a[420964]]({ 'title': a[421252], 'content': a[421253], 'showCancel': ![], 'success': function (qni2$) {
      yl9ks[a[421254]]();
    } });
}), yl9ks[a[421255]](function () {
  console[a[420225]](a[421256]);
}), window['y2950S$'] = function () {
  console[a[420225]](a[421257]);var m651ua = wx[a[421258]]({ 'name': a[421259], 'success': function (towhj) {
      console[a[420225]](a[421260]), console[a[420225]](towhj), towhj && towhj[a[421045]] == a[421261] ? (window['y205'] = !![], window['y205S$'](), window['y20S$5']()) : setTimeout(function () {
        window['y2950S$']();
      }, 0x1f4);
    }, 'fail': function (n29$kg) {
      console[a[420225]](a[421262]), console[a[420225]](n29$kg), setTimeout(function () {
        window['y2950S$']();
      }, 0x1f4);
    } });m651ua && m651ua[a[421263]](ckl98s => {});
}, window['y29S$05'] = function () {
  console[a[420225]](a[421264]);var v0ry63 = wx[a[421258]]({ 'name': a[421265], 'success': function (npi$qg) {
      console[a[420225]](a[421266]), console[a[420225]](npi$qg), npi$qg && npi$qg[a[421045]] == a[421261] ? (window['y2S50'] = !![], window['y205S$'](), window['y20S$5']()) : setTimeout(function () {
        window['y29S$05']();
      }, 0x1f4);
    }, 'fail': function (y3r60v) {
      console[a[420225]](a[421267]), console[a[420225]](y3r60v), setTimeout(function () {
        window['y29S$05']();
      }, 0x1f4);
    } });v0ry63 && v0ry63[a[421263]](k2g$in => {});
}, window[a[421268]] = function () {
  window['y2950$S'](window[a[421124]], a[421269]) >= 0x0 ? (console[a[420225]](a[421270] + window[a[421124]] + a[421271]), window['y2S$'](), window['y2950S$'](), window['y29S$05']()) : (window['y2S0$'](a[421272], window[a[421124]]), wx[a[420964]]({ 'title': a[420965], 'content': a[421273] }));
}, window[a[420997]] = '', wx[a[421274]]({ 'success'(a5ud1m) {
    window[a[420997]] = a[421275] + a5ud1m[a[421276]] + a[421277] + a5ud1m[a[421278]] + a[421279] + a5ud1m[a[420924]] + a[421280] + a5ud1m[a[421281]] + a[421282] + a5ud1m[a[421060]] + a[421283] + a5ud1m[a[421124]] + a[421284] + a5ud1m[a[421285]], console[a[420225]](window[a[420997]]), console[a[420225]](a[421286] + a5ud1m[a[421287]] + a[421288] + a5ud1m[a[421289]] + a[421290] + a5ud1m[a[421291]] + a[421292] + a5ud1m[a[421293]] + a[421294] + a5ud1m[a[421295]] + a[421296] + a5ud1m[a[421297]] + a[421298] + (a5ud1m[a[421299]] ? a5ud1m[a[421299]][a[421210]] + ',' + a5ud1m[a[421299]][a[421213]] + ',' + a5ud1m[a[421299]][a[421215]] + ',' + a5ud1m[a[421299]][a[421217]] : ''));var yxrze0 = a5ud1m[a[421281]] ? a5ud1m[a[421281]][a[420103]]() : '',
        lf8_7 = a5ud1m[a[421278]] ? a5ud1m[a[421278]][a[420103]]()[a[420243]]('\x20', '') : '';window['y2S0'][a[420957]] = yxrze0[a[420146]](a[421300]) != -0x1, window['y2S0'][a[420958]] = yxrze0[a[420146]](a[421301]) != -0x1, window['y2S0'][a[421209]] = yxrze0[a[420146]](a[421300]) != -0x1 || yxrze0[a[420146]](a[421301]) != -0x1, window['y2S0'][a[420959]] = yxrze0[a[420146]](a[421302]) != -0x1 || yxrze0[a[420146]](a[420926]) != -0x1, window['y2S0'][a[421005]] = a5ud1m[a[421060]] ? a5ud1m[a[421060]][a[420103]]() : '', window['y2S0']['y29$50S'] = ![], window['y2S0']['y29$S50'] = 0x2;if (yxrze0[a[420146]](a[421301]) != -0x1) {
      if (a5ud1m[a[421285]] >= 0x18) window['y2S0']['y29$S50'] = 0x3;else window['y2S0']['y29$S50'] = 0x2;
    } else {
      if (yxrze0[a[420146]](a[421300]) != -0x1) {
        if (a5ud1m[a[421285]] && a5ud1m[a[421285]] >= 0x14) window['y2S0']['y29$S50'] = 0x3;else {
          if (lf8_7[a[420146]](a[421303]) != -0x1 || lf8_7[a[420146]](a[421304]) != -0x1 || lf8_7[a[420146]](a[421305]) != -0x1 || lf8_7[a[420146]](a[421306]) != -0x1 || lf8_7[a[420146]](a[421307]) != -0x1) window['y2S0']['y29$S50'] = 0x2;else window['y2S0']['y29$S50'] = 0x3;
        }
      } else window['y2S0']['y29$S50'] = 0x2;
    }console[a[420225]](a[421308] + window['y2S0']['y29$50S'] + a[421309] + window['y2S0']['y29$S50']);
  } }), wx[a[421143]]({ 'success': function (y0vzr) {
    console[a[420225]](a[421310] + y0vzr[a[421145]] + a[421311] + y0vzr[a[421147]]);
  } }), wx[a[421312]]({ 'success': function (tdmu1w) {
    console[a[420225]](a[421313] + tdmu1w[a[421314]]);
  } }), wx[a[421315]]({ 'keepScreenOn': !![] }), wx[a[421316]](function (c9$2kn) {
  console[a[420225]](a[421313] + c9$2kn[a[421314]] + a[421317] + c9$2kn[a[421318]]);
}), wx[a[421118]](function (qnigp) {
  window['y25$'] = qnigp, window['y20$5'] && window['y25$'] && (console[a[420982]](a[421119] + window['y25$'][a[421120]]), window['y20$5'](window['y25$']), window['y25$'] = null);
}), window[a[421319]] = 0x0, window['y29S50$'] = 0x0, window[a[421320]] = null, wx[a[421321]](function () {
  window['y29S50$']++;var a1umd5 = Date[a[420950]]();(window[a[421319]] == 0x0 || a1umd5 - window[a[421319]] > 0x1d4c0) && (console[a[420383]](a[421322]), wx[a[421323]]());if (window['y29S50$'] >= 0x2) {
    window['y29S50$'] = 0x0, console[a[420333]](a[421324]), wx[a[421325]]('0', 0x1);if (window['y2S0'] && window['y2S0'][a[420957]]) window['y2S0$'](a[421326], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});