var W = wx.$l;
import L9ue17v from '../llllSDK/llllSDDK.js';window[W[565]] = { 'wxVersion': window[W[441]][W[442]] }, window[W[566]] = ![], window['$LDH'] = 0x1, window[W[567]] = 0x1, window['$L0HD'] = !![], window[W[568]] = !![], window['$LBT0HD'] = '', window['$LHD'] = { 'base_cdn': W[569], 'cdn': W[569] }, $LHD[W[570]] = {}, $LHD[W[571]] = '0', $LHD[W[502]] = window[W[565]][W[208]], $LHD[W[533]] = '', $LHD['os'] = '1', $LHD[W[572]] = W[573], $LHD[W[574]] = W[575], $LHD[W[576]] = W[577], $LHD[W[578]] = W[579], $LHD[W[580]] = W[581], $LHD[W[582]] = '1', $LHD[W[262]] = '', $LHD[W[583]] = '', $LHD[W[584]] = 0x0, $LHD[W[303]] = {}, $LHD[W[585]] = parseInt($LHD[W[582]]), $LHD[W[586]] = $LHD[W[582]], $LHD[W[149]] = {}, $LHD['$LTH'] = W[587], $LHD[W[588]] = ![], $LHD[W[589]] = W[590], $LHD[W[591]] = Date[W[144]](), $LHD[W[592]] = W[593], $LHD[W[594]] = '_a', $LHD[W[193]] = 0x1, $LHD[W[206]] = 0x7c1, $LHD[W[208]] = window[W[565]][W[208]], $LHD[W[595]] = ![], $LHD[W[526]] = ![], $LHD[W[528]] = ![], $LHD[W[531]] = ![], window['$L0DH'] = 0x5, window['$L0D'] = ![], window['$LD0'] = ![], window['$LH0D'] = ![], window[W[382]] = ![], window[W[385]] = ![], window['$LHD0'] = ![], window['$L0H'] = ![], window['$LH0'] = ![], window['$LD0H'] = ![], window[W[596]] = function (hqzt5l) {
  console[W[310]](W[596], hqzt5l), wx[W[597]]({}), wx[W[471]]({ 'title': W[494], 'content': hqzt5l, 'success'(lfqt5) {
      if (lfqt5[W[598]]) console[W[310]](W[599]);else lfqt5[W[600]] && console[W[310]](W[601]);
    } });
}, window['$LT0HD'] = function (akb2$) {
  console[W[310]](W[602], akb2$), $LTHD0(), wx[W[471]]({ 'title': W[494], 'content': akb2$, 'confirmText': W[603], 'cancelText': W[604], 'success'(mi3cw) {
      if (mi3cw[W[598]]) window['$LHT']();else mi3cw[W[600]] && (console[W[310]](W[605]), wx[W[606]]({}));
    } });
}, window[W[607]] = function (bkh2aj) {
  console[W[310]](W[607], bkh2aj), wx[W[471]]({ 'title': W[494], 'content': bkh2aj, 'confirmText': W[608], 'showCancel': ![], 'complete'(y84nx) {
      console[W[310]](W[605]), wx[W[606]]({});
    } });
}, window['$LT0DH'] = ![], window['$LTH0D'] = function (fto9l) {
  window['$LT0DH'] = !![], wx[W[609]](fto9l);
}, window['$LTHD0'] = function () {
  window['$LT0DH'] && (window['$LT0DH'] = ![], wx[W[597]]({}));
}, window['$LTD0H'] = function (eg71u) {
  window[W[435]][W[145]]['$LTD0H'](eg71u);
}, window[W[610]] = function (kqjhzl, c3rmi0) {
  L9ue17v[W[610]](kqjhzl, function (c3imr0) {
    c3imr0 && c3imr0[W[314]] ? c3imr0[W[314]][W[313]] == 0x1 ? c3rmi0(!![]) : (c3rmi0(![]), console[W[436]](W[611] + c3imr0[W[314]][W[612]])) : console[W[310]](W[610], c3imr0);
  });
}, window['$LTDH0'] = function (xs8_) {
  console[W[310]](W[613], xs8_);
}, window['$LTHD'] = function (z5hqlt) {}, window['$LTDH'] = function (uve71, ny4x_, hzq5lt) {}, window['$LTD'] = function (m3c0y) {
  console[W[310]](W[614], m3c0y), window[W[435]][W[145]][W[197]](), window[W[435]][W[145]][W[198]](), window[W[435]][W[145]][W[212]]();
}, window['$LDT'] = function (aqjhz) {
  window['$LT0HD'](W[615]);var gu6p1 = { 'id': window['$LHD'][W[449]], 'role': window['$LHD'][W[450]], 'level': window['$LHD'][W[451]], 'account': window['$LHD'][W[452]], 'version': window['$LHD'][W[206]], 'cdn': window['$LHD'][W[296]], 'pkgName': window['$LHD'][W[262]], 'gamever': window[W[441]][W[442]], 'serverid': window['$LHD'][W[149]] ? window['$LHD'][W[149]][W[150]] : 0x0, 'systemInfo': window[W[453]], 'error': W[616], 'stack': aqjhz ? aqjhz : W[615] },
      yrmc0 = JSON[W[402]](gu6p1);console[W[404]](W[617] + yrmc0), window['$LTH'](yrmc0);
}, window['$LHTD'] = function (s4x8n_) {
  var d2bs8$ = JSON[W[618]](s4x8n_);d2bs8$[W[619]] = window[W[441]][W[442]], d2bs8$[W[620]] = window['$LHD'][W[149]] ? window['$LHD'][W[149]][W[150]] : 0x0, d2bs8$[W[453]] = window[W[453]];var kajb2 = JSON[W[402]](d2bs8$);console[W[404]](W[621] + kajb2), window['$LTH'](kajb2);
}, window['$LHDT'] = function (hbakz, z5tqhl) {
  var ev91o = { 'id': window['$LHD'][W[449]], 'role': window['$LHD'][W[450]], 'level': window['$LHD'][W[451]], 'account': window['$LHD'][W[452]], 'version': window['$LHD'][W[206]], 'cdn': window['$LHD'][W[296]], 'pkgName': window['$LHD'][W[262]], 'gamever': window[W[441]][W[442]], 'serverid': window['$LHD'][W[149]] ? window['$LHD'][W[149]][W[150]] : 0x0, 'systemInfo': window[W[453]], 'error': hbakz, 'stack': z5tqhl },
      x0_n = JSON[W[402]](ev91o);console[W[421]](W[622] + x0_n), window['$LTH'](x0_n);
}, window['$LTH'] = function (zklqhj) {
  if (window['$LHD'][W[534]] == W[623]) return;var cr3y0m = $LHD['$LTH'] + W[624] + $LHD[W[452]];wx[W[625]]({ 'url': cr3y0m, 'method': W[626], 'data': zklqhj, 'header': { 'content-type': W[627], 'cache-control': W[628] }, 'success': function (pu6e1g) {
      DEBUG && console[W[310]](W[629], cr3y0m, zklqhj, pu6e1g);
    }, 'fail': function ($2bsad) {
      DEBUG && console[W[310]](W[629], cr3y0m, zklqhj, $2bsad);
    }, 'complete': function () {} });
}, window[W[630]] = function () {
  function tf9lo5() {
    return ((0x1 + Math[W[200]]()) * 0x10000 | 0x0)[W[631]](0x10)[W[632]](0x1);
  }return tf9lo5() + tf9lo5() + '-' + tf9lo5() + '-' + tf9lo5() + '-' + tf9lo5() + '+' + tf9lo5() + tf9lo5() + tf9lo5();
}, window['$LHT'] = function () {
  console[W[310]](W[633]);var goe71v = L9ue17v[W[634]]();$LHD[W[586]] = goe71v[W[635]], $LHD[W[585]] = goe71v[W[635]], $LHD[W[582]] = goe71v[W[635]], $LHD[W[262]] = goe71v[W[636]];var f5lo9t = { 'game_ver': $LHD[W[502]] };$LHD[W[583]] = this[W[630]](), $LTH0D({ 'title': W[637] }), L9ue17v[W[347]](f5lo9t, this['$LDTH'][W[204]](this));
}, window['$LDTH'] = function (qlh) {
  var voge71 = qlh[W[638]];console[W[310]](W[639] + voge71 + W[640] + (voge71 == 0x1) + W[641] + qlh[W[442]] + W[642] + window[W[565]][W[208]]);if (!qlh[W[442]] || window['$LB0DTH'](window[W[565]][W[208]], qlh[W[442]]) < 0x0) console[W[310]](W[643]), $LHD[W[574]] = W[644], $LHD[W[576]] = W[645], $LHD[W[578]] = W[646], $LHD[W[296]] = W[647], $LHD[W[648]] = W[649], $LHD[W[650]] = W[651], $LHD[W[595]] = ![];else window['$LB0DTH'](window[W[565]][W[208]], qlh[W[442]]) == 0x0 ? (console[W[310]](W[652]), $LHD[W[574]] = W[575], $LHD[W[576]] = W[577], $LHD[W[578]] = W[579], $LHD[W[296]] = W[569], $LHD[W[648]] = W[649], $LHD[W[650]] = W[651], $LHD[W[595]] = !![]) : (console[W[310]](W[653]), $LHD[W[574]] = W[575], $LHD[W[576]] = W[577], $LHD[W[578]] = W[579], $LHD[W[296]] = W[569], $LHD[W[648]] = W[649], $LHD[W[650]] = W[651], $LHD[W[595]] = ![]);$LHD[W[584]] = config[W[654]] ? config[W[654]] : 0x0, this['$L0HTD'](), this['$L0HDT'](), window[W[655]] = 0x5, $LTH0D({ 'title': W[656] }), L9ue17v[W[657]](this['$LDHT'][W[204]](this));
}, window[W[655]] = 0x5, window['$LDHT'] = function (d$4s_, qzlkjh) {
  if (d$4s_ == 0x0 && qzlkjh && qzlkjh[W[658]]) {
    $LHD[W[659]] = qzlkjh[W[658]];var o957f = this;$LTH0D({ 'title': W[660] }), sendApi($LHD[W[574]], W[661], { 'platform': $LHD[W[572]], 'partner_id': $LHD[W[582]], 'token': qzlkjh[W[658]], 'game_pkg': $LHD[W[262]], 'deviceId': $LHD[W[583]], 'scene': W[662] + $LHD[W[584]] }, this['$L0THD'][W[204]](this), $L0DH, $LDT);
  } else qzlkjh && qzlkjh[W[481]] && window[W[655]] > 0x0 && (qzlkjh[W[481]][W[424]](W[663]) != -0x1 || qzlkjh[W[481]][W[424]](W[664]) != -0x1 || qzlkjh[W[481]][W[424]](W[665]) != -0x1 || qzlkjh[W[481]][W[424]](W[666]) != -0x1 || qzlkjh[W[481]][W[424]](W[667]) != -0x1 || qzlkjh[W[481]][W[424]](W[668]) != -0x1) ? (window[W[655]]--, L9ue17v[W[657]](this['$LDHT'][W[204]](this))) : (window['$LHDT'](W[669], JSON[W[402]]({ 'status': d$4s_, 'data': qzlkjh })), window['$LT0HD'](W[670] + (qzlkjh && qzlkjh[W[481]] ? '，' + qzlkjh[W[481]] : '')));
}, window['$L0THD'] = function (v61u) {
  if (!v61u) {
    window['$LHDT'](W[671], W[672]), window['$LT0HD'](W[673]);return;
  }if (v61u[W[313]] != W[312]) {
    window['$LHDT'](W[671], JSON[W[402]](v61u)), window['$LT0HD'](W[674] + v61u[W[313]]);return;
  }$LHD[W[675]] = String(v61u[W[452]]), $LHD[W[452]] = String(v61u[W[452]]), $LHD[W[506]] = String(v61u[W[506]]), $LHD[W[586]] = String(v61u[W[506]]), $LHD[W[676]] = String(v61u[W[676]]), $LHD[W[677]] = String(v61u[W[678]]), $LHD[W[679]] = String(v61u[W[680]]), $LHD[W[678]] = '';var rmic = this;$LTH0D({ 'title': W[681] }), sendApi($LHD[W[574]], W[682], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, rmic['$L0TDH'][W[204]](rmic), $L0DH, $LDT);
}, window['$L0TDH'] = function (ofl9) {
  if (!ofl9) {
    window['$LT0HD'](W[683]);return;
  }if (ofl9[W[313]] != W[312]) {
    window['$LT0HD'](W[684] + ofl9[W[313]]);return;
  }if (!ofl9[W[314]] || ofl9[W[314]][W[178]] == 0x0) {
    window['$LT0HD'](W[685]);return;
  }$LHD[W[391]] = ofl9[W[686]], $LHD[W[149]] = { 'server_id': String(ofl9[W[314]][0x0][W[150]]), 'server_name': String(ofl9[W[314]][0x0][W[290]]), 'entry_ip': ofl9[W[314]][0x0][W[687]], 'entry_port': parseInt(ofl9[W[314]][0x0][W[688]]), 'status': $LH0T(ofl9[W[314]][0x0]), 'start_time': ofl9[W[314]][0x0][W[689]], 'cdn': $LHD[W[296]] }, this['$LDH0T']();
}, window['$LDH0T'] = function () {
  if ($LHD[W[391]] == 0x1) {
    var o7g = $LHD[W[149]][W[289]];if (o7g === -0x1 || o7g === 0x0) {
      window['$LT0HD'](o7g === -0x1 ? W[690] : W[691]);return;
    }$LDT0H(0x0, $LHD[W[149]][W[150]]), window[W[435]][W[145]][W[386]]($LHD[W[391]]);
  } else window[W[435]][W[145]][W[383]](), $LTHD0();window['$LH0'] = !![], window['$LD0HT'](), window['$LDHT0']();
}, window['$L0HTD'] = function () {
  sendApi($LHD[W[574]], W[692], { 'game_pkg': $LHD[W[262]], 'version_name': $LHD[W[650]] }, this[W[693]][W[204]](this), $L0DH, $LDT);
}, window[W[693]] = function (ymc30) {
  if (!ymc30) {
    window['$LT0HD'](W[694]);return;
  }if (ymc30[W[313]] != W[312]) {
    window['$LT0HD'](W[695] + ymc30[W[313]]);return;
  }if (!ymc30[W[314]] || !ymc30[W[314]][W[502]]) {
    window['$LT0HD'](W[696] + (ymc30[W[314]] && ymc30[W[314]][W[502]]));return;
  }ymc30[W[314]][W[697]] && ymc30[W[314]][W[697]][W[178]] > 0xa && ($LHD[W[698]] = ymc30[W[314]][W[697]], $LHD[W[296]] = ymc30[W[314]][W[697]]), ymc30[W[314]][W[502]] && ($LHD[W[206]] = ymc30[W[314]][W[502]]), console[W[436]](W[699] + $LHD[W[206]] + W[700] + $LHD[W[650]]), window['$LHD0'] = !![], window['$LD0HT'](), window['$LDHT0']();
}, window[W[701]], window['$L0HDT'] = function () {
  sendApi($LHD[W[574]], W[702], { 'game_pkg': $LHD[W[262]] }, this['$L0DTH'][W[204]](this), $L0DH, $LDT);
}, window['$L0DTH'] = function (tzlf5q) {
  if (tzlf5q[W[313]] === W[312] && tzlf5q[W[314]]) {
    window[W[701]] = tzlf5q[W[314]];for (var _d4s$ in tzlf5q[W[314]]) {
      $LHD[_d4s$] = tzlf5q[W[314]][_d4s$];
    }
  } else console[W[436]](W[703] + tzlf5q[W[313]]);window['$L0H'] = !![], window['$LDHT0']();
}, window[W[704]] = function (n4_, o9v17, ab2$, x0_ny3, of791v, rc3iw, tfq5lz, _$4ds, n03_) {
  of791v = String(of791v);var o917 = tfq5lz,
      e61gv = _$4ds;$LHD[W[570]][of791v] = { 'productid': of791v, 'productname': o917, 'productdesc': e61gv, 'roleid': n4_, 'rolename': o9v17, 'rolelevel': ab2$, 'price': rc3iw, 'callback': n03_ }, sendApi($LHD[W[578]], W[705], { 'game_pkg': $LHD[W[262]], 'server_id': $LHD[W[149]][W[150]], 'server_name': $LHD[W[149]][W[290]], 'level': ab2$, 'uid': $LHD[W[452]], 'role_id': n4_, 'role_name': o9v17, 'product_id': of791v, 'product_name': o917, 'product_desc': e61gv, 'money': rc3iw, 'partner_id': $LHD[W[582]] }, toPayCallBack, $L0DH, $LDT);
}, window[W[706]] = function (jqlkzh) {
  if (jqlkzh) {
    if (jqlkzh[W[707]] === 0xc8 || jqlkzh[W[313]] == W[312]) {
      var a$bd2 = $LHD[W[570]][String(jqlkzh[W[708]])];if (a$bd2[W[709]]) a$bd2[W[709]](jqlkzh[W[708]], jqlkzh[W[710]], -0x1);L9ue17v[W[711]]({ 'cpbill': jqlkzh[W[710]], 'productid': jqlkzh[W[708]], 'productname': a$bd2[W[712]], 'productdesc': a$bd2[W[713]], 'serverid': $LHD[W[149]][W[150]], 'servername': $LHD[W[149]][W[290]], 'roleid': a$bd2[W[714]], 'rolename': a$bd2[W[715]], 'rolelevel': a$bd2[W[716]], 'price': a$bd2[W[717]], 'extension': JSON[W[402]]({ 'cp_order_id': jqlkzh[W[710]] }) }, function (n8yx4_, ueg16p) {
        a$bd2[W[709]] && n8yx4_ == 0x0 && a$bd2[W[709]](jqlkzh[W[708]], jqlkzh[W[710]], n8yx4_);console[W[436]](JSON[W[402]]({ 'type': W[718], 'status': n8yx4_, 'data': jqlkzh, 'role_name': a$bd2[W[715]] }));if (n8yx4_ === 0x0) {} else {
          if (n8yx4_ === 0x1) {} else {
            if (n8yx4_ === 0x2) {}
          }
        }
      });
    } else alert(jqlkzh[W[436]]);
  }
}, window['$L0DHT'] = function () {}, window['$LT0D'] = function (n0x_y4, lfqt, lqz5tf, u1veg6, crym0) {
  L9ue17v[W[719]]($LHD[W[149]][W[150]], $LHD[W[149]][W[290]] || $LHD[W[149]][W[150]], n0x_y4, lfqt, lqz5tf), sendApi($LHD[W[574]], W[720], { 'game_pkg': $LHD[W[262]], 'server_id': $LHD[W[149]][W[150]], 'role_id': n0x_y4, 'uid': $LHD[W[452]], 'role_name': lfqt, 'role_type': u1veg6, 'level': lqz5tf });
}, window['$LTD0'] = function (m30c, ftl9q5, qzhtlj, jzhlqt, qakhzj, y0cx, f5qtl, ym30r, ztlqh, ep1u) {
  $LHD[W[449]] = m30c, $LHD[W[450]] = ftl9q5, $LHD[W[451]] = qzhtlj, L9ue17v[W[721]]($LHD[W[149]][W[150]], $LHD[W[149]][W[290]] || $LHD[W[149]][W[150]], m30c, ftl9q5, qzhtlj), sendApi($LHD[W[574]], W[722], { 'game_pkg': $LHD[W[262]], 'server_id': $LHD[W[149]][W[150]], 'role_id': m30c, 'uid': $LHD[W[452]], 'role_name': ftl9q5, 'role_type': jzhlqt, 'level': qzhtlj, 'evolution': qakhzj });
}, window['$L0TD'] = function (v9o17, f9olt5, qlhzjt, w3mi, b$d28, b2k$ad, nxs8, gp6eu, o5ft9l, ev1og) {
  $LHD[W[449]] = v9o17, $LHD[W[450]] = f9olt5, $LHD[W[451]] = qlhzjt, L9ue17v[W[723]]($LHD[W[149]][W[150]], $LHD[W[149]][W[290]] || $LHD[W[149]][W[150]], v9o17, f9olt5, qlhzjt), sendApi($LHD[W[574]], W[722], { 'game_pkg': $LHD[W[262]], 'server_id': $LHD[W[149]][W[150]], 'role_id': v9o17, 'uid': $LHD[W[452]], 'role_name': f9olt5, 'role_type': w3mi, 'level': qlhzjt, 'evolution': b$d28 });
}, window['$L0DT'] = function (vo17g) {}, window['$LT0'] = function (l9qtf5) {
  L9ue17v[W[724]](W[724], function (hjbzk) {
    l9qtf5 && l9qtf5(hjbzk);
  });
}, window[W[725]] = function () {
  L9ue17v[W[725]]();
}, window[W[726]] = function () {
  L9ue17v[W[727]]();
}, window[W[728]] = function (t59of7, d42$, ci3w, mcw, i3mr, v6eg1u, vug71e, ja2bkh) {
  ja2bkh = ja2bkh || $LHD[W[149]][W[150]], sendApi($LHD[W[574]], W[729], { 'phone': t59of7, 'role_id': d42$, 'uid': $LHD[W[452]], 'game_pkg': $LHD[W[262]], 'partner_id': $LHD[W[582]], 'server_id': ja2bkh }, vug71e);
}, window[W[554]] = function (iw3r) {
  window['$LDT0'] = iw3r, window['$LDT0'] && window['$L0T'] && (console[W[436]](W[555] + window['$L0T'][W[556]]), window['$LDT0'](window['$L0T']), window['$L0T'] = null);
}, window['$LD0T'] = function (qtjhzl, ahqj, epg1u6, e97o1v) {
  window[W[730]](W[731], { 'game_pkg': window['$LHD'][W[262]], 'role_id': ahqj, 'server_id': epg1u6 }, e97o1v);
}, window['$LHT0D'] = function (xs_4n, q5zlth) {
  function lq5tzf(hzbja) {
    var f7to = [],
        qjhlkz = [],
        f579ov = window[W[441]][W[732]];for (var _4y8 in f579ov) {
      var gu6ev = Number(_4y8);(!xs_4n || !xs_4n[W[178]] || xs_4n[W[424]](gu6ev) != -0x1) && (qjhlkz[W[318]](f579ov[_4y8]), f7to[W[318]]([gu6ev, 0x3]));
    }window['$LB0DTH'](window[W[463]], W[733]) >= 0x0 ? (console[W[310]](W[734]), L9ue17v[W[735]](qjhlkz, function (hbjak2) {
      console[W[310]](W[736]), console[W[310]](hbjak2);if (hbjak2 && hbjak2[W[481]] == W[737]) for (var mr30ci in f579ov) {
        if (hbjak2[f579ov[mr30ci]] == W[738]) {
          var yx8n4 = Number(mr30ci);for (var ltfqz5 = 0x0; ltfqz5 < f7to[W[178]]; ltfqz5++) {
            if (f7to[ltfqz5][0x0] == yx8n4) {
              f7to[ltfqz5][0x1] = 0x1;break;
            }
          }
        }
      }window['$LB0DTH'](window[W[463]], W[739]) >= 0x0 ? wx[W[740]]({ 'withSubscriptions': !![], 'success': function (kbadj2) {
          var htl5qz = kbadj2[W[741]][W[742]];if (htl5qz) {
            console[W[310]](W[743]), console[W[310]](htl5qz);for (var ahbzjk in f579ov) {
              if (htl5qz[f579ov[ahbzjk]] == W[738]) {
                var xs = Number(ahbzjk);for (var ynx4 = 0x0; ynx4 < f7to[W[178]]; ynx4++) {
                  if (f7to[ynx4][0x0] == xs) {
                    f7to[ynx4][0x1] = 0x2;break;
                  }
                }
              }
            }console[W[310]](f7to), q5zlth && q5zlth(f7to);
          } else console[W[310]](W[744]), console[W[310]](kbadj2), console[W[310]](f7to), q5zlth && q5zlth(f7to);
        }, 'fail': function () {
          console[W[310]](W[745]), console[W[310]](f7to), q5zlth && q5zlth(f7to);
        } }) : (console[W[310]](W[746] + window[W[463]]), console[W[310]](f7to), q5zlth && q5zlth(f7to));
    })) : (console[W[310]](W[747] + window[W[463]]), console[W[310]](f7to), q5zlth && q5zlth(f7to)), wx[W[748]](lq5tzf);
  }wx[W[749]](lq5tzf);
}, window['$LHTD0'] = { 'isSuccess': ![], 'level': W[750], 'isCharging': ![] }, window['$LH0TD'] = function (jza) {
  wx[W[542]]({ 'success': function (jqlzhk) {
      var iwcm = window['$LHTD0'];iwcm[W[751]] = !![], iwcm[W[544]] = Number(jqlzhk[W[544]])[W[752]](0x0), iwcm[W[546]] = jqlzhk[W[546]], jza && jza(iwcm[W[751]], iwcm[W[544]], iwcm[W[546]]);
    }, 'fail': function (eu1gv6) {
      console[W[310]](W[753], eu1gv6[W[481]]);var as2$b = window['$LHTD0'];jza && jza(as2$b[W[751]], as2$b[W[544]], as2$b[W[546]]);
    } });
}, window[W[730]] = function (s$d_, n3x0_y, ajh2k, _nsx8, _n8$s4, jzkhb, fl5o9, t5fl9q) {
  if (_nsx8 == undefined) _nsx8 = 0x1;wx[W[625]]({ 'url': s$d_, 'method': fl5o9 || W[754], 'responseType': W[202], 'data': n3x0_y, 'header': { 'content-type': t5fl9q || W[627] }, 'success': function (qahjkz) {
      DEBUG && console[W[310]](W[755], s$d_, info, qahjkz);if (qahjkz && qahjkz[W[756]] == 0xc8) {
        var d_4s8$ = qahjkz[W[314]];!jzkhb || jzkhb(d_4s8$) ? ajh2k && ajh2k(d_4s8$) : window[W[757]](s$d_, n3x0_y, ajh2k, _nsx8, _n8$s4, jzkhb, qahjkz);
      } else window[W[757]](s$d_, n3x0_y, ajh2k, _nsx8, _n8$s4, jzkhb, qahjkz);
    }, 'fail': function (x48n) {
      DEBUG && console[W[310]](W[758], s$d_, info, x48n), window[W[757]](s$d_, n3x0_y, ajh2k, _nsx8, _n8$s4, jzkhb, x48n);
    }, 'complete': function () {} });
}, window[W[757]] = function (x_n48, $d2ba, abkd$, d_48$, _xn04y, qlzkj, t9lf5) {
  d_48$ - 0x1 > 0x0 ? setTimeout(function () {
    window[W[730]](x_n48, $d2ba, abkd$, d_48$ - 0x1, _xn04y, qlzkj);
  }, 0x3e8) : _xn04y && _xn04y(JSON[W[402]]({ 'url': x_n48, 'response': t9lf5 }));
}, window[W[759]] = function (ry03mc, n_8x4, to95l, eu1gv7, bhzjk, x0_n3y, hlzq5t) {
  !to95l && (to95l = {});var abd2jk = Math[W[405]](Date[W[144]]() / 0x3e8);to95l[W[680]] = abd2jk, to95l[W[760]] = n_8x4;var x30yrc = Object[W[761]](to95l)[W[319]](),
      l9ft = '',
      v1g6eu = '';for (var g1e6up = 0x0; g1e6up < x30yrc[W[178]]; g1e6up++) {
    l9ft = l9ft + (g1e6up == 0x0 ? '' : '&') + x30yrc[g1e6up] + to95l[x30yrc[g1e6up]], v1g6eu = v1g6eu + (g1e6up == 0x0 ? '' : '&') + x30yrc[g1e6up] + '=' + encodeURIComponent(to95l[x30yrc[g1e6up]]);
  }l9ft = l9ft + $LHD[W[580]];var x_y84 = W[762] + md5(l9ft);send(ry03mc + '?' + v1g6eu + (v1g6eu == '' ? '' : '&') + x_y84, null, eu1gv7, bhzjk, x0_n3y, hlzq5t || function (tzqhjl) {
    return tzqhjl[W[313]] == W[312];
  }, null, W[763]);
}, window['$LH0DT'] = function (klqhz, f1vo97) {
  var d$s2b8 = 0x0;$LHD[W[149]] && (d$s2b8 = $LHD[W[149]][W[150]]), sendApi($LHD[W[576]], W[764], { 'partnerId': $LHD[W[582]], 'gamePkg': $LHD[W[262]], 'logTime': Math[W[405]](Date[W[144]]() / 0x3e8), 'platformUid': $LHD[W[676]], 'type': klqhz, 'serverId': d$s2b8 }, null, 0x2, null, function () {
    return !![];
  });
}, window['$LHDT0'] = function (tlf59q) {
  sendApi($LHD[W[574]], W[765], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, $LHD0T, $L0DH, $LDT);
}, window['$LHD0T'] = function (ad$bk2) {
  if (ad$bk2[W[313]] === W[312] && ad$bk2[W[314]]) {
    ad$bk2[W[314]][W[766]]({ 'id': -0x2, 'name': W[767] }), ad$bk2[W[314]][W[766]]({ 'id': -0x1, 'name': W[768] }), $LHD[W[261]] = ad$bk2[W[314]];if (window[W[253]]) window[W[253]][W[297]]();
  } else $LHD[W[272]] = ![], window['$LT0HD'](W[769] + ad$bk2[W[313]]);
}, window['$LT0H'] = function (wrc3m) {
  sendApi($LHD[W[574]], W[770], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, $LTH0, $L0DH, $LDT);
}, window['$LTH0'] = function (r0cm) {
  $LHD[W[305]] = ![];if (r0cm[W[313]] === W[312] && r0cm[W[314]]) {
    for (var t9fql5 = 0x0; t9fql5 < r0cm[W[314]][W[178]]; t9fql5++) {
      r0cm[W[314]][t9fql5][W[289]] = $LH0T(r0cm[W[314]][t9fql5]);
    }$LHD[W[303]][-0x1] = window[W[771]](r0cm[W[314]]), window[W[253]][W[304]](-0x1);
  } else window['$LT0HD'](W[772] + r0cm[W[313]]);
}, window[W[773]] = function (s42$d) {
  sendApi($LHD[W[574]], W[770], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, s42$d, $L0DH, $LDT);
}, window['$L0TH'] = function (_s84$d, f9o7v) {
  sendApi($LHD[W[574]], W[774], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]], 'server_group_id': f9o7v }, $L0HT, $L0DH, $LDT);
}, window['$L0HT'] = function (xy0n) {
  $LHD[W[305]] = ![];if (xy0n[W[313]] === W[312] && xy0n[W[314]] && xy0n[W[314]][W[314]]) {
    var x48y = xy0n[W[314]][W[775]],
        cm30yr = [];for (var $bsad = 0x0; $bsad < xy0n[W[314]][W[314]][W[178]]; $bsad++) {
      xy0n[W[314]][W[314]][$bsad][W[289]] = $LH0T(xy0n[W[314]][W[314]][$bsad]), (cm30yr[W[178]] == 0x0 || xy0n[W[314]][W[314]][$bsad][W[289]] != 0x0) && (cm30yr[cm30yr[W[178]]] = xy0n[W[314]][W[314]][$bsad]);
    }$LHD[W[303]][x48y] = window[W[771]](cm30yr), window[W[253]][W[304]](x48y);
  } else window['$LT0HD'](W[776] + xy0n[W[313]]);
}, window['$LB0DH'] = function (s8_$4n) {
  sendApi($LHD[W[574]], W[777], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'version': $LHD[W[502]], 'game_pkg': $LHD[W[262]], 'device': $LHD[W[583]] }, reqServerRecommendCallBack, $L0DH, $LDT);
}, window[W[778]] = function (lhjqzt) {
  $LHD[W[305]] = ![];if (lhjqzt[W[313]] === W[312] && lhjqzt[W[314]]) {
    for (var eov719 = 0x0; eov719 < lhjqzt[W[314]][W[178]]; eov719++) {
      lhjqzt[W[314]][eov719][W[289]] = $LH0T(lhjqzt[W[314]][eov719]);
    }$LHD[W[303]][-0x2] = window[W[771]](lhjqzt[W[314]]), window[W[253]][W[304]](-0x2);
  } else alert(W[779] + lhjqzt[W[313]]);
}, window[W[771]] = function (bd2kja) {
  if (!bd2kja && bd2kja[W[178]] <= 0x0) return bd2kja;for (let tqhj = 0x0; tqhj < bd2kja[W[178]]; tqhj++) {
    bd2kja[tqhj][W[780]] && bd2kja[tqhj][W[780]] == 0x1 && (bd2kja[tqhj][W[290]] += W[781]);
  }return bd2kja;
}, window['$LHT0'] = function (qzjkh, kabhz) {
  qzjkh = qzjkh || $LHD[W[149]][W[150]], sendApi($LHD[W[574]], W[782], { 'type': '4', 'game_pkg': $LHD[W[262]], 'server_id': qzjkh }, kabhz);
}, window[W[783]] = function (sdb2a$, $_8ns, akd2jb, bkad2) {
  akd2jb = akd2jb || $LHD[W[149]][W[150]], sendApi($LHD[W[574]], W[784], { 'type': sdb2a$, 'game_pkg': $_8ns, 'server_id': akd2jb }, bkad2);
}, window['$LH0T'] = function (_n4sx) {
  if (_n4sx) {
    if (_n4sx[W[289]] == 0x1) {
      if (_n4sx[W[785]] == 0x1) return 0x2;else return 0x1;
    } else return _n4sx[W[289]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['$LDT0H'] = function (qlt9f5, $4d2s) {
  $LHD[W[786]] = { 'step': qlt9f5, 'server_id': $4d2s };var vf917 = this;$LTH0D({ 'title': W[787] }), sendApi($LHD[W[574]], W[788], { 'partner_id': $LHD[W[582]], 'uid': $LHD[W[452]], 'game_pkg': $LHD[W[262]], 'server_id': $4d2s, 'platform': $LHD[W[506]], 'platform_uid': $LHD[W[676]], 'check_login_time': $LHD[W[679]], 'check_login_sign': $LHD[W[677]], 'version_name': $LHD[W[650]] }, $LDTH0, $L0DH, $LDT, function (y0x3cr) {
    return y0x3cr[W[313]] == W[312] || y0x3cr[W[436]] == W[789] || y0x3cr[W[436]] == W[790];
  });
}, window['$LDTH0'] = function (ny8x4) {
  var o7ge = this;if (ny8x4[W[313]] === W[312] && ny8x4[W[314]]) {
    var kbd2$ = $LHD[W[149]];kbd2$[W[791]] = $LHD[W[585]], kbd2$[W[678]] = String(ny8x4[W[314]][W[792]]), kbd2$[W[591]] = parseInt(ny8x4[W[314]][W[680]]);if (ny8x4[W[314]][W[793]]) kbd2$[W[793]] = parseInt(ny8x4[W[314]][W[793]]);else kbd2$[W[793]] = parseInt(ny8x4[W[314]][W[150]]);kbd2$[W[794]] = 0x0, kbd2$[W[296]] = $LHD[W[698]], kbd2$[W[795]] = ny8x4[W[314]][W[796]], kbd2$[W[797]] = ny8x4[W[314]][W[797]], console[W[310]](W[798] + JSON[W[402]](kbd2$[W[797]])), $LHD[W[391]] == 0x1 && kbd2$[W[797]] && kbd2$[W[797]][W[799]] == 0x1 && ($LHD[W[209]] = 0x1, window[W[435]][W[145]]['$LBDH']()), $LD0TH();
  } else $LHD[W[786]][W[800]] >= 0x3 ? ($LDT(JSON[W[402]](ny8x4)), window['$LT0HD'](W[801] + ny8x4[W[313]])) : sendApi($LHD[W[574]], W[661], { 'platform': $LHD[W[572]], 'partner_id': $LHD[W[582]], 'token': $LHD[W[659]], 'game_pkg': $LHD[W[262]], 'deviceId': $LHD[W[583]], 'scene': W[662] + $LHD[W[584]] }, function (jhzakq) {
    if (!jhzakq || jhzakq[W[313]] != W[312]) {
      window['$LT0HD'](W[674] + jhzakq && jhzakq[W[313]]);return;
    }$LHD[W[677]] = String(jhzakq[W[678]]), $LHD[W[679]] = String(jhzakq[W[680]]), setTimeout(function () {
      $LDT0H($LHD[W[786]][W[800]] + 0x1, $LHD[W[786]][W[150]]);
    }, 0x5dc);
  }, $L0DH, $LDT, function (n8x_4y) {
    return n8x_4y[W[313]] == W[312] || n8x_4y[W[313]] == W[802];
  });
}, window['$LD0TH'] = function () {
  ServerLoading[W[145]][W[386]]($LHD[W[391]]), window['$L0D'] = !![], window['$LDHT0']();
}, window['$LD0HT'] = function () {
  if (window['$LD0'] && window['$LH0D'] && window[W[382]] && window[W[385]] && window['$LHD0'] && window['$LH0']) {
    if (!window[W[803]][W[145]]) {
      console[W[310]](W[804] + window[W[803]][W[145]]);var nxs = wx[W[805]](),
          cw3rmi = nxs[W[556]] ? nxs[W[556]] : 0x0,
          f7vo91 = { 'cdn': window['$LHD'][W[296]], 'spareCdn': window['$LHD'][W[648]], 'newRegister': window['$LHD'][W[391]], 'wxPC': window['$LHD'][W[531]], 'wxIOS': window['$LHD'][W[526]], 'wxAndroid': window['$LHD'][W[528]], 'wxParam': { 'limitLoad': window['$LHD']['$LBT0DH'], 'benchmarkLevel': window['$LHD']['$LBTH0D'], 'wxFrom': window[W[441]][W[654]] == W[806] ? 0x1 : 0x0, 'wxSDKVersion': window[W[463]] }, 'configType': window['$LHD'][W[592]], 'exposeType': window['$LHD'][W[594]], 'scene': cw3rmi };new window[W[803]](f7vo91, window['$LHD'][W[206]], window['$LBT0HD']);
    }
  }
}, window['$LDHT0'] = function () {
  if (window['$LD0'] && window['$LH0D'] && window[W[382]] && window[W[385]] && window['$LHD0'] && window['$LH0'] && window['$L0D'] && window['$L0H']) {
    $LTHD0();if (!$LD0H) {
      $LD0H = !![];if (!window[W[803]][W[145]]) window['$LD0HT']();var qjhzak = 0x0,
          c0i3r = wx[W[807]]();c0i3r && (window['$LHD'][W[530]] && (qjhzak = c0i3r[W[108]]), console[W[436]](W[808] + c0i3r[W[108]] + W[809] + c0i3r[W[220]] + W[810] + c0i3r[W[524]] + W[811] + c0i3r[W[69]] + W[812] + c0i3r[W[170]] + W[813] + c0i3r[W[172]]));var s84x = {};for (const qjhlk in $LHD[W[149]]) {
        s84x[qjhlk] = $LHD[W[149]][qjhlk];
      }var zbkhaj = { 'channel': window['$LHD'][W[586]], 'account': window['$LHD'][W[452]], 'userId': window['$LHD'][W[675]], 'cdn': window['$LHD'][W[296]], 'data': window['$LHD'][W[314]], 'package': window['$LHD'][W[571]], 'newRegister': window['$LHD'][W[391]], 'pkgName': window['$LHD'][W[262]], 'partnerId': window['$LHD'][W[582]], 'platform_uid': window['$LHD'][W[676]], 'deviceId': window['$LHD'][W[583]], 'selectedServer': s84x, 'configType': window['$LHD'][W[592]], 'exposeType': window['$LHD'][W[594]], 'debugUsers': window['$LHD'][W[589]], 'wxMenuTop': qjhzak, 'wxShield': window['$LHD'][W[595]] };if (window[W[701]]) for (var e197v in window[W[701]]) {
        zbkhaj[e197v] = window[W[701]][e197v];
      }window[W[803]][W[145]]['$LDHB'](zbkhaj);
    }
  } else console[W[436]](W[814] + window['$LD0'] + W[815] + window['$LH0D'] + W[816] + window[W[382]] + W[817] + window[W[385]] + W[818] + window['$LHD0'] + W[819] + window['$LH0'] + W[820] + window['$L0D'] + W[821] + window['$L0H']);
};