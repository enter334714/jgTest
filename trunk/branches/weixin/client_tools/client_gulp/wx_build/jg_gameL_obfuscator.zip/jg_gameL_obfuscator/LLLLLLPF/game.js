var W = wx.$l;
require('llllllBF.js'), window[W[822]][W[823]][W[824]] = null, window['client_pb'] = require('LLLCLIENTPB.js'), window[W[825]] = window[W[822]][W[826]][W[827]](client_pb);