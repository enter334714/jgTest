var H = wx.$F;
require("./default.thm.min.js");