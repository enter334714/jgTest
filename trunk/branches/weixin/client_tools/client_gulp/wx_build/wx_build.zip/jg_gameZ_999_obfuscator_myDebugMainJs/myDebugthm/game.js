var H = wx.$F;
require("./default.thm.js");