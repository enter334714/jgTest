var B = wx.$z;
require(B[440915]);