var B = wx.$z;
import zh14gp6 from '../zzabzzsdk/z7sdkz.js';window[B[440916]] = { 'wxVersion': window[B[440917]][B[440918]] }, window[B[440919]] = ![], window['z0DJ'] = 0x1, window[B[440920]] = 0x1, window['z0YJD'] = !![], window[B[440921]] = !![], window['z0R0YJD'] = '', window['z0JD'] = { 'base_cdn': B[440922], 'cdn': B[440922] }, z0JD[B[440923]] = {}, z0JD[B[440304]] = '0', z0JD[B[440924]] = window[B[440916]][B[440925]], z0JD[B[440926]] = '', z0JD['os'] = '1', z0JD[B[440927]] = B[440928], z0JD[B[440929]] = B[440930], z0JD[B[440931]] = B[440932], z0JD[B[440933]] = B[440934], z0JD[B[440935]] = B[440936], z0JD[B[440937]] = '1', z0JD[B[440938]] = '', z0JD[B[440939]] = '', z0JD[B[440940]] = 0x0, z0JD[B[440941]] = {}, z0JD[B[440942]] = parseInt(z0JD[B[440937]]), z0JD[B[440943]] = z0JD[B[440937]], z0JD[B[440944]] = {}, z0JD['z00J'] = B[440945], z0JD[B[440946]] = ![], z0JD[B[440947]] = B[440948], z0JD[B[440949]] = Date[B[440950]](), z0JD[B[440951]] = B[440952], z0JD[B[440953]] = '_a', z0JD[B[440954]] = 0x2, z0JD[B[440955]] = 0x7c1, z0JD[B[440925]] = window[B[440916]][B[440925]], z0JD[B[440956]] = ![], z0JD[B[440957]] = ![], z0JD[B[440958]] = ![], z0JD[B[440959]] = ![], window['z0YDJ'] = 0x5, window['z0YD'] = ![], window['z0DY'] = ![], window['z0JYD'] = ![], window[B[440960]] = ![], window[B[440961]] = ![], window['z0JDY'] = ![], window['z0YJ'] = ![], window['z0JY'] = ![], window['z0DYJ'] = ![], window[B[440962]] = function (bk8ryd) {
  console[B[440225]](B[440962], bk8ryd), wx[B[440963]]({}), wx[B[440964]]({ 'title': B[440965], 'content': bk8ryd, 'success'(fp64gv) {
      if (fp64gv[B[440966]]) console[B[440225]](B[440967]);else fp64gv[B[440968]] && console[B[440225]](B[440969]);
    } });
}, window['z00YJD'] = function (ykotb) {
  console[B[440225]](B[440970], ykotb), z00JDY(), wx[B[440964]]({ 'title': B[440965], 'content': ykotb, 'confirmText': B[440971], 'cancelText': B[440972], 'success'(fgp6v4) {
      if (fgp6v4[B[440966]]) window['z0J0']();else fgp6v4[B[440968]] && (console[B[440225]](B[440973]), wx[B[440974]]({}));
    } });
}, window[B[440975]] = function (p419hg) {
  console[B[440225]](B[440975], p419hg), wx[B[440964]]({ 'title': B[440965], 'content': p419hg, 'confirmText': B[440976], 'showCancel': ![], 'complete'(nvfl67) {
      console[B[440225]](B[440973]), wx[B[440974]]({});
    } });
}, window['z00YDJ'] = ![], window['z00JYD'] = function (mj$qi3) {
  window['z00YDJ'] = !![], wx[B[440977]](mj$qi3);
}, window['z00JDY'] = function () {
  window['z00YDJ'] && (window['z00YDJ'] = ![], wx[B[440963]]({}));
}, window['z00DYJ'] = function (f7livn) {
  window[B[440978]][B[440979]]['z00DYJ'](f7livn);
}, window[B[440980]] = function (asztex, m$qij3) {
  zh14gp6[B[440980]](asztex, function (xate) {
    xate && xate[B[440335]] ? xate[B[440335]][B[440981]] == 0x1 ? m$qij3(!![]) : (m$qij3(![]), console[B[440982]](B[440983] + xate[B[440335]][B[440984]])) : console[B[440225]](B[440980], xate);
  });
}, window['z00DJY'] = function (seatz) {
  console[B[440225]](B[440985], seatz);
}, window['z00JD'] = function (nlm73i) {}, window['z00DJ'] = function (gpxh91, _52b8r, taexzs) {}, window['z00D'] = function (dbko8y) {
  console[B[440225]](B[440986], dbko8y), window[B[440978]][B[440979]][B[440987]](), window[B[440978]][B[440979]][B[440988]](), window[B[440978]][B[440979]][B[440989]]();
}, window['z0D0'] = function (_28ur) {
  window['z00YJD'](B[440990]);var eatso = { 'id': window['z0JD'][B[440991]], 'role': window['z0JD'][B[440992]], 'level': window['z0JD'][B[440993]], 'account': window['z0JD'][B[440994]], 'version': window['z0JD'][B[440955]], 'cdn': window['z0JD'][B[440995]], 'pkgName': window['z0JD'][B[440938]], 'gamever': window[B[440917]][B[440918]], 'serverid': window['z0JD'][B[440944]] ? window['z0JD'][B[440944]][B[440996]] : 0x0, 'systemInfo': window[B[440997]], 'error': B[440998], 'stack': _28ur ? _28ur : B[440990] },
      x1ph9g = JSON[B[440999]](eatso);console[B[440333]](B[441000] + x1ph9g), window['z00J'](x1ph9g);
}, window['z0J0D'] = function (gf6p4h) {
  var ydtzoe = JSON[B[440223]](gf6p4h);ydtzoe[B[441001]] = window[B[440917]][B[440918]], ydtzoe[B[441002]] = window['z0JD'][B[440944]] ? window['z0JD'][B[440944]][B[440996]] : 0x0, ydtzoe[B[440997]] = window[B[440997]];var eaztdo = JSON[B[440999]](ydtzoe);console[B[440333]](B[441003] + eaztdo), window['z00J'](eaztdo);
}, window['z0JD0'] = function (aszteo, s1axh9) {
  var w50_u2 = { 'id': window['z0JD'][B[440991]], 'role': window['z0JD'][B[440992]], 'level': window['z0JD'][B[440993]], 'account': window['z0JD'][B[440994]], 'version': window['z0JD'][B[440955]], 'cdn': window['z0JD'][B[440995]], 'pkgName': window['z0JD'][B[440938]], 'gamever': window[B[440917]][B[440918]], 'serverid': window['z0JD'][B[440944]] ? window['z0JD'][B[440944]][B[440996]] : 0x0, 'systemInfo': window[B[440997]], 'error': aszteo, 'stack': s1axh9 },
      b_58r = JSON[B[440999]](w50_u2);console[B[440383]](B[441004] + b_58r), window['z00J'](b_58r);
}, window['z00J'] = function (d8kbry) {
  if (window['z0JD'][B[441005]] == B[441006]) return;var txz = z0JD['z00J'] + B[441007] + z0JD[B[440994]];wx[B[441008]]({ 'url': txz, 'method': B[441009], 'data': d8kbry, 'header': { 'content-type': B[441010], 'cache-control': B[441011] }, 'success': function (in73q) {
      DEBUG && console[B[440225]](B[441012], txz, d8kbry, in73q);
    }, 'fail': function (l76fvn) {
      DEBUG && console[B[440225]](B[441012], txz, d8kbry, l76fvn);
    }, 'complete': function () {} });
}, window[B[441013]] = function () {
  function dyzoet() {
    return ((0x1 + Math[B[441014]]()) * 0x10000 | 0x0)[B[440060]](0x10)[B[440234]](0x1);
  }return dyzoet() + dyzoet() + '-' + dyzoet() + '-' + dyzoet() + '-' + dyzoet() + '+' + dyzoet() + dyzoet() + dyzoet();
}, window['z0J0'] = function () {
  console[B[440225]](B[441015]);var ghp64 = zh14gp6[B[441016]]();z0JD[B[440943]] = ghp64[B[441017]], z0JD[B[440942]] = ghp64[B[441017]], z0JD[B[440937]] = ghp64[B[441017]], z0JD[B[440938]] = ghp64[B[441018]];var g4fp = { 'game_ver': z0JD[B[440924]] };z0JD[B[440939]] = this[B[441013]](), z00JYD({ 'title': B[441019] }), zh14gp6[B[441020]](g4fp, this['z0D0J'][B[440017]](this));
}, window['z0D0J'] = function (_8rb5) {
  var gv64f = _8rb5[B[441021]];console[B[440225]](B[441022] + gv64f + B[441023] + (gv64f == 0x1) + B[441024] + _8rb5[B[440918]] + B[441025] + window[B[440916]][B[440925]]);if (!_8rb5[B[440918]] || window['z0RYD0J'](window[B[440916]][B[440925]], _8rb5[B[440918]]) < 0x0) console[B[440225]](B[441026]), z0JD[B[440929]] = B[441027], z0JD[B[440931]] = B[441028], z0JD[B[440933]] = B[441029], z0JD[B[440995]] = B[441030], z0JD[B[441031]] = B[441032], z0JD[B[441033]] = 'fj', z0JD[B[440956]] = ![];else window['z0RYD0J'](window[B[440916]][B[440925]], _8rb5[B[440918]]) == 0x0 ? (console[B[440225]](B[441034]), z0JD[B[440929]] = B[440930], z0JD[B[440931]] = B[440932], z0JD[B[440933]] = B[440934], z0JD[B[440995]] = B[441035], z0JD[B[441031]] = B[441032], z0JD[B[441033]] = B[441036], z0JD[B[440956]] = !![]) : (console[B[440225]](B[441037]), z0JD[B[440929]] = B[440930], z0JD[B[440931]] = B[440932], z0JD[B[440933]] = B[440934], z0JD[B[440995]] = B[441035], z0JD[B[441031]] = B[441032], z0JD[B[441033]] = B[441036], z0JD[B[440956]] = ![]);z0JD[B[440940]] = config[B[440051]] ? config[B[440051]] : 0x0, this['z0YJ0D'](), this['z0YJD0'](), window[B[441038]] = 0x5, z00JYD({ 'title': B[441039] }), zh14gp6[B[441040]](this['z0DJ0'][B[440017]](this));
}, window[B[441038]] = 0x5, window['z0DJ0'] = function (sah1, f7nl6v) {
  if (sah1 == 0x0 && f7nl6v && f7nl6v[B[440285]]) {
    z0JD[B[441041]] = f7nl6v[B[440285]];var nf6l7 = this;z00JYD({ 'title': B[441042] }), sendApi(z0JD[B[440929]], B[441043], { 'platform': z0JD[B[440927]], 'partner_id': z0JD[B[440937]], 'token': f7nl6v[B[440285]], 'game_pkg': z0JD[B[440938]], 'deviceId': z0JD[B[440939]], 'scene': B[441044] + z0JD[B[440940]] }, this['z0Y0JD'][B[440017]](this), z0YDJ, z0D0);
  } else f7nl6v && f7nl6v[B[441045]] && window[B[441038]] > 0x0 && (f7nl6v[B[441045]][B[440146]](B[441046]) != -0x1 || f7nl6v[B[441045]][B[440146]](B[441047]) != -0x1 || f7nl6v[B[441045]][B[440146]](B[441048]) != -0x1 || f7nl6v[B[441045]][B[440146]](B[441049]) != -0x1 || f7nl6v[B[441045]][B[440146]](B[441050]) != -0x1 || f7nl6v[B[441045]][B[440146]](B[441051]) != -0x1) ? (window[B[441038]]--, zh14gp6[B[441040]](this['z0DJ0'][B[440017]](this))) : (window['z0JD0'](B[441052], JSON[B[440999]]({ 'status': sah1, 'data': f7nl6v })), window['z00YJD'](B[441053] + (f7nl6v && f7nl6v[B[441045]] ? '，' + f7nl6v[B[441045]] : '')));
}, window['z0Y0JD'] = function (p6g41h) {
  if (!p6g41h) {
    window['z0JD0'](B[441054], B[441055]), window['z00YJD'](B[441056]);return;
  }if (p6g41h[B[440981]] != B[441057]) {
    window['z0JD0'](B[441054], JSON[B[440999]](p6g41h)), window['z00YJD'](B[441058] + p6g41h[B[440981]]);return;
  }z0JD[B[441059]] = String(p6g41h[B[440994]]), z0JD[B[440994]] = String(p6g41h[B[440994]]), z0JD[B[441060]] = String(p6g41h[B[441060]]), z0JD[B[440943]] = String(p6g41h[B[441060]]), z0JD[B[441061]] = String(p6g41h[B[441061]]), z0JD[B[441062]] = String(p6g41h[B[441063]]), z0JD[B[441064]] = String(p6g41h[B[441065]]), z0JD[B[441063]] = '';var q$i3m = this;z00JYD({ 'title': B[441066] }), sendApi(z0JD[B[440929]], B[441067], { 'partner_id': z0JD[B[440937]], 'uid': z0JD[B[440994]], 'version': z0JD[B[440924]], 'game_pkg': z0JD[B[440938]], 'device': z0JD[B[440939]] }, q$i3m['z0Y0DJ'][B[440017]](q$i3m), z0YDJ, z0D0);
}, window['z0Y0DJ'] = function (esx91a) {
  if (!esx91a) {
    window['z00YJD'](B[441068]);return;
  }if (esx91a[B[440981]] != B[441057]) {
    window['z00YJD'](B[441069] + esx91a[B[440981]]);return;
  }if (!esx91a[B[440335]] || esx91a[B[440335]][B[440031]] == 0x0) {
    window['z00YJD'](B[441070]);return;
  }z0JD[B[441071]] = esx91a[B[441072]], z0JD[B[440944]] = { 'server_id': String(esx91a[B[440335]][0x0][B[440996]]), 'server_name': String(esx91a[B[440335]][0x0][B[441073]]), 'entry_ip': esx91a[B[440335]][0x0][B[441074]], 'entry_port': parseInt(esx91a[B[440335]][0x0][B[441075]]), 'status': z0JY0(esx91a[B[440335]][0x0]), 'start_time': esx91a[B[440335]][0x0][B[441076]], 'cdn': z0JD[B[440995]] }, this['z0DJY0']();
}, window['z0DJY0'] = function () {
  if (z0JD[B[441071]] == 0x1) {
    var oated = z0JD[B[440944]][B[441077]];if (oated === -0x1 || oated === 0x0) {
      window['z00YJD'](oated === -0x1 ? B[441078] : B[441079]);return;
    }z0D0YJ(0x0, z0JD[B[440944]][B[440996]]), window[B[440978]][B[440979]][B[441080]](z0JD[B[441071]]);
  } else window[B[440978]][B[440979]][B[441081]](), z00JDY();window['z0JY'] = !![], window['z0DYJ0'](), window['z0DJ0Y']();
}, window['z0YJ0D'] = function () {
  sendApi(z0JD[B[440929]], B[441082], { 'game_pkg': z0JD[B[440938]], 'version_name': z0JD[B[441033]] }, this[B[441083]][B[440017]](this), z0YDJ, z0D0);
}, window[B[441083]] = function (x91sph) {
  if (!x91sph) {
    window['z00YJD'](B[441084]);return;
  }if (x91sph[B[440981]] != B[441057]) {
    window['z00YJD'](B[441085] + x91sph[B[440981]]);return;
  }if (!x91sph[B[440335]] || !x91sph[B[440335]][B[440924]]) {
    window['z00YJD'](B[441086] + (x91sph[B[440335]] && x91sph[B[440335]][B[440924]]));return;
  }x91sph[B[440335]][B[441087]] && x91sph[B[440335]][B[441087]][B[440031]] > 0xa && (z0JD[B[441088]] = x91sph[B[440335]][B[441087]], z0JD[B[440995]] = x91sph[B[440335]][B[441087]]), x91sph[B[440335]][B[440924]] && (z0JD[B[440955]] = x91sph[B[440335]][B[440924]]), console[B[440982]](B[441089] + z0JD[B[440955]] + B[441090] + z0JD[B[441033]]), window['z0JDY'] = !![], window['z0DYJ0'](), window['z0DJ0Y']();
}, window[B[441091]], window['z0YJD0'] = function () {
  sendApi(z0JD[B[440929]], B[441092], { 'game_pkg': z0JD[B[440938]] }, this['z0YD0J'][B[440017]](this), z0YDJ, z0D0);
}, window['z0YD0J'] = function (r2b_5) {
  if (r2b_5[B[440981]] === B[441057] && r2b_5[B[440335]]) {
    window[B[441091]] = r2b_5[B[440335]];for (var ghpf in r2b_5[B[440335]]) {
      z0JD[ghpf] = r2b_5[B[440335]][ghpf];
    }
  } else console[B[440982]](B[441093] + r2b_5[B[440981]]);window['z0YJ'] = !![], window['z0DJ0Y']();
}, window[B[441094]] = function (h9xas1, _by8rk, gvp6f, r8u_2, sxp1, zaeo, u_w502, tdzea, rydb) {
  sxp1 = String(sxp1);var dkzyot = u_w502,
      pf6hg4 = tdzea;z0JD[B[440923]][sxp1] = { 'productid': sxp1, 'productname': dkzyot, 'productdesc': pf6hg4, 'roleid': h9xas1, 'rolename': _by8rk, 'rolelevel': gvp6f, 'price': zaeo, 'callback': rydb }, sendApi(z0JD[B[440933]], B[441095], { 'game_pkg': z0JD[B[440938]], 'server_id': z0JD[B[440944]][B[440996]], 'server_name': z0JD[B[440944]][B[441073]], 'level': gvp6f, 'uid': z0JD[B[440994]], 'role_id': h9xas1, 'role_name': _by8rk, 'product_id': sxp1, 'product_name': dkzyot, 'product_desc': pf6hg4, 'money': zaeo, 'partner_id': z0JD[B[440937]] }, toPayCallBack, z0YDJ, z0D0);
}, window[B[441096]] = function (zeots) {
  if (zeots) {
    if (zeots[B[441097]] === 0xc8 || zeots[B[440981]] == B[441057]) {
      var r25u = z0JD[B[440923]][String(zeots[B[441098]])];if (r25u[B[441099]]) r25u[B[441099]](zeots[B[441098]], zeots[B[441100]], -0x1);zh14gp6[B[441101]]({ 'cpbill': zeots[B[441100]], 'productid': zeots[B[441098]], 'productname': r25u[B[441102]], 'productdesc': r25u[B[441103]], 'serverid': z0JD[B[440944]][B[440996]], 'servername': z0JD[B[440944]][B[441073]], 'roleid': r25u[B[441104]], 'rolename': r25u[B[441105]], 'rolelevel': r25u[B[441106]], 'price': r25u[B[441107]], 'extension': JSON[B[440999]]({ 'cp_order_id': zeots[B[441100]] }) }, function (wu052_, hgf46p) {
        r25u[B[441099]] && wu052_ == 0x0 && r25u[B[441099]](zeots[B[441098]], zeots[B[441100]], wu052_);console[B[440982]](JSON[B[440999]]({ 'type': B[441108], 'status': wu052_, 'data': zeots, 'role_name': r25u[B[441105]] }));if (wu052_ === 0x0) {} else {
          if (wu052_ === 0x1) {} else {
            if (wu052_ === 0x2) {}
          }
        }
      });
    } else alert(zeots[B[440982]]);
  }
}, window['z0YDJ0'] = function () {}, window['z00YD'] = function (m3iq, v7l6f, sa9xh, $ij3, kbyod) {
  zh14gp6[B[441109]](z0JD[B[440944]][B[440996]], z0JD[B[440944]][B[441073]] || z0JD[B[440944]][B[440996]], m3iq, v7l6f, sa9xh), sendApi(z0JD[B[440929]], B[441110], { 'game_pkg': z0JD[B[440938]], 'server_id': z0JD[B[440944]][B[440996]], 'role_id': m3iq, 'uid': z0JD[B[440994]], 'role_name': v7l6f, 'role_type': $ij3, 'level': sa9xh });
}, window['z00DY'] = function (x9ha, edazot, azde, zeotad, nf6l4v, ktzyod, l6n4f, in7flv, eoatzs, e9szx) {
  z0JD[B[440991]] = x9ha, z0JD[B[440992]] = edazot, z0JD[B[440993]] = azde, zh14gp6[B[441111]](z0JD[B[440944]][B[440996]], z0JD[B[440944]][B[441073]] || z0JD[B[440944]][B[440996]], x9ha, edazot, azde), sendApi(z0JD[B[440929]], B[441112], { 'game_pkg': z0JD[B[440938]], 'server_id': z0JD[B[440944]][B[440996]], 'role_id': x9ha, 'uid': z0JD[B[440994]], 'role_name': edazot, 'role_type': zeotad, 'level': azde, 'evolution': nf6l4v });
}, window['z0Y0D'] = function (rbdky8, p4gf6, _2, lf4gv6, gph9x, sxzae, x9ase1, phsx19, b_8yk, u2r_58) {
  z0JD[B[440991]] = rbdky8, z0JD[B[440992]] = p4gf6, z0JD[B[440993]] = _2, zh14gp6[B[441113]](z0JD[B[440944]][B[440996]], z0JD[B[440944]][B[441073]] || z0JD[B[440944]][B[440996]], rbdky8, p4gf6, _2), sendApi(z0JD[B[440929]], B[441112], { 'game_pkg': z0JD[B[440938]], 'server_id': z0JD[B[440944]][B[440996]], 'role_id': rbdky8, 'uid': z0JD[B[440994]], 'role_name': p4gf6, 'role_type': lf4gv6, 'level': _2, 'evolution': gph9x });
}, window['z0YD0'] = function (tybkd) {}, window['z00Y'] = function (ivn7fl) {
  zh14gp6[B[441114]](B[441114], function (x9ez) {
    ivn7fl && ivn7fl(x9ez);
  });
}, window[B[441115]] = function () {
  zh14gp6[B[441115]]();
}, window[B[441116]] = function () {
  zh14gp6[B[441117]]();
}, window[B[441118]] = function (yktdb) {
  window['z0D0Y'] = yktdb, window['z0D0Y'] && window['z0Y0'] && (console[B[440982]](B[441119] + window['z0Y0'][B[441120]]), window['z0D0Y'](window['z0Y0']), window['z0Y0'] = null);
}, window['z0DY0'] = function (dok8b, s9xh1, yodtz, tzose) {
  window[B[441121]](B[441122], { 'game_pkg': window['z0JD'][B[440938]], 'role_id': s9xh1, 'server_id': yodtz }, tzose);
}, window['z0J0YD'] = function (lvn7fi, zydoet) {
  function lmnv7i(mlvi7) {
    var u5_2w0 = [],
        kr8_5b = [],
        fv67nl = window[B[440917]][B[441123]];for (var teazx in fv67nl) {
      var zdeoyt = Number(teazx);(!lvn7fi || !lvn7fi[B[440031]] || lvn7fi[B[440146]](zdeoyt) != -0x1) && (kr8_5b[B[440066]](fv67nl[teazx]), u5_2w0[B[440066]]([zdeoyt, 0x3]));
    }window['z0RYD0J'](window[B[441124]], B[441125]) >= 0x0 ? (console[B[440225]](B[441126]), zh14gp6[B[441127]] && zh14gp6[B[441127]](kr8_5b, function (shax1) {
      console[B[440225]](B[441128]), console[B[440225]](shax1);if (shax1 && shax1[B[441045]] == B[441129]) for (var d8krb in fv67nl) {
        if (shax1[fv67nl[d8krb]] == B[441130]) {
          var okytz = Number(d8krb);for (var hgp = 0x0; hgp < u5_2w0[B[440031]]; hgp++) {
            if (u5_2w0[hgp][0x0] == okytz) {
              u5_2w0[hgp][0x1] = 0x1;break;
            }
          }
        }
      }window['z0RYD0J'](window[B[441124]], B[441131]) >= 0x0 ? wx[B[441132]]({ 'withSubscriptions': !![], 'success': function (b825) {
          var ji3 = b825[B[441133]][B[441134]];if (ji3) {
            console[B[440225]](B[441135]), console[B[440225]](ji3);for (var tkbo in fv67nl) {
              if (ji3[fv67nl[tkbo]] == B[441130]) {
                var kotbyd = Number(tkbo);for (var mni3l = 0x0; mni3l < u5_2w0[B[440031]]; mni3l++) {
                  if (u5_2w0[mni3l][0x0] == kotbyd) {
                    u5_2w0[mni3l][0x1] = 0x2;break;
                  }
                }
              }
            }console[B[440225]](u5_2w0), zydoet && zydoet(u5_2w0);
          } else console[B[440225]](B[441136]), console[B[440225]](b825), console[B[440225]](u5_2w0), zydoet && zydoet(u5_2w0);
        }, 'fail': function () {
          console[B[440225]](B[441137]), console[B[440225]](u5_2w0), zydoet && zydoet(u5_2w0);
        } }) : (console[B[440225]](B[441138] + window[B[441124]]), console[B[440225]](u5_2w0), zydoet && zydoet(u5_2w0));
    })) : (console[B[440225]](B[441139] + window[B[441124]]), console[B[440225]](u5_2w0), zydoet && zydoet(u5_2w0)), wx[B[441140]](lmnv7i);
  }wx[B[441141]](lmnv7i);
}, window['z0J0DY'] = { 'isSuccess': ![], 'level': B[441142], 'isCharging': ![] }, window['z0JY0D'] = function (gf6h4p) {
  wx[B[441143]]({ 'success': function (h1as9x) {
      var ghp9 = window['z0J0DY'];ghp9[B[441144]] = !![], ghp9[B[441145]] = Number(h1as9x[B[441145]])[B[441146]](0x0), ghp9[B[441147]] = h1as9x[B[441147]], gf6h4p && gf6h4p(ghp9[B[441144]], ghp9[B[441145]], ghp9[B[441147]]);
    }, 'fail': function (dykotz) {
      console[B[440225]](B[441148], dykotz[B[441045]]);var oazt = window['z0J0DY'];gf6h4p && gf6h4p(oazt[B[441144]], oazt[B[441145]], oazt[B[441147]]);
    } });
}, window[B[441121]] = function (mi73nq, p1s, hpg94, gh91p, yotzed, v7lmi, mlin7, g6p4f) {
  if (gh91p == undefined) gh91p = 0x1;wx[B[441008]]({ 'url': mi73nq, 'method': mlin7 || B[441149], 'responseType': B[441150], 'data': p1s, 'header': { 'content-type': g6p4f || B[441010] }, 'success': function (tykdbo) {
      DEBUG && console[B[440225]](B[441151], mi73nq, info, tykdbo);if (tykdbo && tykdbo[B[441152]] == 0xc8) {
        var _8bkr5 = tykdbo[B[440335]];!v7lmi || v7lmi(_8bkr5) ? hpg94 && hpg94(_8bkr5) : window[B[441153]](mi73nq, p1s, hpg94, gh91p, yotzed, v7lmi, tykdbo);
      } else window[B[441153]](mi73nq, p1s, hpg94, gh91p, yotzed, v7lmi, tykdbo);
    }, 'fail': function (ky8db) {
      DEBUG && console[B[440225]](B[441154], mi73nq, info, ky8db), window[B[441153]](mi73nq, p1s, hpg94, gh91p, yotzed, v7lmi, ky8db);
    }, 'complete': function () {} });
}, window[B[441153]] = function (p64gh1, dokb8, mvi7l, rwu_25, imn7q3, f64ph, f6p4gh) {
  rwu_25 - 0x1 > 0x0 ? setTimeout(function () {
    window[B[441121]](p64gh1, dokb8, mvi7l, rwu_25 - 0x1, imn7q3, f64ph);
  }, 0x3e8) : imn7q3 && imn7q3(JSON[B[440999]]({ 'url': p64gh1, 'response': f6p4gh }));
}, window[B[441155]] = function (tkyoz, dkbry, i7nqm3, fl4vg6, u2wr_5, x9shp1, q7im3$) {
  !i7nqm3 && (i7nqm3 = {});var qm7$ = Math[B[440071]](Date[B[440950]]() / 0x3e8);i7nqm3[B[441065]] = qm7$, i7nqm3[B[441156]] = dkbry;var i3mjq$ = Object[B[440030]](i7nqm3)[B[440382]](),
      _yk8 = '',
      rybk_ = '';for (var f64vnl = 0x0; f64vnl < i3mjq$[B[440031]]; f64vnl++) {
    _yk8 = _yk8 + (f64vnl == 0x0 ? '' : '&') + i3mjq$[f64vnl] + i7nqm3[i3mjq$[f64vnl]], rybk_ = rybk_ + (f64vnl == 0x0 ? '' : '&') + i3mjq$[f64vnl] + '=' + encodeURIComponent(i7nqm3[i3mjq$[f64vnl]]);
  }_yk8 = _yk8 + z0JD[B[440935]];var vpfg6 = B[441157] + md5(_yk8);send(tkyoz + '?' + rybk_ + (rybk_ == '' ? '' : '&') + vpfg6, null, fl4vg6, u2wr_5, x9shp1, q7im3$ || function (h1x9pg) {
    return h1x9pg[B[440981]] == B[441057];
  }, null, B[441158]);
}, window['z0JYD0'] = function (xzesta, d8bky) {
  var h1s9 = 0x0;z0JD[B[440944]] && (h1s9 = z0JD[B[440944]][B[440996]]), sendApi(z0JD[B[440931]], B[441159], { 'partnerId': z0JD[B[440937]], 'gamePkg': z0JD[B[440938]], 'logTime': Math[B[440071]](Date[B[440950]]() / 0x3e8), 'platformUid': z0JD[B[441061]], 'type': xzesta, 'serverId': h1s9 }, null, 0x2, null, function () {
    return !![];
  });
}, window['z0JD0Y'] = function (fvgl64) {
  sendApi(z0JD[B[440929]], B[441160], { 'partner_id': z0JD[B[440937]], 'uid': z0JD[B[440994]], 'version': z0JD[B[440924]], 'game_pkg': z0JD[B[440938]], 'device': z0JD[B[440939]] }, z0JDY0, z0YDJ, z0D0);
}, window['z0JDY0'] = function (by8r) {
  if (by8r[B[440981]] === B[441057] && by8r[B[440335]]) {
    by8r[B[440335]][B[440174]]({ 'id': -0x2, 'name': B[441161] }), by8r[B[440335]][B[440174]]({ 'id': -0x1, 'name': B[441162] }), z0JD[B[441163]] = by8r[B[440335]];if (window[B[441164]]) window[B[441164]][B[441165]]();
  } else z0JD[B[441166]] = ![], window['z00YJD'](B[441167] + by8r[B[440981]]);
}, window['z00YJ'] = function (h9g1px) {
  sendApi(z0JD[B[440929]], B[441168], { 'partner_id': z0JD[B[440937]], 'uid': z0JD[B[440994]], 'version': z0JD[B[440924]], 'game_pkg': z0JD[B[440938]], 'device': z0JD[B[440939]] }, z00JY, z0YDJ, z0D0);
}, window['z00JY'] = function (q3im$) {
  z0JD[B[441169]] = ![];if (q3im$[B[440981]] === B[441057] && q3im$[B[440335]]) {
    for (var ydeotz = 0x0; ydeotz < q3im$[B[440335]][B[440031]]; ydeotz++) {
      q3im$[B[440335]][ydeotz][B[441077]] = z0JY0(q3im$[B[440335]][ydeotz]);
    }z0JD[B[440941]][-0x1] = window[B[441170]](q3im$[B[440335]]), window[B[441164]][B[441171]](-0x1);
  } else window['z00YJD'](B[441172] + q3im$[B[440981]]);
}, window[B[441173]] = function (m3i7nq) {
  sendApi(z0JD[B[440929]], B[441168], { 'partner_id': z0JD[B[440937]], 'uid': z0JD[B[440994]], 'version': z0JD[B[440924]], 'game_pkg': z0JD[B[440938]], 'device': z0JD[B[440939]] }, m3i7nq, z0YDJ, z0D0);
}, window['z0Y0J'] = function (f64hgp, edozy) {
  sendApi(z0JD[B[440929]], B[441174], { 'partner_id': z0JD[B[440937]], 'uid': z0JD[B[440994]], 'version': z0JD[B[440924]], 'game_pkg': z0JD[B[440938]], 'device': z0JD[B[440939]], 'server_group_id': edozy }, z0YJ0, z0YDJ, z0D0);
}, window['z0YJ0'] = function (u85r2_) {
  z0JD[B[441169]] = ![];if (u85r2_[B[440981]] === B[441057] && u85r2_[B[440335]] && u85r2_[B[440335]][B[440335]]) {
    var p4f6v = u85r2_[B[440335]][B[441175]],
        fnl46v = [];for (var ur258_ = 0x0; ur258_ < u85r2_[B[440335]][B[440335]][B[440031]]; ur258_++) {
      u85r2_[B[440335]][B[440335]][ur258_][B[441077]] = z0JY0(u85r2_[B[440335]][B[440335]][ur258_]), (fnl46v[B[440031]] == 0x0 || u85r2_[B[440335]][B[440335]][ur258_][B[441077]] != 0x0) && (fnl46v[fnl46v[B[440031]]] = u85r2_[B[440335]][B[440335]][ur258_]);
    }z0JD[B[440941]][p4f6v] = window[B[441170]](fnl46v), window[B[441164]][B[441171]](p4f6v);
  } else window['z00YJD'](B[441176] + u85r2_[B[440981]]);
}, window['z0RYDJ'] = function (fnv67) {
  sendApi(z0JD[B[440929]], B[441177], { 'partner_id': z0JD[B[440937]], 'uid': z0JD[B[440994]], 'version': z0JD[B[440924]], 'game_pkg': z0JD[B[440938]], 'device': z0JD[B[440939]] }, reqServerRecommendCallBack, z0YDJ, z0D0);
}, window[B[441178]] = function (vi7lf) {
  z0JD[B[441169]] = ![];if (vi7lf[B[440981]] === B[441057] && vi7lf[B[440335]]) {
    for (var mqi3$ = 0x0; mqi3$ < vi7lf[B[440335]][B[440031]]; mqi3$++) {
      vi7lf[B[440335]][mqi3$][B[441077]] = z0JY0(vi7lf[B[440335]][mqi3$]);
    }z0JD[B[440941]][-0x2] = window[B[441170]](vi7lf[B[440335]]), window[B[441164]][B[441171]](-0x2);
  } else alert(B[441179] + vi7lf[B[440981]]);
}, window[B[441170]] = function (g164) {
  if (!g164 && g164[B[440031]] <= 0x0) return g164;for (let teoas = 0x0; teoas < g164[B[440031]]; teoas++) {
    g164[teoas][B[441180]] && g164[teoas][B[441180]] == 0x1 && (g164[teoas][B[441073]] += B[441181]);
  }return g164;
}, window['z0J0Y'] = function (mivl, m3nli) {
  mivl = mivl || z0JD[B[440944]][B[440996]], sendApi(z0JD[B[440929]], B[441182], { 'type': '4', 'game_pkg': z0JD[B[440938]], 'server_id': mivl }, m3nli);
}, window[B[441183]] = function (xg1p, p4fv6, l7nmv, e1sxa) {
  l7nmv = l7nmv || z0JD[B[440944]][B[440996]], sendApi(z0JD[B[440929]], B[441184], { 'type': xg1p, 'game_pkg': p4fv6, 'server_id': l7nmv }, e1sxa);
}, window['z0JY0'] = function (b8ykod) {
  if (b8ykod) {
    if (b8ykod[B[441077]] == 0x1) {
      if (b8ykod[B[441185]] == 0x1) return 0x2;else return 0x1;
    } else return b8ykod[B[441077]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['z0D0YJ'] = function (ezody, f67lnv) {
  z0JD[B[441186]] = { 'step': ezody, 'server_id': f67lnv };var r_82 = this;z00JYD({ 'title': B[441187] }), sendApi(z0JD[B[440929]], B[441188], { 'partner_id': z0JD[B[440937]], 'uid': z0JD[B[440994]], 'game_pkg': z0JD[B[440938]], 'server_id': f67lnv, 'platform': z0JD[B[441060]], 'platform_uid': z0JD[B[441061]], 'check_login_time': z0JD[B[441064]], 'check_login_sign': z0JD[B[441062]], 'version_name': z0JD[B[441033]] }, z0D0JY, z0YDJ, z0D0, function (p61h) {
    return p61h[B[440981]] == B[441057] || p61h[B[440982]] == B[441189] || p61h[B[440982]] == B[441190];
  });
}, window['z0D0JY'] = function (z9easx) {
  var tdboky = this;if (z9easx[B[440981]] === B[441057] && z9easx[B[440335]]) {
    var lv4gf6 = z0JD[B[440944]];lv4gf6[B[441191]] = z0JD[B[440942]], lv4gf6[B[441063]] = String(z9easx[B[440335]][B[441192]]), lv4gf6[B[440949]] = parseInt(z9easx[B[440335]][B[441065]]);if (z9easx[B[440335]][B[441193]]) lv4gf6[B[441193]] = parseInt(z9easx[B[440335]][B[441193]]);else lv4gf6[B[441193]] = parseInt(z9easx[B[440335]][B[440996]]);lv4gf6[B[441194]] = 0x0, lv4gf6[B[440995]] = z0JD[B[441088]], lv4gf6[B[441195]] = z9easx[B[440335]][B[441196]], lv4gf6[B[441197]] = z9easx[B[440335]][B[441197]], console[B[440225]](B[441198] + JSON[B[440999]](lv4gf6[B[441197]])), z0JD[B[441071]] == 0x1 && lv4gf6[B[441197]] && lv4gf6[B[441197]][B[441199]] == 0x1 && (z0JD[B[441200]] = 0x1, window[B[440978]][B[440979]]['z0RDJ']()), z0DY0J();
  } else z0JD[B[441186]][B[441201]] >= 0x3 ? (z0D0(JSON[B[440999]](z9easx)), window['z00YJD'](B[441202] + z9easx[B[440981]])) : sendApi(z0JD[B[440929]], B[441043], { 'platform': z0JD[B[440927]], 'partner_id': z0JD[B[440937]], 'token': z0JD[B[441041]], 'game_pkg': z0JD[B[440938]], 'deviceId': z0JD[B[440939]], 'scene': B[441044] + z0JD[B[440940]] }, function (mi$j3) {
    if (!mi$j3 || mi$j3[B[440981]] != B[441057]) {
      window['z00YJD'](B[441058] + mi$j3 && mi$j3[B[440981]]);return;
    }z0JD[B[441062]] = String(mi$j3[B[441063]]), z0JD[B[441064]] = String(mi$j3[B[441065]]), setTimeout(function () {
      z0D0YJ(z0JD[B[441186]][B[441201]] + 0x1, z0JD[B[441186]][B[440996]]);
    }, 0x5dc);
  }, z0YDJ, z0D0, function (kyd8br) {
    return kyd8br[B[440981]] == B[441057] || kyd8br[B[440981]] == B[441203];
  });
}, window['z0DY0J'] = function () {
  ServerLoading[B[440979]][B[441080]](z0JD[B[441071]]), window['z0YD'] = !![], window['z0DJ0Y']();
}, window['z0DYJ0'] = function () {
  if (window['z0DY'] && window['z0JYD'] && window[B[440960]] && window[B[440961]] && window['z0JDY'] && window['z0JY']) {
    if (!window[B[441204]][B[440979]]) {
      console[B[440225]](B[441205] + window[B[441204]][B[440979]]);var sh1p9 = wx[B[441206]](),
          xhsp9 = sh1p9[B[441120]] ? sh1p9[B[441120]] : 0x0,
          fh6gp = { 'cdn': window['z0JD'][B[440995]], 'spareCdn': window['z0JD'][B[441031]], 'newRegister': window['z0JD'][B[441071]], 'wxPC': window['z0JD'][B[440959]], 'wxIOS': window['z0JD'][B[440957]], 'wxAndroid': window['z0JD'][B[440958]], 'wxParam': { 'limitLoad': window['z0JD']['z0R0YDJ'], 'benchmarkLevel': window['z0JD']['z0R0JYD'], 'wxFrom': window[B[440917]][B[440051]] == B[441207] ? 0x1 : 0x0, 'wxSDKVersion': window[B[441124]] }, 'configType': window['z0JD'][B[440951]], 'exposeType': window['z0JD'][B[440953]], 'scene': xhsp9 };new window[B[441204]](fh6gp, window['z0JD'][B[440955]], window['z0R0YJD']);
    }
  }
}, window['z0DJ0Y'] = function () {
  if (window['z0DY'] && window['z0JYD'] && window[B[440960]] && window[B[440961]] && window['z0JDY'] && window['z0JY'] && window['z0YD'] && window['z0YJ']) {
    z00JDY();if (!z0DYJ) {
      z0DYJ = !![];if (!window[B[441204]][B[440979]]) window['z0DYJ0']();var fv6g4 = 0x0,
          r5u_28 = wx[B[441208]]();r5u_28 && (window['z0JD'][B[441209]] && (fv6g4 = r5u_28[B[441210]]), console[B[440982]](B[441211] + r5u_28[B[441210]] + B[441212] + r5u_28[B[441213]] + B[441214] + r5u_28[B[441215]] + B[441216] + r5u_28[B[441217]] + B[441218] + r5u_28[B[441219]] + B[441220] + r5u_28[B[441221]]));var dzot = {};for (const dtkz in z0JD[B[440944]]) {
        dzot[dtkz] = z0JD[B[440944]][dtkz];
      }var r8dykb = { 'channel': window['z0JD'][B[440943]], 'account': window['z0JD'][B[440994]], 'userId': window['z0JD'][B[441059]], 'serverId': dzot[B[440996]], 'cdn': window['z0JD'][B[440995]], 'data': window['z0JD'][B[440335]], 'package': window['z0JD'][B[440304]], 'newRegister': window['z0JD'][B[441071]], 'pkgName': window['z0JD'][B[440938]], 'partnerId': window['z0JD'][B[440937]], 'platform_uid': window['z0JD'][B[441061]], 'deviceId': window['z0JD'][B[440939]], 'selectedServer': dzot, 'configType': window['z0JD'][B[440951]], 'exposeType': window['z0JD'][B[440953]], 'debugUsers': window['z0JD'][B[440947]], 'wxMenuTop': fv6g4, 'wxShield': window['z0JD'][B[440956]] };if (window[B[441091]]) for (var eadoz in window[B[441091]]) {
        r8dykb[eadoz] = window[B[441091]][eadoz];
      }window[B[441204]][B[440979]]['z0DJR'](r8dykb);
    }
  } else console[B[440982]](B[441222] + window['z0DY'] + B[441223] + window['z0JYD'] + B[441224] + window[B[440960]] + B[441225] + window[B[440961]] + B[441226] + window['z0JDY'] + B[441227] + window['z0JY'] + B[441228] + window['z0YD'] + B[441229] + window['z0YJ']);
};