var B = wx.$z;
console[B[440982]](B[441230]), window[B[441231]], wx[B[441232]](function (b52r) {
  if (b52r) {
    if (b52r[B[440056]]) {
      var lmn73 = window[B[440917]][B[440918]][B[440243]](new RegExp(/\./, 'g'), '_'),
          li7fvn = b52r[B[440056]],
          a9szxe = li7fvn[B[440067]](/(zzzzz\/zzGAMEz.js:)[0-9]{1,60}(:)/g);if (a9szxe) for (var kdo8by = 0x0; kdo8by < a9szxe[B[440031]]; kdo8by++) {
        if (a9szxe[kdo8by] && a9szxe[kdo8by][B[440031]] > 0x0) {
          var mq$73 = parseInt(a9szxe[kdo8by][B[440243]](B[441233], '')[B[440243]](':', ''));li7fvn = li7fvn[B[440243]](a9szxe[kdo8by], a9szxe[kdo8by][B[440243]](':' + mq$73 + ':', ':' + (mq$73 - 0x2) + ':'));
        }
      }li7fvn = li7fvn[B[440243]](new RegExp(B[441234], 'g'), B[441235] + lmn73 + B[441236]), li7fvn = li7fvn[B[440243]](new RegExp(B[441237], 'g'), B[441235] + lmn73 + B[441236]), b52r[B[440056]] = li7fvn;
    }var b25r8 = { 'id': window['z0JD'][B[440991]], 'role': window['z0JD'][B[440992]], 'level': window['z0JD'][B[440993]], 'user': window['z0JD'][B[440994]], 'version': window['z0JD'][B[440955]], 'cdn': window['z0JD'][B[440995]], 'pkgName': window['z0JD'][B[440938]], 'gamever': window[B[440917]][B[440918]], 'serverid': window['z0JD'][B[440944]] ? window['z0JD'][B[440944]][B[440996]] : 0x0, 'systemInfo': window[B[440997]], 'error': B[441238], 'stack': b52r ? b52r[B[440056]] : '' },
        u_52w0 = JSON[B[440999]](b25r8);console[B[440333]](B[441239] + u_52w0), (!window[B[441231]] || window[B[441231]] != b25r8[B[440333]]) && (window[B[441231]] = b25r8[B[440333]], window['z00J'](b25r8));
  }
});import 'zzbfzz.js';import 'zz11zz.js';window[B[441240]] = require(B[441241]);import 'zINDzz.js';import 'zzIB1zz.js';import 'zzMtadzz.js';import 'zzINIzz.js';console[B[440982]](B[441242]), console[B[440982]](B[441243]), z00JYD({ 'title': B[441244] });var z$7mqi = { 'z0R0DJY': !![] };new window[B[440978]](z$7mqi), window[B[440978]][B[440979]]['z0RYJD0']();if (window['z0R0JDY']) clearInterval(window['z0R0JDY']);window['z0R0JDY'] = null, window['z0RYD0J'] = function (imv7n, nl7iv) {
  if (!imv7n || !nl7iv) return 0x0;imv7n = imv7n[B[440201]]('.'), nl7iv = nl7iv[B[440201]]('.');const x9az = Math[B[440301]](imv7n[B[440031]], nl7iv[B[440031]]);while (imv7n[B[440031]] < x9az) {
    imv7n[B[440066]]('0');
  }while (nl7iv[B[440031]] < x9az) {
    nl7iv[B[440066]]('0');
  }for (var iqnm7 = 0x0; iqnm7 < x9az; iqnm7++) {
    const ydob8k = parseInt(imv7n[iqnm7]),
          inm7 = parseInt(nl7iv[iqnm7]);if (ydob8k > inm7) return 0x1;else {
      if (ydob8k < inm7) return -0x1;
    }
  }return 0x0;
}, window[B[441124]] = wx[B[441245]]()[B[441124]], console[B[440225]](B[441246] + window[B[441124]]);var zzsext = wx[B[441247]]();zzsext[B[441248]](function (eazd) {
  console[B[440225]](B[441249] + eazd[B[441250]]);
}), zzsext[B[441251]](function () {
  wx[B[440964]]({ 'title': B[441252], 'content': B[441253], 'showCancel': ![], 'success': function (w5r_u2) {
      zzsext[B[441254]]();
    } });
}), zzsext[B[441255]](function () {
  console[B[440225]](B[441256]);
}), window['z0RYDJ0'] = function () {
  console[B[440225]](B[441257]);var _0wu25 = wx[B[441258]]({ 'name': B[441259], 'success': function (y8kd) {
      console[B[440225]](B[441260]), console[B[440225]](y8kd), y8kd && y8kd[B[441045]] == B[441261] ? (window['z0DY'] = !![], window['z0DYJ0'](), window['z0DJ0Y']()) : setTimeout(function () {
        window['z0RYDJ0']();
      }, 0x1f4);
    }, 'fail': function (p64gh1) {
      console[B[440225]](B[441262]), console[B[440225]](p64gh1), setTimeout(function () {
        window['z0RYDJ0']();
      }, 0x1f4);
    } });_0wu25 && _0wu25[B[441263]](_u5r2 => {});
}, window['z0RJ0DY'] = function () {
  console[B[440225]](B[441264]);var kzoyt = wx[B[441258]]({ 'name': B[441265], 'success': function (lifv7) {
      console[B[440225]](B[441266]), console[B[440225]](lifv7), lifv7 && lifv7[B[441045]] == B[441261] ? (window['z0JYD'] = !![], window['z0DYJ0'](), window['z0DJ0Y']()) : setTimeout(function () {
        window['z0RJ0DY']();
      }, 0x1f4);
    }, 'fail': function (dyotk) {
      console[B[440225]](B[441267]), console[B[440225]](dyotk), setTimeout(function () {
        window['z0RJ0DY']();
      }, 0x1f4);
    } });kzoyt && kzoyt[B[441263]](fv6nl7 => {});
}, window[B[441268]] = function () {
  window['z0RYD0J'](window[B[441124]], B[441269]) >= 0x0 ? (console[B[440225]](B[441270] + window[B[441124]] + B[441271]), window['z0J0'](), window['z0RYDJ0'](), window['z0RJ0DY']()) : (window['z0JD0'](B[441272], window[B[441124]]), wx[B[440964]]({ 'title': B[440965], 'content': B[441273] }));
}, window[B[440997]] = '', wx[B[441274]]({ 'success'(sh9a1x) {
    window[B[440997]] = B[441275] + sh9a1x[B[441276]] + B[441277] + sh9a1x[B[441278]] + B[441279] + sh9a1x[B[440924]] + B[441280] + sh9a1x[B[441281]] + B[441282] + sh9a1x[B[441060]] + B[441283] + sh9a1x[B[441124]] + B[441284] + sh9a1x[B[441285]], console[B[440225]](window[B[440997]]), console[B[440225]](B[441286] + sh9a1x[B[441287]] + B[441288] + sh9a1x[B[441289]] + B[441290] + sh9a1x[B[441291]] + B[441292] + sh9a1x[B[441293]] + B[441294] + sh9a1x[B[441295]] + B[441296] + sh9a1x[B[441297]] + B[441298] + (sh9a1x[B[441299]] ? sh9a1x[B[441299]][B[441210]] + ',' + sh9a1x[B[441299]][B[441213]] + ',' + sh9a1x[B[441299]][B[441215]] + ',' + sh9a1x[B[441299]][B[441217]] : ''));var xea = sh9a1x[B[441281]] ? sh9a1x[B[441281]][B[440103]]() : '',
        _8br5 = sh9a1x[B[441278]] ? sh9a1x[B[441278]][B[440103]]()[B[440243]]('\x20', '') : '';window['z0JD'][B[440957]] = xea[B[440146]](B[441300]) != -0x1, window['z0JD'][B[440958]] = xea[B[440146]](B[441301]) != -0x1, window['z0JD'][B[441209]] = xea[B[440146]](B[441300]) != -0x1 || xea[B[440146]](B[441301]) != -0x1, window['z0JD'][B[440959]] = xea[B[440146]](B[441302]) != -0x1 || xea[B[440146]](B[440926]) != -0x1, window['z0JD'][B[441005]] = sh9a1x[B[441060]] ? sh9a1x[B[441060]][B[440103]]() : '', window['z0JD']['z0R0YDJ'] = ![], window['z0JD']['z0R0JYD'] = 0x2;if (xea[B[440146]](B[441301]) != -0x1) {
      if (sh9a1x[B[441285]] >= 0x18) window['z0JD']['z0R0JYD'] = 0x3;else window['z0JD']['z0R0JYD'] = 0x2;
    } else {
      if (xea[B[440146]](B[441300]) != -0x1) {
        if (sh9a1x[B[441285]] && sh9a1x[B[441285]] >= 0x14) window['z0JD']['z0R0JYD'] = 0x3;else {
          if (_8br5[B[440146]](B[441303]) != -0x1 || _8br5[B[440146]](B[441304]) != -0x1 || _8br5[B[440146]](B[441305]) != -0x1 || _8br5[B[440146]](B[441306]) != -0x1 || _8br5[B[440146]](B[441307]) != -0x1) window['z0JD']['z0R0JYD'] = 0x2;else window['z0JD']['z0R0JYD'] = 0x3;
        }
      } else window['z0JD']['z0R0JYD'] = 0x2;
    }console[B[440225]](B[441308] + window['z0JD']['z0R0YDJ'] + B[441309] + window['z0JD']['z0R0JYD']);
  } }), wx[B[441143]]({ 'success': function (adt) {
    console[B[440225]](B[441310] + adt[B[441145]] + B[441311] + adt[B[441147]]);
  } }), wx[B[441312]]({ 'success': function (xes19) {
    console[B[440225]](B[441313] + xes19[B[441314]]);
  } }), wx[B[441315]]({ 'keepScreenOn': !![] }), wx[B[441316]](function (hpgf) {
  console[B[440225]](B[441313] + hpgf[B[441314]] + B[441317] + hpgf[B[441318]]);
}), wx[B[441118]](function (zasto) {
  window['z0Y0'] = zasto, window['z0D0Y'] && window['z0Y0'] && (console[B[440982]](B[441119] + window['z0Y0'][B[441120]]), window['z0D0Y'](window['z0Y0']), window['z0Y0'] = null);
}), window[B[441319]] = 0x0, window['z0RJYD0'] = 0x0, window[B[441320]] = null, wx[B[441321]](function () {
  window['z0RJYD0']++;var p91gxh = Date[B[440950]]();(window[B[441319]] == 0x0 || p91gxh - window[B[441319]] > 0x1d4c0) && (console[B[440383]](B[441322]), wx[B[441323]]());if (window['z0RJYD0'] >= 0x2) {
    window['z0RJYD0'] = 0x0, console[B[440333]](B[441324]), wx[B[441325]]('0', 0x1);if (window['z0JD'] && window['z0JD'][B[440957]]) window['z0JD0'](B[441326], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});