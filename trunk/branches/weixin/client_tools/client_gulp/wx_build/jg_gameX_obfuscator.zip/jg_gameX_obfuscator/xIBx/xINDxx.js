var u = wx.$x;
import xtk1wb from '../xxaxxx/x7xx.js';window[u[400917]] = { 'wxVersion': window[u[400918]][u[400919]] }, window[u[400920]] = ![], window['x196'] = 0x1, window[u[400921]] = 0x1, window['x1J69'] = !![], window[u[400922]] = !![], window['x1T$J69'] = '', window['x169'] = { 'base_cdn': u[400923], 'cdn': u[400923] }, x169[u[400924]] = {}, x169[u[400304]] = '0', x169[u[400925]] = window[u[400917]][u[400926]], x169[u[400927]] = '', x169['os'] = '1', x169[u[400928]] = u[400929], x169[u[400930]] = u[400931], x169[u[400932]] = u[400933], x169[u[400934]] = u[400935], x169[u[400936]] = u[400937], x169[u[400938]] = '1', x169[u[400939]] = '', x169[u[400940]] = '', x169[u[400941]] = 0x0, x169[u[400942]] = {}, x169[u[400943]] = parseInt(x169[u[400938]]), x169[u[400944]] = x169[u[400938]], x169[u[400945]] = {}, x169['x1$6'] = u[400946], x169[u[400947]] = ![], x169[u[400948]] = u[400949], x169[u[400950]] = Date[u[400951]](), x169[u[400952]] = u[400953], x169[u[400954]] = '_a', x169[u[400955]] = 0x2, x169[u[400956]] = 0x7c1, x169[u[400926]] = window[u[400917]][u[400926]], x169[u[400957]] = ![], x169[u[400958]] = ![], x169[u[400959]] = ![], x169[u[400960]] = ![], window['x1J96'] = 0x5, window['x1J9'] = ![], window['x19J'] = ![], window['x16J9'] = ![], window[u[400961]] = ![], window[u[400962]] = ![], window['x169J'] = ![], window['x1J6'] = ![], window['x16J'] = ![], window['x19J6'] = ![], window[u[400963]] = function (ixzmo) {
  console[u[400225]](u[400963], ixzmo), wx[u[400964]]({}), wx[u[400965]]({ 'title': u[400966], 'content': ixzmo, 'success'(u4dgv) {
      if (u4dgv[u[400967]]) console[u[400225]](u[400968]);else u4dgv[u[400969]] && console[u[400225]](u[400970]);
    } });
}, window['x1$J69'] = function (fcjl7) {
  console[u[400225]](u[400971], fcjl7), x1$69J(), wx[u[400965]]({ 'title': u[400966], 'content': fcjl7, 'confirmText': u[400972], 'cancelText': u[400973], 'success'(g4xsim) {
      if (g4xsim[u[400967]]) window['x16$']();else g4xsim[u[400969]] && (console[u[400225]](u[400974]), wx[u[400975]]({}));
    } });
}, window[u[400976]] = function (nudgv) {
  console[u[400225]](u[400976], nudgv), wx[u[400965]]({ 'title': u[400966], 'content': nudgv, 'confirmText': u[400977], 'showCancel': ![], 'complete'($97ly8) {
      console[u[400225]](u[400974]), wx[u[400975]]({});
    } });
}, window['x1$J96'] = ![], window['x1$6J9'] = function (epbah) {
  window['x1$J96'] = !![], wx[u[400978]](epbah);
}, window['x1$69J'] = function () {
  window['x1$J96'] && (window['x1$J96'] = ![], wx[u[400964]]({}));
}, window['x1$9J6'] = function (vjunf) {
  window[u[400979]][u[400980]]['x1$9J6'](vjunf);
}, window[u[400981]] = function (mzs5o2, cnuvdj) {
  xtk1wb[u[400981]](mzs5o2, function (kep) {
    kep && kep[u[400335]] ? kep[u[400335]][u[400982]] == 0x1 ? cnuvdj(!![]) : (cnuvdj(![]), console[u[400983]](u[400984] + kep[u[400335]][u[400985]])) : console[u[400225]](u[400981], kep);
  });
}, window['x1$96J'] = function (djvngu) {
  console[u[400225]](u[400986], djvngu);
}, window['x1$69'] = function (fc79j) {}, window['x1$96'] = function (cu, u4gvnd, z623) {}, window['x1$9'] = function (o65z2m) {
  console[u[400225]](u[400987], o65z2m), window[u[400979]][u[400980]][u[400988]](), window[u[400979]][u[400980]][u[400989]](), window[u[400979]][u[400980]][u[400990]]();
}, window['x19$'] = function (n9fcj) {
  window['x1$J69'](u[400991]);var flj9nc = { 'id': window['x169'][u[400992]], 'role': window['x169'][u[400993]], 'level': window['x169'][u[400994]], 'account': window['x169'][u[400995]], 'version': window['x169'][u[400956]], 'cdn': window['x169'][u[400996]], 'pkgName': window['x169'][u[400939]], 'gamever': window[u[400918]][u[400919]], 'serverid': window['x169'][u[400945]] ? window['x169'][u[400945]][u[400997]] : 0x0, 'systemInfo': window[u[400998]], 'error': u[400999], 'stack': n9fcj ? n9fcj : u[400991] },
      u9njc = JSON[u[401000]](flj9nc);console[u[400333]](u[401001] + u9njc), window['x1$6'](u9njc);
}, window['x16$9'] = function (kbwe1) {
  var d4gnu = JSON[u[400223]](kbwe1);d4gnu[u[401002]] = window[u[400918]][u[400919]], d4gnu[u[401003]] = window['x169'][u[400945]] ? window['x169'][u[400945]][u[400997]] : 0x0, d4gnu[u[400998]] = window[u[400998]];var mx4os = JSON[u[401000]](d4gnu);console[u[400333]](u[401004] + mx4os), window['x1$6'](mx4os);
}, window['x169$'] = function (bh0ap, l79$) {
  var bep0kh = { 'id': window['x169'][u[400992]], 'role': window['x169'][u[400993]], 'level': window['x169'][u[400994]], 'account': window['x169'][u[400995]], 'version': window['x169'][u[400956]], 'cdn': window['x169'][u[400996]], 'pkgName': window['x169'][u[400939]], 'gamever': window[u[400918]][u[400919]], 'serverid': window['x169'][u[400945]] ? window['x169'][u[400945]][u[400997]] : 0x0, 'systemInfo': window[u[400998]], 'error': bh0ap, 'stack': l79$ },
      guv = JSON[u[401000]](bep0kh);console[u[400383]](u[401005] + guv), window['x1$6'](guv);
}, window['x1$6'] = function (sm4gxi) {
  if (window['x169'][u[401006]] == u[401007]) return;var cvdju = x169['x1$6'] + u[401008] + x169[u[400995]];wx[u[401009]]({ 'url': cvdju, 'method': u[401010], 'data': sm4gxi, 'header': { 'content-type': u[401011], 'cache-control': u[401012] }, 'success': function (ah0) {
      DEBUG && console[u[400225]](u[401013], cvdju, sm4gxi, ah0);
    }, 'fail': function (k0ebwh) {
      DEBUG && console[u[400225]](u[401013], cvdju, sm4gxi, k0ebwh);
    }, 'complete': function () {} });
}, window[u[401014]] = function () {
  function s4gid() {
    return ((0x1 + Math[u[401015]]()) * 0x10000 | 0x0)[u[400060]](0x10)[u[400234]](0x1);
  }return s4gid() + s4gid() + '-' + s4gid() + '-' + s4gid() + '-' + s4gid() + '+' + s4gid() + s4gid() + s4gid();
}, window['x16$'] = function () {
  console[u[400225]](u[401016]);var wtk613 = xtk1wb[u[401017]]();x169[u[400944]] = wtk613[u[401018]], x169[u[400943]] = wtk613[u[401018]], x169[u[400938]] = wtk613[u[401018]], x169[u[400939]] = wtk613[u[401019]];var flcj79 = { 'game_ver': x169[u[400925]] };x169[u[400940]] = this[u[401014]](), x1$6J9({ 'title': u[401020] }), xtk1wb[u[401021]](flcj79, this['x19$6'][u[400017]](this));
}, window['x19$6'] = function (ngd4u) {
  var dcjuv = ngd4u[u[401022]];console[u[400225]](u[401023] + dcjuv + u[401024] + (dcjuv == 0x1) + u[401025] + ngd4u[u[400919]] + u[401026] + window[u[400917]][u[400926]]);if (!ngd4u[u[400919]] || window['x1TJ9$6'](window[u[400917]][u[400926]], ngd4u[u[400919]]) < 0x0) console[u[400225]](u[401027]), x169[u[400930]] = u[401028], x169[u[400932]] = u[401029], x169[u[400934]] = u[401030], x169[u[400996]] = u[401031], x169[u[401032]] = u[401033], x169[u[401034]] = 'xc', x169[u[400957]] = ![];else window['x1TJ9$6'](window[u[400917]][u[400926]], ngd4u[u[400919]]) == 0x0 ? (console[u[400225]](u[401035]), x169[u[400930]] = u[400931], x169[u[400932]] = u[400933], x169[u[400934]] = u[400935], x169[u[400996]] = u[401036], x169[u[401032]] = u[401033], x169[u[401034]] = u[401037], x169[u[400957]] = !![]) : (console[u[400225]](u[401038]), x169[u[400930]] = u[400931], x169[u[400932]] = u[400933], x169[u[400934]] = u[400935], x169[u[400996]] = u[401036], x169[u[401032]] = u[401033], x169[u[401034]] = u[401037], x169[u[400957]] = ![]);x169[u[400941]] = config[u[400051]] ? config[u[400051]] : 0x0, this['x1J6$9'](), this['x1J69$'](), window[u[401039]] = 0x5, x1$6J9({ 'title': u[401040] }), xtk1wb[u[401041]](this['x196$'][u[400017]](this));
}, window[u[401039]] = 0x5, window['x196$'] = function (gi4sd, yl79f8) {
  if (gi4sd == 0x0 && yl79f8 && yl79f8[u[400285]]) {
    x169[u[401042]] = yl79f8[u[400285]];var jdugnv = this;x1$6J9({ 'title': u[401043] }), sendApi(x169[u[400930]], u[401044], { 'platform': x169[u[400928]], 'partner_id': x169[u[400938]], 'token': yl79f8[u[400285]], 'game_pkg': x169[u[400939]], 'deviceId': x169[u[400940]], 'scene': u[401045] + x169[u[400941]] }, this['x1J$69'][u[400017]](this), x1J96, x19$);
  } else yl79f8 && yl79f8[u[401046]] && window[u[401039]] > 0x0 && (yl79f8[u[401046]][u[400146]](u[401047]) != -0x1 || yl79f8[u[401046]][u[400146]](u[401048]) != -0x1 || yl79f8[u[401046]][u[400146]](u[401049]) != -0x1 || yl79f8[u[401046]][u[400146]](u[401050]) != -0x1 || yl79f8[u[401046]][u[400146]](u[401051]) != -0x1 || yl79f8[u[401046]][u[400146]](u[401052]) != -0x1) ? (window[u[401039]]--, xtk1wb[u[401041]](this['x196$'][u[400017]](this))) : (window['x169$'](u[401053], JSON[u[401000]]({ 'status': gi4sd, 'data': yl79f8 })), window['x1$J69'](u[401054] + (yl79f8 && yl79f8[u[401046]] ? '，' + yl79f8[u[401046]] : '')));
}, window['x1J$69'] = function (fcl897) {
  if (!fcl897) {
    window['x169$'](u[401055], u[401056]), window['x1$J69'](u[401057]);return;
  }if (fcl897[u[400982]] != u[401058]) {
    window['x169$'](u[401055], JSON[u[401000]](fcl897)), window['x1$J69'](u[401059] + fcl897[u[400982]]);return;
  }x169[u[401060]] = String(fcl897[u[400995]]), x169[u[400995]] = String(fcl897[u[400995]]), x169[u[401061]] = String(fcl897[u[401061]]), x169[u[400944]] = String(fcl897[u[401061]]), x169[u[401062]] = String(fcl897[u[401062]]), x169[u[401063]] = String(fcl897[u[401064]]), x169[u[401065]] = String(fcl897[u[401066]]), x169[u[401064]] = '';var q0p = this;x1$6J9({ 'title': u[401067] }), sendApi(x169[u[400930]], u[401068], { 'partner_id': x169[u[400938]], 'uid': x169[u[400995]], 'version': x169[u[400925]], 'game_pkg': x169[u[400939]], 'device': x169[u[400940]] }, q0p['x1J$96'][u[400017]](q0p), x1J96, x19$);
}, window['x1J$96'] = function (jl9nfc) {
  if (!jl9nfc) {
    window['x1$J69'](u[401069]);return;
  }if (jl9nfc[u[400982]] != u[401058]) {
    window['x1$J69'](u[401070] + jl9nfc[u[400982]]);return;
  }if (!jl9nfc[u[400335]] || jl9nfc[u[400335]][u[400031]] == 0x0) {
    window['x1$J69'](u[401071]);return;
  }x169[u[401072]] = jl9nfc[u[401073]], x169[u[400945]] = { 'server_id': String(jl9nfc[u[400335]][0x0][u[400997]]), 'server_name': String(jl9nfc[u[400335]][0x0][u[401074]]), 'entry_ip': jl9nfc[u[400335]][0x0][u[401075]], 'entry_port': parseInt(jl9nfc[u[400335]][0x0][u[401076]]), 'status': x16J$(jl9nfc[u[400335]][0x0]), 'start_time': jl9nfc[u[400335]][0x0][u[401077]], 'cdn': x169[u[400996]] }, this['x196J$']();
}, window['x196J$'] = function () {
  if (x169[u[401072]] == 0x1) {
    var b0epkh = x169[u[400945]][u[401078]];if (b0epkh === -0x1 || b0epkh === 0x0) {
      window['x1$J69'](b0epkh === -0x1 ? u[401079] : u[401080]);return;
    }x19$J6(0x0, x169[u[400945]][u[400997]]), window[u[400979]][u[400980]][u[401081]](x169[u[401072]]);
  } else window[u[400979]][u[400980]][u[401082]](), x1$69J();window['x16J'] = !![], window['x19J6$'](), window['x196$J']();
}, window['x1J6$9'] = function () {
  sendApi(x169[u[400930]], u[401083], { 'game_pkg': x169[u[400939]], 'version_name': x169[u[401034]] }, this[u[401084]][u[400017]](this), x1J96, x19$);
}, window[u[401084]] = function (aphq_) {
  if (!aphq_) {
    window['x1$J69'](u[401085]);return;
  }if (aphq_[u[400982]] != u[401058]) {
    window['x1$J69'](u[401086] + aphq_[u[400982]]);return;
  }if (!aphq_[u[400335]] || !aphq_[u[400335]][u[400925]]) {
    window['x1$J69'](u[401087] + (aphq_[u[400335]] && aphq_[u[400335]][u[400925]]));return;
  }aphq_[u[400335]][u[401088]] && aphq_[u[400335]][u[401088]][u[400031]] > 0xa && (x169[u[401089]] = aphq_[u[400335]][u[401088]], x169[u[400996]] = aphq_[u[400335]][u[401088]]), aphq_[u[400335]][u[400925]] && (x169[u[400956]] = aphq_[u[400335]][u[400925]]), console[u[400983]](u[401090] + x169[u[400956]] + u[401091] + x169[u[401034]]), window['x169J'] = !![], window['x19J6$'](), window['x196$J']();
}, window[u[401092]], window['x1J69$'] = function () {
  sendApi(x169[u[400930]], u[401093], { 'game_pkg': x169[u[400939]] }, this['x1J9$6'][u[400017]](this), x1J96, x19$);
}, window['x1J9$6'] = function (qhaep_) {
  if (qhaep_[u[400982]] === u[401058] && qhaep_[u[400335]]) {
    window[u[401092]] = qhaep_[u[400335]];for (var pe0qh in qhaep_[u[400335]]) {
      x169[pe0qh] = qhaep_[u[400335]][pe0qh];
    }
  } else console[u[400983]](u[401094] + qhaep_[u[400982]]);window['x1J6'] = !![], window['x196$J']();
}, window[u[401095]] = function (apqe0h, bpkeh, w136, vid4ug, bw1k0, fcjnuv, gims4x, i4dsxg, i4vdu) {
  bw1k0 = String(bw1k0);var lc8 = gims4x,
      gsm4xi = i4dsxg;x169[u[400924]][bw1k0] = { 'productid': bw1k0, 'productname': lc8, 'productdesc': gsm4xi, 'roleid': apqe0h, 'rolename': bpkeh, 'rolelevel': w136, 'price': fcjnuv, 'callback': i4vdu }, sendApi(x169[u[400934]], u[401096], { 'game_pkg': x169[u[400939]], 'server_id': x169[u[400945]][u[400997]], 'server_name': x169[u[400945]][u[401074]], 'level': w136, 'uid': x169[u[400995]], 'role_id': apqe0h, 'role_name': bpkeh, 'product_id': bw1k0, 'product_name': lc8, 'product_desc': gsm4xi, 'money': fcjnuv, 'partner_id': x169[u[400938]] }, toPayCallBack, x1J96, x19$);
}, window[u[401097]] = function (moxs) {
  if (moxs) {
    if (moxs[u[401098]] === 0xc8 || moxs[u[400982]] == u[401058]) {
      var dig4s = x169[u[400924]][String(moxs[u[401099]])];if (dig4s[u[401100]]) dig4s[u[401100]](moxs[u[401099]], moxs[u[401101]], -0x1);xtk1wb[u[401102]]({ 'cpbill': moxs[u[401101]], 'productid': moxs[u[401099]], 'productname': dig4s[u[401103]], 'productdesc': dig4s[u[401104]], 'serverid': x169[u[400945]][u[400997]], 'servername': x169[u[400945]][u[401074]], 'roleid': dig4s[u[401105]], 'rolename': dig4s[u[401106]], 'rolelevel': dig4s[u[401107]], 'price': dig4s[u[401108]], 'extension': JSON[u[401000]]({ 'cp_order_id': moxs[u[401101]] }) }, function (w26, fnjcuv) {
        dig4s[u[401100]] && w26 == 0x0 && dig4s[u[401100]](moxs[u[401099]], moxs[u[401101]], w26);console[u[400983]](JSON[u[401000]]({ 'type': u[401109], 'status': w26, 'data': moxs, 'role_name': dig4s[u[401106]] }));if (w26 === 0x0) {} else {
          if (w26 === 0x1) {} else {
            if (w26 === 0x2) {}
          }
        }
      });
    } else alert(moxs[u[400983]]);
  }
}, window['x1J96$'] = function () {}, window['x1$J9'] = function (fcj9ln, vidx4g, zot652, i4gvx, gm4isx) {
  xtk1wb[u[401110]](x169[u[400945]][u[400997]], x169[u[400945]][u[401074]] || x169[u[400945]][u[400997]], fcj9ln, vidx4g, zot652), sendApi(x169[u[400930]], u[401111], { 'game_pkg': x169[u[400939]], 'server_id': x169[u[400945]][u[400997]], 'role_id': fcj9ln, 'uid': x169[u[400995]], 'role_name': vidx4g, 'role_type': i4gvx, 'level': zot652 });
}, window['x1$9J'] = function (dujvn, vid4gu, f9nuc, l978yf, wt16k, g4vdi, njcl9, fn9ju, udjcn, szi) {
  x169[u[400992]] = dujvn, x169[u[400993]] = vid4gu, x169[u[400994]] = f9nuc, xtk1wb[u[401112]](x169[u[400945]][u[400997]], x169[u[400945]][u[401074]] || x169[u[400945]][u[400997]], dujvn, vid4gu, f9nuc), sendApi(x169[u[400930]], u[401113], { 'game_pkg': x169[u[400939]], 'server_id': x169[u[400945]][u[400997]], 'role_id': dujvn, 'uid': x169[u[400995]], 'role_name': vid4gu, 'role_type': l978yf, 'level': f9nuc, 'evolution': wt16k });
}, window['x1J$9'] = function (gdvui, hpr_aq, hepqa0, mix4, vd4ugn, f79jc, _hpeq, jfnl9, behkp, ahpeq) {
  x169[u[400992]] = gdvui, x169[u[400993]] = hpr_aq, x169[u[400994]] = hepqa0, xtk1wb[u[401114]](x169[u[400945]][u[400997]], x169[u[400945]][u[401074]] || x169[u[400945]][u[400997]], gdvui, hpr_aq, hepqa0), sendApi(x169[u[400930]], u[401113], { 'game_pkg': x169[u[400939]], 'server_id': x169[u[400945]][u[400997]], 'role_id': gdvui, 'uid': x169[u[400995]], 'role_name': hpr_aq, 'role_type': mix4, 'level': hepqa0, 'evolution': vd4ugn });
}, window['x1J9$'] = function (f7y89l) {}, window['x1$J'] = function (xsmioz) {
  xtk1wb[u[401115]](u[401115], function (c7f89) {
    xsmioz && xsmioz(c7f89);
  });
}, window[u[401116]] = function () {
  xtk1wb[u[401116]]();
}, window[u[401117]] = function () {
  xtk1wb[u[401118]]();
}, window[u[401119]] = function (h0bpa, dnjgvu, udvjn, ew0kb, l7cj9f, rh_paq, t62oz, bh0ea) {
  bh0ea = bh0ea || x169[u[400945]][u[400997]], sendApi(x169[u[400930]], u[401120], { 'phone': h0bpa, 'role_id': dnjgvu, 'uid': x169[u[400995]], 'game_pkg': x169[u[400939]], 'partner_id': x169[u[400938]], 'server_id': bh0ea }, t62oz);
}, window[u[401121]] = function (ujfc9) {
  window['x19$J'] = ujfc9, window['x19$J'] && window['x1J$'] && (console[u[400983]](u[401122] + window['x1J$'][u[401123]]), window['x19$J'](window['x1J$']), window['x1J$'] = null);
}, window['x19J$'] = function (qra_, qe0, jl9cn, to2z56) {
  window[u[401124]](u[401125], { 'game_pkg': window['x169'][u[400939]], 'role_id': qe0, 'server_id': jl9cn }, to2z56);
}, window['x16$J9'] = function (ep0kbh, g4uvn) {
  function osixmz(nl9c) {
    var gund4 = [],
        ehkbw = [],
        vxdi4g = window[u[400918]][u[401126]];for (var k3w16t in vxdi4g) {
      var lj9fn = Number(k3w16t);(!ep0kbh || !ep0kbh[u[400031]] || ep0kbh[u[400146]](lj9fn) != -0x1) && (ehkbw[u[400066]](vxdi4g[k3w16t]), gund4[u[400066]]([lj9fn, 0x3]));
    }window['x1TJ9$6'](window[u[401127]], u[401128]) >= 0x0 ? (console[u[400225]](u[401129]), xtk1wb[u[401130]] && xtk1wb[u[401130]](ehkbw, function (hp0kbe) {
      console[u[400225]](u[401131]), console[u[400225]](hp0kbe);if (hp0kbe && hp0kbe[u[401046]] == u[401132]) for (var fnu9cj in vxdi4g) {
        if (hp0kbe[vxdi4g[fnu9cj]] == u[401133]) {
          var uidgv = Number(fnu9cj);for (var fy9l8 = 0x0; fy9l8 < gund4[u[400031]]; fy9l8++) {
            if (gund4[fy9l8][0x0] == uidgv) {
              gund4[fy9l8][0x1] = 0x1;break;
            }
          }
        }
      }window['x1TJ9$6'](window[u[401127]], u[401134]) >= 0x0 ? wx[u[401135]]({ 'withSubscriptions': !![], 'success': function (igs4d) {
          var pb0 = igs4d[u[401136]][u[401137]];if (pb0) {
            console[u[400225]](u[401138]), console[u[400225]](pb0);for (var jf in vxdi4g) {
              if (pb0[vxdi4g[jf]] == u[401133]) {
                var x4sgd = Number(jf);for (var ixmos = 0x0; ixmos < gund4[u[400031]]; ixmos++) {
                  if (gund4[ixmos][0x0] == x4sgd) {
                    gund4[ixmos][0x1] = 0x2;break;
                  }
                }
              }
            }console[u[400225]](gund4), g4uvn && g4uvn(gund4);
          } else console[u[400225]](u[401139]), console[u[400225]](igs4d), console[u[400225]](gund4), g4uvn && g4uvn(gund4);
        }, 'fail': function () {
          console[u[400225]](u[401140]), console[u[400225]](gund4), g4uvn && g4uvn(gund4);
        } }) : (console[u[400225]](u[401141] + window[u[401127]]), console[u[400225]](gund4), g4uvn && g4uvn(gund4));
    })) : (console[u[400225]](u[401142] + window[u[401127]]), console[u[400225]](gund4), g4uvn && g4uvn(gund4)), wx[u[401143]](osixmz);
  }wx[u[401144]](osixmz);
}, window['x16$9J'] = { 'isSuccess': ![], 'level': u[401145], 'isCharging': ![] }, window['x16J$9'] = function (gsix4) {
  wx[u[401146]]({ 'success': function (xsz) {
      var sixmg4 = window['x16$9J'];sixmg4[u[401147]] = !![], sixmg4[u[401148]] = Number(xsz[u[401148]])[u[401149]](0x0), sixmg4[u[401150]] = xsz[u[401150]], gsix4 && gsix4(sixmg4[u[401147]], sixmg4[u[401148]], sixmg4[u[401150]]);
    }, 'fail': function (tkwb1) {
      console[u[400225]](u[401151], tkwb1[u[401046]]);var yf89l7 = window['x16$9J'];gsix4 && gsix4(yf89l7[u[401147]], yf89l7[u[401148]], yf89l7[u[401150]]);
    } });
}, window[u[401124]] = function (f8l97c, w31bkt, vcnfu, dnjc, mzox, q_r, njcudv, xsoz) {
  if (dnjc == undefined) dnjc = 0x1;wx[u[401009]]({ 'url': f8l97c, 'method': njcudv || u[401152], 'responseType': u[401153], 'data': w31bkt, 'header': { 'content-type': xsoz || u[401011] }, 'success': function (kep0b) {
      DEBUG && console[u[400225]](u[401154], f8l97c, info, kep0b);if (kep0b && kep0b[u[401155]] == 0xc8) {
        var jn9c = kep0b[u[400335]];!q_r || q_r(jn9c) ? vcnfu && vcnfu(jn9c) : window[u[401156]](f8l97c, w31bkt, vcnfu, dnjc, mzox, q_r, kep0b);
      } else window[u[401156]](f8l97c, w31bkt, vcnfu, dnjc, mzox, q_r, kep0b);
    }, 'fail': function (zxom) {
      DEBUG && console[u[400225]](u[401157], f8l97c, info, zxom), window[u[401156]](f8l97c, w31bkt, vcnfu, dnjc, mzox, q_r, zxom);
    }, 'complete': function () {} });
}, window[u[401156]] = function (izsox, i4vdgu, gud4v, ujgnv, z5t63, xo5szm, jlcn9f) {
  ujgnv - 0x1 > 0x0 ? setTimeout(function () {
    window[u[401124]](izsox, i4vdgu, gud4v, ujgnv - 0x1, z5t63, xo5szm);
  }, 0x3e8) : z5t63 && z5t63(JSON[u[401000]]({ 'url': izsox, 'response': jlcn9f }));
}, window[u[401158]] = function (mzsix, ujnfc9, h_peqa, uncf, zo2m, u4vdig, x4oim) {
  !h_peqa && (h_peqa = {});var xg4dv = Math[u[400071]](Date[u[400951]]() / 0x3e8);h_peqa[u[401066]] = xg4dv, h_peqa[u[401159]] = ujnfc9;var rhap_q = Object[u[400030]](h_peqa)[u[400382]](),
      kbp0e = '',
      toz26 = '';for (var qap0eh = 0x0; qap0eh < rhap_q[u[400031]]; qap0eh++) {
    kbp0e = kbp0e + (qap0eh == 0x0 ? '' : '&') + rhap_q[qap0eh] + h_peqa[rhap_q[qap0eh]], toz26 = toz26 + (qap0eh == 0x0 ? '' : '&') + rhap_q[qap0eh] + '=' + encodeURIComponent(h_peqa[rhap_q[qap0eh]]);
  }kbp0e = kbp0e + x169[u[400936]];var z5ot = u[401160] + md5(kbp0e);send(mzsix + '?' + toz26 + (toz26 == '' ? '' : '&') + z5ot, null, uncf, zo2m, u4vdig, x4oim || function (dxisg4) {
    return dxisg4[u[400982]] == u[401058];
  }, null, u[401161]);
}, window['x16J9$'] = function (v4gndu, vd4ui) {
  var ncjvu = 0x0;x169[u[400945]] && (ncjvu = x169[u[400945]][u[400997]]), sendApi(x169[u[400932]], u[401162], { 'partnerId': x169[u[400938]], 'gamePkg': x169[u[400939]], 'logTime': Math[u[400071]](Date[u[400951]]() / 0x3e8), 'platformUid': x169[u[401062]], 'type': v4gndu, 'serverId': ncjvu }, null, 0x2, null, function () {
    return !![];
  });
}, window['x169$J'] = function (hbpek0) {
  sendApi(x169[u[400930]], u[401163], { 'partner_id': x169[u[400938]], 'uid': x169[u[400995]], 'version': x169[u[400925]], 'game_pkg': x169[u[400939]], 'device': x169[u[400940]] }, x169J$, x1J96, x19$);
}, window['x169J$'] = function (w163t2) {
  if (w163t2[u[400982]] === u[401058] && w163t2[u[400335]]) {
    w163t2[u[400335]][u[400174]]({ 'id': -0x2, 'name': u[401164] }), w163t2[u[400335]][u[400174]]({ 'id': -0x1, 'name': u[401165] }), x169[u[401166]] = w163t2[u[400335]];if (window[u[401167]]) window[u[401167]][u[401168]]();
  } else x169[u[401169]] = ![], window['x1$J69'](u[401170] + w163t2[u[400982]]);
}, window['x1$J6'] = function (f9lcjn) {
  sendApi(x169[u[400930]], u[401171], { 'partner_id': x169[u[400938]], 'uid': x169[u[400995]], 'version': x169[u[400925]], 'game_pkg': x169[u[400939]], 'device': x169[u[400940]] }, x1$6J, x1J96, x19$);
}, window['x1$6J'] = function (zsm2) {
  x169[u[401172]] = ![];if (zsm2[u[400982]] === u[401058] && zsm2[u[400335]]) {
    for (var vugid = 0x0; vugid < zsm2[u[400335]][u[400031]]; vugid++) {
      zsm2[u[400335]][vugid][u[401078]] = x16J$(zsm2[u[400335]][vugid]);
    }x169[u[400942]][-0x1] = window[u[401173]](zsm2[u[400335]]), window[u[401167]][u[401174]](-0x1);
  } else window['x1$J69'](u[401175] + zsm2[u[400982]]);
}, window[u[401176]] = function (ncjuf) {
  sendApi(x169[u[400930]], u[401171], { 'partner_id': x169[u[400938]], 'uid': x169[u[400995]], 'version': x169[u[400925]], 'game_pkg': x169[u[400939]], 'device': x169[u[400940]] }, ncjuf, x1J96, x19$);
}, window['x1J$6'] = function (o265, t652) {
  sendApi(x169[u[400930]], u[401177], { 'partner_id': x169[u[400938]], 'uid': x169[u[400995]], 'version': x169[u[400925]], 'game_pkg': x169[u[400939]], 'device': x169[u[400940]], 'server_group_id': t652 }, x1J6$, x1J96, x19$);
}, window['x1J6$'] = function (om56z) {
  x169[u[401172]] = ![];if (om56z[u[400982]] === u[401058] && om56z[u[400335]] && om56z[u[400335]][u[400335]]) {
    var w1b3kt = om56z[u[400335]][u[401178]],
        ly789 = [];for (var fvncu = 0x0; fvncu < om56z[u[400335]][u[400335]][u[400031]]; fvncu++) {
      om56z[u[400335]][u[400335]][fvncu][u[401078]] = x16J$(om56z[u[400335]][u[400335]][fvncu]), (ly789[u[400031]] == 0x0 || om56z[u[400335]][u[400335]][fvncu][u[401078]] != 0x0) && (ly789[ly789[u[400031]]] = om56z[u[400335]][u[400335]][fvncu]);
    }x169[u[400942]][w1b3kt] = window[u[401173]](ly789), window[u[401167]][u[401174]](w1b3kt);
  } else window['x1$J69'](u[401179] + om56z[u[400982]]);
}, window['x1TJ96'] = function (vdgx) {
  sendApi(x169[u[400930]], u[401180], { 'partner_id': x169[u[400938]], 'uid': x169[u[400995]], 'version': x169[u[400925]], 'game_pkg': x169[u[400939]], 'device': x169[u[400940]] }, reqServerRecommendCallBack, x1J96, x19$);
}, window[u[401181]] = function (phe_) {
  x169[u[401172]] = ![];if (phe_[u[400982]] === u[401058] && phe_[u[400335]]) {
    for (var xszmo = 0x0; xszmo < phe_[u[400335]][u[400031]]; xszmo++) {
      phe_[u[400335]][xszmo][u[401078]] = x16J$(phe_[u[400335]][xszmo]);
    }x169[u[400942]][-0x2] = window[u[401173]](phe_[u[400335]]), window[u[401167]][u[401174]](-0x2);
  } else alert(u[401182] + phe_[u[400982]]);
}, window[u[401173]] = function (o4ms) {
  if (!o4ms && o4ms[u[400031]] <= 0x0) return o4ms;for (let vud4gn = 0x0; vud4gn < o4ms[u[400031]]; vud4gn++) {
    o4ms[vud4gn][u[401183]] && o4ms[vud4gn][u[401183]] == 0x1 && (o4ms[vud4gn][u[401074]] += u[401184]);
  }return o4ms;
}, window['x16$J'] = function (igduv, kt316) {
  igduv = igduv || x169[u[400945]][u[400997]], sendApi(x169[u[400930]], u[401185], { 'type': '4', 'game_pkg': x169[u[400939]], 'server_id': igduv }, kt316);
}, window[u[401186]] = function (k1w, jfcvun, hq_a, dgu4n) {
  hq_a = hq_a || x169[u[400945]][u[400997]], sendApi(x169[u[400930]], u[401187], { 'type': k1w, 'game_pkg': jfcvun, 'server_id': hq_a }, dgu4n);
}, window['x16J$'] = function (k0bh) {
  if (k0bh) {
    if (k0bh[u[401078]] == 0x1) {
      if (k0bh[u[401188]] == 0x1) return 0x2;else return 0x1;
    } else return k0bh[u[401078]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['x19$J6'] = function (t3w1kb, vg4u) {
  x169[u[401189]] = { 'step': t3w1kb, 'server_id': vg4u };var bea0ph = this;x1$6J9({ 'title': u[401190] }), sendApi(x169[u[400930]], u[401191], { 'partner_id': x169[u[400938]], 'uid': x169[u[400995]], 'game_pkg': x169[u[400939]], 'server_id': vg4u, 'platform': x169[u[401061]], 'platform_uid': x169[u[401062]], 'check_login_time': x169[u[401065]], 'check_login_sign': x169[u[401063]], 'version_name': x169[u[401034]] }, x19$6J, x1J96, x19$, function (bk0hw) {
    return bk0hw[u[400982]] == u[401058] || bk0hw[u[400983]] == u[401192] || bk0hw[u[400983]] == u[401193];
  });
}, window['x19$6J'] = function (bha0ep) {
  var s4digx = this;if (bha0ep[u[400982]] === u[401058] && bha0ep[u[400335]]) {
    var cjfu9n = x169[u[400945]];cjfu9n[u[401194]] = x169[u[400943]], cjfu9n[u[401064]] = String(bha0ep[u[400335]][u[401195]]), cjfu9n[u[400950]] = parseInt(bha0ep[u[400335]][u[401066]]);if (bha0ep[u[400335]][u[401196]]) cjfu9n[u[401196]] = parseInt(bha0ep[u[400335]][u[401196]]);else cjfu9n[u[401196]] = parseInt(bha0ep[u[400335]][u[400997]]);cjfu9n[u[401197]] = 0x0, cjfu9n[u[400996]] = x169[u[401089]], cjfu9n[u[401198]] = bha0ep[u[400335]][u[401199]], cjfu9n[u[401200]] = bha0ep[u[400335]][u[401200]], console[u[400225]](u[401201] + JSON[u[401000]](cjfu9n[u[401200]])), x169[u[401072]] == 0x1 && cjfu9n[u[401200]] && cjfu9n[u[401200]][u[401202]] == 0x1 && (x169[u[401203]] = 0x1, window[u[400979]][u[400980]]['x1T96']()), x19J$6();
  } else x169[u[401189]][u[401204]] >= 0x3 ? (x19$(JSON[u[401000]](bha0ep)), window['x1$J69'](u[401205] + bha0ep[u[400982]])) : sendApi(x169[u[400930]], u[401044], { 'platform': x169[u[400928]], 'partner_id': x169[u[400938]], 'token': x169[u[401042]], 'game_pkg': x169[u[400939]], 'deviceId': x169[u[400940]], 'scene': u[401045] + x169[u[400941]] }, function (o265t) {
    if (!o265t || o265t[u[400982]] != u[401058]) {
      window['x1$J69'](u[401059] + o265t && o265t[u[400982]]);return;
    }x169[u[401063]] = String(o265t[u[401064]]), x169[u[401065]] = String(o265t[u[401066]]), setTimeout(function () {
      x19$J6(x169[u[401189]][u[401204]] + 0x1, x169[u[401189]][u[400997]]);
    }, 0x5dc);
  }, x1J96, x19$, function (cl9) {
    return cl9[u[400982]] == u[401058] || cl9[u[400982]] == u[401206];
  });
}, window['x19J$6'] = function () {
  ServerLoading[u[400980]][u[401081]](x169[u[401072]]), window['x1J9'] = !![], window['x196$J']();
}, window['x19J6$'] = function () {
  if (window['x19J'] && window['x16J9'] && window[u[400961]] && window[u[400962]] && window['x169J'] && window['x16J']) {
    if (!window[u[401207]][u[400980]]) {
      console[u[400225]](u[401208] + window[u[401207]][u[400980]]);var wk13b = wx[u[401209]](),
          dnv4ug = wk13b[u[401123]] ? wk13b[u[401123]] : 0x0,
          uvf = { 'cdn': window['x169'][u[400996]], 'spareCdn': window['x169'][u[401032]], 'newRegister': window['x169'][u[401072]], 'wxPC': window['x169'][u[400960]], 'wxIOS': window['x169'][u[400958]], 'wxAndroid': window['x169'][u[400959]], 'wxParam': { 'limitLoad': window['x169']['x1T$J96'], 'benchmarkLevel': window['x169']['x1T$6J9'], 'wxFrom': window[u[400918]][u[400051]] == u[401210] ? 0x1 : 0x0, 'wxSDKVersion': window[u[401127]] }, 'configType': window['x169'][u[400952]], 'exposeType': window['x169'][u[400954]], 'scene': dnv4ug };new window[u[401207]](uvf, window['x169'][u[400956]], window['x1T$J69']);
    }
  }
}, window['x196$J'] = function () {
  if (window['x19J'] && window['x16J9'] && window[u[400961]] && window[u[400962]] && window['x169J'] && window['x16J'] && window['x1J9'] && window['x1J6']) {
    x1$69J();if (!x19J6) {
      x19J6 = !![];if (!window[u[401207]][u[400980]]) window['x19J6$']();var dcjnvu = 0x0,
          u4vgdn = wx[u[401211]]();u4vgdn && (window['x169'][u[401212]] && (dcjnvu = u4vgdn[u[401213]]), console[u[400983]](u[401214] + u4vgdn[u[401213]] + u[401215] + u4vgdn[u[401216]] + u[401217] + u4vgdn[u[401218]] + u[401219] + u4vgdn[u[401220]] + u[401221] + u4vgdn[u[401222]] + u[401223] + u4vgdn[u[401224]]));var eap0hb = {};for (const t31wb in x169[u[400945]]) {
        eap0hb[t31wb] = x169[u[400945]][t31wb];
      }var w31kt6 = { 'channel': window['x169'][u[400944]], 'account': window['x169'][u[400995]], 'userId': window['x169'][u[401060]], 'cdn': window['x169'][u[400996]], 'data': window['x169'][u[400335]], 'package': window['x169'][u[400304]], 'newRegister': window['x169'][u[401072]], 'pkgName': window['x169'][u[400939]], 'partnerId': window['x169'][u[400938]], 'platform_uid': window['x169'][u[401062]], 'deviceId': window['x169'][u[400940]], 'selectedServer': eap0hb, 'configType': window['x169'][u[400952]], 'exposeType': window['x169'][u[400954]], 'debugUsers': window['x169'][u[400948]], 'wxMenuTop': dcjnvu, 'wxShield': window['x169'][u[400957]] };if (window[u[401092]]) for (var jcunf in window[u[401092]]) {
        w31kt6[jcunf] = window[u[401092]][jcunf];
      }window[u[401207]][u[400980]]['x196T'](w31kt6);
    }
  } else console[u[400983]](u[401225] + window['x19J'] + u[401226] + window['x16J9'] + u[401227] + window[u[400961]] + u[401228] + window[u[400962]] + u[401229] + window['x169J'] + u[401230] + window['x16J'] + u[401231] + window['x1J9'] + u[401232] + window['x1J6']);
};