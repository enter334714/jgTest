var u = wx.$x;
module.exports = {
  //环境参数
  appid: "wxfe0dede5698c6666", //小程序appid
  env: 'develop', //配置环境,正式release,开发 develop,开发环境打印日志
  //请求域名,确保做好解析和添加白名单
  url: 'https://cps.moyangmoyang.com' //必须要填完整域名，域名范例 https://aaa.bbbbb.com
};