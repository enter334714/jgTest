var u = wx.$x;
console[u[400983]](u[401233]), window[u[401234]], wx[u[401235]](function (w1t3b) {
  if (w1t3b) {
    if (w1t3b[u[400056]]) {
      var ism4gx = window[u[400918]][u[400919]][u[400243]](new RegExp(/\./, 'g'), '_'),
          gvdix = w1t3b[u[400056]],
          ismzx = gvdix[u[400067]](/(xxxxxxxxx\/xxGAMEx.js:)[0-9]{1,60}(:)/g);if (ismzx) for (var a0phb = 0x0; a0phb < ismzx[u[400031]]; a0phb++) {
        if (ismzx[a0phb] && ismzx[a0phb][u[400031]] > 0x0) {
          var dv4ig = parseInt(ismzx[a0phb][u[400243]](u[401236], '')[u[400243]](':', ''));gvdix = gvdix[u[400243]](ismzx[a0phb], ismzx[a0phb][u[400243]](':' + dv4ig + ':', ':' + (dv4ig - 0x2) + ':'));
        }
      }gvdix = gvdix[u[400243]](new RegExp(u[401237], 'g'), u[401238] + ism4gx + u[401239]), gvdix = gvdix[u[400243]](new RegExp(u[401240], 'g'), u[401238] + ism4gx + u[401239]), w1t3b[u[400056]] = gvdix;
    }var ujcvd = { 'id': window['x169'][u[400992]], 'role': window['x169'][u[400993]], 'level': window['x169'][u[400994]], 'user': window['x169'][u[400995]], 'version': window['x169'][u[400956]], 'cdn': window['x169'][u[400996]], 'pkgName': window['x169'][u[400939]], 'gamever': window[u[400918]][u[400919]], 'serverid': window['x169'][u[400945]] ? window['x169'][u[400945]][u[400997]] : 0x0, 'systemInfo': window[u[400998]], 'error': u[401241], 'stack': w1t3b ? w1t3b[u[400056]] : '' },
        t5oz2 = JSON[u[401000]](ujcvd);console[u[400333]](u[401242] + t5oz2), (!window[u[401234]] || window[u[401234]] != ujcvd[u[400333]]) && (window[u[401234]] = ujcvd[u[400333]], window['x1$6'](ujcvd));
  }
});import 'xxfxx.js';import 'xx11xx.js';window[u[401243]] = require(u[401244]);import 'xINDxx.js';import 'xxIB1xx.js';import 'xxMtadxx.js';import 'xxINIxxx.js';console[u[400983]](u[401245]), console[u[400983]](u[401246]), x1$6J9({ 'title': u[401247] });var xjfunv = { 'x1T$96J': !![] };new window[u[400979]](xjfunv), window[u[400979]][u[400980]]['x1TJ69$']();if (window['x1T$69J']) clearInterval(window['x1T$69J']);window['x1T$69J'] = null, window['x1TJ9$6'] = function (hqrp_a, gnvju) {
  if (!hqrp_a || !gnvju) return 0x0;hqrp_a = hqrp_a[u[400201]]('.'), gnvju = gnvju[u[400201]]('.');const ivd4 = Math[u[400301]](hqrp_a[u[400031]], gnvju[u[400031]]);while (hqrp_a[u[400031]] < ivd4) {
    hqrp_a[u[400066]]('0');
  }while (gnvju[u[400031]] < ivd4) {
    gnvju[u[400066]]('0');
  }for (var t3b1w = 0x0; t3b1w < ivd4; t3b1w++) {
    const imo = parseInt(hqrp_a[t3b1w]),
          qap_r = parseInt(gnvju[t3b1w]);if (imo > qap_r) return 0x1;else {
      if (imo < qap_r) return -0x1;
    }
  }return 0x0;
}, window[u[401127]] = wx[u[401248]]()[u[401127]], console[u[400225]](u[401249] + window[u[401127]]);var xhkbp0e = wx[u[401250]]();xhkbp0e[u[401251]](function (zsxoim) {
  console[u[400225]](u[401252] + zsxoim[u[401253]]);
}), xhkbp0e[u[401254]](function () {
  wx[u[400965]]({ 'title': u[401255], 'content': u[401256], 'showCancel': ![], 'success': function (u9cj) {
      xhkbp0e[u[401257]]();
    } });
}), xhkbp0e[u[401258]](function () {
  console[u[400225]](u[401259]);
}), window['x1TJ96$'] = function () {
  console[u[400225]](u[401260]);var i4xvd = wx[u[401261]]({ 'name': u[401262], 'success': function (imxosz) {
      console[u[400225]](u[401263]), console[u[400225]](imxosz), imxosz && imxosz[u[401046]] == u[401264] ? (window['x19J'] = !![], window['x19J6$'](), window['x196$J']()) : setTimeout(function () {
        window['x1TJ96$']();
      }, 0x1f4);
    }, 'fail': function (sxiozm) {
      console[u[400225]](u[401265]), console[u[400225]](sxiozm), setTimeout(function () {
        window['x1TJ96$']();
      }, 0x1f4);
    } });i4xvd && i4xvd[u[401266]](udjvc => {});
}, window['x1T6$9J'] = function () {
  console[u[400225]](u[401267]);var zo5s2m = wx[u[401261]]({ 'name': u[401268], 'success': function (nu4gvd) {
      console[u[400225]](u[401269]), console[u[400225]](nu4gvd), nu4gvd && nu4gvd[u[401046]] == u[401264] ? (window['x16J9'] = !![], window['x19J6$'](), window['x196$J']()) : setTimeout(function () {
        window['x1T6$9J']();
      }, 0x1f4);
    }, 'fail': function (unjdc) {
      console[u[400225]](u[401270]), console[u[400225]](unjdc), setTimeout(function () {
        window['x1T6$9J']();
      }, 0x1f4);
    } });zo5s2m && zo5s2m[u[401266]](uivg4 => {});
}, window[u[401271]] = function () {
  window['x1TJ9$6'](window[u[401127]], u[401272]) >= 0x0 ? (console[u[400225]](u[401273] + window[u[401127]] + u[401274]), window['x16$'](), window['x1TJ96$'](), window['x1T6$9J']()) : (window['x169$'](u[401275], window[u[401127]]), wx[u[400965]]({ 'title': u[400966], 'content': u[401276] }));
}, window[u[400998]] = '', wx[u[401277]]({ 'success'(bw03k1) {
    window[u[400998]] = u[401278] + bw03k1[u[401279]] + u[401280] + bw03k1[u[401281]] + u[401282] + bw03k1[u[400925]] + u[401283] + bw03k1[u[401284]] + u[401285] + bw03k1[u[401061]] + u[401286] + bw03k1[u[401127]] + u[401287] + bw03k1[u[401288]], console[u[400225]](window[u[400998]]), console[u[400225]](u[401289] + bw03k1[u[401290]] + u[401291] + bw03k1[u[401292]] + u[401293] + bw03k1[u[401294]] + u[401295] + bw03k1[u[401296]] + u[401297] + bw03k1[u[401298]] + u[401299] + bw03k1[u[401300]] + u[401301] + (bw03k1[u[401302]] ? bw03k1[u[401302]][u[401213]] + ',' + bw03k1[u[401302]][u[401216]] + ',' + bw03k1[u[401302]][u[401218]] + ',' + bw03k1[u[401302]][u[401220]] : ''));var ab0 = bw03k1[u[401284]] ? bw03k1[u[401284]][u[400103]]() : '',
        xm5sz = bw03k1[u[401281]] ? bw03k1[u[401281]][u[400103]]()[u[400243]]('\x20', '') : '';window['x169'][u[400958]] = ab0[u[400146]](u[401303]) != -0x1, window['x169'][u[400959]] = ab0[u[400146]](u[401304]) != -0x1, window['x169'][u[401212]] = ab0[u[400146]](u[401303]) != -0x1 || ab0[u[400146]](u[401304]) != -0x1, window['x169'][u[400960]] = ab0[u[400146]](u[401305]) != -0x1 || ab0[u[400146]](u[400927]) != -0x1, window['x169'][u[401006]] = bw03k1[u[401061]] ? bw03k1[u[401061]][u[400103]]() : '', window['x169']['x1T$J96'] = ![], window['x169']['x1T$6J9'] = 0x2;if (ab0[u[400146]](u[401304]) != -0x1) {
      if (bw03k1[u[401288]] >= 0x18) window['x169']['x1T$6J9'] = 0x3;else window['x169']['x1T$6J9'] = 0x2;
    } else {
      if (ab0[u[400146]](u[401303]) != -0x1) {
        if (bw03k1[u[401288]] && bw03k1[u[401288]] >= 0x14) window['x169']['x1T$6J9'] = 0x3;else {
          if (xm5sz[u[400146]](u[401306]) != -0x1 || xm5sz[u[400146]](u[401307]) != -0x1 || xm5sz[u[400146]](u[401308]) != -0x1 || xm5sz[u[400146]](u[401309]) != -0x1 || xm5sz[u[400146]](u[401310]) != -0x1) window['x169']['x1T$6J9'] = 0x2;else window['x169']['x1T$6J9'] = 0x3;
        }
      } else window['x169']['x1T$6J9'] = 0x2;
    }console[u[400225]](u[401311] + window['x169']['x1T$J96'] + u[401312] + window['x169']['x1T$6J9']);
  } }), wx[u[401146]]({ 'success': function (e_hpa) {
    console[u[400225]](u[401313] + e_hpa[u[401148]] + u[401314] + e_hpa[u[401150]]);
  } }), wx[u[401315]]({ 'success': function (lcj79) {
    console[u[400225]](u[401316] + lcj79[u[401317]]);
  } }), wx[u[401318]]({ 'keepScreenOn': !![] }), wx[u[401319]](function (mzosxi) {
  console[u[400225]](u[401316] + mzosxi[u[401317]] + u[401320] + mzosxi[u[401321]]);
}), wx[u[401121]](function (ehq_p) {
  window['x1J$'] = ehq_p, window['x19$J'] && window['x1J$'] && (console[u[400983]](u[401122] + window['x1J$'][u[401123]]), window['x19$J'](window['x1J$']), window['x1J$'] = null);
}), window[u[401322]] = 0x0, window['x1T6J9$'] = 0x0, window[u[401323]] = null, wx[u[401324]](function () {
  window['x1T6J9$']++;var c7l9 = Date[u[400951]]();(window[u[401322]] == 0x0 || c7l9 - window[u[401322]] > 0x1d4c0) && (console[u[400383]](u[401325]), wx[u[401326]]());if (window['x1T6J9$'] >= 0x2) {
    window['x1T6J9$'] = 0x0, console[u[400333]](u[401327]), wx[u[401328]]('0', 0x1);if (window['x169'] && window['x169'][u[400958]]) window['x169$'](u[401329], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});