var v = wx.$d;
import zkuqg from '../dddk/dddsdk.js';window[v[0x7809]] = { 'wxVersion': window[v[0x22e]][v[0x77a9]] }, window[v[0x780a]] = ![], window['D$ZL'] = 0x1, window[v[0x780b]] = 0x1, window['D$ALZ'] = !![], window[v[0x780c]] = !![], window['D$YSALZ'] = '', window[v[0x780d]] = ![], window['D$LZ'] = { 'base_cdn': v[0x780e], 'cdn': v[0x780e] }, D$LZ[v[0x780f]] = {}, D$LZ[v[0x6488]] = '0', D$LZ[v[0x1341]] = window[v[0x7809]][v[0x7810]], D$LZ[v[0x7673]] = '', D$LZ['os'] = '1', D$LZ[v[0x7811]] = v[0x7812], D$LZ[v[0x7813]] = v[0x7814], D$LZ[v[0x7815]] = v[0x7816], D$LZ[v[0x7817]] = v[0x7818], D$LZ[v[0x7819]] = v[0x781a], D$LZ[v[0x5f18]] = '1', D$LZ[v[0x65bc]] = '', D$LZ[v[0x65be]] = '', D$LZ[v[0x781b]] = 0x0, D$LZ[v[0x781c]] = {}, D$LZ[v[0x781d]] = parseInt(D$LZ[v[0x5f18]]), D$LZ[v[0x65ba]] = D$LZ[v[0x5f18]], D$LZ[v[0x65b6]] = {}, D$LZ['D$SL'] = v[0x781e], D$LZ[v[0x781f]] = ![], D$LZ[v[0x3168]] = v[0x7820], D$LZ[v[0x659a]] = Date[v[0x53]](), D$LZ[v[0x2fd5]] = v[0x7821], D$LZ[v[0x2e1]] = '_a', D$LZ[v[0x7822]] = 0x2, D$LZ[v[0x65]] = 0x7c1, D$LZ[v[0x7810]] = window[v[0x7809]][v[0x7810]], D$LZ[v[0x2f9]] = ![], D$LZ[v[0x44a]] = ![], D$LZ[v[0x2d73]] = ![], D$LZ[v[0x648a]] = ![], window['D$AZL'] = 0x5, window['D$AZ'] = ![], window['D$ZA'] = ![], window['D$LAZ'] = ![], window[v[0x7823]] = ![], window[v[0x7824]] = ![], window['D$LZA'] = ![], window['D$AL'] = ![], window['D$LA'] = ![], window['D$ZAL'] = ![], window[v[0x7825]] = null, window[v[0x27f]] = function (yp7vl) {
  console[v[0x1e2]](v[0x27f], yp7vl), wx[v[0x145a]]({}), wx[v[0x77c1]]({ 'title': v[0x19c7], 'content': yp7vl, 'success'(pr8$) {
      if (pr8$[v[0x7826]]) console[v[0x1e2]](v[0x7827]);else pr8$[v[0x22a]] && console[v[0x1e2]](v[0x770c]);
    } });
}, window['D$SALZ'] = function (mnhe6) {
  console[v[0x1e2]](v[0x7828], mnhe6), D$SLZA(), wx[v[0x77c1]]({ 'title': v[0x19c7], 'content': mnhe6, 'confirmText': v[0x7829], 'cancelText': v[0x4ab4], 'success'(aq0g) {
      if (aq0g[v[0x7826]]) window['D$LS']();else aq0g[v[0x22a]] && (console[v[0x1e2]](v[0x782a]), wx[v[0x6486]]({}));
    } });
}, window[v[0x782b]] = function (_394nc) {
  console[v[0x1e2]](v[0x782b], _394nc), wx[v[0x77c1]]({ 'title': v[0x19c7], 'content': _394nc, 'confirmText': v[0x663d], 'showCancel': ![], 'complete'(_hj4) {
      console[v[0x1e2]](v[0x782a]), wx[v[0x6486]]({});
    } });
}, window['D$SAZL'] = ![], window['D$SLAZ'] = function (hmn6j) {
  window['D$SAZL'] = !![], wx[v[0x1459]](hmn6j);
}, window['D$SLZA'] = function () {
  window['D$SAZL'] && (window['D$SAZL'] = ![], wx[v[0x145a]]({}));
}, window['D$SZAL'] = function (rv7$pw) {
  window[v[0x77b8]][v[0x94]]['D$SZAL'](rv7$pw);
}, window[v[0x30e6]] = function (igufk, iue6d) {
  zkuqg[v[0x30e6]](igufk, function (h9n_4j) {
    h9n_4j && h9n_4j[v[0xb]] ? h9n_4j[v[0xb]][v[0x4d0]] == 0x1 ? iue6d(!![]) : (iue6d(![]), console[v[0x4e]](v[0x782c] + h9n_4j[v[0xb]][v[0x782d]])) : console[v[0x1e2]](v[0x30e6], h9n_4j);
  });
}, window['D$SZLA'] = function (qza0) {
  console[v[0x1e2]](v[0x782e], qza0);
}, window['D$SLZ'] = function (rv$p1) {}, window['D$SZL'] = function (xrb8a1, x1w8br, n43_9) {}, window['D$SZ'] = function (q0zga) {
  console[v[0x1e2]](v[0x782f], q0zga), window[v[0x77b8]][v[0x94]][v[0x7830]](), window[v[0x77b8]][v[0x94]][v[0x7831]](), window[v[0x77b8]][v[0x94]][v[0x7832]]();
}, window['D$ZS'] = function (ugkti) {
  window[v[0x7833]](0xe, v[0x7834] + ugkti), window['D$SALZ'](v[0x7835]);var bz0agq = { 'id': window['D$LZ'][v[0x77ae]], 'role': window['D$LZ'][v[0x12f9]], 'level': window['D$LZ'][v[0x77af]], 'account': window['D$LZ'][v[0x65bb]], 'version': window['D$LZ'][v[0x65]], 'cdn': window['D$LZ'][v[0x127e]], 'pkgName': window['D$LZ'][v[0x65bc]], 'gamever': window[v[0x22e]][v[0x77a9]], 'serverid': window['D$LZ'][v[0x65b6]] ? window['D$LZ'][v[0x65b6]][v[0x2e25]] : 0x0, 'systemInfo': window[v[0x77b0]], 'error': v[0x7836], 'stack': ugkti ? ugkti : v[0x7835] },
      $p1rw8 = JSON[v[0x1270]](bz0agq);console[v[0x7d]](v[0x7837] + $p1rw8), window['D$SL']($p1rw8);
}, window[v[0x7833]] = function (q0fg, gt0qk) {
  sendApi(D$LZ[v[0x7815]], v[0x7838], { 'game_pkg': D$LZ[v[0x65bc]], 'partner_id': D$LZ[v[0x5f18]], 'server_id': D$LZ[v[0x65b6]] && D$LZ[v[0x65b6]][v[0x2e25]] > 0x0 ? D$LZ[v[0x65b6]][v[0x2e25]] : 0x0, 'uid': D$LZ[v[0x65bb]] > 0x0 ? D$LZ[v[0x65bb]] : 0x0, 'type': q0fg, 'info': gt0qk });
}, window['D$LSZ'] = function (n43_j9) {
  var de6hjm = JSON[v[0x20e]](n43_j9);de6hjm[v[0x7839]] = window[v[0x22e]][v[0x77a9]], de6hjm[v[0x783a]] = window['D$LZ'][v[0x65b6]] ? window['D$LZ'][v[0x65b6]][v[0x2e25]] : 0x0, de6hjm[v[0x77b0]] = window[v[0x77b0]];var e6dj = JSON[v[0x1270]](de6hjm);console[v[0x7d]](v[0x783b] + e6dj), window['D$SL'](e6dj);
}, window['D$LZS'] = function (_43oc9, oc3_) {
  var hj6_ = { 'id': window['D$LZ'][v[0x77ae]], 'role': window['D$LZ'][v[0x12f9]], 'level': window['D$LZ'][v[0x77af]], 'account': window['D$LZ'][v[0x65bb]], 'version': window['D$LZ'][v[0x65]], 'cdn': window['D$LZ'][v[0x127e]], 'pkgName': window['D$LZ'][v[0x65bc]], 'gamever': window[v[0x22e]][v[0x77a9]], 'serverid': window['D$LZ'][v[0x65b6]] ? window['D$LZ'][v[0x65b6]][v[0x2e25]] : 0x0, 'systemInfo': window[v[0x77b0]], 'error': _43oc9, 'stack': oc3_ },
      uigfkt = JSON[v[0x1270]](hj6_);console[v[0x60]](v[0x783c] + uigfkt), window['D$SL'](uigfkt);
}, window['D$SL'] = function (uedf) {
  if (window['D$LZ'][v[0x77f1]] == v[0x783d]) return;var gzbqa0 = D$LZ['D$SL'] + v[0x783e] + D$LZ[v[0x65bb]];wx[v[0x1dd]]({ 'url': gzbqa0, 'method': v[0x7767], 'data': uedf, 'header': { 'content-type': v[0x783f], 'cache-control': v[0x7840] }, 'success': function (y7l$p) {
      DEBUG && console[v[0x1e2]](v[0x7841], gzbqa0, uedf, y7l$p);
    }, 'fail': function (_6njh) {
      DEBUG && console[v[0x1e2]](v[0x7841], gzbqa0, uedf, _6njh);
    }, 'complete': function () {} });
}, window[v[0x7842]] = function () {
  function v$p7ly() {
    return ((0x1 + Math[v[0x77]]()) * 0x10000 | 0x0)[v[0x10e]](0x10)[v[0x1f1]](0x1);
  }return v$p7ly() + v$p7ly() + '-' + v$p7ly() + '-' + v$p7ly() + '-' + v$p7ly() + '+' + v$p7ly() + v$p7ly() + v$p7ly();
}, window['D$LS'] = function () {
  console[v[0x1e2]](v[0x7843]);var wr1$vp = zkuqg[v[0x7844]]();D$LZ[v[0x65ba]] = wr1$vp[v[0x7845]], D$LZ[v[0x781d]] = wr1$vp[v[0x7845]], D$LZ[v[0x5f18]] = wr1$vp[v[0x7845]], D$LZ[v[0x65bc]] = wr1$vp[v[0x7846]];var j4nm6h = { 'game_ver': D$LZ[v[0x1341]] };D$LZ[v[0x65be]] = this[v[0x7842]](), D$SLAZ({ 'title': v[0x7847] }), zkuqg[v[0x16b]](j4nm6h, this['D$ZSL'][v[0x4a]](this));
}, window['D$ZSL'] = function (xqz0b) {
  var nhem = xqz0b[v[0x7848]];sdkInitRes = xqz0b, console[v[0x1e2]](v[0x7849] + nhem + v[0x784a] + (nhem == 0x1) + v[0x784b] + xqz0b[v[0x77a9]] + v[0x784c] + window[v[0x7809]][v[0x7810]]);if (!xqz0b[v[0x77a9]] || window['D$YAZSL'](window[v[0x7809]][v[0x7810]], xqz0b[v[0x77a9]]) < 0x0) console[v[0x1e2]](v[0x784d]), D$LZ[v[0x7813]] = v[0x784e], D$LZ[v[0x7815]] = v[0x784f], D$LZ[v[0x7817]] = v[0x7850], D$LZ[v[0x127e]] = v[0x7851], D$LZ[v[0x6487]] = v[0x7852], D$LZ[v[0x7853]] = 'fj', D$LZ[v[0x2f9]] = ![];else window['D$YAZSL'](window[v[0x7809]][v[0x7810]], xqz0b[v[0x77a9]]) == 0x0 ? (console[v[0x1e2]](v[0x7854]), D$LZ[v[0x7813]] = v[0x7814], D$LZ[v[0x7815]] = v[0x7816], D$LZ[v[0x7817]] = v[0x7818], D$LZ[v[0x127e]] = v[0x7855], D$LZ[v[0x6487]] = v[0x7852], D$LZ[v[0x7853]] = v[0x7856], D$LZ[v[0x2f9]] = !![]) : (console[v[0x1e2]](v[0x7857]), D$LZ[v[0x7813]] = v[0x7814], D$LZ[v[0x7815]] = v[0x7816], D$LZ[v[0x7817]] = v[0x7818], D$LZ[v[0x127e]] = v[0x7855], D$LZ[v[0x6487]] = v[0x7852], D$LZ[v[0x7853]] = v[0x7856], D$LZ[v[0x2f9]] = ![]);D$LZ[v[0x781b]] = config[v[0x75ed]] ? config[v[0x75ed]] : 0x0, this['D$ALSZ'](), this['D$ALZS'](), window[v[0x7858]] = 0x5, D$SLAZ({ 'title': v[0x7859] }), zkuqg[v[0x76c6]](this['D$ZLS'][v[0x4a]](this));
}, window[v[0x7858]] = 0x5, window['D$ZLS'] = function (giuftk, ifteud) {
  if (giuftk == 0x0 && ifteud && ifteud[v[0x7649]]) {
    D$LZ[v[0x785a]] = ifteud[v[0x7649]];var hj4n_6 = this;D$SLAZ({ 'title': v[0x785b] }), sendApi(D$LZ[v[0x7813]], v[0x785c], { 'platform': D$LZ[v[0x7811]], 'partner_id': D$LZ[v[0x5f18]], 'token': ifteud[v[0x7649]], 'game_pkg': D$LZ[v[0x65bc]], 'deviceId': D$LZ[v[0x65be]], 'scene': v[0x785d] + D$LZ[v[0x781b]] }, this['D$ASLZ'][v[0x4a]](this), D$AZL, D$ZS);
  } else ifteud && ifteud[v[0x667d]] && window[v[0x7858]] > 0x0 && (ifteud[v[0x667d]][v[0x73]](v[0x785e]) != -0x1 || ifteud[v[0x667d]][v[0x73]](v[0x785f]) != -0x1 || ifteud[v[0x667d]][v[0x73]](v[0x7860]) != -0x1 || ifteud[v[0x667d]][v[0x73]](v[0x7861]) != -0x1 || ifteud[v[0x667d]][v[0x73]](v[0x7862]) != -0x1 || ifteud[v[0x667d]][v[0x73]](v[0x7863]) != -0x1) ? (window[v[0x7858]]--, zkuqg[v[0x76c6]](this['D$ZLS'][v[0x4a]](this))) : (window[v[0x7833]](0x1, v[0x7864] + giuftk + v[0x7865] + (ifteud ? ifteud[v[0x667d]] : '')), window['D$LZS'](v[0x7866], JSON[v[0x1270]]({ 'status': giuftk, 'data': ifteud })), window['D$SALZ'](v[0x7867] + (ifteud && ifteud[v[0x667d]] ? '，' + ifteud[v[0x667d]] : '')));
}, window['D$ASLZ'] = function (r81xwb) {
  if (!r81xwb) {
    window[v[0x7833]](0x2, v[0x7868]), window['D$LZS'](v[0x7869], v[0x786a]), window['D$SALZ'](v[0x786b]);return;
  }if (r81xwb[v[0x4d0]] != v[0x27ca]) {
    window[v[0x7833]](0x2, v[0x786c] + r81xwb[v[0x4d0]]), window['D$LZS'](v[0x7869], JSON[v[0x1270]](r81xwb)), window['D$SALZ'](v[0x786d] + r81xwb[v[0x4d0]]);return;
  }D$LZ[v[0x4c2f]] = String(r81xwb[v[0x65bb]]), D$LZ[v[0x65bb]] = String(r81xwb[v[0x65bb]]), D$LZ[v[0x6598]] = String(r81xwb[v[0x6598]]), D$LZ[v[0x65ba]] = String(r81xwb[v[0x6598]]), D$LZ[v[0x65bd]] = String(r81xwb[v[0x65bd]]), D$LZ[v[0x786e]] = String(r81xwb[v[0x2e14]]), D$LZ[v[0x786f]] = String(r81xwb[v[0x36a]]), D$LZ[v[0x2e14]] = '';var rvw$1 = this;D$SLAZ({ 'title': v[0x7870] });var mdeui6 = localStorage[v[0x1e0]](v[0x7871] + D$LZ[v[0x65bc]] + D$LZ[v[0x65bb]]);if (mdeui6 && mdeui6 != '') {
    var _c5o39 = Number(mdeui6);rvw$1[v[0x7872]](_c5o39);
  } else rvw$1[v[0x7873]]();
}, window[v[0x7873]] = function () {
  var _c349o = this;sendApi(D$LZ[v[0x7813]], v[0x7874], { 'partner_id': D$LZ[v[0x5f18]], 'uid': D$LZ[v[0x65bb]], 'version': D$LZ[v[0x1341]], 'game_pkg': D$LZ[v[0x65bc]], 'device': D$LZ[v[0x65be]] }, _c349o['D$ASZL'][v[0x4a]](_c349o), D$AZL, D$ZS);
}, window['D$ASZL'] = function (igktuf) {
  if (!igktuf) {
    window[v[0x7833]](0x3, v[0x7875]), window['D$SALZ'](v[0x7875]);return;
  }if (igktuf[v[0x4d0]] != v[0x27ca]) {
    window[v[0x7833]](0x3, v[0x7876] + igktuf[v[0x4d0]]), window['D$SALZ'](v[0x7876] + igktuf[v[0x4d0]]);return;
  }if (!igktuf[v[0xb]] || igktuf[v[0xb]][v[0xd]] == 0x0) {
    window[v[0x7833]](0x3, v[0x7877]), window['D$SALZ'](v[0x7878]);return;
  }this[v[0x7879]](igktuf);
}, window[v[0x7872]] = function (zab0x8) {
  var $7wrpv = this;sendApi(D$LZ[v[0x7813]], v[0x787a], { 'server_id': zab0x8, 'time': Date[v[0x53]]() / 0x3e8 }, $7wrpv[v[0x787b]][v[0x4a]]($7wrpv), D$AZL, D$ZS);
}, window[v[0x787b]] = function (c95o23) {
  if (!c95o23) {
    window[v[0x7833]](0x4, v[0x787c]), this[v[0x7873]]();return;
  }if (c95o23[v[0x4d0]] != v[0x27ca]) {
    window[v[0x7833]](0x4, v[0x787d] + c95o23[v[0x4d0]]), this[v[0x7873]]();return;
  }if (!c95o23[v[0xb]] || c95o23[v[0xb]][v[0xd]] == 0x0) {
    window[v[0x7833]](0x4, v[0x787e]), this[v[0x7873]]();return;
  }this[v[0x7879]](c95o23), window[v[0x77b8]] && window[v[0x77b8]][v[0x94]][v[0x787f]] && window[v[0x77b8]][v[0x94]][v[0x787f]](sdkInitRes[v[0x7880]], sdkInitRes[v[0x7881]], sdkInitRes[v[0x7882]], sdkInitRes[v[0x7883]], sdkInitRes[v[0x7884]]);
}, window[v[0x7879]] = function (fugikt) {
  D$LZ[v[0x289]] = fugikt[v[0x7885]] != undefined ? fugikt[v[0x7885]] : 0x0, D$LZ[v[0x65b6]] = { 'server_id': String(fugikt[v[0xb]][0x0][v[0x2e25]]), 'server_name': String(fugikt[v[0xb]][0x0][v[0x7886]]), 'entry_ip': fugikt[v[0xb]][0x0][v[0x65d2]], 'entry_port': parseInt(fugikt[v[0xb]][0x0][v[0x65d3]]), 'status': D$LAS(fugikt[v[0xb]][0x0]), 'start_time': fugikt[v[0xb]][0x0][v[0x7887]], 'cdn': D$LZ[v[0x127e]] }, this['D$ZLAS']();
}, window[v[0x7888]] = null, window['D$ZLAS'] = function () {
  var b0x8a = this;zkuqg[v[0x779e]](function (gfkutq) {
    console[v[0x1e2]](v[0x7889] + JSON[v[0x1270]](gfkutq)), youYiCofig = gfkutq;window[v[0x7888]][v[0x788a]] == 0x1 && (D$LZ[v[0x289]] = 0x0);if (D$LZ[v[0x289]] == 0x1) {
      var kzgfq = D$LZ[v[0x65b6]][v[0x6a]];if (kzgfq === -0x1 || kzgfq === 0x0) {
        window[v[0x7833]](0xf, v[0x788b] + D$LZ[v[0x65b6]]['id'] + v[0x788c] + D$LZ[v[0x65b6]][v[0x6a]]), window['D$SALZ'](kzgfq === -0x1 ? v[0x788d] : v[0x788e]);return;
      }D$ZSAL(0x0, D$LZ[v[0x65b6]][v[0x2e25]]), window[v[0x77b8]][v[0x94]][v[0x788f]](D$LZ[v[0x289]]);
    } else window[v[0x77b8]][v[0x94]][v[0x7890]](() => {
      var y$pv = window[v[0x7888]][v[0x7891]],
          fgu = window[v[0x7888]][v[0x788a]] == 0x1;fgu && window[v[0x77b8]][v[0x94]][v[0x7892]](v[0x7893], y$pv, v[0x7894]);
    }, b0x8a), D$SLZA();window['D$LA'] = !![], window['D$ZALS'](), window['D$ZLSA']();
  });
}, window[v[0x7895]] = function () {
  zkuqg[v[0x779f]](function ($yv7) {
    console[v[0x1e2]](v[0x7896] + JSON[v[0x1270]]($yv7));
  });
}, window['D$ALSZ'] = function () {
  sendApi(D$LZ[v[0x7813]], v[0x7897], { 'game_pkg': D$LZ[v[0x65bc]], 'version_name': D$LZ[v[0x7853]] }, this[v[0x7898]][v[0x4a]](this), D$AZL, D$ZS);
}, window[v[0x7898]] = function (idufk) {
  if (!idufk) {
    window[v[0x7833]](0x5, v[0x7899]), window['D$SALZ'](v[0x7899]);return;
  }if (idufk[v[0x4d0]] != v[0x27ca]) {
    window[v[0x7833]](0x5, v[0x789a] + idufk[v[0x4d0]]), window['D$SALZ'](v[0x789a] + idufk[v[0x4d0]]);return;
  }if (!idufk[v[0xb]] || !idufk[v[0xb]][v[0x1341]]) {
    window[v[0x7833]](0x5, v[0x789b] + (idufk[v[0xb]] && idufk[v[0xb]][v[0x1341]])), window['D$SALZ'](v[0x789b] + (idufk[v[0xb]] && idufk[v[0xb]][v[0x1341]]));return;
  }idufk[v[0xb]][v[0x789c]] && idufk[v[0xb]][v[0x789c]][v[0xd]] > 0xa && (D$LZ[v[0x789d]] = idufk[v[0xb]][v[0x789c]], D$LZ[v[0x127e]] = idufk[v[0xb]][v[0x789c]]), idufk[v[0xb]][v[0x1341]] && (D$LZ[v[0x65]] = idufk[v[0xb]][v[0x1341]]), console[v[0x4e]](v[0x6643] + D$LZ[v[0x65]] + v[0x789e] + D$LZ[v[0x7853]]), window['D$LZA'] = !![], window['D$ZALS'](), window['D$ZLSA']();
}, window[v[0x789f]], window['D$ALZS'] = function () {
  sendApi(D$LZ[v[0x7813]], v[0x78a0], { 'game_pkg': D$LZ[v[0x65bc]] }, this['D$AZSL'][v[0x4a]](this), D$AZL, D$ZS);
}, window['D$AZSL'] = function (qa0x) {
  if (qa0x && qa0x[v[0x4d0]] === v[0x27ca] && qa0x[v[0xb]]) {
    window[v[0x789f]] = qa0x[v[0xb]];for (var bx1rw in qa0x[v[0xb]]) {
      D$LZ[bx1rw] = qa0x[v[0xb]][bx1rw];
    }
  } else window[v[0x7833]](0xb, v[0x78a1]), console[v[0x4e]](v[0x78a2] + qa0x[v[0x4d0]]);window['D$AL'] = !![], window['D$ZLSA']();
}, window[v[0x78a3]] = function (ktfgu, idktfu, pl$y, wrx$81, m46jhn, fgtkiu, kqfz0g, duteif, gtkq, mj4n6) {
  m46jhn = String(m46jhn);var dietm = kqfz0g,
      _46nhj = duteif;D$LZ[v[0x780f]][m46jhn] = { 'productid': m46jhn, 'productname': dietm, 'productdesc': _46nhj, 'roleid': ktfgu, 'rolename': idktfu, 'rolelevel': pl$y, 'price': fgtkiu, 'callback': gtkq }, sendApi(D$LZ[v[0x7817]], v[0x78a4], { 'game_pkg': D$LZ[v[0x65bc]], 'server_id': D$LZ[v[0x65b6]][v[0x2e25]], 'server_name': D$LZ[v[0x65b6]][v[0x7886]], 'level': pl$y, 'uid': D$LZ[v[0x65bb]], 'role_id': ktfgu, 'role_name': idktfu, 'product_id': m46jhn, 'product_name': dietm, 'product_desc': _46nhj, 'money': fgtkiu, 'partner_id': D$LZ[v[0x5f18]] }, toPayCallBack, D$AZL, D$ZS);
}, window[v[0x78a5]] = function (kfgt) {
  if (kfgt && (kfgt[v[0x78a6]] === 0xc8 || kfgt[v[0x4d0]] == v[0x27ca])) {
    var fgz0q = D$LZ[v[0x780f]][String(kfgt[v[0x78a7]])];if (fgz0q[v[0x14a]]) fgz0q[v[0x14a]](kfgt[v[0x78a7]], kfgt[v[0x78a8]], -0x1);zkuqg[v[0x7780]]({ 'cpbill': kfgt[v[0x78a8]], 'productid': kfgt[v[0x78a7]], 'productname': fgz0q[v[0x78a9]], 'productdesc': fgz0q[v[0x78aa]], 'serverid': D$LZ[v[0x65b6]][v[0x2e25]], 'servername': D$LZ[v[0x65b6]][v[0x7886]], 'roleid': fgz0q[v[0x78ab]], 'rolename': fgz0q[v[0x78ac]], 'rolelevel': fgz0q[v[0x78ad]], 'price': fgz0q[v[0x6cb3]], 'extension': JSON[v[0x1270]]({ 'cp_order_id': kfgt[v[0x78a8]] }) }, function (diemu, xr1w) {
      fgz0q[v[0x14a]] && diemu == 0x0 && fgz0q[v[0x14a]](kfgt[v[0x78a7]], kfgt[v[0x78a8]], diemu);console[v[0x4e]](JSON[v[0x1270]]({ 'type': v[0x78ae], 'status': diemu, 'data': kfgt, 'role_name': fgz0q[v[0x78ac]] }));if (diemu === 0x0) {} else {
        if (diemu === 0x1) {} else {
          if (diemu === 0x2) {}
        }
      }
    });
  } else {
    var aqzgk0 = kfgt ? v[0x78af] + kfgt[v[0x78a6]] + v[0x78b0] + kfgt[v[0x4d0]] + v[0x78b1] + kfgt[v[0x4e]] : v[0x78b2];window[v[0x7833]](0xd, v[0x78b3] + aqzgk0), alert(aqzgk0);
  }
}, window['D$AZLS'] = function () {}, window['D$SAZ'] = function (qgz0ba, zq0kga, d6umi, r8pw$, eiudm6) {
  zkuqg[v[0x77a0]](D$LZ[v[0x65b6]][v[0x2e25]], D$LZ[v[0x65b6]][v[0x7886]] || D$LZ[v[0x65b6]][v[0x2e25]], qgz0ba, zq0kga, d6umi), sendApi(D$LZ[v[0x7813]], v[0x78b4], { 'game_pkg': D$LZ[v[0x65bc]], 'server_id': D$LZ[v[0x65b6]][v[0x2e25]], 'role_id': qgz0ba, 'uid': D$LZ[v[0x65bb]], 'role_name': zq0kga, 'role_type': r8pw$, 'level': d6umi });
}, window['D$SZA'] = function (rp8w, co32, fuktg, yv$wp7, tieumd, qaxb0z, h4j_n, $wy7v, jnm46, b1ra) {
  D$LZ[v[0x77ae]] = rp8w, D$LZ[v[0x12f9]] = co32, D$LZ[v[0x77af]] = fuktg, zkuqg[v[0x77a1]](D$LZ[v[0x65b6]][v[0x2e25]], D$LZ[v[0x65b6]][v[0x7886]] || D$LZ[v[0x65b6]][v[0x2e25]], rp8w, co32, fuktg), sendApi(D$LZ[v[0x7813]], v[0x78b5], { 'game_pkg': D$LZ[v[0x65bc]], 'server_id': D$LZ[v[0x65b6]][v[0x2e25]], 'role_id': rp8w, 'uid': D$LZ[v[0x65bb]], 'role_name': co32, 'role_type': yv$wp7, 'level': fuktg, 'evolution': tieumd });
}, window['D$ASZ'] = function (b8rx1, z0gaqk, gkufqt, qf0zgk, ueftid, ifdteu, _39nc, y$lpv, kqgzf0, iudtem) {
  D$LZ[v[0x77ae]] = b8rx1, D$LZ[v[0x12f9]] = z0gaqk, D$LZ[v[0x77af]] = gkufqt, zkuqg[v[0x77a2]](D$LZ[v[0x65b6]][v[0x2e25]], D$LZ[v[0x65b6]][v[0x7886]] || D$LZ[v[0x65b6]][v[0x2e25]], b8rx1, z0gaqk, gkufqt), sendApi(D$LZ[v[0x7813]], v[0x78b5], { 'game_pkg': D$LZ[v[0x65bc]], 'server_id': D$LZ[v[0x65b6]][v[0x2e25]], 'role_id': b8rx1, 'uid': D$LZ[v[0x65bb]], 'role_name': z0gaqk, 'role_type': qf0zgk, 'level': gkufqt, 'evolution': ueftid });
}, window['D$AZS'] = function ($rv1pw) {}, window['D$SA'] = function (j_h) {
  zkuqg[v[0x7747]](v[0x7747], function (v$1pr) {
    j_h && j_h(v$1pr);
  });
}, window[v[0x5f16]] = function () {
  zkuqg[v[0x5f16]]();
}, window[v[0x78b6]] = function () {
  zkuqg[v[0x5ea8]]();
}, window[v[0x78b7]] = function (o49c_3, rx8$1w, jh_64, c523o, eud6im, gqutkf, yp7, m6eidh) {
  m6eidh = m6eidh || D$LZ[v[0x65b6]][v[0x2e25]], sendApi(D$LZ[v[0x7813]], v[0x78b8], { 'phone': o49c_3, 'role_id': rx8$1w, 'uid': D$LZ[v[0x65bb]], 'game_pkg': D$LZ[v[0x65bc]], 'partner_id': D$LZ[v[0x5f18]], 'server_id': m6eidh }, yp7, 0x2, null, function () {
    return !![];
  });
}, window[v[0x2b85]] = function (udteif) {
  window['D$ZSA'] = udteif, window['D$ZSA'] && window['D$AS'] && (console[v[0x4e]](v[0x7801] + window['D$AS'][v[0x31f]]), window['D$ZSA'](window['D$AS']), window['D$AS'] = null);
}, window['D$ZAS'] = function (ukgfq, qtgufk, iftd, ukgtf) {
  window[v[0x16]](v[0x78b9], { 'game_pkg': window['D$LZ'][v[0x65bc]], 'role_id': qtgufk, 'server_id': iftd }, ukgtf);
}, window['D$LSAZ'] = function (fqg0t, edmhj6, r$pvw7) {
  function fqzkg0(b0gza) {
    var c9o_43 = [],
        _9 = [],
        gqtf0k = r$pvw7 || window[v[0x22e]][v[0x78ba]];for (var g0fkz in gqtf0k) {
      var ed6hj = Number(g0fkz);(!fqg0t || !fqg0t[v[0xd]] || fqg0t[v[0x73]](ed6hj) != -0x1) && (_9[v[0x1d]](gqtf0k[g0fkz]), c9o_43[v[0x1d]]([ed6hj, 0x3]));
    }window['D$YAZSL'](window[v[0x77b9]], v[0x78bb]) >= 0x0 ? (console[v[0x1e2]](v[0x78bc]), zkuqg[v[0x779b]] && zkuqg[v[0x779b]](_9, function (bxrw1) {
      console[v[0x1e2]](v[0x78bd]), console[v[0x1e2]](bxrw1);if (bxrw1 && bxrw1[v[0x667d]] == v[0x78be]) for (var f0qk in gqtf0k) {
        if (bxrw1[gqtf0k[f0qk]] == v[0x78bf]) {
          var ed6hjm = Number(f0qk);for (var b8x1 = 0x0; b8x1 < c9o_43[v[0xd]]; b8x1++) {
            if (c9o_43[b8x1][0x0] == ed6hjm) {
              c9o_43[b8x1][0x1] = 0x1;break;
            }
          }
        }
      }window['D$YAZSL'](window[v[0x77b9]], v[0x78c0]) >= 0x0 ? wx[v[0x78c1]]({ 'withSubscriptions': !![], 'success': function (oc93_5) {
          var j6n4m = oc93_5[v[0x78c2]][v[0x78c3]];if (j6n4m) {
            console[v[0x1e2]](v[0x78c4]), console[v[0x1e2]](j6n4m);for (var $7wrvp in gqtf0k) {
              if (j6n4m[gqtf0k[$7wrvp]] == v[0x78bf]) {
                var r7$wpv = Number($7wrvp);for (var kufigt = 0x0; kufigt < c9o_43[v[0xd]]; kufigt++) {
                  if (c9o_43[kufigt][0x0] == r7$wpv) {
                    c9o_43[kufigt][0x1] = 0x2;break;
                  }
                }
              }
            }console[v[0x1e2]](c9o_43), edmhj6 && edmhj6(c9o_43);
          } else console[v[0x1e2]](v[0x78c5]), console[v[0x1e2]](oc93_5), console[v[0x1e2]](c9o_43), edmhj6 && edmhj6(c9o_43);
        }, 'fail': function () {
          console[v[0x1e2]](v[0x78c6]), console[v[0x1e2]](c9o_43), edmhj6 && edmhj6(c9o_43);
        } }) : (console[v[0x1e2]](v[0x78c7] + window[v[0x77b9]]), console[v[0x1e2]](c9o_43), edmhj6 && edmhj6(c9o_43));
    })) : (console[v[0x1e2]](v[0x78c8] + window[v[0x77b9]]), console[v[0x1e2]](c9o_43), edmhj6 && edmhj6(c9o_43)), wx[v[0x78c9]](fqzkg0);
  }wx[v[0x78ca]](fqzkg0);
}, window['D$LSZA'] = { 'isSuccess': ![], 'level': v[0x78cb], 'isCharging': ![] }, window['D$LASZ'] = function (yv$wp) {
  wx[v[0x77f9]]({ 'success': function (xbzq0) {
      var w1$ = window['D$LSZA'];w1$[v[0x78cc]] = !![], w1$[v[0x12e1]] = Number(xbzq0[v[0x12e1]])[v[0x1166]](0x0), w1$[v[0x77fc]] = xbzq0[v[0x77fc]], yv$wp && yv$wp(w1$[v[0x78cc]], w1$[v[0x12e1]], w1$[v[0x77fc]]);
    }, 'fail': function (n6_h) {
      console[v[0x1e2]](v[0x78cd], n6_h[v[0x667d]]);var xwrb = window['D$LSZA'];yv$wp && yv$wp(xwrb[v[0x78cc]], xwrb[v[0x12e1]], xwrb[v[0x77fc]]);
    } });
}, window[v[0x2fb7]] = function (itkdfu) {
  wx[v[0x2fb7]]({ 'success': function (fuigtk) {
      itkdfu && itkdfu(!![], fuigtk);
    }, 'fail': function (cn_943) {
      itkdfu && itkdfu(![], cn_943);
    } });
}, window[v[0x2fb9]] = function (_64nj) {
  if (_64nj) wx[v[0x2fb9]](_64nj);
}, window[v[0x6482]] = function (_n4h9j) {
  wx[v[0x6482]](_n4h9j);
}, window[v[0x16]] = function (j9_hn, r81w$, mneh, kfugi, o94_, hn46jm, h6nj4, tfuqk) {
  if (kfugi == undefined) kfugi = 0x1;wx[v[0x1dd]]({ 'url': j9_hn, 'method': h6nj4 || v[0x6546], 'responseType': v[0x121e], 'data': r81w$, 'header': { 'content-type': tfuqk || v[0x783f] }, 'success': function (qgka0) {
      DEBUG && console[v[0x1e2]](v[0x78ce], j9_hn, info, qgka0);if (qgka0 && qgka0[v[0x66c3]] == 0xc8) {
        var $w1vrp = qgka0[v[0xb]];!hn46jm || hn46jm($w1vrp) ? mneh && mneh($w1vrp) : window[v[0x78cf]](j9_hn, r81w$, mneh, kfugi, o94_, hn46jm, qgka0);
      } else window[v[0x78cf]](j9_hn, r81w$, mneh, kfugi, o94_, hn46jm, qgka0);
    }, 'fail': function (kq0a) {
      DEBUG && console[v[0x1e2]](v[0x78d0], j9_hn, info, kq0a), window[v[0x78cf]](j9_hn, r81w$, mneh, kfugi, o94_, hn46jm, kq0a);
    }, 'complete': function () {} });
}, window[v[0x78cf]] = function (ukqgft, b1x8w, xaz, a80x, mh4n6, $v1prw, r$p1v) {
  a80x - 0x1 > 0x0 ? setTimeout(function () {
    window[v[0x16]](ukqgft, b1x8w, xaz, a80x - 0x1, mh4n6, $v1prw);
  }, 0x3e8) : mh4n6 && mh4n6(JSON[v[0x1270]]({ 'url': ukqgft, 'response': r$p1v }));
}, window[v[0x78d1]] = function (w7$yvp, wp7$vy, n34j_, wp$1, z0a8b, zkg0f, w$7v) {
  !n34j_ && (n34j_ = {});var zqxab0 = Math[v[0x76]](Date[v[0x53]]() / 0x3e8);n34j_[v[0x36a]] = zqxab0, n34j_[v[0x78d2]] = wp7$vy;var $7ywpv = Object[v[0x106]](n34j_)[v[0x44e]](),
      idfktu = '',
      qgakz = '';for (var zgk0q = 0x0; zgk0q < $7ywpv[v[0xd]]; zgk0q++) {
    idfktu = idfktu + (zgk0q == 0x0 ? '' : '&') + $7ywpv[zgk0q] + n34j_[$7ywpv[zgk0q]], qgakz = qgakz + (zgk0q == 0x0 ? '' : '&') + $7ywpv[zgk0q] + '=' + encodeURIComponent(n34j_[$7ywpv[zgk0q]]);
  }idfktu = idfktu + D$LZ[v[0x7819]];var wpr$v7 = v[0x78d3] + md5(idfktu);send(w7$yvp + '?' + qgakz + (qgakz == '' ? '' : '&') + wpr$v7, null, wp$1, z0a8b, zkg0f, w$7v || function (kqtufg) {
    return kqtufg[v[0x4d0]] == v[0x27ca];
  }, null, v[0x76e0]);
}, window['D$LAZS'] = function (rx, tume) {
  var nj_ = 0x0;D$LZ[v[0x65b6]] && (nj_ = D$LZ[v[0x65b6]][v[0x2e25]]), sendApi(D$LZ[v[0x7815]], v[0x78d4], { 'partnerId': D$LZ[v[0x5f18]], 'gamePkg': D$LZ[v[0x65bc]], 'logTime': Math[v[0x76]](Date[v[0x53]]() / 0x3e8), 'platformUid': D$LZ[v[0x65bd]], 'type': rx, 'serverId': nj_ }, null, 0x2, null, function () {
    return !![];
  });
}, window['D$LZSA'] = function (q0azgb) {
  sendApi(D$LZ[v[0x7813]], v[0x78d5], { 'partner_id': D$LZ[v[0x5f18]], 'uid': D$LZ[v[0x65bb]], 'version': D$LZ[v[0x1341]], 'game_pkg': D$LZ[v[0x65bc]], 'device': D$LZ[v[0x65be]] }, D$LZAS, D$AZL, D$ZS);
}, window['D$LZAS'] = function (aqkgz) {
  if (aqkgz && aqkgz[v[0x4d0]] === v[0x27ca] && aqkgz[v[0xb]]) {
    aqkgz[v[0xb]][v[0x16b7]]({ 'id': -0x2, 'name': v[0x78d6] }), aqkgz[v[0xb]][v[0x16b7]]({ 'id': -0x1, 'name': v[0x78d7] }), D$LZ[v[0x78d8]] = aqkgz[v[0xb]];if (window[v[0x319b]]) window[v[0x319b]][v[0x78d9]]();
  } else {
    D$LZ[v[0x78da]] = ![];var ufgtq = aqkgz ? aqkgz[v[0x4d0]] : '';window[v[0x7833]](0x7, v[0x78db] + ufgtq), window['D$SALZ'](v[0x78dc] + ufgtq);
  }
}, window['D$SAL'] = function (brw18) {
  sendApi(D$LZ[v[0x7813]], v[0x78dd], { 'partner_id': D$LZ[v[0x5f18]], 'uid': D$LZ[v[0x65bb]], 'version': D$LZ[v[0x1341]], 'game_pkg': D$LZ[v[0x65bc]], 'device': D$LZ[v[0x65be]] }, D$SLA, D$AZL, D$ZS);
}, window['D$SLA'] = function (wpr1$v) {
  D$LZ[v[0x78de]] = ![];if (wpr1$v && wpr1$v[v[0x4d0]] === v[0x27ca] && wpr1$v[v[0xb]]) {
    for (var q0zxab = 0x0; q0zxab < wpr1$v[v[0xb]][v[0xd]]; q0zxab++) {
      wpr1$v[v[0xb]][q0zxab][v[0x6a]] = D$LAS(wpr1$v[v[0xb]][q0zxab]);
    }D$LZ[v[0x781c]][-0x1] = window[v[0x78df]](wpr1$v[v[0xb]]), window[v[0x319b]][v[0x78e0]](-0x1);
  } else {
    var fgk0qt = wpr1$v ? wpr1$v[v[0x4d0]] : '';window[v[0x7833]](0x8, v[0x78e1] + fgk0qt), window['D$SALZ'](v[0x78e2] + fgk0qt);
  }
}, window[v[0x78e3]] = function (eh) {
  sendApi(D$LZ[v[0x7813]], v[0x78dd], { 'partner_id': D$LZ[v[0x5f18]], 'uid': D$LZ[v[0x65bb]], 'version': D$LZ[v[0x1341]], 'game_pkg': D$LZ[v[0x65bc]], 'device': D$LZ[v[0x65be]] }, eh, D$AZL, D$ZS);
}, window['D$ASL'] = function (xaz0, jh_4n6) {
  sendApi(D$LZ[v[0x7813]], v[0x78e4], { 'partner_id': D$LZ[v[0x5f18]], 'uid': D$LZ[v[0x65bb]], 'version': D$LZ[v[0x1341]], 'game_pkg': D$LZ[v[0x65bc]], 'device': D$LZ[v[0x65be]], 'server_group_id': jh_4n6 }, D$ALS, D$AZL, D$ZS);
}, window['D$ALS'] = function (vy$pl) {
  D$LZ[v[0x78de]] = ![];if (vy$pl && vy$pl[v[0x4d0]] === v[0x27ca] && vy$pl[v[0xb]] && vy$pl[v[0xb]][v[0xb]]) {
    var iedm6h = vy$pl[v[0xb]][v[0x78e5]],
        gkiutf = [];for (var gfqkt0 = 0x0; gfqkt0 < vy$pl[v[0xb]][v[0xb]][v[0xd]]; gfqkt0++) {
      vy$pl[v[0xb]][v[0xb]][gfqkt0][v[0x6a]] = D$LAS(vy$pl[v[0xb]][v[0xb]][gfqkt0]), (gkiutf[v[0xd]] == 0x0 || vy$pl[v[0xb]][v[0xb]][gfqkt0][v[0x6a]] != 0x0) && (gkiutf[gkiutf[v[0xd]]] = vy$pl[v[0xb]][v[0xb]][gfqkt0]);
    }D$LZ[v[0x781c]][iedm6h] = window[v[0x78df]](gkiutf), window[v[0x319b]][v[0x78e0]](iedm6h);
  } else {
    var o5c93 = vy$pl ? vy$pl[v[0x4d0]] : '';window[v[0x7833]](0x9, v[0x78e6] + o5c93), window['D$SALZ'](v[0x78e7] + o5c93);
  }
}, window['D$YAZL'] = function (dikuf) {
  sendApi(D$LZ[v[0x7813]], v[0x78e8], { 'partner_id': D$LZ[v[0x5f18]], 'uid': D$LZ[v[0x65bb]], 'version': D$LZ[v[0x1341]], 'game_pkg': D$LZ[v[0x65bc]], 'device': D$LZ[v[0x65be]] }, reqServerRecommendCallBack, D$AZL, D$ZS);
}, window[v[0x78e9]] = function (tukgf) {
  D$LZ[v[0x78de]] = ![];if (tukgf && tukgf[v[0x4d0]] === v[0x27ca] && tukgf[v[0xb]]) {
    for (var z1b8x = 0x0; z1b8x < tukgf[v[0xb]][v[0xd]]; z1b8x++) {
      tukgf[v[0xb]][z1b8x][v[0x6a]] = D$LAS(tukgf[v[0xb]][z1b8x]);
    }D$LZ[v[0x781c]][-0x2] = window[v[0x78df]](tukgf[v[0xb]]), window[v[0x319b]][v[0x78e0]](-0x2);
  } else {
    var bxza8 = tukgf ? tukgf[v[0x4d0]] : '';window[v[0x7833]](0xa, v[0x78ea] + bxza8), alert(v[0x78eb] + bxza8);
  }
}, window[v[0x78df]] = function (kiguf) {
  return kiguf;
}, window['D$LSA'] = function (wrx8$, yp7vw$) {
  wrx8$ = wrx8$ || D$LZ[v[0x65b6]][v[0x2e25]], sendApi(D$LZ[v[0x7813]], v[0x78ec], { 'type': '4', 'game_pkg': D$LZ[v[0x65bc]], 'server_id': wrx8$ }, yp7vw$);
}, window[v[0x78ed]] = function (gf0, j6nm4, $y7vlp, ditmue) {
  $y7vlp = $y7vlp || D$LZ[v[0x65b6]][v[0x2e25]], sendApi(D$LZ[v[0x7813]], v[0x78ee], { 'type': gf0, 'game_pkg': j6nm4, 'server_id': $y7vlp }, ditmue);
}, window[v[0x78ef]] = function (nj_94, $7wypv) {
  sendApi(D$LZ[v[0x7813]], v[0x78f0], { 'game_pkg': nj_94 }, $7wypv);
}, window['D$LAS'] = function (ktuifd) {
  if (ktuifd) {
    if (ktuifd[v[0x6a]] == 0x1) {
      if (ktuifd[v[0x78f1]] == 0x1) return 0x2;else return 0x1;
    } else return ktuifd[v[0x6a]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['D$ZSAL'] = function (kuifgt, ufetd) {
  var j4mhn = window[v[0x7888]][v[0x788a]] == 0x1;if (j4mhn) {
    var hjn4_9 = window[v[0x7888]][v[0x7891]],
        j4mhn = window[v[0x7888]][v[0x788a]] == 0x1;window[v[0x77b8]][v[0x94]][v[0x7892]](v[0x7893], hjn4_9, v[0x7894]);return;
  }D$LZ[v[0x78f2]] = { 'step': kuifgt, 'server_id': ufetd };var o_c9 = this;D$SLAZ({ 'title': v[0x78f3] }), sendApi(D$LZ[v[0x7813]], v[0x78f4], { 'partner_id': D$LZ[v[0x5f18]], 'uid': D$LZ[v[0x65bb]], 'game_pkg': D$LZ[v[0x65bc]], 'server_id': ufetd, 'platform': D$LZ[v[0x6598]], 'platform_uid': D$LZ[v[0x65bd]], 'check_login_time': D$LZ[v[0x786f]], 'check_login_sign': D$LZ[v[0x786e]], 'version_name': D$LZ[v[0x7853]] }, D$ZSLA, D$AZL, D$ZS, function (x0abz) {
    return x0abz[v[0x4d0]] == v[0x27ca] || x0abz[v[0x4e]] == v[0x78f5] || x0abz[v[0x4e]] == v[0x78f6];
  });
}, window['D$ZSLA'] = function (i6um) {
  var o943_c = this;if (i6um && i6um[v[0x4d0]] === v[0x27ca] && i6um[v[0xb]]) {
    var ehid6m = D$LZ[v[0x65b6]];ehid6m[v[0x78f7]] = D$LZ[v[0x781d]], ehid6m[v[0x2e14]] = String(i6um[v[0xb]][v[0x78f8]]), ehid6m[v[0x659a]] = parseInt(i6um[v[0xb]][v[0x36a]]);if (i6um[v[0xb]][v[0x6599]]) ehid6m[v[0x6599]] = parseInt(i6um[v[0xb]][v[0x6599]]);else ehid6m[v[0x6599]] = parseInt(i6um[v[0xb]][v[0x2e25]]);ehid6m[v[0x78f9]] = 0x0, ehid6m[v[0x127e]] = D$LZ[v[0x789d]], ehid6m[v[0x78fa]] = i6um[v[0xb]][v[0x78fb]], ehid6m[v[0x78fc]] = i6um[v[0xb]][v[0x78fc]];if (i6um[v[0xb]][v[0x659d]]) ehid6m[v[0x659d]] = parseInt(i6um[v[0xb]][v[0x659d]]);console[v[0x1e2]](v[0x78fd] + JSON[v[0x1270]](ehid6m[v[0x78fc]])), D$LZ[v[0x289]] == 0x1 && ehid6m[v[0x78fc]] && ehid6m[v[0x78fc]][v[0x78fe]] == 0x1 && (D$LZ[v[0x78ff]] = 0x1, window[v[0x77b8]][v[0x94]]['D$YZL']()), D$ZASL();
  } else {
    if (D$LZ[v[0x78f2]][v[0x1cd8]] >= 0x3) {
      var jh6n_4 = i6um ? i6um[v[0x4d0]] : '';window[v[0x7833]](0xc, v[0x7900] + jh6n_4), D$ZS(JSON[v[0x1270]](i6um)), window['D$SALZ'](v[0x7901] + jh6n_4);
    } else sendApi(D$LZ[v[0x7813]], v[0x785c], { 'platform': D$LZ[v[0x7811]], 'partner_id': D$LZ[v[0x5f18]], 'token': D$LZ[v[0x785a]], 'game_pkg': D$LZ[v[0x65bc]], 'deviceId': D$LZ[v[0x65be]], 'scene': v[0x785d] + D$LZ[v[0x781b]] }, function (j4hn_6) {
      if (!j4hn_6 || j4hn_6[v[0x4d0]] != v[0x27ca]) {
        window['D$SALZ'](v[0x786d] + j4hn_6 && j4hn_6[v[0x4d0]]);return;
      }D$LZ[v[0x786e]] = String(j4hn_6[v[0x2e14]]), D$LZ[v[0x786f]] = String(j4hn_6[v[0x36a]]), setTimeout(function () {
        D$ZSAL(D$LZ[v[0x78f2]][v[0x1cd8]] + 0x1, D$LZ[v[0x78f2]][v[0x2e25]]);
      }, 0x5dc);
    }, D$AZL, D$ZS, function (o53c29) {
      return o53c29[v[0x4d0]] == v[0x27ca] || o53c29[v[0x4d0]] == v[0x6711];
    });
  }
}, window['D$ZASL'] = function () {
  ServerLoading[v[0x94]][v[0x788f]](D$LZ[v[0x289]]), window['D$AZ'] = !![], window['D$ZLSA']();
}, window['D$ZALS'] = function () {
  if (window['D$ZA'] && window['D$LAZ'] && window[v[0x7823]] && window[v[0x7824]] && window['D$LZA'] && window['D$LA']) {
    if (!window[v[0x74be]][v[0x94]]) {
      console[v[0x1e2]](v[0x7902] + window[v[0x74be]][v[0x94]]);var mhen6 = wx[v[0x77a4]](),
          jn934 = mhen6[v[0x31f]] ? mhen6[v[0x31f]] : 0x0,
          $pwr18 = { 'cdn': window['D$LZ'][v[0x127e]], 'spareCdn': window['D$LZ'][v[0x6487]], 'newRegister': window['D$LZ'][v[0x289]], 'wxPC': window['D$LZ'][v[0x648a]], 'wxIOS': window['D$LZ'][v[0x44a]], 'wxAndroid': window['D$LZ'][v[0x2d73]], 'wxParam': { 'limitLoad': window['D$LZ']['D$YSAZL'], 'benchmarkLevel': window['D$LZ']['D$YSLAZ'], 'wxFrom': window[v[0x22e]][v[0x75ed]] == v[0x7903] ? 0x1 : 0x0, 'wxSDKVersion': window[v[0x77b9]] }, 'configType': window['D$LZ'][v[0x2fd5]], 'exposeType': window['D$LZ'][v[0x2e1]], 'scene': jn934 };new window[v[0x74be]]($pwr18, window['D$LZ'][v[0x65]], window['D$YSALZ']);
    }
  }
}, window['D$ZLSA'] = function () {
  if (window['D$ZA'] && window['D$LAZ'] && window[v[0x7823]] && window[v[0x7824]] && window['D$LZA'] && window['D$LA'] && window['D$AZ'] && window['D$AL']) {
    D$SLZA();if (!D$ZAL) {
      D$ZAL = !![];if (!window[v[0x74be]][v[0x94]]) window['D$ZALS']();var igftku = 0x0,
          defiu = wx[v[0x7904]]();defiu && (window['D$LZ'][v[0x77ef]] && (igftku = defiu[v[0x13e]]), console[v[0x4e]](v[0x7905] + defiu[v[0x13e]] + v[0x7906] + defiu[v[0x4e4]] + v[0x7907] + defiu[v[0x4e6]] + v[0x7908] + defiu[v[0x4e5]] + v[0x7909] + defiu[v[0xb2]] + v[0x790a] + defiu[v[0xb3]]));var mjdeh = {};for (const n39_j in D$LZ[v[0x65b6]]) {
        mjdeh[n39_j] = D$LZ[v[0x65b6]][n39_j];
      }var idmtue = { 'channel': window['D$LZ'][v[0x65ba]], 'account': window['D$LZ'][v[0x65bb]], 'userId': window['D$LZ'][v[0x4c2f]], 'cdn': window['D$LZ'][v[0x127e]], 'data': window['D$LZ'][v[0xb]], 'package': window['D$LZ'][v[0x6488]], 'newRegister': window['D$LZ'][v[0x289]], 'pkgName': window['D$LZ'][v[0x65bc]], 'partnerId': window['D$LZ'][v[0x5f18]], 'platform_uid': window['D$LZ'][v[0x65bd]], 'deviceId': window['D$LZ'][v[0x65be]], 'selectedServer': mjdeh, 'configType': window['D$LZ'][v[0x2fd5]], 'exposeType': window['D$LZ'][v[0x2e1]], 'debugUsers': window['D$LZ'][v[0x3168]], 'wxMenuTop': igftku, 'wxShield': window['D$LZ'][v[0x2f9]] };if (window[v[0x789f]]) for (var aq0kz in window[v[0x789f]]) {
        idmtue[aq0kz] = window[v[0x789f]][aq0kz];
      }window[v[0x74be]][v[0x94]]['D$ZLY'](idmtue);if (D$LZ[v[0x65b6]] && D$LZ[v[0x65b6]][v[0x2e25]]) localStorage[v[0x1e5]](v[0x7871] + D$LZ[v[0x65bc]] + D$LZ[v[0x65bb]], D$LZ[v[0x65b6]][v[0x2e25]]);
    }
  } else console[v[0x4e]](v[0x790b] + window['D$ZA'] + v[0x790c] + window['D$LAZ'] + v[0x790d] + window[v[0x7823]] + v[0x790e] + window[v[0x7824]] + v[0x790f] + window['D$LZA'] + v[0x7910] + window['D$LA'] + v[0x7911] + window['D$AZ'] + v[0x7912] + window['D$AL']);
};