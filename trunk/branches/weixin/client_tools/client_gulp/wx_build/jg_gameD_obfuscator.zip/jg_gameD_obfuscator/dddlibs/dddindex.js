var v = wx.$d;
import zkutq from '../dddk/dddsdk.js';window[v[0x72df]] = { 'wxVersion': window[v[0x22d]][v[0x727b]] }, window[v[0x72e0]] = ![], window['D$ZL'] = 0x1, window[v[0x72e1]] = 0x1, window['D$ALZ'] = !![], window[v[0x72e2]] = !![], window['D$YSALZ'] = '', window['D$LZ'] = { 'base_cdn': v[0x72e3], 'cdn': v[0x72e3] }, D$LZ[v[0x72e4]] = {}, D$LZ[v[0x61dd]] = '0', D$LZ[v[0x1285]] = window[v[0x72df]][v[0x72e5]], D$LZ[v[0x6fd3]] = '', D$LZ['os'] = '1', D$LZ[v[0x72e6]] = v[0x72e7], D$LZ[v[0x72e8]] = v[0x72e9], D$LZ[v[0x72ea]] = v[0x72eb], D$LZ[v[0x72ec]] = v[0x72ed], D$LZ[v[0x72ee]] = v[0x72ef], D$LZ[v[0x5cc9]] = '1', D$LZ[v[0x6304]] = '', D$LZ[v[0x6306]] = '', D$LZ[v[0x72f0]] = 0x0, D$LZ[v[0x72f1]] = {}, D$LZ[v[0x72f2]] = parseInt(D$LZ[v[0x5cc9]]), D$LZ[v[0x6302]] = D$LZ[v[0x5cc9]], D$LZ[v[0x62fe]] = {}, D$LZ['D$SL'] = v[0x72f3], D$LZ[v[0x72f4]] = ![], D$LZ[v[0x3009]] = v[0x72f5], D$LZ[v[0x62e9]] = Date[v[0x53]](), D$LZ[v[0x2e7b]] = v[0x72f6], D$LZ[v[0x2ca]] = '_a', D$LZ[v[0x72f7]] = 0x2, D$LZ[v[0x65]] = 0x7c1, D$LZ[v[0x72e5]] = window[v[0x72df]][v[0x72e5]], D$LZ[v[0x2e2]] = ![], D$LZ[v[0x432]] = ![], D$LZ[v[0x2c6f]] = ![], D$LZ[v[0x61df]] = ![], window['D$AZL'] = 0x5, window['D$AZ'] = ![], window['D$ZA'] = ![], window['D$LAZ'] = ![], window[v[0x72f8]] = ![], window[v[0x72f9]] = ![], window['D$LZA'] = ![], window['D$AL'] = ![], window['D$LA'] = ![], window['D$ZAL'] = ![], window[v[0x1071]] = function (zga0) {
  console[v[0x1e2]](v[0x1071], zga0), wx[v[0x139d]]({}), wx[v[0x7293]]({ 'title': v[0x18fb], 'content': zga0, 'success'(xb0azq) {
      if (xb0azq[v[0x72fa]]) console[v[0x1e2]](v[0x72fb]);else xb0azq[v[0x229]] && console[v[0x1e2]](v[0x7069]);
    } });
}, window['D$SALZ'] = function (gq0fzk) {
  console[v[0x1e2]](v[0x72fc], gq0fzk), D$SLZA(), wx[v[0x7293]]({ 'title': v[0x18fb], 'content': gq0fzk, 'confirmText': v[0x72fd], 'cancelText': v[0x4899], 'success'(r7pvw$) {
      if (r7pvw$[v[0x72fa]]) window['D$LS']();else r7pvw$[v[0x229]] && (console[v[0x1e2]](v[0x72fe]), wx[v[0x61d8]]({}));
    } });
}, window[v[0x72ff]] = function (y7$pv) {
  console[v[0x1e2]](v[0x72ff], y7$pv), wx[v[0x7293]]({ 'title': v[0x18fb], 'content': y7$pv, 'confirmText': v[0x6386], 'showCancel': ![], 'complete'(iefut) {
      console[v[0x1e2]](v[0x72fe]), wx[v[0x61d8]]({});
    } });
}, window['D$SAZL'] = ![], window['D$SLAZ'] = function (uftedi) {
  window['D$SAZL'] = !![], wx[v[0x139c]](uftedi);
}, window['D$SLZA'] = function () {
  window['D$SAZL'] && (window['D$SAZL'] = ![], wx[v[0x139d]]({}));
}, window['D$SZAL'] = function (py7$lv) {
  window[v[0x728a]][v[0x94]]['D$SZAL'](py7$lv);
}, window[v[0x2f8f]] = function (w8r$, zq0gk) {
  zkutq[v[0x2f8f]](w8r$, function (fkgt) {
    fkgt && fkgt[v[0xb]] ? fkgt[v[0xb]][v[0x102e]] == 0x1 ? zq0gk(!![]) : (zq0gk(![]), console[v[0x4e]](v[0x7300] + fkgt[v[0xb]][v[0x7301]])) : console[v[0x1e2]](v[0x2f8f], fkgt);
  });
}, window['D$SZLA'] = function (o359c) {
  console[v[0x1e2]](v[0x7302], o359c);
}, window['D$SLZ'] = function (tdeif) {}, window['D$SZL'] = function (d6eimu, p8w1, dihm6) {}, window['D$SZ'] = function (_nc943) {
  console[v[0x1e2]](v[0x7303], _nc943), window[v[0x728a]][v[0x94]][v[0x7304]](), window[v[0x728a]][v[0x94]][v[0x7305]](), window[v[0x728a]][v[0x94]][v[0x7306]]();
}, window['D$ZS'] = function (gab0) {
  window['D$SALZ'](v[0x7307]);var ra1bx = { 'id': window['D$LZ'][v[0x7280]], 'role': window['D$LZ'][v[0x123e]], 'level': window['D$LZ'][v[0x7281]], 'account': window['D$LZ'][v[0x6303]], 'version': window['D$LZ'][v[0x65]], 'cdn': window['D$LZ'][v[0x11c3]], 'pkgName': window['D$LZ'][v[0x6304]], 'gamever': window[v[0x22d]][v[0x727b]], 'serverid': window['D$LZ'][v[0x62fe]] ? window['D$LZ'][v[0x62fe]][v[0x2d21]] : 0x0, 'systemInfo': window[v[0x7282]], 'error': v[0x7308], 'stack': gab0 ? gab0 : v[0x7307] },
      qab0z = JSON[v[0x11b5]](ra1bx);console[v[0x7d]](v[0x7309] + qab0z), window['D$SL'](qab0z);
}, window['D$LSZ'] = function (ktuqg) {
  var g0azq = JSON[v[0x20f]](ktuqg);g0azq[v[0x730a]] = window[v[0x22d]][v[0x727b]], g0azq[v[0x730b]] = window['D$LZ'][v[0x62fe]] ? window['D$LZ'][v[0x62fe]][v[0x2d21]] : 0x0, g0azq[v[0x7282]] = window[v[0x7282]];var jmnhe6 = JSON[v[0x11b5]](g0azq);console[v[0x7d]](v[0x730c] + jmnhe6), window['D$SL'](jmnhe6);
}, window['D$LZS'] = function (rw$x1, tudk) {
  var n43j9_ = { 'id': window['D$LZ'][v[0x7280]], 'role': window['D$LZ'][v[0x123e]], 'level': window['D$LZ'][v[0x7281]], 'account': window['D$LZ'][v[0x6303]], 'version': window['D$LZ'][v[0x65]], 'cdn': window['D$LZ'][v[0x11c3]], 'pkgName': window['D$LZ'][v[0x6304]], 'gamever': window[v[0x22d]][v[0x727b]], 'serverid': window['D$LZ'][v[0x62fe]] ? window['D$LZ'][v[0x62fe]][v[0x2d21]] : 0x0, 'systemInfo': window[v[0x7282]], 'error': rw$x1, 'stack': tudk },
      jm46n = JSON[v[0x11b5]](n43j9_);console[v[0x60]](v[0x730d] + jm46n), window['D$SL'](jm46n);
}, window['D$SL'] = function (azq0) {
  if (window['D$LZ'][v[0x72c4]] == v[0x730e]) return;var g0qzba = D$LZ['D$SL'] + v[0x730f] + D$LZ[v[0x6303]];wx[v[0x1dd]]({ 'url': g0qzba, 'method': v[0x70bc], 'data': azq0, 'header': { 'content-type': v[0x7310], 'cache-control': v[0x7311] }, 'success': function (tedumi) {
      DEBUG && console[v[0x1e2]](v[0x7312], g0qzba, azq0, tedumi);
    }, 'fail': function (zbg0) {
      DEBUG && console[v[0x1e2]](v[0x7312], g0qzba, azq0, zbg0);
    }, 'complete': function () {} });
}, window[v[0x7313]] = function () {
  function edtfui() {
    return ((0x1 + Math[v[0x77]]()) * 0x10000 | 0x0)[v[0x113]](0x10)[v[0x1f4]](0x1);
  }return edtfui() + edtfui() + '-' + edtfui() + '-' + edtfui() + '-' + edtfui() + '+' + edtfui() + edtfui() + edtfui();
}, window['D$LS'] = function () {
  console[v[0x1e2]](v[0x7314]);var c49o_3 = zkutq[v[0x7315]]();D$LZ[v[0x6302]] = c49o_3[v[0x7316]], D$LZ[v[0x72f2]] = c49o_3[v[0x7316]], D$LZ[v[0x5cc9]] = c49o_3[v[0x7316]], D$LZ[v[0x6304]] = c49o_3[v[0x7317]];var oc9_43 = { 'game_ver': D$LZ[v[0x1285]] };D$LZ[v[0x6306]] = this[v[0x7313]](), D$SLAZ({ 'title': v[0x7318] }), zkutq[v[0x170]](oc9_43, this['D$ZSL'][v[0x4a]](this));
}, window['D$ZSL'] = function (gzq0ba) {
  var h_4n9j = gzq0ba[v[0x7319]];console[v[0x1e2]](v[0x731a] + h_4n9j + v[0x731b] + (h_4n9j == 0x1) + v[0x731c] + gzq0ba[v[0x727b]] + v[0x731d] + window[v[0x72df]][v[0x72e5]]);if (!gzq0ba[v[0x727b]] || window['D$YAZSL'](window[v[0x72df]][v[0x72e5]], gzq0ba[v[0x727b]]) < 0x0) console[v[0x1e2]](v[0x731e]), D$LZ[v[0x72e8]] = v[0x731f], D$LZ[v[0x72ea]] = v[0x7320], D$LZ[v[0x72ec]] = v[0x7321], D$LZ[v[0x11c3]] = v[0x7322], D$LZ[v[0x61dc]] = v[0x7323], D$LZ[v[0x7324]] = 'fj', D$LZ[v[0x2e2]] = ![];else window['D$YAZSL'](window[v[0x72df]][v[0x72e5]], gzq0ba[v[0x727b]]) == 0x0 ? (console[v[0x1e2]](v[0x7325]), D$LZ[v[0x72e8]] = v[0x72e9], D$LZ[v[0x72ea]] = v[0x72eb], D$LZ[v[0x72ec]] = v[0x72ed], D$LZ[v[0x11c3]] = v[0x7326], D$LZ[v[0x61dc]] = v[0x7323], D$LZ[v[0x7324]] = v[0x7327], D$LZ[v[0x2e2]] = !![]) : (console[v[0x1e2]](v[0x7328]), D$LZ[v[0x72e8]] = v[0x72e9], D$LZ[v[0x72ea]] = v[0x72eb], D$LZ[v[0x72ec]] = v[0x72ed], D$LZ[v[0x11c3]] = v[0x7326], D$LZ[v[0x61dc]] = v[0x7323], D$LZ[v[0x7324]] = v[0x7327], D$LZ[v[0x2e2]] = ![]);D$LZ[v[0x72f0]] = config[v[0x7201]] ? config[v[0x7201]] : 0x0, this['D$ALSZ'](), this['D$ALZS'](), window[v[0x7329]] = 0x5, D$SLAZ({ 'title': v[0x732a] }), zkutq[v[0x7023]](this['D$ZLS'][v[0x4a]](this));
}, window[v[0x7329]] = 0x5, window['D$ZLS'] = function (p$wr7v, fkq0tg) {
  if (p$wr7v == 0x0 && fkq0tg && fkq0tg[v[0x725d]]) {
    D$LZ[v[0x732b]] = fkq0tg[v[0x725d]];var bx8ra1 = this;D$SLAZ({ 'title': v[0x732c] }), sendApi(D$LZ[v[0x72e8]], v[0x732d], { 'platform': D$LZ[v[0x72e6]], 'partner_id': D$LZ[v[0x5cc9]], 'token': fkq0tg[v[0x725d]], 'game_pkg': D$LZ[v[0x6304]], 'deviceId': D$LZ[v[0x6306]], 'scene': v[0x732e] + D$LZ[v[0x72f0]] }, this['D$ASLZ'][v[0x4a]](this), D$AZL, D$ZS);
  } else fkq0tg && fkq0tg[v[0x63bb]] && window[v[0x7329]] > 0x0 && (fkq0tg[v[0x63bb]][v[0x73]](v[0x732f]) != -0x1 || fkq0tg[v[0x63bb]][v[0x73]](v[0x7330]) != -0x1 || fkq0tg[v[0x63bb]][v[0x73]](v[0x7331]) != -0x1 || fkq0tg[v[0x63bb]][v[0x73]](v[0x7332]) != -0x1 || fkq0tg[v[0x63bb]][v[0x73]](v[0x7333]) != -0x1 || fkq0tg[v[0x63bb]][v[0x73]](v[0x7334]) != -0x1) ? (window[v[0x7329]]--, zkutq[v[0x7023]](this['D$ZLS'][v[0x4a]](this))) : (window['D$LZS'](v[0x7335], JSON[v[0x11b5]]({ 'status': p$wr7v, 'data': fkq0tg })), window['D$SALZ'](v[0x7336] + (fkq0tg && fkq0tg[v[0x63bb]] ? '，' + fkq0tg[v[0x63bb]] : '')));
}, window['D$ASLZ'] = function ($vwy) {
  if (!$vwy) {
    window['D$LZS'](v[0x7337], v[0x7338]), window['D$SALZ'](v[0x7339]);return;
  }if ($vwy[v[0x102e]] != v[0x26eb]) {
    window['D$LZS'](v[0x7337], JSON[v[0x11b5]]($vwy)), window['D$SALZ'](v[0x733a] + $vwy[v[0x102e]]);return;
  }D$LZ[v[0x5cc8]] = String($vwy[v[0x6303]]), D$LZ[v[0x6303]] = String($vwy[v[0x6303]]), D$LZ[v[0x62e7]] = String($vwy[v[0x62e7]]), D$LZ[v[0x6302]] = String($vwy[v[0x62e7]]), D$LZ[v[0x6305]] = String($vwy[v[0x6305]]), D$LZ[v[0x733b]] = String($vwy[v[0x2d10]]), D$LZ[v[0x733c]] = String($vwy[v[0x353]]), D$LZ[v[0x2d10]] = '';var ejh = this;D$SLAZ({ 'title': v[0x733d] }), sendApi(D$LZ[v[0x72e8]], v[0x733e], { 'partner_id': D$LZ[v[0x5cc9]], 'uid': D$LZ[v[0x6303]], 'version': D$LZ[v[0x1285]], 'game_pkg': D$LZ[v[0x6304]], 'device': D$LZ[v[0x6306]] }, ejh['D$ASZL'][v[0x4a]](ejh), D$AZL, D$ZS);
}, window['D$ASZL'] = function (g0qbaz) {
  if (!g0qbaz) {
    window['D$SALZ'](v[0x733f]);return;
  }if (g0qbaz[v[0x102e]] != v[0x26eb]) {
    window['D$SALZ'](v[0x7340] + g0qbaz[v[0x102e]]);return;
  }if (!g0qbaz[v[0xb]] || g0qbaz[v[0xb]][v[0xd]] == 0x0) {
    window['D$SALZ'](v[0x7341]);return;
  }D$LZ[v[0x276]] = g0qbaz[v[0x7342]], D$LZ[v[0x62fe]] = { 'server_id': String(g0qbaz[v[0xb]][0x0][v[0x2d21]]), 'server_name': String(g0qbaz[v[0xb]][0x0][v[0x7343]]), 'entry_ip': g0qbaz[v[0xb]][0x0][v[0x631a]], 'entry_port': parseInt(g0qbaz[v[0xb]][0x0][v[0x631b]]), 'status': D$LAS(g0qbaz[v[0xb]][0x0]), 'start_time': g0qbaz[v[0xb]][0x0][v[0x7344]], 'cdn': D$LZ[v[0x11c3]] }, this['D$ZLAS']();
}, window['D$ZLAS'] = function () {
  if (D$LZ[v[0x276]] == 0x1) {
    var o5932 = D$LZ[v[0x62fe]][v[0x6a]];if (o5932 === -0x1 || o5932 === 0x0) {
      window['D$SALZ'](o5932 === -0x1 ? v[0x7345] : v[0x7346]);return;
    }D$ZSAL(0x0, D$LZ[v[0x62fe]][v[0x2d21]]), window[v[0x728a]][v[0x94]][v[0x7347]](D$LZ[v[0x276]]);
  } else window[v[0x728a]][v[0x94]][v[0x7348]](), D$SLZA();window['D$LA'] = !![], window['D$ZALS'](), window['D$ZLSA']();
}, window['D$ALSZ'] = function () {
  sendApi(D$LZ[v[0x72e8]], v[0x7349], { 'game_pkg': D$LZ[v[0x6304]], 'version_name': D$LZ[v[0x7324]] }, this[v[0x734a]][v[0x4a]](this), D$AZL, D$ZS);
}, window[v[0x734a]] = function (qazk0) {
  if (!qazk0) {
    window['D$SALZ'](v[0x734b]);return;
  }if (qazk0[v[0x102e]] != v[0x26eb]) {
    window['D$SALZ'](v[0x734c] + qazk0[v[0x102e]]);return;
  }if (!qazk0[v[0xb]] || !qazk0[v[0xb]][v[0x1285]]) {
    window['D$SALZ'](v[0x734d] + (qazk0[v[0xb]] && qazk0[v[0xb]][v[0x1285]]));return;
  }qazk0[v[0xb]][v[0x734e]] && qazk0[v[0xb]][v[0x734e]][v[0xd]] > 0xa && (D$LZ[v[0x734f]] = qazk0[v[0xb]][v[0x734e]], D$LZ[v[0x11c3]] = qazk0[v[0xb]][v[0x734e]]), qazk0[v[0xb]][v[0x1285]] && (D$LZ[v[0x65]] = qazk0[v[0xb]][v[0x1285]]), console[v[0x4e]](v[0x638c] + D$LZ[v[0x65]] + v[0x7350] + D$LZ[v[0x7324]]), window['D$LZA'] = !![], window['D$ZALS'](), window['D$ZLSA']();
}, window[v[0x7351]], window['D$ALZS'] = function () {
  sendApi(D$LZ[v[0x72e8]], v[0x7352], { 'game_pkg': D$LZ[v[0x6304]] }, this['D$AZSL'][v[0x4a]](this), D$AZL, D$ZS);
}, window['D$AZSL'] = function (e6mhnj) {
  if (e6mhnj[v[0x102e]] === v[0x26eb] && e6mhnj[v[0xb]]) {
    window[v[0x7351]] = e6mhnj[v[0xb]];for (var eftui in e6mhnj[v[0xb]]) {
      D$LZ[eftui] = e6mhnj[v[0xb]][eftui];
    }
  } else console[v[0x4e]](v[0x7353] + e6mhnj[v[0x102e]]);window['D$AL'] = !![], window['D$ZLSA']();
}, window[v[0x7354]] = function (n43j_, x1w8br, hdm6ei, co_4, zab8, xqzb, dtiu, edmi6, k0fzq) {
  zab8 = String(zab8);var bxzaq0 = dtiu,
      _hj46n = edmi6;D$LZ[v[0x72e4]][zab8] = { 'productid': zab8, 'productname': bxzaq0, 'productdesc': _hj46n, 'roleid': n43j_, 'rolename': x1w8br, 'rolelevel': hdm6ei, 'price': xqzb, 'callback': k0fzq }, sendApi(D$LZ[v[0x72ec]], v[0x7355], { 'game_pkg': D$LZ[v[0x6304]], 'server_id': D$LZ[v[0x62fe]][v[0x2d21]], 'server_name': D$LZ[v[0x62fe]][v[0x7343]], 'level': hdm6ei, 'uid': D$LZ[v[0x6303]], 'role_id': n43j_, 'role_name': x1w8br, 'product_id': zab8, 'product_name': bxzaq0, 'product_desc': _hj46n, 'money': xqzb, 'partner_id': D$LZ[v[0x5cc9]] }, toPayCallBack, D$AZL, D$ZS);
}, window[v[0x7356]] = function (f0tqkg) {
  if (f0tqkg) {
    if (f0tqkg[v[0x7357]] === 0xc8 || f0tqkg[v[0x102e]] == v[0x26eb]) {
      var kgtfi = D$LZ[v[0x72e4]][String(f0tqkg[v[0x7358]])];if (kgtfi[v[0x14f]]) kgtfi[v[0x14f]](f0tqkg[v[0x7358]], f0tqkg[v[0x7359]], -0x1);zkutq[v[0x70d4]]({ 'cpbill': f0tqkg[v[0x7359]], 'productid': f0tqkg[v[0x7358]], 'productname': kgtfi[v[0x735a]], 'productdesc': kgtfi[v[0x735b]], 'serverid': D$LZ[v[0x62fe]][v[0x2d21]], 'servername': D$LZ[v[0x62fe]][v[0x7343]], 'roleid': kgtfi[v[0x735c]], 'rolename': kgtfi[v[0x735d]], 'rolelevel': kgtfi[v[0x735e]], 'price': kgtfi[v[0x69a8]], 'extension': JSON[v[0x11b5]]({ 'cp_order_id': f0tqkg[v[0x7359]] }) }, function (dhme6j, r8a) {
        kgtfi[v[0x14f]] && dhme6j == 0x0 && kgtfi[v[0x14f]](f0tqkg[v[0x7358]], f0tqkg[v[0x7359]], dhme6j);console[v[0x4e]](JSON[v[0x11b5]]({ 'type': v[0x735f], 'status': dhme6j, 'data': f0tqkg, 'role_name': kgtfi[v[0x735d]] }));if (dhme6j === 0x0) {} else {
          if (dhme6j === 0x1) {} else {
            if (dhme6j === 0x2) {}
          }
        }
      });
    } else alert(f0tqkg[v[0x4e]]);
  }
}, window['D$AZLS'] = function () {}, window['D$SAZ'] = function (qutgk, mj46h, n3_49c, a0gb, p$7ly) {
  zkutq[v[0x70e7]](D$LZ[v[0x62fe]][v[0x2d21]], D$LZ[v[0x62fe]][v[0x7343]] || D$LZ[v[0x62fe]][v[0x2d21]], qutgk, mj46h, n3_49c), sendApi(D$LZ[v[0x72e8]], v[0x7360], { 'game_pkg': D$LZ[v[0x6304]], 'server_id': D$LZ[v[0x62fe]][v[0x2d21]], 'role_id': qutgk, 'uid': D$LZ[v[0x6303]], 'role_name': mj46h, 'role_type': a0gb, 'level': n3_49c });
}, window['D$SZA'] = function (dmej6, qfgk0, gtkqfu, h4, o52c, b18rxw, umiedt, njh6em, axzq, uqkgf) {
  D$LZ[v[0x7280]] = dmej6, D$LZ[v[0x123e]] = qfgk0, D$LZ[v[0x7281]] = gtkqfu, zkutq[v[0x70e8]](D$LZ[v[0x62fe]][v[0x2d21]], D$LZ[v[0x62fe]][v[0x7343]] || D$LZ[v[0x62fe]][v[0x2d21]], dmej6, qfgk0, gtkqfu), sendApi(D$LZ[v[0x72e8]], v[0x7361], { 'game_pkg': D$LZ[v[0x6304]], 'server_id': D$LZ[v[0x62fe]][v[0x2d21]], 'role_id': dmej6, 'uid': D$LZ[v[0x6303]], 'role_name': qfgk0, 'role_type': h4, 'level': gtkqfu, 'evolution': o52c });
}, window['D$ASZ'] = function (iume6, q0kgft, imed6h, tgfukq, qakg0, wpr81, fuetd, $pv1, qufkg, kfutid) {
  D$LZ[v[0x7280]] = iume6, D$LZ[v[0x123e]] = q0kgft, D$LZ[v[0x7281]] = imed6h, zkutq[v[0x70e9]](D$LZ[v[0x62fe]][v[0x2d21]], D$LZ[v[0x62fe]][v[0x7343]] || D$LZ[v[0x62fe]][v[0x2d21]], iume6, q0kgft, imed6h), sendApi(D$LZ[v[0x72e8]], v[0x7361], { 'game_pkg': D$LZ[v[0x6304]], 'server_id': D$LZ[v[0x62fe]][v[0x2d21]], 'role_id': iume6, 'uid': D$LZ[v[0x6303]], 'role_name': q0kgft, 'role_type': tgfukq, 'level': imed6h, 'evolution': qakg0 });
}, window['D$AZS'] = function (pl$7vy) {}, window['D$SA'] = function (x8z1ba) {
  zkutq[v[0x709f]](v[0x709f], function (abzx8) {
    x8z1ba && x8z1ba(abzx8);
  });
}, window[v[0x61c8]] = function () {
  zkutq[v[0x61c8]]();
}, window[v[0x7362]] = function () {
  zkutq[v[0x5c5d]]();
}, window[v[0x7363]] = function ($rv7, qgz0, hj49_, tdfieu, $r1vp, cn9_43, j6_n4, j43_) {
  j43_ = j43_ || D$LZ[v[0x62fe]][v[0x2d21]], sendApi(D$LZ[v[0x72e8]], v[0x7364], { 'phone': $rv7, 'role_id': qgz0, 'uid': D$LZ[v[0x6303]], 'game_pkg': D$LZ[v[0x6304]], 'partner_id': D$LZ[v[0x5cc9]], 'server_id': j43_ }, j6_n4);
}, window[v[0x2a85]] = function (kqgz0a) {
  window['D$ZSA'] = kqgz0a, window['D$ZSA'] && window['D$AS'] && (console[v[0x4e]](v[0x72d7] + window['D$AS'][v[0x308]]), window['D$ZSA'](window['D$AS']), window['D$AS'] = null);
}, window['D$ZAS'] = function (jh_6n4, _39c4o, oc92, q0kgza) {
  window[v[0x16]](v[0x7365], { 'game_pkg': window['D$LZ'][v[0x6304]], 'role_id': _39c4o, 'server_id': oc92 }, q0kgza);
}, window['D$LSAZ'] = function (qgzk0f, yvpw7) {
  function dufeit(r8$pw1) {
    var gfutqk = [],
        j49_3 = [],
        kgt0 = window[v[0x22d]][v[0x7366]];for (var ra81x in kgt0) {
      var r8$x1 = Number(ra81x);(!qgzk0f || !qgzk0f[v[0xd]] || qgzk0f[v[0x73]](r8$x1) != -0x1) && (j49_3[v[0x1d]](kgt0[ra81x]), gfutqk[v[0x1d]]([r8$x1, 0x3]));
    }window['D$YAZSL'](window[v[0x728b]], v[0x7367]) >= 0x0 ? (console[v[0x1e2]](v[0x7368]), zkutq[v[0x7369]] && zkutq[v[0x7369]](j49_3, function (ba81rx) {
      console[v[0x1e2]](v[0x736a]), console[v[0x1e2]](ba81rx);if (ba81rx && ba81rx[v[0x63bb]] == v[0x736b]) for (var c3o952 in kgt0) {
        if (ba81rx[kgt0[c3o952]] == v[0x736c]) {
          var tfidku = Number(c3o952);for (var n9j43_ = 0x0; n9j43_ < gfutqk[v[0xd]]; n9j43_++) {
            if (gfutqk[n9j43_][0x0] == tfidku) {
              gfutqk[n9j43_][0x1] = 0x1;break;
            }
          }
        }
      }window['D$YAZSL'](window[v[0x728b]], v[0x736d]) >= 0x0 ? wx[v[0x736e]]({ 'withSubscriptions': !![], 'success': function (qktfg) {
          var w1rp$8 = qktfg[v[0x736f]][v[0x7370]];if (w1rp$8) {
            console[v[0x1e2]](v[0x7371]), console[v[0x1e2]](w1rp$8);for (var kt0f in kgt0) {
              if (w1rp$8[kgt0[kt0f]] == v[0x736c]) {
                var o_395c = Number(kt0f);for (var xzab0q = 0x0; xzab0q < gfutqk[v[0xd]]; xzab0q++) {
                  if (gfutqk[xzab0q][0x0] == o_395c) {
                    gfutqk[xzab0q][0x1] = 0x2;break;
                  }
                }
              }
            }console[v[0x1e2]](gfutqk), yvpw7 && yvpw7(gfutqk);
          } else console[v[0x1e2]](v[0x7372]), console[v[0x1e2]](qktfg), console[v[0x1e2]](gfutqk), yvpw7 && yvpw7(gfutqk);
        }, 'fail': function () {
          console[v[0x1e2]](v[0x7373]), console[v[0x1e2]](gfutqk), yvpw7 && yvpw7(gfutqk);
        } }) : (console[v[0x1e2]](v[0x7374] + window[v[0x728b]]), console[v[0x1e2]](gfutqk), yvpw7 && yvpw7(gfutqk));
    })) : (console[v[0x1e2]](v[0x7375] + window[v[0x728b]]), console[v[0x1e2]](gfutqk), yvpw7 && yvpw7(gfutqk)), wx[v[0x7376]](dufeit);
  }wx[v[0x7377]](dufeit);
}, window['D$LSZA'] = { 'isSuccess': ![], 'level': v[0x7378], 'isCharging': ![] }, window['D$LASZ'] = function (uetmd) {
  wx[v[0x72cc]]({ 'success': function (fkuqg) {
      var pyvw7 = window['D$LSZA'];pyvw7[v[0x7379]] = !![], pyvw7[v[0x1226]] = Number(fkuqg[v[0x1226]])[v[0x10a1]](0x0), pyvw7[v[0x72cf]] = fkuqg[v[0x72cf]], uetmd && uetmd(pyvw7[v[0x7379]], pyvw7[v[0x1226]], pyvw7[v[0x72cf]]);
    }, 'fail': function (q0gbaz) {
      console[v[0x1e2]](v[0x737a], q0gbaz[v[0x63bb]]);var prvw1 = window['D$LSZA'];uetmd && uetmd(prvw1[v[0x7379]], prvw1[v[0x1226]], prvw1[v[0x72cf]]);
    } });
}, window[v[0x16]] = function (djem, nm4jh, dtfiuk, $v1rwp, p7yv$l, zxabq0, xwb, v$ply7) {
  if ($v1rwp == undefined) $v1rwp = 0x1;wx[v[0x1dd]]({ 'url': djem, 'method': xwb || v[0x6296], 'responseType': v[0x1166], 'data': nm4jh, 'header': { 'content-type': v$ply7 || v[0x7310] }, 'success': function (y$pwv) {
      DEBUG && console[v[0x1e2]](v[0x737b], djem, info, y$pwv);if (y$pwv && y$pwv[v[0x6402]] == 0xc8) {
        var rwp$v7 = y$pwv[v[0xb]];!zxabq0 || zxabq0(rwp$v7) ? dtfiuk && dtfiuk(rwp$v7) : window[v[0x737c]](djem, nm4jh, dtfiuk, $v1rwp, p7yv$l, zxabq0, y$pwv);
      } else window[v[0x737c]](djem, nm4jh, dtfiuk, $v1rwp, p7yv$l, zxabq0, y$pwv);
    }, 'fail': function (c_9n4) {
      DEBUG && console[v[0x1e2]](v[0x737d], djem, info, c_9n4), window[v[0x737c]](djem, nm4jh, dtfiuk, $v1rwp, p7yv$l, zxabq0, c_9n4);
    }, 'complete': function () {} });
}, window[v[0x737c]] = function (jh4n, _j4, r$p1wv, bz8a0x, b0xq, c3n9_4, _oc439) {
  bz8a0x - 0x1 > 0x0 ? setTimeout(function () {
    window[v[0x16]](jh4n, _j4, r$p1wv, bz8a0x - 0x1, b0xq, c3n9_4);
  }, 0x3e8) : b0xq && b0xq(JSON[v[0x11b5]]({ 'url': jh4n, 'response': _oc439 }));
}, window[v[0x737e]] = function (jmne6h, idtem, aqgz, u6dime, jnhm6e, yv7$, udemt) {
  !aqgz && (aqgz = {});var lpvy$ = Math[v[0x76]](Date[v[0x53]]() / 0x3e8);aqgz[v[0x353]] = lpvy$, aqgz[v[0x737f]] = idtem;var qfktu = Object[v[0x10b]](aqgz)[v[0x436]](),
      o439_ = '',
      ufktd = '';for (var n3c4_ = 0x0; n3c4_ < qfktu[v[0xd]]; n3c4_++) {
    o439_ = o439_ + (n3c4_ == 0x0 ? '' : '&') + qfktu[n3c4_] + aqgz[qfktu[n3c4_]], ufktd = ufktd + (n3c4_ == 0x0 ? '' : '&') + qfktu[n3c4_] + '=' + encodeURIComponent(aqgz[qfktu[n3c4_]]);
  }o439_ = o439_ + D$LZ[v[0x72ee]];var _4j9 = v[0x7380] + md5(o439_);send(jmne6h + '?' + ufktd + (ufktd == '' ? '' : '&') + _4j9, null, u6dime, jnhm6e, yv7$, udemt || function (o35c2) {
    return o35c2[v[0x102e]] == v[0x26eb];
  }, null, v[0x703d]);
}, window['D$LAZS'] = function (zgq0ba, h6mdje) {
  var hmeid = 0x0;D$LZ[v[0x62fe]] && (hmeid = D$LZ[v[0x62fe]][v[0x2d21]]), sendApi(D$LZ[v[0x72ea]], v[0x7381], { 'partnerId': D$LZ[v[0x5cc9]], 'gamePkg': D$LZ[v[0x6304]], 'logTime': Math[v[0x76]](Date[v[0x53]]() / 0x3e8), 'platformUid': D$LZ[v[0x6305]], 'type': zgq0ba, 'serverId': hmeid }, null, 0x2, null, function () {
    return !![];
  });
}, window['D$LZSA'] = function (wp81r$) {
  sendApi(D$LZ[v[0x72e8]], v[0x7382], { 'partner_id': D$LZ[v[0x5cc9]], 'uid': D$LZ[v[0x6303]], 'version': D$LZ[v[0x1285]], 'game_pkg': D$LZ[v[0x6304]], 'device': D$LZ[v[0x6306]] }, D$LZAS, D$AZL, D$ZS);
}, window['D$LZAS'] = function (vpl) {
  if (vpl[v[0x102e]] === v[0x26eb] && vpl[v[0xb]]) {
    vpl[v[0xb]][v[0x15f8]]({ 'id': -0x2, 'name': v[0x7383] }), vpl[v[0xb]][v[0x15f8]]({ 'id': -0x1, 'name': v[0x7384] }), D$LZ[v[0x7385]] = vpl[v[0xb]];if (window[v[0x303b]]) window[v[0x303b]][v[0x7386]]();
  } else D$LZ[v[0x7387]] = ![], window['D$SALZ'](v[0x7388] + vpl[v[0x102e]]);
}, window['D$SAL'] = function (abz8x1) {
  sendApi(D$LZ[v[0x72e8]], v[0x7389], { 'partner_id': D$LZ[v[0x5cc9]], 'uid': D$LZ[v[0x6303]], 'version': D$LZ[v[0x1285]], 'game_pkg': D$LZ[v[0x6304]], 'device': D$LZ[v[0x6306]] }, D$SLA, D$AZL, D$ZS);
}, window['D$SLA'] = function ($wp1vr) {
  D$LZ[v[0x738a]] = ![];if ($wp1vr[v[0x102e]] === v[0x26eb] && $wp1vr[v[0xb]]) {
    for (var enjhm = 0x0; enjhm < $wp1vr[v[0xb]][v[0xd]]; enjhm++) {
      $wp1vr[v[0xb]][enjhm][v[0x6a]] = D$LAS($wp1vr[v[0xb]][enjhm]);
    }D$LZ[v[0x72f1]][-0x1] = window[v[0x738b]]($wp1vr[v[0xb]]), window[v[0x303b]][v[0x738c]](-0x1);
  } else window['D$SALZ'](v[0x738d] + $wp1vr[v[0x102e]]);
}, window[v[0x738e]] = function (n_3c4) {
  sendApi(D$LZ[v[0x72e8]], v[0x7389], { 'partner_id': D$LZ[v[0x5cc9]], 'uid': D$LZ[v[0x6303]], 'version': D$LZ[v[0x1285]], 'game_pkg': D$LZ[v[0x6304]], 'device': D$LZ[v[0x6306]] }, n_3c4, D$AZL, D$ZS);
}, window['D$ASL'] = function (gtqfk0, fzg0qk) {
  sendApi(D$LZ[v[0x72e8]], v[0x738f], { 'partner_id': D$LZ[v[0x5cc9]], 'uid': D$LZ[v[0x6303]], 'version': D$LZ[v[0x1285]], 'game_pkg': D$LZ[v[0x6304]], 'device': D$LZ[v[0x6306]], 'server_group_id': fzg0qk }, D$ALS, D$AZL, D$ZS);
}, window['D$ALS'] = function (hdm6j) {
  D$LZ[v[0x738a]] = ![];if (hdm6j[v[0x102e]] === v[0x26eb] && hdm6j[v[0xb]] && hdm6j[v[0xb]][v[0xb]]) {
    var tqkugf = hdm6j[v[0xb]][v[0x7390]],
        yvlp = [];for (var c_o943 = 0x0; c_o943 < hdm6j[v[0xb]][v[0xb]][v[0xd]]; c_o943++) {
      hdm6j[v[0xb]][v[0xb]][c_o943][v[0x6a]] = D$LAS(hdm6j[v[0xb]][v[0xb]][c_o943]), (yvlp[v[0xd]] == 0x0 || hdm6j[v[0xb]][v[0xb]][c_o943][v[0x6a]] != 0x0) && (yvlp[yvlp[v[0xd]]] = hdm6j[v[0xb]][v[0xb]][c_o943]);
    }D$LZ[v[0x72f1]][tqkugf] = window[v[0x738b]](yvlp), window[v[0x303b]][v[0x738c]](tqkugf);
  } else window['D$SALZ'](v[0x7391] + hdm6j[v[0x102e]]);
}, window['D$YAZL'] = function (w18rx) {
  sendApi(D$LZ[v[0x72e8]], v[0x7392], { 'partner_id': D$LZ[v[0x5cc9]], 'uid': D$LZ[v[0x6303]], 'version': D$LZ[v[0x1285]], 'game_pkg': D$LZ[v[0x6304]], 'device': D$LZ[v[0x6306]] }, reqServerRecommendCallBack, D$AZL, D$ZS);
}, window[v[0x7393]] = function ($7vwy) {
  D$LZ[v[0x738a]] = ![];if ($7vwy[v[0x102e]] === v[0x26eb] && $7vwy[v[0xb]]) {
    for (var a1br8x = 0x0; a1br8x < $7vwy[v[0xb]][v[0xd]]; a1br8x++) {
      $7vwy[v[0xb]][a1br8x][v[0x6a]] = D$LAS($7vwy[v[0xb]][a1br8x]);
    }D$LZ[v[0x72f1]][-0x2] = window[v[0x738b]]($7vwy[v[0xb]]), window[v[0x303b]][v[0x738c]](-0x2);
  } else alert(v[0x7394] + $7vwy[v[0x102e]]);
}, window[v[0x738b]] = function (zq0bga) {
  if (!zq0bga && zq0bga[v[0xd]] <= 0x0) return zq0bga;for (let utfq = 0x0; utfq < zq0bga[v[0xd]]; utfq++) {
    zq0bga[utfq][v[0x7395]] && zq0bga[utfq][v[0x7395]] == 0x1 && (zq0bga[utfq][v[0x7343]] += v[0x7396]);
  }return zq0bga;
}, window['D$LSA'] = function (dmj, zkfqg0) {
  dmj = dmj || D$LZ[v[0x62fe]][v[0x2d21]], sendApi(D$LZ[v[0x72e8]], v[0x7397], { 'type': '4', 'game_pkg': D$LZ[v[0x6304]], 'server_id': dmj }, zkfqg0);
}, window[v[0x7398]] = function (dikfu, qzf0g, gak0zq, figtk) {
  gak0zq = gak0zq || D$LZ[v[0x62fe]][v[0x2d21]], sendApi(D$LZ[v[0x72e8]], v[0x7399], { 'type': dikfu, 'game_pkg': qzf0g, 'server_id': gak0zq }, figtk);
}, window['D$LAS'] = function (tguk) {
  if (tguk) {
    if (tguk[v[0x6a]] == 0x1) {
      if (tguk[v[0x739a]] == 0x1) return 0x2;else return 0x1;
    } else return tguk[v[0x6a]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['D$ZSAL'] = function (dmj6e, n64hm) {
  D$LZ[v[0x739b]] = { 'step': dmj6e, 'server_id': n64hm };var zx8b0a = this;D$SLAZ({ 'title': v[0x739c] }), sendApi(D$LZ[v[0x72e8]], v[0x739d], { 'partner_id': D$LZ[v[0x5cc9]], 'uid': D$LZ[v[0x6303]], 'game_pkg': D$LZ[v[0x6304]], 'server_id': n64hm, 'platform': D$LZ[v[0x62e7]], 'platform_uid': D$LZ[v[0x6305]], 'check_login_time': D$LZ[v[0x733c]], 'check_login_sign': D$LZ[v[0x733b]], 'version_name': D$LZ[v[0x7324]] }, D$ZSLA, D$AZL, D$ZS, function (djhm6) {
    return djhm6[v[0x102e]] == v[0x26eb] || djhm6[v[0x4e]] == v[0x739e] || djhm6[v[0x4e]] == v[0x739f];
  });
}, window['D$ZSLA'] = function (h4jmn) {
  var pw7$vy = this;if (h4jmn[v[0x102e]] === v[0x26eb] && h4jmn[v[0xb]]) {
    var fkdut = D$LZ[v[0x62fe]];fkdut[v[0x73a0]] = D$LZ[v[0x72f2]], fkdut[v[0x2d10]] = String(h4jmn[v[0xb]][v[0x73a1]]), fkdut[v[0x62e9]] = parseInt(h4jmn[v[0xb]][v[0x353]]);if (h4jmn[v[0xb]][v[0x62e8]]) fkdut[v[0x62e8]] = parseInt(h4jmn[v[0xb]][v[0x62e8]]);else fkdut[v[0x62e8]] = parseInt(h4jmn[v[0xb]][v[0x2d21]]);fkdut[v[0x73a2]] = 0x0, fkdut[v[0x11c3]] = D$LZ[v[0x734f]], fkdut[v[0x73a3]] = h4jmn[v[0xb]][v[0x73a4]], fkdut[v[0x73a5]] = h4jmn[v[0xb]][v[0x73a5]], console[v[0x1e2]](v[0x73a6] + JSON[v[0x11b5]](fkdut[v[0x73a5]])), D$LZ[v[0x276]] == 0x1 && fkdut[v[0x73a5]] && fkdut[v[0x73a5]][v[0x73a7]] == 0x1 && (D$LZ[v[0x73a8]] = 0x1, window[v[0x728a]][v[0x94]]['D$YZL']()), D$ZASL();
  } else D$LZ[v[0x739b]][v[0x1bfd]] >= 0x3 ? (D$ZS(JSON[v[0x11b5]](h4jmn)), window['D$SALZ'](v[0x73a9] + h4jmn[v[0x102e]])) : sendApi(D$LZ[v[0x72e8]], v[0x732d], { 'platform': D$LZ[v[0x72e6]], 'partner_id': D$LZ[v[0x5cc9]], 'token': D$LZ[v[0x732b]], 'game_pkg': D$LZ[v[0x6304]], 'deviceId': D$LZ[v[0x6306]], 'scene': v[0x732e] + D$LZ[v[0x72f0]] }, function (nhjm6) {
    if (!nhjm6 || nhjm6[v[0x102e]] != v[0x26eb]) {
      window['D$SALZ'](v[0x733a] + nhjm6 && nhjm6[v[0x102e]]);return;
    }D$LZ[v[0x733b]] = String(nhjm6[v[0x2d10]]), D$LZ[v[0x733c]] = String(nhjm6[v[0x353]]), setTimeout(function () {
      D$ZSAL(D$LZ[v[0x739b]][v[0x1bfd]] + 0x1, D$LZ[v[0x739b]][v[0x2d21]]);
    }, 0x5dc);
  }, D$AZL, D$ZS, function (mh6ie) {
    return mh6ie[v[0x102e]] == v[0x26eb] || mh6ie[v[0x102e]] == v[0x6451];
  });
}, window['D$ZASL'] = function () {
  ServerLoading[v[0x94]][v[0x7347]](D$LZ[v[0x276]]), window['D$AZ'] = !![], window['D$ZLSA']();
}, window['D$ZALS'] = function () {
  if (window['D$ZA'] && window['D$LAZ'] && window[v[0x72f8]] && window[v[0x72f9]] && window['D$LZA'] && window['D$LA']) {
    if (!window[v[0x6fc4]][v[0x94]]) {
      console[v[0x1e2]](v[0x73aa] + window[v[0x6fc4]][v[0x94]]);var gtuqf = wx[v[0x70eb]](),
          tugi = gtuqf[v[0x308]] ? gtuqf[v[0x308]] : 0x0,
          b1xaz8 = { 'cdn': window['D$LZ'][v[0x11c3]], 'spareCdn': window['D$LZ'][v[0x61dc]], 'newRegister': window['D$LZ'][v[0x276]], 'wxPC': window['D$LZ'][v[0x61df]], 'wxIOS': window['D$LZ'][v[0x432]], 'wxAndroid': window['D$LZ'][v[0x2c6f]], 'wxParam': { 'limitLoad': window['D$LZ']['D$YSAZL'], 'benchmarkLevel': window['D$LZ']['D$YSLAZ'], 'wxFrom': window[v[0x22d]][v[0x7201]] == v[0x73ab] ? 0x1 : 0x0, 'wxSDKVersion': window[v[0x728b]] }, 'configType': window['D$LZ'][v[0x2e7b]], 'exposeType': window['D$LZ'][v[0x2ca]], 'scene': tugi };new window[v[0x6fc4]](b1xaz8, window['D$LZ'][v[0x65]], window['D$YSALZ']);
    }
  }
}, window['D$ZLSA'] = function () {
  if (window['D$ZA'] && window['D$LAZ'] && window[v[0x72f8]] && window[v[0x72f9]] && window['D$LZA'] && window['D$LA'] && window['D$AZ'] && window['D$AL']) {
    D$SLZA();if (!D$ZAL) {
      D$ZAL = !![];if (!window[v[0x6fc4]][v[0x94]]) window['D$ZALS']();var vwp$y7 = 0x0,
          tkfiug = wx[v[0x73ac]]();tkfiug && (window['D$LZ'][v[0x72c2]] && (vwp$y7 = tkfiug[v[0x143]]), console[v[0x4e]](v[0x73ad] + tkfiug[v[0x143]] + v[0x73ae] + tkfiug[v[0x4c0]] + v[0x73af] + tkfiug[v[0x4c2]] + v[0x73b0] + tkfiug[v[0x4c1]] + v[0x73b1] + tkfiug[v[0xb0]] + v[0x73b2] + tkfiug[v[0xb1]]));var kz0qg = {};for (const kgf0tq in D$LZ[v[0x62fe]]) {
        kz0qg[kgf0tq] = D$LZ[v[0x62fe]][kgf0tq];
      }var g0zkfq = { 'channel': window['D$LZ'][v[0x6302]], 'account': window['D$LZ'][v[0x6303]], 'userId': window['D$LZ'][v[0x5cc8]], 'serverId': kz0qg[v[0x2d21]], 'cdn': window['D$LZ'][v[0x11c3]], 'data': window['D$LZ'][v[0xb]], 'package': window['D$LZ'][v[0x61dd]], 'newRegister': window['D$LZ'][v[0x276]], 'pkgName': window['D$LZ'][v[0x6304]], 'partnerId': window['D$LZ'][v[0x5cc9]], 'platform_uid': window['D$LZ'][v[0x6305]], 'deviceId': window['D$LZ'][v[0x6306]], 'selectedServer': kz0qg, 'configType': window['D$LZ'][v[0x2e7b]], 'exposeType': window['D$LZ'][v[0x2ca]], 'debugUsers': window['D$LZ'][v[0x3009]], 'wxMenuTop': vwp$y7, 'wxShield': window['D$LZ'][v[0x2e2]] };if (window[v[0x7351]]) for (var emhjn6 in window[v[0x7351]]) {
        g0zkfq[emhjn6] = window[v[0x7351]][emhjn6];
      }window[v[0x6fc4]][v[0x94]]['D$ZLY'](g0zkfq);
    }
  } else console[v[0x4e]](v[0x73b3] + window['D$ZA'] + v[0x73b4] + window['D$LAZ'] + v[0x73b5] + window[v[0x72f8]] + v[0x73b6] + window[v[0x72f9]] + v[0x73b7] + window['D$LZA'] + v[0x73b8] + window['D$LA'] + v[0x73b9] + window['D$AZ'] + v[0x73ba] + window['D$AL']);
};