var v = wx.$d;
import 'dddmain.js';