var v = wx.$d;
require(v[0x7478]);