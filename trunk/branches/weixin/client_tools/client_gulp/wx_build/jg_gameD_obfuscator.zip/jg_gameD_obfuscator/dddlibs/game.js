var v = wx.$d;
require(v[0x79e6]);