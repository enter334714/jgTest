'use strict';

var H = wx.$F;
var fa_jk5v,
    fu6p40 = this && this[H[640436]] || function () {
  var t496pr = Object[H[640437]] || { '__proto__': [] } instanceof Array && function (iab_, o8z1c) {
    iab_[H[640438]] = o8z1c;
  } || function (kai_vb, zhc12) {
    for (var v$jsd in zhc12) zhc12[H[640439]](v$jsd) && (kai_vb[v$jsd] = zhc12[v$jsd]);
  };return function (x0lup, ptr98) {
    function l04xwu() {
      this[H[640440]] = x0lup;
    }t496pr(x0lup, ptr98), x0lup[H[640441]] = null === ptr98 ? Object[H[640442]](ptr98) : (l04xwu[H[640441]] = ptr98[H[640441]], new l04xwu());
  };
}(),
    fz1o = laya['ui'][H[640443]],
    fnbki = laya['ui'][H[640444]];!function (qgdym) {
  var lxne3 = function (yq$smd) {
    function o8r() {
      return yq$smd[H[640445]](this) || this;
    }return fu6p40(o8r, yq$smd), o8r[H[640441]][H[640446]] = function () {
      yq$smd[H[640441]][H[640446]][H[640445]](this), this[H[640447]](qgdym['G$T'][H[640448]]);
    }, o8r[H[640448]] = { 'type': H[640443], 'props': { 'width': 0x2d0, 'name': H[640449], 'height': 0x500 }, 'child': [{ 'type': H[640450], 'props': { 'width': 0x2d0, 'var': H[640451], 'skin': H[640452], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': H[640453], 'props': { 'y': 0x0, 'width': 0x2d0, 'right': 0x0, 'height': 0x500 }, 'child': [{ 'type': H[640450], 'props': { 'width': 0x2d0, 'var': H[640454], 'top': -0x8b, 'skin': H[640455], 'height': 0x8b, 'centerX': 0x0, 'anchorY': 0x1 } }, { 'type': H[640450], 'props': { 'width': 0x2d0, 'var': H[640456], 'top': 0x500, 'skin': H[640457], 'height': 0x8b, 'centerX': 0x0 } }, { 'type': H[640450], 'props': { 'x': -0xdc, 'width': 0xdc, 'var': H[640458], 'skin': H[640459], 'left': -0xdc, 'height': 0x500, 'centerY': 0x0 } }, { 'type': H[640450], 'props': { 'width': 0xdc, 'var': H[640460], 'skin': H[640461], 'left': 0x2d0, 'height': 0x500, 'centerY': 0x0 } }] }] }, o8r;
  }(fz1o);qgdym['G$T'] = lxne3;
}(fa_jk5v || (fa_jk5v = {})), function (ds$v5j) {
  var knab3i = function (k5av_j) {
    function k_avb5() {
      return k5av_j[H[640445]](this) || this;
    }return fu6p40(k_avb5, k5av_j), k_avb5[H[640441]][H[640446]] = function () {
      k5av_j[H[640441]][H[640446]][H[640445]](this), this[H[640447]](ds$v5j['G$l'][H[640448]]);
    }, k_avb5[H[640448]] = { 'type': H[640443], 'props': { 'width': 0x2d0, 'name': H[640462], 'height': 0x500 }, 'child': [{ 'type': H[640450], 'props': { 'width': 0x2d0, 'var': H[640451], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': H[640453], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x2d0, 'height': 0x500 }, 'child': [{ 'type': H[640450], 'props': { 'var': H[640454], 'centerX': 0x0, 'bottom': 0x500, 'anchorY': 0x1 } }, { 'type': H[640450], 'props': { 'var': H[640456], 'top': 0x500, 'centerX': 0x0 } }, { 'type': H[640450], 'props': { 'var': H[640458], 'right': 0x2d0, 'pivotX': 0x1, 'centerY': 0x0 } }, { 'type': H[640450], 'props': { 'var': H[640460], 'left': 0x2d0, 'centerY': 0x0 } }] }, { 'type': H[640450], 'props': { 'var': H[640463], 'skin': H[640464], 'centerX': 0x0, 'bottom': 0xa } }, { 'type': H[640453], 'props': { 'y': 0x3c3, 'x': 0x0, 'width': 0x2d0, 'var': H[640465], 'name': H[640465], 'height': 0x82 }, 'child': [{ 'type': H[640450], 'props': { 'y': 0x2e, 'x': 0x3e, 'width': 0x254, 'var': H[640466], 'skin': H[640467], 'height': 0x1b, 'centerX': 0x0 } }, { 'type': H[640450], 'props': { 'y': 0x31, 'x': 0x40, 'width': 0x24e, 'var': H[640468], 'skin': H[640469], 'height': 0x15 } }, { 'type': H[640450], 'props': { 'y': 0x37, 'x': 0x1fb, 'width': 0xd0, 'var': H[640470], 'skin': H[640471], 'height': 0xb } }, { 'type': H[640450], 'props': { 'y': 0x6, 'x': 0x274, 'width': 0x27, 'var': H[640472], 'skin': H[640473], 'height': 0x74 } }, { 'type': H[640474], 'props': { 'y': 0x30, 'x': 0x125, 'width': 0x86, 'var': H[640475], 'valign': H[640476], 'text': H[640477], 'strokeColor': H[640478], 'stroke': 0x3, 'height': 0x18, 'fontSize': 0x18, 'color': H[640479], 'centerX': 0x0, 'bold': !0x1, 'align': H[640480] } }] }, { 'type': H[640453], 'props': { 'y': 0x429, 'x': 0x0, 'width': 0x2d0, 'var': H[640481], 'name': H[640481], 'height': 0x11 }, 'child': [{ 'type': H[640450], 'props': { 'y': 0x0, 'x': 0x133, 'var': H[640482], 'skin': H[640483], 'centerX': -0x2d } }, { 'type': H[640450], 'props': { 'y': 0x0, 'x': 0x151, 'var': H[640484], 'skin': H[640485], 'centerX': -0xf } }, { 'type': H[640450], 'props': { 'y': 0x0, 'x': 0x16f, 'var': H[640486], 'skin': H[640487], 'centerX': 0xf } }, { 'type': H[640450], 'props': { 'y': 0x0, 'x': 0x18d, 'var': H[640488], 'skin': H[640487], 'centerX': 0x2d } }] }, { 'type': H[640489], 'props': { 'y': 0x316, 'x': 0x37, 'visible': !0x1, 'var': H[640490], 'stateNum': 0x1, 'skin': H[640491], 'name': H[640490], 'labelSize': 0x1e, 'labelFont': H[640492], 'labelColors': H[640493] }, 'child': [{ 'type': H[640474], 'props': { 'y': 0x9b, 'x': 0x92, 'width': 0x143, 'var': H[640494], 'text': H[640495], 'name': H[640494], 'height': 0x1e, 'fontSize': 0x1e, 'color': '#bd4f1e', 'align': H[640480] } }] }, { 'type': H[640474], 'props': { 'y': 0x453, 'width': 0x1f4, 'var': H[640496], 'valign': H[640476], 'text': H[640497], 'height': 0x1a, 'fontSize': 0x1a, 'color': H[640498], 'centerX': 0x0, 'bold': !0x1, 'align': H[640480] } }, { 'type': H[640474], 'props': { 'y': 0xa, 'x': 0xa, 'width': 0x156, 'var': H[640499], 'valign': H[640476], 'top': 0x14, 'text': H[640500], 'strokeColor': H[640501], 'stroke': 0x2, 'right': 0x14, 'height': 0x20, 'fontSize': 0x18, 'color': H[640502], 'bold': !0x1, 'align': H[640105] } }] }, k_avb5;
  }(fz1o);ds$v5j['G$l'] = knab3i;
}(fa_jk5v || (fa_jk5v = {})), function (kbvi) {
  var j$mqd = function ($dmsqy) {
    function jd5$v() {
      return $dmsqy[H[640445]](this) || this;
    }return fu6p40(jd5$v, $dmsqy), jd5$v[H[640441]][H[640446]] = function () {
      fz1o[H[640503]](H[640504], laya[H[640505]][H[640506]][H[640504]]), fz1o[H[640503]](H[640507], laya[H[640508]][H[640507]]), $dmsqy[H[640441]][H[640446]][H[640445]](this), this[H[640447]](kbvi['G$w'][H[640448]]);
    }, jd5$v[H[640448]] = { 'type': H[640443], 'props': { 'width': 0x2d0, 'name': H[640509], 'height': 0x500 }, 'child': [{ 'type': H[640450], 'props': { 'width': 0x2d0, 'var': H[640451], 'skin': H[640452], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': H[640453], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x2d0, 'height': 0x500 }, 'child': [{ 'type': H[640450], 'props': { 'width': 0x2d0, 'var': H[640454], 'skin': H[640455], 'bottom': 0x4ff } }, { 'type': H[640450], 'props': { 'width': 0x2d0, 'var': H[640456], 'top': 0x4ff, 'skin': H[640457] } }, { 'type': H[640450], 'props': { 'var': H[640458], 'skin': H[640459], 'right': 0x2cf, 'height': 0x500 } }, { 'type': H[640450], 'props': { 'var': H[640460], 'skin': H[640461], 'left': 0x2cf, 'height': 0x500 } }] }, { 'type': H[640450], 'props': { 'y': 0x34d, 'var': H[640510], 'skin': H[640511], 'centerX': 0x0 } }, { 'type': H[640450], 'props': { 'y': 0x44e, 'var': H[640512], 'skin': H[640513], 'name': H[640512], 'centerX': 0x0 } }, { 'type': H[640450], 'props': { 'y': 0x3a2, 'x': 0xa2, 'var': H[640514], 'skin': H[640515] } }, { 'type': H[640450], 'props': { 'var': H[640463], 'skin': H[640464], 'centerX': 0x0, 'bottom': 0x1e } }, { 'type': H[640450], 'props': { 'y': 0x3f7, 'var': H[640516], 'stateNum': 0x1, 'skin': H[640517], 'name': H[640516], 'centerX': 0x0 } }, { 'type': H[640450], 'props': { 'x': 0xc4, 'visible': !0x1, 'var': H[640518], 'skin': H[640519], 'bottom': 0x4 } }, { 'type': H[640474], 'props': { 'y': 0x280, 'x': 0x0, 'width': 0x2d0, 'var': H[640520], 'valign': H[640476], 'text': H[640521], 'strokeColor': H[640522], 'stroke': 0x2, 'height': 0x20, 'fontSize': 0x20, 'color': H[640523], 'bold': !0x1, 'align': H[640480] } }, { 'type': H[640474], 'props': { 'y': 0x3a4, 'x': 0x209, 'var': H[640524], 'valign': H[640476], 'text': H[640525], 'height': 0x20, 'fontSize': 0x1e, 'color': H[640526], 'bold': !0x1, 'align': H[640480] } }, { 'type': H[640474], 'props': { 'y': 0x3a4, 'width': 0x156, 'var': H[640527], 'valign': H[640476], 'text': H[640528], 'height': 0x20, 'fontSize': 0x1e, 'color': H[640526], 'centerX': 0x0, 'bold': !0x1, 'align': H[640480] } }, { 'type': H[640474], 'props': { 'width': 0x156, 'var': H[640499], 'valign': H[640476], 'top': 0x14, 'text': H[640500], 'strokeColor': H[640501], 'stroke': 0x2, 'right': 0x14, 'height': 0x20, 'fontSize': 0x18, 'color': H[640502], 'bold': !0x1, 'align': H[640105] } }, { 'type': H[640504], 'props': { 'y': 0x4e7, 'x': 0x100, 'visible': !0x1, 'var': H[640529], 'height': 0x10 } }, { 'type': H[640450], 'props': { 'y': 0x7f, 'x': 593.5, 'var': H[640530], 'skin': H[640531] } }, { 'type': H[640450], 'props': { 'y': 0x101, 'x': 0x252, 'visible': !0x1, 'var': H[640532], 'skin': H[640533], 'name': H[640532] } }, { 'type': H[640450], 'props': { 'y': 0x47, 'x': -0x2, 'visible': !0x1, 'var': H[640534], 'skin': H[640535], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': H[640450], 'props': { 'y': 36.5, 'x': 0x268, 'var': H[640536], 'skin': H[640537] } }, { 'type': H[640474], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': H[640538], 'valign': H[640476], 'text': H[640539], 'height': 0x23, 'fontSize': 0x1e, 'color': H[640522], 'bold': !0x1, 'align': H[640480] } }, { 'type': H[640507], 'props': { 'y': 0x8e, 'x': 0x3d, 'wordWrap': !0x0, 'width': 0x221, 'var': H[640540], 'valign': H[640102], 'overflow': H[640541], 'mouseEnabled': !0x0, 'leading': 0x4, 'height': 0x366, 'fontSize': 0x1a, 'color': H[640542] } }] }, { 'type': H[640450], 'props': { 'y': 0x71, 'x': 0x21, 'visible': !0x1, 'var': H[640543], 'skin': H[640544], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': H[640450], 'props': { 'y': 36.5, 'x': 0x268, 'var': H[640545], 'skin': H[640537] } }, { 'type': H[640489], 'props': { 'y': 0x388, 'x': 0xbe, 'var': H[640546], 'stateNum': 0x1, 'skin': H[640547], 'labelSize': 0x1e, 'labelColors': H[640548], 'label': H[640549] } }, { 'type': H[640453], 'props': { 'y': 0x388, 'x': 0x22, 'width': 0x254, 'var': H[640550], 'height': 0x3b } }, { 'type': H[640474], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': H[640551], 'valign': H[640476], 'text': H[640539], 'height': 0x23, 'fontSize': 0x1e, 'color': H[640522], 'bold': !0x1, 'align': H[640480] } }, { 'type': H[640552], 'props': { 'y': 0x8e, 'x': 0x3d, 'width': 0x221, 'var': H[640553], 'height': 0x2dd }, 'child': [{ 'type': H[640504], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x221, 'var': H[640554], 'height': 0x2dd } }] }] }, { 'type': H[640450], 'props': { 'visible': !0x1, 'var': H[640555], 'skin': H[640544], 'name': H[640555], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': H[640450], 'props': { 'y': 36.5, 'x': 0x268, 'var': H[640556], 'skin': H[640537] } }, { 'type': H[640489], 'props': { 'y': 0x388, 'x': 0xbe, 'var': H[640557], 'stateNum': 0x1, 'skin': H[640547], 'labelSize': 0x1e, 'labelColors': H[640548], 'label': H[640549] } }, { 'type': H[640453], 'props': { 'y': 0x388, 'x': 0x22, 'width': 0x254, 'var': H[640558], 'height': 0x3b } }, { 'type': H[640474], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': H[640559], 'valign': H[640476], 'text': H[640539], 'height': 0x23, 'fontSize': 0x1e, 'color': H[640522], 'bold': !0x1, 'align': H[640480] } }, { 'type': H[640552], 'props': { 'y': 0x8e, 'x': 0x3d, 'width': 0x221, 'var': H[640560], 'height': 0x2dd }, 'child': [{ 'type': H[640504], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x221, 'var': H[640561], 'height': 0x2dd } }] }] }, { 'type': H[640450], 'props': { 'visible': !0x1, 'var': H[640562], 'skin': H[640563], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': H[640453], 'props': { 'y': 0x75, 'x': 0x3d, 'width': 0xc8, 'var': H[640564], 'height': 0x389 } }, { 'type': H[640453], 'props': { 'y': 0x75, 'x': 0x125, 'width': 0x166, 'var': H[640565], 'height': 0x389 } }, { 'type': H[640450], 'props': { 'y': 0xd, 'x': 0x282, 'var': H[640566], 'skin': H[640567] } }] }] }, jd5$v;
  }(fz1o);kbvi['G$w'] = j$mqd;
}(fa_jk5v || (fa_jk5v = {})), function (wixe3) {
  var roz918, u40wlx;roz918 = wixe3['G$u'] || (wixe3['G$u'] = {}), u40wlx = function (vkaj5_) {
    function c89z1o() {
      return vkaj5_[H[640445]](this) || this;
    }return fu6p40(c89z1o, vkaj5_), c89z1o[H[640441]][H[640568]] = function () {
      vkaj5_[H[640441]][H[640568]][H[640445]](this), this[H[640569]] = 0x0, this[H[640570]] = 0x0, this[H[640571]](), this[H[640572]]();
    }, c89z1o[H[640441]][H[640571]] = function () {
      this['on'](Laya[H[640573]][H[640574]], this, this['G$p']);
    }, c89z1o[H[640441]][H[640575]] = function () {
      this[H[640576]](Laya[H[640573]][H[640574]], this, this['G$p']);
    }, c89z1o[H[640441]][H[640572]] = function () {
      this['G$D'] = Date[H[640142]](), fl0e[H[640036]]['f1K2I$A'](), fl0e[H[640036]][H[640577]]();
    }, c89z1o[H[640441]][H[640578]] = function (u046t) {
      void 0x0 === u046t && (u046t = !0x0), this[H[640575]](), vkaj5_[H[640441]][H[640578]][H[640445]](this, u046t);
    }, c89z1o[H[640441]]['G$p'] = function () {
      0x2710 < Date[H[640142]]() - this['G$D'] && (this['G$D'] -= 0x3e8, fqgym[H[640579]]['f1$2'][H[640023]][H[640024]] && (fl0e[H[640036]][H[640580]](), fl0e[H[640036]][H[640581]]()));
    }, c89z1o;
  }(fa_jk5v['G$T']), roz918[H[640582]] = u40wlx;
}(modules || (modules = {})), function (d_sv5j) {
  var uwexl0, r9z8o1, t6r4u, ka3_b, $jsdm5, rpu6t4;uwexl0 = d_sv5j['G$P'] || (d_sv5j['G$P'] = {}), r9z8o1 = Laya[H[640573]], t6r4u = Laya[H[640450]], ka3_b = Laya[H[640583]], $jsdm5 = Laya[H[640584]], rpu6t4 = function (ki3ba_) {
    function yqds() {
      var a3nkib = ki3ba_[H[640445]](this) || this;return a3nkib['G$j'] = new t6r4u(), a3nkib[H[640585]](a3nkib['G$j']), a3nkib['G$J'] = null, a3nkib['G$q'] = [], a3nkib['G$M'] = !0x1, a3nkib['G$z'] = 0x0, a3nkib['G$b'] = !0x0, a3nkib['G$K'] = 0x6, a3nkib['G$Y'] = !0x1, a3nkib['on'](r9z8o1[H[640586]], a3nkib, a3nkib['G$t']), a3nkib['on'](r9z8o1[H[640587]], a3nkib, a3nkib['G$A']), a3nkib;
    }return fu6p40(yqds, ki3ba_), yqds[H[640442]] = function (ab_ki3, i_avkb, x4lu0, jkv5a, a_jv5k, s$dj5v, kin) {
      void 0x0 === jkv5a && (jkv5a = 0x0), void 0x0 === a_jv5k && (a_jv5k = 0x6), void 0x0 === s$dj5v && (s$dj5v = !0x0), void 0x0 === kin && (kin = !0x1);var rp6t89 = new yqds();return rp6t89[H[640588]](i_avkb, x4lu0, jkv5a), rp6t89[H[640589]] = a_jv5k, rp6t89[H[640590]] = s$dj5v, rp6t89[H[640591]] = kin, ab_ki3 && ab_ki3[H[640585]](rp6t89), rp6t89;
    }, yqds[H[640592]] = function (t61r98) {
      t61r98 && (t61r98[H[640593]] = !0x0, t61r98[H[640592]]());
    }, yqds[H[640594]] = function (ymqs) {
      ymqs && (ymqs[H[640593]] = !0x1, ymqs[H[640594]]());
    }, yqds[H[640441]][H[640578]] = function (puxl40) {
      Laya[H[640595]][H[640596]](this, this['G$L']), this[H[640576]](r9z8o1[H[640586]], this, this['G$t']), this[H[640576]](r9z8o1[H[640587]], this, this['G$A']), ki3ba_[H[640441]][H[640578]][H[640445]](this, puxl40);
    }, yqds[H[640441]]['G$t'] = function () {}, yqds[H[640441]]['G$A'] = function () {}, yqds[H[640441]][H[640588]] = function (pl0x, euxl0w, r46up) {
      if (this['G$J'] != pl0x) {
        this['G$J'] = pl0x, this['G$q'] = [];for (var ut6p0 = 0x0, v_kbai = r46up; v_kbai <= euxl0w; v_kbai++) this['G$q'][ut6p0++] = pl0x + '/' + v_kbai + H[640597];var ch1oz2 = $jsdm5[H[640598]](this['G$q'][0x0]);ch1oz2 && (this[H[640425]] = ch1oz2[H[640599]], this[H[640427]] = ch1oz2[H[640600]]), this['G$L']();
      }
    }, Object[H[640601]](yqds[H[640441]], H[640591], { 'get': function () {
        return this['G$Y'];
      }, 'set': function (hcz2) {
        this['G$Y'] = hcz2;
      }, 'enumerable': !0x0, 'configurable': !0x0 }), Object[H[640601]](yqds[H[640441]], H[640589], { 'set': function (wl40u) {
        this['G$K'] != wl40u && (this['G$K'] = wl40u, this['G$M'] && (Laya[H[640595]][H[640596]](this, this['G$L']), Laya[H[640595]][H[640590]](this['G$K'] * (0x3e8 / 0x3c), this, this['G$L'])));
      }, 'enumerable': !0x0, 'configurable': !0x0 }), Object[H[640601]](yqds[H[640441]], H[640590], { 'set': function (jvs5$d) {
        this['G$b'] = jvs5$d;
      }, 'enumerable': !0x0, 'configurable': !0x0 }), yqds[H[640441]][H[640592]] = function () {
      this['G$M'] && this[H[640594]](), this['G$M'] = !0x0, this['G$z'] = 0x0, Laya[H[640595]][H[640590]](this['G$K'] * (0x3e8 / 0x3c), this, this['G$L']), this['G$L']();
    }, yqds[H[640441]][H[640594]] = function () {
      this['G$M'] = !0x1, this['G$z'] = 0x0, this['G$L'](), Laya[H[640595]][H[640596]](this, this['G$L']);
    }, yqds[H[640441]][H[640602]] = function () {
      this['G$M'] && (this['G$M'] = !0x1, Laya[H[640595]][H[640596]](this, this['G$L']));
    }, yqds[H[640441]][H[640603]] = function () {
      this['G$M'] || (this['G$M'] = !0x0, Laya[H[640595]][H[640590]](this['G$K'] * (0x3e8 / 0x3c), this, this['G$L']), this['G$L']());
    }, Object[H[640601]](yqds[H[640441]], H[640604], { 'get': function () {
        return this['G$M'];
      }, 'enumerable': !0x0, 'configurable': !0x0 }), yqds[H[640441]]['G$L'] = function () {
      this['G$q'] && 0x0 != this['G$q'][H[640010]] && (this['G$j'][H[640588]] = this['G$q'][this['G$z']], this['G$M'] && (this['G$z']++, this['G$z'] == this['G$q'][H[640010]] && (this['G$b'] ? this['G$z'] = 0x0 : (Laya[H[640595]][H[640596]](this, this['G$L']), this['G$M'] = !0x1, this['G$Y'] && (this[H[640593]] = !0x1), this[H[640605]](r9z8o1[H[640606]])))));
    }, yqds;
  }(ka3_b), uwexl0[H[640607]] = rpu6t4;
}(modules || (modules = {})), function (m$g7q) {
  var ulx4, ew0n, _5sd;ulx4 = m$g7q['G$u'] || (m$g7q['G$u'] = {}), ew0n = m$g7q['G$P'][H[640607]], _5sd = function (k_v5ba) {
    function jd$v5(_5sjvk) {
      void 0x0 === _5sjvk && (_5sjvk = 0x0);var an3bk = k_v5ba[H[640445]](this) || this;return an3bk['G$i'] = { 'bgImgSkin': H[640608], 'topImgSkin': H[640609], 'btmImgSkin': H[640610], 'leftImgSkin': H[640611], 'rightImgSkin': H[640612], 'loadingBarBgSkin': H[640467], 'copyRightImgBottom': 0xa, 'processBox1Y': 0x3c3, 'processBox2Y': 0x429, 'loadingTipsSize': 0x1a, 'getTipsBtnVisible': !0x1 }, an3bk['G$W'] = { 'bgImgSkin': H[640613], 'topImgSkin': H[640614], 'btmImgSkin': H[640615], 'leftImgSkin': H[640616], 'rightImgSkin': H[640617], 'loadingBarBgSkin': H[640618], 'copyRightImgBottom': 0xa, 'processBox1Y': 0x3c3, 'processBox2Y': 0x429, 'loadingTipsSize': 0x1a, 'getTipsBtnVisible': !0x1 }, an3bk['G$m'] = 0x0, an3bk['G$c'](0x1 == _5sjvk ? an3bk['G$W'] : an3bk['G$i']), an3bk;
    }return fu6p40(jd$v5, k_v5ba), jd$v5[H[640441]][H[640568]] = function () {
      if (k_v5ba[H[640441]][H[640568]][H[640445]](this), fl0e[H[640036]][H[640577]](), this['G$a'] = fqgym[H[640579]]['f1$2'], this[H[640569]] = 0x0, this[H[640570]] = 0x0, this['G$a']) {
        var iav_k = this['G$a'][H[640181]];this[H[640496]][H[640619]] = 0x1 == iav_k ? H[640498] : 0x2 == iav_k ? H[640620] : 0x65 == iav_k ? H[640620] : H[640498];
      }this['G$B'] = [this[H[640482]], this[H[640484]], this[H[640486]], this[H[640488]]], fqgym[H[640579]][H[640621]] = this, f1A$2I(), fl0e[H[640036]][H[640206]](), fl0e[H[640036]][H[640207]](), this[H[640572]]();
    }, jd$v5[H[640441]]['f1A$2'] = function (co2h1) {
      var zc18ho = this;if (-0x1 === co2h1) return zc18ho['G$m'] = 0x0, Laya[H[640595]][H[640596]](this, this['f1A$2']), void Laya[H[640595]][H[640622]](0x1, this, this['f1A$2']);if (-0x2 !== co2h1) {
        zc18ho['G$m'] < 0.9 ? zc18ho['G$m'] += (0.15 * Math[H[640225]]() + 0.01) / (0x64 * Math[H[640225]]() + 0x32) : zc18ho['G$m'] < 0x1 && (zc18ho['G$m'] += 0.0001), 0.9999 < zc18ho['G$m'] && (zc18ho['G$m'] = 0.9999, Laya[H[640595]][H[640596]](this, this['f1A$2']), Laya[H[640595]][H[640623]](0xbb8, this, function () {
          0.9 < zc18ho['G$m'] && f1A$2(-0x1);
        }));var xni3ew = zc18ho['G$m'],
            u0tpl = 0x24e * xni3ew;zc18ho['G$m'] = zc18ho['G$m'] > xni3ew ? zc18ho['G$m'] : xni3ew, zc18ho[H[640468]][H[640425]] = u0tpl;var zo19c = zc18ho[H[640468]]['x'] + u0tpl;zc18ho[H[640472]]['x'] = zo19c - 0xf, 0x16c <= zo19c ? (zc18ho[H[640470]][H[640593]] = !0x0, zc18ho[H[640470]]['x'] = zo19c - 0xca) : zc18ho[H[640470]][H[640593]] = !0x1, zc18ho[H[640475]][H[640357]] = (0x64 * xni3ew >> 0x0) + '%', zc18ho['G$m'] < 0.9999 && Laya[H[640595]][H[640622]](0x1, this, this['f1A$2']);
      } else Laya[H[640595]][H[640596]](this, this['f1A$2']);
    }, jd$v5[H[640441]]['f1A2$'] = function (xn3wle, e3iban, ym$qd) {
      0x1 < xn3wle && (xn3wle = 0x1);var kb3na = 0x24e * xn3wle;this['G$m'] = this['G$m'] > xn3wle ? this['G$m'] : xn3wle, this[H[640468]][H[640425]] = kb3na;var l0wex = this[H[640468]]['x'] + kb3na;this[H[640472]]['x'] = l0wex - 0xf, 0x16c <= l0wex ? (this[H[640470]][H[640593]] = !0x0, this[H[640470]]['x'] = l0wex - 0xca) : this[H[640470]][H[640593]] = !0x1, this[H[640475]][H[640357]] = (0x64 * xn3wle >> 0x0) + '%', this[H[640496]][H[640357]] = e3iban;for (var ak5_b = ym$qd - 0x1, vd5 = 0x0; vd5 < this['G$B'][H[640010]]; vd5++) this['G$B'][vd5][H[640588]] = vd5 < ak5_b ? H[640483] : ak5_b === vd5 ? H[640485] : H[640487];
    }, jd$v5[H[640441]][H[640572]] = function () {
      this['f1A2$'](0.1, H[640624], 0x1), this['f1A$2'](-0x1), fqgym[H[640579]]['f1A$2'] = this['f1A$2'][H[640234]](this), fqgym[H[640579]]['f1A2$'] = this['f1A2$'][H[640234]](this), this[H[640499]][H[640357]] = H[640625] + this['G$a'][H[640020]] + H[640626] + this['G$a'][H[640156]], this[H[640411]]();
    }, jd$v5[H[640441]][H[640627]] = function (myg7q$) {
      this[H[640628]](), Laya[H[640595]][H[640596]](this, this['f1A$2']), Laya[H[640595]][H[640596]](this, this['G$s']), fl0e[H[640036]][H[640208]](), this[H[640490]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$r']);
    }, jd$v5[H[640441]][H[640628]] = function () {
      fqgym[H[640579]]['f1A$2'] = function () {}, fqgym[H[640579]]['f1A2$'] = function () {};
    }, jd$v5[H[640441]][H[640578]] = function (nab3ie) {
      void 0x0 === nab3ie && (nab3ie = !0x0), this[H[640628]](), k_v5ba[H[640441]][H[640578]][H[640445]](this, nab3ie);
    }, jd$v5[H[640441]][H[640411]] = function () {
      this['G$a'][H[640411]] && 0x1 == this['G$a'][H[640411]] && (this[H[640490]][H[640593]] = !0x0, this[H[640490]][H[640629]] = !0x0, this[H[640490]][H[640588]] = H[640491], this[H[640490]]['on'](Laya[H[640573]][H[640574]], this, this['G$r']), this['G$I'](), this['G$Q'](!0x0));
    }, jd$v5[H[640441]]['G$r'] = function () {
      this[H[640490]][H[640629]] && (this[H[640490]][H[640629]] = !0x1, this[H[640490]][H[640588]] = H[640630], this['G$o'](), this['G$Q'](!0x1));
    }, jd$v5[H[640441]]['G$c'] = function (lp40ut) {
      this[H[640451]][H[640588]] = lp40ut[H[640631]], this[H[640454]][H[640588]] = lp40ut[H[640632]], this[H[640456]][H[640588]] = lp40ut[H[640633]], this[H[640458]][H[640588]] = lp40ut[H[640634]], this[H[640460]][H[640588]] = lp40ut[H[640635]], this[H[640463]][H[640103]] = lp40ut[H[640636]], this[H[640465]]['y'] = lp40ut[H[640637]], this[H[640481]]['y'] = lp40ut[H[640638]], this[H[640466]][H[640588]] = lp40ut[H[640639]], this[H[640496]][H[640640]] = lp40ut[H[640641]], this[H[640490]][H[640593]] = this['G$a'][H[640411]] && 0x1 == this['G$a'][H[640411]], this[H[640490]][H[640593]] ? this['G$I']() : this['G$o'](), this['G$Q'](this[H[640490]][H[640593]]);
    }, jd$v5[H[640441]]['G$I'] = function () {
      this['G$e'] || (this['G$e'] = ew0n[H[640442]](this[H[640490]], H[640642], 0x4, 0x0, 0xc), this['G$e'][H[640643]](0xa1, 0x6a), this['G$e'][H[640644]](1.14, 1.15)), ew0n[H[640592]](this['G$e']);
    }, jd$v5[H[640441]]['G$o'] = function () {
      this['G$e'] && ew0n[H[640594]](this['G$e']);
    }, jd$v5[H[640441]]['G$Q'] = function (va5_k) {
      Laya[H[640595]][H[640596]](this, this['G$s']), va5_k ? (this['G$y'] = 0x9, this[H[640494]][H[640593]] = !0x0, this['G$s'](), Laya[H[640595]][H[640590]](0x3e8, this, this['G$s'])) : this[H[640494]][H[640593]] = !0x1;
    }, jd$v5[H[640441]]['G$s'] = function () {
      0x0 < this['G$y'] ? (this[H[640494]][H[640357]] = H[640645] + this['G$y'] + 's)', this['G$y']--) : (this[H[640494]][H[640357]] = '', Laya[H[640595]][H[640596]](this, this['G$s']), this['G$r']());
    }, jd$v5;
  }(fa_jk5v['G$l']), ulx4[H[640646]] = _5sd;
}(modules || (modules = {})), function (t06p) {
  var u6tpr, x0lpu, sm$dy, wen0l;u6tpr = t06p['G$u'] || (t06p['G$u'] = {}), x0lpu = Laya[H[640647]], sm$dy = Laya[H[640573]], wen0l = function (vai_bk) {
    function $y7g() {
      var vs5d$ = vai_bk[H[640445]](this) || this;return vs5d$['G$v'] = 0x0, vs5d$['G$x'] = H[640648], vs5d$['G$R'] = 0x0, vs5d$['G$F'] = 0x0, vs5d$['G$O'] = H[640649], vs5d$;
    }return fu6p40($y7g, vai_bk), $y7g[H[640441]][H[640568]] = function () {
      vai_bk[H[640441]][H[640568]][H[640445]](this), this[H[640569]] = 0x0, this[H[640570]] = 0x0, fl0e[H[640036]]['f1K2I$A'](), this['G$a'] = fqgym[H[640579]]['f1$2'], this['G$$'] = new x0lpu(), this['G$$'][H[640650]] = '', this['G$$'][H[640651]] = u6tpr[H[640652]], this['G$$'][H[640102]] = 0x5, this['G$$'][H[640653]] = 0x1, this['G$$'][H[640654]] = 0x5, this['G$$'][H[640425]] = this[H[640564]][H[640425]], this['G$$'][H[640427]] = this[H[640564]][H[640427]] - 0x8, this[H[640564]][H[640585]](this['G$$']), this['G$Z'] = new x0lpu(), this['G$Z'][H[640650]] = '', this['G$Z'][H[640651]] = u6tpr[H[640655]], this['G$Z'][H[640102]] = 0x5, this['G$Z'][H[640653]] = 0x1, this['G$Z'][H[640654]] = 0x5, this['G$Z'][H[640425]] = this[H[640565]][H[640425]], this['G$Z'][H[640427]] = this[H[640565]][H[640427]] - 0x8, this[H[640565]][H[640585]](this['G$Z']), this['G$H'] = new x0lpu(), this['G$H'][H[640656]] = '', this['G$H'][H[640651]] = u6tpr[H[640657]], this['G$H'][H[640658]] = 0x1, this['G$H'][H[640425]] = this[H[640550]][H[640425]], this['G$H'][H[640427]] = this[H[640550]][H[640427]], this[H[640550]][H[640585]](this['G$H']), this['G$X'] = new x0lpu(), this['G$X'][H[640656]] = '', this['G$X'][H[640651]] = u6tpr[H[640659]], this['G$X'][H[640658]] = 0x1, this['G$X'][H[640425]] = this[H[640550]][H[640425]], this['G$X'][H[640427]] = this[H[640550]][H[640427]], this[H[640558]][H[640585]](this['G$X']);var pltu0 = this['G$a'][H[640181]];this['G$k'] = 0x1 == pltu0 ? H[640526] : 0x2 == pltu0 ? H[640526] : 0x3 == pltu0 ? H[640526] : 0x65 == pltu0 ? H[640526] : H[640660], this[H[640516]][H[640661]](0x1fa, 0x58), this['G$n'] = [], this[H[640530]][H[640593]] = !0x1, this[H[640554]][H[640619]] = H[640542], this[H[640554]][H[640662]][H[640640]] = 0x1a, this[H[640554]][H[640662]][H[640663]] = 0x1c, this[H[640554]][H[640664]] = !0x1, this[H[640561]][H[640619]] = H[640542], this[H[640561]][H[640662]][H[640640]] = 0x1a, this[H[640561]][H[640662]][H[640663]] = 0x1c, this[H[640561]][H[640664]] = !0x1, this[H[640529]][H[640619]] = H[640522], this[H[640529]][H[640662]][H[640640]] = 0x12, this[H[640529]][H[640662]][H[640663]] = 0x12, this[H[640529]][H[640662]][H[640665]] = 0x2, this[H[640529]][H[640662]][H[640666]] = H[640620], this[H[640529]][H[640662]][H[640667]] = !0x1, fqgym[H[640579]][H[640375]] = this, f1A$2I(), this[H[640571]](), this[H[640572]]();
    }, $y7g[H[640441]][H[640578]] = function (jms5d) {
      void 0x0 === jms5d && (jms5d = !0x0), this[H[640575]](), this['G$d'](), this['G$G'](), this['G$N'](), this['G$$'] && (this['G$$'][H[640668]](), this['G$$'][H[640578]](), this['G$$'] = null), this['G$Z'] && (this['G$Z'][H[640668]](), this['G$Z'][H[640578]](), this['G$Z'] = null), this['G$H'] && (this['G$H'][H[640668]](), this['G$H'][H[640578]](), this['G$H'] = null), this['G$X'] && (this['G$X'][H[640668]](), this['G$X'][H[640578]](), this['G$X'] = null), Laya[H[640595]][H[640596]](this, this['G$h']), vai_bk[H[640441]][H[640578]][H[640445]](this, jms5d);
    }, $y7g[H[640441]][H[640571]] = function () {
      this[H[640451]]['on'](Laya[H[640573]][H[640574]], this, this['G$g']), this[H[640516]]['on'](Laya[H[640573]][H[640574]], this, this['G$f']), this[H[640510]]['on'](Laya[H[640573]][H[640574]], this, this['G$U']), this[H[640510]]['on'](Laya[H[640573]][H[640574]], this, this['G$U']), this[H[640566]]['on'](Laya[H[640573]][H[640574]], this, this['G$E']), this[H[640530]]['on'](Laya[H[640573]][H[640574]], this, this['G$V']), this[H[640536]]['on'](Laya[H[640573]][H[640574]], this, this['G$C']), this[H[640540]]['on'](Laya[H[640573]][H[640669]], this, this['G$S']), this[H[640545]]['on'](Laya[H[640573]][H[640574]], this, this['G$_']), this[H[640546]]['on'](Laya[H[640573]][H[640574]], this, this['G$_']), this[H[640553]]['on'](Laya[H[640573]][H[640669]], this, this['G$TT']), this[H[640532]]['on'](Laya[H[640573]][H[640574]], this, this['G$lT']), this[H[640556]]['on'](Laya[H[640573]][H[640574]], this, this['G$wT']), this[H[640557]]['on'](Laya[H[640573]][H[640574]], this, this['G$wT']), this[H[640560]]['on'](Laya[H[640573]][H[640669]], this, this['G$uT']), this[H[640518]]['on'](Laya[H[640573]][H[640574]], this, this['G$pT']), this[H[640529]]['on'](Laya[H[640573]][H[640670]], this, this['G$DT']), this['G$H'][H[640671]] = !0x0, this['G$H'][H[640672]] = Laya[H[640673]][H[640442]](this, this['G$PT'], null, !0x1), this['G$X'][H[640671]] = !0x0, this['G$X'][H[640672]] = Laya[H[640673]][H[640442]](this, this['G$jT'], null, !0x1);
    }, $y7g[H[640441]][H[640575]] = function () {
      this[H[640451]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$g']), this[H[640516]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$f']), this[H[640510]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$U']), this[H[640510]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$U']), this[H[640566]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$E']), this[H[640530]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$V']), this[H[640536]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$C']), this[H[640540]][H[640576]](Laya[H[640573]][H[640669]], this, this['G$S']), this[H[640545]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$_']), this[H[640546]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$_']), this[H[640553]][H[640576]](Laya[H[640573]][H[640669]], this, this['G$TT']), this[H[640532]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$lT']), this[H[640556]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$wT']), this[H[640557]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$wT']), this[H[640560]][H[640576]](Laya[H[640573]][H[640669]], this, this['G$uT']), this[H[640518]][H[640576]](Laya[H[640573]][H[640574]], this, this['G$pT']), this[H[640529]][H[640576]](Laya[H[640573]][H[640670]], this, this['G$DT']), this['G$H'][H[640671]] = !0x1, this['G$H'][H[640672]] = null, this['G$X'][H[640671]] = !0x1, this['G$X'][H[640672]] = null;
    }, $y7g[H[640441]][H[640572]] = function () {
      var lwexn = this;this['G$D'] = Date[H[640142]](), this['G$JT'] = this['G$a'][H[640023]][H[640024]], this['G$qT'](this['G$a'][H[640023]]), this['G$$'][H[640674]] = this['G$a'][H[640374]], this['G$U'](), req_multi_server_notice(0x4, this['G$a'][H[640022]], this['G$a'][H[640023]][H[640024]], this['G$MT'][H[640234]](this)), Laya[H[640595]][H[640675]](0x2, this, function () {
        lwexn['G$zT'] = lwexn['G$a'][H[640676]] && lwexn['G$a'][H[640676]][H[640677]] ? lwexn['G$a'][H[640676]][H[640677]] : [], lwexn['G$bT'] = null != lwexn['G$a'][H[640678]] ? lwexn['G$a'][H[640678]] : 0x0;var uelx0w = '1' == localStorage[H[640679]](lwexn['G$O']),
            j_va5 = 0x0 != f1$2[H[640680]],
            ikb_3a = 0x0 == lwexn['G$bT'] || 0x1 == lwexn['G$bT'];lwexn['G$KT'] = j_va5 && uelx0w || ikb_3a, lwexn['G$YT']();
      }), this[H[640499]][H[640357]] = H[640625] + this['G$a'][H[640020]] + H[640626] + this['G$a'][H[640156]], this[H[640527]][H[640619]] = this[H[640524]][H[640619]] = this['G$k'], this[H[640512]][H[640593]] = 0x1 == this['G$a'][H[640681]], this[H[640520]][H[640593]] = !0x1;
    }, $y7g[H[640441]][H[640682]] = function () {}, $y7g[H[640441]]['G$g'] = function () {
      this['G$KT'] ? 0x2710 < Date[H[640142]]() - this['G$D'] && (this['G$D'] -= 0x7d0, fl0e[H[640036]][H[640580]]()) : this['G$tT'](H[640683]);
    }, $y7g[H[640441]]['G$f'] = function () {
      this['G$KT'] ? this['G$AT'](this['G$a'][H[640023]]) && (fqgym[H[640579]]['f1$2'][H[640023]] = this['G$a'][H[640023]], f12AI$(0x0, this['G$a'][H[640023]][H[640024]])) : this['G$tT'](H[640683]);
    }, $y7g[H[640441]]['G$U'] = function () {
      this['G$a'][H[640377]] ? this[H[640562]][H[640593]] = !0x0 : (this['G$a'][H[640377]] = !0x0, f1$2AI(0x0));
    }, $y7g[H[640441]]['G$E'] = function () {
      this[H[640562]][H[640593]] = !0x1;
    }, $y7g[H[640441]]['G$V'] = function () {
      this['G$LT']();
    }, $y7g[H[640441]]['G$_'] = function () {
      this[H[640543]][H[640593]] = !0x1;
    }, $y7g[H[640441]]['G$C'] = function () {
      this[H[640534]][H[640593]] = !0x1;
    }, $y7g[H[640441]]['G$lT'] = function () {
      this['G$iT']();
    }, $y7g[H[640441]]['G$wT'] = function () {
      this[H[640555]][H[640593]] = !0x1;
    }, $y7g[H[640441]]['G$pT'] = function () {
      this['G$KT'] = !this['G$KT'], this['G$KT'] && localStorage[H[640684]](this['G$O'], '1'), this[H[640518]][H[640588]] = H[640685] + (this['G$KT'] ? H[640686] : H[640687]);
    }, $y7g[H[640441]]['G$DT'] = function (qdmys$) {
      this['G$iT'](Number(qdmys$));
    }, $y7g[H[640441]]['G$S'] = function () {
      this['G$v'] = this[H[640540]][H[640688]], Laya[H[640689]]['on'](sm$dy[H[640690]], this, this['G$WT']), Laya[H[640689]]['on'](sm$dy[H[640691]], this, this['G$d']), Laya[H[640689]]['on'](sm$dy[H[640692]], this, this['G$d']);
    }, $y7g[H[640441]]['G$WT'] = function () {
      if (this[H[640540]]) {
        var r19zo8 = this['G$v'] - this[H[640540]][H[640688]];this[H[640540]][H[640693]] += r19zo8, this['G$v'] = this[H[640540]][H[640688]];
      }
    }, $y7g[H[640441]]['G$d'] = function () {
      Laya[H[640689]][H[640576]](sm$dy[H[640690]], this, this['G$WT']), Laya[H[640689]][H[640576]](sm$dy[H[640691]], this, this['G$d']), Laya[H[640689]][H[640576]](sm$dy[H[640692]], this, this['G$d']);
    }, $y7g[H[640441]]['G$TT'] = function () {
      this['G$R'] = this[H[640553]][H[640688]], Laya[H[640689]]['on'](sm$dy[H[640690]], this, this['G$mT']), Laya[H[640689]]['on'](sm$dy[H[640691]], this, this['G$G']), Laya[H[640689]]['on'](sm$dy[H[640692]], this, this['G$G']);
    }, $y7g[H[640441]]['G$mT'] = function () {
      if (this[H[640554]]) {
        var a3_ki = this['G$R'] - this[H[640553]][H[640688]];this[H[640554]]['y'] -= a3_ki, this[H[640553]][H[640427]] < this[H[640554]][H[640694]] ? this[H[640554]]['y'] < this[H[640553]][H[640427]] - this[H[640554]][H[640694]] ? this[H[640554]]['y'] = this[H[640553]][H[640427]] - this[H[640554]][H[640694]] : 0x0 < this[H[640554]]['y'] && (this[H[640554]]['y'] = 0x0) : this[H[640554]]['y'] = 0x0, this['G$R'] = this[H[640553]][H[640688]];
      }
    }, $y7g[H[640441]]['G$G'] = function () {
      Laya[H[640689]][H[640576]](sm$dy[H[640690]], this, this['G$mT']), Laya[H[640689]][H[640576]](sm$dy[H[640691]], this, this['G$G']), Laya[H[640689]][H[640576]](sm$dy[H[640692]], this, this['G$G']);
    }, $y7g[H[640441]]['G$uT'] = function () {
      this['G$F'] = this[H[640560]][H[640688]], Laya[H[640689]]['on'](sm$dy[H[640690]], this, this['G$cT']), Laya[H[640689]]['on'](sm$dy[H[640691]], this, this['G$N']), Laya[H[640689]]['on'](sm$dy[H[640692]], this, this['G$N']);
    }, $y7g[H[640441]]['G$cT'] = function () {
      if (this[H[640561]]) {
        var qgm7$y = this['G$F'] - this[H[640560]][H[640688]];this[H[640561]]['y'] -= qgm7$y, this[H[640560]][H[640427]] < this[H[640561]][H[640694]] ? this[H[640561]]['y'] < this[H[640560]][H[640427]] - this[H[640561]][H[640694]] ? this[H[640561]]['y'] = this[H[640560]][H[640427]] - this[H[640561]][H[640694]] : 0x0 < this[H[640561]]['y'] && (this[H[640561]]['y'] = 0x0) : this[H[640561]]['y'] = 0x0, this['G$F'] = this[H[640560]][H[640688]];
      }
    }, $y7g[H[640441]]['G$N'] = function () {
      Laya[H[640689]][H[640576]](sm$dy[H[640690]], this, this['G$cT']), Laya[H[640689]][H[640576]](sm$dy[H[640691]], this, this['G$N']), Laya[H[640689]][H[640576]](sm$dy[H[640692]], this, this['G$N']);
    }, $y7g[H[640441]]['G$PT'] = function () {
      if (this['G$H'][H[640674]]) {
        for (var smqdj$, u04px = 0x0; u04px < this['G$H'][H[640674]][H[640010]]; u04px++) {
          var b3ena = this['G$H'][H[640674]][u04px];b3ena[0x1] = u04px == this['G$H'][H[640695]], u04px == this['G$H'][H[640695]] && (smqdj$ = b3ena[0x0]);
        }smqdj$ && smqdj$[H[640696]] && (smqdj$[H[640696]] = smqdj$[H[640696]][H[640008]](/(<)(?!(br)).[a-zA-Z]{0,10}(>)/g, '')), this[H[640551]][H[640357]] = smqdj$ && smqdj$[H[640697]] ? smqdj$[H[640697]] : '', this[H[640554]][H[640698]] = smqdj$ && smqdj$[H[640696]] ? smqdj$[H[640696]] : '', this[H[640554]]['y'] = 0x0;
      }
    }, $y7g[H[640441]]['G$jT'] = function () {
      if (this['G$X'][H[640674]]) {
        for (var t8r6p, t96r81 = 0x0; t96r81 < this['G$X'][H[640674]][H[640010]]; t96r81++) {
          var sv5jk = this['G$X'][H[640674]][t96r81];sv5jk[0x1] = t96r81 == this['G$X'][H[640695]], t96r81 == this['G$X'][H[640695]] && (t8r6p = sv5jk[0x0]);
        }t8r6p && t8r6p[H[640696]] && (t8r6p[H[640696]] = t8r6p[H[640696]][H[640008]](/(<)(?!(br)).[a-zA-Z]{0,10}(>)/g, '')), this[H[640559]][H[640357]] = t8r6p && t8r6p[H[640697]] ? t8r6p[H[640697]] : '', this[H[640561]][H[640698]] = t8r6p && t8r6p[H[640696]] ? t8r6p[H[640696]] : '', this[H[640561]]['y'] = 0x0;
      }
    }, $y7g[H[640441]]['G$qT'] = function (put640) {
      this[H[640527]][H[640357]] = -0x1 === put640[H[640291]] ? put640[H[640287]] + H[640699] : 0x0 === put640[H[640291]] ? put640[H[640287]] + H[640700] : put640[H[640287]], this[H[640527]][H[640619]] = -0x1 === put640[H[640291]] ? H[640701] : 0x0 === put640[H[640291]] ? H[640702] : this['G$k'], this[H[640514]][H[640588]] = this[H[640703]](put640[H[640291]]), this['G$a'][H[640021]] = put640[H[640021]] || '', this['G$a'][H[640023]] = put640, this[H[640530]][H[640593]] = !0x0;
    }, $y7g[H[640441]]['G$aT'] = function (vbka_5) {
      this[H[640376]](vbka_5);
    }, $y7g[H[640441]]['G$BT'] = function (tp6r4u) {
      this['G$qT'](tp6r4u), this[H[640562]][H[640593]] = !0x1;
    }, $y7g[H[640441]][H[640376]] = function (_5dvj) {
      if (void 0x0 === _5dvj && (_5dvj = 0x0), this[H[640704]]) {
        var lt0u4 = this['G$a'][H[640374]];if (lt0u4 && 0x0 !== lt0u4[H[640010]]) {
          for (var ym7g$ = lt0u4[H[640010]], bk5va_ = 0x0; bk5va_ < ym7g$; bk5va_++) lt0u4[bk5va_][H[640705]] = this['G$aT'][H[640234]](this), lt0u4[bk5va_][H[640706]] = bk5va_ == _5dvj, lt0u4[bk5va_][H[640707]] = bk5va_;var svj5k = (this['G$$'][H[640708]] = lt0u4)[_5dvj]['id'];this['G$a'][H[640170]][svj5k] ? this[H[640382]](svj5k) : this['G$a'][H[640380]] || (this['G$a'][H[640380]] = !0x0, -0x1 == svj5k ? f1AI$(0x0) : -0x2 == svj5k ? f1KI2$(0x0) : f1IA$(0x0, svj5k));
        }
      }
    }, $y7g[H[640441]][H[640382]] = function (_abik3) {
      if (this[H[640704]] && this['G$a'][H[640170]][_abik3]) {
        for (var $ydgq = this['G$a'][H[640170]][_abik3], $ymgdq = $ydgq[H[640010]], $dgmqy = 0x0; $dgmqy < $ymgdq; $dgmqy++) $ydgq[$dgmqy][H[640705]] = this['G$BT'][H[640234]](this);this['G$Z'][H[640708]] = $ydgq;
      }
    }, $y7g[H[640441]]['G$AT'] = function (mqdy) {
      return -0x1 == mqdy[H[640291]] ? (alert(H[640709]), !0x1) : 0x0 != mqdy[H[640291]] || (alert(H[640710]), !0x1);
    }, $y7g[H[640441]][H[640703]] = function (kav_j) {
      var p6ut0 = '';return 0x2 === kav_j ? p6ut0 = H[640515] : 0x1 === kav_j ? p6ut0 = H[640711] : -0x1 !== kav_j && 0x0 !== kav_j || (p6ut0 = H[640712]), p6ut0;
    }, $y7g[H[640441]]['G$MT'] = function (v_iba) {
      console[H[640042]](H[640713], v_iba);var tu6p4 = Date[H[640142]]() / 0x3e8,
          q7gmy$ = localStorage[H[640679]](this['G$x']),
          oc18z = !(this['G$n'] = []);if (H[640272] == v_iba[H[640201]]) for (var abne3 in v_iba[H[640200]]) {
        var kna3ib = v_iba[H[640200]][abne3],
            k_ba3 = tu6p4 < kna3ib[H[640714]],
            ch1zo2 = 0x1 == kna3ib[H[640715]],
            _bvia = 0x2 == kna3ib[H[640715]] && kna3ib[H[640716]] + '' != q7gmy$;!oc18z && k_ba3 && (ch1zo2 || _bvia) && (oc18z = !0x0), k_ba3 && this['G$n'][H[640039]](kna3ib), _bvia && localStorage[H[640684]](this['G$x'], kna3ib[H[640716]] + '');
      }this['G$n'][H[640366]](function (dj$m, d$qmsy) {
        return dj$m[H[640717]] - d$qmsy[H[640717]];
      }), console[H[640042]](H[640718], this['G$n']), oc18z && this['G$LT']();
    }, $y7g[H[640441]]['G$LT'] = function () {
      if (this['G$H']) {
        if (this['G$n']) {
          this['G$H']['x'] = 0x2 < this['G$n'][H[640010]] ? 0x0 : (this[H[640550]][H[640425]] - 0x112 * this['G$n'][H[640010]]) / 0x2;for (var xne3wi = [], len3w = 0x0; len3w < this['G$n'][H[640010]]; len3w++) {
            var knab3 = this['G$n'][len3w];xne3wi[H[640039]]([knab3, len3w == this['G$H'][H[640695]]]);
          }0x0 < (this['G$H'][H[640674]] = xne3wi)[H[640010]] ? (this['G$H'][H[640695]] = 0x0, this['G$H'][H[640719]](0x0)) : (this[H[640551]][H[640357]] = H[640539], this[H[640554]][H[640357]] = ''), this[H[640546]][H[640593]] = this['G$n'][H[640010]] <= 0x1, this[H[640550]][H[640593]] = 0x1 < this['G$n'][H[640010]];
        }this[H[640543]][H[640593]] = !0x0;
      }
    }, $y7g[H[640441]]['G$YT'] = function () {
      for (var nba3ik = '', w0lux4 = 0x0; w0lux4 < this['G$zT'][H[640010]]; w0lux4++) {
        nba3ik += H[640720] + w0lux4 + H[640721] + this['G$zT'][w0lux4][H[640697]] + H[640722], w0lux4 < this['G$zT'][H[640010]] - 0x1 && (nba3ik += '、');
      }this[H[640529]][H[640698]] = H[640723] + nba3ik, this[H[640518]][H[640588]] = H[640685] + (this['G$KT'] ? H[640686] : H[640687]), this[H[640529]]['x'] = (0x2d0 - this[H[640529]][H[640425]]) / 0x2, this[H[640518]]['x'] = this[H[640529]]['x'] - 0x1e, this[H[640532]][H[640593]] = 0x0 < this['G$zT'][H[640010]], this[H[640518]][H[640593]] = this[H[640529]][H[640593]] = 0x0 < this['G$zT'][H[640010]] && 0x0 != this['G$bT'];
    }, $y7g[H[640441]]['G$iT'] = function (dygq$m) {
      if (void 0x0 === dygq$m && (dygq$m = 0x0), this['G$X']) {
        if (this['G$zT']) {
          this['G$X']['x'] = 0x2 < this['G$zT'][H[640010]] ? 0x0 : (this[H[640550]][H[640425]] - 0x112 * this['G$zT'][H[640010]]) / 0x2;for (var k_svj = [], $js5dm = 0x0; $js5dm < this['G$zT'][H[640010]]; $js5dm++) {
            var bikav_ = this['G$zT'][$js5dm];k_svj[H[640039]]([bikav_, $js5dm == this['G$X'][H[640695]]]);
          }0x0 < (this['G$X'][H[640674]] = k_svj)[H[640010]] ? (this['G$X'][H[640695]] = dygq$m, this['G$X'][H[640719]](dygq$m)) : (this[H[640559]][H[640357]] = H[640724], this[H[640561]][H[640357]] = ''), this[H[640557]][H[640593]] = this['G$zT'][H[640010]] <= 0x1, this[H[640558]][H[640593]] = 0x1 < this['G$zT'][H[640010]];
        }this[H[640555]][H[640593]] = !0x0;
      }
    }, $y7g[H[640441]]['G$tT'] = function (g7q$m) {
      this[H[640520]][H[640357]] = g7q$m, this[H[640520]]['y'] = 0x280, this[H[640520]][H[640593]] = !0x0, this['G$sT'] = 0x1, Laya[H[640595]][H[640596]](this, this['G$h']), this['G$h'](), Laya[H[640595]][H[640622]](0x1, this, this['G$h']);
    }, $y7g[H[640441]]['G$h'] = function () {
      this[H[640520]]['y'] -= this['G$sT'], this['G$sT'] *= 1.1, this[H[640520]]['y'] <= 0x24e && (this[H[640520]][H[640593]] = !0x1, Laya[H[640595]][H[640596]](this, this['G$h']));
    }, $y7g;
  }(fa_jk5v['G$w']), u6tpr[H[640725]] = wen0l;
}(modules || (modules = {}));var modules,
    fqgym = Laya[H[640726]],
    f$ydmg = Laya[H[640727]],
    fka5b_ = Laya[H[640728]],
    fu40pt6 = Laya[H[640729]],
    f$sqdmj = Laya[H[640673]],
    fqm$dys = modules['G$u'][H[640582]],
    fnaeb3 = modules['G$u'][H[640646]],
    ft4u6p = modules['G$u'][H[640725]],
    fl0e = function () {
  function s$dm5j(mgq$7) {
    this[H[640730]] = [H[640467], H[640618], H[640469], H[640471], H[640473], H[640487], H[640485], H[640483], H[640731], H[640732], H[640733], H[640734], H[640735], H[640608], H[640613], H[640491], H[640630], H[640610], H[640611], H[640612], H[640609], H[640615], H[640616], H[640617], H[640614]], this['f1K2I$'] = [H[640537], H[640531], H[640517], H[640533], H[640736], H[640737], H[640738], H[640567], H[640515], H[640711], H[640712], H[640511], H[640452], H[640457], H[640459], H[640461], H[640455], H[640464], H[640535], H[640563], H[640739], H[640547], H[640740], H[640544], H[640513], H[640519], H[640741]], this[H[640742]] = !0x1, this[H[640743]] = !0x1, this['G$rT'] = !0x1, this['G$IT'] = '', s$dm5j[H[640036]] = this, Laya[H[640744]][H[640233]](), Laya3D[H[640233]](0x0, 0x0, !0x1, !0x1, !0x1), DecodeTools[H[640233]](), Laya[H[640689]][H[640745]] = Laya[H[640746]][H[640747]], Laya[H[640689]][H[640748]] = Laya[H[640746]][H[640749]], Laya[H[640689]][H[640750]] = Laya[H[640746]][H[640751]], Laya[H[640689]][H[640752]] = Laya[H[640746]][H[640753]], Laya[H[640689]][H[640754]] = Laya[H[640746]][H[640755]];var vakj_5 = Laya[H[640756]];vakj_5[H[640757]] = 0x6, vakj_5[H[640758]] = vakj_5[H[640759]] = 0x400, vakj_5[H[640760]](), Laya[H[640761]][H[640762]] = Laya[H[640761]][H[640763]] = '', Laya[H[640726]][H[640579]][H[640764]](Laya[H[640573]][H[640765]], this['G$QT'][H[640234]](this)), Laya[H[640584]][H[640766]][H[640767]] = { 'frames': { 'btn_chuangjue_kaishi.png': { 'frame': { 'h': 0x58, 'idx': 0x0, 'w': 0x1fa, 'x': 0x0, 'y': 0x0 }, 'sourceSize': { 'h': 0x58, 'w': 0x1fa }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'btn_chuangjue_nan.png': { 'frame': { 'h': 0x62, 'idx': 0x0, 'w': 0x6c, 'x': 0x14f, 'y': 0x59 }, 'sourceSize': { 'h': 0x62, 'w': 0x6c }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'btn_chuangjue_nv.png': { 'frame': { 'h': 0x62, 'idx': 0x0, 'w': 0x6b, 'x': 0x0, 'y': 0xa4 }, 'sourceSize': { 'h': 0x62, 'w': 0x6b }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'image_chuangjue_mingbg.png': { 'frame': { 'h': 0x4a, 'idx': 0x0, 'w': 0x14e, 'x': 0x0, 'y': 0x59 }, 'sourceSize': { 'h': 0x4a, 'w': 0x14e }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'image_chuangjue_suiji.png': { 'frame': { 'h': 0x38, 'idx': 0x0, 'w': 0x34, 'x': 0x1bc, 'y': 0x59 }, 'sourceSize': { 'h': 0x38, 'w': 0x34 }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'z999z99928b.png': { 'frame': { 'h': 0x19, 'idx': 0x0, 'w': 0x19, 'x': 0x1bc, 'y': 0x92 }, 'sourceSize': { 'h': 0x1b, 'w': 0x1a }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x2 } }, 'z999z99929b.png': { 'frame': { 'h': 0x1b, 'idx': 0x0, 'w': 0x1a, 'x': 0x1d6, 'y': 0x92 }, 'sourceSize': { 'h': 0x1b, 'w': 0x1a }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } } }, 'meta': { 'image': H[640768], 'prefix': H[640769] } }, fqgym[H[640579]][H[640770]] = s$dm5j[H[640036]]['f1K$2'], fqgym[H[640579]][H[640771]] = s$dm5j[H[640036]]['f1K$2'], this[H[640772]] = new Laya[H[640583]](), this[H[640772]][H[640773]] = H[640774], Laya[H[640689]][H[640585]](this[H[640772]]), this['G$QT']();
  }return s$dm5j[H[640441]]['f1A2I$'] = function (wnelx) {
    s$dm5j[H[640036]][H[640772]][H[640593]] = wnelx;
  }, s$dm5j[H[640441]]['f1KI$2A'] = function () {
    s$dm5j[H[640036]][H[640775]] || (s$dm5j[H[640036]][H[640775]] = new fqm$dys()), s$dm5j[H[640036]][H[640775]][H[640704]] || s$dm5j[H[640036]][H[640772]][H[640585]](s$dm5j[H[640036]][H[640775]]), s$dm5j[H[640036]]['G$oT']();
  }, s$dm5j[H[640441]][H[640206]] = function () {
    this[H[640775]] && this[H[640775]][H[640704]] && (Laya[H[640689]][H[640776]](this[H[640775]]), this[H[640775]][H[640578]](!0x0), this[H[640775]] = null);
  }, s$dm5j[H[640441]]['f1K2I$A'] = function () {
    this[H[640742]] || (this[H[640742]] = !0x0, Laya[H[640777]][H[640778]](this['f1K2I$'], f$sqdmj[H[640442]](this, function () {
      fqgym[H[640579]][H[640183]] = !0x0, fqgym[H[640579]]['f12I$A'](), fqgym[H[640579]]['f12$AI']();
    })));
  }, s$dm5j[H[640441]][H[640295]] = function () {
    for (var jkv_5 = function () {
      s$dm5j[H[640036]][H[640779]] || (s$dm5j[H[640036]][H[640779]] = new ft4u6p()), s$dm5j[H[640036]][H[640779]][H[640704]] || s$dm5j[H[640036]][H[640772]][H[640585]](s$dm5j[H[640036]][H[640779]]), s$dm5j[H[640036]]['G$oT']();
    }, r6918z = !0x0, nw3be = 0x0, jd$vs5 = this['f1K2I$']; nw3be < jd$vs5[H[640010]]; nw3be++) {
      var l3xewn = jd$vs5[nw3be];if (null == Laya[H[640584]][H[640598]](l3xewn)) {
        r6918z = !0x1;break;
      }
    }r6918z ? jkv_5() : Laya[H[640777]][H[640778]](this['f1K2I$'], f$sqdmj[H[640442]](this, jkv_5));
  }, s$dm5j[H[640441]][H[640207]] = function () {
    this[H[640779]] && this[H[640779]][H[640704]] && (Laya[H[640689]][H[640776]](this[H[640779]]), this[H[640779]][H[640578]](!0x0), this[H[640779]] = null);
  }, s$dm5j[H[640441]][H[640577]] = function () {
    this[H[640743]] || (this[H[640743]] = !0x0, Laya[H[640777]][H[640778]](this[H[640730]], f$sqdmj[H[640442]](this, function () {
      fqgym[H[640579]][H[640184]] = !0x0, fqgym[H[640579]]['f12I$A'](), fqgym[H[640579]]['f12$AI']();
    })));
  }, s$dm5j[H[640441]][H[640294]] = function (l0uex) {
    void 0x0 === l0uex && (l0uex = 0x0), Laya[H[640777]][H[640778]](this[H[640730]], f$sqdmj[H[640442]](this, function () {
      s$dm5j[H[640036]][H[640780]] || (s$dm5j[H[640036]][H[640780]] = new fnaeb3(l0uex)), s$dm5j[H[640036]][H[640780]][H[640704]] || s$dm5j[H[640036]][H[640772]][H[640585]](s$dm5j[H[640036]][H[640780]]), s$dm5j[H[640036]]['G$oT']();
    }));
  }, s$dm5j[H[640441]][H[640208]] = function () {
    this[H[640780]] && this[H[640780]][H[640704]] && (Laya[H[640689]][H[640776]](this[H[640780]]), this[H[640780]][H[640578]](!0x0), this[H[640780]] = null);for (var rz619 = 0x0, p4u0t = this['f1K2I$']; rz619 < p4u0t[H[640010]]; rz619++) {
      var qydg$ = p4u0t[rz619];Laya[H[640584]][H[640781]](s$dm5j[H[640036]], qydg$), Laya[H[640584]][H[640782]](qydg$, !0x0);
    }for (var $smj = 0x0, ieanb = this[H[640730]]; $smj < ieanb[H[640010]]; $smj++) {
      qydg$ = ieanb[$smj], (Laya[H[640584]][H[640781]](s$dm5j[H[640036]], qydg$), Laya[H[640584]][H[640782]](qydg$, !0x0));
    }this[H[640772]][H[640704]] && this[H[640772]][H[640704]][H[640776]](this[H[640772]]);
  }, s$dm5j[H[640441]]['f1K2$'] = function () {
    this[H[640780]] && this[H[640780]][H[640704]] && s$dm5j[H[640036]][H[640780]][H[640411]]();
  }, s$dm5j[H[640441]][H[640580]] = function () {
    var aik = fqgym[H[640579]]['f1$2'][H[640023]];this['G$rT'] || -0x1 == aik[H[640291]] || 0x0 == aik[H[640291]] || (this['G$rT'] = !0x0, fqgym[H[640579]]['f1$2'][H[640023]] = aik, f12AI$(0x0, aik[H[640024]]));
  }, s$dm5j[H[640441]][H[640581]] = function () {
    var z9186r = '';z9186r += H[640783] + fqgym[H[640579]]['f1$2'][H[640285]], z9186r += H[640784] + this[H[640742]], z9186r += H[640785] + (null != s$dm5j[H[640036]][H[640779]]), z9186r += H[640786] + this[H[640743]], z9186r += H[640787] + (null != s$dm5j[H[640036]][H[640780]]), z9186r += H[640788] + (fqgym[H[640579]][H[640770]] == s$dm5j[H[640036]]['f1K$2']), z9186r += H[640789] + (fqgym[H[640579]][H[640771]] == s$dm5j[H[640036]]['f1K$2']), z9186r += H[640790] + s$dm5j[H[640036]]['G$IT'];for (var $djs5 = 0x0, pr98t6 = this['f1K2I$']; $djs5 < pr98t6[H[640010]]; $djs5++) {
      z9186r += ',\x20' + (m$dsy = pr98t6[$djs5]) + '=' + (null != Laya[H[640584]][H[640598]](m$dsy));
    }for (var abkn = 0x0, dy$mq = this[H[640730]]; abkn < dy$mq[H[640010]]; abkn++) {
      var m$dsy;z9186r += ',\x20' + (m$dsy = dy$mq[abkn]) + '=' + (null != Laya[H[640584]][H[640598]](m$dsy));
    }var sv5jk_ = fqgym[H[640579]]['f1$2'][H[640023]];sv5jk_ && (z9186r += H[640791] + sv5jk_[H[640291]], z9186r += H[640792] + sv5jk_[H[640024]], z9186r += H[640793] + sv5jk_[H[640287]]);var u4t60 = JSON[H[640027]]({ 'error': H[640794], 'stack': z9186r });console[H[640028]](u4t60), this['G$eT'] && this['G$eT'] == z9186r || (this['G$eT'] = z9186r, f1$A2(u4t60));
  }, s$dm5j[H[640441]]['G$yT'] = function () {
    var plx04 = Laya[H[640689]],
        ikb3an = Math[H[640363]](plx04[H[640425]]),
        o19cz8 = Math[H[640363]](plx04[H[640427]]);o19cz8 / ikb3an < 1.7777778 ? (this[H[640795]] = Math[H[640363]](ikb3an / (o19cz8 / 0x500)), this[H[640796]] = 0x500, this[H[640797]] = o19cz8 / 0x500) : (this[H[640795]] = 0x2d0, this[H[640796]] = Math[H[640363]](o19cz8 / (ikb3an / 0x2d0)), this[H[640797]] = ikb3an / 0x2d0);var nwelx3 = Math[H[640363]](plx04[H[640425]]),
        x4plu0 = Math[H[640363]](plx04[H[640427]]);x4plu0 / nwelx3 < 1.7777778 ? (this[H[640795]] = Math[H[640363]](nwelx3 / (x4plu0 / 0x500)), this[H[640796]] = 0x500, this[H[640797]] = x4plu0 / 0x500) : (this[H[640795]] = 0x2d0, this[H[640796]] = Math[H[640363]](x4plu0 / (nwelx3 / 0x2d0)), this[H[640797]] = nwelx3 / 0x2d0), this['G$oT']();
  }, s$dm5j[H[640441]]['G$oT'] = function () {
    this[H[640772]] && (this[H[640772]][H[640661]](this[H[640795]], this[H[640796]]), this[H[640772]][H[640644]](this[H[640797]], this[H[640797]], !0x0));
  }, s$dm5j[H[640441]]['G$QT'] = function () {
    if (fka5b_[H[640798]] && fqgym[H[640799]]) {
      var u046tp = parseInt(fka5b_[H[640800]][H[640662]][H[640102]][H[640008]]('px', '')),
          eiw3nb = parseInt(fka5b_[H[640801]][H[640662]][H[640427]][H[640008]]('px', '')) * this[H[640797]],
          yqgd = fqgym[H[640802]] / fu40pt6[H[640803]][H[640425]];return 0x0 < (u046tp = fqgym[H[640804]] - eiw3nb * yqgd - u046tp) && (u046tp = 0x0), void (fqgym[H[640805]][H[640662]][H[640102]] = u046tp + 'px');
    }fqgym[H[640805]][H[640662]][H[640102]] = H[640806];var a_ib3 = Math[H[640363]](fqgym[H[640425]]),
        lup0 = Math[H[640363]](fqgym[H[640427]]);a_ib3 = a_ib3 + 0x1 & 0x7ffffffe, lup0 = lup0 + 0x1 & 0x7ffffffe;var pt86r9 = Laya[H[640689]];0x3 == ENV ? (pt86r9[H[640745]] = Laya[H[640746]][H[640807]], pt86r9[H[640425]] = a_ib3, pt86r9[H[640427]] = lup0) : lup0 < a_ib3 ? (pt86r9[H[640745]] = Laya[H[640746]][H[640807]], pt86r9[H[640425]] = a_ib3, pt86r9[H[640427]] = lup0) : (pt86r9[H[640745]] = Laya[H[640746]][H[640747]], pt86r9[H[640425]] = 0x348, pt86r9[H[640427]] = Math[H[640363]](lup0 / (a_ib3 / 0x348)) + 0x1 & 0x7ffffffe), this['G$yT']();
  }, s$dm5j[H[640441]]['f1K$2'] = function (gq7$, ai3bkn) {
    function r19z6() {
      kb3i_a[H[640808]] = null, kb3i_a[H[640809]] = null;
    }var kb3i_a,
        _aikbv = gq7$;(kb3i_a = new fqgym[H[640579]][H[640450]]())[H[640808]] = function () {
      r19z6(), ai3bkn(_aikbv, 0xc8, kb3i_a);
    }, kb3i_a[H[640809]] = function () {
      console[H[640143]](H[640810], _aikbv), s$dm5j[H[640036]]['G$IT'] += _aikbv + '|', r19z6(), ai3bkn(_aikbv, 0x194, null);
    }, kb3i_a[H[640811]] = _aikbv, -0x1 == s$dm5j[H[640036]]['f1K2I$'][H[640108]](_aikbv) && -0x1 == s$dm5j[H[640036]][H[640730]][H[640108]](_aikbv) || Laya[H[640584]][H[640812]](s$dm5j[H[640036]], _aikbv);
  }, s$dm5j[H[640441]]['G$vT'] = function (b5ak_, ys$dqm) {
    return -0x1 != b5ak_[H[640108]](ys$dqm, b5ak_[H[640010]] - ys$dqm[H[640010]]);
  }, s$dm5j;
}();!function ($qgmdy) {
  var avjk_5, lxpu40;avjk_5 = $qgmdy['G$u'] || ($qgmdy['G$u'] = {}), lxpu40 = function (lew3x) {
    function ozc21() {
      var nbi3we = lew3x[H[640445]](this) || this;return nbi3we['G$xT'] = H[640813], nbi3we['G$RT'] = H[640814], nbi3we[H[640425]] = 0x112, nbi3we[H[640427]] = 0x3b, nbi3we['G$FT'] = new Laya[H[640450]](), nbi3we[H[640585]](nbi3we['G$FT']), nbi3we['G$OT'] = new Laya[H[640474]](), nbi3we['G$OT'][H[640640]] = 0x1e, nbi3we['G$OT'][H[640619]] = nbi3we['G$RT'], nbi3we[H[640585]](nbi3we['G$OT']), nbi3we['G$OT'][H[640569]] = 0x0, nbi3we['G$OT'][H[640570]] = 0x0, nbi3we;
    }return fu6p40(ozc21, lew3x), ozc21[H[640441]][H[640568]] = function () {
      lew3x[H[640441]][H[640568]][H[640445]](this), this['G$a'] = fqgym[H[640579]]['f1$2'], this['G$a'][H[640181]], this[H[640571]]();
    }, Object[H[640601]](ozc21[H[640441]], H[640674], { 'set': function (qd$sjm) {
        qd$sjm && this[H[640815]](qd$sjm);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), ozc21[H[640441]][H[640815]] = function (a3nieb) {
      this['G$$T'] = a3nieb[0x0], this['G$ZT'] = a3nieb[0x1], this['G$OT'][H[640357]] = this['G$$T'][H[640697]], this['G$OT'][H[640619]] = this['G$ZT'] ? this['G$xT'] : this['G$RT'], this['G$FT'][H[640588]] = this['G$ZT'] ? H[640547] : H[640739];
    }, ozc21[H[640441]][H[640578]] = function (d$smqj) {
      void 0x0 === d$smqj && (d$smqj = !0x0), this[H[640575]](), lew3x[H[640441]][H[640578]][H[640445]](this, d$smqj);
    }, ozc21[H[640441]][H[640571]] = function () {}, ozc21[H[640441]][H[640575]] = function () {}, ozc21;
  }(Laya[H[640443]]), avjk_5[H[640657]] = lxpu40;
}(modules || (modules = {})), function (mg7$y) {
  var jsqmd$, i_kba;jsqmd$ = mg7$y['G$u'] || (mg7$y['G$u'] = {}), i_kba = function (h18czo) {
    function $dj5m() {
      var xuelw0 = h18czo[H[640445]](this) || this;return xuelw0['G$xT'] = H[640813], xuelw0['G$RT'] = H[640814], xuelw0[H[640425]] = 0x112, xuelw0[H[640427]] = 0x3b, xuelw0['G$FT'] = new Laya[H[640450]](), xuelw0[H[640585]](xuelw0['G$FT']), xuelw0['G$OT'] = new Laya[H[640474]](), xuelw0['G$OT'][H[640640]] = 0x1e, xuelw0['G$OT'][H[640619]] = xuelw0['G$RT'], xuelw0[H[640585]](xuelw0['G$OT']), xuelw0['G$OT'][H[640569]] = 0x0, xuelw0['G$OT'][H[640570]] = 0x0, xuelw0;
    }return fu6p40($dj5m, h18czo), $dj5m[H[640441]][H[640568]] = function () {
      h18czo[H[640441]][H[640568]][H[640445]](this), this['G$a'] = fqgym[H[640579]]['f1$2'], this['G$a'][H[640181]], this[H[640571]]();
    }, Object[H[640601]]($dj5m[H[640441]], H[640674], { 'set': function (ro1z9) {
        ro1z9 && this[H[640815]](ro1z9);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), $dj5m[H[640441]][H[640815]] = function (l4xup) {
      this['G$$T'] = l4xup[0x0], this['G$ZT'] = l4xup[0x1], this['G$OT'][H[640357]] = this['G$$T'][H[640697]], this['G$OT'][H[640619]] = this['G$ZT'] ? this['G$xT'] : this['G$RT'], this['G$FT'][H[640588]] = this['G$ZT'] ? H[640547] : H[640739];
    }, $dj5m[H[640441]][H[640578]] = function (xp4l) {
      void 0x0 === xp4l && (xp4l = !0x0), this[H[640575]](), h18czo[H[640441]][H[640578]][H[640445]](this, xp4l);
    }, $dj5m[H[640441]][H[640571]] = function () {}, $dj5m[H[640441]][H[640575]] = function () {}, $dj5m;
  }(Laya[H[640443]]), jsqmd$[H[640659]] = i_kba;
}(modules || (modules = {})), function (z1or) {
  var _jvak, vba5k;_jvak = z1or['G$u'] || (z1or['G$u'] = {}), vba5k = function ($mdqg) {
    function v5k_js() {
      var $jm5 = $mdqg[H[640445]](this) || this;return $jm5[H[640425]] = 0xc0, $jm5[H[640427]] = 0x46, $jm5['G$FT'] = new Laya[H[640450]](), $jm5[H[640585]]($jm5['G$FT']), $jm5['G$OT'] = new Laya[H[640474]](), $jm5['G$OT'][H[640640]] = 0x1e, $jm5['G$OT'][H[640619]] = $jm5['G$k'], $jm5[H[640585]]($jm5['G$OT']), $jm5['G$OT'][H[640569]] = 0x0, $jm5['G$OT'][H[640570]] = 0x0, $jm5;
    }return fu6p40(v5k_js, $mdqg), v5k_js[H[640441]][H[640568]] = function () {
      $mdqg[H[640441]][H[640568]][H[640445]](this), this['G$a'] = fqgym[H[640579]]['f1$2'];var utp406 = this['G$a'][H[640181]];this['G$k'] = 0x1 == utp406 ? H[640814] : 0x2 == utp406 ? H[640814] : 0x3 == utp406 ? H[640816] : H[640814], this[H[640571]]();
    }, Object[H[640601]](v5k_js[H[640441]], H[640674], { 'set': function (nbiak3) {
        nbiak3 && this[H[640815]](nbiak3);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), v5k_js[H[640441]][H[640815]] = function (m5jd$) {
      this['G$$T'] = m5jd$, this['G$OT'][H[640357]] = m5jd$[H[640773]], this['G$FT'][H[640588]] = m5jd$[H[640706]] ? H[640736] : H[640737];
    }, v5k_js[H[640441]][H[640578]] = function (ex3iw) {
      void 0x0 === ex3iw && (ex3iw = !0x0), this[H[640575]](), $mdqg[H[640441]][H[640578]][H[640445]](this, ex3iw);
    }, v5k_js[H[640441]][H[640571]] = function () {
      this['on'](Laya[H[640573]][H[640691]], this, this[H[640817]]);
    }, v5k_js[H[640441]][H[640575]] = function () {
      this[H[640576]](Laya[H[640573]][H[640691]], this, this[H[640817]]);
    }, v5k_js[H[640441]][H[640817]] = function () {
      this['G$$T'] && this['G$$T'][H[640705]] && this['G$$T'][H[640705]](this['G$$T'][H[640707]]);
    }, v5k_js;
  }(Laya[H[640443]]), _jvak[H[640652]] = vba5k;
}(modules || (modules = {})), function (v_kbi) {
  var zr861, d$jv5;zr861 = v_kbi['G$u'] || (v_kbi['G$u'] = {}), d$jv5 = function (o981) {
    function gm$7qy() {
      var $v5dsj = o981[H[640445]](this) || this;return $v5dsj['G$FT'] = new Laya[H[640450]](H[640738]), $v5dsj['G$OT'] = new Laya[H[640474]](), $v5dsj['G$OT'][H[640640]] = 0x1e, $v5dsj['G$OT'][H[640619]] = $v5dsj['G$k'], $v5dsj[H[640585]]($v5dsj['G$FT']), $v5dsj['G$HT'] = new Laya[H[640450]](), $v5dsj[H[640585]]($v5dsj['G$HT']), $v5dsj[H[640425]] = 0x166, $v5dsj[H[640427]] = 0x46, $v5dsj[H[640585]]($v5dsj['G$OT']), $v5dsj['G$HT'][H[640570]] = 0x0, $v5dsj['G$HT']['x'] = 0x12, $v5dsj['G$OT']['x'] = 0x50, $v5dsj['G$OT'][H[640570]] = 0x0, $v5dsj['G$FT'][H[640818]][H[640819]](0x0, 0x0, $v5dsj[H[640425]], $v5dsj[H[640427]], H[640820]), $v5dsj;
    }return fu6p40(gm$7qy, o981), gm$7qy[H[640441]][H[640568]] = function () {
      o981[H[640441]][H[640568]][H[640445]](this), this['G$a'] = fqgym[H[640579]]['f1$2'];var p8r69 = this['G$a'][H[640181]];this['G$k'] = 0x1 == p8r69 ? H[640821] : 0x2 == p8r69 ? H[640821] : 0x3 == p8r69 ? H[640816] : H[640821], this[H[640571]]();
    }, Object[H[640601]](gm$7qy[H[640441]], H[640674], { 'set': function (m$syq) {
        m$syq && this[H[640815]](m$syq);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), gm$7qy[H[640441]][H[640815]] = function (p60t4u) {
      this['G$$T'] = p60t4u, this['G$OT'][H[640619]] = -0x1 === p60t4u[H[640291]] ? H[640701] : 0x0 === p60t4u[H[640291]] ? H[640702] : this['G$k'], this['G$OT'][H[640357]] = -0x1 === p60t4u[H[640291]] ? p60t4u[H[640287]] + H[640699] : 0x0 === p60t4u[H[640291]] ? p60t4u[H[640287]] + H[640700] : p60t4u[H[640287]], this['G$HT'][H[640588]] = this[H[640703]](p60t4u[H[640291]]);
    }, gm$7qy[H[640441]][H[640578]] = function (s5dv_) {
      void 0x0 === s5dv_ && (s5dv_ = !0x0), this[H[640575]](), o981[H[640441]][H[640578]][H[640445]](this, s5dv_);
    }, gm$7qy[H[640441]][H[640571]] = function () {
      this['on'](Laya[H[640573]][H[640691]], this, this[H[640817]]);
    }, gm$7qy[H[640441]][H[640575]] = function () {
      this[H[640576]](Laya[H[640573]][H[640691]], this, this[H[640817]]);
    }, gm$7qy[H[640441]][H[640817]] = function () {
      this['G$$T'] && this['G$$T'][H[640705]] && this['G$$T'][H[640705]](this['G$$T']);
    }, gm$7qy[H[640441]][H[640703]] = function (qmjd$s) {
      var eiwn3x = '';return 0x2 === qmjd$s ? eiwn3x = H[640515] : 0x1 === qmjd$s ? eiwn3x = H[640711] : -0x1 !== qmjd$s && 0x0 !== qmjd$s || (eiwn3x = H[640712]), eiwn3x;
    }, gm$7qy;
  }(Laya[H[640443]]), zr861[H[640655]] = d$jv5;
}(modules || (modules = {})), window[H[640035]] = fl0e;