'use strict';

var H = wx.$F;
var fdchkl,
    fudkl = this && this[H[641328]] || function () {
  var y9i_6p = Object[H[641329]] || { '__proto__': [] } instanceof Array && function ($m, $z7xb0) {
    $m[H[641330]] = $z7xb0;
  } || function (lck4s, lkdh) {
    for (var gkcwlh in lkdh) lkdh[H[640019]](gkcwlh) && (lck4s[gkcwlh] = lkdh[gkcwlh]);
  };return function (q3rm, hk4l) {
    function rmqb3() {
      this[H[640059]] = q3rm;
    }y9i_6p(q3rm, hk4l), q3rm[H[640018]] = null === hk4l ? Object[H[640014]](hk4l) : (rmqb3[H[640018]] = hk4l[H[640018]], new rmqb3());
  };
}(),
    fp4usd9 = laya['ui'][H[641331]],
    fbmq$30 = laya['ui'][H[641332]];!function (klcdh) {
  var ej581 = function (hcwlgk) {
    function u4s9() {
      return hcwlgk[H[640007]](this) || this;
    }return fudkl(u4s9, hcwlgk), u4s9[H[640018]][H[641333]] = function () {
      hcwlgk[H[640018]][H[641333]][H[640007]](this), this[H[641334]](klcdh['G$T'][H[641335]]);
    }, u4s9[H[641335]] = { 'type': H[641331], 'props': { 'width': 0x2d0, 'name': H[641336], 'height': 0x500 }, 'child': [{ 'type': H[641337], 'props': { 'width': 0x2d0, 'var': H[641338], 'skin': H[641339], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': H[641340], 'props': { 'y': 0x0, 'width': 0x2d0, 'right': 0x0, 'height': 0x500 }, 'child': [{ 'type': H[641337], 'props': { 'width': 0x2d0, 'var': H[641341], 'top': -0x8b, 'skin': H[641342], 'height': 0x8b, 'centerX': 0x0, 'anchorY': 0x1 } }, { 'type': H[641337], 'props': { 'width': 0x2d0, 'var': H[641343], 'top': 0x500, 'skin': H[641344], 'height': 0x8b, 'centerX': 0x0 } }, { 'type': H[641337], 'props': { 'x': -0xdc, 'width': 0xdc, 'var': H[641345], 'skin': H[641346], 'left': -0xdc, 'height': 0x500, 'centerY': 0x0 } }, { 'type': H[641337], 'props': { 'width': 0xdc, 'var': H[641347], 'skin': H[641348], 'left': 0x2d0, 'height': 0x500, 'centerY': 0x0 } }] }] }, u4s9;
  }(fp4usd9);klcdh['G$T'] = ej581;
}(fdchkl || (fdchkl = {})), function (wj82e) {
  var m$x3b0 = function (qmb) {
    function lck4d() {
      return qmb[H[640007]](this) || this;
    }return fudkl(lck4d, qmb), lck4d[H[640018]][H[641333]] = function () {
      qmb[H[640018]][H[641333]][H[640007]](this), this[H[641334]](wj82e['G$l'][H[641335]]);
    }, lck4d[H[641335]] = { 'type': H[641331], 'props': { 'width': 0x2d0, 'name': H[641349], 'height': 0x500 }, 'child': [{ 'type': H[641337], 'props': { 'width': 0x2d0, 'var': H[641338], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': H[641340], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x2d0, 'height': 0x500 }, 'child': [{ 'type': H[641337], 'props': { 'var': H[641341], 'centerX': 0x0, 'bottom': 0x500, 'anchorY': 0x1 } }, { 'type': H[641337], 'props': { 'var': H[641343], 'top': 0x500, 'centerX': 0x0 } }, { 'type': H[641337], 'props': { 'var': H[641345], 'right': 0x2d0, 'pivotX': 0x1, 'centerY': 0x0 } }, { 'type': H[641337], 'props': { 'var': H[641347], 'left': 0x2d0, 'centerY': 0x0 } }] }, { 'type': H[641337], 'props': { 'var': H[641350], 'skin': H[641351], 'centerX': 0x0, 'bottom': 0xa } }, { 'type': H[641340], 'props': { 'y': 0x3c3, 'x': 0x0, 'width': 0x2d0, 'var': H[641352], 'name': H[641352], 'height': 0x82 }, 'child': [{ 'type': H[641337], 'props': { 'y': 0x2e, 'x': 0x3e, 'width': 0x254, 'var': H[641353], 'skin': H[641354], 'height': 0x1b, 'centerX': 0x0 } }, { 'type': H[641337], 'props': { 'y': 0x31, 'x': 0x40, 'width': 0x24e, 'var': H[641355], 'skin': H[641356], 'height': 0x15 } }, { 'type': H[641337], 'props': { 'y': 0x37, 'x': 0x1fb, 'width': 0xd0, 'var': H[641357], 'skin': H[641358], 'height': 0xb } }, { 'type': H[641337], 'props': { 'y': 0x6, 'x': 0x274, 'width': 0x27, 'var': H[641359], 'skin': H[641360], 'height': 0x74 } }, { 'type': H[641361], 'props': { 'y': 0x30, 'x': 0x125, 'width': 0x86, 'var': H[641362], 'valign': H[641363], 'text': H[641364], 'strokeColor': H[641365], 'stroke': 0x3, 'height': 0x18, 'fontSize': 0x18, 'color': H[641366], 'centerX': 0x0, 'bold': !0x1, 'align': H[641367] } }] }, { 'type': H[641340], 'props': { 'y': 0x429, 'x': 0x0, 'width': 0x2d0, 'var': H[641368], 'name': H[641368], 'height': 0x11 }, 'child': [{ 'type': H[641337], 'props': { 'y': 0x0, 'x': 0x133, 'var': H[641369], 'skin': H[641370], 'centerX': -0x2d } }, { 'type': H[641337], 'props': { 'y': 0x0, 'x': 0x151, 'var': H[641371], 'skin': H[641372], 'centerX': -0xf } }, { 'type': H[641337], 'props': { 'y': 0x0, 'x': 0x16f, 'var': H[641373], 'skin': H[641374], 'centerX': 0xf } }, { 'type': H[641337], 'props': { 'y': 0x0, 'x': 0x18d, 'var': H[641375], 'skin': H[641374], 'centerX': 0x2d } }] }, { 'type': H[641376], 'props': { 'y': 0x316, 'x': 0x37, 'visible': !0x1, 'var': H[641377], 'stateNum': 0x1, 'skin': H[641378], 'name': H[641377], 'labelSize': 0x1e, 'labelFont': H[641379], 'labelColors': H[641380] }, 'child': [{ 'type': H[641361], 'props': { 'y': 0x9b, 'x': 0x92, 'width': 0x143, 'var': H[641381], 'text': H[641382], 'name': H[641381], 'height': 0x1e, 'fontSize': 0x1e, 'color': '#bd4f1e', 'align': H[641367] } }] }, { 'type': H[641361], 'props': { 'y': 0x453, 'width': 0x1f4, 'var': H[641383], 'valign': H[641363], 'text': H[641384], 'height': 0x1a, 'fontSize': 0x1a, 'color': H[641385], 'centerX': 0x0, 'bold': !0x1, 'align': H[641367] } }, { 'type': H[641361], 'props': { 'y': 0xa, 'x': 0xa, 'width': 0x156, 'var': H[641386], 'valign': H[641363], 'top': 0x14, 'text': H[641387], 'strokeColor': H[641388], 'stroke': 0x2, 'right': 0x14, 'height': 0x20, 'fontSize': 0x18, 'color': H[641389], 'bold': !0x1, 'align': H[641012] } }] }, lck4d;
  }(fp4usd9);wj82e['G$l'] = m$x3b0;
}(fdchkl || (fdchkl = {})), function (xa7$z) {
  var $3mxb = function (b$3mx) {
    function e52j() {
      return b$3mx[H[640007]](this) || this;
    }return fudkl(e52j, b$3mx), e52j[H[640018]][H[641333]] = function () {
      fp4usd9[H[641390]](H[641391], laya[H[641392]][H[641393]][H[641391]]), fp4usd9[H[641390]](H[641394], laya[H[641395]][H[641394]]), b$3mx[H[640018]][H[641333]][H[640007]](this), this[H[641334]](xa7$z['G$w'][H[641335]]);
    }, e52j[H[641335]] = { 'type': H[641331], 'props': { 'width': 0x2d0, 'name': H[641396], 'height': 0x500 }, 'child': [{ 'type': H[641337], 'props': { 'width': 0x2d0, 'var': H[641338], 'skin': H[641339], 'name': 'bg', 'height': 0x500, 'centerY': 0x0, 'centerX': 0x0 } }, { 'type': H[641340], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x2d0, 'height': 0x500 }, 'child': [{ 'type': H[641337], 'props': { 'width': 0x2d0, 'var': H[641341], 'skin': H[641342], 'bottom': 0x4ff } }, { 'type': H[641337], 'props': { 'width': 0x2d0, 'var': H[641343], 'top': 0x4ff, 'skin': H[641344] } }, { 'type': H[641337], 'props': { 'var': H[641345], 'skin': H[641346], 'right': 0x2cf, 'height': 0x500 } }, { 'type': H[641337], 'props': { 'var': H[641347], 'skin': H[641348], 'left': 0x2cf, 'height': 0x500 } }] }, { 'type': H[641337], 'props': { 'y': 0x34d, 'var': H[641397], 'skin': H[641398], 'centerX': 0x0 } }, { 'type': H[641337], 'props': { 'y': 0x44e, 'var': H[641399], 'skin': H[641400], 'name': H[641399], 'centerX': 0x0 } }, { 'type': H[641337], 'props': { 'y': 0x3a2, 'x': 0xa2, 'var': H[641401], 'skin': H[641402] } }, { 'type': H[641337], 'props': { 'var': H[641350], 'skin': H[641351], 'centerX': 0x0, 'bottom': 0x1e } }, { 'type': H[641337], 'props': { 'y': 0x3f7, 'var': H[641403], 'stateNum': 0x1, 'skin': H[641404], 'name': H[641403], 'centerX': 0x0 } }, { 'type': H[641337], 'props': { 'x': 0xc4, 'visible': !0x1, 'var': H[641405], 'skin': H[641406], 'bottom': 0x4 } }, { 'type': H[641361], 'props': { 'y': 0x280, 'x': 0x0, 'width': 0x2d0, 'var': H[641407], 'valign': H[641363], 'text': H[641408], 'strokeColor': H[641409], 'stroke': 0x2, 'height': 0x20, 'fontSize': 0x20, 'color': H[641410], 'bold': !0x1, 'align': H[641367] } }, { 'type': H[641361], 'props': { 'y': 0x3a4, 'x': 0x209, 'var': H[641411], 'valign': H[641363], 'text': H[641412], 'height': 0x20, 'fontSize': 0x1e, 'color': H[641413], 'bold': !0x1, 'align': H[641367] } }, { 'type': H[641361], 'props': { 'y': 0x3a4, 'width': 0x156, 'var': H[641414], 'valign': H[641363], 'text': H[641415], 'height': 0x20, 'fontSize': 0x1e, 'color': H[641413], 'centerX': 0x0, 'bold': !0x1, 'align': H[641367] } }, { 'type': H[641361], 'props': { 'width': 0x156, 'var': H[641386], 'valign': H[641363], 'top': 0x14, 'text': H[641387], 'strokeColor': H[641388], 'stroke': 0x2, 'right': 0x14, 'height': 0x20, 'fontSize': 0x18, 'color': H[641389], 'bold': !0x1, 'align': H[641012] } }, { 'type': H[641391], 'props': { 'y': 0x4e7, 'x': 0x100, 'visible': !0x1, 'var': H[641416], 'height': 0x10 } }, { 'type': H[641337], 'props': { 'y': 0x7f, 'x': 593.5, 'var': H[641417], 'skin': H[641418] } }, { 'type': H[641337], 'props': { 'y': 0x101, 'x': 0x252, 'visible': !0x1, 'var': H[641419], 'skin': H[641420], 'name': H[641419] } }, { 'type': H[641337], 'props': { 'y': 0x47, 'x': -0x2, 'visible': !0x1, 'var': H[641421], 'skin': H[641422], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': H[641337], 'props': { 'y': 36.5, 'x': 0x268, 'var': H[641423], 'skin': H[641424] } }, { 'type': H[641361], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': H[641425], 'valign': H[641363], 'text': H[641426], 'height': 0x23, 'fontSize': 0x1e, 'color': H[641409], 'bold': !0x1, 'align': H[641367] } }, { 'type': H[641394], 'props': { 'y': 0x8e, 'x': 0x3d, 'wordWrap': !0x0, 'width': 0x221, 'var': H[641427], 'valign': H[641009], 'overflow': H[641428], 'mouseEnabled': !0x0, 'leading': 0x4, 'height': 0x366, 'fontSize': 0x1a, 'color': H[641429] } }] }, { 'type': H[641337], 'props': { 'y': 0x71, 'x': 0x21, 'visible': !0x1, 'var': H[641430], 'skin': H[641422], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': H[641337], 'props': { 'y': 36.5, 'x': 0x268, 'var': H[641431], 'skin': H[641424] } }, { 'type': H[641376], 'props': { 'y': 0x388, 'x': 0xbe, 'var': H[641432], 'stateNum': 0x1, 'skin': H[641433], 'labelSize': 0x1e, 'labelColors': H[641434], 'label': H[641435] } }, { 'type': H[641340], 'props': { 'y': 0x388, 'x': 0x22, 'width': 0x254, 'var': H[641436], 'height': 0x3b } }, { 'type': H[641361], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': H[641437], 'valign': H[641363], 'text': H[641426], 'height': 0x23, 'fontSize': 0x1e, 'color': H[641409], 'bold': !0x1, 'align': H[641367] } }, { 'type': H[641438], 'props': { 'y': 0x8e, 'x': 0x3d, 'width': 0x221, 'var': H[641439], 'height': 0x2dd }, 'child': [{ 'type': H[641391], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x221, 'var': H[641440], 'height': 0x2dd } }] }] }, { 'type': H[641337], 'props': { 'visible': !0x1, 'var': H[641441], 'skin': H[641422], 'name': H[641441], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': H[641337], 'props': { 'y': 36.5, 'x': 0x268, 'var': H[641442], 'skin': H[641424] } }, { 'type': H[641376], 'props': { 'y': 0x388, 'x': 0xbe, 'var': H[641443], 'stateNum': 0x1, 'skin': H[641433], 'labelSize': 0x1e, 'labelColors': H[641434], 'label': H[641435] } }, { 'type': H[641340], 'props': { 'y': 0x388, 'x': 0x22, 'width': 0x254, 'var': H[641444], 'height': 0x3b } }, { 'type': H[641361], 'props': { 'y': 0x48, 'x': 0xd8, 'width': 0xea, 'var': H[641445], 'valign': H[641363], 'text': H[641426], 'height': 0x23, 'fontSize': 0x1e, 'color': H[641409], 'bold': !0x1, 'align': H[641367] } }, { 'type': H[641438], 'props': { 'y': 0x8e, 'x': 0x3d, 'width': 0x221, 'var': H[641446], 'height': 0x2dd }, 'child': [{ 'type': H[641391], 'props': { 'y': 0x0, 'x': 0x0, 'width': 0x221, 'var': H[641447], 'height': 0x2dd } }] }] }, { 'type': H[641337], 'props': { 'visible': !0x1, 'var': H[641448], 'skin': H[641449], 'centerY': 0x0, 'centerX': 0x0 }, 'child': [{ 'type': H[641340], 'props': { 'y': 0x75, 'x': 0x3d, 'width': 0xc8, 'var': H[641450], 'height': 0x389 } }, { 'type': H[641340], 'props': { 'y': 0x75, 'x': 0x125, 'width': 0x166, 'var': H[641451], 'height': 0x389 } }, { 'type': H[641337], 'props': { 'y': 0xd, 'x': 0x282, 'var': H[641452], 'skin': H[641453] } }] }] }, e52j;
  }(fp4usd9);xa7$z['G$w'] = $3mxb;
}(fdchkl || (fdchkl = {})), function (p4ks) {
  var xan7zt, u9py6;xan7zt = p4ks['G$u'] || (p4ks['G$u'] = {}), u9py6 = function (gc1hl) {
    function bx0m7$() {
      return gc1hl[H[640007]](this) || this;
    }return fudkl(bx0m7$, gc1hl), bx0m7$[H[640018]][H[641454]] = function () {
      gc1hl[H[640018]][H[641454]][H[640007]](this), this[H[641455]] = 0x0, this[H[641456]] = 0x0, this[H[641457]](), this[H[641458]]();
    }, bx0m7$[H[640018]][H[641457]] = function () {
      this['on'](Laya[H[641459]][H[641460]], this, this['G$p']);
    }, bx0m7$[H[640018]][H[641461]] = function () {
      this[H[640336]](Laya[H[641459]][H[641460]], this, this['G$p']);
    }, bx0m7$[H[640018]][H[641458]] = function () {
      this['G$D'] = Date[H[641047]](), fhg2c1[H[640947]]['f129BTK'](), fhg2c1[H[640947]][H[641462]]();
    }, bx0m7$[H[640018]][H[641463]] = function (pd4s9u) {
      void 0x0 === pd4s9u && (pd4s9u = !0x0), this[H[641461]](), gc1hl[H[640018]][H[641463]][H[640007]](this, pd4s9u);
    }, bx0m7$[H[640018]]['G$p'] = function () {
      0x2710 < Date[H[641047]]() - this['G$D'] && (this['G$D'] -= 0x3e8, fn8t5j[H[641464]]['f1T9'][H[640935]][H[640936]] && (fhg2c1[H[640947]][H[641465]](), fhg2c1[H[640947]][H[641466]]()));
    }, bx0m7$;
  }(fdchkl['G$T']), xan7zt[H[641467]] = u9py6;
}(modules || (modules = {})), function (k4lu) {
  var nzt7va, y_s9up, $zb0, j82ev, ukpds4, a$x7z;nzt7va = k4lu['G$P'] || (k4lu['G$P'] = {}), y_s9up = Laya[H[641459]], $zb0 = Laya[H[641337]], j82ev = Laya[H[641468]], ukpds4 = Laya[H[641469]], a$x7z = function (gh1cl) {
    function v2j() {
      var xzba$7 = gh1cl[H[640007]](this) || this;return xzba$7['G$j'] = new $zb0(), xzba$7[H[641470]](xzba$7['G$j']), xzba$7['G$J'] = null, xzba$7['G$q'] = [], xzba$7['G$M'] = !0x1, xzba$7['G$z'] = 0x0, xzba$7['G$b'] = !0x0, xzba$7['G$K'] = 0x6, xzba$7['G$Y'] = !0x1, xzba$7['on'](y_s9up[H[641471]], xzba$7, xzba$7['G$t']), xzba$7['on'](y_s9up[H[641472]], xzba$7, xzba$7['G$A']), xzba$7;
    }return fudkl(v2j, gh1cl), v2j[H[640014]] = function (v8e5j2, mb7$0x, sudkl4, _p9syu, sp9du, yu_6p9, y9s_pu) {
      void 0x0 === _p9syu && (_p9syu = 0x0), void 0x0 === sp9du && (sp9du = 0x6), void 0x0 === yu_6p9 && (yu_6p9 = !0x0), void 0x0 === y9s_pu && (y9s_pu = !0x1);var bm3$0q = new v2j();return bm3$0q[H[641473]](mb7$0x, sudkl4, _p9syu), bm3$0q[H[641474]] = sp9du, bm3$0q[H[641475]] = yu_6p9, bm3$0q[H[641476]] = y9s_pu, v8e5j2 && v8e5j2[H[641470]](bm3$0q), bm3$0q;
    }, v2j[H[641477]] = function (h1wcgl) {
      h1wcgl && (h1wcgl[H[641478]] = !0x0, h1wcgl[H[641477]]());
    }, v2j[H[641479]] = function (m3$0bx) {
      m3$0bx && (m3$0bx[H[641478]] = !0x1, m3$0bx[H[641479]]());
    }, v2j[H[640018]][H[641463]] = function (axzt7) {
      Laya[H[641480]][H[641481]](this, this['G$L']), this[H[640336]](y_s9up[H[641471]], this, this['G$t']), this[H[640336]](y_s9up[H[641472]], this, this['G$A']), gh1cl[H[640018]][H[641463]][H[640007]](this, axzt7);
    }, v2j[H[640018]]['G$t'] = function () {}, v2j[H[640018]]['G$A'] = function () {}, v2j[H[640018]][H[641473]] = function (hwkc, hcgw2, azn7$x) {
      if (this['G$J'] != hwkc) {
        this['G$J'] = hwkc, this['G$q'] = [];for (var j2815e = 0x0, b$x7az = azn7$x; b$x7az <= hcgw2; b$x7az++) this['G$q'][j2815e++] = hwkc + '/' + b$x7az + H[641482];var q0$bm = ukpds4[H[641483]](this['G$q'][0x0]);q0$bm && (this[H[641317]] = q0$bm[H[641484]], this[H[641319]] = q0$bm[H[641485]]), this['G$L']();
      }
    }, Object[H[640008]](v2j[H[640018]], H[641476], { 'get': function () {
        return this['G$Y'];
      }, 'set': function (e28j1w) {
        this['G$Y'] = e28j1w;
      }, 'enumerable': !0x0, 'configurable': !0x0 }), Object[H[640008]](v2j[H[640018]], H[641474], { 'set': function (ip9y_) {
        this['G$K'] != ip9y_ && (this['G$K'] = ip9y_, this['G$M'] && (Laya[H[641480]][H[641481]](this, this['G$L']), Laya[H[641480]][H[641475]](this['G$K'] * (0x3e8 / 0x3c), this, this['G$L'])));
      }, 'enumerable': !0x0, 'configurable': !0x0 }), Object[H[640008]](v2j[H[640018]], H[641475], { 'set': function (xaz$7n) {
        this['G$b'] = xaz$7n;
      }, 'enumerable': !0x0, 'configurable': !0x0 }), v2j[H[640018]][H[641477]] = function () {
      this['G$M'] && this[H[641479]](), this['G$M'] = !0x0, this['G$z'] = 0x0, Laya[H[641480]][H[641475]](this['G$K'] * (0x3e8 / 0x3c), this, this['G$L']), this['G$L']();
    }, v2j[H[640018]][H[641479]] = function () {
      this['G$M'] = !0x1, this['G$z'] = 0x0, this['G$L'](), Laya[H[641480]][H[641481]](this, this['G$L']);
    }, v2j[H[640018]][H[641486]] = function () {
      this['G$M'] && (this['G$M'] = !0x1, Laya[H[641480]][H[641481]](this, this['G$L']));
    }, v2j[H[640018]][H[641487]] = function () {
      this['G$M'] || (this['G$M'] = !0x0, Laya[H[641480]][H[641475]](this['G$K'] * (0x3e8 / 0x3c), this, this['G$L']), this['G$L']());
    }, Object[H[640008]](v2j[H[640018]], H[641488], { 'get': function () {
        return this['G$M'];
      }, 'enumerable': !0x0, 'configurable': !0x0 }), v2j[H[640018]]['G$L'] = function () {
      this['G$q'] && 0x0 != this['G$q'][H[640031]] && (this['G$j'][H[641473]] = this['G$q'][this['G$z']], this['G$M'] && (this['G$z']++, this['G$z'] == this['G$q'][H[640031]] && (this['G$b'] ? this['G$z'] = 0x0 : (Laya[H[641480]][H[641481]](this, this['G$L']), this['G$M'] = !0x1, this['G$Y'] && (this[H[641478]] = !0x1), this[H[641489]](y_s9up[H[641490]])))));
    }, v2j;
  }(j82ev), nzt7va[H[641491]] = a$x7z;
}(modules || (modules = {})), function (p_s9yu) {
  var _dp9su, atnxz, w2g1je;_dp9su = p_s9yu['G$u'] || (p_s9yu['G$u'] = {}), atnxz = p_s9yu['G$P'][H[641491]], w2g1je = function (ysp_) {
    function ejt8(_96iyo) {
      void 0x0 === _96iyo && (_96iyo = 0x0);var a5vznt = ysp_[H[640007]](this) || this;return a5vznt['G$i'] = { 'bgImgSkin': H[641492], 'topImgSkin': H[641493], 'btmImgSkin': H[641494], 'leftImgSkin': H[641495], 'rightImgSkin': H[641496], 'loadingBarBgSkin': H[641354], 'copyRightImgBottom': 0xa, 'processBox1Y': 0x3c3, 'processBox2Y': 0x429, 'loadingTipsSize': 0x1a, 'getTipsBtnVisible': !0x1 }, a5vznt['G$W'] = { 'bgImgSkin': H[641497], 'topImgSkin': H[641498], 'btmImgSkin': H[641499], 'leftImgSkin': H[641500], 'rightImgSkin': H[641501], 'loadingBarBgSkin': H[641502], 'copyRightImgBottom': 0xa, 'processBox1Y': 0x3c3, 'processBox2Y': 0x429, 'loadingTipsSize': 0x1a, 'getTipsBtnVisible': !0x1 }, a5vznt['G$m'] = 0x0, a5vznt['G$c'](0x1 == _96iyo ? a5vznt['G$W'] : a5vznt['G$i']), a5vznt;
    }return fudkl(ejt8, ysp_), ejt8[H[640018]][H[641454]] = function () {
      if (ysp_[H[640018]][H[641454]][H[640007]](this), fhg2c1[H[640947]][H[641462]](), this['G$a'] = fn8t5j[H[641464]]['f1T9'], this[H[641455]] = 0x0, this[H[641456]] = 0x0, this['G$a']) {
        var $bmx = this['G$a'][H[641084]];this[H[641383]][H[641503]] = 0x1 == $bmx ? H[641385] : 0x2 == $bmx ? H[641504] : 0x65 == $bmx ? H[641504] : H[641385];
      }this['G$B'] = [this[H[641369]], this[H[641371]], this[H[641373]], this[H[641375]]], fn8t5j[H[641464]][H[641505]] = this, f1KT9B(), fhg2c1[H[640947]][H[641108]](), fhg2c1[H[640947]][H[641109]](), this[H[641458]]();
    }, ejt8[H[640018]]['f1KT9'] = function (t5ev) {
      var u6yp9_ = this;if (-0x1 === t5ev) return u6yp9_['G$m'] = 0x0, Laya[H[641480]][H[641481]](this, this['f1KT9']), void Laya[H[641480]][H[641506]](0x1, this, this['f1KT9']);if (-0x2 !== t5ev) {
        u6yp9_['G$m'] < 0.9 ? u6yp9_['G$m'] += (0.15 * Math[H[641126]]() + 0.01) / (0x64 * Math[H[641126]]() + 0x32) : u6yp9_['G$m'] < 0x1 && (u6yp9_['G$m'] += 0.0001), 0.9999 < u6yp9_['G$m'] && (u6yp9_['G$m'] = 0.9999, Laya[H[641480]][H[641481]](this, this['f1KT9']), Laya[H[641480]][H[641507]](0xbb8, this, function () {
          0.9 < u6yp9_['G$m'] && f1KT9(-0x1);
        }));var kluds4 = u6yp9_['G$m'],
            nz7$ = 0x24e * kluds4;u6yp9_['G$m'] = u6yp9_['G$m'] > kluds4 ? u6yp9_['G$m'] : kluds4, u6yp9_[H[641355]][H[641317]] = nz7$;var _y9p6u = u6yp9_[H[641355]]['x'] + nz7$;u6yp9_[H[641359]]['x'] = _y9p6u - 0xf, 0x16c <= _y9p6u ? (u6yp9_[H[641357]][H[641478]] = !0x0, u6yp9_[H[641357]]['x'] = _y9p6u - 0xca) : u6yp9_[H[641357]][H[641478]] = !0x1, u6yp9_[H[641362]][H[641253]] = (0x64 * kluds4 >> 0x0) + '%', u6yp9_['G$m'] < 0.9999 && Laya[H[641480]][H[641506]](0x1, this, this['f1KT9']);
      } else Laya[H[641480]][H[641481]](this, this['f1KT9']);
    }, ejt8[H[640018]]['f1K9T'] = function (qr0b3, weh1, d4clhk) {
      0x1 < qr0b3 && (qr0b3 = 0x1);var dkusp = 0x24e * qr0b3;this['G$m'] = this['G$m'] > qr0b3 ? this['G$m'] : qr0b3, this[H[641355]][H[641317]] = dkusp;var tx7na = this[H[641355]]['x'] + dkusp;this[H[641359]]['x'] = tx7na - 0xf, 0x16c <= tx7na ? (this[H[641357]][H[641478]] = !0x0, this[H[641357]]['x'] = tx7na - 0xca) : this[H[641357]][H[641478]] = !0x1, this[H[641362]][H[641253]] = (0x64 * qr0b3 >> 0x0) + '%', this[H[641383]][H[641253]] = weh1;for (var $nazx = d4clhk - 0x1, gjw1 = 0x0; gjw1 < this['G$B'][H[640031]]; gjw1++) this['G$B'][gjw1][H[641473]] = gjw1 < $nazx ? H[641370] : $nazx === gjw1 ? H[641372] : H[641374];
    }, ejt8[H[640018]][H[641458]] = function () {
      this['f1K9T'](0.1, H[641508], 0x1), this['f1KT9'](-0x1), fn8t5j[H[641464]]['f1KT9'] = this['f1KT9'][H[640017]](this), fn8t5j[H[641464]]['f1K9T'] = this['f1K9T'][H[640017]](this), this[H[641386]][H[641253]] = H[641509] + this['G$a'][H[640932]] + H[641510] + this['G$a'][H[641059]], this[H[641303]]();
    }, ejt8[H[640018]][H[641511]] = function (vjn5t8) {
      this[H[641512]](), Laya[H[641480]][H[641481]](this, this['f1KT9']), Laya[H[641480]][H[641481]](this, this['G$s']), fhg2c1[H[640947]][H[641110]](), this[H[641377]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$r']);
    }, ejt8[H[640018]][H[641512]] = function () {
      fn8t5j[H[641464]]['f1KT9'] = function () {}, fn8t5j[H[641464]]['f1K9T'] = function () {};
    }, ejt8[H[640018]][H[641463]] = function (kdcs4) {
      void 0x0 === kdcs4 && (kdcs4 = !0x0), this[H[641512]](), ysp_[H[640018]][H[641463]][H[640007]](this, kdcs4);
    }, ejt8[H[640018]][H[641303]] = function () {
      this['G$a'][H[641303]] && 0x1 == this['G$a'][H[641303]] && (this[H[641377]][H[641478]] = !0x0, this[H[641377]][H[641513]] = !0x0, this[H[641377]][H[641473]] = H[641378], this[H[641377]]['on'](Laya[H[641459]][H[641460]], this, this['G$r']), this['G$I'](), this['G$Q'](!0x0));
    }, ejt8[H[640018]]['G$r'] = function () {
      this[H[641377]][H[641513]] && (this[H[641377]][H[641513]] = !0x1, this[H[641377]][H[641473]] = H[641514], this['G$o'](), this['G$Q'](!0x1));
    }, ejt8[H[640018]]['G$c'] = function (sk4up) {
      this[H[641338]][H[641473]] = sk4up[H[641515]], this[H[641341]][H[641473]] = sk4up[H[641516]], this[H[641343]][H[641473]] = sk4up[H[641517]], this[H[641345]][H[641473]] = sk4up[H[641518]], this[H[641347]][H[641473]] = sk4up[H[641519]], this[H[641350]][H[641010]] = sk4up[H[641520]], this[H[641352]]['y'] = sk4up[H[641521]], this[H[641368]]['y'] = sk4up[H[641522]], this[H[641353]][H[641473]] = sk4up[H[641523]], this[H[641383]][H[641524]] = sk4up[H[641525]], this[H[641377]][H[641478]] = this['G$a'][H[641303]] && 0x1 == this['G$a'][H[641303]], this[H[641377]][H[641478]] ? this['G$I']() : this['G$o'](), this['G$Q'](this[H[641377]][H[641478]]);
    }, ejt8[H[640018]]['G$I'] = function () {
      this['G$e'] || (this['G$e'] = atnxz[H[640014]](this[H[641377]], H[641526], 0x4, 0x0, 0xc), this['G$e'][H[640356]](0xa1, 0x6a), this['G$e'][H[641527]](1.14, 1.15)), atnxz[H[641477]](this['G$e']);
    }, ejt8[H[640018]]['G$o'] = function () {
      this['G$e'] && atnxz[H[641479]](this['G$e']);
    }, ejt8[H[640018]]['G$Q'] = function (pdus) {
      Laya[H[641480]][H[641481]](this, this['G$s']), pdus ? (this['G$y'] = 0x9, this[H[641381]][H[641478]] = !0x0, this['G$s'](), Laya[H[641480]][H[641475]](0x3e8, this, this['G$s'])) : this[H[641381]][H[641478]] = !0x1;
    }, ejt8[H[640018]]['G$s'] = function () {
      0x0 < this['G$y'] ? (this[H[641381]][H[641253]] = H[641528] + this['G$y'] + 's)', this['G$y']--) : (this[H[641381]][H[641253]] = '', Laya[H[641480]][H[641481]](this, this['G$s']), this['G$r']());
    }, ejt8;
  }(fdchkl['G$l']), _dp9su[H[641529]] = w2g1je;
}(modules || (modules = {})), function (kwcgl) {
  var gc4lhk, $baz7, pu_9, ghe12;gc4lhk = kwcgl['G$u'] || (kwcgl['G$u'] = {}), $baz7 = Laya[H[641530]], pu_9 = Laya[H[641459]], ghe12 = function (skdc4) {
    function zb$a7() {
      var x7$b0z = skdc4[H[640007]](this) || this;return x7$b0z['G$v'] = 0x0, x7$b0z['G$x'] = H[641531], x7$b0z['G$R'] = 0x0, x7$b0z['G$F'] = 0x0, x7$b0z['G$O'] = H[641532], x7$b0z;
    }return fudkl(zb$a7, skdc4), zb$a7[H[640018]][H[641454]] = function () {
      skdc4[H[640018]][H[641454]][H[640007]](this), this[H[641455]] = 0x0, this[H[641456]] = 0x0, fhg2c1[H[640947]]['f129BTK'](), this['G$a'] = fn8t5j[H[641464]]['f1T9'], this['G$$'] = new $baz7(), this['G$$'][H[641533]] = '', this['G$$'][H[641534]] = gc4lhk[H[641535]], this['G$$'][H[641009]] = 0x5, this['G$$'][H[641536]] = 0x1, this['G$$'][H[641537]] = 0x5, this['G$$'][H[641317]] = this[H[641450]][H[641317]], this['G$$'][H[641319]] = this[H[641450]][H[641319]] - 0x8, this[H[641450]][H[641470]](this['G$$']), this['G$Z'] = new $baz7(), this['G$Z'][H[641533]] = '', this['G$Z'][H[641534]] = gc4lhk[H[641538]], this['G$Z'][H[641009]] = 0x5, this['G$Z'][H[641536]] = 0x1, this['G$Z'][H[641537]] = 0x5, this['G$Z'][H[641317]] = this[H[641451]][H[641317]], this['G$Z'][H[641319]] = this[H[641451]][H[641319]] - 0x8, this[H[641451]][H[641470]](this['G$Z']), this['G$H'] = new $baz7(), this['G$H'][H[641539]] = '', this['G$H'][H[641534]] = gc4lhk[H[641540]], this['G$H'][H[641541]] = 0x1, this['G$H'][H[641317]] = this[H[641436]][H[641317]], this['G$H'][H[641319]] = this[H[641436]][H[641319]], this[H[641436]][H[641470]](this['G$H']), this['G$X'] = new $baz7(), this['G$X'][H[641539]] = '', this['G$X'][H[641534]] = gc4lhk[H[641542]], this['G$X'][H[641541]] = 0x1, this['G$X'][H[641317]] = this[H[641436]][H[641317]], this['G$X'][H[641319]] = this[H[641436]][H[641319]], this[H[641444]][H[641470]](this['G$X']);var kwhgl = this['G$a'][H[641084]];this['G$k'] = 0x1 == kwhgl ? H[641413] : 0x2 == kwhgl ? H[641413] : 0x3 == kwhgl ? H[641413] : 0x65 == kwhgl ? H[641413] : H[641543], this[H[641403]][H[641544]](0x1fa, 0x58), this['G$n'] = [], this[H[641417]][H[641478]] = !0x1, this[H[641440]][H[641503]] = H[641429], this[H[641440]][H[641545]][H[641524]] = 0x1a, this[H[641440]][H[641545]][H[641546]] = 0x1c, this[H[641440]][H[641547]] = !0x1, this[H[641447]][H[641503]] = H[641429], this[H[641447]][H[641545]][H[641524]] = 0x1a, this[H[641447]][H[641545]][H[641546]] = 0x1c, this[H[641447]][H[641547]] = !0x1, this[H[641416]][H[641503]] = H[641409], this[H[641416]][H[641545]][H[641524]] = 0x12, this[H[641416]][H[641545]][H[641546]] = 0x12, this[H[641416]][H[641545]][H[641548]] = 0x2, this[H[641416]][H[641545]][H[641549]] = H[641504], this[H[641416]][H[641545]][H[641550]] = !0x1, fn8t5j[H[641464]][H[641267]] = this, f1KT9B(), this[H[641457]](), this[H[641458]]();
    }, zb$a7[H[640018]][H[641463]] = function (pu_s9) {
      void 0x0 === pu_s9 && (pu_s9 = !0x0), this[H[641461]](), this['G$d'](), this['G$G'](), this['G$N'](), this['G$$'] && (this['G$$'][H[641551]](), this['G$$'][H[641463]](), this['G$$'] = null), this['G$Z'] && (this['G$Z'][H[641551]](), this['G$Z'][H[641463]](), this['G$Z'] = null), this['G$H'] && (this['G$H'][H[641551]](), this['G$H'][H[641463]](), this['G$H'] = null), this['G$X'] && (this['G$X'][H[641551]](), this['G$X'][H[641463]](), this['G$X'] = null), Laya[H[641480]][H[641481]](this, this['G$h']), skdc4[H[640018]][H[641463]][H[640007]](this, pu_s9);
    }, zb$a7[H[640018]][H[641457]] = function () {
      this[H[641338]]['on'](Laya[H[641459]][H[641460]], this, this['G$g']), this[H[641403]]['on'](Laya[H[641459]][H[641460]], this, this['G$f']), this[H[641397]]['on'](Laya[H[641459]][H[641460]], this, this['G$U']), this[H[641397]]['on'](Laya[H[641459]][H[641460]], this, this['G$U']), this[H[641452]]['on'](Laya[H[641459]][H[641460]], this, this['G$E']), this[H[641417]]['on'](Laya[H[641459]][H[641460]], this, this['G$V']), this[H[641423]]['on'](Laya[H[641459]][H[641460]], this, this['G$C']), this[H[641427]]['on'](Laya[H[641459]][H[641552]], this, this['G$S']), this[H[641431]]['on'](Laya[H[641459]][H[641460]], this, this['G$_']), this[H[641432]]['on'](Laya[H[641459]][H[641460]], this, this['G$_']), this[H[641439]]['on'](Laya[H[641459]][H[641552]], this, this['G$TT']), this[H[641419]]['on'](Laya[H[641459]][H[641460]], this, this['G$lT']), this[H[641442]]['on'](Laya[H[641459]][H[641460]], this, this['G$wT']), this[H[641443]]['on'](Laya[H[641459]][H[641460]], this, this['G$wT']), this[H[641446]]['on'](Laya[H[641459]][H[641552]], this, this['G$uT']), this[H[641405]]['on'](Laya[H[641459]][H[641460]], this, this['G$pT']), this[H[641416]]['on'](Laya[H[641459]][H[641553]], this, this['G$DT']), this['G$H'][H[641554]] = !0x0, this['G$H'][H[641555]] = Laya[H[641556]][H[640014]](this, this['G$PT'], null, !0x1), this['G$X'][H[641554]] = !0x0, this['G$X'][H[641555]] = Laya[H[641556]][H[640014]](this, this['G$jT'], null, !0x1);
    }, zb$a7[H[640018]][H[641461]] = function () {
      this[H[641338]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$g']), this[H[641403]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$f']), this[H[641397]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$U']), this[H[641397]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$U']), this[H[641452]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$E']), this[H[641417]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$V']), this[H[641423]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$C']), this[H[641427]][H[640336]](Laya[H[641459]][H[641552]], this, this['G$S']), this[H[641431]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$_']), this[H[641432]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$_']), this[H[641439]][H[640336]](Laya[H[641459]][H[641552]], this, this['G$TT']), this[H[641419]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$lT']), this[H[641442]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$wT']), this[H[641443]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$wT']), this[H[641446]][H[640336]](Laya[H[641459]][H[641552]], this, this['G$uT']), this[H[641405]][H[640336]](Laya[H[641459]][H[641460]], this, this['G$pT']), this[H[641416]][H[640336]](Laya[H[641459]][H[641553]], this, this['G$DT']), this['G$H'][H[641554]] = !0x1, this['G$H'][H[641555]] = null, this['G$X'][H[641554]] = !0x1, this['G$X'][H[641555]] = null;
    }, zb$a7[H[640018]][H[641458]] = function () {
      var na7zt = this;this['G$D'] = Date[H[641047]](), this['G$JT'] = !0x1, this['G$qT'] = this['G$a'][H[640935]][H[640936]], this['G$MT'](this['G$a'][H[640935]]), this['G$$'][H[641557]] = this['G$a'][H[641266]], this['G$U'](), req_multi_server_notice(0x4, this['G$a'][H[640934]], this['G$a'][H[640935]][H[640936]], this['G$zT'][H[640017]](this)), Laya[H[641480]][H[641558]](0xa, this, function () {
        na7zt['G$JT'] = !0x0, na7zt['G$bT'] = na7zt['G$a'][H[641559]] && na7zt['G$a'][H[641559]][H[641560]] ? na7zt['G$a'][H[641559]][H[641560]] : [], na7zt['G$KT'] = null != na7zt['G$a'][H[641561]] ? na7zt['G$a'][H[641561]] : 0x0;var va5zt = '1' == localStorage[H[641562]](na7zt['G$O']),
            mx7$b = 0x0 != f1T9[H[641563]],
            mq0$3 = 0x0 == na7zt['G$KT'] || 0x1 == na7zt['G$KT'];na7zt['G$YT'] = mx7$b && va5zt || mq0$3, na7zt['G$tT']();
      }), this[H[641386]][H[641253]] = H[641509] + this['G$a'][H[640932]] + H[641510] + this['G$a'][H[641059]], this[H[641414]][H[641503]] = this[H[641411]][H[641503]] = this['G$k'], this[H[641399]][H[641478]] = 0x1 == this['G$a'][H[641564]], this[H[641407]][H[641478]] = !0x1;
    }, zb$a7[H[640018]][H[641565]] = function () {}, zb$a7[H[640018]]['G$g'] = function () {
      this['G$JT'] && (this['G$YT'] ? 0x2710 < Date[H[641047]]() - this['G$D'] && (this['G$D'] -= 0x7d0, fhg2c1[H[640947]][H[641465]]()) : this['G$AT'](H[641566]));
    }, zb$a7[H[640018]]['G$f'] = function () {
      this['G$JT'] && (this['G$YT'] ? this['G$LT'](this['G$a'][H[640935]]) && (fn8t5j[H[641464]]['f1T9'][H[640935]] = this['G$a'][H[640935]], f19KBT(0x0, this['G$a'][H[640935]][H[640936]])) : this['G$AT'](H[641566]));
    }, zb$a7[H[640018]]['G$U'] = function () {
      this['G$a'][H[641269]] ? this[H[641448]][H[641478]] = !0x0 : (this['G$a'][H[641269]] = !0x0, f1T9KB(0x0));
    }, zb$a7[H[640018]]['G$E'] = function () {
      this[H[641448]][H[641478]] = !0x1;
    }, zb$a7[H[640018]]['G$V'] = function () {
      this['G$iT']();
    }, zb$a7[H[640018]]['G$_'] = function () {
      this[H[641430]][H[641478]] = !0x1;
    }, zb$a7[H[640018]]['G$C'] = function () {
      this[H[641421]][H[641478]] = !0x1;
    }, zb$a7[H[640018]]['G$lT'] = function () {
      this['G$WT']();
    }, zb$a7[H[640018]]['G$wT'] = function () {
      this[H[641441]][H[641478]] = !0x1;
    }, zb$a7[H[640018]]['G$pT'] = function () {
      this['G$YT'] = !this['G$YT'], this['G$YT'] && localStorage[H[641567]](this['G$O'], '1'), this[H[641405]][H[641473]] = H[641568] + (this['G$YT'] ? H[641569] : H[641570]);
    }, zb$a7[H[640018]]['G$DT'] = function (eg2) {
      this['G$WT'](Number(eg2));
    }, zb$a7[H[640018]]['G$S'] = function () {
      this['G$v'] = this[H[641427]][H[641571]], Laya[H[641572]]['on'](pu_9[H[641573]], this, this['G$mT']), Laya[H[641572]]['on'](pu_9[H[641574]], this, this['G$d']), Laya[H[641572]]['on'](pu_9[H[641575]], this, this['G$d']);
    }, zb$a7[H[640018]]['G$mT'] = function () {
      if (this[H[641427]]) {
        var d_p9s = this['G$v'] - this[H[641427]][H[641571]];this[H[641427]][H[641576]] += d_p9s, this['G$v'] = this[H[641427]][H[641571]];
      }
    }, zb$a7[H[640018]]['G$d'] = function () {
      Laya[H[641572]][H[640336]](pu_9[H[641573]], this, this['G$mT']), Laya[H[641572]][H[640336]](pu_9[H[641574]], this, this['G$d']), Laya[H[641572]][H[640336]](pu_9[H[641575]], this, this['G$d']);
    }, zb$a7[H[640018]]['G$TT'] = function () {
      this['G$R'] = this[H[641439]][H[641571]], Laya[H[641572]]['on'](pu_9[H[641573]], this, this['G$cT']), Laya[H[641572]]['on'](pu_9[H[641574]], this, this['G$G']), Laya[H[641572]]['on'](pu_9[H[641575]], this, this['G$G']);
    }, zb$a7[H[640018]]['G$cT'] = function () {
      if (this[H[641440]]) {
        var w2j81 = this['G$R'] - this[H[641439]][H[641571]];this[H[641440]]['y'] -= w2j81, this[H[641439]][H[641319]] < this[H[641440]][H[641577]] ? this[H[641440]]['y'] < this[H[641439]][H[641319]] - this[H[641440]][H[641577]] ? this[H[641440]]['y'] = this[H[641439]][H[641319]] - this[H[641440]][H[641577]] : 0x0 < this[H[641440]]['y'] && (this[H[641440]]['y'] = 0x0) : this[H[641440]]['y'] = 0x0, this['G$R'] = this[H[641439]][H[641571]];
      }
    }, zb$a7[H[640018]]['G$G'] = function () {
      Laya[H[641572]][H[640336]](pu_9[H[641573]], this, this['G$cT']), Laya[H[641572]][H[640336]](pu_9[H[641574]], this, this['G$G']), Laya[H[641572]][H[640336]](pu_9[H[641575]], this, this['G$G']);
    }, zb$a7[H[640018]]['G$uT'] = function () {
      this['G$F'] = this[H[641446]][H[641571]], Laya[H[641572]]['on'](pu_9[H[641573]], this, this['G$aT']), Laya[H[641572]]['on'](pu_9[H[641574]], this, this['G$N']), Laya[H[641572]]['on'](pu_9[H[641575]], this, this['G$N']);
    }, zb$a7[H[640018]]['G$aT'] = function () {
      if (this[H[641447]]) {
        var t5ejv8 = this['G$F'] - this[H[641446]][H[641571]];this[H[641447]]['y'] -= t5ejv8, this[H[641446]][H[641319]] < this[H[641447]][H[641577]] ? this[H[641447]]['y'] < this[H[641446]][H[641319]] - this[H[641447]][H[641577]] ? this[H[641447]]['y'] = this[H[641446]][H[641319]] - this[H[641447]][H[641577]] : 0x0 < this[H[641447]]['y'] && (this[H[641447]]['y'] = 0x0) : this[H[641447]]['y'] = 0x0, this['G$F'] = this[H[641446]][H[641571]];
      }
    }, zb$a7[H[640018]]['G$N'] = function () {
      Laya[H[641572]][H[640336]](pu_9[H[641573]], this, this['G$aT']), Laya[H[641572]][H[640336]](pu_9[H[641574]], this, this['G$N']), Laya[H[641572]][H[640336]](pu_9[H[641575]], this, this['G$N']);
    }, zb$a7[H[640018]]['G$PT'] = function () {
      if (this['G$H'][H[641557]]) {
        for (var taznx7, hdl4c = 0x0; hdl4c < this['G$H'][H[641557]][H[640031]]; hdl4c++) {
          var q30m$ = this['G$H'][H[641557]][hdl4c];q30m$[0x1] = hdl4c == this['G$H'][H[641578]], hdl4c == this['G$H'][H[641578]] && (taznx7 = q30m$[0x0]);
        }taznx7 && taznx7[H[641579]] && (taznx7[H[641579]] = taznx7[H[641579]][H[640243]](/(<)(?!(br)).[a-zA-Z]{0,10}(>)/g, '')), this[H[641437]][H[641253]] = taznx7 && taznx7[H[641580]] ? taznx7[H[641580]] : '', this[H[641440]][H[641581]] = taznx7 && taznx7[H[641579]] ? taznx7[H[641579]] : '', this[H[641440]]['y'] = 0x0;
      }
    }, zb$a7[H[640018]]['G$jT'] = function () {
      if (this['G$X'][H[641557]]) {
        for (var hw1ge, w21eg = 0x0; w21eg < this['G$X'][H[641557]][H[640031]]; w21eg++) {
          var x$bm = this['G$X'][H[641557]][w21eg];x$bm[0x1] = w21eg == this['G$X'][H[641578]], w21eg == this['G$X'][H[641578]] && (hw1ge = x$bm[0x0]);
        }hw1ge && hw1ge[H[641579]] && (hw1ge[H[641579]] = hw1ge[H[641579]][H[640243]](/(<)(?!(br)).[a-zA-Z]{0,10}(>)/g, '')), this[H[641445]][H[641253]] = hw1ge && hw1ge[H[641580]] ? hw1ge[H[641580]] : '', this[H[641447]][H[641581]] = hw1ge && hw1ge[H[641579]] ? hw1ge[H[641579]] : '', this[H[641447]]['y'] = 0x0;
      }
    }, zb$a7[H[640018]]['G$MT'] = function (z5vant) {
      this[H[641414]][H[641253]] = -0x1 === z5vant[H[641187]] ? z5vant[H[641183]] + H[641582] : 0x0 === z5vant[H[641187]] ? z5vant[H[641183]] + H[641583] : z5vant[H[641183]], this[H[641414]][H[641503]] = -0x1 === z5vant[H[641187]] ? H[641584] : 0x0 === z5vant[H[641187]] ? H[641585] : this['G$k'], this[H[641401]][H[641473]] = this[H[641586]](z5vant[H[641187]]), this['G$a'][H[640933]] = z5vant[H[640933]] || '', this['G$a'][H[640935]] = z5vant, this[H[641417]][H[641478]] = !0x0;
    }, zb$a7[H[640018]]['G$BT'] = function (rmq3b) {
      this[H[641268]](rmq3b);
    }, zb$a7[H[640018]]['G$sT'] = function (s4luk) {
      this['G$MT'](s4luk), this[H[641448]][H[641478]] = !0x1;
    }, zb$a7[H[640018]][H[641268]] = function (m0bqr) {
      if (void 0x0 === m0bqr && (m0bqr = 0x0), this[H[640125]]) {
        var ntzx7a = this['G$a'][H[641266]];if (ntzx7a && 0x0 !== ntzx7a[H[640031]]) {
          for (var uy96_p = ntzx7a[H[640031]], up9ds = 0x0; up9ds < uy96_p; up9ds++) ntzx7a[up9ds][H[641587]] = this['G$BT'][H[640017]](this), ntzx7a[up9ds][H[641588]] = up9ds == m0bqr, ntzx7a[up9ds][H[641589]] = up9ds;var lg4kc = (this['G$$'][H[640368]] = ntzx7a)[m0bqr]['id'];this['G$a'][H[641073]][lg4kc] ? this[H[641274]](lg4kc) : this['G$a'][H[641272]] || (this['G$a'][H[641272]] = !0x0, -0x1 == lg4kc ? f1KBT(0x0) : -0x2 == lg4kc ? f12B9T(0x0) : f1BKT(0x0, lg4kc));
        }
      }
    }, zb$a7[H[640018]][H[641274]] = function (d4hkc) {
      if (this[H[640125]] && this['G$a'][H[641073]][d4hkc]) {
        for (var zn$7 = this['G$a'][H[641073]][d4hkc], pyu6_9 = zn$7[H[640031]], ls4kcd = 0x0; ls4kcd < pyu6_9; ls4kcd++) zn$7[ls4kcd][H[641587]] = this['G$sT'][H[640017]](this);this['G$Z'][H[640368]] = zn$7;
      }
    }, zb$a7[H[640018]]['G$LT'] = function (jn5v) {
      return -0x1 == jn5v[H[641187]] ? (alert(H[641590]), !0x1) : 0x0 != jn5v[H[641187]] || (alert(H[641591]), !0x1);
    }, zb$a7[H[640018]][H[641586]] = function (e18j2) {
      var psd_9 = '';return 0x2 === e18j2 ? psd_9 = H[641402] : 0x1 === e18j2 ? psd_9 = H[641592] : -0x1 !== e18j2 && 0x0 !== e18j2 || (psd_9 = H[641593]), psd_9;
    }, zb$a7[H[640018]]['G$zT'] = function (klgcw) {
      console[H[640225]](H[641594], klgcw);var n8v5j = Date[H[641047]]() / 0x3e8,
          rbqm = localStorage[H[641562]](this['G$x']),
          xbaz = !(this['G$n'] = []);if (H[641168] == klgcw[H[641103]]) for (var $mqb in klgcw[H[640335]]) {
        var hcgklw = klgcw[H[640335]][$mqb],
            v8t5a = n8v5j < hcgklw[H[641595]],
            _9piy = 0x1 == hcgklw[H[641596]],
            bm0x3$ = 0x2 == hcgklw[H[641596]] && hcgklw[H[641597]] + '' != rbqm;!xbaz && v8t5a && (_9piy || bm0x3$) && (xbaz = !0x0), v8t5a && this['G$n'][H[640066]](hcgklw), bm0x3$ && localStorage[H[641567]](this['G$x'], hcgklw[H[641597]] + '');
      }this['G$n'][H[640382]](function (i9_py, v8jnt5) {
        return i9_py[H[641598]] - v8jnt5[H[641598]];
      }), console[H[640225]](H[641599], this['G$n']), xbaz && this['G$iT']();
    }, zb$a7[H[640018]]['G$iT'] = function () {
      if (this['G$H']) {
        if (this['G$n']) {
          this['G$H']['x'] = 0x2 < this['G$n'][H[640031]] ? 0x0 : (this[H[641436]][H[641317]] - 0x112 * this['G$n'][H[640031]]) / 0x2;for (var cghk = [], x0mb3$ = 0x0; x0mb3$ < this['G$n'][H[640031]]; x0mb3$++) {
            var hwglck = this['G$n'][x0mb3$];cghk[H[640066]]([hwglck, x0mb3$ == this['G$H'][H[641578]]]);
          }0x0 < (this['G$H'][H[641557]] = cghk)[H[640031]] ? (this['G$H'][H[641578]] = 0x0, this['G$H'][H[641600]](0x0)) : (this[H[641437]][H[641253]] = H[641426], this[H[641440]][H[641253]] = ''), this[H[641432]][H[641478]] = this['G$n'][H[640031]] <= 0x1, this[H[641436]][H[641478]] = 0x1 < this['G$n'][H[640031]];
        }this[H[641430]][H[641478]] = !0x0;
      }
    }, zb$a7[H[640018]]['G$tT'] = function () {
      for (var $bx0m3 = '', j8v5tn = 0x0; j8v5tn < this['G$bT'][H[640031]]; j8v5tn++) {
        $bx0m3 += H[641601] + j8v5tn + H[641602] + this['G$bT'][j8v5tn][H[641580]] + H[641603], j8v5tn < this['G$bT'][H[640031]] - 0x1 && ($bx0m3 += '、');
      }this[H[641416]][H[641581]] = H[641604] + $bx0m3, this[H[641405]][H[641473]] = H[641568] + (this['G$YT'] ? H[641569] : H[641570]), this[H[641416]]['x'] = (0x2d0 - this[H[641416]][H[641317]]) / 0x2, this[H[641405]]['x'] = this[H[641416]]['x'] - 0x1e, this[H[641419]][H[641478]] = 0x0 < this['G$bT'][H[640031]], this[H[641405]][H[641478]] = this[H[641416]][H[641478]] = 0x0 < this['G$bT'][H[640031]] && 0x0 != this['G$KT'];
    }, zb$a7[H[640018]]['G$WT'] = function (n7az$) {
      if (void 0x0 === n7az$ && (n7az$ = 0x0), this['G$X']) {
        if (this['G$bT']) {
          this['G$X']['x'] = 0x2 < this['G$bT'][H[640031]] ? 0x0 : (this[H[641436]][H[641317]] - 0x112 * this['G$bT'][H[640031]]) / 0x2;for (var a7$zxn = [], jve8t5 = 0x0; jve8t5 < this['G$bT'][H[640031]]; jve8t5++) {
            var cgkh4l = this['G$bT'][jve8t5];a7$zxn[H[640066]]([cgkh4l, jve8t5 == this['G$X'][H[641578]]]);
          }0x0 < (this['G$X'][H[641557]] = a7$zxn)[H[640031]] ? (this['G$X'][H[641578]] = n7az$, this['G$X'][H[641600]](n7az$)) : (this[H[641445]][H[641253]] = H[641605], this[H[641447]][H[641253]] = ''), this[H[641443]][H[641478]] = this['G$bT'][H[640031]] <= 0x1, this[H[641444]][H[641478]] = 0x1 < this['G$bT'][H[640031]];
        }this[H[641441]][H[641478]] = !0x0;
      }
    }, zb$a7[H[640018]]['G$AT'] = function (a7bxz$) {
      this[H[641407]][H[641253]] = a7bxz$, this[H[641407]]['y'] = 0x280, this[H[641407]][H[641478]] = !0x0, this['G$rT'] = 0x1, Laya[H[641480]][H[641481]](this, this['G$h']), this['G$h'](), Laya[H[641480]][H[641506]](0x1, this, this['G$h']);
    }, zb$a7[H[640018]]['G$h'] = function () {
      this[H[641407]]['y'] -= this['G$rT'], this['G$rT'] *= 1.1, this[H[641407]]['y'] <= 0x24e && (this[H[641407]][H[641478]] = !0x1, Laya[H[641480]][H[641481]](this, this['G$h']));
    }, zb$a7;
  }(fdchkl['G$w']), gc4lhk[H[641606]] = ghe12;
}(modules || (modules = {}));var modules,
    fn8t5j = Laya[H[641607]],
    fdslku4 = Laya[H[641608]],
    ftn8a = Laya[H[641609]],
    fgweh21 = Laya[H[641610]],
    fta5nv = Laya[H[641556]],
    fhclkw = modules['G$u'][H[641467]],
    fzna7$x = modules['G$u'][H[641529]],
    fazn7tx = modules['G$u'][H[641606]],
    fhg2c1 = function () {
  function jt5nv8(t8nv) {
    this[H[641611]] = [H[641354], H[641502], H[641356], H[641358], H[641360], H[641374], H[641372], H[641370], H[641612], H[641613], H[641614], H[641615], H[641616], H[641492], H[641497], H[641378], H[641514], H[641494], H[641495], H[641496], H[641493], H[641499], H[641500], H[641501], H[641498]], this['f129BT'] = [H[641424], H[641418], H[641404], H[641420], H[641617], H[641618], H[641619], H[641453], H[641402], H[641592], H[641593], H[641398], H[641339], H[641344], H[641346], H[641348], H[641342], H[641351], H[641422], H[641449], H[641620], H[641433], H[641400], H[641406], H[641621]], this[H[641622]] = !0x1, this[H[641623]] = !0x1, this['G$IT'] = !0x1, this['G$QT'] = '', jt5nv8[H[640947]] = this, Laya[H[641624]][H[641132]](), Laya3D[H[641132]](0x0, 0x0, !0x1, !0x1, !0x1), DecodeTools[H[641132]](), Laya[H[641572]][H[641625]] = Laya[H[641626]][H[641627]], Laya[H[641572]][H[641628]] = Laya[H[641626]][H[641629]], Laya[H[641572]][H[641630]] = Laya[H[641626]][H[641631]], Laya[H[641572]][H[641632]] = Laya[H[641626]][H[641633]], Laya[H[641572]][H[641634]] = Laya[H[641626]][H[641635]];var lh4dck = Laya[H[641636]];lh4dck[H[641637]] = 0x6, lh4dck[H[641638]] = lh4dck[H[641639]] = 0x400, lh4dck[H[641640]](), Laya[H[641641]][H[641642]] = Laya[H[641641]][H[641643]] = '', Laya[H[641607]][H[641464]][H[641644]](Laya[H[641459]][H[641645]], this['G$oT'][H[640017]](this)), Laya[H[641469]][H[641646]][H[641647]] = { 'frames': { 'btn_chuangjue_kaishi.png': { 'frame': { 'h': 0x58, 'idx': 0x0, 'w': 0x1fa, 'x': 0x0, 'y': 0x0 }, 'sourceSize': { 'h': 0x58, 'w': 0x1fa }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'btn_chuangjue_nan.png': { 'frame': { 'h': 0x62, 'idx': 0x0, 'w': 0x6c, 'x': 0x14f, 'y': 0x59 }, 'sourceSize': { 'h': 0x62, 'w': 0x6c }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'btn_chuangjue_nv.png': { 'frame': { 'h': 0x62, 'idx': 0x0, 'w': 0x6b, 'x': 0x0, 'y': 0xa4 }, 'sourceSize': { 'h': 0x62, 'w': 0x6b }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'image_chuangjue_mingbg.png': { 'frame': { 'h': 0x4a, 'idx': 0x0, 'w': 0x14e, 'x': 0x0, 'y': 0x59 }, 'sourceSize': { 'h': 0x4a, 'w': 0x14e }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'image_chuangjue_suiji.png': { 'frame': { 'h': 0x38, 'idx': 0x0, 'w': 0x34, 'x': 0x1bc, 'y': 0x59 }, 'sourceSize': { 'h': 0x38, 'w': 0x34 }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } }, 'z999z99928b.png': { 'frame': { 'h': 0x19, 'idx': 0x0, 'w': 0x19, 'x': 0x1bc, 'y': 0x92 }, 'sourceSize': { 'h': 0x1b, 'w': 0x1a }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x2 } }, 'z999z99929b.png': { 'frame': { 'h': 0x1b, 'idx': 0x0, 'w': 0x1a, 'x': 0x1d6, 'y': 0x92 }, 'sourceSize': { 'h': 0x1b, 'w': 0x1a }, 'spriteSourceSize': { 'x': 0x0, 'y': 0x0 } } }, 'meta': { 'image': H[641648], 'prefix': H[641649] } }, fn8t5j[H[641464]][H[641650]] = jt5nv8[H[640947]]['f12T9'], fn8t5j[H[641464]][H[641651]] = jt5nv8[H[640947]]['f12T9'], this[H[641652]] = new Laya[H[641468]](), this[H[641652]][H[640042]] = H[641653], Laya[H[641572]][H[641470]](this[H[641652]]), this['G$oT']();
  }return jt5nv8[H[640018]]['f1K9BT'] = function (b0$x7z) {
    jt5nv8[H[640947]][H[641652]][H[641478]] = b0$x7z;
  }, jt5nv8[H[640018]]['f12BT9K'] = function () {
    jt5nv8[H[640947]][H[641654]] || (jt5nv8[H[640947]][H[641654]] = new fhclkw()), jt5nv8[H[640947]][H[641654]][H[640125]] || jt5nv8[H[640947]][H[641652]][H[641470]](jt5nv8[H[640947]][H[641654]]), jt5nv8[H[640947]]['G$eT']();
  }, jt5nv8[H[640018]][H[641108]] = function () {
    this[H[641654]] && this[H[641654]][H[640125]] && (Laya[H[641572]][H[641655]](this[H[641654]]), this[H[641654]][H[641463]](!0x0), this[H[641654]] = null);
  }, jt5nv8[H[640018]]['f129BTK'] = function () {
    this[H[641622]] || (this[H[641622]] = !0x0, Laya[H[641656]][H[640231]](this['f129BT'], fta5nv[H[640014]](this, function () {
      fn8t5j[H[641464]][H[641086]] = !0x0, fn8t5j[H[641464]]['f19BTK'](), fn8t5j[H[641464]]['f19TKB']();
    })));
  }, jt5nv8[H[640018]][H[641191]] = function () {
    for (var e1w2jg = function () {
      jt5nv8[H[640947]][H[641657]] || (jt5nv8[H[640947]][H[641657]] = new fazn7tx()), jt5nv8[H[640947]][H[641657]][H[640125]] || jt5nv8[H[640947]][H[641652]][H[641470]](jt5nv8[H[640947]][H[641657]]), jt5nv8[H[640947]]['G$eT']();
    }, bxz7$a = !0x0, s4lkdu = 0x0, tav7n = this['f129BT']; s4lkdu < tav7n[H[640031]]; s4lkdu++) {
      var v5nazt = tav7n[s4lkdu];if (null == Laya[H[641469]][H[641483]](v5nazt)) {
        bxz7$a = !0x1;break;
      }
    }bxz7$a ? e1w2jg() : Laya[H[641656]][H[640231]](this['f129BT'], fta5nv[H[640014]](this, e1w2jg));
  }, jt5nv8[H[640018]][H[641109]] = function () {
    this[H[641657]] && this[H[641657]][H[640125]] && (Laya[H[641572]][H[641655]](this[H[641657]]), this[H[641657]][H[641463]](!0x0), this[H[641657]] = null);
  }, jt5nv8[H[640018]][H[641462]] = function () {
    this[H[641623]] || (this[H[641623]] = !0x0, Laya[H[641656]][H[640231]](this[H[641611]], fta5nv[H[640014]](this, function () {
      fn8t5j[H[641464]][H[641087]] = !0x0, fn8t5j[H[641464]]['f19BTK'](), fn8t5j[H[641464]]['f19TKB']();
    })));
  }, jt5nv8[H[640018]][H[641190]] = function (w12hge) {
    void 0x0 === w12hge && (w12hge = 0x0), Laya[H[641656]][H[640231]](this[H[641611]], fta5nv[H[640014]](this, function () {
      jt5nv8[H[640947]][H[641658]] || (jt5nv8[H[640947]][H[641658]] = new fzna7$x(w12hge)), jt5nv8[H[640947]][H[641658]][H[640125]] || jt5nv8[H[640947]][H[641652]][H[641470]](jt5nv8[H[640947]][H[641658]]), jt5nv8[H[640947]]['G$eT']();
    }));
  }, jt5nv8[H[640018]][H[641110]] = function () {
    this[H[641658]] && this[H[641658]][H[640125]] && (Laya[H[641572]][H[641655]](this[H[641658]]), this[H[641658]][H[641463]](!0x0), this[H[641658]] = null);for (var dkl4cs = 0x0, wgchk = this['f129BT']; dkl4cs < wgchk[H[640031]]; dkl4cs++) {
      var b3r0q = wgchk[dkl4cs];Laya[H[641469]][H[641659]](jt5nv8[H[640947]], b3r0q), Laya[H[641469]][H[641660]](b3r0q, !0x0);
    }for (var bxm0 = 0x0, y96pu = this[H[641611]]; bxm0 < y96pu[H[640031]]; bxm0++) {
      b3r0q = y96pu[bxm0], (Laya[H[641469]][H[641659]](jt5nv8[H[640947]], b3r0q), Laya[H[641469]][H[641660]](b3r0q, !0x0));
    }this[H[641652]][H[640125]] && this[H[641652]][H[640125]][H[641655]](this[H[641652]]);
  }, jt5nv8[H[640018]]['f129T'] = function () {
    this[H[641658]] && this[H[641658]][H[640125]] && jt5nv8[H[640947]][H[641658]][H[641303]]();
  }, jt5nv8[H[640018]][H[641465]] = function () {
    var hclwg1 = fn8t5j[H[641464]]['f1T9'][H[640935]];this['G$IT'] || -0x1 == hclwg1[H[641187]] || 0x0 == hclwg1[H[641187]] || (this['G$IT'] = !0x0, fn8t5j[H[641464]]['f1T9'][H[640935]] = hclwg1, f19KBT(0x0, hclwg1[H[640936]]));
  }, jt5nv8[H[640018]][H[641466]] = function () {
    var b3$xm0 = '';b3$xm0 += H[641661] + fn8t5j[H[641464]]['f1T9'][H[641181]], b3$xm0 += H[641662] + this[H[641622]], b3$xm0 += H[641663] + (null != jt5nv8[H[640947]][H[641657]]), b3$xm0 += H[641664] + this[H[641623]], b3$xm0 += H[641665] + (null != jt5nv8[H[640947]][H[641658]]), b3$xm0 += H[641666] + (fn8t5j[H[641464]][H[641650]] == jt5nv8[H[640947]]['f12T9']), b3$xm0 += H[641667] + (fn8t5j[H[641464]][H[641651]] == jt5nv8[H[640947]]['f12T9']), b3$xm0 += H[641668] + jt5nv8[H[640947]]['G$QT'];for (var a7$zb = 0x0, w182j = this['f129BT']; a7$zb < w182j[H[640031]]; a7$zb++) {
      b3$xm0 += ',\x20' + (kudsl = w182j[a7$zb]) + '=' + (null != Laya[H[641469]][H[641483]](kudsl));
    }for (var ntvz = 0x0, ax = this[H[641611]]; ntvz < ax[H[640031]]; ntvz++) {
      var kudsl;b3$xm0 += ',\x20' + (kudsl = ax[ntvz]) + '=' + (null != Laya[H[641469]][H[641483]](kudsl));
    }var usk4dp = fn8t5j[H[641464]]['f1T9'][H[640935]];usk4dp && (b3$xm0 += H[641669] + usk4dp[H[641187]], b3$xm0 += H[641670] + usk4dp[H[640936]], b3$xm0 += H[641671] + usk4dp[H[641183]]);var spdu94 = JSON[H[640939]]({ 'error': H[641672], 'stack': b3$xm0 });console[H[640333]](spdu94), this['G$yT'] && this['G$yT'] == b3$xm0 || (this['G$yT'] = b3$xm0, f1TK9(spdu94));
  }, jt5nv8[H[640018]]['G$vT'] = function () {
    var sudp = Laya[H[641572]],
        avnt7 = Math[H[640071]](sudp[H[641317]]),
        e81j52 = Math[H[640071]](sudp[H[641319]]);e81j52 / avnt7 < 1.7777778 ? (this[H[641673]] = Math[H[640071]](avnt7 / (e81j52 / 0x500)), this[H[641674]] = 0x500, this[H[641675]] = e81j52 / 0x500) : (this[H[641673]] = 0x2d0, this[H[641674]] = Math[H[640071]](e81j52 / (avnt7 / 0x2d0)), this[H[641675]] = avnt7 / 0x2d0);var ks4lud = Math[H[640071]](sudp[H[641317]]),
        av7ntz = Math[H[640071]](sudp[H[641319]]);av7ntz / ks4lud < 1.7777778 ? (this[H[641673]] = Math[H[640071]](ks4lud / (av7ntz / 0x500)), this[H[641674]] = 0x500, this[H[641675]] = av7ntz / 0x500) : (this[H[641673]] = 0x2d0, this[H[641674]] = Math[H[640071]](av7ntz / (ks4lud / 0x2d0)), this[H[641675]] = ks4lud / 0x2d0), this['G$eT']();
  }, jt5nv8[H[640018]]['G$eT'] = function () {
    this[H[641652]] && (this[H[641652]][H[641544]](this[H[641673]], this[H[641674]]), this[H[641652]][H[641527]](this[H[641675]], this[H[641675]], !0x0));
  }, jt5nv8[H[640018]]['G$oT'] = function () {
    if (ftn8a[H[641676]] && fn8t5j[H[641677]]) {
      var j28e5v = parseInt(ftn8a[H[641678]][H[641545]][H[641009]][H[640243]]('px', '')),
          br30m = parseInt(ftn8a[H[641679]][H[641545]][H[641319]][H[640243]]('px', '')) * this[H[641675]],
          tjv5n = fn8t5j[H[641680]] / fgweh21[H[641681]][H[641317]];return 0x0 < (j28e5v = fn8t5j[H[641682]] - br30m * tjv5n - j28e5v) && (j28e5v = 0x0), void (fn8t5j[H[641683]][H[641545]][H[641009]] = j28e5v + 'px');
    }fn8t5j[H[641683]][H[641545]][H[641009]] = H[641684];var n$za7 = Math[H[640071]](fn8t5j[H[641317]]),
        bmx0$3 = Math[H[640071]](fn8t5j[H[641319]]);n$za7 = n$za7 + 0x1 & 0x7ffffffe, bmx0$3 = bmx0$3 + 0x1 & 0x7ffffffe;var zat5vn = Laya[H[641572]];0x3 == ENV ? (zat5vn[H[641625]] = Laya[H[641626]][H[641685]], zat5vn[H[641317]] = n$za7, zat5vn[H[641319]] = bmx0$3) : bmx0$3 < n$za7 ? (zat5vn[H[641625]] = Laya[H[641626]][H[641685]], zat5vn[H[641317]] = n$za7, zat5vn[H[641319]] = bmx0$3) : (zat5vn[H[641625]] = Laya[H[641626]][H[641627]], zat5vn[H[641317]] = 0x348, zat5vn[H[641319]] = Math[H[640071]](bmx0$3 / (n$za7 / 0x348)) + 0x1 & 0x7ffffffe), this['G$vT']();
  }, jt5nv8[H[640018]]['f12T9'] = function (_puys, $xaz7b) {
    function nv58t() {
      $xzab[H[641686]] = null, $xzab[H[641687]] = null;
    }var $xzab,
        bm30q$ = _puys;($xzab = new fn8t5j[H[641464]][H[641337]]())[H[641686]] = function () {
      nv58t(), $xaz7b(bm30q$, 0xc8, $xzab);
    }, $xzab[H[641687]] = function () {
      console[H[640383]](H[641688], bm30q$), jt5nv8[H[640947]]['G$QT'] += bm30q$ + '|', nv58t(), $xaz7b(bm30q$, 0x194, null);
    }, $xzab[H[641689]] = bm30q$, -0x1 == jt5nv8[H[640947]]['f129BT'][H[640146]](bm30q$) && -0x1 == jt5nv8[H[640947]][H[641611]][H[640146]](bm30q$) || Laya[H[641469]][H[641690]](jt5nv8[H[640947]], bm30q$);
  }, jt5nv8[H[640018]]['G$xT'] = function (e2851j, gc1w2) {
    return -0x1 != e2851j[H[640146]](gc1w2, e2851j[H[640031]] - gc1w2[H[640031]]);
  }, jt5nv8;
}();!function (clkhwg) {
  var u4skl, syu_p;u4skl = clkhwg['G$u'] || (clkhwg['G$u'] = {}), syu_p = function (dlkus) {
    function nvj5t8() {
      var rm0q3b = dlkus[H[640007]](this) || this;return rm0q3b['G$RT'] = H[641691], rm0q3b['G$FT'] = H[641692], rm0q3b[H[641317]] = 0x112, rm0q3b[H[641319]] = 0x3b, rm0q3b['G$OT'] = new Laya[H[641337]](), rm0q3b[H[641470]](rm0q3b['G$OT']), rm0q3b['G$$T'] = new Laya[H[641361]](), rm0q3b['G$$T'][H[641524]] = 0x1e, rm0q3b['G$$T'][H[641503]] = rm0q3b['G$FT'], rm0q3b[H[641470]](rm0q3b['G$$T']), rm0q3b['G$$T'][H[641455]] = 0x0, rm0q3b['G$$T'][H[641456]] = 0x0, rm0q3b;
    }return fudkl(nvj5t8, dlkus), nvj5t8[H[640018]][H[641454]] = function () {
      dlkus[H[640018]][H[641454]][H[640007]](this), this['G$a'] = fn8t5j[H[641464]]['f1T9'], this['G$a'][H[641084]], this[H[641457]]();
    }, Object[H[640008]](nvj5t8[H[640018]], H[641557], { 'set': function (bx$3m) {
        bx$3m && this[H[641693]](bx$3m);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), nvj5t8[H[640018]][H[641693]] = function ($07bxm) {
      this['G$ZT'] = $07bxm[0x0], this['G$HT'] = $07bxm[0x1], this['G$$T'][H[641253]] = this['G$ZT'][H[641580]], this['G$$T'][H[641503]] = this['G$HT'] ? this['G$RT'] : this['G$FT'], this['G$OT'][H[641473]] = this['G$HT'] ? H[641433] : H[641620];
    }, nvj5t8[H[640018]][H[641463]] = function (d4kul) {
      void 0x0 === d4kul && (d4kul = !0x0), this[H[641461]](), dlkus[H[640018]][H[641463]][H[640007]](this, d4kul);
    }, nvj5t8[H[640018]][H[641457]] = function () {}, nvj5t8[H[640018]][H[641461]] = function () {}, nvj5t8;
  }(Laya[H[641331]]), u4skl[H[641540]] = syu_p;
}(modules || (modules = {})), function (v85njt) {
  var _9yi6p, cdl4;_9yi6p = v85njt['G$u'] || (v85njt['G$u'] = {}), cdl4 = function (azbx$7) {
    function zvatn7() {
      var r3bm0q = azbx$7[H[640007]](this) || this;return r3bm0q['G$RT'] = H[641691], r3bm0q['G$FT'] = H[641692], r3bm0q[H[641317]] = 0x112, r3bm0q[H[641319]] = 0x3b, r3bm0q['G$OT'] = new Laya[H[641337]](), r3bm0q[H[641470]](r3bm0q['G$OT']), r3bm0q['G$$T'] = new Laya[H[641361]](), r3bm0q['G$$T'][H[641524]] = 0x1e, r3bm0q['G$$T'][H[641503]] = r3bm0q['G$FT'], r3bm0q[H[641470]](r3bm0q['G$$T']), r3bm0q['G$$T'][H[641455]] = 0x0, r3bm0q['G$$T'][H[641456]] = 0x0, r3bm0q;
    }return fudkl(zvatn7, azbx$7), zvatn7[H[640018]][H[641454]] = function () {
      azbx$7[H[640018]][H[641454]][H[640007]](this), this['G$a'] = fn8t5j[H[641464]]['f1T9'], this['G$a'][H[641084]], this[H[641457]]();
    }, Object[H[640008]](zvatn7[H[640018]], H[641557], { 'set': function (lg) {
        lg && this[H[641693]](lg);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), zvatn7[H[640018]][H[641693]] = function (wgkh) {
      this['G$ZT'] = wgkh[0x0], this['G$HT'] = wgkh[0x1], this['G$$T'][H[641253]] = this['G$ZT'][H[641580]], this['G$$T'][H[641503]] = this['G$HT'] ? this['G$RT'] : this['G$FT'], this['G$OT'][H[641473]] = this['G$HT'] ? H[641433] : H[641620];
    }, zvatn7[H[640018]][H[641463]] = function (txzn) {
      void 0x0 === txzn && (txzn = !0x0), this[H[641461]](), azbx$7[H[640018]][H[641463]][H[640007]](this, txzn);
    }, zvatn7[H[640018]][H[641457]] = function () {}, zvatn7[H[640018]][H[641461]] = function () {}, zvatn7;
  }(Laya[H[641331]]), _9yi6p[H[641542]] = cdl4;
}(modules || (modules = {})), function (py6_9) {
  var w2e8, nxatz;w2e8 = py6_9['G$u'] || (py6_9['G$u'] = {}), nxatz = function (h21ge) {
    function jet5() {
      var $zxn = h21ge[H[640007]](this) || this;return $zxn[H[641317]] = 0xc0, $zxn[H[641319]] = 0x46, $zxn['G$OT'] = new Laya[H[641337]](), $zxn[H[641470]]($zxn['G$OT']), $zxn['G$$T'] = new Laya[H[641361]](), $zxn['G$$T'][H[641524]] = 0x1e, $zxn['G$$T'][H[641503]] = $zxn['G$k'], $zxn[H[641470]]($zxn['G$$T']), $zxn['G$$T'][H[641455]] = 0x0, $zxn['G$$T'][H[641456]] = 0x0, $zxn;
    }return fudkl(jet5, h21ge), jet5[H[640018]][H[641454]] = function () {
      h21ge[H[640018]][H[641454]][H[640007]](this), this['G$a'] = fn8t5j[H[641464]]['f1T9'];var vn5a8t = this['G$a'][H[641084]];this['G$k'] = 0x1 == vn5a8t ? H[641692] : 0x2 == vn5a8t ? H[641692] : 0x3 == vn5a8t ? H[641694] : H[641692], this[H[641457]]();
    }, Object[H[640008]](jet5[H[640018]], H[641557], { 'set': function ($a7z) {
        $a7z && this[H[641693]]($a7z);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), jet5[H[640018]][H[641693]] = function (e8w2) {
      this['G$ZT'] = e8w2, this['G$$T'][H[641253]] = e8w2[H[640042]], this['G$OT'][H[641473]] = e8w2[H[641588]] ? H[641617] : H[641618];
    }, jet5[H[640018]][H[641463]] = function (m0qr) {
      void 0x0 === m0qr && (m0qr = !0x0), this[H[641461]](), h21ge[H[640018]][H[641463]][H[640007]](this, m0qr);
    }, jet5[H[640018]][H[641457]] = function () {
      this['on'](Laya[H[641459]][H[641574]], this, this[H[641695]]);
    }, jet5[H[640018]][H[641461]] = function () {
      this[H[640336]](Laya[H[641459]][H[641574]], this, this[H[641695]]);
    }, jet5[H[640018]][H[641695]] = function () {
      this['G$ZT'] && this['G$ZT'][H[641587]] && this['G$ZT'][H[641587]](this['G$ZT'][H[641589]]);
    }, jet5;
  }(Laya[H[641331]]), w2e8[H[641535]] = nxatz;
}(modules || (modules = {})), function (udkp) {
  var ud_ps9, hw1lc;ud_ps9 = udkp['G$u'] || (udkp['G$u'] = {}), hw1lc = function ($nxz) {
    function dsup9_() {
      var qrm30 = $nxz[H[640007]](this) || this;return qrm30['G$OT'] = new Laya[H[641337]](H[641619]), qrm30['G$$T'] = new Laya[H[641361]](), qrm30['G$$T'][H[641524]] = 0x1e, qrm30['G$$T'][H[641503]] = qrm30['G$k'], qrm30[H[641470]](qrm30['G$OT']), qrm30['G$XT'] = new Laya[H[641337]](), qrm30[H[641470]](qrm30['G$XT']), qrm30[H[641317]] = 0x166, qrm30[H[641319]] = 0x46, qrm30[H[641470]](qrm30['G$$T']), qrm30['G$XT'][H[641456]] = 0x0, qrm30['G$XT']['x'] = 0x12, qrm30['G$$T']['x'] = 0x50, qrm30['G$$T'][H[641456]] = 0x0, qrm30['G$OT'][H[641696]][H[641697]](0x0, 0x0, qrm30[H[641317]], qrm30[H[641319]], H[641698]), qrm30;
    }return fudkl(dsup9_, $nxz), dsup9_[H[640018]][H[641454]] = function () {
      $nxz[H[640018]][H[641454]][H[640007]](this), this['G$a'] = fn8t5j[H[641464]]['f1T9'];var pk4d = this['G$a'][H[641084]];this['G$k'] = 0x1 == pk4d ? H[641699] : 0x2 == pk4d ? H[641699] : 0x3 == pk4d ? H[641694] : H[641699], this[H[641457]]();
    }, Object[H[640008]](dsup9_[H[640018]], H[641557], { 'set': function (ew821j) {
        ew821j && this[H[641693]](ew821j);
      }, 'enumerable': !0x0, 'configurable': !0x0 }), dsup9_[H[640018]][H[641693]] = function (ys9_up) {
      this['G$ZT'] = ys9_up, this['G$$T'][H[641503]] = -0x1 === ys9_up[H[641187]] ? H[641584] : 0x0 === ys9_up[H[641187]] ? H[641585] : this['G$k'], this['G$$T'][H[641253]] = -0x1 === ys9_up[H[641187]] ? ys9_up[H[641183]] + H[641582] : 0x0 === ys9_up[H[641187]] ? ys9_up[H[641183]] + H[641583] : ys9_up[H[641183]], this['G$XT'][H[641473]] = this[H[641586]](ys9_up[H[641187]]);
    }, dsup9_[H[640018]][H[641463]] = function (uy9p_s) {
      void 0x0 === uy9p_s && (uy9p_s = !0x0), this[H[641461]](), $nxz[H[640018]][H[641463]][H[640007]](this, uy9p_s);
    }, dsup9_[H[640018]][H[641457]] = function () {
      this['on'](Laya[H[641459]][H[641574]], this, this[H[641695]]);
    }, dsup9_[H[640018]][H[641461]] = function () {
      this[H[640336]](Laya[H[641459]][H[641574]], this, this[H[641695]]);
    }, dsup9_[H[640018]][H[641695]] = function () {
      this['G$ZT'] && this['G$ZT'][H[641587]] && this['G$ZT'][H[641587]](this['G$ZT']);
    }, dsup9_[H[640018]][H[641586]] = function (a8tv5n) {
      var pk4dsu = '';return 0x2 === a8tv5n ? pk4dsu = H[641402] : 0x1 === a8tv5n ? pk4dsu = H[641592] : -0x1 !== a8tv5n && 0x0 !== a8tv5n || (pk4dsu = H[641593]), pk4dsu;
    }, dsup9_;
  }(Laya[H[641331]]), ud_ps9[H[641538]] = hw1lc;
}(modules || (modules = {})), window[H[640946]] = fhg2c1;