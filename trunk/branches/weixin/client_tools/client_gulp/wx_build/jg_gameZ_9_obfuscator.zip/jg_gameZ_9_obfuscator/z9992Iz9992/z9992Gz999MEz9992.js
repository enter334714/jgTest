var H = wx.$F;
console[H[640001]](H[640002]), window[H[640003]], wx[H[640004]](function (mdjqs) {
  if (mdjqs) {
    if (mdjqs[H[640005]]) {
      var qmdgy = window[H[640006]][H[640007]][H[640008]](new RegExp(/\./, 'g'), '_'),
          kb_a3 = mdjqs[H[640005]],
          zoc918 = kb_a3[H[640009]](/(z999z999z999z999z999\/z9992Gz999MEz9992.js:)[0-9]{1,60}(:)/g);if (zoc918) for (var t19r86 = 0x0; t19r86 < zoc918[H[640010]]; t19r86++) {
        if (zoc918[t19r86] && zoc918[t19r86][H[640010]] > 0x0) {
          var utp40 = parseInt(zoc918[t19r86][H[640008]](H[640011], '')[H[640008]](':', ''));kb_a3 = kb_a3[H[640008]](zoc918[t19r86], zoc918[t19r86][H[640008]](':' + utp40 + ':', ':' + (utp40 - 0x2) + ':'));
        }
      }kb_a3 = kb_a3[H[640008]](new RegExp(H[640012], 'g'), H[640013] + qmdgy + H[640014]), kb_a3 = kb_a3[H[640008]](new RegExp(H[640015], 'g'), H[640013] + qmdgy + H[640014]), mdjqs[H[640005]] = kb_a3;
    }var z9o8c1 = { 'id': window['f1$2'][H[640016]], 'role': window['f1$2'][H[640017]], 'level': window['f1$2'][H[640018]], 'user': window['f1$2'][H[640019]], 'version': window['f1$2'][H[640020]], 'cdn': window['f1$2'][H[640021]], 'pkgName': window['f1$2'][H[640022]], 'gamever': window[H[640006]][H[640007]], 'serverid': window['f1$2'][H[640023]] ? window['f1$2'][H[640023]][H[640024]] : 0x0, 'systemInfo': window[H[640025]], 'error': H[640026], 'stack': mdjqs ? mdjqs[H[640005]] : '' },
        n3kib = JSON[H[640027]](z9o8c1);console[H[640028]](H[640029] + n3kib), (!window[H[640003]] || window[H[640003]] != z9o8c1[H[640028]]) && (window[H[640003]] = z9o8c1[H[640028]], window['f1A$'](z9o8c1));
  }
});import 'z999z999bfz999z999.js';import 'z999z99911z999z999.js';window[H[640030]] = require(H[640031]);import 'z999INDz999z999.js';import 'z999z999Iz9991z999z999.js';import 'z999z999Mtadz999z999.js';import 'z999z999INIz999az999.js';import './mx.laya.fc.js';console[H[640001]](H[640032]), console[H[640001]](H[640033]), f1A$I2({ 'title': H[640034] });var ft0p64u = { 'f1KA2$I': !![] };new window[H[640035]](ft0p64u), window[H[640035]][H[640036]]['f1KI$2A']();if (window['f1KA$2I']) clearInterval(window['f1KA$2I']);window['f1KA$2I'] = null, window['f1KI2A$'] = function (tu0pl4, $gy7) {
  if (!tu0pl4 || !$gy7) return 0x0;tu0pl4 = tu0pl4[H[640037]]('.'), $gy7 = $gy7[H[640037]]('.');const m7q$gy = Math[H[640038]](tu0pl4[H[640010]], $gy7[H[640010]]);while (tu0pl4[H[640010]] < m7q$gy) {
    tu0pl4[H[640039]]('0');
  }while ($gy7[H[640010]] < m7q$gy) {
    $gy7[H[640039]]('0');
  }for (var ewn3lx = 0x0; ewn3lx < m7q$gy; ewn3lx++) {
    const l04utp = parseInt(tu0pl4[ewn3lx]),
          bie3na = parseInt($gy7[ewn3lx]);if (l04utp > bie3na) return 0x1;else {
      if (l04utp < bie3na) return -0x1;
    }
  }return 0x0;
}, window[H[640040]] = wx[H[640041]]()[H[640040]], console[H[640042]](H[640043] + window[H[640040]]);var fh12zoc = wx[H[640044]]();fh12zoc[H[640045]](function (rp649) {
  console[H[640042]](H[640046] + rp649[H[640047]]);
}), fh12zoc[H[640048]](function () {
  wx[H[640049]]({ 'title': H[640050], 'content': H[640051], 'showCancel': ![], 'success': function (u04lxp) {
      fh12zoc[H[640052]]();
    } });
}), fh12zoc[H[640053]](function () {
  console[H[640042]](H[640054]);
}), window['f1KI2$A'] = function () {
  console[H[640042]](H[640055]);var vk_b5 = wx[H[640056]]({ 'name': H[640057], 'success': function (v5jd) {
      console[H[640042]](H[640058]), console[H[640042]](v5jd), v5jd && v5jd[H[640059]] == H[640060] ? (window['f12I'] = !![], window['f12I$A'](), window['f12$AI']()) : setTimeout(function () {
        window['f1KI2$A']();
      }, 0x1f4);
    }, 'fail': function (t4ur6) {
      console[H[640042]](H[640061]), console[H[640042]](t4ur6), setTimeout(function () {
        window['f1KI2$A']();
      }, 0x1f4);
    } });vk_b5 && vk_b5[H[640062]](p4rtu6 => {});
}, window['f1K$A2I'] = function () {
  console[H[640042]](H[640063]);var a_v5kj = wx[H[640056]]({ 'name': H[640064], 'success': function ($dygq) {
      console[H[640042]](H[640065]), console[H[640042]]($dygq), $dygq && $dygq[H[640059]] == H[640060] ? (window['f1$I2'] = !![], window['f12I$A'](), window['f12$AI']()) : setTimeout(function () {
        window['f1K$A2I']();
      }, 0x1f4);
    }, 'fail': function (zr81) {
      console[H[640042]](H[640066]), console[H[640042]](zr81), setTimeout(function () {
        window['f1K$A2I']();
      }, 0x1f4);
    } });a_v5kj && a_v5kj[H[640062]](xnl0ew => {});
}, window[H[640067]] = function () {
  window['f1KI2A$'](window[H[640040]], H[640068]) >= 0x0 ? (console[H[640042]](H[640069] + window[H[640040]] + H[640070]), window['f1$A'](), window['f1KI2$A'](), window['f1K$A2I']()) : (window['f1$2A'](H[640071], window[H[640040]]), wx[H[640049]]({ 'title': H[640072], 'content': H[640073] }));
}, window[H[640025]] = '', wx[H[640074]]({ 'success'(vd$sj) {
    window[H[640025]] = H[640075] + vd$sj[H[640076]] + H[640077] + vd$sj[H[640078]] + H[640079] + vd$sj[H[640080]] + H[640081] + vd$sj[H[640082]] + H[640083] + vd$sj[H[640084]] + H[640085] + vd$sj[H[640040]] + H[640086] + vd$sj[H[640087]], console[H[640042]](window[H[640025]]), console[H[640042]](H[640088] + vd$sj[H[640089]] + H[640090] + vd$sj[H[640091]] + H[640092] + vd$sj[H[640093]] + H[640094] + vd$sj[H[640095]] + H[640096] + vd$sj[H[640097]] + H[640098] + vd$sj[H[640099]] + H[640100] + (vd$sj[H[640101]] ? vd$sj[H[640101]][H[640102]] + ',' + vd$sj[H[640101]][H[640103]] + ',' + vd$sj[H[640101]][H[640104]] + ',' + vd$sj[H[640101]][H[640105]] : ''));var v5bak = vd$sj[H[640082]] ? vd$sj[H[640082]][H[640106]]() : '',
        uxew = vd$sj[H[640078]] ? vd$sj[H[640078]][H[640106]]()[H[640008]]('\x20', '') : '';window['f1$2'][H[640107]] = v5bak[H[640108]](H[640109]) != -0x1, window['f1$2'][H[640110]] = v5bak[H[640108]](H[640111]) != -0x1, window['f1$2'][H[640112]] = v5bak[H[640108]](H[640109]) != -0x1 || v5bak[H[640108]](H[640111]) != -0x1, window['f1$2'][H[640113]] = v5bak[H[640108]](H[640114]) != -0x1 || v5bak[H[640108]](H[640115]) != -0x1, window['f1$2'][H[640116]] = vd$sj[H[640084]] ? vd$sj[H[640084]][H[640106]]() : '', window['f1$2']['f1KAI2$'] = ![], window['f1$2']['f1KA$I2'] = 0x2;if (v5bak[H[640108]](H[640111]) != -0x1) {
      if (vd$sj[H[640087]] >= 0x18) window['f1$2']['f1KA$I2'] = 0x3;else window['f1$2']['f1KA$I2'] = 0x2;
    } else {
      if (v5bak[H[640108]](H[640109]) != -0x1) {
        if (vd$sj[H[640087]] && vd$sj[H[640087]] >= 0x14) window['f1$2']['f1KA$I2'] = 0x3;else {
          if (uxew[H[640108]](H[640117]) != -0x1 || uxew[H[640108]](H[640118]) != -0x1 || uxew[H[640108]](H[640119]) != -0x1 || uxew[H[640108]](H[640120]) != -0x1 || uxew[H[640108]](H[640121]) != -0x1) window['f1$2']['f1KA$I2'] = 0x2;else window['f1$2']['f1KA$I2'] = 0x3;
        }
      } else window['f1$2']['f1KA$I2'] = 0x2;
    }console[H[640042]](H[640122] + window['f1$2']['f1KAI2$'] + H[640123] + window['f1$2']['f1KA$I2']);
  } }), wx[H[640124]]({ 'success': function (a3kibn) {
    console[H[640042]](H[640125] + a3kibn[H[640126]] + H[640127] + a3kibn[H[640128]]);
  } }), wx[H[640129]]({ 'success': function (_j) {
    console[H[640042]](H[640130] + _j[H[640131]]);
  } }), wx[H[640132]]({ 'keepScreenOn': !![] }), wx[H[640133]](function (o1zh) {
  console[H[640042]](H[640130] + o1zh[H[640131]] + H[640134] + o1zh[H[640135]]);
}), wx[H[640136]](function ($ygqm) {
  window['f1IA'] = $ygqm, window['f12AI'] && window['f1IA'] && (console[H[640001]](H[640137] + window['f1IA'][H[640138]]), window['f12AI'](window['f1IA']), window['f1IA'] = null);
}), window[H[640139]] = 0x0, window['f1K$I2A'] = 0x0, window[H[640140]] = null, wx[H[640141]](function () {
  window['f1K$I2A']++;var z1oc9 = Date[H[640142]]();(window[H[640139]] == 0x0 || z1oc9 - window[H[640139]] > 0x1d4c0) && (console[H[640143]](H[640144]), wx[H[640145]]());if (window['f1K$I2A'] >= 0x2) {
    window['f1K$I2A'] = 0x0, console[H[640028]](H[640146]), wx[H[640147]]('0', 0x1);if (window['f1$2'] && window['f1$2'][H[640107]]) window['f1$2A'](H[640148], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});