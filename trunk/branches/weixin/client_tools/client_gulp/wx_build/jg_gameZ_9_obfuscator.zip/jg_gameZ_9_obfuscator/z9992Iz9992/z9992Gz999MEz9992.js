var H = wx.$F;
console[H[640917]](H[640918]), window[H[640919]], wx[H[640920]](function (w2jge1) {
  if (w2jge1) {
    if (w2jge1[H[640056]]) {
      var $m0b3q = window[H[640921]][H[640922]][H[640243]](new RegExp(/\./, 'g'), '_'),
          r3mb = w2jge1[H[640056]],
          w2j8e = r3mb[H[640067]](/(z999z999z999z999z999\/z9992Gz999MEz9992.js:)[0-9]{1,60}(:)/g);if (w2j8e) for (var dsp4 = 0x0; dsp4 < w2j8e[H[640031]]; dsp4++) {
        if (w2j8e[dsp4] && w2j8e[dsp4][H[640031]] > 0x0) {
          var su9yp = parseInt(w2j8e[dsp4][H[640243]](H[640923], '')[H[640243]](':', ''));r3mb = r3mb[H[640243]](w2j8e[dsp4], w2j8e[dsp4][H[640243]](':' + su9yp + ':', ':' + (su9yp - 0x2) + ':'));
        }
      }r3mb = r3mb[H[640243]](new RegExp(H[640924], 'g'), H[640925] + $m0b3q + H[640926]), r3mb = r3mb[H[640243]](new RegExp(H[640927], 'g'), H[640925] + $m0b3q + H[640926]), w2jge1[H[640056]] = r3mb;
    }var n8ta5v = { 'id': window['f1T9'][H[640928]], 'role': window['f1T9'][H[640929]], 'level': window['f1T9'][H[640930]], 'user': window['f1T9'][H[640931]], 'version': window['f1T9'][H[640932]], 'cdn': window['f1T9'][H[640933]], 'pkgName': window['f1T9'][H[640934]], 'gamever': window[H[640921]][H[640922]], 'serverid': window['f1T9'][H[640935]] ? window['f1T9'][H[640935]][H[640936]] : 0x0, 'systemInfo': window[H[640937]], 'error': H[640938], 'stack': w2jge1 ? w2jge1[H[640056]] : '' },
        g1whe = JSON[H[640939]](n8ta5v);console[H[640333]](H[640940] + g1whe), (!window[H[640919]] || window[H[640919]] != n8ta5v[H[640333]]) && (window[H[640919]] = n8ta5v[H[640333]], window['f1KT'](n8ta5v));
  }
});import 'z999z999bfz999z999.js';import 'z999z99911z999z999.js';window[H[640941]] = require(H[640942]);import 'z999INDz999z999.js';import 'z999z999Iz9991z999z999.js';import 'z999z999Mtadz999z999.js';import 'z999z999INIz999az999.js';import './mx.laya.fc.js';console[H[640917]](H[640943]), console[H[640917]](H[640944]), f1KTB9({ 'title': H[640945] });var fgckl4h = { 'f12K9TB': !![] };new window[H[640946]](fgckl4h), window[H[640946]][H[640947]]['f12BT9K']();if (window['f12KT9B']) clearInterval(window['f12KT9B']);window['f12KT9B'] = null, window['f12B9KT'] = function (ckd4l, etv8j) {
  if (!ckd4l || !etv8j) return 0x0;ckd4l = ckd4l[H[640201]]('.'), etv8j = etv8j[H[640201]]('.');const hcwlkg = Math[H[640301]](ckd4l[H[640031]], etv8j[H[640031]]);while (ckd4l[H[640031]] < hcwlkg) {
    ckd4l[H[640066]]('0');
  }while (etv8j[H[640031]] < hcwlkg) {
    etv8j[H[640066]]('0');
  }for (var at7xz = 0x0; at7xz < hcwlkg; at7xz++) {
    const ge2h1w = parseInt(ckd4l[at7xz]),
          v5etj = parseInt(etv8j[at7xz]);if (ge2h1w > v5etj) return 0x1;else {
      if (ge2h1w < v5etj) return -0x1;
    }
  }return 0x0;
}, window[H[640948]] = wx[H[640949]]()[H[640948]], console[H[640225]](H[640950] + window[H[640948]]);var fnxa7$z = wx[H[640951]]();fnxa7$z[H[640952]](function (clkd4s) {
  console[H[640225]](H[640953] + clkd4s[H[640954]]);
}), fnxa7$z[H[640955]](function () {
  wx[H[640956]]({ 'title': H[640957], 'content': H[640958], 'showCancel': ![], 'success': function (k4sp) {
      fnxa7$z[H[640959]]();
    } });
}), fnxa7$z[H[640960]](function () {
  console[H[640225]](H[640961]);
}), window['f12B9TK'] = function () {
  console[H[640225]](H[640962]);var y69i_ = wx[H[640963]]({ 'name': H[640964], 'success': function (q0r3bm) {
      console[H[640225]](H[640965]), console[H[640225]](q0r3bm), q0r3bm && q0r3bm[H[640966]] == H[640967] ? (window['f19B'] = !![], window['f19BTK'](), window['f19TKB']()) : setTimeout(function () {
        window['f12B9TK']();
      }, 0x1f4);
    }, 'fail': function (b0$7x) {
      console[H[640225]](H[640968]), console[H[640225]](b0$7x), setTimeout(function () {
        window['f12B9TK']();
      }, 0x1f4);
    } });y69i_ && y69i_[H[640969]](jv85e2 => {});
}, window['f12TK9B'] = function () {
  console[H[640225]](H[640970]);var v5 = wx[H[640963]]({ 'name': H[640971], 'success': function (e5vj) {
      console[H[640225]](H[640972]), console[H[640225]](e5vj), e5vj && e5vj[H[640966]] == H[640967] ? (window['f1TB9'] = !![], window['f19BTK'](), window['f19TKB']()) : setTimeout(function () {
        window['f12TK9B']();
      }, 0x1f4);
    }, 'fail': function (v8t5je) {
      console[H[640225]](H[640973]), console[H[640225]](v8t5je), setTimeout(function () {
        window['f12TK9B']();
      }, 0x1f4);
    } });v5 && v5[H[640969]](b0xz$7 => {});
}, window[H[640974]] = function () {
  window['f12B9KT'](window[H[640948]], H[640975]) >= 0x0 ? (console[H[640225]](H[640976] + window[H[640948]] + H[640977]), window['f1TK'](), window['f12B9TK'](), window['f12TK9B']()) : (window['f1T9K'](H[640978], window[H[640948]]), wx[H[640956]]({ 'title': H[640979], 'content': H[640980] }));
}, window[H[640937]] = '', wx[H[640981]]({ 'success'(klwhgc) {
    window[H[640937]] = H[640982] + klwhgc[H[640983]] + H[640984] + klwhgc[H[640985]] + H[640986] + klwhgc[H[640987]] + H[640988] + klwhgc[H[640989]] + H[640990] + klwhgc[H[640991]] + H[640992] + klwhgc[H[640948]] + H[640993] + klwhgc[H[640994]], console[H[640225]](window[H[640937]]), console[H[640225]](H[640995] + klwhgc[H[640996]] + H[640997] + klwhgc[H[640998]] + H[640999] + klwhgc[H[641000]] + H[641001] + klwhgc[H[641002]] + H[641003] + klwhgc[H[641004]] + H[641005] + klwhgc[H[641006]] + H[641007] + (klwhgc[H[641008]] ? klwhgc[H[641008]][H[641009]] + ',' + klwhgc[H[641008]][H[641010]] + ',' + klwhgc[H[641008]][H[641011]] + ',' + klwhgc[H[641008]][H[641012]] : ''));var q3bmr0 = klwhgc[H[640989]] ? klwhgc[H[640989]][H[640103]]() : '',
        xab7z = klwhgc[H[640985]] ? klwhgc[H[640985]][H[640103]]()[H[640243]]('\x20', '') : '';window['f1T9'][H[641013]] = q3bmr0[H[640146]](H[641014]) != -0x1, window['f1T9'][H[641015]] = q3bmr0[H[640146]](H[641016]) != -0x1, window['f1T9'][H[641017]] = q3bmr0[H[640146]](H[641014]) != -0x1 || q3bmr0[H[640146]](H[641016]) != -0x1, window['f1T9'][H[641018]] = q3bmr0[H[640146]](H[641019]) != -0x1 || q3bmr0[H[640146]](H[641020]) != -0x1, window['f1T9'][H[641021]] = klwhgc[H[640991]] ? klwhgc[H[640991]][H[640103]]() : '', window['f1T9']['f12KB9T'] = ![], window['f1T9']['f12KTB9'] = 0x2;if (q3bmr0[H[640146]](H[641016]) != -0x1) {
      if (klwhgc[H[640994]] >= 0x18) window['f1T9']['f12KTB9'] = 0x3;else window['f1T9']['f12KTB9'] = 0x2;
    } else {
      if (q3bmr0[H[640146]](H[641014]) != -0x1) {
        if (klwhgc[H[640994]] && klwhgc[H[640994]] >= 0x14) window['f1T9']['f12KTB9'] = 0x3;else {
          if (xab7z[H[640146]](H[641022]) != -0x1 || xab7z[H[640146]](H[641023]) != -0x1 || xab7z[H[640146]](H[641024]) != -0x1 || xab7z[H[640146]](H[641025]) != -0x1 || xab7z[H[640146]](H[641026]) != -0x1) window['f1T9']['f12KTB9'] = 0x2;else window['f1T9']['f12KTB9'] = 0x3;
        }
      } else window['f1T9']['f12KTB9'] = 0x2;
    }console[H[640225]](H[641027] + window['f1T9']['f12KB9T'] + H[641028] + window['f1T9']['f12KTB9']);
  } }), wx[H[641029]]({ 'success': function (pi_y9) {
    console[H[640225]](H[641030] + pi_y9[H[641031]] + H[641032] + pi_y9[H[641033]]);
  } }), wx[H[641034]]({ 'success': function ($0xzb7) {
    console[H[640225]](H[641035] + $0xzb7[H[641036]]);
  } }), wx[H[641037]]({ 'keepScreenOn': !![] }), wx[H[641038]](function (v5jn8) {
  console[H[640225]](H[641035] + v5jn8[H[641036]] + H[641039] + v5jn8[H[641040]]);
}), wx[H[641041]](function (xz7$an) {
  window['f1BK'] = xz7$an, window['f19KB'] && window['f1BK'] && (console[H[640917]](H[641042] + window['f1BK'][H[641043]]), window['f19KB'](window['f1BK']), window['f1BK'] = null);
}), window[H[641044]] = 0x0, window['f12TB9K'] = 0x0, window[H[641045]] = null, wx[H[641046]](function () {
  window['f12TB9K']++;var tavn5z = Date[H[641047]]();(window[H[641044]] == 0x0 || tavn5z - window[H[641044]] > 0x1d4c0) && (console[H[640383]](H[641048]), wx[H[641049]]());if (window['f12TB9K'] >= 0x2) {
    window['f12TB9K'] = 0x0, console[H[640333]](H[641050]), wx[H[641051]]('0', 0x1);if (window['f1T9'] && window['f1T9'][H[641013]]) window['f1T9K'](H[641052], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});