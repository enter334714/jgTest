var H = wx.$F;
import fe58vtj from '../z999z999basdz999/z9995sdkz999.js';window[H[641053]] = { 'wxVersion': window[H[640921]][H[640922]] }, window[H[641054]] = ![], window['f19T'] = 0x1, window[H[641055]] = 0x1, window['f1BT9'] = !![], window[H[641056]] = !![], window['f12KBT9'] = '', window['f1T9'] = { 'base_cdn': H[641057], 'cdn': H[641057] }, f1T9[H[641058]] = {}, f1T9[H[640304]] = '0', f1T9[H[640987]] = window[H[641053]][H[641059]], f1T9[H[641020]] = '', f1T9['os'] = '1', f1T9[H[641060]] = H[641061], f1T9[H[641062]] = H[641063], f1T9[H[641064]] = H[641065], f1T9[H[641066]] = H[641067], f1T9[H[641068]] = H[641069], f1T9[H[641070]] = '1', f1T9[H[640934]] = '', f1T9[H[641071]] = '', f1T9[H[641072]] = 0x0, f1T9[H[641073]] = {}, f1T9[H[641074]] = parseInt(f1T9[H[641070]]), f1T9[H[641075]] = f1T9[H[641070]], f1T9[H[640935]] = {}, f1T9['f1KT'] = H[641076], f1T9[H[641077]] = ![], f1T9[H[641078]] = H[641079], f1T9[H[641080]] = Date[H[641047]](), f1T9[H[641081]] = H[641082], f1T9[H[641083]] = '_a', f1T9[H[641084]] = 0x2, f1T9[H[640932]] = 0x7c1, f1T9[H[641059]] = window[H[641053]][H[641059]], f1T9[H[641085]] = ![], f1T9[H[641013]] = ![], f1T9[H[641015]] = ![], f1T9[H[641018]] = ![], window['f1B9T'] = 0x5, window['f1B9'] = ![], window['f19B'] = ![], window['f1TB9'] = ![], window[H[641086]] = ![], window[H[641087]] = ![], window['f1T9B'] = ![], window['f1BT'] = ![], window['f1TB'] = ![], window['f19BT'] = ![], window[H[641088]] = function (ku4dl) {
  console[H[640225]](H[641088], ku4dl), wx[H[641089]]({}), wx[H[640956]]({ 'title': H[640979], 'content': ku4dl, 'success'(xb7az$) {
      if (xb7az$[H[641090]]) console[H[640225]](H[641091]);else xb7az$[H[641092]] && console[H[640225]](H[641093]);
    } });
}, window['f1KBT9'] = function (mrbq30) {
  console[H[640225]](H[641094], mrbq30), f1KT9B(), wx[H[640956]]({ 'title': H[640979], 'content': mrbq30, 'confirmText': H[641095], 'cancelText': H[641096], 'success'(jewg12) {
      if (jewg12[H[641090]]) window['f1TK']();else jewg12[H[641092]] && (console[H[640225]](H[641097]), wx[H[641098]]({}));
    } });
}, window[H[641099]] = function (zavt7n) {
  console[H[640225]](H[641099], zavt7n), wx[H[640956]]({ 'title': H[640979], 'content': zavt7n, 'confirmText': H[641100], 'showCancel': ![], 'complete'(gw2ch) {
      console[H[640225]](H[641097]), wx[H[641098]]({});
    } });
}, window['f1KB9T'] = ![], window['f1KTB9'] = function (cg1l) {
  window['f1KB9T'] = !![], wx[H[641101]](cg1l);
}, window['f1KT9B'] = function () {
  window['f1KB9T'] && (window['f1KB9T'] = ![], wx[H[641089]]({}));
}, window['f1K9BT'] = function (y6_9oi) {
  window[H[640946]][H[640947]]['f1K9BT'](y6_9oi);
}, window[H[641102]] = function (c2gwh1, d9usp4) {
  fe58vtj[H[641102]](c2gwh1, function (v58te) {
    v58te && v58te[H[640335]] ? v58te[H[640335]][H[641103]] == 0x1 ? d9usp4(!![]) : (d9usp4(![]), console[H[640917]](H[641104] + v58te[H[640335]][H[641105]])) : console[H[640225]](H[641102], v58te);
  });
}, window['f1K9TB'] = function (pusk4) {
  console[H[640225]](H[641106], pusk4);
}, window['f1KT9'] = function (m7bx) {}, window['f1K9T'] = function (cs4l, _iy9o, du9s4p) {}, window['f1K9'] = function (s4up) {
  console[H[640225]](H[641107], s4up), window[H[640946]][H[640947]][H[641108]](), window[H[640946]][H[640947]][H[641109]](), window[H[640946]][H[640947]][H[641110]]();
}, window['f19K'] = function (e15j28) {
  window['f1KBT9'](H[641111]);var e125j = { 'id': window['f1T9'][H[640928]], 'role': window['f1T9'][H[640929]], 'level': window['f1T9'][H[640930]], 'account': window['f1T9'][H[640931]], 'version': window['f1T9'][H[640932]], 'cdn': window['f1T9'][H[640933]], 'pkgName': window['f1T9'][H[640934]], 'gamever': window[H[640921]][H[640922]], 'serverid': window['f1T9'][H[640935]] ? window['f1T9'][H[640935]][H[640936]] : 0x0, 'systemInfo': window[H[640937]], 'error': H[641112], 'stack': e15j28 ? e15j28 : H[641111] },
      cwklgh = JSON[H[640939]](e125j);console[H[640333]](H[641113] + cwklgh), window['f1KT'](cwklgh);
}, window['f1TK9'] = function (hew2) {
  var j2w18 = JSON[H[640223]](hew2);j2w18[H[641114]] = window[H[640921]][H[640922]], j2w18[H[641115]] = window['f1T9'][H[640935]] ? window['f1T9'][H[640935]][H[640936]] : 0x0, j2w18[H[640937]] = window[H[640937]];var n7vz = JSON[H[640939]](j2w18);console[H[640333]](H[641116] + n7vz), window['f1KT'](n7vz);
}, window['f1T9K'] = function (lc4kdh, uy9) {
  var mb$x07 = { 'id': window['f1T9'][H[640928]], 'role': window['f1T9'][H[640929]], 'level': window['f1T9'][H[640930]], 'account': window['f1T9'][H[640931]], 'version': window['f1T9'][H[640932]], 'cdn': window['f1T9'][H[640933]], 'pkgName': window['f1T9'][H[640934]], 'gamever': window[H[640921]][H[640922]], 'serverid': window['f1T9'][H[640935]] ? window['f1T9'][H[640935]][H[640936]] : 0x0, 'systemInfo': window[H[640937]], 'error': lc4kdh, 'stack': uy9 },
      jnt8v5 = JSON[H[640939]](mb$x07);console[H[640383]](H[641117] + jnt8v5), window['f1KT'](jnt8v5);
}, window['f1KT'] = function (io69_y) {
  if (window['f1T9'][H[641021]] == H[641118]) return;var $3xbm = f1T9['f1KT'] + H[641119] + f1T9[H[640931]];wx[H[641120]]({ 'url': $3xbm, 'method': H[641121], 'data': io69_y, 'header': { 'content-type': H[641122], 'cache-control': H[641123] }, 'success': function (hwclkg) {
      DEBUG && console[H[640225]](H[641124], $3xbm, io69_y, hwclkg);
    }, 'fail': function (tavzn7) {
      DEBUG && console[H[640225]](H[641124], $3xbm, io69_y, tavzn7);
    }, 'complete': function () {} });
}, window[H[641125]] = function () {
  function w1eg2j() {
    return ((0x1 + Math[H[641126]]()) * 0x10000 | 0x0)[H[640060]](0x10)[H[640234]](0x1);
  }return w1eg2j() + w1eg2j() + '-' + w1eg2j() + '-' + w1eg2j() + '-' + w1eg2j() + '+' + w1eg2j() + w1eg2j() + w1eg2j();
}, window['f1TK'] = function () {
  console[H[640225]](H[641127]);var gc21wh = fe58vtj[H[641128]]();f1T9[H[641075]] = gc21wh[H[641129]], f1T9[H[641074]] = gc21wh[H[641129]], f1T9[H[641070]] = gc21wh[H[641129]], f1T9[H[640934]] = gc21wh[H[641130]];var bxm = { 'game_ver': f1T9[H[640987]] };f1T9[H[641071]] = this[H[641125]](), f1KTB9({ 'title': H[641131] }), fe58vtj[H[641132]](bxm, this['f19KT'][H[640017]](this));
}, window['f19KT'] = function (cghklw) {
  var ej2wg1 = cghklw[H[641133]];console[H[640225]](H[641134] + ej2wg1 + H[641135] + (ej2wg1 == 0x1) + H[641136] + cghklw[H[640922]] + H[641137] + window[H[641053]][H[641059]]);if (!cghklw[H[640922]] || window['f12B9KT'](window[H[641053]][H[641059]], cghklw[H[640922]]) < 0x0) console[H[640225]](H[641138]), f1T9[H[641062]] = H[641139], f1T9[H[641064]] = H[641140], f1T9[H[641066]] = H[641141], f1T9[H[640933]] = H[641142], f1T9[H[641143]] = H[641144], f1T9[H[641145]] = 'cg', f1T9[H[641085]] = ![];else window['f12B9KT'](window[H[641053]][H[641059]], cghklw[H[640922]]) == 0x0 ? (console[H[640225]](H[641146]), f1T9[H[641062]] = H[641063], f1T9[H[641064]] = H[641065], f1T9[H[641066]] = H[641067], f1T9[H[640933]] = H[641147], f1T9[H[641143]] = H[641144], f1T9[H[641145]] = H[641148], f1T9[H[641085]] = !![]) : (console[H[640225]](H[641149]), f1T9[H[641062]] = H[641063], f1T9[H[641064]] = H[641065], f1T9[H[641066]] = H[641067], f1T9[H[640933]] = H[641147], f1T9[H[641143]] = H[641144], f1T9[H[641145]] = H[641148], f1T9[H[641085]] = ![]);f1T9[H[641072]] = config[H[640051]] ? config[H[640051]] : 0x0, this['f1BTK9'](), this['f1BT9K'](), window[H[641150]] = 0x5, f1KTB9({ 'title': H[641151] }), fe58vtj[H[641152]](this['f19TK'][H[640017]](this));
}, window[H[641150]] = 0x5, window['f19TK'] = function (u_6y, ud4sp9) {
  if (u_6y == 0x0 && ud4sp9 && ud4sp9[H[640285]]) {
    f1T9[H[641153]] = ud4sp9[H[640285]];var dusl4k = this;f1KTB9({ 'title': H[641154] }), sendApi(f1T9[H[641062]], H[641155], { 'platform': f1T9[H[641060]], 'partner_id': f1T9[H[641070]], 'token': ud4sp9[H[640285]], 'game_pkg': f1T9[H[640934]], 'deviceId': f1T9[H[641071]], 'scene': H[641156] + f1T9[H[641072]] }, this['f1BKT9'][H[640017]](this), f1B9T, f19K);
  } else ud4sp9 && ud4sp9[H[640966]] && window[H[641150]] > 0x0 && (ud4sp9[H[640966]][H[640146]](H[641157]) != -0x1 || ud4sp9[H[640966]][H[640146]](H[641158]) != -0x1 || ud4sp9[H[640966]][H[640146]](H[641159]) != -0x1 || ud4sp9[H[640966]][H[640146]](H[641160]) != -0x1 || ud4sp9[H[640966]][H[640146]](H[641161]) != -0x1 || ud4sp9[H[640966]][H[640146]](H[641162]) != -0x1) ? (window[H[641150]]--, fe58vtj[H[641152]](this['f19TK'][H[640017]](this))) : (window['f1T9K'](H[641163], JSON[H[640939]]({ 'status': u_6y, 'data': ud4sp9 })), window['f1KBT9'](H[641164] + (ud4sp9 && ud4sp9[H[640966]] ? '，' + ud4sp9[H[640966]] : '')));
}, window['f1BKT9'] = function (kh4lc) {
  if (!kh4lc) {
    window['f1T9K'](H[641165], H[641166]), window['f1KBT9'](H[641167]);return;
  }if (kh4lc[H[641103]] != H[641168]) {
    window['f1T9K'](H[641165], JSON[H[640939]](kh4lc)), window['f1KBT9'](H[641169] + kh4lc[H[641103]]);return;
  }f1T9[H[641170]] = String(kh4lc[H[640931]]), f1T9[H[640931]] = String(kh4lc[H[640931]]), f1T9[H[640991]] = String(kh4lc[H[640991]]), f1T9[H[641075]] = String(kh4lc[H[640991]]), f1T9[H[641171]] = String(kh4lc[H[641171]]), f1T9[H[641172]] = String(kh4lc[H[641173]]), f1T9[H[641174]] = String(kh4lc[H[641175]]), f1T9[H[641173]] = '';var wj1ge = this;f1KTB9({ 'title': H[641176] }), sendApi(f1T9[H[641062]], H[641177], { 'partner_id': f1T9[H[641070]], 'uid': f1T9[H[640931]], 'version': f1T9[H[640987]], 'game_pkg': f1T9[H[640934]], 'device': f1T9[H[641071]] }, wj1ge['f1BK9T'][H[640017]](wj1ge), f1B9T, f19K);
}, window['f1BK9T'] = function (lck4ds) {
  if (!lck4ds) {
    window['f1KBT9'](H[641178]);return;
  }if (lck4ds[H[641103]] != H[641168]) {
    window['f1KBT9'](H[641179] + lck4ds[H[641103]]);return;
  }if (!lck4ds[H[640335]] || lck4ds[H[640335]][H[640031]] == 0x0) {
    window['f1KBT9'](H[641180]);return;
  }f1T9[H[641181]] = lck4ds[H[641182]], f1T9[H[640935]] = { 'server_id': String(lck4ds[H[640335]][0x0][H[640936]]), 'server_name': String(lck4ds[H[640335]][0x0][H[641183]]), 'entry_ip': lck4ds[H[640335]][0x0][H[641184]], 'entry_port': parseInt(lck4ds[H[640335]][0x0][H[641185]]), 'status': f1TBK(lck4ds[H[640335]][0x0]), 'start_time': lck4ds[H[640335]][0x0][H[641186]], 'cdn': f1T9[H[640933]] }, this['f19TBK']();
}, window['f19TBK'] = function () {
  if (f1T9[H[641181]] == 0x1) {
    var njvt85 = f1T9[H[640935]][H[641187]];if (njvt85 === -0x1 || njvt85 === 0x0) {
      window['f1KBT9'](njvt85 === -0x1 ? H[641188] : H[641189]);return;
    }f19KBT(0x0, f1T9[H[640935]][H[640936]]), window[H[640946]][H[640947]][H[641190]](f1T9[H[641181]]);
  } else window[H[640946]][H[640947]][H[641191]](), f1KT9B();window['f1TB'] = !![], window['f19BTK'](), window['f19TKB']();
}, window['f1BTK9'] = function () {
  sendApi(f1T9[H[641062]], H[641192], { 'game_pkg': f1T9[H[640934]], 'version_name': f1T9[H[641145]] }, this[H[641193]][H[640017]](this), f1B9T, f19K);
}, window[H[641193]] = function (gkh4lc) {
  if (!gkh4lc) {
    window['f1KBT9'](H[641194]);return;
  }if (gkh4lc[H[641103]] != H[641168]) {
    window['f1KBT9'](H[641195] + gkh4lc[H[641103]]);return;
  }if (!gkh4lc[H[640335]] || !gkh4lc[H[640335]][H[640987]]) {
    window['f1KBT9'](H[641196] + (gkh4lc[H[640335]] && gkh4lc[H[640335]][H[640987]]));return;
  }gkh4lc[H[640335]][H[641197]] && gkh4lc[H[640335]][H[641197]][H[640031]] > 0xa && (f1T9[H[641198]] = gkh4lc[H[640335]][H[641197]], f1T9[H[640933]] = gkh4lc[H[640335]][H[641197]]), gkh4lc[H[640335]][H[640987]] && (f1T9[H[640932]] = gkh4lc[H[640335]][H[640987]]), console[H[640917]](H[641199] + f1T9[H[640932]] + H[641200] + f1T9[H[641145]]), window['f1T9B'] = !![], window['f19BTK'](), window['f19TKB']();
}, window[H[641201]], window['f1BT9K'] = function () {
  sendApi(f1T9[H[641062]], H[641202], { 'game_pkg': f1T9[H[640934]] }, this['f1B9KT'][H[640017]](this), f1B9T, f19K);
}, window['f1B9KT'] = function (uyp_96) {
  if (uyp_96[H[641103]] === H[641168] && uyp_96[H[640335]]) {
    window[H[641201]] = uyp_96[H[640335]];for (var tazx7n in uyp_96[H[640335]]) {
      f1T9[tazx7n] = uyp_96[H[640335]][tazx7n];
    }
  } else console[H[640917]](H[641203] + uyp_96[H[641103]]);window['f1BT'] = !![], window['f19TKB']();
}, window[H[641204]] = function (v5tnza, a7bx$z, $0bz7, _uy96p, tv7za, jgw21e, usp9d4, n5t8av, zx$n7) {
  tv7za = String(tv7za);var kl4sud = usp9d4,
      cw2hg1 = n5t8av;f1T9[H[641058]][tv7za] = { 'productid': tv7za, 'productname': kl4sud, 'productdesc': cw2hg1, 'roleid': v5tnza, 'rolename': a7bx$z, 'rolelevel': $0bz7, 'price': jgw21e, 'callback': zx$n7 }, sendApi(f1T9[H[641066]], H[641205], { 'game_pkg': f1T9[H[640934]], 'server_id': f1T9[H[640935]][H[640936]], 'server_name': f1T9[H[640935]][H[641183]], 'level': $0bz7, 'uid': f1T9[H[640931]], 'role_id': v5tnza, 'role_name': a7bx$z, 'product_id': tv7za, 'product_name': kl4sud, 'product_desc': cw2hg1, 'money': jgw21e, 'partner_id': f1T9[H[641070]] }, toPayCallBack, f1B9T, f19K);
}, window[H[641206]] = function (whclgk) {
  if (whclgk) {
    if (whclgk[H[641207]] === 0xc8 || whclgk[H[641103]] == H[641168]) {
      var avn5t = f1T9[H[641058]][String(whclgk[H[641208]])];if (avn5t[H[641209]]) avn5t[H[641209]](whclgk[H[641208]], whclgk[H[641210]], -0x1);fe58vtj[H[641211]]({ 'cpbill': whclgk[H[641210]], 'productid': whclgk[H[641208]], 'productname': avn5t[H[641212]], 'productdesc': avn5t[H[641213]], 'serverid': f1T9[H[640935]][H[640936]], 'servername': f1T9[H[640935]][H[641183]], 'roleid': avn5t[H[641214]], 'rolename': avn5t[H[641215]], 'rolelevel': avn5t[H[641216]], 'price': avn5t[H[641217]], 'extension': JSON[H[640939]]({ 'cp_order_id': whclgk[H[641210]] }) }, function (xzt7, wgc1h) {
        avn5t[H[641209]] && xzt7 == 0x0 && avn5t[H[641209]](whclgk[H[641208]], whclgk[H[641210]], xzt7);console[H[640917]](JSON[H[640939]]({ 'type': H[641218], 'status': xzt7, 'data': whclgk, 'role_name': avn5t[H[641215]] }));if (xzt7 === 0x0) {} else {
          if (xzt7 === 0x1) {} else {
            if (xzt7 === 0x2) {}
          }
        }
      });
    } else alert(whclgk[H[640917]]);
  }
}, window['f1B9TK'] = function () {}, window['f1KB9'] = function (cdslk4, lu4sk, tn7axz, _su9dp, klwch) {
  fe58vtj[H[641219]](f1T9[H[640935]][H[640936]], f1T9[H[640935]][H[641183]] || f1T9[H[640935]][H[640936]], cdslk4, lu4sk, tn7axz), sendApi(f1T9[H[641062]], H[641220], { 'game_pkg': f1T9[H[640934]], 'server_id': f1T9[H[640935]][H[640936]], 'role_id': cdslk4, 'uid': f1T9[H[640931]], 'role_name': lu4sk, 'role_type': _su9dp, 'level': tn7axz });
}, window['f1K9B'] = function (x$azn7, u9s_pd, p4sd9, a58nvt, y_9sup, zantx7, usp9d, wgc12h, _yp6u9, kcwlg) {
  f1T9[H[640928]] = x$azn7, f1T9[H[640929]] = u9s_pd, f1T9[H[640930]] = p4sd9, fe58vtj[H[641221]](f1T9[H[640935]][H[640936]], f1T9[H[640935]][H[641183]] || f1T9[H[640935]][H[640936]], x$azn7, u9s_pd, p4sd9), sendApi(f1T9[H[641062]], H[641222], { 'game_pkg': f1T9[H[640934]], 'server_id': f1T9[H[640935]][H[640936]], 'role_id': x$azn7, 'uid': f1T9[H[640931]], 'role_name': u9s_pd, 'role_type': a58nvt, 'level': p4sd9, 'evolution': y_9sup });
}, window['f1BK9'] = function (v7atnz, cw1hl, m$3b, hclg4k, z7xatn, p_sy, i9_6o, jw8, dukl4s, wj218) {
  f1T9[H[640928]] = v7atnz, f1T9[H[640929]] = cw1hl, f1T9[H[640930]] = m$3b, fe58vtj[H[641223]](f1T9[H[640935]][H[640936]], f1T9[H[640935]][H[641183]] || f1T9[H[640935]][H[640936]], v7atnz, cw1hl, m$3b), sendApi(f1T9[H[641062]], H[641222], { 'game_pkg': f1T9[H[640934]], 'server_id': f1T9[H[640935]][H[640936]], 'role_id': v7atnz, 'uid': f1T9[H[640931]], 'role_name': cw1hl, 'role_type': hclg4k, 'level': m$3b, 'evolution': z7xatn });
}, window['f1B9K'] = function (sdp_) {}, window['f1KB'] = function (g1whe) {
  fe58vtj[H[641224]](H[641224], function (gh1cw2) {
    g1whe && g1whe(gh1cw2);
  });
}, window[H[641225]] = function () {
  fe58vtj[H[641225]]();
}, window[H[641226]] = function () {
  fe58vtj[H[641227]]();
}, window[H[641041]] = function (ghe1) {
  window['f19KB'] = ghe1, window['f19KB'] && window['f1BK'] && (console[H[640917]](H[641042] + window['f1BK'][H[641043]]), window['f19KB'](window['f1BK']), window['f1BK'] = null);
}, window['f19BK'] = function (v285je, gckwl, hlgwkc, q3mb0) {
  window[H[641228]](H[641229], { 'game_pkg': window['f1T9'][H[640934]], 'role_id': gckwl, 'server_id': hlgwkc }, q3mb0);
}, window['f1TKB9'] = function (zb, $0mb7) {
  function egj1(bq) {
    var vaz7 = [],
        _i6p9y = [],
        antx = window[H[640921]][H[641230]];for (var bqm03$ in antx) {
      var kdlcs = Number(bqm03$);(!zb || !zb[H[640031]] || zb[H[640146]](kdlcs) != -0x1) && (_i6p9y[H[640066]](antx[bqm03$]), vaz7[H[640066]]([kdlcs, 0x3]));
    }window['f12B9KT'](window[H[640948]], H[641231]) >= 0x0 ? (console[H[640225]](H[641232]), fe58vtj[H[641233]] && fe58vtj[H[641233]](_i6p9y, function (gh2cw) {
      console[H[640225]](H[641234]), console[H[640225]](gh2cw);if (gh2cw && gh2cw[H[640966]] == H[641235]) for (var xb7a in antx) {
        if (gh2cw[antx[xb7a]] == H[641236]) {
          var ghew21 = Number(xb7a);for (var _y9pi = 0x0; _y9pi < vaz7[H[640031]]; _y9pi++) {
            if (vaz7[_y9pi][0x0] == ghew21) {
              vaz7[_y9pi][0x1] = 0x1;break;
            }
          }
        }
      }window['f12B9KT'](window[H[640948]], H[641237]) >= 0x0 ? wx[H[641238]]({ 'withSubscriptions': !![], 'success': function (p_6u) {
          var p6_i9y = p_6u[H[641239]][H[641240]];if (p6_i9y) {
            console[H[640225]](H[641241]), console[H[640225]](p6_i9y);for (var jgw1e2 in antx) {
              if (p6_i9y[antx[jgw1e2]] == H[641236]) {
                var b0x$m3 = Number(jgw1e2);for (var xaz7nt = 0x0; xaz7nt < vaz7[H[640031]]; xaz7nt++) {
                  if (vaz7[xaz7nt][0x0] == b0x$m3) {
                    vaz7[xaz7nt][0x1] = 0x2;break;
                  }
                }
              }
            }console[H[640225]](vaz7), $0mb7 && $0mb7(vaz7);
          } else console[H[640225]](H[641242]), console[H[640225]](p_6u), console[H[640225]](vaz7), $0mb7 && $0mb7(vaz7);
        }, 'fail': function () {
          console[H[640225]](H[641243]), console[H[640225]](vaz7), $0mb7 && $0mb7(vaz7);
        } }) : (console[H[640225]](H[641244] + window[H[640948]]), console[H[640225]](vaz7), $0mb7 && $0mb7(vaz7));
    })) : (console[H[640225]](H[641245] + window[H[640948]]), console[H[640225]](vaz7), $0mb7 && $0mb7(vaz7)), wx[H[641246]](egj1);
  }wx[H[641247]](egj1);
}, window['f1TK9B'] = { 'isSuccess': ![], 'level': H[641248], 'isCharging': ![] }, window['f1TBK9'] = function (x3$0mb) {
  wx[H[641029]]({ 'success': function (p9s_) {
      var $0mxb7 = window['f1TK9B'];$0mxb7[H[641249]] = !![], $0mxb7[H[641031]] = Number(p9s_[H[641031]])[H[641250]](0x0), $0mxb7[H[641033]] = p9s_[H[641033]], x3$0mb && x3$0mb($0mxb7[H[641249]], $0mxb7[H[641031]], $0mxb7[H[641033]]);
    }, 'fail': function (l4hck) {
      console[H[640225]](H[641251], l4hck[H[640966]]);var jge2w1 = window['f1TK9B'];x3$0mb && x3$0mb(jge2w1[H[641249]], jge2w1[H[641031]], jge2w1[H[641033]]);
    } });
}, window[H[641228]] = function (upkd, tj58vn, y9p_u, lhwcg1, gwj21e, p6y, whclg1, jvn) {
  if (lhwcg1 == undefined) lhwcg1 = 0x1;wx[H[641120]]({ 'url': upkd, 'method': whclg1 || H[641252], 'responseType': H[641253], 'data': tj58vn, 'header': { 'content-type': jvn || H[641122] }, 'success': function (glkhc) {
      DEBUG && console[H[640225]](H[641254], upkd, info, glkhc);if (glkhc && glkhc[H[641255]] == 0xc8) {
        var y_69p = glkhc[H[640335]];!p6y || p6y(y_69p) ? y9p_u && y9p_u(y_69p) : window[H[641256]](upkd, tj58vn, y9p_u, lhwcg1, gwj21e, p6y, glkhc);
      } else window[H[641256]](upkd, tj58vn, y9p_u, lhwcg1, gwj21e, p6y, glkhc);
    }, 'fail': function (w2j18) {
      DEBUG && console[H[640225]](H[641257], upkd, info, w2j18), window[H[641256]](upkd, tj58vn, y9p_u, lhwcg1, gwj21e, p6y, w2j18);
    }, 'complete': function () {} });
}, window[H[641256]] = function (u9d_ps, gkw, syup, m3bx$, qb3$0m, uy9_p6, wj2) {
  m3bx$ - 0x1 > 0x0 ? setTimeout(function () {
    window[H[641228]](u9d_ps, gkw, syup, m3bx$ - 0x1, qb3$0m, uy9_p6);
  }, 0x3e8) : qb3$0m && qb3$0m(JSON[H[640939]]({ 'url': u9d_ps, 'response': wj2 }));
}, window[H[641258]] = function (naz7vt, gjew, zvant, t5j8e, gc4h, o6_9iy, k4sdup) {
  !zvant && (zvant = {});var m30rb = Math[H[640071]](Date[H[641047]]() / 0x3e8);zvant[H[641175]] = m30rb, zvant[H[641259]] = gjew;var udsl4 = Object[H[640030]](zvant)[H[640382]](),
      u4psdk = '',
      $zxna7 = '';for (var y9ps_ = 0x0; y9ps_ < udsl4[H[640031]]; y9ps_++) {
    u4psdk = u4psdk + (y9ps_ == 0x0 ? '' : '&') + udsl4[y9ps_] + zvant[udsl4[y9ps_]], $zxna7 = $zxna7 + (y9ps_ == 0x0 ? '' : '&') + udsl4[y9ps_] + '=' + encodeURIComponent(zvant[udsl4[y9ps_]]);
  }u4psdk = u4psdk + f1T9[H[641068]];var dlck = H[641260] + md5(u4psdk);send(naz7vt + '?' + $zxna7 + ($zxna7 == '' ? '' : '&') + dlck, null, t5j8e, gc4h, o6_9iy, k4sdup || function (j58v2e) {
    return j58v2e[H[641103]] == H[641168];
  }, null, H[641261]);
}, window['f1TB9K'] = function (_d9ps, txnaz7) {
  var wcg12 = 0x0;f1T9[H[640935]] && (wcg12 = f1T9[H[640935]][H[640936]]), sendApi(f1T9[H[641064]], H[641262], { 'partnerId': f1T9[H[641070]], 'gamePkg': f1T9[H[640934]], 'logTime': Math[H[640071]](Date[H[641047]]() / 0x3e8), 'platformUid': f1T9[H[641171]], 'type': _d9ps, 'serverId': wcg12 }, null, 0x2, null, function () {
    return !![];
  });
}, window['f1T9KB'] = function ($mb70) {
  sendApi(f1T9[H[641062]], H[641263], { 'partner_id': f1T9[H[641070]], 'uid': f1T9[H[640931]], 'version': f1T9[H[640987]], 'game_pkg': f1T9[H[640934]], 'device': f1T9[H[641071]] }, f1T9BK, f1B9T, f19K);
}, window['f1T9BK'] = function (jw2ge1) {
  if (jw2ge1[H[641103]] === H[641168] && jw2ge1[H[640335]]) {
    jw2ge1[H[640335]][H[640174]]({ 'id': -0x2, 'name': H[641264] }), jw2ge1[H[640335]][H[640174]]({ 'id': -0x1, 'name': H[641265] }), f1T9[H[641266]] = jw2ge1[H[640335]];if (window[H[641267]]) window[H[641267]][H[641268]]();
  } else f1T9[H[641269]] = ![], window['f1KBT9'](H[641270] + jw2ge1[H[641103]]);
}, window['f1KBT'] = function (uksp4) {
  sendApi(f1T9[H[641062]], H[641271], { 'partner_id': f1T9[H[641070]], 'uid': f1T9[H[640931]], 'version': f1T9[H[640987]], 'game_pkg': f1T9[H[640934]], 'device': f1T9[H[641071]] }, f1KTB, f1B9T, f19K);
}, window['f1KTB'] = function (klcs) {
  f1T9[H[641272]] = ![];if (klcs[H[641103]] === H[641168] && klcs[H[640335]]) {
    for (var upsd9_ = 0x0; upsd9_ < klcs[H[640335]][H[640031]]; upsd9_++) {
      klcs[H[640335]][upsd9_][H[641187]] = f1TBK(klcs[H[640335]][upsd9_]);
    }f1T9[H[641073]][-0x1] = window[H[641273]](klcs[H[640335]]), window[H[641267]][H[641274]](-0x1);
  } else window['f1KBT9'](H[641275] + klcs[H[641103]]);
}, window[H[641276]] = function (x30$b) {
  sendApi(f1T9[H[641062]], H[641271], { 'partner_id': f1T9[H[641070]], 'uid': f1T9[H[640931]], 'version': f1T9[H[640987]], 'game_pkg': f1T9[H[640934]], 'device': f1T9[H[641071]] }, x30$b, f1B9T, f19K);
}, window['f1BKT'] = function (ewg2j, l4duk) {
  sendApi(f1T9[H[641062]], H[641277], { 'partner_id': f1T9[H[641070]], 'uid': f1T9[H[640931]], 'version': f1T9[H[640987]], 'game_pkg': f1T9[H[640934]], 'device': f1T9[H[641071]], 'server_group_id': l4duk }, f1BTK, f1B9T, f19K);
}, window['f1BTK'] = function (a7vn) {
  f1T9[H[641272]] = ![];if (a7vn[H[641103]] === H[641168] && a7vn[H[640335]] && a7vn[H[640335]][H[640335]]) {
    var sd94 = a7vn[H[640335]][H[641278]],
        d4chk = [];for (var y9pi6 = 0x0; y9pi6 < a7vn[H[640335]][H[640335]][H[640031]]; y9pi6++) {
      a7vn[H[640335]][H[640335]][y9pi6][H[641187]] = f1TBK(a7vn[H[640335]][H[640335]][y9pi6]), (d4chk[H[640031]] == 0x0 || a7vn[H[640335]][H[640335]][y9pi6][H[641187]] != 0x0) && (d4chk[d4chk[H[640031]]] = a7vn[H[640335]][H[640335]][y9pi6]);
    }f1T9[H[641073]][sd94] = window[H[641273]](d4chk), window[H[641267]][H[641274]](sd94);
  } else window['f1KBT9'](H[641279] + a7vn[H[641103]]);
}, window['f12B9T'] = function (a$xz7b) {
  sendApi(f1T9[H[641062]], H[641280], { 'partner_id': f1T9[H[641070]], 'uid': f1T9[H[640931]], 'version': f1T9[H[640987]], 'game_pkg': f1T9[H[640934]], 'device': f1T9[H[641071]] }, reqServerRecommendCallBack, f1B9T, f19K);
}, window[H[641281]] = function (vjn5) {
  f1T9[H[641272]] = ![];if (vjn5[H[641103]] === H[641168] && vjn5[H[640335]]) {
    for (var d_pus9 = 0x0; d_pus9 < vjn5[H[640335]][H[640031]]; d_pus9++) {
      vjn5[H[640335]][d_pus9][H[641187]] = f1TBK(vjn5[H[640335]][d_pus9]);
    }f1T9[H[641073]][-0x2] = window[H[641273]](vjn5[H[640335]]), window[H[641267]][H[641274]](-0x2);
  } else alert(H[641282] + vjn5[H[641103]]);
}, window[H[641273]] = function (evj8) {
  if (!evj8 && evj8[H[640031]] <= 0x0) return evj8;for (let p_9sd = 0x0; p_9sd < evj8[H[640031]]; p_9sd++) {
    evj8[p_9sd][H[641283]] && evj8[p_9sd][H[641283]] == 0x1 && (evj8[p_9sd][H[641183]] += H[641284]);
  }return evj8;
}, window['f1TKB'] = function ($m0, kpu4s) {
  $m0 = $m0 || f1T9[H[640935]][H[640936]], sendApi(f1T9[H[641062]], H[641285], { 'type': '4', 'game_pkg': f1T9[H[640934]], 'server_id': $m0 }, kpu4s);
}, window[H[641286]] = function (clh1gw, m3b$x0, mb$x, j281we) {
  mb$x = mb$x || f1T9[H[640935]][H[640936]], sendApi(f1T9[H[641062]], H[641287], { 'type': clh1gw, 'game_pkg': m3b$x0, 'server_id': mb$x }, j281we);
}, window['f1TBK'] = function (hkgclw) {
  if (hkgclw) {
    if (hkgclw[H[641187]] == 0x1) {
      if (hkgclw[H[641288]] == 0x1) return 0x2;else return 0x1;
    } else return hkgclw[H[641187]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['f19KBT'] = function (vtjn, nxa7$) {
  f1T9[H[641289]] = { 'step': vtjn, 'server_id': nxa7$ };var z5vt = this;f1KTB9({ 'title': H[641290] }), sendApi(f1T9[H[641062]], H[641291], { 'partner_id': f1T9[H[641070]], 'uid': f1T9[H[640931]], 'game_pkg': f1T9[H[640934]], 'server_id': nxa7$, 'platform': f1T9[H[640991]], 'platform_uid': f1T9[H[641171]], 'check_login_time': f1T9[H[641174]], 'check_login_sign': f1T9[H[641172]], 'version_name': f1T9[H[641145]] }, f19KTB, f1B9T, f19K, function (v8jtn5) {
    return v8jtn5[H[641103]] == H[641168] || v8jtn5[H[640917]] == H[641292] || v8jtn5[H[640917]] == H[641293];
  });
}, window['f19KTB'] = function ($xm03) {
  var jwg1e2 = this;if ($xm03[H[641103]] === H[641168] && $xm03[H[640335]]) {
    var tzv7a = f1T9[H[640935]];tzv7a[H[641294]] = f1T9[H[641074]], tzv7a[H[641173]] = String($xm03[H[640335]][H[641295]]), tzv7a[H[641080]] = parseInt($xm03[H[640335]][H[641175]]);if ($xm03[H[640335]][H[641296]]) tzv7a[H[641296]] = parseInt($xm03[H[640335]][H[641296]]);else tzv7a[H[641296]] = parseInt($xm03[H[640335]][H[640936]]);tzv7a[H[641297]] = 0x0, tzv7a[H[640933]] = f1T9[H[641198]], tzv7a[H[641298]] = $xm03[H[640335]][H[641299]], tzv7a[H[641300]] = $xm03[H[640335]][H[641300]], console[H[640225]](H[641301] + JSON[H[640939]](tzv7a[H[641300]])), f1T9[H[641181]] == 0x1 && tzv7a[H[641300]] && tzv7a[H[641300]][H[641302]] == 0x1 && (f1T9[H[641303]] = 0x1, window[H[640946]][H[640947]]['f129T']()), f19BKT();
  } else f1T9[H[641289]][H[641304]] >= 0x3 ? (f19K(JSON[H[640939]]($xm03)), window['f1KBT9'](H[641305] + $xm03[H[641103]])) : sendApi(f1T9[H[641062]], H[641155], { 'platform': f1T9[H[641060]], 'partner_id': f1T9[H[641070]], 'token': f1T9[H[641153]], 'game_pkg': f1T9[H[640934]], 'deviceId': f1T9[H[641071]], 'scene': H[641156] + f1T9[H[641072]] }, function ($xan) {
    if (!$xan || $xan[H[641103]] != H[641168]) {
      window['f1KBT9'](H[641169] + $xan && $xan[H[641103]]);return;
    }f1T9[H[641172]] = String($xan[H[641173]]), f1T9[H[641174]] = String($xan[H[641175]]), setTimeout(function () {
      f19KBT(f1T9[H[641289]][H[641304]] + 0x1, f1T9[H[641289]][H[640936]]);
    }, 0x5dc);
  }, f1B9T, f19K, function (ghe21w) {
    return ghe21w[H[641103]] == H[641168] || ghe21w[H[641103]] == H[641306];
  });
}, window['f19BKT'] = function () {
  ServerLoading[H[640947]][H[641190]](f1T9[H[641181]]), window['f1B9'] = !![], window['f19TKB']();
}, window['f19BTK'] = function () {
  if (window['f19B'] && window['f1TB9'] && window[H[641086]] && window[H[641087]] && window['f1T9B'] && window['f1TB']) {
    if (!window[H[641307]][H[640947]]) {
      console[H[640225]](H[641308] + window[H[641307]][H[640947]]);var h21e = wx[H[641309]](),
          cdl4k = h21e[H[641043]] ? h21e[H[641043]] : 0x0,
          $x7n = { 'cdn': window['f1T9'][H[640933]], 'spareCdn': window['f1T9'][H[641143]], 'newRegister': window['f1T9'][H[641181]], 'wxPC': window['f1T9'][H[641018]], 'wxIOS': window['f1T9'][H[641013]], 'wxAndroid': window['f1T9'][H[641015]], 'wxParam': { 'limitLoad': window['f1T9']['f12KB9T'], 'benchmarkLevel': window['f1T9']['f12KTB9'], 'wxFrom': window[H[640921]][H[640051]] == H[641310] ? 0x1 : 0x0, 'wxSDKVersion': window[H[640948]] }, 'configType': window['f1T9'][H[641081]], 'exposeType': window['f1T9'][H[641083]], 'scene': cdl4k };new window[H[641307]]($x7n, window['f1T9'][H[640932]], window['f12KBT9']);
    }
  }
}, window['f19TKB'] = function () {
  if (window['f19B'] && window['f1TB9'] && window[H[641086]] && window[H[641087]] && window['f1T9B'] && window['f1TB'] && window['f1B9'] && window['f1BT']) {
    f1KT9B();if (!f19BT) {
      f19BT = !![];if (!window[H[641307]][H[640947]]) window['f19BTK']();var x0b$7m = 0x0,
          py9_6 = wx[H[641311]]();py9_6 && (window['f1T9'][H[641017]] && (x0b$7m = py9_6[H[641009]]), console[H[640917]](H[641312] + py9_6[H[641009]] + H[641313] + py9_6[H[641010]] + H[641314] + py9_6[H[641011]] + H[641315] + py9_6[H[641012]] + H[641316] + py9_6[H[641317]] + H[641318] + py9_6[H[641319]]));var w21jge = {};for (const lhwck in f1T9[H[640935]]) {
        w21jge[lhwck] = f1T9[H[640935]][lhwck];
      }var kusdp = { 'channel': window['f1T9'][H[641075]], 'account': window['f1T9'][H[640931]], 'userId': window['f1T9'][H[641170]], 'cdn': window['f1T9'][H[640933]], 'data': window['f1T9'][H[640335]], 'package': window['f1T9'][H[640304]], 'newRegister': window['f1T9'][H[641181]], 'pkgName': window['f1T9'][H[640934]], 'partnerId': window['f1T9'][H[641070]], 'platform_uid': window['f1T9'][H[641171]], 'deviceId': window['f1T9'][H[641071]], 'selectedServer': w21jge, 'configType': window['f1T9'][H[641081]], 'exposeType': window['f1T9'][H[641083]], 'debugUsers': window['f1T9'][H[641078]], 'wxMenuTop': x0b$7m, 'wxShield': window['f1T9'][H[641085]] };if (window[H[641201]]) for (var vnat in window[H[641201]]) {
        kusdp[vnat] = window[H[641201]][vnat];
      }window[H[641307]][H[640947]]['f19T2'](kusdp), setTimeout(() => {
        new MxFc();
      }, 0x2710);
    }
  } else console[H[640917]](H[641320] + window['f19B'] + H[641321] + window['f1TB9'] + H[641322] + window[H[641086]] + H[641323] + window[H[641087]] + H[641324] + window['f1T9B'] + H[641325] + window['f1TB'] + H[641326] + window['f1B9'] + H[641327] + window['f1BT']);
};