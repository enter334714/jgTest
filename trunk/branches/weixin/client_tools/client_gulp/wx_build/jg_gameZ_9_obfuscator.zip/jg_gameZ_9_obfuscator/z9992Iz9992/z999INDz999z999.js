var H = wx.$F;
import ftpur64 from '../z999z999basdz999/z9995sdkz999.js';window[H[640149]] = { 'wxVersion': window[H[640006]][H[640007]] }, window[H[640150]] = ![], window['f12$'] = 0x1, window[H[640151]] = 0x1, window['f1I$2'] = !![], window[H[640152]] = !![], window['f1KAI$2'] = '', window['f1$2'] = { 'base_cdn': H[640153], 'cdn': H[640153] }, f1$2[H[640154]] = {}, f1$2[H[640155]] = '0', f1$2[H[640080]] = window[H[640149]][H[640156]], f1$2[H[640115]] = '', f1$2['os'] = '1', f1$2[H[640157]] = H[640158], f1$2[H[640159]] = H[640160], f1$2[H[640161]] = H[640162], f1$2[H[640163]] = H[640164], f1$2[H[640165]] = H[640166], f1$2[H[640167]] = '1', f1$2[H[640022]] = '', f1$2[H[640168]] = '', f1$2[H[640169]] = 0x0, f1$2[H[640170]] = {}, f1$2[H[640171]] = parseInt(f1$2[H[640167]]), f1$2[H[640172]] = f1$2[H[640167]], f1$2[H[640023]] = {}, f1$2['f1A$'] = H[640173], f1$2[H[640174]] = ![], f1$2[H[640175]] = H[640176], f1$2[H[640177]] = Date[H[640142]](), f1$2[H[640178]] = H[640179], f1$2[H[640180]] = '_a', f1$2[H[640181]] = 0x2, f1$2[H[640020]] = 0x7c1, f1$2[H[640156]] = window[H[640149]][H[640156]], f1$2[H[640182]] = ![], f1$2[H[640107]] = ![], f1$2[H[640110]] = ![], f1$2[H[640113]] = ![], window['f1I2$'] = 0x5, window['f1I2'] = ![], window['f12I'] = ![], window['f1$I2'] = ![], window[H[640183]] = ![], window[H[640184]] = ![], window['f1$2I'] = ![], window['f1I$'] = ![], window['f1$I'] = ![], window['f12I$'] = ![], window[H[640185]] = function (ineb) {
  console[H[640042]](H[640185], ineb), wx[H[640186]]({}), wx[H[640049]]({ 'title': H[640072], 'content': ineb, 'success'(t64u) {
      if (t64u[H[640187]]) console[H[640042]](H[640188]);else t64u[H[640189]] && console[H[640042]](H[640190]);
    } });
}, window['f1AI$2'] = function (bv_5ak) {
  console[H[640042]](H[640191], bv_5ak), f1A$2I(), wx[H[640049]]({ 'title': H[640072], 'content': bv_5ak, 'confirmText': H[640192], 'cancelText': H[640193], 'success'(jsdv$) {
      if (jsdv$[H[640187]]) window['f1$A']();else jsdv$[H[640189]] && (console[H[640042]](H[640194]), wx[H[640195]]({}));
    } });
}, window[H[640196]] = function (r6198z) {
  console[H[640042]](H[640196], r6198z), wx[H[640049]]({ 'title': H[640072], 'content': r6198z, 'confirmText': H[640197], 'showCancel': ![], 'complete'(or819) {
      console[H[640042]](H[640194]), wx[H[640195]]({});
    } });
}, window['f1AI2$'] = ![], window['f1A$I2'] = function (t1698r) {
  window['f1AI2$'] = !![], wx[H[640198]](t1698r);
}, window['f1A$2I'] = function () {
  window['f1AI2$'] && (window['f1AI2$'] = ![], wx[H[640186]]({}));
}, window['f1A2I$'] = function (qmj$sd) {
  window[H[640035]][H[640036]]['f1A2I$'](qmj$sd);
}, window[H[640199]] = function (cz91o8, w0enxl) {
  ftpur64[H[640199]](cz91o8, function (qy$sm) {
    qy$sm && qy$sm[H[640200]] ? qy$sm[H[640200]][H[640201]] == 0x1 ? w0enxl(!![]) : (w0enxl(![]), console[H[640001]](H[640202] + qy$sm[H[640200]][H[640203]])) : console[H[640042]](H[640199], qy$sm);
  });
}, window['f1A2$I'] = function (sk5v_) {
  console[H[640042]](H[640204], sk5v_);
}, window['f1A$2'] = function (z189c) {}, window['f1A2$'] = function (nwl3xe, qmd$sj, _viak) {}, window['f1A2'] = function (t6p04u) {
  console[H[640042]](H[640205], t6p04u), window[H[640035]][H[640036]][H[640206]](), window[H[640035]][H[640036]][H[640207]](), window[H[640035]][H[640036]][H[640208]]();
}, window['f12A'] = function (zor89) {
  window['f1AI$2'](H[640209]);var t46u0p = { 'id': window['f1$2'][H[640016]], 'role': window['f1$2'][H[640017]], 'level': window['f1$2'][H[640018]], 'account': window['f1$2'][H[640019]], 'version': window['f1$2'][H[640020]], 'cdn': window['f1$2'][H[640021]], 'pkgName': window['f1$2'][H[640022]], 'gamever': window[H[640006]][H[640007]], 'serverid': window['f1$2'][H[640023]] ? window['f1$2'][H[640023]][H[640024]] : 0x0, 'systemInfo': window[H[640025]], 'error': H[640210], 'stack': zor89 ? zor89 : H[640209] },
      a3b_ki = JSON[H[640027]](t46u0p);console[H[640028]](H[640211] + a3b_ki), window['f1A$'](a3b_ki);
}, window['f1$A2'] = function (oh2cz) {
  var l0nwex = JSON[H[640212]](oh2cz);l0nwex[H[640213]] = window[H[640006]][H[640007]], l0nwex[H[640214]] = window['f1$2'][H[640023]] ? window['f1$2'][H[640023]][H[640024]] : 0x0, l0nwex[H[640025]] = window[H[640025]];var z21ho = JSON[H[640027]](l0nwex);console[H[640028]](H[640215] + z21ho), window['f1A$'](z21ho);
}, window['f1$2A'] = function (sk5, a_v5kj) {
  var zoh8c1 = { 'id': window['f1$2'][H[640016]], 'role': window['f1$2'][H[640017]], 'level': window['f1$2'][H[640018]], 'account': window['f1$2'][H[640019]], 'version': window['f1$2'][H[640020]], 'cdn': window['f1$2'][H[640021]], 'pkgName': window['f1$2'][H[640022]], 'gamever': window[H[640006]][H[640007]], 'serverid': window['f1$2'][H[640023]] ? window['f1$2'][H[640023]][H[640024]] : 0x0, 'systemInfo': window[H[640025]], 'error': sk5, 'stack': a_v5kj },
      kbiav_ = JSON[H[640027]](zoh8c1);console[H[640143]](H[640216] + kbiav_), window['f1A$'](kbiav_);
}, window['f1A$'] = function (z189o) {
  if (window['f1$2'][H[640116]] == H[640217]) return;var t98r1 = f1$2['f1A$'] + H[640218] + f1$2[H[640019]];wx[H[640219]]({ 'url': t98r1, 'method': H[640220], 'data': z189o, 'header': { 'content-type': H[640221], 'cache-control': H[640222] }, 'success': function (sdmjq) {
      DEBUG && console[H[640042]](H[640223], t98r1, z189o, sdmjq);
    }, 'fail': function (bk_i3a) {
      DEBUG && console[H[640042]](H[640223], t98r1, z189o, bk_i3a);
    }, 'complete': function () {} });
}, window[H[640224]] = function () {
  function inxew3() {
    return ((0x1 + Math[H[640225]]()) * 0x10000 | 0x0)[H[640226]](0x10)[H[640227]](0x1);
  }return inxew3() + inxew3() + '-' + inxew3() + '-' + inxew3() + '-' + inxew3() + '+' + inxew3() + inxew3() + inxew3();
}, window['f1$A'] = function () {
  console[H[640042]](H[640228]);var t9rp = ftpur64[H[640229]]();f1$2[H[640172]] = t9rp[H[640230]], f1$2[H[640171]] = t9rp[H[640230]], f1$2[H[640167]] = t9rp[H[640230]], f1$2[H[640022]] = t9rp[H[640231]];var mdjs = { 'game_ver': f1$2[H[640080]] };f1$2[H[640168]] = this[H[640224]](), f1A$I2({ 'title': H[640232] }), ftpur64[H[640233]](mdjs, this['f12A$'][H[640234]](this));
}, window['f12A$'] = function (v$s) {
  var akbin = v$s[H[640235]];console[H[640042]](H[640236] + akbin + H[640237] + (akbin == 0x1) + H[640238] + v$s[H[640007]] + H[640239] + window[H[640149]][H[640156]]);if (!v$s[H[640007]] || window['f1KI2A$'](window[H[640149]][H[640156]], v$s[H[640007]]) < 0x0) console[H[640042]](H[640240]), f1$2[H[640159]] = H[640241], f1$2[H[640161]] = H[640242], f1$2[H[640163]] = H[640243], f1$2[H[640021]] = H[640244], f1$2[H[640245]] = H[640246], f1$2[H[640247]] = 'cg', f1$2[H[640182]] = ![];else window['f1KI2A$'](window[H[640149]][H[640156]], v$s[H[640007]]) == 0x0 ? (console[H[640042]](H[640248]), f1$2[H[640159]] = H[640160], f1$2[H[640161]] = H[640162], f1$2[H[640163]] = H[640164], f1$2[H[640021]] = H[640249], f1$2[H[640245]] = H[640246], f1$2[H[640247]] = H[640250], f1$2[H[640182]] = !![]) : (console[H[640042]](H[640251]), f1$2[H[640159]] = H[640160], f1$2[H[640161]] = H[640162], f1$2[H[640163]] = H[640164], f1$2[H[640021]] = H[640249], f1$2[H[640245]] = H[640246], f1$2[H[640247]] = H[640250], f1$2[H[640182]] = ![]);f1$2[H[640169]] = config[H[640252]] ? config[H[640252]] : 0x0, this['f1I$A2'](), this['f1I$2A'](), window[H[640253]] = 0x5, f1A$I2({ 'title': H[640254] }), ftpur64[H[640255]](this['f12$A'][H[640234]](this));
}, window[H[640253]] = 0x5, window['f12$A'] = function (b3nak, l4wu0x) {
  if (b3nak == 0x0 && l4wu0x && l4wu0x[H[640256]]) {
    f1$2[H[640257]] = l4wu0x[H[640256]];var z1o2ch = this;f1A$I2({ 'title': H[640258] }), sendApi(f1$2[H[640159]], H[640259], { 'platform': f1$2[H[640157]], 'partner_id': f1$2[H[640167]], 'token': l4wu0x[H[640256]], 'game_pkg': f1$2[H[640022]], 'deviceId': f1$2[H[640168]], 'scene': H[640260] + f1$2[H[640169]] }, this['f1IA$2'][H[640234]](this), f1I2$, f12A);
  } else l4wu0x && l4wu0x[H[640059]] && window[H[640253]] > 0x0 && (l4wu0x[H[640059]][H[640108]](H[640261]) != -0x1 || l4wu0x[H[640059]][H[640108]](H[640262]) != -0x1 || l4wu0x[H[640059]][H[640108]](H[640263]) != -0x1 || l4wu0x[H[640059]][H[640108]](H[640264]) != -0x1 || l4wu0x[H[640059]][H[640108]](H[640265]) != -0x1 || l4wu0x[H[640059]][H[640108]](H[640266]) != -0x1) ? (window[H[640253]]--, ftpur64[H[640255]](this['f12$A'][H[640234]](this))) : (window['f1$2A'](H[640267], JSON[H[640027]]({ 'status': b3nak, 'data': l4wu0x })), window['f1AI$2'](H[640268] + (l4wu0x && l4wu0x[H[640059]] ? '，' + l4wu0x[H[640059]] : '')));
}, window['f1IA$2'] = function (dy$mg) {
  if (!dy$mg) {
    window['f1$2A'](H[640269], H[640270]), window['f1AI$2'](H[640271]);return;
  }if (dy$mg[H[640201]] != H[640272]) {
    window['f1$2A'](H[640269], JSON[H[640027]](dy$mg)), window['f1AI$2'](H[640273] + dy$mg[H[640201]]);return;
  }f1$2[H[640274]] = String(dy$mg[H[640019]]), f1$2[H[640019]] = String(dy$mg[H[640019]]), f1$2[H[640084]] = String(dy$mg[H[640084]]), f1$2[H[640172]] = String(dy$mg[H[640084]]), f1$2[H[640275]] = String(dy$mg[H[640275]]), f1$2[H[640276]] = String(dy$mg[H[640277]]), f1$2[H[640278]] = String(dy$mg[H[640279]]), f1$2[H[640277]] = '';var kbn = this;f1A$I2({ 'title': H[640280] }), sendApi(f1$2[H[640159]], H[640281], { 'partner_id': f1$2[H[640167]], 'uid': f1$2[H[640019]], 'version': f1$2[H[640080]], 'game_pkg': f1$2[H[640022]], 'device': f1$2[H[640168]] }, kbn['f1IA2$'][H[640234]](kbn), f1I2$, f12A);
}, window['f1IA2$'] = function (aik_vb) {
  if (!aik_vb) {
    window['f1AI$2'](H[640282]);return;
  }if (aik_vb[H[640201]] != H[640272]) {
    window['f1AI$2'](H[640283] + aik_vb[H[640201]]);return;
  }if (!aik_vb[H[640200]] || aik_vb[H[640200]][H[640010]] == 0x0) {
    window['f1AI$2'](H[640284]);return;
  }f1$2[H[640285]] = aik_vb[H[640286]], f1$2[H[640023]] = { 'server_id': String(aik_vb[H[640200]][0x0][H[640024]]), 'server_name': String(aik_vb[H[640200]][0x0][H[640287]]), 'entry_ip': aik_vb[H[640200]][0x0][H[640288]], 'entry_port': parseInt(aik_vb[H[640200]][0x0][H[640289]]), 'status': f1$IA(aik_vb[H[640200]][0x0]), 'start_time': aik_vb[H[640200]][0x0][H[640290]], 'cdn': f1$2[H[640021]] }, this['f12$IA']();
}, window['f12$IA'] = function () {
  if (f1$2[H[640285]] == 0x1) {
    var mqjs$d = f1$2[H[640023]][H[640291]];if (mqjs$d === -0x1 || mqjs$d === 0x0) {
      window['f1AI$2'](mqjs$d === -0x1 ? H[640292] : H[640293]);return;
    }f12AI$(0x0, f1$2[H[640023]][H[640024]]), window[H[640035]][H[640036]][H[640294]](f1$2[H[640285]]);
  } else window[H[640035]][H[640036]][H[640295]](), f1A$2I();window['f1$I'] = !![], window['f12I$A'](), window['f12$AI']();
}, window['f1I$A2'] = function () {
  sendApi(f1$2[H[640159]], H[640296], { 'game_pkg': f1$2[H[640022]], 'version_name': f1$2[H[640247]] }, this[H[640297]][H[640234]](this), f1I2$, f12A);
}, window[H[640297]] = function (ymqd$) {
  if (!ymqd$) {
    window['f1AI$2'](H[640298]);return;
  }if (ymqd$[H[640201]] != H[640272]) {
    window['f1AI$2'](H[640299] + ymqd$[H[640201]]);return;
  }if (!ymqd$[H[640200]] || !ymqd$[H[640200]][H[640080]]) {
    window['f1AI$2'](H[640300] + (ymqd$[H[640200]] && ymqd$[H[640200]][H[640080]]));return;
  }ymqd$[H[640200]][H[640301]] && ymqd$[H[640200]][H[640301]][H[640010]] > 0xa && (f1$2[H[640302]] = ymqd$[H[640200]][H[640301]], f1$2[H[640021]] = ymqd$[H[640200]][H[640301]]), ymqd$[H[640200]][H[640080]] && (f1$2[H[640020]] = ymqd$[H[640200]][H[640080]]), console[H[640001]](H[640303] + f1$2[H[640020]] + H[640304] + f1$2[H[640247]]), window['f1$2I'] = !![], window['f12I$A'](), window['f12$AI']();
}, window[H[640305]], window['f1I$2A'] = function () {
  sendApi(f1$2[H[640159]], H[640306], { 'game_pkg': f1$2[H[640022]] }, this['f1I2A$'][H[640234]](this), f1I2$, f12A);
}, window['f1I2A$'] = function ($dqj) {
  if ($dqj[H[640201]] === H[640272] && $dqj[H[640200]]) {
    window[H[640305]] = $dqj[H[640200]];for (var ewnl in $dqj[H[640200]]) {
      f1$2[ewnl] = $dqj[H[640200]][ewnl];
    }
  } else console[H[640001]](H[640307] + $dqj[H[640201]]);window['f1I$'] = !![], window['f12$AI']();
}, window[H[640308]] = function (_a5kvb, n3bae, a5vj, eabn, i_kb3, _sjd5, sdyq$m, e0lnx, $smjdq) {
  i_kb3 = String(i_kb3);var ie3bw = sdyq$m,
      up4tr = e0lnx;f1$2[H[640154]][i_kb3] = { 'productid': i_kb3, 'productname': ie3bw, 'productdesc': up4tr, 'roleid': _a5kvb, 'rolename': n3bae, 'rolelevel': a5vj, 'price': _sjd5, 'callback': $smjdq }, sendApi(f1$2[H[640163]], H[640309], { 'game_pkg': f1$2[H[640022]], 'server_id': f1$2[H[640023]][H[640024]], 'server_name': f1$2[H[640023]][H[640287]], 'level': a5vj, 'uid': f1$2[H[640019]], 'role_id': _a5kvb, 'role_name': n3bae, 'product_id': i_kb3, 'product_name': ie3bw, 'product_desc': up4tr, 'money': _sjd5, 'partner_id': f1$2[H[640167]] }, toPayCallBack, f1I2$, f12A);
}, window[H[640310]] = function (tu40pl) {
  if (tu40pl) {
    if (tu40pl[H[640311]] === 0xc8 || tu40pl[H[640201]] == H[640272]) {
      var avb5_k = f1$2[H[640154]][String(tu40pl[H[640312]])];if (avb5_k[H[640313]]) avb5_k[H[640313]](tu40pl[H[640312]], tu40pl[H[640314]], -0x1);ftpur64[H[640315]]({ 'cpbill': tu40pl[H[640314]], 'productid': tu40pl[H[640312]], 'productname': avb5_k[H[640316]], 'productdesc': avb5_k[H[640317]], 'serverid': f1$2[H[640023]][H[640024]], 'servername': f1$2[H[640023]][H[640287]], 'roleid': avb5_k[H[640318]], 'rolename': avb5_k[H[640319]], 'rolelevel': avb5_k[H[640320]], 'price': avb5_k[H[640321]], 'extension': JSON[H[640027]]({ 'cp_order_id': tu40pl[H[640314]] }) }, function (x0elwu, ymdqs) {
        avb5_k[H[640313]] && x0elwu == 0x0 && avb5_k[H[640313]](tu40pl[H[640312]], tu40pl[H[640314]], x0elwu);console[H[640001]](JSON[H[640027]]({ 'type': H[640322], 'status': x0elwu, 'data': tu40pl, 'role_name': avb5_k[H[640319]] }));if (x0elwu === 0x0) {} else {
          if (x0elwu === 0x1) {} else {
            if (x0elwu === 0x2) {}
          }
        }
      });
    } else alert(tu40pl[H[640001]]);
  }
}, window['f1I2$A'] = function () {}, window['f1AI2'] = function (mjs5, l04xup, trp968, anki3b, u40xl) {
  ftpur64[H[640323]](f1$2[H[640023]][H[640024]], f1$2[H[640023]][H[640287]] || f1$2[H[640023]][H[640024]], mjs5, l04xup, trp968), sendApi(f1$2[H[640159]], H[640324], { 'game_pkg': f1$2[H[640022]], 'server_id': f1$2[H[640023]][H[640024]], 'role_id': mjs5, 'uid': f1$2[H[640019]], 'role_name': l04xup, 'role_type': anki3b, 'level': trp968 });
}, window['f1A2I'] = function (r89t6p, ew0n, _vka5b, p0u4x, ln0, gd$mq, xni3e, z8oc9, k3i_ba, vkai) {
  f1$2[H[640016]] = r89t6p, f1$2[H[640017]] = ew0n, f1$2[H[640018]] = _vka5b, ftpur64[H[640325]](f1$2[H[640023]][H[640024]], f1$2[H[640023]][H[640287]] || f1$2[H[640023]][H[640024]], r89t6p, ew0n, _vka5b), sendApi(f1$2[H[640159]], H[640326], { 'game_pkg': f1$2[H[640022]], 'server_id': f1$2[H[640023]][H[640024]], 'role_id': r89t6p, 'uid': f1$2[H[640019]], 'role_name': ew0n, 'role_type': p0u4x, 'level': _vka5b, 'evolution': ln0 });
}, window['f1IA2'] = function (eib, exl0, gymq$, h1z2oc, uwlxe0, kb5_v, vk5b, prt6, kb_5va, jv$5sd) {
  f1$2[H[640016]] = eib, f1$2[H[640017]] = exl0, f1$2[H[640018]] = gymq$, ftpur64[H[640327]](f1$2[H[640023]][H[640024]], f1$2[H[640023]][H[640287]] || f1$2[H[640023]][H[640024]], eib, exl0, gymq$), sendApi(f1$2[H[640159]], H[640326], { 'game_pkg': f1$2[H[640022]], 'server_id': f1$2[H[640023]][H[640024]], 'role_id': eib, 'uid': f1$2[H[640019]], 'role_name': exl0, 'role_type': h1z2oc, 'level': gymq$, 'evolution': uwlxe0 });
}, window['f1I2A'] = function (z18oh) {}, window['f1AI'] = function (jmdqs$) {
  ftpur64[H[640328]](H[640328], function (ka_j5) {
    jmdqs$ && jmdqs$(ka_j5);
  });
}, window[H[640329]] = function () {
  ftpur64[H[640329]]();
}, window[H[640330]] = function () {
  ftpur64[H[640331]]();
}, window[H[640136]] = function (zco2h1) {
  window['f12AI'] = zco2h1, window['f12AI'] && window['f1IA'] && (console[H[640001]](H[640137] + window['f1IA'][H[640138]]), window['f12AI'](window['f1IA']), window['f1IA'] = null);
}, window['f12IA'] = function (bk3_ia, $qdmg, ib_a3k, oz1ch8) {
  window[H[640332]](H[640333], { 'game_pkg': window['f1$2'][H[640022]], 'role_id': $qdmg, 'server_id': ib_a3k }, oz1ch8);
}, window['f1$AI2'] = function (p460u, z18oc) {
  function v5ab_(ixe3w) {
    var _vsjd5 = [],
        ka_vj5 = [],
        j5_avk = window[H[640006]][H[640334]];for (var v$sdj in j5_avk) {
      var ivkab_ = Number(v$sdj);(!p460u || !p460u[H[640010]] || p460u[H[640108]](ivkab_) != -0x1) && (ka_vj5[H[640039]](j5_avk[v$sdj]), _vsjd5[H[640039]]([ivkab_, 0x3]));
    }window['f1KI2A$'](window[H[640040]], H[640335]) >= 0x0 ? (console[H[640042]](H[640336]), ftpur64[H[640337]] && ftpur64[H[640337]](ka_vj5, function (elxwn) {
      console[H[640042]](H[640338]), console[H[640042]](elxwn);if (elxwn && elxwn[H[640059]] == H[640339]) for (var tu6r4 in j5_avk) {
        if (elxwn[j5_avk[tu6r4]] == H[640340]) {
          var lew0nx = Number(tu6r4);for (var jqsm$ = 0x0; jqsm$ < _vsjd5[H[640010]]; jqsm$++) {
            if (_vsjd5[jqsm$][0x0] == lew0nx) {
              _vsjd5[jqsm$][0x1] = 0x1;break;
            }
          }
        }
      }window['f1KI2A$'](window[H[640040]], H[640341]) >= 0x0 ? wx[H[640342]]({ 'withSubscriptions': !![], 'success': function (vaj5_) {
          var co12hz = vaj5_[H[640343]][H[640344]];if (co12hz) {
            console[H[640042]](H[640345]), console[H[640042]](co12hz);for (var tpu406 in j5_avk) {
              if (co12hz[j5_avk[tpu406]] == H[640340]) {
                var md5js = Number(tpu406);for (var w4l0 = 0x0; w4l0 < _vsjd5[H[640010]]; w4l0++) {
                  if (_vsjd5[w4l0][0x0] == md5js) {
                    _vsjd5[w4l0][0x1] = 0x2;break;
                  }
                }
              }
            }console[H[640042]](_vsjd5), z18oc && z18oc(_vsjd5);
          } else console[H[640042]](H[640346]), console[H[640042]](vaj5_), console[H[640042]](_vsjd5), z18oc && z18oc(_vsjd5);
        }, 'fail': function () {
          console[H[640042]](H[640347]), console[H[640042]](_vsjd5), z18oc && z18oc(_vsjd5);
        } }) : (console[H[640042]](H[640348] + window[H[640040]]), console[H[640042]](_vsjd5), z18oc && z18oc(_vsjd5));
    })) : (console[H[640042]](H[640349] + window[H[640040]]), console[H[640042]](_vsjd5), z18oc && z18oc(_vsjd5)), wx[H[640350]](v5ab_);
  }wx[H[640351]](v5ab_);
}, window['f1$A2I'] = { 'isSuccess': ![], 'level': H[640352], 'isCharging': ![] }, window['f1$IA2'] = function ($mdy) {
  wx[H[640124]]({ 'success': function (ikb_v) {
      var nlwe0x = window['f1$A2I'];nlwe0x[H[640353]] = !![], nlwe0x[H[640126]] = Number(ikb_v[H[640126]])[H[640354]](0x0), nlwe0x[H[640128]] = ikb_v[H[640128]], $mdy && $mdy(nlwe0x[H[640353]], nlwe0x[H[640126]], nlwe0x[H[640128]]);
    }, 'fail': function (kvab5) {
      console[H[640042]](H[640355], kvab5[H[640059]]);var uxwe = window['f1$A2I'];$mdy && $mdy(uxwe[H[640353]], uxwe[H[640126]], uxwe[H[640128]]);
    } });
}, window[H[640332]] = function (nbk3ai, w3bi, exi3, l4upx0, o8r9z1, tplu40, $ds5mj, $g7my) {
  if (l4upx0 == undefined) l4upx0 = 0x1;wx[H[640219]]({ 'url': nbk3ai, 'method': $ds5mj || H[640356], 'responseType': H[640357], 'data': w3bi, 'header': { 'content-type': $g7my || H[640221] }, 'success': function (_sv5kj) {
      DEBUG && console[H[640042]](H[640358], nbk3ai, info, _sv5kj);if (_sv5kj && _sv5kj[H[640359]] == 0xc8) {
        var h21c = _sv5kj[H[640200]];!tplu40 || tplu40(h21c) ? exi3 && exi3(h21c) : window[H[640360]](nbk3ai, w3bi, exi3, l4upx0, o8r9z1, tplu40, _sv5kj);
      } else window[H[640360]](nbk3ai, w3bi, exi3, l4upx0, o8r9z1, tplu40, _sv5kj);
    }, 'fail': function (a3ei) {
      DEBUG && console[H[640042]](H[640361], nbk3ai, info, a3ei), window[H[640360]](nbk3ai, w3bi, exi3, l4upx0, o8r9z1, tplu40, a3ei);
    }, 'complete': function () {} });
}, window[H[640360]] = function (p6rt49, p98t, ni3web, ani3k, ibna3, ewn3xi, jsdv) {
  ani3k - 0x1 > 0x0 ? setTimeout(function () {
    window[H[640332]](p6rt49, p98t, ni3web, ani3k - 0x1, ibna3, ewn3xi);
  }, 0x3e8) : ibna3 && ibna3(JSON[H[640027]]({ 'url': p6rt49, 'response': jsdv }));
}, window[H[640362]] = function (s$mdq, w3ieb, qm7g$y, nxl3e, xwen3l, t4pur6, vsj5d) {
  !qm7g$y && (qm7g$y = {});var vk_ia = Math[H[640363]](Date[H[640142]]() / 0x3e8);qm7g$y[H[640279]] = vk_ia, qm7g$y[H[640364]] = w3ieb;var r8z96 = Object[H[640365]](qm7g$y)[H[640366]](),
      r81zo = '',
      neb3 = '';for (var x0lp = 0x0; x0lp < r8z96[H[640010]]; x0lp++) {
    r81zo = r81zo + (x0lp == 0x0 ? '' : '&') + r8z96[x0lp] + qm7g$y[r8z96[x0lp]], neb3 = neb3 + (x0lp == 0x0 ? '' : '&') + r8z96[x0lp] + '=' + encodeURIComponent(qm7g$y[r8z96[x0lp]]);
  }r81zo = r81zo + f1$2[H[640165]];var xwnel = H[640367] + md5(r81zo);send(s$mdq + '?' + neb3 + (neb3 == '' ? '' : '&') + xwnel, null, nxl3e, xwen3l, t4pur6, vsj5d || function (en3xi) {
    return en3xi[H[640201]] == H[640272];
  }, null, H[640368]);
}, window['f1$I2A'] = function (ewlxn3, luexw0) {
  var mdj$s = 0x0;f1$2[H[640023]] && (mdj$s = f1$2[H[640023]][H[640024]]), sendApi(f1$2[H[640161]], H[640369], { 'partnerId': f1$2[H[640167]], 'gamePkg': f1$2[H[640022]], 'logTime': Math[H[640363]](Date[H[640142]]() / 0x3e8), 'platformUid': f1$2[H[640275]], 'type': ewlxn3, 'serverId': mdj$s }, null, 0x2, null, function () {
    return !![];
  });
}, window['f1$2AI'] = function (uel0x) {
  sendApi(f1$2[H[640159]], H[640370], { 'partner_id': f1$2[H[640167]], 'uid': f1$2[H[640019]], 'version': f1$2[H[640080]], 'game_pkg': f1$2[H[640022]], 'device': f1$2[H[640168]] }, f1$2IA, f1I2$, f12A);
}, window['f1$2IA'] = function (x40w) {
  if (x40w[H[640201]] === H[640272] && x40w[H[640200]]) {
    x40w[H[640200]][H[640371]]({ 'id': -0x2, 'name': H[640372] }), x40w[H[640200]][H[640371]]({ 'id': -0x1, 'name': H[640373] }), f1$2[H[640374]] = x40w[H[640200]];if (window[H[640375]]) window[H[640375]][H[640376]]();
  } else f1$2[H[640377]] = ![], window['f1AI$2'](H[640378] + x40w[H[640201]]);
}, window['f1AI$'] = function (i3ane) {
  sendApi(f1$2[H[640159]], H[640379], { 'partner_id': f1$2[H[640167]], 'uid': f1$2[H[640019]], 'version': f1$2[H[640080]], 'game_pkg': f1$2[H[640022]], 'device': f1$2[H[640168]] }, f1A$I, f1I2$, f12A);
}, window['f1A$I'] = function (nix) {
  f1$2[H[640380]] = ![];if (nix[H[640201]] === H[640272] && nix[H[640200]]) {
    for (var xwln3 = 0x0; xwln3 < nix[H[640200]][H[640010]]; xwln3++) {
      nix[H[640200]][xwln3][H[640291]] = f1$IA(nix[H[640200]][xwln3]);
    }f1$2[H[640170]][-0x1] = window[H[640381]](nix[H[640200]]), window[H[640375]][H[640382]](-0x1);
  } else window['f1AI$2'](H[640383] + nix[H[640201]]);
}, window[H[640384]] = function (r689pt) {
  sendApi(f1$2[H[640159]], H[640379], { 'partner_id': f1$2[H[640167]], 'uid': f1$2[H[640019]], 'version': f1$2[H[640080]], 'game_pkg': f1$2[H[640022]], 'device': f1$2[H[640168]] }, r689pt, f1I2$, f12A);
}, window['f1IA$'] = function (z1or9, gmyqd) {
  sendApi(f1$2[H[640159]], H[640385], { 'partner_id': f1$2[H[640167]], 'uid': f1$2[H[640019]], 'version': f1$2[H[640080]], 'game_pkg': f1$2[H[640022]], 'device': f1$2[H[640168]], 'server_group_id': gmyqd }, f1I$A, f1I2$, f12A);
}, window['f1I$A'] = function (bkni) {
  f1$2[H[640380]] = ![];if (bkni[H[640201]] === H[640272] && bkni[H[640200]] && bkni[H[640200]][H[640200]]) {
    var up406 = bkni[H[640200]][H[640386]],
        zor19 = [];for (var r89z6 = 0x0; r89z6 < bkni[H[640200]][H[640200]][H[640010]]; r89z6++) {
      bkni[H[640200]][H[640200]][r89z6][H[640291]] = f1$IA(bkni[H[640200]][H[640200]][r89z6]), (zor19[H[640010]] == 0x0 || bkni[H[640200]][H[640200]][r89z6][H[640291]] != 0x0) && (zor19[zor19[H[640010]]] = bkni[H[640200]][H[640200]][r89z6]);
    }f1$2[H[640170]][up406] = window[H[640381]](zor19), window[H[640375]][H[640382]](up406);
  } else window['f1AI$2'](H[640387] + bkni[H[640201]]);
}, window['f1KI2$'] = function (myqgd$) {
  sendApi(f1$2[H[640159]], H[640388], { 'partner_id': f1$2[H[640167]], 'uid': f1$2[H[640019]], 'version': f1$2[H[640080]], 'game_pkg': f1$2[H[640022]], 'device': f1$2[H[640168]] }, reqServerRecommendCallBack, f1I2$, f12A);
}, window[H[640389]] = function (ul04p) {
  f1$2[H[640380]] = ![];if (ul04p[H[640201]] === H[640272] && ul04p[H[640200]]) {
    for (var vdsj5$ = 0x0; vdsj5$ < ul04p[H[640200]][H[640010]]; vdsj5$++) {
      ul04p[H[640200]][vdsj5$][H[640291]] = f1$IA(ul04p[H[640200]][vdsj5$]);
    }f1$2[H[640170]][-0x2] = window[H[640381]](ul04p[H[640200]]), window[H[640375]][H[640382]](-0x2);
  } else alert(H[640390] + ul04p[H[640201]]);
}, window[H[640381]] = function (ut640) {
  if (!ut640 && ut640[H[640010]] <= 0x0) return ut640;for (let wb3n = 0x0; wb3n < ut640[H[640010]]; wb3n++) {
    ut640[wb3n][H[640391]] && ut640[wb3n][H[640391]] == 0x1 && (ut640[wb3n][H[640287]] += H[640392]);
  }return ut640;
}, window['f1$AI'] = function (vsk, ul04pt) {
  vsk = vsk || f1$2[H[640023]][H[640024]], sendApi(f1$2[H[640159]], H[640393], { 'type': '4', 'game_pkg': f1$2[H[640022]], 'server_id': vsk }, ul04pt);
}, window[H[640394]] = function (trpu46, kjs_v5, v_jsd, bakvi) {
  v_jsd = v_jsd || f1$2[H[640023]][H[640024]], sendApi(f1$2[H[640159]], H[640395], { 'type': trpu46, 'game_pkg': kjs_v5, 'server_id': v_jsd }, bakvi);
}, window['f1$IA'] = function (ai_kvb) {
  if (ai_kvb) {
    if (ai_kvb[H[640291]] == 0x1) {
      if (ai_kvb[H[640396]] == 0x1) return 0x2;else return 0x1;
    } else return ai_kvb[H[640291]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['f12AI$'] = function (kba3_i, avkj5_) {
  f1$2[H[640397]] = { 'step': kba3_i, 'server_id': avkj5_ };var wux0l4 = this;f1A$I2({ 'title': H[640398] }), sendApi(f1$2[H[640159]], H[640399], { 'partner_id': f1$2[H[640167]], 'uid': f1$2[H[640019]], 'game_pkg': f1$2[H[640022]], 'server_id': avkj5_, 'platform': f1$2[H[640084]], 'platform_uid': f1$2[H[640275]], 'check_login_time': f1$2[H[640278]], 'check_login_sign': f1$2[H[640276]], 'version_name': f1$2[H[640247]] }, f12A$I, f1I2$, f12A, function (ozr8) {
    return ozr8[H[640201]] == H[640272] || ozr8[H[640001]] == H[640400] || ozr8[H[640001]] == H[640401];
  });
}, window['f12A$I'] = function (uwlx) {
  var u40p6 = this;if (uwlx[H[640201]] === H[640272] && uwlx[H[640200]]) {
    var s_kvj = f1$2[H[640023]];s_kvj[H[640402]] = f1$2[H[640171]], s_kvj[H[640277]] = String(uwlx[H[640200]][H[640403]]), s_kvj[H[640177]] = parseInt(uwlx[H[640200]][H[640279]]);if (uwlx[H[640200]][H[640404]]) s_kvj[H[640404]] = parseInt(uwlx[H[640200]][H[640404]]);else s_kvj[H[640404]] = parseInt(uwlx[H[640200]][H[640024]]);s_kvj[H[640405]] = 0x0, s_kvj[H[640021]] = f1$2[H[640302]], s_kvj[H[640406]] = uwlx[H[640200]][H[640407]], s_kvj[H[640408]] = uwlx[H[640200]][H[640408]], console[H[640042]](H[640409] + JSON[H[640027]](s_kvj[H[640408]])), f1$2[H[640285]] == 0x1 && s_kvj[H[640408]] && s_kvj[H[640408]][H[640410]] == 0x1 && (f1$2[H[640411]] = 0x1, window[H[640035]][H[640036]]['f1K2$']()), f12IA$();
  } else f1$2[H[640397]][H[640412]] >= 0x3 ? (f12A(JSON[H[640027]](uwlx)), window['f1AI$2'](H[640413] + uwlx[H[640201]])) : sendApi(f1$2[H[640159]], H[640259], { 'platform': f1$2[H[640157]], 'partner_id': f1$2[H[640167]], 'token': f1$2[H[640257]], 'game_pkg': f1$2[H[640022]], 'deviceId': f1$2[H[640168]], 'scene': H[640260] + f1$2[H[640169]] }, function (kba3i) {
    if (!kba3i || kba3i[H[640201]] != H[640272]) {
      window['f1AI$2'](H[640273] + kba3i && kba3i[H[640201]]);return;
    }f1$2[H[640276]] = String(kba3i[H[640277]]), f1$2[H[640278]] = String(kba3i[H[640279]]), setTimeout(function () {
      f12AI$(f1$2[H[640397]][H[640412]] + 0x1, f1$2[H[640397]][H[640024]]);
    }, 0x5dc);
  }, f1I2$, f12A, function (xlu04) {
    return xlu04[H[640201]] == H[640272] || xlu04[H[640201]] == H[640414];
  });
}, window['f12IA$'] = function () {
  ServerLoading[H[640036]][H[640294]](f1$2[H[640285]]), window['f1I2'] = !![], window['f12$AI']();
}, window['f12I$A'] = function () {
  if (window['f12I'] && window['f1$I2'] && window[H[640183]] && window[H[640184]] && window['f1$2I'] && window['f1$I']) {
    if (!window[H[640415]][H[640036]]) {
      console[H[640042]](H[640416] + window[H[640415]][H[640036]]);var $qjsmd = wx[H[640417]](),
          m$y = $qjsmd[H[640138]] ? $qjsmd[H[640138]] : 0x0,
          $qydsm = { 'cdn': window['f1$2'][H[640021]], 'spareCdn': window['f1$2'][H[640245]], 'newRegister': window['f1$2'][H[640285]], 'wxPC': window['f1$2'][H[640113]], 'wxIOS': window['f1$2'][H[640107]], 'wxAndroid': window['f1$2'][H[640110]], 'wxParam': { 'limitLoad': window['f1$2']['f1KAI2$'], 'benchmarkLevel': window['f1$2']['f1KA$I2'], 'wxFrom': window[H[640006]][H[640252]] == H[640418] ? 0x1 : 0x0, 'wxSDKVersion': window[H[640040]] }, 'configType': window['f1$2'][H[640178]], 'exposeType': window['f1$2'][H[640180]], 'scene': m$y };new window[H[640415]]($qydsm, window['f1$2'][H[640020]], window['f1KAI$2']);
    }
  }
}, window['f12$AI'] = function () {
  if (window['f12I'] && window['f1$I2'] && window[H[640183]] && window[H[640184]] && window['f1$2I'] && window['f1$I'] && window['f1I2'] && window['f1I$']) {
    f1A$2I();if (!f12I$) {
      f12I$ = !![];if (!window[H[640415]][H[640036]]) window['f12I$A']();var mq7$g = 0x0,
          _5vka = wx[H[640419]]();_5vka && (window['f1$2'][H[640112]] && (mq7$g = _5vka[H[640102]]), console[H[640001]](H[640420] + _5vka[H[640102]] + H[640421] + _5vka[H[640103]] + H[640422] + _5vka[H[640104]] + H[640423] + _5vka[H[640105]] + H[640424] + _5vka[H[640425]] + H[640426] + _5vka[H[640427]]));var ak_3i = {};for (const bnak in f1$2[H[640023]]) {
        ak_3i[bnak] = f1$2[H[640023]][bnak];
      }var a_kib = { 'channel': window['f1$2'][H[640172]], 'account': window['f1$2'][H[640019]], 'userId': window['f1$2'][H[640274]], 'cdn': window['f1$2'][H[640021]], 'data': window['f1$2'][H[640200]], 'package': window['f1$2'][H[640155]], 'newRegister': window['f1$2'][H[640285]], 'pkgName': window['f1$2'][H[640022]], 'partnerId': window['f1$2'][H[640167]], 'platform_uid': window['f1$2'][H[640275]], 'deviceId': window['f1$2'][H[640168]], 'selectedServer': ak_3i, 'configType': window['f1$2'][H[640178]], 'exposeType': window['f1$2'][H[640180]], 'debugUsers': window['f1$2'][H[640175]], 'wxMenuTop': mq7$g, 'wxShield': window['f1$2'][H[640182]] };if (window[H[640305]]) for (var lxn3we in window[H[640305]]) {
        a_kib[lxn3we] = window[H[640305]][lxn3we];
      }window[H[640415]][H[640036]]['f12$K'](a_kib), setTimeout(() => {
        new MxFc();
      }, 0x2710);
    }
  } else console[H[640001]](H[640428] + window['f12I'] + H[640429] + window['f1$I2'] + H[640430] + window[H[640183]] + H[640431] + window[H[640184]] + H[640432] + window['f1$2I'] + H[640433] + window['f1$I'] + H[640434] + window['f1I2'] + H[640435] + window['f1I$']);
};