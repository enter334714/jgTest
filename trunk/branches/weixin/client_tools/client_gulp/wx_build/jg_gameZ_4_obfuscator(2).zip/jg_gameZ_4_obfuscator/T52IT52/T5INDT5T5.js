var B = wx.$B;
import Blt0y from '../T5T5basdT5/T55sdkT5.js';window[B[520144]] = { 'wxVersion': window[B[520006]][B[520007]] }, window[B[520145]] = ![], window['B1LN'] = 0x1, window[B[520146]] = 0x1, window['B1SNL'] = !![], window[B[520147]] = !![], window['B12_SNL'] = '', window['B1NL'] = { 'base_cdn': B[520148], 'cdn': B[520148] }, B1NL[B[520149]] = {}, B1NL[B[520150]] = '0', B1NL[B[520079]] = window[B[520144]][B[520151]], B1NL[B[520114]] = '', B1NL['os'] = '1', B1NL[B[520152]] = B[520153], B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520160]] = B[520161], B1NL[B[520162]] = '1', B1NL[B[520163]] = '', B1NL[B[520164]] = '', B1NL[B[520165]] = 0x0, B1NL[B[520166]] = {}, B1NL[B[520167]] = parseInt(B1NL[B[520162]]), B1NL[B[520168]] = B1NL[B[520162]], B1NL[B[520022]] = {}, B1NL['B1_N'] = B[520169], B1NL[B[520170]] = ![], B1NL[B[520171]] = B[520172], B1NL[B[520173]] = Date[B[520174]](), B1NL[B[520175]] = B[520176], B1NL[B[520177]] = '_a', B1NL[B[520178]] = 0x2, B1NL[B[520020]] = 0x7c1, B1NL[B[520151]] = window[B[520144]][B[520151]], B1NL[B[520179]] = ![], B1NL[B[520106]] = ![], B1NL[B[520109]] = ![], B1NL[B[520112]] = ![], window['B1SLN'] = 0x5, window['B1SL'] = ![], window['B1LS'] = ![], window['B1NSL'] = ![], window[B[520180]] = ![], window[B[520181]] = ![], window['B1NLS'] = ![], window['B1SN'] = ![], window['B1NS'] = ![], window['B1LSN'] = ![], window[B[520182]] = function (l$4vy) {
  console[B[520041]](B[520182], l$4vy), wx[B[520183]]({}), wx[B[520048]]({ 'title': B[520071], 'content': l$4vy, 'success'(pus) {
      if (pus[B[520184]]) console[B[520041]](B[520185]);else pus[B[520186]] && console[B[520041]](B[520187]);
    } });
}, window['B1_SNL'] = function (pn7ug) {
  console[B[520041]](B[520188], pn7ug), B1_NLS(), wx[B[520048]]({ 'title': B[520071], 'content': pn7ug, 'confirmText': B[520189], 'cancelText': B[520190], 'success'(nguse) {
      if (nguse[B[520184]]) window['B1N_']();else nguse[B[520186]] && (console[B[520041]](B[520191]), wx[B[520192]]({}));
    } });
}, window[B[520193]] = function (o1m5jr) {
  console[B[520041]](B[520193], o1m5jr), wx[B[520048]]({ 'title': B[520071], 'content': o1m5jr, 'confirmText': B[520194], 'showCancel': ![], 'complete'(s7gnuh) {
      console[B[520041]](B[520191]), wx[B[520192]]({});
    } });
}, window['B1_SLN'] = ![], window['B1_NSL'] = function (h7b96) {
  window['B1_SLN'] = !![], wx[B[520195]](h7b96);
}, window['B1_NLS'] = function () {
  window['B1_SLN'] && (window['B1_SLN'] = ![], wx[B[520183]]({}));
}, window['B1_LSN'] = function (v0$y4) {
  window[B[520034]][B[520035]]['B1_LSN'](v0$y4);
}, window[B[520196]] = function (ia83w, wf32a) {
  Blt0y[B[520196]](ia83w, function (b4zyvl) {
    b4zyvl && b4zyvl[B[520197]] ? b4zyvl[B[520197]][B[520198]] == 0x1 ? wf32a(!![]) : (wf32a(![]), console[B[520001]](B[520199] + b4zyvl[B[520197]][B[520200]])) : console[B[520041]](B[520196], b4zyvl);
  });
}, window['B1_LNS'] = function (qt$_x) {
  console[B[520041]](B[520201], qt$_x);
}, window['B1_NL'] = function (seug) {}, window['B1_LN'] = function (lbz4vy, yv04zl, ag2ip) {}, window['B1_L'] = function (zkh9b6) {
  console[B[520041]](B[520202], zkh9b6), window[B[520034]][B[520035]][B[520203]](), window[B[520034]][B[520035]][B[520204]](), window[B[520034]][B[520035]][B[520205]]();
}, window['B1L_'] = function (dqt$_x) {
  window['B1_SNL'](B[520206]);var pei = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'account': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'cdn': window['B1NL'][B[520021]], 'pkgName': window['B1NL'][B[520163]], 'gamever': window[B[520006]][B[520007]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': B[520207], 'stack': dqt$_x ? dqt$_x : B[520206] },
      eiw23a = JSON[B[520026]](pei);console[B[520027]](B[520208] + eiw23a), window['B1_N'](eiw23a);
}, window['B1N_L'] = function (o1) {
  var v4zlkb = JSON[B[520209]](o1);v4zlkb[B[520210]] = window[B[520006]][B[520007]], v4zlkb[B[520211]] = window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, v4zlkb[B[520024]] = window[B[520024]];var $_yxt0 = JSON[B[520026]](v4zlkb);console[B[520027]](B[520212] + $_yxt0), window['B1_N']($_yxt0);
}, window['B1NL_'] = function (rm15j, w3i2e) {
  var $0xyvt = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'account': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'cdn': window['B1NL'][B[520021]], 'pkgName': window['B1NL'][B[520163]], 'gamever': window[B[520006]][B[520007]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': rm15j, 'stack': w3i2e },
      j5rf3 = JSON[B[520026]]($0xyvt);console[B[520213]](B[520214] + j5rf3), window['B1_N'](j5rf3);
}, window['B1_N'] = function (l0y4) {
  if (window['B1NL'][B[520115]] == B[520215]) return;var gunse = B1NL['B1_N'] + B[520216] + B1NL[B[520019]];wx[B[520217]]({ 'url': gunse, 'method': B[520218], 'data': l0y4, 'header': { 'content-type': B[520219], 'cache-control': B[520220] }, 'success': function (l0y$v4) {
      DEBUG && console[B[520041]](B[520221], gunse, l0y4, l0y$v4);
    }, 'fail': function (bk7h69) {
      DEBUG && console[B[520041]](B[520221], gunse, l0y4, bk7h69);
    }, 'complete': function () {} });
}, window[B[520222]] = function () {
  function rw5f83() {
    return ((0x1 + Math[B[520223]]()) * 0x10000 | 0x0)[B[520224]](0x10)[B[520225]](0x1);
  }return rw5f83() + rw5f83() + '-' + rw5f83() + '-' + rw5f83() + '-' + rw5f83() + '+' + rw5f83() + rw5f83() + rw5f83();
}, window['B1N_'] = function () {
  console[B[520041]](B[520226]);var xdt0_ = Blt0y[B[520227]]();B1NL[B[520168]] = xdt0_[B[520228]], B1NL[B[520167]] = xdt0_[B[520228]], B1NL[B[520162]] = xdt0_[B[520228]], B1NL[B[520163]] = xdt0_[B[520229]];var neugp = { 'game_ver': B1NL[B[520079]] };B1NL[B[520164]] = this[B[520222]](), B1_NSL({ 'title': B[520230] }), Blt0y[B[520231]](neugp, this['B1L_N'][B[520232]](this));
};var wx_develop = ![];window['B1L_N'] = function (j851rf) {
  var x$dq = j851rf[B[520233]];wx_develop = x$dq == 0x1, console[B[520041]](B[520234] + x$dq + B[520235] + (x$dq == 0x1) + B[520236] + j851rf[B[520007]] + B[520237] + window[B[520144]][B[520151]]);if (!j851rf[B[520007]] || window['B12SL_N'](window[B[520144]][B[520151]], j851rf[B[520007]]) < 0x0) console[B[520041]](B[520238]), B1NL[B[520154]] = B[520239], B1NL[B[520156]] = B[520240], B1NL[B[520158]] = B[520241], B1NL[B[520021]] = B[520242], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = 'fs', B1NL[B[520179]] = ![];else window['B12SL_N'](window[B[520144]][B[520151]], j851rf[B[520007]]) == 0x0 ? (console[B[520041]](B[520246]), B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520021]] = B[520247], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = B[520248], B1NL[B[520179]] = !![]) : (console[B[520041]](B[520249]), B1NL[B[520154]] = B[520155], B1NL[B[520156]] = B[520157], B1NL[B[520158]] = B[520159], B1NL[B[520021]] = B[520247], B1NL[B[520243]] = B[520244], B1NL[B[520245]] = B[520248], B1NL[B[520179]] = ![]);B1NL[B[520165]] = config[B[520250]] ? config[B[520250]] : 0x0, this['B1SN_L'](), this['B1SNL_'](), window[B[520251]] = 0x5, B1_NSL({ 'title': B[520252] }), Blt0y[B[520253]](this['B1LN_'][B[520232]](this));
}, window[B[520251]] = 0x5, window['B1LN_'] = function (sugpe, gupein) {
  if (sugpe == 0x0 && gupein && gupein[B[520254]]) {
    B1NL[B[520255]] = gupein[B[520254]];var f385r = this;B1_NSL({ 'title': B[520256] }), sendApi(B1NL[B[520154]], B[520257], { 'platform': B1NL[B[520152]], 'partner_id': B1NL[B[520162]], 'token': gupein[B[520254]], 'game_pkg': B1NL[B[520163]], 'deviceId': B1NL[B[520164]], 'scene': B[520258] + B1NL[B[520165]] }, this['B1S_NL'][B[520232]](this), B1SLN, B1L_);
  } else gupein && gupein[B[520058]] && window[B[520251]] > 0x0 && (gupein[B[520058]][B[520107]](B[520259]) != -0x1 || gupein[B[520058]][B[520107]](B[520260]) != -0x1 || gupein[B[520058]][B[520107]](B[520261]) != -0x1 || gupein[B[520058]][B[520107]](B[520262]) != -0x1 || gupein[B[520058]][B[520107]](B[520263]) != -0x1 || gupein[B[520058]][B[520107]](B[520264]) != -0x1) ? (window[B[520251]]--, Blt0y[B[520253]](this['B1LN_'][B[520232]](this))) : (window['B1NL_'](B[520265], JSON[B[520026]]({ 'status': sugpe, 'data': gupein })), window['B1_SNL'](B[520266] + (gupein && gupein[B[520058]] ? '，' + gupein[B[520058]] : '')));
}, window['B1S_NL'] = function (bk4lz9) {
  if (!bk4lz9) {
    window['B1NL_'](B[520267], B[520268]), window['B1_SNL'](B[520269]);return;
  }if (bk4lz9[B[520198]] != B[520270]) {
    window['B1NL_'](B[520267], JSON[B[520026]](bk4lz9)), window['B1_SNL'](B[520271] + bk4lz9[B[520198]]);return;
  }B1NL[B[520272]] = String(bk4lz9[B[520019]]), B1NL[B[520019]] = String(bk4lz9[B[520019]]), B1NL[B[520083]] = String(bk4lz9[B[520083]]), B1NL[B[520168]] = String(bk4lz9[B[520083]]), B1NL[B[520273]] = String(bk4lz9[B[520273]]), B1NL[B[520274]] = String(bk4lz9[B[520275]]), B1NL[B[520276]] = String(bk4lz9[B[520277]]), B1NL[B[520275]] = '';var tyxv$ = this;B1_NSL({ 'title': B[520278] }), sendApi(B1NL[B[520154]], B[520279], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, tyxv$['B1S_LN'][B[520232]](tyxv$), B1SLN, B1L_);
}, window['B1S_LN'] = function (nh97s) {
  if (!nh97s) {
    window['B1_SNL'](B[520280]);return;
  }if (nh97s[B[520198]] != B[520270]) {
    window['B1_SNL'](B[520281] + nh97s[B[520198]]);return;
  }if (!nh97s[B[520197]] || nh97s[B[520197]][B[520010]] == 0x0) {
    window['B1_SNL'](B[520282]);return;
  }B1NL[B[520283]] = nh97s[B[520284]], B1NL[B[520022]] = { 'server_id': String(nh97s[B[520197]][0x0][B[520023]]), 'server_name': String(nh97s[B[520197]][0x0][B[520285]]), 'entry_ip': nh97s[B[520197]][0x0][B[520286]], 'entry_port': parseInt(nh97s[B[520197]][0x0][B[520287]]), 'status': B1NS_(nh97s[B[520197]][0x0]), 'start_time': nh97s[B[520197]][0x0][B[520288]], 'cdn': B1NL[B[520021]] }, this['B1LNS_']();
}, window['B1LNS_'] = function () {
  if (B1NL[B[520283]] == 0x1) {
    var r1jf58 = B1NL[B[520022]][B[520289]];if (r1jf58 === -0x1 || r1jf58 === 0x0) {
      window['B1_SNL'](r1jf58 === -0x1 ? B[520290] : B[520291]);return;
    }B1L_SN(0x0, B1NL[B[520022]][B[520023]]), window[B[520034]][B[520035]][B[520292]](B1NL[B[520283]]);
  } else window[B[520034]][B[520035]][B[520293]](), B1_NLS();window['B1NS'] = !![], window['B1LSN_'](), window['B1LN_S']();
}, window['B1SN_L'] = function () {
  sendApi(B1NL[B[520154]], B[520294], { 'game_pkg': B1NL[B[520163]], 'version_name': B1NL[B[520245]] }, this[B[520295]][B[520232]](this), B1SLN, B1L_);
}, window[B[520295]] = function (lk4zv) {
  if (!lk4zv) {
    window['B1_SNL'](B[520296]);return;
  }if (lk4zv[B[520198]] != B[520270]) {
    window['B1_SNL'](B[520297] + lk4zv[B[520198]]);return;
  }if (!lk4zv[B[520197]] || !lk4zv[B[520197]][B[520079]]) {
    window['B1_SNL'](B[520298] + (lk4zv[B[520197]] && lk4zv[B[520197]][B[520079]]));return;
  }lk4zv[B[520197]][B[520299]] && lk4zv[B[520197]][B[520299]][B[520010]] > 0xa && (B1NL[B[520300]] = lk4zv[B[520197]][B[520299]], B1NL[B[520021]] = lk4zv[B[520197]][B[520299]]), lk4zv[B[520197]][B[520079]] && (B1NL[B[520020]] = lk4zv[B[520197]][B[520079]]), console[B[520001]](B[520301] + B1NL[B[520020]] + B[520302] + B1NL[B[520245]]), window['B1NLS'] = !![], window['B1LSN_'](), window['B1LN_S']();
}, window[B[520303]], window['B1SNL_'] = function () {
  sendApi(B1NL[B[520154]], B[520304], { 'game_pkg': B1NL[B[520163]] }, this['B1SL_N'][B[520232]](this), B1SLN, B1L_);
}, window['B1SL_N'] = function (p7nus) {
  if (p7nus[B[520198]] === B[520270] && p7nus[B[520197]]) {
    window[B[520303]] = p7nus[B[520197]];for (var jr15m in p7nus[B[520197]]) {
      B1NL[jr15m] = p7nus[B[520197]][jr15m];
    }
  } else console[B[520001]](B[520305] + p7nus[B[520198]]);window['B1SN'] = !![], window['B1LN_S']();
}, window[B[520306]] = function (jf5m1r, z04ylv, j38, ugp2i, nuepgi, wae32i, k649, dtx$_0, rj15f) {
  nuepgi = String(nuepgi);var a32f8 = k649,
      skh97 = dtx$_0;B1NL[B[520149]][nuepgi] = { 'productid': nuepgi, 'productname': a32f8, 'productdesc': skh97, 'roleid': jf5m1r, 'rolename': z04ylv, 'rolelevel': j38, 'price': wae32i, 'callback': rj15f }, sendApi(B1NL[B[520158]], B[520307], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'server_name': B1NL[B[520022]][B[520285]], 'level': j38, 'uid': B1NL[B[520019]], 'role_id': jf5m1r, 'role_name': z04ylv, 'product_id': nuepgi, 'product_name': a32f8, 'product_desc': skh97, 'money': wae32i, 'partner_id': B1NL[B[520162]] }, toPayCallBack, B1SLN, B1L_);
}, window[B[520308]] = function (ybzl4) {
  if (ybzl4) {
    if (ybzl4[B[520309]] === 0xc8 || ybzl4[B[520198]] == B[520270]) {
      var pgei2 = B1NL[B[520149]][String(ybzl4[B[520310]])];if (pgei2[B[520311]]) pgei2[B[520311]](ybzl4[B[520310]], ybzl4[B[520312]], -0x1);Blt0y[B[520313]]({ 'cpbill': ybzl4[B[520312]], 'productid': ybzl4[B[520310]], 'productname': pgei2[B[520314]], 'productdesc': pgei2[B[520315]], 'serverid': B1NL[B[520022]][B[520023]], 'servername': B1NL[B[520022]][B[520285]], 'roleid': pgei2[B[520316]], 'rolename': pgei2[B[520317]], 'rolelevel': pgei2[B[520318]], 'price': pgei2[B[520319]], 'extension': JSON[B[520026]]({ 'cp_order_id': ybzl4[B[520312]] }) }, function (af8r, aipwe) {
        pgei2[B[520311]] && af8r == 0x0 && pgei2[B[520311]](ybzl4[B[520310]], ybzl4[B[520312]], af8r);console[B[520001]](JSON[B[520026]]({ 'type': B[520320], 'status': af8r, 'data': ybzl4, 'role_name': pgei2[B[520317]] }));if (af8r === 0x0) {} else {
          if (af8r === 0x1) {} else {
            if (af8r === 0x2) {}
          }
        }
      });
    } else alert(ybzl4[B[520001]]);
  }
}, window['B1SLN_'] = function () {}, window['B1_SL'] = function (psun7, ngespu, xy$t_0, y4vbl, zkl4v) {
  Blt0y[B[520321]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], psun7, ngespu, xy$t_0), sendApi(B1NL[B[520154]], B[520322], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': psun7, 'uid': B1NL[B[520019]], 'role_name': ngespu, 'role_type': y4vbl, 'level': xy$t_0 });
}, window['B1_LS'] = function (pegin, y$0xt_, s7k6h9, $tx0_, s7hgu, sp7ngu, z4byvl, pg2aei, lzv4bk, a2epi) {
  B1NL[B[520016]] = pegin, B1NL[B[520017]] = y$0xt_, B1NL[B[520018]] = s7k6h9, Blt0y[B[520323]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], pegin, y$0xt_, s7k6h9), sendApi(B1NL[B[520154]], B[520324], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': pegin, 'uid': B1NL[B[520019]], 'role_name': y$0xt_, 'role_type': $tx0_, 'level': s7k6h9, 'evolution': s7hgu });
}, window['B1S_L'] = function (r853fw, mjrf, fw8r5, ylv04z, zh69b, ueip, supg7n, wiep, v4y$0, oj1r5) {
  B1NL[B[520016]] = r853fw, B1NL[B[520017]] = mjrf, B1NL[B[520018]] = fw8r5, Blt0y[B[520325]](B1NL[B[520022]][B[520023]], B1NL[B[520022]][B[520285]] || B1NL[B[520022]][B[520023]], r853fw, mjrf, fw8r5), sendApi(B1NL[B[520154]], B[520324], { 'game_pkg': B1NL[B[520163]], 'server_id': B1NL[B[520022]][B[520023]], 'role_id': r853fw, 'uid': B1NL[B[520019]], 'role_name': mjrf, 'role_type': ylv04z, 'level': fw8r5, 'evolution': zh69b });
}, window['B1SL_'] = function (uhs7n6) {}, window['B1_S'] = function (w23eai) {
  Blt0y[B[520326]](B[520326], function (vxy) {
    w23eai && w23eai(vxy);
  });
}, window[B[520327]] = function () {
  Blt0y[B[520327]]();
}, window[B[520328]] = function () {
  Blt0y[B[520329]]();
}, window[B[520135]] = function (k9hb) {
  window['B1L_S'] = k9hb, window['B1L_S'] && window['B1S_'] && (console[B[520001]](B[520136] + window['B1S_'][B[520137]]), window['B1L_S'](window['B1S_']), window['B1S_'] = null);
}, window['B1LS_'] = function (bl9z4k, $0x_, h7k69, gpie2) {
  window[B[520330]](B[520331], { 'game_pkg': window['B1NL'][B[520163]], 'role_id': $0x_, 'server_id': h7k69 }, gpie2);
}, window['B1N_SL'] = function (vyzlb4, d_$xq) {
  function pea2i(gpinue) {
    var h7n6su = [],
        a38w2i = [],
        y0t$l = window[B[520006]][B[520332]];for (var j15frm in y0t$l) {
      var z96bkh = Number(j15frm);(!vyzlb4 || !vyzlb4[B[520010]] || vyzlb4[B[520107]](z96bkh) != -0x1) && (a38w2i[B[520038]](y0t$l[j15frm]), h7n6su[B[520038]]([z96bkh, 0x3]));
    }window['B12SL_N'](window[B[520039]], B[520333]) >= 0x0 ? (console[B[520041]](B[520334]), Blt0y[B[520335]] && Blt0y[B[520335]](a38w2i, function (mf5jr) {
      console[B[520041]](B[520336]), console[B[520041]](mf5jr);if (mf5jr && mf5jr[B[520058]] == B[520337]) for (var xt0y$_ in y0t$l) {
        if (mf5jr[y0t$l[xt0y$_]] == B[520338]) {
          var euns = Number(xt0y$_);for (var pw2 = 0x0; pw2 < h7n6su[B[520010]]; pw2++) {
            if (h7n6su[pw2][0x0] == euns) {
              h7n6su[pw2][0x1] = 0x1;break;
            }
          }
        }
      }window['B12SL_N'](window[B[520039]], B[520339]) >= 0x0 ? wx[B[520340]]({ 'withSubscriptions': !![], 'success': function (wfr8a3) {
          var fraw83 = wfr8a3[B[520341]][B[520342]];if (fraw83) {
            console[B[520041]](B[520343]), console[B[520041]](fraw83);for (var r1mj5f in y0t$l) {
              if (fraw83[y0t$l[r1mj5f]] == B[520338]) {
                var $t0dx_ = Number(r1mj5f);for (var u7spgn = 0x0; u7spgn < h7n6su[B[520010]]; u7spgn++) {
                  if (h7n6su[u7spgn][0x0] == $t0dx_) {
                    h7n6su[u7spgn][0x1] = 0x2;break;
                  }
                }
              }
            }console[B[520041]](h7n6su), d_$xq && d_$xq(h7n6su);
          } else console[B[520041]](B[520344]), console[B[520041]](wfr8a3), console[B[520041]](h7n6su), d_$xq && d_$xq(h7n6su);
        }, 'fail': function () {
          console[B[520041]](B[520345]), console[B[520041]](h7n6su), d_$xq && d_$xq(h7n6su);
        } }) : (console[B[520041]](B[520346] + window[B[520039]]), console[B[520041]](h7n6su), d_$xq && d_$xq(h7n6su));
    })) : (console[B[520041]](B[520347] + window[B[520039]]), console[B[520041]](h7n6su), d_$xq && d_$xq(h7n6su)), wx[B[520348]](pea2i);
  }wx[B[520349]](pea2i);
}, window['B1N_LS'] = { 'isSuccess': ![], 'level': B[520350], 'isCharging': ![] }, window['B1NS_L'] = function (ughs7) {
  wx[B[520123]]({ 'success': function ($tyx0_) {
      var usgpne = window['B1N_LS'];usgpne[B[520351]] = !![], usgpne[B[520125]] = Number($tyx0_[B[520125]])[B[520352]](0x0), usgpne[B[520127]] = $tyx0_[B[520127]], ughs7 && ughs7(usgpne[B[520351]], usgpne[B[520125]], usgpne[B[520127]]);
    }, 'fail': function (m5f1r) {
      console[B[520041]](B[520353], m5f1r[B[520058]]);var nepiu = window['B1N_LS'];ughs7 && ughs7(nepiu[B[520351]], nepiu[B[520125]], nepiu[B[520127]]);
    } });
}, window[B[520330]] = function (b7k96h, i3aew2, lvt0, w3e2a, $d_tqx, ngi, tv$yx, farw8) {
  if (w3e2a == undefined) w3e2a = 0x1;wx[B[520217]]({ 'url': b7k96h, 'method': tv$yx || B[520354], 'responseType': B[520355], 'data': i3aew2, 'header': { 'content-type': farw8 || B[520219] }, 'success': function (faw328) {
      DEBUG && console[B[520041]](B[520356], b7k96h, info, faw328);if (faw328 && faw328[B[520357]] == 0xc8) {
        var $_0td = faw328[B[520197]];!ngi || ngi($_0td) ? lvt0 && lvt0($_0td) : window[B[520358]](b7k96h, i3aew2, lvt0, w3e2a, $d_tqx, ngi, faw328);
      } else window[B[520358]](b7k96h, i3aew2, lvt0, w3e2a, $d_tqx, ngi, faw328);
    }, 'fail': function (nuspeg) {
      DEBUG && console[B[520041]](B[520359], b7k96h, info, nuspeg), window[B[520358]](b7k96h, i3aew2, lvt0, w3e2a, $d_tqx, ngi, nuspeg);
    }, 'complete': function () {} });
}, window[B[520358]] = function (rwf358, s9hk76, r83afw, egpai, ai8w3, rj8f35, ngpu7s) {
  egpai - 0x1 > 0x0 ? setTimeout(function () {
    window[B[520330]](rwf358, s9hk76, r83afw, egpai - 0x1, ai8w3, rj8f35);
  }, 0x3e8) : ai8w3 && ai8w3(JSON[B[520026]]({ 'url': rwf358, 'response': ngpu7s }));
}, window[B[520360]] = function (yxtv$, rwf38, peai, d$qx_, suhn67, $yl40v, fj385) {
  !peai && (peai = {});var qd_$tx = Math[B[520361]](Date[B[520174]]() / 0x3e8);peai[B[520277]] = qd_$tx, peai[B[520362]] = rwf38;var k69hs = Object[B[520363]](peai)[B[520364]](),
      xd_tq$ = '',
      _d0t$ = '';for (var zb46k = 0x0; zb46k < k69hs[B[520010]]; zb46k++) {
    xd_tq$ = xd_tq$ + (zb46k == 0x0 ? '' : '&') + k69hs[zb46k] + peai[k69hs[zb46k]], _d0t$ = _d0t$ + (zb46k == 0x0 ? '' : '&') + k69hs[zb46k] + '=' + encodeURIComponent(peai[k69hs[zb46k]]);
  }xd_tq$ = xd_tq$ + B1NL[B[520160]];var $x0v = B[520365] + md5(xd_tq$);send(yxtv$ + '?' + _d0t$ + (_d0t$ == '' ? '' : '&') + $x0v, null, d$qx_, suhn67, $yl40v, fj385 || function (a8i32w) {
    return a8i32w[B[520198]] == B[520270];
  }, null, B[520366]);
}, window['B1NSL_'] = function (_0$t, ns7uh6) {
  var k6bh9 = 0x0;B1NL[B[520022]] && (k6bh9 = B1NL[B[520022]][B[520023]]), sendApi(B1NL[B[520156]], B[520367], { 'partnerId': B1NL[B[520162]], 'gamePkg': B1NL[B[520163]], 'logTime': Math[B[520361]](Date[B[520174]]() / 0x3e8), 'platformUid': B1NL[B[520273]], 'type': _0$t, 'serverId': k6bh9 }, null, 0x2, null, function () {
    return !![];
  });
}, window['B1NL_S'] = function (gnepiu) {
  sendApi(B1NL[B[520154]], B[520368], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, B1NLS_, B1SLN, B1L_);
}, window['B1NLS_'] = function (sk67) {
  if (sk67[B[520198]] === B[520270] && sk67[B[520197]]) {
    sk67[B[520197]][B[520369]]({ 'id': -0x2, 'name': B[520370] }), sk67[B[520197]][B[520369]]({ 'id': -0x1, 'name': B[520371] }), B1NL[B[520372]] = sk67[B[520197]];if (window[B[520373]]) window[B[520373]][B[520374]]();
  } else B1NL[B[520375]] = ![], window['B1_SNL'](B[520376] + sk67[B[520198]]);
}, window['B1_SN'] = function ($04vly) {
  sendApi(B1NL[B[520154]], B[520377], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, B1_NS, B1SLN, B1L_);
}, window['B1_NS'] = function (guenps) {
  B1NL[B[520378]] = ![];if (guenps[B[520198]] === B[520270] && guenps[B[520197]]) {
    for (var j5mr = 0x0; j5mr < guenps[B[520197]][B[520010]]; j5mr++) {
      guenps[B[520197]][j5mr][B[520289]] = B1NS_(guenps[B[520197]][j5mr]);
    }B1NL[B[520166]][-0x1] = window[B[520379]](guenps[B[520197]]), window[B[520373]][B[520380]](-0x1);
  } else window['B1_SNL'](B[520381] + guenps[B[520198]]);
}, window[B[520382]] = function (gup2e) {
  sendApi(B1NL[B[520154]], B[520377], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, gup2e, B1SLN, B1L_);
}, window['B1S_N'] = function (xd_$q, egspn) {
  sendApi(B1NL[B[520154]], B[520383], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]], 'server_group_id': egspn }, B1SN_, B1SLN, B1L_);
}, window['B1SN_'] = function (enuip) {
  B1NL[B[520378]] = ![];if (enuip[B[520198]] === B[520270] && enuip[B[520197]] && enuip[B[520197]][B[520197]]) {
    var jf538 = enuip[B[520197]][B[520384]],
        fw38ar = [];for (var enig = 0x0; enig < enuip[B[520197]][B[520197]][B[520010]]; enig++) {
      enuip[B[520197]][B[520197]][enig][B[520289]] = B1NS_(enuip[B[520197]][B[520197]][enig]), (fw38ar[B[520010]] == 0x0 || enuip[B[520197]][B[520197]][enig][B[520289]] != 0x0) && (fw38ar[fw38ar[B[520010]]] = enuip[B[520197]][B[520197]][enig]);
    }B1NL[B[520166]][jf538] = window[B[520379]](fw38ar), window[B[520373]][B[520380]](jf538);
  } else window['B1_SNL'](B[520385] + enuip[B[520198]]);
}, window['B12SLN'] = function (nueig) {
  sendApi(B1NL[B[520154]], B[520386], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'version': B1NL[B[520079]], 'game_pkg': B1NL[B[520163]], 'device': B1NL[B[520164]] }, reqServerRecommendCallBack, B1SLN, B1L_);
}, window[B[520387]] = function (h7bk6) {
  B1NL[B[520378]] = ![];if (h7bk6[B[520198]] === B[520270] && h7bk6[B[520197]]) {
    for (var eai2wp = 0x0; eai2wp < h7bk6[B[520197]][B[520010]]; eai2wp++) {
      h7bk6[B[520197]][eai2wp][B[520289]] = B1NS_(h7bk6[B[520197]][eai2wp]);
    }B1NL[B[520166]][-0x2] = window[B[520379]](h7bk6[B[520197]]), window[B[520373]][B[520380]](-0x2);
  } else alert(B[520388] + h7bk6[B[520198]]);
}, window[B[520379]] = function ($0yvx) {
  if (!$0yvx && $0yvx[B[520010]] <= 0x0) return $0yvx;for (let zy4v = 0x0; zy4v < $0yvx[B[520010]]; zy4v++) {
    $0yvx[zy4v][B[520389]] && $0yvx[zy4v][B[520389]] == 0x1 && ($0yvx[zy4v][B[520285]] += B[520390]);
  }return $0yvx;
}, window['B1N_S'] = function (weai, ty0x) {
  weai = weai || B1NL[B[520022]][B[520023]], sendApi(B1NL[B[520154]], B[520391], { 'type': '4', 'game_pkg': B1NL[B[520163]], 'server_id': weai }, ty0x);
}, window[B[520392]] = function (nuipg, sgnuep, sepgn, gaie) {
  sepgn = sepgn || B1NL[B[520022]][B[520023]], sendApi(B1NL[B[520154]], B[520393], { 'type': nuipg, 'game_pkg': sgnuep, 'server_id': sepgn }, gaie);
}, window['B1NS_'] = function (k96hs) {
  if (k96hs) {
    if (k96hs[B[520289]] == 0x1) {
      if (k96hs[B[520394]] == 0x1) return 0x2;else return 0x1;
    } else return k96hs[B[520289]] == 0x0 ? 0x0 : -0x1;
  }return -0x1;
}, window['B1L_SN'] = function (zk69b, b4kl) {
  B1NL[B[520395]] = { 'step': zk69b, 'server_id': b4kl };var lb4vzk = this;B1_NSL({ 'title': B[520396] }), sendApi(B1NL[B[520154]], B[520397], { 'partner_id': B1NL[B[520162]], 'uid': B1NL[B[520019]], 'game_pkg': B1NL[B[520163]], 'server_id': b4kl, 'platform': B1NL[B[520083]], 'platform_uid': B1NL[B[520273]], 'check_login_time': B1NL[B[520276]], 'check_login_sign': B1NL[B[520274]], 'version_name': B1NL[B[520245]] }, B1L_NS, B1SLN, B1L_, function (e2iaw3) {
    return e2iaw3[B[520198]] == B[520270] || e2iaw3[B[520001]] == B[520398] || e2iaw3[B[520001]] == B[520399];
  });
}, window['B1L_NS'] = function (ie2a3) {
  var fw5 = this;if (ie2a3[B[520198]] === B[520270] && ie2a3[B[520197]]) {
    var k79hs6 = B1NL[B[520022]];k79hs6[B[520400]] = B1NL[B[520167]], k79hs6[B[520275]] = String(ie2a3[B[520197]][B[520401]]), k79hs6[B[520173]] = parseInt(ie2a3[B[520197]][B[520277]]);if (ie2a3[B[520197]][B[520402]]) k79hs6[B[520402]] = parseInt(ie2a3[B[520197]][B[520402]]);else k79hs6[B[520402]] = parseInt(ie2a3[B[520197]][B[520023]]);k79hs6[B[520403]] = 0x0, k79hs6[B[520021]] = B1NL[B[520300]], k79hs6[B[520404]] = ie2a3[B[520197]][B[520405]], k79hs6[B[520406]] = ie2a3[B[520197]][B[520406]], console[B[520041]](B[520407] + JSON[B[520026]](k79hs6[B[520406]])), B1NL[B[520283]] == 0x1 && k79hs6[B[520406]] && k79hs6[B[520406]][B[520408]] == 0x1 && (B1NL[B[520409]] = 0x1, window[B[520034]][B[520035]]['B12LN']()), B1LS_N();
  } else sendApi(B1NL[B[520154]], B[520257], { 'platform': B1NL[B[520152]], 'partner_id': B1NL[B[520162]], 'token': B1NL[B[520255]], 'game_pkg': B1NL[B[520163]], 'deviceId': B1NL[B[520164]], 'scene': B[520258] + B1NL[B[520165]] }, function ($dxt0_) {
    if ($dxt0_[B[520198]] == B[520410]) {
      window['B1_SNL'](B[520271] + $dxt0_[B[520198]]);return;
    }B1NL[B[520274]] = String($dxt0_[B[520275]]), B1NL[B[520276]] = String($dxt0_[B[520277]]), setTimeout(function () {
      B1L_SN(B1NL[B[520395]][B[520411]], B1NL[B[520395]][B[520023]]);
    }, 0x5dc);
  }, B1SLN, B1L_, function (k76b9h) {
    return k76b9h[B[520198]] == B[520270] || k76b9h[B[520198]] == B[520410];
  });
}, window['B1LS_N'] = function () {
  ServerLoading[B[520035]][B[520292]](B1NL[B[520283]]), window['B1SL'] = !![], window['B1LN_S']();
}, window['B1LSN_'] = function () {
  if (window['B1LS'] && window['B1NSL'] && window[B[520180]] && window[B[520181]] && window['B1NLS'] && window['B1NS']) {
    if (!window[B[520412]][B[520035]]) {
      console[B[520041]](B[520413] + window[B[520412]][B[520035]]);var upig2 = wx[B[520414]](),
          $d_0x = upig2[B[520137]] ? upig2[B[520137]] : 0x0,
          kbl4z = { 'cdn': window['B1NL'][B[520021]], 'spareCdn': window['B1NL'][B[520243]], 'newRegister': window['B1NL'][B[520283]], 'wxPC': window['B1NL'][B[520112]], 'wxIOS': window['B1NL'][B[520106]], 'wxAndroid': window['B1NL'][B[520109]], 'wxParam': { 'limitLoad': window['B1NL']['B12_SLN'], 'benchmarkLevel': window['B1NL']['B12_NSL'], 'wxFrom': window[B[520006]][B[520250]] == B[520415] ? 0x1 : 0x0, 'wxSDKVersion': window[B[520039]] }, 'configType': window['B1NL'][B[520175]], 'exposeType': window['B1NL'][B[520177]], 'scene': $d_0x };new window[B[520412]](kbl4z, window['B1NL'][B[520020]], window['B12_SNL']);
    }
  }
}, window['B1LN_S'] = function () {
  if (window['B1LS'] && window['B1NSL'] && window[B[520180]] && window[B[520181]] && window['B1NLS'] && window['B1NS'] && window['B1SL'] && window['B1SN']) {
    B1_NLS();if (!B1LSN) {
      B1LSN = !![];if (!window[B[520412]][B[520035]]) window['B1LSN_']();var bz4l9k = 0x0,
          aip2eg = wx[B[520416]]();aip2eg && (window['B1NL'][B[520111]] && (bz4l9k = aip2eg[B[520101]]), console[B[520001]](B[520417] + aip2eg[B[520101]] + B[520418] + aip2eg[B[520102]] + B[520419] + aip2eg[B[520103]] + B[520420] + aip2eg[B[520104]] + B[520421] + aip2eg[B[520422]] + B[520423] + aip2eg[B[520424]]));var fj5r18 = {};for (const a2wipe in B1NL[B[520022]]) {
        fj5r18[a2wipe] = B1NL[B[520022]][a2wipe];
      }var _$tqd = { 'channel': window['B1NL'][B[520168]], 'account': window['B1NL'][B[520019]], 'userId': window['B1NL'][B[520272]], 'cdn': window['B1NL'][B[520021]], 'data': window['B1NL'][B[520197]], 'package': window['B1NL'][B[520150]], 'newRegister': window['B1NL'][B[520283]], 'pkgName': window['B1NL'][B[520163]], 'partnerId': window['B1NL'][B[520162]], 'platform_uid': window['B1NL'][B[520273]], 'deviceId': window['B1NL'][B[520164]], 'selectedServer': fj5r18, 'configType': window['B1NL'][B[520175]], 'exposeType': window['B1NL'][B[520177]], 'debugUsers': window['B1NL'][B[520171]], 'wxMenuTop': bz4l9k, 'wxShield': window['B1NL'][B[520179]] };if (window[B[520303]]) for (var h7u6ns in window[B[520303]]) {
        _$tqd[h7u6ns] = window[B[520303]][h7u6ns];
      }window[B[520412]][B[520035]]['B1LN2'](_$tqd);
    }
  } else console[B[520001]](B[520425] + window['B1LS'] + B[520426] + window['B1NSL'] + B[520427] + window[B[520180]] + B[520428] + window[B[520181]] + B[520429] + window['B1NLS'] + B[520430] + window['B1NS'] + B[520431] + window['B1SL'] + B[520432] + window['B1SN']);
};