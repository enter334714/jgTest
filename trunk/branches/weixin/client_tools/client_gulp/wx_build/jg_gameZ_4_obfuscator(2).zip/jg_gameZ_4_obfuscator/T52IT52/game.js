var B = wx.$B;
require(B[520000]);