var B = wx.$B;
console[B[520001]](B[520002]), window[B[520003]], wx[B[520004]](function (b9kzl) {
  if (b9kzl) {
    if (b9kzl[B[520005]]) {
      var rmj1o5 = window[B[520006]][B[520007]][B[520008]](new RegExp(/\./, 'g'), '_'),
          d_txq$ = b9kzl[B[520005]],
          eig = d_txq$[B[520009]](/(T5T5T5T5T5\/T52GT5MET52.js:)[0-9]{1,60}(:)/g);if (eig) for (var t$x0_y = 0x0; t$x0_y < eig[B[520010]]; t$x0_y++) {
        if (eig[t$x0_y] && eig[t$x0_y][B[520010]] > 0x0) {
          var b69k4 = parseInt(eig[t$x0_y][B[520008]](B[520011], '')[B[520008]](':', ''));d_txq$ = d_txq$[B[520008]](eig[t$x0_y], eig[t$x0_y][B[520008]](':' + b69k4 + ':', ':' + (b69k4 - 0x2) + ':'));
        }
      }d_txq$ = d_txq$[B[520008]](new RegExp(B[520012], 'g'), B[520013] + rmj1o5 + B[520014]), d_txq$ = d_txq$[B[520008]](new RegExp(B[520015], 'g'), B[520013] + rmj1o5 + B[520014]), b9kzl[B[520005]] = d_txq$;
    }var fr3 = { 'id': window['B1NL'][B[520016]], 'role': window['B1NL'][B[520017]], 'level': window['B1NL'][B[520018]], 'user': window['B1NL'][B[520019]], 'version': window['B1NL'][B[520020]], 'gamever': window[B[520006]][B[520007]], 'cdn': window['B1NL'][B[520021]], 'serverid': window['B1NL'][B[520022]] ? window['B1NL'][B[520022]][B[520023]] : 0x0, 'systemInfo': window[B[520024]], 'error': B[520025], 'stack': b9kzl ? b9kzl[B[520005]] : '' },
        pngeu = JSON[B[520026]](fr3);console[B[520027]](B[520028] + pngeu), (!window[B[520003]] || window[B[520003]] != fr3[B[520027]]) && (window[B[520003]] = fr3[B[520027]], window['B1_N'](fr3));
  }
});import 'T5T5bfT5T5.js';import 'T5T511T5T5.js';window[B[520029]] = require(B[520030]);import 'T5INDT5T5.js';import 'T5T5IT51T5T5.js';import 'T5T5MtadT5T5.js';import 'T5T5INIT5aT5.js';console[B[520001]](B[520031]), console[B[520001]](B[520032]), B1_NSL({ 'title': B[520033] });var Bg7np = { 'B12_LNS': !![] };new window[B[520034]](Bg7np), window[B[520034]][B[520035]]['B12SNL_']();if (window['B12_NLS']) clearInterval(window['B12_NLS']);window['B12_NLS'] = null, window['B12SL_N'] = function (oj5m, enpuig) {
  if (!oj5m || !enpuig) return 0x0;oj5m = oj5m[B[520036]]('.'), enpuig = enpuig[B[520036]]('.');const wi8 = Math[B[520037]](oj5m[B[520010]], enpuig[B[520010]]);while (oj5m[B[520010]] < wi8) {
    oj5m[B[520038]]('0');
  }while (enpuig[B[520010]] < wi8) {
    enpuig[B[520038]]('0');
  }for (var y4lv0$ = 0x0; y4lv0$ < wi8; y4lv0$++) {
    const us7pn = parseInt(oj5m[y4lv0$]),
          o5m1r = parseInt(enpuig[y4lv0$]);if (us7pn > o5m1r) return 0x1;else {
      if (us7pn < o5m1r) return -0x1;
    }
  }return 0x0;
}, window[B[520039]] = wx[B[520040]]()[B[520039]], console[B[520041]](B[520042] + window[B[520039]]);var B$ty_ = wx[B[520043]]();B$ty_[B[520044]](function (sh6) {
  console[B[520041]](B[520045] + sh6[B[520046]]);
}), B$ty_[B[520047]](function () {
  wx[B[520048]]({ 'title': B[520049], 'content': B[520050], 'showCancel': ![], 'success': function (t$vy) {
      B$ty_[B[520051]]();
    } });
}), B$ty_[B[520052]](function () {
  console[B[520041]](B[520053]);
}), window['B12SLN_'] = function () {
  console[B[520041]](B[520054]);var up7sng = wx[B[520055]]({ 'name': B[520056], 'success': function (_xd0) {
      console[B[520041]](B[520057]), console[B[520041]](_xd0), _xd0 && _xd0[B[520058]] == B[520059] ? (window['B1LS'] = !![], window['B1LSN_'](), window['B1LN_S']()) : setTimeout(function () {
        window['B12SLN_']();
      }, 0x1f4);
    }, 'fail': function (yl4v$) {
      console[B[520041]](B[520060]), console[B[520041]](yl4v$), setTimeout(function () {
        window['B12SLN_']();
      }, 0x1f4);
    } });up7sng && up7sng[B[520061]](rfj185 => {});
}, window['B12N_LS'] = function () {
  console[B[520041]](B[520062]);var p2wiae = wx[B[520055]]({ 'name': B[520063], 'success': function (su7hn) {
      console[B[520041]](B[520064]), console[B[520041]](su7hn), su7hn && su7hn[B[520058]] == B[520059] ? (window['B1NSL'] = !![], window['B1LSN_'](), window['B1LN_S']()) : setTimeout(function () {
        window['B12N_LS']();
      }, 0x1f4);
    }, 'fail': function (wa2i38) {
      console[B[520041]](B[520065]), console[B[520041]](wa2i38), setTimeout(function () {
        window['B12N_LS']();
      }, 0x1f4);
    } });p2wiae && p2wiae[B[520061]](v$lty => {});
}, window[B[520066]] = function () {
  window['B12SL_N'](window[B[520039]], B[520067]) >= 0x0 ? (console[B[520041]](B[520068] + window[B[520039]] + B[520069]), window['B1N_'](), window['B12SLN_'](), window['B12N_LS']()) : (window['B1NL_'](B[520070], window[B[520039]]), wx[B[520048]]({ 'title': B[520071], 'content': B[520072] }));
}, window[B[520024]] = '', wx[B[520073]]({ 'success'(nupsg) {
    window[B[520024]] = B[520074] + nupsg[B[520075]] + B[520076] + nupsg[B[520077]] + B[520078] + nupsg[B[520079]] + B[520080] + nupsg[B[520081]] + B[520082] + nupsg[B[520083]] + B[520084] + nupsg[B[520039]] + B[520085] + nupsg[B[520086]], console[B[520041]](window[B[520024]]), console[B[520041]](B[520087] + nupsg[B[520088]] + B[520089] + nupsg[B[520090]] + B[520091] + nupsg[B[520092]] + B[520093] + nupsg[B[520094]] + B[520095] + nupsg[B[520096]] + B[520097] + nupsg[B[520098]] + B[520099] + (nupsg[B[520100]] ? nupsg[B[520100]][B[520101]] + ',' + nupsg[B[520100]][B[520102]] + ',' + nupsg[B[520100]][B[520103]] + ',' + nupsg[B[520100]][B[520104]] : ''));var f58j = nupsg[B[520081]] ? nupsg[B[520081]][B[520105]]() : '',
        farw3 = nupsg[B[520077]] ? nupsg[B[520077]][B[520105]]()[B[520008]]('\x20', '') : '';window['B1NL'][B[520106]] = f58j[B[520107]](B[520108]) != -0x1, window['B1NL'][B[520109]] = f58j[B[520107]](B[520110]) != -0x1, window['B1NL'][B[520111]] = f58j[B[520107]](B[520108]) != -0x1 || f58j[B[520107]](B[520110]) != -0x1, window['B1NL'][B[520112]] = f58j[B[520107]](B[520113]) != -0x1 || f58j[B[520107]](B[520114]) != -0x1, window['B1NL'][B[520115]] = nupsg[B[520083]] ? nupsg[B[520083]][B[520105]]() : '', window['B1NL']['B12_SLN'] = ![], window['B1NL']['B12_NSL'] = 0x2;if (f58j[B[520107]](B[520110]) != -0x1) {
      if (nupsg[B[520086]] >= 0x18) window['B1NL']['B12_NSL'] = 0x3;else window['B1NL']['B12_NSL'] = 0x2;
    } else {
      if (f58j[B[520107]](B[520108]) != -0x1) {
        if (nupsg[B[520086]] && nupsg[B[520086]] >= 0x14) window['B1NL']['B12_NSL'] = 0x3;else {
          if (farw3[B[520107]](B[520116]) != -0x1 || farw3[B[520107]](B[520117]) != -0x1 || farw3[B[520107]](B[520118]) != -0x1 || farw3[B[520107]](B[520119]) != -0x1 || farw3[B[520107]](B[520120]) != -0x1) window['B1NL']['B12_NSL'] = 0x2;else window['B1NL']['B12_NSL'] = 0x3;
        }
      } else window['B1NL']['B12_NSL'] = 0x2;
    }console[B[520041]](B[520121] + window['B1NL']['B12_SLN'] + B[520122] + window['B1NL']['B12_NSL']);
  } }), wx[B[520123]]({ 'success': function (frj583) {
    console[B[520041]](B[520124] + frj583[B[520125]] + B[520126] + frj583[B[520127]]);
  } }), wx[B[520128]]({ 'success': function (ai83) {
    console[B[520041]](B[520129] + ai83[B[520130]]);
  } }), wx[B[520131]]({ 'keepScreenOn': !![] }), wx[B[520132]](function (i82a3) {
  console[B[520041]](B[520129] + i82a3[B[520130]] + B[520133] + i82a3[B[520134]]);
}), wx[B[520135]](function ($tx_0) {
  window['B1S_'] = $tx_0, window['B1L_S'] && window['B1S_'] && (console[B[520001]](B[520136] + window['B1S_'][B[520137]]), window['B1L_S'](window['B1S_']), window['B1S_'] = null);
}), window['B12NSL_'] = 0x0, window[B[520138]] = null, wx[B[520139]](function () {
  window['B12NSL_']++, wx[B[520140]]();if (window['B12NSL_'] >= 0x2) {
    window['B12NSL_'] = 0x0, console[B[520027]](B[520141]), wx[B[520142]]('0', 0x1);if (window['B1NL'] && window['B1NL'][B[520106]]) window['B1NL_'](B[520143], '');if (onMemoryWarningCallBack) onMemoryWarningCallBack();
  }
});