var B = wx.$B;
import 'T52MT5IT52.js';