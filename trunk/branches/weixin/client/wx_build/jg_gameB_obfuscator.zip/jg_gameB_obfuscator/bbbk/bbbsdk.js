var _ = wx.y$;
import Dall from "./bbbhelp";var config = { game_id: _[13060], game_pkg: _[13061], partner_id: "19", game_ver: _[13062], is_auth: !1, from: null, tmpId: { 1: _[13063], 2: _[13064], 3: _[13065] }, min_app_id: "" };window.config = config;var p$EB = p$EDB();var HOST = _[13046];var t;var t_second = 0;var t_max = 300;var p$DBE = null;var p$DEB = null;var p$EBD = null;function p$EDB() {
  var r = {};return { order_data: {}, init: function (e, n) {
      var o = e && e.game_ver ? e.game_ver : 0;console.log(_[13066]);var t = this;var a;a = (r = wx.getStorageSync(_[13067])) ? 0 : (r = t.uuid(16, 32), wx.setStorageSync(_[13067], r), 1), (i = wx.getStorageSync(_[13068])) || (i = t.uuid(16, 32), wx.setStorageSync(_[13068], i));e = wx.getLaunchOptionsSync();var r = e.scene || "";var i;console.log(_[13069]), console.log(e), a && e.query && e.query.ad_code && wx.setStorageSync(_[13070], e.query.ad_code), e.query && e.query.from && "" != e.query.from ? (a && wx.setStorageSync(_[13071], e.query.from), config.from = e.query.from) : (i = wx.getStorageSync(_[13071])) || "" == i || (config.from = i), console.log(config.from), t.log(_[13072], { install: a, scene: r }), wx.showShareMenu();t = e.query && e.query.invite ? e.query.invite : "";e = e.query && e.query.invite_type ? e.query.invite_type : "";t && (p$DEB = { invite: t, invite_type: e, is_new: a, scene: r }), o && this.checkGameVersion(o, function (e) {
        n && n(e);
      });
    }, login: function (e, n) {
      console.log(_[13073]);var t = this;r.login = _[12711] == typeof n ? n : null, config.is_auth ? wx.getSetting({ success: function (e) {
          var n, o;e.authSetting[_[13074]] ? (console.log(_[13075]), t.do_login()) : (console.log(_[13076]), wx.hideLoading({}), e = 2 * (n = wx.getSystemInfoSync()).screenWidth / 3, n.screenHeight, (o = wx.createUserInfoButton({ type: _[11414], text: _[13077], withCredentials: !1, style: { top: n.windowHeight / 2 + n.windowHeight / 4, left: n.windowWidth / 2 - 100, width: 200, height: 40, lineHeight: 40, backgroundColor: _[13078], color: _[2405], textAlign: _[505], fontSize: 16, borderRadius: 4 } })).show(), o.onTap(e => {
            console.log(e), p$ACBD({ title: _[13079] }), _[13080] == e.errMsg ? t.do_login({ head_img: e.userInfo.avatarUrl || "", nick_name: e.userInfo.nickName || "" }) : t.do_login(), o.destroy();
          }));
        }, fail: function () {
          console.log(_[13081]), t.do_login();
        } }) : (console.log(_[13082] + config.is_auth), t.do_login());
    }, do_login: function (o) {
      var a = this;wx.login({ success: function (e) {
          if (console.log(_[13083] + JSON.stringify(e)), e.code) {
            var t = a.getPublicData();if (t.is_from_min = 1, t.code = e.code, t.nick_name = o ? o.nick_name : "", t.head_img = o ? o.head_img : "", p$DEB && _[26] == typeof p$DEB) for (var n in p$DEB) t[n] = p$DEB[n];config.is_auth ? wx.getUserInfo({ success: function (e) {
                var n = e.encryptedData;var o = e.iv;e = e.signature;t.encryptedData = n, t.iv = o, t.signature = e, wx.request({ url: _[13049] + HOST + _[13084], method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: t, success: function (e) {
                    if (console.log(_[13085]), console.log(e), 200 == e.statusCode) {
                      var n = e.data;if (n.state) {
                        e = { userid: n.data.user_id, account: n.data.nick_name, token: n.data.token, invite_uid: n.data.invite_uid || "", invite_nickname: n.data.invite_nickname || "", invite_head_img: n.data.invite_head_img || "", head_img: n.data.head_img || "", is_client: n.data.is_client || "0", ios_pay: n.data.ios_pay || "0" };try {
                          wx.setStorageSync(_[13086], n.data.sdk_token), wx.setStorageSync(_[13087], n.data.user_id), wx.setStorageSync(_[13047], n.data.username), n.data.ext && wx.setStorageSync(_[13088], n.data.ext);
                        } catch (e) {}r.login && r.login(0, e);
                      } else r.login && r.login(1, { errMsg: n.msg });a.getShareInfo(_[13089], function (e) {
                        console.log(_[13090]), wx.onShareAppMessage(function () {
                          return a.logStartShare(_[13089]), { title: e.title, imageUrl: e.img, query: e.query };
                        });
                      });
                    } else r.login && r.login(1, { errMsg: _[13091] });
                  }, fail: function (e) {
                    r.login && r.login(1, { errMsg: e.errMsg });
                  } });
              }, fail: function (e) {
                r.login && r.login(1, { errMsg: e.errMsg });
              } }) : wx.request({ url: _[13049] + HOST + _[13084], method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: t, success: function (e) {
                if (console.log(_[13085]), console.log(e), 200 == e.statusCode) {
                  var n = e.data;if (n.state) {
                    e = { userid: n.data.user_id, account: n.data.nick_name, token: n.data.token, invite_uid: n.data.invite_uid || "", invite_nickname: n.data.invite_nickname || "", invite_head_img: n.data.invite_head_img || "", head_img: n.data.head_img || "", is_client: n.data.is_client || "0", ios_pay: n.data.ios_pay || "0" };try {
                      wx.setStorageSync(_[13086], n.data.sdk_token), wx.setStorageSync(_[13087], n.data.user_id), wx.setStorageSync(_[13047], n.data.username), n.data.ext && wx.setStorageSync(_[13088], n.data.ext);
                    } catch (e) {}r.login && r.login(0, e);
                  } else r.login && r.login(1, { errMsg: n.msg });a.getShareInfo(_[13089], function (e) {
                    console.log(_[13090]), wx.onShareAppMessage(function () {
                      return a.logStartShare(_[13089]), { title: e.title, imageUrl: e.img, query: e.query };
                    });
                  });
                } else r.login && r.login(1, { errMsg: _[13091] });
              } });
          } else r.login && r.login(1, { errMsg: e.errMsg });
        }, fail: function (e) {
          console.log(_[13092] + JSON.stringify(e)), (-1 < e.errMsg.indexOf(_[13093]) || -1 < e.errMsg.indexOf(_[13094])) && r.login && r.login(1, { errMsg: e.errMsg });
        } });
    }, share: function (e) {
      r.share = _[12711] == typeof callback ? callback : null;var n = e.type || _[12889];console.log(_[13095] + n);var o = this;this.getShareInfo(n, function (e) {
        o.logStartShare(n), wx.shareAppMessage({ title: e.title, imageUrl: e.img, query: e.query });
      });
    }, logStartShare: function (e) {
      var n = wx.getStorageSync(_[13086]);wx.request({ url: _[13049] + HOST + _[13096], method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: { game_pkg: config.game_pkg, partner_id: config.partner_id, sdk_token: n, server_id: p$DBE ? p$DBE.server_id : "", role_id: p$DBE ? p$DBE.role_id : "", type: e }, success: function (e) {} });
    }, p$BA: function () {
      wx.openCustomerServiceConversation();
    }, checkGameVersion: function (e, n) {
      console.log(_[13097]);wx.getStorageSync(_[13086]);wx.request({ url: _[13049] + HOST + _[13098], method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: { game_pkg: config.game_pkg, partner_id: config.partner_id, game_ver: e }, success: function (e) {
          console.log(_[13099]), console.log(e), 200 == e.statusCode ? (e = e.data, config.min_app_id = e.data.min_app_id, e.state ? n && n(e.data) : n && n({ develop: 0 })) : n && n({ develop: 0 });
        }, fail: function (e) {
          console.log(e);
        } });
    }, getShareInfo: function (e, n) {
      console.log(_[13100]);var o = wx.getStorageSync(_[13086]);wx.request({ url: _[13049] + HOST + _[13101], method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: { game_pkg: config.game_pkg, partner_id: config.partner_id, sdk_token: o, type: e, server_id: p$DBE ? p$DBE.server_id : "", role_id: p$DBE ? p$DBE.role_id : "", no_log: 1 }, success: function (e) {
          console.log(_[13102]), console.log(e), 200 == e.statusCode ? (e = e.data).state ? n && n(e.data) : r.share && r.share(1, { errMsg: _[13103] + e.msg }) : r.share && r.share(1, { errMsg: _[13104] });
        } });
    }, updateShare: function (e, n, o, t, a, r) {
      console.log(_[13105]);var i = wx.getStorageSync(_[13086]);wx.request({ url: _[13049] + HOST + _[13106], method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: { game_pkg: config.game_pkg, partner_id: config.partner_id, sdk_token: i, invite: e, invite_type: n, is_new: o, role_id: t, sever_id: a, scene: r }, success: function (e) {
          console.log(_[13107]), console.log(e);
        } });
    }, msgCheck: function (e, n) {
      console.log(_[13108]);var o = wx.getStorageSync(_[13086]);wx.request({ url: _[13049] + HOST + _[13109], method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: { game_pkg: config.game_pkg, partner_id: config.partner_id, sdk_token: o, content: e }, success: function (e) {
          console.log(_[13110]), console.log(e), n && n(e);
        } });
    }, pay: function (e, n) {
      var o = this;wx.checkSession({ success: function () {
          o.startPay(e, n);
        }, fail: function () {
          console.log(_[13111]), o.login({}, function () {
            o.startPay(e, n);
          });
        } });
    }, startPay: function (e, n) {
      console.log(_[13112]), console.log(e);var o = this;r.pay = _[12711] == typeof n ? n : null;var t = wx.getStorageSync(_[13086]);n = wx.getStorageSync(_[13088]);var a;t && n ? (a = wx.getSystemInfoSync(), t = { cpbill: e.cpbill, productid: e.productid, productname: e.productname, productdesc: e.productdesc, serverid: e.serverid, servername: e.servername, roleid: e.roleid, rolename: e.rolename, rolelevel: e.rolelevel, price: e.price, extension: e.extension, sdk_token: t, session_key: n, platform: a.platform }, o.order_data = t, (n = o.getPublicData()).order_data = JSON.stringify(t), n.is_from_min = 1, wx.request({ url: _[13049] + HOST + _[13113], method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: n, success: function (e) {
          console.log(_[13114]), console.log(e), 200 == e.statusCode ? (e = e.data).state ? void 0 === wx.requestPayment ? _[12807] == a.platform || _[12808] == a.platform ? e.data.is_android_pay ? 1 == e.data.ios_pay_type ? o.kfPay(e.data) : 2 == e.data.ios_pay_type && o.xiaoPay(e.data) : o.gamePay(e.data) : e.data.is_ios_pay ? 1 == e.data.ios_pay_type ? o.kfPay(e.data) : 2 == e.data.ios_pay_type && o.xiaoPay(e.data) : wx.showModal({ title: _[13115], content: _[13116], confirmText: _[13117], showCancel: !1 }) : o.minPay(e.data) : r.pay && r.pay(1, { errMsg: e.msg }) : r.login && r.login(1, { errMsg: _[13091] });
        } })) : r.pay && r.pay(1, { errMsg: _[13118] });
    }, xiaoPay: function (e) {
      wx.navigateToMiniProgram({ appId: config.min_app_id, path: _[13119] + e.orderId + _[13120] + e.money, extraData: {}, envVersion: _[13058], success(e) {} });
    }, minPay: function (n) {
      var o = this;wx.requestPayment({ timeStamp: n.timeStamp, nonceStr: n.nonceStr, package: n.package, signType: n.signType, paySign: n.paySign, success: function (e) {
          _[13121] == e.errMsg && (e = { cpOrderNo: o.order_data.cpbill, orderNo: n.orderId, amount: o.order_data.price, extension: o.order_data.extension }, r.pay && r.pay(0, e));
        }, fail: function (e) {
          _[13122] == e.errMsg ? r.pay && r.pay(2, { errMsg: _[13123] }) : r.pay && r.pay(1, { errMsg: _[13124] + e.err_desc });
        }, complete: function (e) {} });
    }, gamePay: function (n) {
      var o = this;n.buyQuantity <= n.balance ? (console.log(_[13125]), wx.showModal({ title: _[13115], content: _[13126] + n.balance + _[13127] + n.buyQuantity + _[13128], showCancel: !1, confirmText: _[13117], success: function () {
          o.gameGoPay(n);
        } })) : (console.log(_[13129]), wx.requestMidasPayment({ mode: _[13130], env: n.env, offerId: n.offerId, currencyType: n.currencyType, platform: n.platform, buyQuantity: n.buyQuantity, zoneId: n.zoneId, success: function (e) {
          _[13131] == e.errMsg && o.gameGoPay(n);
        }, fail: function (e) {
          -1 !== e.errMsg.indexOf(_[13132]) ? r.pay && r.pay(2, { errMsg: _[13123] }) : r.pay && r.pay(1, { errMsg: _[13124] + e.errMsg });
        }, complete: function (e) {} }));
    }, kfPay: function (e) {
      p$EBD = e.orderId, wx.showModal({ title: _[13115], content: _[13133], showCancel: !1, confirmText: _[13117], success: function () {
          wx.openCustomerServiceConversation({ showMessageCard: !0, sendMessageTitle: _[13134], sendMessageImg: _[13135] });
        } });
    }, gameGoPay: function (n, e) {
      console.log(_[13136]);var o = this;var t = wx.getStorageSync(_[13088]);wx.request({ url: _[13049] + HOST + _[13137] + config.partner_id + "/" + config.game_pkg + "/", method: _[12850], dataType: _[13051], header: { "content-type": _[12906] }, data: { order_id: n.orderId, time: n.time, sign: n.sign, session_key: t }, success: function (e) {
          console.log(_[13138]), console.log(e), 200 == e.statusCode && (1 == e.data.state ? (e = { cpOrderNo: o.order_data.cpbill, orderNo: n.orderId, amount: o.order_data.price, extension: o.order_data.extension }, r.pay && r.pay(0, e)) : r.pay && r.pay(1, { errMsg: _[13139] }));
        }, fail: function () {} });
    }, logCreateRole: function (e) {
      var n = wx.getStorageSync(_[13087]);var o = wx.getStorageSync(_[13047]);var t = {};t.user_id = n, t.user_name = o, t.role_id = e.roleid, t.role_lev = e.rolelevel, t.role_name = e.rolename, t.server_id = e.serverid, e.roleid && e.serverid && (p$DBE = { role_id: e.roleid, server_id: e.serverid }), this.log(_[43], t);
    }, logEnterGame: function (e) {
      var n = wx.getStorageSync(_[13087]);var o = wx.getStorageSync(_[13047]);var t = {};t.user_id = n, t.user_name = o, t.role_id = e.roleid, t.role_lev = e.rolelevel, t.role_name = e.rolename, t.server_id = e.serverid, e.roleid && e.serverid && (p$DBE = { role_id: e.roleid, server_id: e.serverid }), this.log(_[13140], t), p$DEB && this.updateShare(p$DEB.invite, p$DEB.invite_type, p$DEB.is_new, e.roleid, e.serverid, p$DEB.scene);
    }, logRoleUpLevel: function (e) {
      var n = wx.getStorageSync(_[13087]);var o = wx.getStorageSync(_[13047]);var t = {};t.user_id = n, t.user_name = o, t.role_id = e.roleid, t.role_lev = e.rolelevel, t.role_name = e.rolename, t.server_id = e.serverid, e.roleid && e.serverid && (p$DBE = { role_id: e.roleid, server_id: e.serverid }), this.log(_[13141], t);
    }, uuid: function (e, n) {
      var o = _[13142].split("");var t,
          a = [];var r;if (e = e || o.length, n) for (t = 0; t < n; t++) a[t] = o[0 | Math.random() * e];else for (a[8] = a[13] = a[18] = a[23] = "-", a[14] = "4", t = 0; t < 36; t++) a[t] || (r = 0 | 16 * Math.random(), a[t] = o[19 == t ? 3 & r | 8 : r]);return a.join("");
    }, getPublicData: function () {
      var e = wx.getSystemInfoSync();var n = wx.getStorageSync(_[13067]);var o = wx.getStorageSync(_[13068]);var t = wx.getStorageSync(_[13070]);return { game_id: config.game_id, game_pkg: config.game_pkg, partner_id: config.partner_id, ad_code: t, uuid: n, idfv: o, dname: e.model, mac: _[13143], net_type: 0 == e.wifiSignal ? "4G" : _[13144], os_ver: e.system, sdk_ver: e.version, game_ver: config.game_ver, device: _[12807] == e.platform ? 1 : 2 };
    }, log: function (e, n) {
      var o = this.getPublicData();for (var t in n) o[t] = n[t];console.log(_[13145] + e), console.log(o), wx.request({ url: _[13049] + HOST + _[13146] + e + _[13147] + encodeURIComponent(JSON.stringify(o)) });
    }, getDate: function () {
      var e = new Date();return e.getFullYear() + "-" + e.getMonth() + "-" + e.getDate();
    }, downloadClient: function () {
      wx.openCustomerServiceConversation();
    }, subscribeMessage: function (e, n) {
      console.log(_[13148] + e), r.subscribeMessage = _[12711] == typeof n ? n : null, wx.requestSubscribeMessage({ tmplIds: e, success(e) {
          console.log(_[13149]), console.log(e), r.subscribeMessage && r.subscribeMessage(e);
        }, fail(e) {
          console.log(_[13150]), console.log(e), r.subscribeMessage && r.subscribeMessage(e);
        } });
    }, weiduanHelper: function () {
      new Dall().stebutonanimation(config.partner_id, config.game_pkg, config.game_id);
    } };
}function run(e, n, o) {
  e in p$EB && p$EB[e](n, o);
}exports.init = function (e, n) {
  run(_[10998], e, n);
}, exports.login = function (e) {
  run(_[13151], "", e);
}, exports.pay = function (e, n) {
  run(_[13152], e, n);
}, exports.p$BA = function () {
  run(_[13153]);
}, exports.logCreateRole = function (e, n, o, t, a) {
  run(_[13154], { serverid: e, servername: n, roleid: o, rolename: t, rolelevel: a });
}, exports.logEnterGame = function (e, n, o, t, a) {
  run(_[13155], { serverid: e, servername: n, roleid: o, rolename: t, rolelevel: a });
}, exports.logRoleUpLevel = function (e, n, o, t, a) {
  run(_[13156], { serverid: e, servername: n, roleid: o, rolename: t, rolelevel: a });
}, exports.share = function (e) {
  run(_[12889], { type: e });
}, exports.msgCheck = function (e, n) {
  run(_[12841], e, n);
}, exports.downloadClient = function () {
  run(_[13157]);
}, exports.subscribeMessage = function (e, n) {
  run(_[13158], e, n);
}, exports.getConfig = function () {
  return { game_id: config.game_id, game_pkg: config.game_pkg, partner_id: config.partner_id };
}, exports.getPublicData = function () {
  run(_[13159]);
}, exports.weiduanHelper = function () {
  run(_[13160]);
};