var _ = wx.y$;
var _dfcbge = wx['y$'];0x3ac00;