var _ = wx.y$;
var _dqpons = wx['y$'];0xda37c;