var _ = wx.y$;
import _d$y0_z from '../bbbk/bbbsdk.js';window[_[26222]] = { 'wxVersion': window[_[13554]][_[26160]] }, window[_[26223]] = !0x1, window['p$DC'] = 0x1, window[_[26224]] = 0x1, window['p$BCD'] = !0x0, window[_[26225]] = !0x0, window['p$CED'] = '', window['p$CD'] = { 'base_cdn': _[0x3218], 'cdn': _[0x3218] }, p$CD[_[26226]] = {}, p$CD[_[24428]] = '0', p$CD[_[10852]] = window[_[26222]][_[26227]], p$CD[_[12809]] = '', p$CD['os'] = '1', p$CD[_[26228]] = _[0x3219], p$CD[_[26229]] = _[0x321a], p$CD[_[26230]] = _[0x321b], p$CD[_[26231]] = _[0x321c], p$CD[_[26232]] = _[0x321d], p$CD[_[24431]] = '1', p$CD[_[24573]] = '', p$CD[_[26233]] = '', p$CD[_[26234]] = 0x0, p$CD[_[26235]] = {}, p$CD[_[26236]] = parseInt(p$CD[_[24431]]), p$CD[_[24571]] = p$CD[_[24431]], p$CD[_[24570]] = {}, p$CD['p$AC'] = _[0x321e], p$CD[_[26237]] = !0x1, p$CD[_[17508]] = _[0x321f], p$CD[_[24562]] = Date[_[13201]](), p$CD[_[17348]] = _[0x3220], p$CD[_[13626]] = '_a', p$CD[_[26238]] = 0x2, p$CD[_[13216]] = 0x7c1, p$CD[_[26227]] = window[_[26222]][_[26227]], p$CD[_[13941]] = !0x1, p$CD[_[13520]] = !0x1, window['p$BDC'] = 0x5, window['p$BD'] = !0x1, window['p$DB'] = !0x1, window['p$CBD'] = !0x1, window['p$CDB'] = !0x1, window['p$BC'] = !0x1, window['p$CB'] = !0x1, window['p$DBC'] = !0x1, window[_[12833]] = function (chfd) {
  console[_[13503]](_[0x3221], chfd), wx[_[14667]]({}), wx[_[26193]]({ 'title': _[0xcbe], 'content': chfd, 'success'(rwuvst) {
      rwuvst[_[26239]] ? console[_[13503]](_[0x3222]) : rwuvst[_[13552]] && console[_[13503]](_[0x3223]);
    } });
}, window['p$ABCD'] = function (zvxywu) {
  console[_[13503]](_[0x3224], zvxywu), p$ACDB(), wx[_[26193]]({ 'title': _[0xcbe], 'content': zvxywu, 'confirmText': _[0x3225], 'cancelText': _[0x2062], 'success'($32_0) {
      $32_0[_[26239]] ? window['p$CA']() : $32_0[_[13552]] && (console[_[13503]](_[0x3226]), wx[_[24624]]({}));
    } });
}, window['p$DEBC'] = function (pnmor) {
  console[_[13503]](_[0x3227], pnmor), wx[_[26193]]({ 'title': _[0xcbe], 'content': pnmor, 'confirmText': _[0x2b10], 'showCancel': !0x1, 'complete'(_0y$xz) {
      console[_[13503]](_[0x3226]), wx[_[24624]]({});
    } });
}, window['p$ABDC'] = !0x1, window['p$ACBD'] = function (sqrto) {
  window['p$ABDC'] = !0x0, wx[_[14666]](sqrto);
}, window['p$ACDB'] = function () {
  window['p$ABDC'] && (window['p$ABDC'] = !0x1, wx[_[14667]]({}));
}, window['p$ADBC'] = function (ik) {
  window[_[26186]][_[36]]['p$ADBC'](ik);
}, window[_[12841]] = function (z10_, wvxytu) {
  _d$y0_z[_[12841]](z10_, function (dfieg) {
    dfieg && dfieg[_[510]] ? 0x1 == dfieg[_[510]][_[2763]] ? wvxytu(!0x0) : (wvxytu(!0x1), console[_[11]](_[0x3228] + dfieg[_[510]][_[26240]])) : console[_[13503]](_[0x3229], dfieg);
  });
}, window['p$ADCB'] = function (vtqsru) {
  console[_[13503]](_[0x322a], vtqsru);
}, window['p$ACD'] = function (dhgfce) {}, window['p$ADC'] = function (jihgkl, qnlpmo, gfkih) {}, window['p$AD'] = function (wyxvut) {
  console[_[13503]](_[0x322b], wyxvut), window[_[26186]][_[36]][_[26241]](), window[_[26186]][_[36]][_[26242]](), window[_[26186]][_[36]][_[26243]]();
}, window['p$DA'] = function (srtoq) {
  console[_[13503]](_[0x322c]), window['p$ABCD'](_[0x322c]), p$AC(srtoq || _[0x322d]);
}, window['p$CAD'] = function (cbedaf) {
  cbedaf = JSON[_[13534]](cbedaf), (cbedaf[_[26244]] = window[_[13554]][_[26160]], cbedaf[_[26245]] = window['p$CD'][_[24570]] ? window['p$CD'][_[24570]][_[17325]] : 0x0, cbedaf['p$ED'] = window['p$ED']), cbedaf = JSON[_[14394]](cbedaf), (console[_[9]](_[0x322e] + cbedaf), p$AC(cbedaf));
}, window['p$CDA'] = function (sqrpt) {
  sqrpt = { 'id': window['p$CD'][_[26161]], 'role': window['p$CD'][_[2521]], 'level': window['p$CD'][_[26162]], 'user': window['p$CD'][_[24572]], 'version': window['p$CD'][_[13216]], 'cdn': window['p$CD'][_[14403]], 'pkgName': window['p$CD'][_[24573]], 'gamever': window[_[13554]][_[26160]], 'serverid': window['p$CD'][_[24570]] ? window['p$CD'][_[24570]][_[17325]] : 0x0, 'p$ED': window['p$ED'], 'error': sqrpt }, sqrpt = JSON[_[14394]](sqrpt), (console[_[13212]](_[0x322f] + sqrpt), window['p$AC'](sqrpt));
}, window['p$AC'] = function (x_y0z$) {
  var _32$01;_[0x3230] != window['p$CD'][_[26210]] && (_32$01 = p$CD['p$AC'] + _[0x3231] + p$CD[_[24572]], wx[_[13498]]({ 'url': _32$01, 'method': _[0x3232], 'data': x_y0z$, 'header': { 'content-type': _[0x3233], 'cache-control': _[0x3234] }, 'success': function (fhegj) {}, 'fail': function (lnmjik) {}, 'complete': function () {} }));
}, window[_[26246]] = function () {
  function sroqp() {
    return (0x10000 * (0x1 + Math[_[13230]]()) | 0x0)[_[13357]](0x10)[_[13509]](0x1);
  }return sroqp() + sroqp() + '-' + sroqp() + '-' + sroqp() + '-' + sroqp() + '+' + sroqp() + sroqp() + sroqp();
}, window['p$CA'] = function () {
  console[_[13503]](_[0x3235]);var $1z02_ = _d$y0_z[_[26247]]();p$CD[_[24571]] = $1z02_[_[26248]], p$CD[_[26236]] = $1z02_[_[26248]], p$CD[_[24431]] = $1z02_[_[26248]], p$CD[_[24573]] = $1z02_[_[26249]], $1z02_ = { 'game_ver': p$CD[_[10852]] }, (p$CD[_[26233]] = this[_[26246]](), _d$y0_z[_[10998]]($1z02_, this['p$DAC'][_[13194]](this)));
}, window['p$DAC'] = function (y_xz$0) {
  var opqsrt = y_xz$0[_[26250]];console[_[13503]](_[0x3236] + opqsrt + _[0x3237] + (0x1 == opqsrt) + _[0x3238] + y_xz$0[_[26160]] + _[0x3239] + window[_[26222]][_[26227]]), window['p$BDEC'](window[_[26222]][_[26227]], y_xz$0[_[26160]]) < 0x0 ? (console[_[13503]](_[0x323a]), p$CD[_[26229]] = _[0x323b], p$CD[_[26230]] = _[0x323c], p$CD[_[26231]] = _[0x323d], p$CD[_[24427]] = _[0x323e], p$CD[_[26251]] = _[0x323f], p$CD[_[13941]] = !0x1) : 0x0 == window['p$BDEC'](window[_[26222]][_[26227]], y_xz$0[_[26160]]) ? (console[_[13503]](_[0x3240]), p$CD[_[26229]] = _[0x321a], p$CD[_[26230]] = _[0x321b], p$CD[_[26231]] = _[0x321c], p$CD[_[24427]] = _[0x323e], p$CD[_[26251]] = '', p$CD[_[13941]] = !0x0) : (console[_[13503]](_[0x3241]), p$CD[_[26229]] = _[0x321a], p$CD[_[26230]] = _[0x321b], p$CD[_[26231]] = _[0x321c], p$CD[_[24427]] = _[0x323e], p$CD[_[26251]] = '', p$CD[_[13941]] = !0x1), p$CD[_[26234]] = config[_[25855]] || 0x0, this['p$BCAD'](), this['p$BCDA'](), _d$y0_z[_[13151]](this['p$DCA'][_[13194]](this));
}, window['p$DCA'] = function (gfdhi, jlnk) {
  p$ACBD({ 'title': _[0x3242] }), 0x0 === gfdhi && jlnk && jlnk[_[25932]] ? (p$CD[_[26252]] = jlnk[_[25932]], sendApi(p$CD[_[26229]], _[0x3243], { 'platform': p$CD[_[26228]], 'partner_id': p$CD[_[24431]], 'token': jlnk[_[25932]], 'game_pkg': p$CD[_[24573]], 'deviceId': p$CD[_[26233]], 'scene': _[0x3244] + p$CD[_[26234]] }, this['p$BACD'][_[13194]](this), p$BDC, p$DA)) : (p$AC(JSON[_[14394]]({ 'error': JSON[_[14394]]({ 'type': _[0x3245], 'status': gfdhi, 'data': jlnk }) })), window['p$ABCD'](_[0x3246] + (jlnk && jlnk[_[24630]] ? '，' + jlnk[_[24630]] : '')));
}, window['p$BACD'] = function (fegdh) {
  fegdh ? _[0x13e0] == fegdh[_[2763]] ? (p$CD[_[24569]] = String(fegdh[_[24572]]), p$CD[_[24572]] = String(fegdh[_[24572]]), p$CD[_[24560]] = String(fegdh[_[24560]]), p$CD[_[24571]] = String(fegdh[_[24560]]), p$CD[_[24574]] = String(fegdh[_[24574]]), p$CD[_[26253]] = String(fegdh[_[17319]]), p$CD[_[26254]] = String(fegdh[_[2761]]), p$CD[_[17319]] = '', sendApi(p$CD[_[26229]], _[0x3247], { 'partner_id': p$CD[_[24431]], 'uid': p$CD[_[24572]], 'version': p$CD[_[10852]], 'game_pkg': p$CD[_[24573]], 'device': p$CD[_[26233]] }, this['p$BADC'][_[13194]](this), p$BDC, p$DA)) : window['p$ABCD'](_[0x3248] + fegdh[_[2763]]) : window['p$ABCD'](_[0x3249]);
}, window['p$BADC'] = function (ikmjn) {
  ikmjn ? _[0x13e0] == ikmjn[_[2763]] ? ikmjn[_[510]] && 0x0 != ikmjn[_[510]][_[8332]] ? (p$CD[_[13600]] = ikmjn[_[26255]], p$CD[_[24570]] = { 'server_id': String(ikmjn[_[510]][0x0][_[17325]]), 'server_name': String(ikmjn[_[510]][0x0][_[26256]]), 'entry_ip': ikmjn[_[510]][0x0][_[24584]], 'entry_port': parseInt(ikmjn[_[510]][0x0][_[24585]]), 'status': p$DACB(ikmjn[_[510]][0x0]), 'start_time': ikmjn[_[510]][0x0][_[26257]], 'cdn': p$CD[_[14403]] }, this['p$CDE']()) : window['p$ABCD'](_[0x324a]) : window['p$ABCD'](_[0x324b] + ikmjn[_[2763]]) : window['p$ABCD'](_[0x324c]);
}, window['p$CDE'] = function () {
  if (0x1 == p$CD[_[13600]]) {
    var gkijhf = p$CD[_[24570]][_[198]];if (-0x1 === gkijhf || 0x0 === gkijhf) return void window['p$ABCD'](-0x1 === gkijhf ? _[0x324d] : _[0x324e]);p$DBAC(0x0, p$CD[_[24570]][_[17325]]), window[_[26186]][_[36]][_[26258]](p$CD[_[13600]]);
  } else window[_[26186]][_[36]][_[26259]](), p$ACDB();window['p$CB'] = !0x0, window['p$DCBA'](), window['p$DE']();
}, window['p$BCAD'] = function () {
  sendApi(p$CD[_[26229]], _[0x324f], { 'game_pkg': p$CD[_[24573]], 'version_name': p$CD[_[26251]] }, function (kjlnim) {
    kjlnim ? _[0x13e0] == kjlnim[_[2763]] ? (p$CD[_[26260]] = kjlnim[_[510]][_[26261]] || p$CD[_[26260]], p$CD[_[14403]] = kjlnim[_[510]][_[26261]] || p$CD[_[14403]], p$CD[_[13216]] = kjlnim[_[510]][_[10852]] || p$CD[_[13216]], console[_[11]](_[0x3250] + p$CD[_[13216]]), window['p$CDB'] = !0x0, window['p$DCBA'](), window['p$DE']()) : window['p$ABCD'](_[0x3251] + kjlnim[_[2763]]) : window['p$ABCD'](_[0x3252]);
  });
}, window[_[26262]], window['p$BCDA'] = function () {
  sendApi(p$CD[_[26229]], _[0x3253], { 'game_pkg': p$CD[_[24573]] }, p$BDAC);
}, window['p$BDAC'] = function (zwy$v) {
  if (_[0x13e0] === zwy$v[_[2763]] && zwy$v[_[510]]) {
    for (var ebfgdc in window[_[26262]] = zwy$v[_[510]], zwy$v[_[510]]) p$CD[ebfgdc] = zwy$v[_[510]][ebfgdc];
  } else console[_[11]](_[0x3254] + zwy$v[_[2763]]);window['p$BC'] = !0x0, window['p$DE']();
}, window[_[26263]] = function ($x_0z, fcegd, gecf, cgbefd, tywvxu, vyx$z, lijhkg, y0_x$, efdchg) {
  tywvxu = String(tywvxu), (p$CD[_[26226]][tywvxu] = { 'productid': tywvxu, 'productname': lijhkg, 'productdesc': y0_x$, 'roleid': $x_0z, 'rolename': fcegd, 'rolelevel': gecf, 'price': vyx$z, 'callback': efdchg }, sendApi(p$CD[_[26231]], _[0x3255], { 'game_pkg': p$CD[_[24573]], 'server_id': p$CD[_[24570]][_[17325]], 'server_name': p$CD[_[24570]][_[26256]], 'level': gecf, 'uid': p$CD[_[24572]], 'role_id': $x_0z, 'role_name': fcegd, 'product_id': tywvxu, 'product_name': lijhkg, 'product_desc': y0_x$, 'money': vyx$z, 'partner_id': p$CD[_[24431]] }, toPayCallBack, p$BDC, p$DA));
}, window[_[26264]] = function (hdife) {
  var hlkm;hdife && (0xc8 === hdife[_[26265]] || _[0x13e0] == hdife[_[2763]] ? ((hlkm = p$CD[_[26226]][String(hdife[_[26266]])])[_[13393]] && hlkm[_[13393]](hdife[_[26266]], hdife[_[26267]], -0x1), _d$y0_z[_[13152]]({ 'cpbill': hdife[_[26267]], 'productid': hdife[_[26266]], 'productname': hlkm[_[26268]], 'productdesc': hlkm[_[26269]], 'serverid': p$CD[_[24570]][_[17325]], 'servername': p$CD[_[24570]][_[26256]], 'roleid': hlkm[_[26270]], 'rolename': hlkm[_[26271]], 'rolelevel': hlkm[_[26272]], 'price': hlkm[_[25197]], 'extension': JSON[_[14394]]({ 'cp_order_id': hdife[_[26267]] }) }, function (wvst, sxvu) {
    hlkm[_[13393]] && 0x0 == wvst && hlkm[_[13393]](hdife[_[26266]], hdife[_[26267]], wvst), console[_[11]](JSON[_[14394]]({ 'type': _[0x3256], 'status': wvst, 'data': hdife, 'role_name': hlkm[_[26271]] }));
  })) : alert(hdife[_[11]]));
}, window['p$BDCA'] = function () {}, window['p$ABD'] = function (wyutx, y_z0x$, y$xwv, hgjief) {
  _d$y0_z[_[13154]](p$CD[_[24570]][_[17325]], p$CD[_[24570]][_[26256]] || p$CD[_[24570]][_[17325]], wyutx, y_z0x$, y$xwv), sendApi(p$CD[_[26229]], _[0x3257], { 'game_pkg': p$CD[_[24573]], 'server_id': p$CD[_[24570]][_[17325]], 'role_id': wyutx, 'uid': p$CD[_[24572]], 'role_name': y_z0x$, 'role_type': hgjief, 'level': y$xwv });
}, window['p$ADB'] = function (trpqo, nlopmk, kjolm, nomkp, vwyzx$) {
  p$CD[_[26161]] = trpqo, p$CD[_[2521]] = nlopmk, p$CD[_[26162]] = kjolm, _d$y0_z[_[13155]](p$CD[_[24570]][_[17325]], p$CD[_[24570]][_[26256]] || p$CD[_[24570]][_[17325]], trpqo, nlopmk, kjolm), sendApi(p$CD[_[26229]], _[0x3258], { 'game_pkg': p$CD[_[24573]], 'server_id': p$CD[_[24570]][_[17325]], 'role_id': trpqo, 'uid': p$CD[_[24572]], 'role_name': nlopmk, 'role_type': nomkp, 'level': kjolm, 'evolution': vwyzx$ });
}, window['p$BAD'] = function (vxuyz, sqpro, w$vyz, stwrv, gefdhc) {
  p$CD[_[26161]] = vxuyz, p$CD[_[2521]] = sqpro, p$CD[_[26162]] = w$vyz;
}, window['p$BDA'] = function (_yxw$z) {}, window['p$AB'] = function (porqmn) {
  _d$y0_z[_[12889]](_[0x3259], function (kojnml) {
    porqmn(kojnml);
  });
}, window['p$BA'] = function () {
  _d$y0_z['p$BA']();
}, window[_[26273]] = function () {
  _d$y0_z[_[13160]]();
}, window['p$DBA'] = null, window['p$CABD'] = null, window['p$DAB'] = function (aefcdb) {
  window['p$CABD'] = aefcdb, window['p$CABD'] && window['p$DBA'] && (console[_[11]](_[0x3215] + window['p$DBA'][_[199]]), window['p$CABD'](window['p$DBA']), window['p$DBA'] = null);
}, window['p$CADB'] = function (opkl, z_xwy$, wsvru, nr) {
  window[_[13176]](_[0x325a], { 'game_pkg': window['p$CD'][_[24573]], 'role_id': z_xwy$, 'server_id': wsvru }, nr);
}, window['p$CBAD'] = function (ab, kjihml) {
  wx[_[26274]](function _10324(ikhjm) {
    var lopqn = [],
        jlhikm = [],
        jkihfg = window[_[13554]][_[26275]];for (var zvy$x in jkihfg) {
      var fji = Number(zvy$x);ab && ab[_[8332]] && -0x1 == ab[_[13226]](fji) || (jlhikm[_[13182]](jkihfg[zvy$x]), lopqn[_[13182]]([fji, 0x3]));
    }0x0 <= window['p$BDEC'](window[_[26187]], _[0x325b]) ? (console[_[13503]](_[0x325c]), _d$y0_z[_[13158]](jlhikm, function (gklihj) {
      if (console[_[13503]](_[0x325d]), console[_[13503]](gklihj), gklihj && _[0x325e] == gklihj[_[24630]]) {
        for (var nomjl in jkihfg) if (_[0x325f] == gklihj[jkihfg[nomjl]]) {
          var sptoqr = Number(nomjl);for (var rnmpoq = 0x0; rnmpoq < lopqn[_[8332]]; rnmpoq++) if (lopqn[rnmpoq][0x0] == sptoqr) {
            lopqn[rnmpoq][0x1] = 0x1;break;
          }
        }
      }0x0 <= window['p$BDEC'](window[_[26187]], _[0x3260]) ? wx[_[26276]]({ 'withSubscriptions': !0x0, 'success': function (gdhi) {
          var hgkfij = gdhi[_[26277]][_[26278]];if (hgkfij) {
            for (var $0y_1z in console[_[13503]](_[0x3261]), console[_[13503]](hgkfij), jkihfg) if (_[0x325f] == hgkfij[jkihfg[$0y_1z]]) {
              var hkjig = Number($0y_1z);for (var gbcfed = 0x0; gbcfed < lopqn[_[8332]]; gbcfed++) if (lopqn[gbcfed][0x0] == hkjig) {
                lopqn[gbcfed][0x1] = 0x2;break;
              }
            }console[_[13503]](lopqn), kjihml && kjihml(lopqn);
          } else console[_[13503]](_[0x3262]), console[_[13503]](gdhi), console[_[13503]](lopqn), kjihml && kjihml(lopqn);
        }, 'fail': function () {
          console[_[13503]](_[0x3263]), console[_[13503]](lopqn), kjihml && kjihml(lopqn);
        } }) : (console[_[13503]](_[0x3264] + window[_[26187]]), console[_[13503]](lopqn), kjihml && kjihml(lopqn));
    })) : (console[_[13503]](_[0x3265] + window[_[26187]]), console[_[13503]](lopqn), kjihml && kjihml(lopqn)), wx[_[26279]](_10324);
  });
}, window['p$CBDA'] = { 'isSuccess': !0x1, 'level': _[0x3266], 'isCharging': !0x1 }, window['p$CDAB'] = function (_10z2) {
  wx[_[26211]]({ 'success': function (qrtus) {
      var fecd = window['p$CBDA'];fecd[_[26280]] = !0x0, fecd[_[2510]] = Number(qrtus[_[2510]])[_[14272]](0x0), fecd[_[26212]] = qrtus[_[26212]], _10z2 && _10z2(fecd[_[26280]], fecd[_[2510]], fecd[_[26212]]);
    }, 'fail': function (mrpnoq) {
      console[_[13503]](_[0x3267], mrpnoq[_[24630]]), mrpnoq = window['p$CBDA'], _10z2 && _10z2(mrpnoq[_[26280]], mrpnoq[_[2510]], mrpnoq[_[26212]]);
    } });
}, window[_[13176]] = function (rqvst, swvx, qrtsp, lpmkno, mlki, ruvtw, bcefdg, dihfg) {
  null == lpmkno && (lpmkno = 0x1);var w$yzv = new XMLHttpRequest();w$yzv[_[24521]] = function () {
    if (0x4 == w$yzv[_[3]]) {
      if (0xc8 == w$yzv[_[198]] || 0x12d == w$yzv[_[198]]) {
        var pnqo;w$yzv[_[24522]];if (pnqo = JSON[_[13534]](w$yzv[_[24522]]), !ruvtw || ruvtw(pnqo, w$yzv, rqvst)) return void (qrtsp && qrtsp(pnqo));console[_[11]](rqvst), console[_[9]](pnqo);
      }0x0 < lpmkno - 0x1 ? setTimeout(function () {
        send(rqvst, swvx, qrtsp, lpmkno - 0x1, mlki, ruvtw);
      }, 0x3e8) : mlki && mlki(JSON[_[14394]]({ 'error': JSON[_[14394]]({ 'url': rqvst, 'status': w$yzv[_[198]], 'response': w$yzv[_[24522]], 'responseType': w$yzv[_[24637]] }) }));
    }
  }, w$yzv[_[13186]](bcefdg || _[0x2a5f], rqvst), w$yzv[_[24637]] = _[0x2c96], w$yzv[_[26281]](_[0x3268], dihfg || _[0x3233]), w$yzv[_[13176]](swvx);
}, window[_[26282]] = function (surtq, npmo, zuxwvy, ihgl, dfghce, $xwz_, _341) {
  zuxwvy = zuxwvy || {};var txwv = Math[_[13229]](Date[_[13201]]() / 0x3e8);zuxwvy[_[2761]] = txwv, zuxwvy[_[24461]] = npmo;var yxutvw = Object[_[13349]](zuxwvy)[_[13924]](),
      trvsu = '',
      lnqop = '';for (var usxtvw = 0x0; usxtvw < yxutvw[_[8332]]; usxtvw++) trvsu = trvsu + (0x0 == usxtvw ? '' : '&') + yxutvw[usxtvw] + zuxwvy[yxutvw[usxtvw]], lnqop = lnqop + (0x0 == usxtvw ? '' : '&') + yxutvw[usxtvw] + '=' + encodeURIComponent(zuxwvy[yxutvw[usxtvw]]);trvsu += p$CD[_[26232]], npmo = _[0x3269] + md5(trvsu), send(surtq + '?' + lnqop + ('' == lnqop ? '' : '&') + npmo, null, ihgl, dfghce, $xwz_, _341 || function (wsvurt) {
    return _[0x13e0] == wsvurt[_[2763]];
  }, null, _[0x326a]);
}, window['p$CDBA'] = function (xustwv, lnmqpo) {
  var fgecdb = 0x0;p$CD[_[24570]] && (fgecdb = p$CD[_[24570]][_[17325]]), sendApi(p$CD[_[26230]], _[0x326b], { 'partnerId': p$CD[_[24431]], 'gamePkg': p$CD[_[24573]], 'logTime': Math[_[13229]](Date[_[13201]]() / 0x3e8), 'platformUid': p$CD[_[24574]], 'type': xustwv, 'serverId': fgecdb }, null, 0x2, null, function () {
    return !0x0;
  });
}, window['p$ABC'] = function (jihgfk) {
  sendApi(p$CD[_[26229]], _[0x326c], { 'partner_id': p$CD[_[24431]], 'uid': p$CD[_[24572]], 'version': p$CD[_[10852]], 'game_pkg': p$CD[_[24573]], 'device': p$CD[_[26233]] }, p$ACB, p$BDC, p$DA);
}, window['p$ACB'] = function (fbcdeg) {
  _[0x13e0] === fbcdeg[_[2763]] && fbcdeg[_[510]] ? (fbcdeg[_[510]][_[14988]]({ 'id': -0x2, 'name': _[0x326d] }), fbcdeg[_[510]][_[14988]]({ 'id': -0x1, 'name': _[0x326e] }), p$CD[_[26283]] = fbcdeg[_[510]], window[_[17544]] && window[_[17544]][_[26284]]()) : (p$CD[_[26285]] = !0x1, window['p$ABCD'](_[0x326f] + fbcdeg[_[2763]]));
}, window['p$BAC'] = function (tqsurv) {
  sendApi(p$CD[_[26229]], _[0x3270], { 'partner_id': p$CD[_[24431]], 'uid': p$CD[_[24572]], 'version': p$CD[_[10852]], 'game_pkg': p$CD[_[24573]] }, p$BCA, p$BDC, p$DA);
}, window['p$BCA'] = function (ljomnk) {
  if (p$CD[_[26286]] = !0x1, _[0x13e0] === ljomnk[_[2763]] && ljomnk[_[510]]) {
    for (var mlnik = 0x0; mlnik < ljomnk[_[510]][_[8332]]; mlnik++) ljomnk[_[510]][mlnik][_[198]] = p$DACB(ljomnk[_[510]][mlnik]);p$CD[_[26235]][-0x1] = window[_[26287]](ljomnk[_[510]]), window[_[17544]][_[26288]](-0x1);
  } else window['p$ABCD'](_[0x3271] + ljomnk[_[2763]]);
}, window['p$CAB'] = function (qospr, opsnrq) {
  sendApi(p$CD[_[26229]], _[0x3272], { 'partner_id': p$CD[_[24431]], 'uid': p$CD[_[24572]], 'version': p$CD[_[10852]], 'game_pkg': p$CD[_[24573]], 'device': p$CD[_[26233]], 'server_group_id': opsnrq }, p$CBA, p$BDC, p$DA);
}, window['p$CBA'] = function (cfegdb) {
  if (p$CD[_[26286]] = !0x1, _[0x13e0] === cfegdb[_[2763]] && cfegdb[_[510]] && cfegdb[_[510]][_[510]]) {
    var $_y1z = cfegdb[_[510]][_[26289]],
        olnkpm = [];for (var x$0_ = 0x0; x$0_ < cfegdb[_[510]][_[510]][_[8332]]; x$0_++) cfegdb[_[510]][_[510]][x$0_][_[198]] = p$DACB(cfegdb[_[510]][_[510]][x$0_]), 0x0 != olnkpm[_[8332]] && 0x0 == cfegdb[_[510]][_[510]][x$0_][_[198]] || (olnkpm[olnkpm[_[8332]]] = cfegdb[_[510]][_[510]][x$0_]);p$CD[_[26235]][$_y1z] = window[_[26287]](olnkpm), window[_[17544]][_[26288]]($_y1z);
  } else window['p$ABCD'](_[0x3273] + cfegdb[_[2763]]);
}, window['p$CEBD'] = function (ponqrs) {
  sendApi(p$CD[_[26229]], _[0x3274], { 'partner_id': p$CD[_[24431]], 'uid': p$CD[_[24572]], 'version': p$CD[_[10852]] }, reqServerRecommendCallBack, p$BDC, p$DA);
}, window[_[26290]] = function (xzu) {
  if (p$CD[_[26286]] = !0x1, _[0x13e0] === xzu[_[2763]] && xzu[_[510]]) {
    for (var pmoqln = 0x0; pmoqln < xzu[_[510]][_[8332]]; pmoqln++) xzu[_[510]][pmoqln][_[198]] = p$DACB(xzu[_[510]][pmoqln]);p$CD[_[26235]][-0x2] = window[_[26287]](xzu[_[510]]), window[_[17544]][_[26288]](-0x2);
  } else alert(_[0x3275] + xzu[_[2763]]);
}, window[_[26287]] = function (fiejg) {
  if (!fiejg && fiejg[_[8332]] <= 0x0) return fiejg;for (let sotr = 0x0; sotr < fiejg[_[8332]]; sotr++) fiejg[sotr][_[26291]] && 0x1 == fiejg[sotr][_[26291]] && (fiejg[sotr][_[26256]] += _[0x3276]);return fiejg;
}, window['p$DABC'] = function (qrpno, pmlonk) {
  qrpno = qrpno || p$CD[_[24570]][_[17325]], sendApi(p$CD[_[26229]], _[0x3277], { 'type': '4', 'game_pkg': p$CD[_[24573]], 'server_id': qrpno }, pmlonk);
}, window['p$DACB'] = function (fabedc) {
  return fabedc ? 0x1 == fabedc[_[198]] ? 0x1 == fabedc[_[26292]] ? 0x2 : 0x1 : 0x0 == fabedc[_[198]] ? 0x0 : -0x1 : -0x1;
}, window['p$DBAC'] = function (snqrop, mojlnk) {
  p$CD[_[26293]] = { 'step': snqrop, 'server_id': mojlnk }, sendApi(p$CD[_[26229]], _[0x3278], { 'partner_id': p$CD[_[24431]], 'uid': p$CD[_[24572]], 'game_pkg': p$CD[_[24573]], 'server_id': mojlnk, 'platform': p$CD[_[24560]], 'platform_uid': p$CD[_[24574]], 'check_login_time': p$CD[_[26254]], 'check_login_sign': p$CD[_[26253]], 'version_name': p$CD[_[26251]] }, p$DBCA, p$BDC, p$DA, function ($_y01z) {
    return _[0x13e0] == $_y01z[_[2763]] || _[0x3279] == $_y01z[_[11]] || _[0x327a] == $_y01z[_[11]];
  });
}, window['p$DBCA'] = function (surt) {
  var _1$032;_[0x13e0] === surt[_[2763]] && surt[_[510]] ? ((_1$032 = p$CD[_[24570]])[_[26294]] = p$CD[_[26236]], _1$032[_[17319]] = String(surt[_[510]][_[26295]]), _1$032[_[24562]] = parseInt(surt[_[510]][_[2761]]), surt[_[510]][_[24561]] ? _1$032[_[24561]] = parseInt(surt[_[510]][_[24561]]) : _1$032[_[24561]] = parseInt(surt[_[510]][_[17325]]), _1$032[_[26296]] = 0x0, _1$032[_[14403]] = p$CD[_[26260]], _1$032[_[26297]] = surt[_[510]][_[26298]], _1$032[_[26299]] = surt[_[510]][_[26299]], 0x1 == p$CD[_[13600]] && _1$032[_[26299]] && 0x1 == _1$032[_[26299]][_[26300]] && (p$CD[_[26301]] = 0x1, window[_[26186]][_[36]]['p$EBC']()), p$DCAB()) : sendApi(p$CD[_[26229]], _[0x3243], { 'platform': p$CD[_[26228]], 'partner_id': p$CD[_[24431]], 'token': p$CD[_[26252]], 'game_pkg': p$CD[_[24573]], 'deviceId': p$CD[_[26233]], 'scene': _[0x3244] + p$CD[_[26234]] }, function (z_01$y) {
    _[0x327b] != z_01$y[_[2763]] ? (p$CD[_[26253]] = String(z_01$y[_[17319]]), p$CD[_[26254]] = String(z_01$y[_[2761]]), setTimeout(function () {
      p$DBAC(p$CD[_[26293]][_[11446]], p$CD[_[26293]][_[17325]]);
    }, 0x5dc)) : window['p$ABCD'](_[0x3248] + z_01$y[_[2763]]);
  }, p$BDC, p$DA, function (ceadf) {
    return _[0x13e0] == ceadf[_[2763]] || _[0x327b] == ceadf[_[2763]];
  });
}, window['p$DCAB'] = function () {
  ServerLoading[_[36]][_[26258]](p$CD[_[13600]]), window['p$BD'] = !0x0, window['p$DE']();
}, window['p$DCBA'] = function () {
  var _zx0y;window['p$DB'] && window['p$CBD'] && window['p$CDB'] && window['p$CB'] && (window[_[25840]][_[36]] || (console[_[13503]](_[0x327c] + window[_[25840]][_[36]]), _zx0y = wx[_[26302]]()[_[199]] || 0x0, _zx0y = { 'cdn': window['p$CD'][_[14403]], 'spareCdn': window['p$CD'][_[24427]], 'newRegister': window['p$CD'][_[13600]], 'wxPC': window['p$CD'][_[24430]], 'wxIOS': window['p$CD'][_[13520]], 'wxParam': { 'limitLoad': window['p$CD']['p$CE'], 'benchmarkLevel': window['p$CD']['p$EC'], 'wxFrom': window[_[13554]][_[25855]] ? 0x1 : 0x0, 'wxSDKVersion': window[_[26187]] }, 'configType': window['p$CD'][_[17348]], 'exposeType': window['p$CD'][_[13626]], 'scene': _zx0y }, new window[_[25840]](_zx0y, window['p$CD'][_[13216]], window['p$CED'])));
}, window['p$DE'] = function () {
  if (window['p$DB'] && window['p$CBD'] && window['p$CDB'] && window['p$CB'] && window['p$BD'] && window['p$BC']) {
    if (p$DBC) p$ACDB();else {
      p$DBC = !0x0, window[_[25840]][_[36]] || window['p$DCBA']();var ehcdfg = 0x0,
          pknom = wx[_[26303]]();pknom && (window['p$CD'][_[26209]] && (ehcdfg = pknom[_[39]]), console[_[11]](_[0x327d] + pknom[_[39]] + _[0x327e] + pknom[_[11424]] + _[0x327f] + pknom[_[5130]] + _[0x3280] + pknom[_[3595]] + _[0x3281] + pknom[_[3012]] + _[0x3282] + pknom[_[3013]]));var ghjlk = {};for (const fegidh in p$CD[_[24570]]) ghjlk[fegidh] = p$CD[_[24570]][fegidh];var feih = { 'channel': window['p$CD'][_[24571]], 'account': window['p$CD'][_[24572]], 'userId': window['p$CD'][_[24569]], 'serverId': ghjlk[_[17325]], 'cdn': window['p$CD'][_[14403]], 'data': window['p$CD'][_[510]], 'package': window['p$CD'][_[24428]], 'newRegister': window['p$CD'][_[13600]], 'pkgName': window['p$CD'][_[24573]], 'partnerId': window['p$CD'][_[24431]], 'platform_uid': window['p$CD'][_[24574]], 'deviceId': window['p$CD'][_[26233]], 'selectedServer': ghjlk, 'configType': window['p$CD'][_[17348]], 'exposeType': window['p$CD'][_[13626]], 'debugUsers': window['p$CD'][_[17508]], 'wxMenuTop': ehcdfg, 'wxShield': window['p$CD'][_[13941]] };if (window[_[26262]]) {
        for (var kimh in window[_[26262]]) feih[kimh] = window[_[26262]][kimh];
      }window[_[25840]][_[36]]['p$EBDC'](feih);
    }
  }
};