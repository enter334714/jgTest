var _ = wx.y$;
var _dfdeig = wx['y$'];0xb0a3b;