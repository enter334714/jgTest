var _ = wx.y$;
var _dqptrsu = wx['y$'];0x2c61b;