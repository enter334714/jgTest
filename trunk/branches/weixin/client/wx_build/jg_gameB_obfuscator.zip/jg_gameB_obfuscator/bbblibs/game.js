var _ = wx.y$;
require(_[0x32f5]);