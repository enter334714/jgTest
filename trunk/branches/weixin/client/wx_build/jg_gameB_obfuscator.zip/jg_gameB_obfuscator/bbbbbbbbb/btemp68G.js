var _ = wx.y$;
var _dolnp = wx['y$'];0x73639;