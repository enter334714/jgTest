var _ = wx.y$;
import 'lsjdflaamain.js';