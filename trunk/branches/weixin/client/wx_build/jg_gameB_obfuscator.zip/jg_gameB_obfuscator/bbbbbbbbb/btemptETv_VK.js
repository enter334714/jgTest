var _ = wx.y$;
var _dvxuzwy = wx['y$'];0xc7c36;