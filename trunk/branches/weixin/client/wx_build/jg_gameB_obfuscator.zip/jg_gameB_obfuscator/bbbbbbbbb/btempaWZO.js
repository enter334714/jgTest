var _ = wx.y$;
var _dmihkjl = wx['y$'];0x7056d;