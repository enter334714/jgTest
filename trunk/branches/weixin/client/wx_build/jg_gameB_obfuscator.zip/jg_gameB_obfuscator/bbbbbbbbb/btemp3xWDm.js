var _ = wx.y$;
var _dqpsnr = wx['y$'];0x45790;