var _ = wx.y$;
var _dhilkjg = wx['y$'];0x30a63;